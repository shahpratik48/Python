# How to configure `delivery_config.json`

One file holds the whole hierarchy **and** every pod's GitLab links:

```
Division > Subdivision > Stream > Crew > Pod
                                          ├── issue_projects  (one or more)
                                          └── mr_repos        (one or more)
```

A pod is defined in exactly one place. Adding one never means editing two files and keeping them in
step.

## Shape

```json
{
  "reporting": { "...": "window, baseline and thresholds -- see below" },
  "divisions": [
    { "name": "Global Wealth Management Americas",
      "subdivisions": [
        { "name": "Global Wealth Management Americas",
          "streams": [
            { "name": "Data Analytics and Foundational Platforms",
              "crews": [
                { "name": "STAAT Data Science",
                  "pods": [
                    { "name": "Insights",
                      "key": "insights",
                      "group_path": "ubs/.../commons",
                      "issue_projects": ["ubs/.../staat-ds-insights-home"],
                      "mr_repos": {
                        "IKG": "ubs/.../ikg-dags",
                        "NLG": "ubs/.../nlg-dags"
                      } } ] } ] } ] } ] }
  ]
}
```

---

## Adding things

### A new pod

Append to the `pods` list of the crew it belongs to:

```json
{
  "name": "Data Platform",
  "issue_projects": ["ubs/.../dp-board", "ubs/.../dp-intake"],
  "mr_repos": { "ingest": "ubs/.../dp-ingest", "api": "ubs/.../dp-api" }
}
```

Nothing else to change. The next run produces `Data_Platform_pod_productivity_*.xlsx` and `.html`,
loads the four pod tables, and includes it in the crew roll-up.

| Field | Required | Notes |
|---|---|---|
| `name` | yes | Display name. Also the **start of every file name** for that pod, and its `scope_name` in the database. |
| `issue_projects` | yes | **One or more** projects whose issues belong to the pod. Accepts a string or a list. |
| `mr_repos` | yes | **One or more** repositories whose MRs belong to the pod. Accepts `{"Label": "path"}` or a bare list. |
| `key` | no | Auto-derived from `name` (`Data Platform` → `data_platform`). Must be unique within the crew. |
| `group_path` | no | Group holding iterations and epics. Defaults to the first issue project's parent. Needed for proper iteration names. |

### A new issue link or MR link on an existing pod

Both are lists, so just add to them:

```json
"issue_projects": ["ubs/.../board-a", "ubs/.../board-b"],
"mr_repos": { "svc-one": "ubs/.../svc-one", "svc-two": "ubs/.../svc-two" }
```

Issues are pooled across every issue link; MRs are summed across every MR link.

### A new crew

Append to that stream's `crews`. Each crew produces its own roll-up alongside its pods:

```json
{ "name": "Data Engineering", "pods": [ { "...": "pod objects" } ] }
```

### A new stream, subdivision or division

Same pattern at the matching level — append an object with a `name` and the list below it:

```json
{ "name": "Another Division",
  "subdivisions": [
    { "name": "Sub A",
      "streams": [
        { "name": "Stream A",
          "crews": [ { "name": "Crew A", "pods": [ "..." ] } ] } ] } ] }
```

Nothing in the Python names a division, stream, crew or pod — the code walks whatever is in the file.

---

## Accepted shapes

**`mr_repos`** as a labelled map, or a bare list where the label is the last path segment:

```json
"mr_repos": { "ingest": "ubs/.../dp-ingest" }    →  column header "ingest"
"mr_repos": [ "ubs/.../dp-ingest" ]              →  column header "dp-ingest"
```

**Full URLs are fine anywhere a path is** — they are normalised, so you can paste from the browser:

```json
"issue_projects": ["https://devcloud.ubs.net/ubs/dp/board-a"]   →  ubs/dp/board-a
```

**A link may name a project or a group.** Projects are tried first; anything that is not one is
expanded as a group and every project beneath it is included. So a pod can point at a single
repository or at a whole sub-group without the config saying which.

---

## Reporting settings

```json
"reporting": {
  "start_month": "2024-11",
  "end_month": "2026-07",
  "baseline_month": "2025-11",
  "baseline_window_months": 3,
  "target_gain_pct": 20.0,
  "target_months": 14,
  "issue_sla_days": 5,
  "mr_sla_hours": 72,
  "issue_slowest_trim_pct": 15
}
```

| Setting | Meaning |
|---|---|
| `start_month` / `end_month` | The reporting window. |
| `baseline_month` | First month of the baseline. |
| `baseline_window_months` | Baseline is the **mean** of this many months from `baseline_month` — 3 means Nov-25, Dec-25, Jan-26. Set to 1 for a single-month baseline. |
| `target_gain_pct` / `target_months` | The aspiration ramp: 0% at the baseline, reaching the target after this many months. |
| `issue_sla_days` | Business days before an issue is flagged. |
| `mr_sla_hours` | Hours before a merge request is flagged. |
| `issue_slowest_trim_pct` | Slowest N% of each month's in-scope issues excluded from Cycle Time. 0 disables. |

> Changing any of these alters what stored months mean. Re-run once with
> `force_full_refresh=True` so history is recomputed on the new basis.

---

## Validation

A malformed file **raises rather than falling back to a default** — quietly reporting on the wrong
pods would be worse than stopping. Errors name the offending pod:

```
Pod 'NoRepos' needs at least one entry in 'mr_repos'.
Duplicate pod key(s) ['insights'] in crew 'STAAT Data Science' -- keys become file and
table names, so they must be unique.
```

Run cell 1 of the notebook (*Check the configuration*) after any edit. It prints the resolved
hierarchy and link counts without touching GitLab, so a mistake surfaces in seconds rather than
part-way through a long run.
