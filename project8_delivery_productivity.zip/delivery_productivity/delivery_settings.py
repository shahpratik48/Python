"""
Configuration for pod and crew delivery reporting.

Everything -- the org hierarchy and every pod's issue and MR links -- lives
in a single `delivery_config.json`. A pod is defined in exactly one place,
so adding one never means editing two files and keeping them in step.

Secrets are never hard-coded. They resolve as
    environment variable -> Airflow Variable -> prompt (notebook only)
"""
from __future__ import annotations

import getpass
import json
import logging
import os
import re
import sys
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional

_LOG_FMT = "%(asctime)s | %(levelname)-7s | %(name)-22s | %(message)s"
_configured = False


def setup_logging(level: str = "INFO", log_dir: Optional[str] = None,
                  log_to_file: bool = True) -> str:
    global _configured
    root = logging.getLogger()
    if _configured:
        return getattr(root, "_dl_log", "")
    root.setLevel(getattr(logging, str(level).upper(), logging.INFO))
    for h in list(root.handlers):
        root.removeHandler(h)
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(logging.Formatter(_LOG_FMT))
    root.addHandler(sh)
    path = ""
    if log_to_file:
        log_dir = log_dir or os.path.dirname(os.path.abspath(__file__))
        os.makedirs(log_dir, exist_ok=True)
        path = os.path.join(log_dir, "delivery_report_%s.log"
                            % datetime.now().strftime("%Y%m%d_%H%M%S"))
        fh = logging.FileHandler(path, encoding="utf-8")
        fh.setFormatter(logging.Formatter(_LOG_FMT))
        root.addHandler(fh)
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    root._dl_log = path
    _configured = True
    return path


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)


def _env(k, d=None):
    return os.getenv(k, d)


def _norm_path(value) -> str:
    """Accepts a bare project path or a full GitLab URL, returns the path the
    API expects -- so configuration can be pasted from a browser."""
    p = str(value or "").strip().rstrip("/")
    if not p:
        return ""
    if "://" in p:
        p = p.split("://", 1)[1]
        p = p.split("/", 1)[1] if "/" in p else ""
    return p.strip("/")


# --------------------------------------------------------------------------
@dataclass
class Pod:
    name: str
    key: str
    issue_projects: List[str] = field(default_factory=list)
    mr_repos: Dict[str, str] = field(default_factory=dict)
    group_path: str = ""
    crew: str = ""
    stream: str = ""
    subdivision: str = ""
    division: str = ""

    @staticmethod
    def from_dict(d: dict, ctx: dict) -> "Pod":
        name = str(d.get("name") or "").strip()
        if not name:
            raise ValueError("Every pod needs a 'name'. Offending entry: %r" % (d,))
        key = str(d.get("key") or "").strip() or \
            re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")

        raw = d.get("issue_projects")
        if isinstance(raw, str):
            raw = [raw]
        issues = [_norm_path(x) for x in (raw or []) if str(x).strip()]
        if not issues:
            raise ValueError("Pod %r needs at least one entry in 'issue_projects'." % name)

        raw = d.get("mr_repos")
        repos: Dict[str, str] = {}
        if isinstance(raw, dict):
            for label, path in raw.items():
                if str(path).strip():
                    repos[str(label)] = _norm_path(path)
        elif isinstance(raw, (list, tuple)):
            for path in raw:
                if str(path).strip():
                    p = _norm_path(path)
                    repos[p.rsplit("/", 1)[-1]] = p
        if not repos:
            raise ValueError("Pod %r needs at least one entry in 'mr_repos'." % name)

        return Pod(name=name, key=key, issue_projects=issues, mr_repos=repos,
                   group_path=_norm_path(d.get("group_path", "")) or issues[0].rsplit("/", 1)[0],
                   **ctx)

    @property
    def safe_name(self) -> str:
        """Filename-safe pod name, used to prefix that pod's report files."""
        return "".join(c if (c.isalnum() or c in "._-") else "_" for c in self.name).strip("_")


@dataclass
class Crew:
    name: str
    stream: str = ""
    subdivision: str = ""
    division: str = ""
    pods: List[Pod] = field(default_factory=list)

    @property
    def safe_name(self) -> str:
        return "".join(c if (c.isalnum() or c in "._-") else "_" for c in self.name).strip("_")


CONFIG_FILE = _env("DELIVERY_CONFIG_FILE",
                   os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "delivery_config.json"))


def load_crews(path: Optional[str] = None) -> List[Crew]:
    """Every crew in the config, each with its pods fully resolved.

    A malformed file raises rather than falling back to a default -- quietly
    reporting on the wrong pods would be worse than stopping.
    """
    log = get_logger("delivery.config")
    target = path or CONFIG_FILE
    if not os.path.exists(target):
        raise FileNotFoundError(
            "Config not found at %s. Keep delivery_config.json beside these scripts, or point "
            "DELIVERY_CONFIG_FILE at it." % target)
    raw = json.load(open(target, encoding="utf-8"))

    crews: List[Crew] = []
    for div in raw.get("divisions", []):
        dn = str(div.get("name", ""))
        for sub in div.get("subdivisions", []):
            sn = str(sub.get("name", ""))
            for st in sub.get("streams", []):
                tn = str(st.get("name", ""))
                for c in st.get("crews", []):
                    cn = str(c.get("name", ""))
                    ctx = {"crew": cn, "stream": tn, "subdivision": sn, "division": dn}
                    pods = [Pod.from_dict(p, ctx) for p in c.get("pods", [])]
                    if not pods:
                        log.warning("Crew %r has no pods -- skipped.", cn)
                        continue
                    keys = [p.key for p in pods]
                    dupes = {k for k in keys if keys.count(k) > 1}
                    if dupes:
                        raise ValueError("Duplicate pod key(s) %s in crew %r -- keys become "
                                          "file and table names, so they must be unique."
                                          % (sorted(dupes), cn))
                    crews.append(Crew(name=cn, stream=tn, subdivision=sn, division=dn, pods=pods))
    if not crews:
        raise ValueError("No crews with pods found in %s." % target)
    log.info("Loaded %d crew(s), %d pod(s) from %s",
             len(crews), sum(len(c.pods) for c in crews), target)
    return crews


def load_reporting(path: Optional[str] = None) -> dict:
    target = path or CONFIG_FILE
    raw = json.load(open(target, encoding="utf-8"))
    return raw.get("reporting", {}) or {}


# --------------------------------------------------------------------------
@dataclass
class DeliverySettings:
    """Runtime settings. The reporting window and thresholds come from the
    config file; anything here can still be overridden per run."""

    gitlab_url: str = field(default_factory=lambda: _env("GITLAB_URL", "https://devcloud.ubs.net"))
    gitlab_token: Optional[str] = field(default_factory=lambda: _env("GITLAB_TOKEN", ""))
    gitlab_token_var: str = field(default_factory=lambda: _env(
        "GITLAB_TOKEN_VAR", "GENESIS_DDLC_IKG_GIT_SECRET"))

    start_month: str = "2024-11"
    end_month: str = "2026-07"
    baseline_month: str = "2025-11"
    baseline_window_months: int = 3
    target_gain_pct: float = 20.0
    target_months: int = 14
    issue_sla_days: float = 5.0
    mr_sla_hours: float = 72.0
    issue_slowest_trim_pct: float = 15.0

    # Throughput is per pod. A pod report covers one pod, so the divisor is 1;
    # the crew roll-up divides by however many pods it covers.
    pod_count: int = 1

    in_progress_labels: List[str] = field(default_factory=lambda: [
        s.strip() for s in _env("DELIVERY_IN_PROGRESS_LABELS",
                                "in progress,in-progress,doing,wip").split(",") if s.strip()])

    # Parallelism. The run is network-bound and now spans several pods, so
    # this matters more than in a single-pod report.
    max_workers: int = field(default_factory=lambda: int(_env("DELIVERY_MAX_WORKERS", "32")))

    # ---------------- Greenplum ----------------
    gp_host: str = field(default_factory=lambda: _env("GREENPLUM_HOST",
                                                      "greenplum-rdsp.zur.swissbank.com"))
    gp_port: int = field(default_factory=lambda: int(_env("GREENPLUM_PORT", "5432")))
    gp_db: str = field(default_factory=lambda: _env("GREENPLUM_DB", "gprdsp"))
    gp_user: str = field(default_factory=lambda: _env("GREENPLUM_USER", "ds_rdsp_dev"))
    gp_password: Optional[str] = field(default_factory=lambda: _env("GREENPLUM_PASSWORD", ""))
    gp_password_var: str = field(default_factory=lambda: _env("GP_PASSWORD_VAR",
                                                              "GREENPLUM_PASSWORD"))
    gp_schema: str = field(default_factory=lambda: _env("DELIVERY_GP_SCHEMA",
                                                        "sandbox_prj_smart_insights"))
    gp_owner_group: str = field(default_factory=lambda: _env(
        "IKG_TABLE_OWNER_GROUP", "erd_gpdb_prj_smart_insights"))
    gp_reader_group: str = field(default_factory=lambda: _env(
        "IKG_TABLE_READER_GROUP", "erd_gpdb_prj_smart_insights_ro"))
    load_to_greenplum: bool = field(
        default_factory=lambda: _env("DELIVERY_LOAD_GP", "true").lower() == "true")

    output_dir: str = field(default_factory=lambda: _env(
        "DELIVERY_OUTPUT_DIR", os.path.dirname(os.path.abspath(__file__))))

    # ---------------- table names ----------------
    # Pod-level and crew-level are kept apart deliberately: mixing a pod row
    # and a crew roll-up in one table would double-count on any naive SUM.
    tbl_pod_issue_detail: str = "pod_issue_detail"
    tbl_pod_mr_detail: str = "pod_mr_detail"
    tbl_pod_issue_summary: str = "pod_issue_monthly_summary"
    tbl_pod_mr_summary: str = "pod_mr_monthly_summary"
    tbl_crew_issue_detail: str = "crew_rollup_issue_detail"
    tbl_crew_mr_detail: str = "crew_rollup_mr_detail"
    tbl_crew_issue_summary: str = "crew_rollup_issue_monthly_summary"
    tbl_crew_mr_summary: str = "crew_rollup_mr_monthly_summary"

    # per-pod context, set by the runner
    pod: Optional[Pod] = None
    crew_name: str = ""
    issue_group: str = ""
    mr_group: str = ""

    def apply_reporting(self, rep: dict) -> "DeliverySettings":
        for k in ("start_month", "end_month", "baseline_month"):
            if rep.get(k):
                setattr(self, k, str(rep[k]))
        for k in ("baseline_window_months", "target_months"):
            if rep.get(k) is not None:
                setattr(self, k, int(rep[k]))
        for k in ("target_gain_pct", "issue_sla_days", "mr_sla_hours",
                  "issue_slowest_trim_pct"):
            if rep.get(k) is not None:
                setattr(self, k, float(rep[k]))
        return self

    def _airflow_var(self, key):
        try:
            from airflow.models import Variable  # type: ignore
            return Variable.get(key, default_var=None)
        except Exception:
            return None

    def resolve_secrets(self, interactive: bool = True) -> "DeliverySettings":
        log = get_logger("delivery.settings")
        if not self.gitlab_token:
            self.gitlab_token = self._airflow_var(self.gitlab_token_var)
        if not self.gitlab_token and interactive:
            self.gitlab_token = getpass.getpass("GitLab personal access token: ").strip() or None
        if not self.gitlab_token:
            raise RuntimeError("No GitLab token. Set GITLAB_TOKEN or the Airflow Variable '%s'."
                               % self.gitlab_token_var)
        log.info("GitLab token resolved.")

        if self.load_to_greenplum:
            if not self.gp_password:
                self.gp_password = self._airflow_var(self.gp_password_var)
            if not self.gp_password and interactive:
                self.gp_password = getpass.getpass(
                    "Greenplum password for %s@%s: " % (self.gp_user, self.gp_host)).strip() or None
            if not self.gp_password:
                raise RuntimeError(
                    "No Greenplum password. Set GREENPLUM_PASSWORD or the Airflow Variable '%s', "
                    "or set load_to_greenplum=False." % self.gp_password_var)
            log.info("Greenplum password resolved for %s@%s/%s.",
                     self.gp_user, self.gp_host, self.gp_db)
        return self

    def for_pod(self, pod: Pod) -> "DeliverySettings":
        """A copy scoped to one pod, so the collector can stay unchanged."""
        import copy
        s = copy.copy(self)
        s.pod = pod
        s.crew_name = pod.crew
        s.pod_count = 1
        return s
