"""
Orchestration: a report per pod, then a crew roll-up from the same data.

    for each pod (in parallel)
        collect -> metrics -> chart -> xlsx + html -> 4 pod tables
    then
        combine every pod's rows -> crew chart -> xlsx + html -> 4 crew tables

The crew roll-up reuses the pod data rather than re-querying GitLab. That
matters: the crew covers every project of every pod, so fetching it again
would double the slowest part of the run and could produce numbers that
disagree with the pod reports they are supposed to summarise.

Pods run concurrently, and the fetching inside each pod is itself
parallel. The two levels multiply, so `pod_workers` is kept modest while
`max_workers` does the heavy lifting -- otherwise the two together would
open far more connections than a shared GitLab instance should see.
"""
from __future__ import annotations

import datetime as _dt
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from delivery_charts import build_figure, save_png
from delivery_gitlab import GitLabClient
from delivery_metrics import build_series, collect, month_range, monthly_stats
from delivery_output import write_html, write_xlsx
from delivery_settings import (Crew, DeliverySettings, Pod, get_logger, load_crews,
                               load_reporting)

log = get_logger("delivery.main")


@dataclass
class ScopeResult:
    """One report: a pod, or the crew roll-up."""
    level: str                      # "pod" | "crew"
    name: str
    crew_name: str = ""
    months: List[str] = field(default_factory=list)
    current_month: str = ""
    issues: List = field(default_factory=list)
    mrs: List = field(default_factory=list)
    stats: Dict = field(default_factory=dict)
    series: object = None
    xlsx_path: str = ""
    html_path: str = ""
    chart_path: str = ""
    greenplum: Optional[dict] = None
    months_fetched: List[str] = field(default_factory=list)
    months_from_db: List[str] = field(default_factory=list)
    error: str = ""


@dataclass
class RunResult:
    crew: str
    pods: List[ScopeResult] = field(default_factory=list)
    crew_result: Optional[ScopeResult] = None

    @property
    def failed_pods(self) -> List[ScopeResult]:
        return [p for p in self.pods if p.error]


def _file_prefix(level: str, name: str) -> str:
    safe = "".join(c if (c.isalnum() or c in "._-") else "_" for c in name).strip("_")
    return "%s_%s_productivity" % (safe, level)


def _report(settings, level, name, crew_name, months, current_month, issues, mrs,
            pod_count, include_pod, progress=None) -> ScopeResult:
    """Everything downstream of collection: stats, chart, files, database."""
    def say(m):
        log.info(m)
        if progress:
            progress(m)

    stats = monthly_stats(issues, mrs, months, None, pod_count=pod_count)
    ser = build_series(stats, months, settings)

    prefix = _file_prefix(level, name)
    chart = save_png(build_figure(ser, name), settings.output_dir, prefix + "_dashboard")
    xlsx = write_xlsx(settings, ser, stats, months, issues, mrs, chart, current_month,
                      settings.output_dir, label=name, include_pod=include_pod,
                      file_prefix=prefix)
    html = write_html(settings, ser, stats, months, issues, mrs, chart, current_month,
                      settings.output_dir, label=name, include_pod=include_pod,
                      file_prefix=prefix)
    say("%s '%s': gain %s%%  ->  %s | %s"
        % (level, name, ser.overall_gain, xlsx.split("/")[-1], html.split("/")[-1]))
    return ScopeResult(level=level, name=name, crew_name=crew_name, months=months,
                       current_month=current_month, issues=issues, mrs=mrs, stats=stats,
                       series=ser, xlsx_path=xlsx, html_path=html, chart_path=chart)


def run_pod(settings: DeliverySettings, pod: Pod, months: List[str], current_month: str,
            progress=None, force_full_refresh: bool = False) -> ScopeResult:
    def say(m):
        log.info(m)
        if progress:
            progress(m)

    s = settings.for_pod(pod)

    already = set()
    if s.load_to_greenplum and not force_full_refresh:
        from delivery_greenplum import loaded_months
        already = loaded_months(s, level="pod", scope_name=pod.name)

    eligible = [m for m in months if m <= current_month]
    to_fetch = [m for m in eligible if m == current_month or m not in already]
    from_db = [m for m in eligible if m not in to_fetch]
    say("Pod '%s': fetching %d month(s) from GitLab, reusing %d from Greenplum."
        % (pod.name, len(to_fetch), len(from_db)))

    client = GitLabClient(s)
    issues, mrs, _states = collect(client, s, to_fetch, progress=progress)
    if from_db:
        from delivery_greenplum import read_detail
        oi, om = read_detail(s, from_db, level="pod", scope_name=pod.name)
        issues, mrs = oi + issues, om + mrs

    res = _report(s, "pod", pod.name, pod.crew, months, current_month, issues, mrs,
                  pod_count=1, include_pod=False, progress=progress)
    res.months_fetched, res.months_from_db = to_fetch, from_db

    if s.load_to_greenplum:
        from delivery_greenplum import load
        res.greenplum = load(s, res.series, res.stats, months, issues, mrs, current_month,
                             progress=progress, fetched_months=to_fetch,
                             level="pod", scope_name=pod.name, crew_name=pod.crew)
    return res


def run_crew(settings: DeliverySettings, crew: Crew, pod_results: List[ScopeResult],
             months: List[str], current_month: str, progress=None) -> ScopeResult:
    """Crew roll-up built from the pod results already collected."""
    issues = [r for p in pod_results for r in p.issues]
    mrs = [r for p in pod_results for r in p.mrs]
    n_pods = len(pod_results)

    import copy
    s = copy.copy(settings)
    s.pod = None
    s.crew_name = crew.name
    # Throughput is per pod, so the crew divides by however many pods reported.
    s.pod_count = max(1, n_pods)

    res = _report(s, "crew", crew.name, crew.name, months, current_month, issues, mrs,
                  pod_count=s.pod_count, include_pod=True, progress=progress)
    res.level = "crew"

    if s.load_to_greenplum:
        from delivery_greenplum import load
        # The crew tables are rebuilt from pod data every run, so the write
        # set is every month present rather than only what GitLab returned.
        fetched = [m for m in months if m <= current_month]
        res.greenplum = load(s, res.series, res.stats, months, issues, mrs, current_month,
                             progress=progress, fetched_months=fetched,
                             level="crew", scope_name=crew.name, crew_name=crew.name)
    return res


def run_all(settings: Optional[DeliverySettings] = None, config_path: Optional[str] = None,
            progress=None, now: Optional[_dt.datetime] = None,
            force_full_refresh: bool = False, pod_workers: int = 3,
            only_crew: Optional[str] = None) -> List[RunResult]:
    def say(m):
        log.info(m)
        if progress:
            progress(m)

    settings = settings or DeliverySettings()
    settings.apply_reporting(load_reporting(config_path))
    crews = load_crews(config_path)
    if only_crew:
        crews = [c for c in crews if c.name == only_crew]
        if not crews:
            raise ValueError("No crew named %r in the config." % only_crew)

    now = now or _dt.datetime.now(_dt.timezone.utc)
    months = month_range(settings.start_month, settings.end_month)
    current_month = min(now.strftime("%Y-%m"), months[-1])
    say("%d month(s) %s to %s | baseline %s | current month %s"
        % (len(months), months[0], months[-1], settings.baseline_month, current_month))

    out: List[RunResult] = []
    for crew in crews:
        say("=" * 70)
        say("Crew '%s' -- %d pod(s): %s"
            % (crew.name, len(crew.pods), ", ".join(p.name for p in crew.pods)))
        rr = RunResult(crew=crew.name)

        def _one(pod):
            try:
                return run_pod(settings, pod, months, current_month, progress,
                               force_full_refresh)
            except Exception as e:
                # one pod failing must not cost the others their reports
                log.exception("Pod '%s' FAILED.", pod.name)
                return ScopeResult(level="pod", name=pod.name, crew_name=crew.name,
                                   error="%s: %s" % (type(e).__name__, e))

        workers = max(1, min(pod_workers, len(crew.pods)))
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futs = {ex.submit(_one, p): p for p in crew.pods}
            for fut in as_completed(futs):
                rr.pods.append(fut.result())
        # keep configuration order rather than completion order
        order = {p.name: i for i, p in enumerate(crew.pods)}
        rr.pods.sort(key=lambda r: order.get(r.name, 99))

        good = [p for p in rr.pods if not p.error]
        for p in rr.failed_pods:
            say("  POD FAILED: %s -- %s" % (p.name, p.error))
        if good:
            rr.crew_result = run_crew(settings, crew, good, months, current_month, progress)
        else:
            say("  No pod succeeded, so no crew roll-up was produced.")
        out.append(rr)

    return out
