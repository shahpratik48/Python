# IKG-ODM Development Assistant

A chat assistant that turns a **GitLab story** into **IKG and/or ODM code**: it reads the story, understands the
requirement, designs the change, writes the files in the exact style of the repositories, checks them against the SQL
standards, reviews them, reports the evidence and a confidence score, and - on your confirmation - creates the branches
`<story id>-<brief title>-ikg` (from `ikg-master`) and `<story id>-<brief title>-odm` (from `odm-master`) and commits the files.

```
story number ─► Story agent ─► Design agent ─► Code agent (one file at a time) ─► Standards checker ─► Review agent
                 (requirement)   (files, tables,   (copies the folder pattern,     (deterministic,       (verdict, findings,
                                  DAG tasks, impact) verifies columns in data/code)  scored 0-100)         confidence)
                                                           ▲                                             │
                                                           └──────────── fixes (max_review_rounds) ◄─────┘
      chat: change requests · questions · show plan / file / diff · download zip · push (branches + commit)
```

## Start

```
pip install -r requirements.txt
jupyter notebook IKG_DevAssist.ipynb      # cells 1-4: config, secrets, connect, open the chat window
python app_web.py                         # same UI from a terminal (http://localhost:8766)
python run_devassist.py --story 1234      # one story from the command line
python run_devassist.py --selftest        # offline mechanics test (fake GitLab + scripted model, no secrets)
python run_devassist.py --check           # connectivity: Azure OpenAI, Greenplum, GitLab, repositories
```

Secrets are asked at runtime (hidden input) or read from `IKG_AZURE_OPENAI_API_KEY`, `IKG_GP_PASSWORD`, `IKG_GITLAB_TOKEN`.
They are never written to config files, code, cache or chat history.

## What the assistant uses

| Source | Used for |
|---|---|
| GitLab issue board (`staat-ds-insights-home`) | story title, description, labels, comments, attachments |
| Repository `ikg-dags` (`dags/ikg` @ `ikg-master`) | SQL folders and scripts (targets, sources, columns, params), DAG tasks, conventions, examples to copy |
| Repository `odm-dags` (`dags/odm` @ `odm-master`) | rule SQL files (`si_*.sql`), rule folders, insight table DDL, task-name files |
| Greenplum `core_ikg` metadata: `ikg_attribute_business_description`, `ikg_graph_relationship`, `ikg_graph_joining_key`, `ikg_metadata_glossary_llm`, `ikg_profile_table_descriptions` | what the profile columns mean, keys, how tables join |
| Greenplum lineage: `ikg_table_lineage_metadata_auto_refresh`, `ikg_column_lineage_master_auto_refresh` | trace a profile column back to its source (profile tables are never read inside IKG scripts) |
| `information_schema` + read-only `SELECT ... LIMIT 50` | real columns/types of source tables, sample values, distinct codes |
| `skills/*.md` | business definitions (household, statement household), glossary, metadata standards |
| `knowledge/odm_knowledge.md` | what ODM is, insight tables, rule conventions, lifecycle |
| `knowledge/ikg_conventions.md` | IKG repository layout, SQL pattern, naming, how to add a column / profile table |
| `ikg-dags/dags/ikg/sql_validator/config/` : `standards_config.yaml`, `sql_rules.yaml`, `severity_mapping.yaml` | the deterministic standards checker (score, grade, build gates) - read from the downloaded repository (start fails with a clear message if they are missing) |
| `standards/ikg_project_rules.yaml` | the assistant's own IKG / ODM project rules (profile-as-source, params, grant, DAG task, history script, ODM file/insert) |

The ODM knowledge file (`knowledge/odm_knowledge.md`) was transcribed from screenshots - replace it with the original.
The three standards files are loaded from the repository folder `dags/ikg/sql_validator/config` (config key
`knowledge.standards_repo_folder`) at every start; there are no local copies (the self-test uses its own fixtures in
`ikgdev/selftest_data/`).

## Rules the assistant enforces (IKG)

- **logic in intermediate tables, profile scripts simple**: every derivation (joins, aggregation, CASE, windows) is
  computed in `<subject>/<table>_ikg.sql` at the profile's grain; the profile script only adds the column and a
  LEFT JOIN on the entity key (rule IKG-PROF-001 flags any logic added to `ikg_create_profiles/*.sql`; the design and
  code agents refuse such plans/files);
- **scripts given in the story** (fenced code in the description or comments) are extracted, analysed and ported into
  the intermediate table file - never silently dropped;

- intermediate tables `..._ikg`, profile tables `<entity>_profile_curr_ikg` (`ikg_create_profiles`), history
  `<entity>_profile_ikg` (`ikg_create_profiles_history`), one SQL file per table, file name = table name;
- schemas only through Airflow params: `{{params.IKG_SCHEMA}}` (never `core_ikg`), `{{params.EDW_INPUT_SCHEMA}}`
  (never `core_wma_shared`), date `{{params.IKG_PROFILE_DATE}}`, owner/reader params;
- a profile table is never a source inside an IKG script - the column is traced to its producing table (lineage);
- `DROP TABLE IF EXISTS` / `CREATE TABLE ... AS` / `DISTRIBUTED BY` / `ALTER ... OWNER TO` / `GRANT SELECT` on every table;
- new SQL files registered as `PostgresOperator` tasks in `ikg_data_refresh.py` (task + task_map; dependencies come from
  `IKG_TASK_DEP_DICT`); Python for DAGs, SQL for everything else, no new R;
- performance notes (filter by profile date early, aggregate before join, distribute on the join key) and impact
  (consumers of changed tables, DAG groups touched) in the plan; validation queries proposed.

ODM: rule files `si_<name>.sql` in the client / prospect / field-leader rule folders, `insight_type` = file name, single
`INSERT INTO {{ params.ODM_TABLE }}` with the 11 insight columns, `run_id = {{ params.ODM_RUN_UUID }}`; a new insight is a new
`insight_type` + file; the profile table, target type, where logic and metric fields are derived from the story.

## Speed: how a story runs now

story (1 call, context pack) → design (1-2 calls) → files in parallel (context pack: examples, original/DAG region, source
facts) → deterministic standards check → **fix passes** (coder in fix mode, 2-3 steps, only the files with findings) →
**one** reviewer round → its findings applied in fix mode → final standards check. No second reviewer round
(`generation.max_review_rounds: 1`; 2 = the reviewer looks again, slower). Every agent step and tool call is in the log.

## Documentation (optional)

`documentation.enabled` (or the switch in the UI / `documentation on`): after every story a one-pager
(`docs/story_<id>_onepager.docx`) and 6 slides (`docs/story_<id>_slides.pptx`) for non-technical readers are written
(what was asked, what was built, how the information flows, an example, quality). `make docs` writes them on demand.

## Confidence and evidence

Every generated file carries the agent's evidence (files, tables, columns it verified), its confidence (rubric: 90+ all
inputs verified and pattern copied; 75-89 one assumption; 60-74 inferred source/expression; <60 unclear requirement) and
"what is required" (what a human must confirm). The overall confidence is
`0.4 × average file confidence + 0.3 × reviewer confidence + 0.3 × standards score` (High ≥ 85, Medium ≥ 70, Low).
Findings on lines that already existed in a modified file are listed but not scored. Standards score =
`100 − Σ(weight × findings)` with weights critical 10 / high 5 / medium 2 / low 1 (from severity_mapping.yaml, sane
range enforced); grades A ≥ 90, B ≥ 80, C ≥ 70, D ≥ 60, else F; score 0 = penalties ≥ 100. The exact formula and
each finding are in the log and the Quality tab, together with "how to raise the confidence".

## Chat commands

`story 1234` · change requests in plain English (`use acc_mhh_n instead of acc_hh_n`, `add a null check`) · `show plan` ·
`show file <name>` · `diff <name>` · `status` · `log` · `review` · `regenerate` · `download zip` · `push` (asks for a
confirmation, then creates the branches and one commit per repository) · any question about the code, tables or lineage.

## Layout

```
IKG_DevAssist.ipynb      notebook (config, secrets, connect, open the chat window)
app_web.py               web UI from a terminal      run_devassist.py   CLI / self-test / check
config/devassist_config.yaml   all settings (LLM, Greenplum, GitLab projects + branches, conventions, generation knobs, storage)
config/entity_model.yaml       entities and keys
ikgdev/                  package: gitlab.py (issues, code download, branches, commits) · repo.py (code index) · catalog.py
                         (metadata/lineage knowledge) · standards.py (checker) · workspace.py (story folder) · session.py
                         (chat logic) · webui.py (HTTP server) · store.py (chat history) · agents/ (base, tools, specialists)
prompts/                 one prompt per agent        knowledge/   ODM knowledge, IKG conventions
standards/               the 3 standards yaml files  skills/      business definition skill files
web/index.html           the chat page               output/      repos, knowledge cache, stories/<id>/ (files, log, zip), chats
```
