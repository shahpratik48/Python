"""
Context packs: everything an agent would otherwise fetch with 5-10 tool calls, collected deterministically in
milliseconds and handed over with the task. Fewer model round-trips = faster and more consistent results.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Dict, List, Optional

TABLE_WORD = re.compile(r"\b([a-z][a-z0-9_]{3,}_ikg|[a-z][a-z0-9_]*_profile_curr_ikg|[a-z][a-z0-9_]*_fact|[a-z][a-z0-9_]*_dimn?)\b")


def _script_brief(repo, path: str, max_chars: int = 7000) -> dict:
    s = repo.scripts.get(path)
    d = {"path": path, "content": repo.read(path, max_chars)}
    if s:
        d.update(targets=s.targets, sources=s.sources, columns=s.columns[:80], distributed_by=s.distributed_by, params=s.params)
        d["dag_tasks"] = [f"{t.group}/{t.task_id}" for t in repo.tasks_for_sql(path)]
    return d


def _mentioned_tables(text: str) -> List[str]:
    seen, out = set(), []
    for m in TABLE_WORD.finditer((text or "").lower()):
        t = m.group(1)
        if t not in seen:
            seen.add(t)
            out.append(t)
    return out[:25]


def for_story(ctx, story: dict) -> dict:
    """Tables mentioned in the story text / scripts: where they are produced and read, their columns."""
    text = " ".join([story.get("title", ""), story.get("description", "")] + [n.get("body", "") for n in story.get("notes", [])]
                    + [b.get("code", "") for b in story.get("code_blocks", [])])
    pack = {"tables_mentioned": [], "profile_tables": [], "note": "pre-collected; call tools only for what is missing here"}
    ikg = ctx.repos.get("ikg")
    for t in _mentioned_tables(text):
        row = {"table": t}
        if ikg is not None:
            row["produced_by"] = ikg.script_for_table(t)[:3]
            row["read_by"] = ikg.scripts_reading(t)[:6]
            if row["produced_by"]:
                s = ikg.scripts.get(row["produced_by"][0])
                if s:
                    row["columns"] = s.columns[:60]
                    row["sources"] = s.sources[:12]
        if ctx.cat is not None and t in ctx.cat.tables:
            tb = ctx.cat.tables[t]
            row["business"] = {"entity": tb.entity, "grain": tb.grain, "keys": tb.primary_key or tb.join_keys,
                               "columns": [{"column": c.name, "description": c.description[:120]} for c in tb.columns[:40]]}
            pack["profile_tables"].append(t)
        pack["tables_mentioned"].append(row)
    if ikg is not None:
        pack["sql_folders"] = sorted(ikg.folders)[:120]
    return pack


def for_design(ctx, req: dict) -> dict:
    """Producing scripts of the requirement's sources, the profile scripts to change, DAG groups of the subject folders."""
    pack = {"sources": [], "profile_scripts": [], "dag_groups": {}, "folder_examples": {}, "note": "pre-collected; call tools only for what is missing here"}
    ikg = ctx.repos.get("ikg")
    if ikg is None:
        return pack
    ikgc = ctx.cfg.get("ikg", {})
    prof_folder = ikgc.get("profile_folder", "ikg_create_profiles")
    hist_folder = ikgc.get("history_folder", "ikg_create_profiles_history")
    sql_root = ikgc.get("sql_root", "dags/ikg/scripts/sql")
    folders = set()
    for src in req.get("sources", [])[:8]:
        t = (src.get("table") or "").split(".")[-1].lower()
        prods = ikg.script_for_table(t)
        row = {"table": t, "produced_by": prods[:2], "read_by": ikg.scripts_reading(t)[:8]}
        if prods:
            row["script"] = _script_brief(ikg, prods[0], 6000)
            folders.add(Path(prods[0]).parent.name)
        pack["sources"].append(row)
    for pc in req.get("profile_changes", [])[:4]:
        pt = (pc.get("profile_table") or "").lower()
        p = f"{sql_root}/{prof_folder}/{pt}.sql"
        if ikg.exists(p):
            pack["profile_scripts"].append(_script_brief(ikg, p, 8000))
            hp = f"{sql_root}/{hist_folder}/{pt.replace(ikgc.get('profile_suffix', '_profile_curr_ikg'), ikgc.get('history_suffix', '_profile_ikg'))}.sql"
            pack["profile_scripts"].append({"path": hp, "exists": ikg.exists(hp), "content": ikg.read(hp, 3000) if ikg.exists(hp) else ""})
            # which intermediate tables does the profile already join?
            s = ikg.scripts.get(p)
            if s:
                for src in s.sources[:10]:
                    folders.update(Path(x).parent.name for x in ikg.script_for_table(src.split(".")[-1])[:1])
        else:
            pack["profile_scripts"].append({"path": p, "exists": False, "note": "new profile table - needs history script too"})
    for f in sorted(folders)[:5]:
        if f in (prof_folder, hist_folder):
            continue
        pack["dag_groups"][f] = [t.task_id for t in ikg.tasks if t.group == f][:40]
        pack["folder_examples"][f] = [ _script_brief(ikg, x, 4000) for x in ikg.folder_examples(f, 1)]
    return pack


def _group_block(lines: List[str], start: int, max_lines: int) -> str:
    """Compact view of one TaskGroup: header, first/last operator lines, task_map head/tail - with line numbers."""
    end = next((j for j in range(start + 1, len(lines)) if "with TaskGroup(" in lines[j] or lines[j].startswith("    start_pipeline")), len(lines))
    block = list(range(start, end))
    if len(block) <= max_lines:
        return "\n".join(f"{i + 1}: {lines[i]}" for i in block)
    tm = next((i for i in block if re.match(r"\s*task_map\s*=\s*\{", lines[i])), None)
    close = next((i for i in block if tm is not None and i > tm and lines[i].strip().startswith("}")), None)
    keep = set(block[:6])
    if tm is not None:
        keep.update(range(max(start, tm - 3), tm + 3))
    if close is not None:
        keep.update(range(max(start, close - 4), min(end, close + 4)))
    keep.update(block[-3:])
    out, last = [], None
    for i in sorted(keep):
        if last is not None and i != last + 1:
            out.append("    ... (lines omitted - read_file(start_line, end_line) for more)")
        out.append(f"{i + 1}: {lines[i]}")
        last = i
    return "\n".join(out)


def dag_regions(ctx, groups: List[str], current_text: Optional[str] = None, max_lines: int = 120) -> dict:
    """The TaskGroup blocks of the DAG file for the given groups (line-numbered, compact) - what the coder must edit.
    current_text = the generated version when the DAG was already modified in this story."""
    ikg = ctx.repos.get("ikg")
    dag_file = ctx.cfg.get("ikg", {}).get("dag_file", "")
    if ikg is None or not dag_file or not ikg.exists(dag_file):
        return {}
    text = current_text if current_text else ikg.read(dag_file, 10 ** 8)
    lines = text.splitlines()
    out = {"file": dag_file, "based_on": "current generated version" if current_text else "repository version",
           "rule": "return `edits` [{find, replace}]: `find` = one or two lines copied EXACTLY from below (without the line numbers), "
                   "occurring once; `replace` = the same lines plus the new operator line / task_map entry. Never return the whole file.",
           "groups": {}}
    for g in groups:
        start = next((i for i, l in enumerate(lines) if re.search(rf"with\s+TaskGroup\(\s*['\"]{re.escape(g)}['\"]", l)), None)
        if start is None:
            ex = next((i for i, l in enumerate(lines) if "with TaskGroup(" in l), 0)
            out["groups"][g] = {"exists": False, "note": "group does not exist - add a new TaskGroup block shaped like this one and add the group "
                                                        "to the start_pipeline list", "example": _group_block(lines, ex, max_lines)}
        else:
            out["groups"][g] = {"exists": True, "lines": _group_block(lines, start, max_lines)}
    sp = next((i for i, l in enumerate(lines) if "start_pipeline >>" in l), None)
    if sp is not None:
        out["start_pipeline_line"] = f"{sp + 1}: {lines[sp][:300]}{' ...' if len(lines[sp]) > 300 else ''}"
    return out


def dag_region(ctx, group: str, max_lines: int = 160) -> dict:     # backwards compatible
    return dag_regions(ctx, [group], None, max_lines)


def groups_touched(ctx, plan: dict) -> List[str]:
    """Task groups = folders of the SQL files in the plan (new files need a task; modified ones usually have it)."""
    out = []
    for f in plan.get("files", []):
        if f.get("repo") == "ikg" and f.get("path", "").endswith(".sql"):
            g = (f.get("details") or {}).get("task_group") or Path(f["path"]).parent.name
            if g not in out:
                out.append(g)
    return out


def for_code(ctx, plan_file: dict, plan: dict, req: dict, current_text: Optional[str] = None) -> dict:
    """Examples of the folder, the original file, source script facts, DAG regions, real columns of EDW sources."""
    repo_key, path = plan_file.get("repo"), plan_file.get("path", "")
    repo = ctx.repos.get(repo_key)
    pack = {"note": "pre-collected; call tools only for what is missing here"}
    if repo is None:
        return pack
    folder = Path(path).parent.name
    details = plan_file.get("details") or {}
    ikgc = ctx.cfg.get("ikg", {})
    # examples of the same folder (not the file itself)
    ex = [p for p in repo.folder_examples(folder, 3) if p != path][:2]
    pack["folder_examples"] = [_script_brief(repo, p, 6000) for p in ex]
    # original
    if plan_file.get("action") == "modify" and repo.exists(path):
        if path.endswith(".py"):
            pack["dag_regions"] = dag_regions(ctx, groups_touched(ctx, plan), current_text)
            pack["new_sql_files_needing_a_task"] = [f["path"] for f in plan.get("files", []) if f.get("repo") == "ikg" and f.get("path", "").endswith(".sql") and f.get("action") == "create"]
        else:
            pack["original"] = _script_brief(repo, path, int(ctx.cfg.generation.get("context_file_chars", 60000)))
    # sources named in the plan details / requirement
    srcs = []
    for s in (details.get("sources") or []) + [x.get("table") for x in req.get("sources", [])]:
        t = (s if isinstance(s, str) else (s or {}).get("table", "")).split(".")[-1].lower()
        if t and t not in srcs:
            srcs.append(t)
    pack["source_scripts"] = []
    pack["source_db_columns"] = []
    for t in srcs[:6]:
        prods = repo.script_for_table(t) if repo_key == "ikg" else []
        if prods:
            pack["source_scripts"].append(_script_brief(repo, prods[0], 5000))
        elif ctx.gp is not None and ctx.cfg.sources.get("allow_data_queries", True):
            cols = _db_columns(ctx, t)
            if cols:
                pack["source_db_columns"].append({"table": t, "columns": cols})
    # profile script the new column goes into (so the history / odm coder sees it)
    if repo_key == "ikg" and folder == ikgc.get("history_folder", "ikg_create_profiles_history"):
        pt = Path(path).stem.replace(ikgc.get("history_suffix", "_profile_ikg"), ikgc.get("profile_suffix", "_profile_curr_ikg"))
        pp = f"{ikgc.get('sql_root')}/{ikgc.get('profile_folder')}/{pt}.sql"
        pack["profile_script"] = {"path": pp, "content": repo.read(pp, 8000)}
    pack["scripts_in_story"] = req.get("scripts_in_story", [])[:3]
    pack["plan_details"] = details
    return pack


def _guess_group(plan: dict) -> str:
    for f in plan.get("files", []):
        if f.get("path", "").endswith(".sql") and "ikg_create_profiles" not in f["path"]:
            return Path(f["path"]).parent.name
    return ""


def _db_columns(ctx, table: str) -> List[dict]:
    try:
        for sch in dict.fromkeys([ctx.cfg.greenplum["schema"], "core_wma_shared"]):
            df = ctx.gp.read("select column_name, data_type from information_schema.columns where table_schema = :s and table_name = :t order by ordinal_position",
                             {"s": sch, "t": table})
            if not df.empty:
                return df.head(200).to_dict("records")
    except Exception:  # noqa: BLE001
        return []
    return []


def for_review(ctx, plan: dict) -> dict:
    """Producing scripts of every table the generated files read, so the reviewer rarely needs tools."""
    pack = {"source_facts": {}}
    ikg = ctx.repos.get("ikg")
    if ikg is None:
        return pack
    for f in plan.get("files", [])[:10]:
        for s in ((f.get("details") or {}).get("sources") or [])[:6]:
            t = (s if isinstance(s, str) else (s or {}).get("table", "")).split(".")[-1].lower()
            prods = ikg.script_for_table(t)
            if prods and t not in pack["source_facts"]:
                sc = ikg.scripts.get(prods[0])
                pack["source_facts"][t] = {"script": prods[0], "columns": sc.columns[:60] if sc else [], "distributed_by": sc.distributed_by if sc else ""}
    return pack
