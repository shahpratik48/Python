"""
Offline self-test: a fake GitLab (local story + local repositories + local "remote" for pushes) and a scripted
stand-in for GPT-5 that drives the real agent loop (tools, grounding, standards checker, review loop, change
requests, zip, push, chat persistence). No network, no secrets:

    python run_devassist.py --selftest [--ikg-repo <path to an ikg-dags checkout>]

Without an ikg-dags checkout a small synthetic one is generated (3 SQL folders + a DAG file).
"""
from __future__ import annotations

import json
import logging
import re
import shutil
import types
from pathlib import Path
from typing import Dict

from .config import Config
from .gitlab import GitLab, extract_code_blocks

log = logging.getLogger(__name__)

STORY_ID = "1234"
STORY = {
    "iid": 1234, "id": 99001234, "title": "Add household 4-week cash distribution count to the household profile",
    "description": ("As an advisor insight owner I want a household level count of cash distribution accounts in the last 4 weeks "
                    "(`mhh_cash_dist_acc_cnt_4w`) on the household profile so that an ODM insight can flag households with 3 or more "
                    "distributing accounts.\n\nAcceptance criteria:\n- new column on the household profile\n- new ODM client insight "
                    "`si_cash_dist_multi_acc` with metric = the count\n- weekly refresh with the IKG pipeline\n\n"
                    "Draft logic from the analyst:\n```sql\nSELECT acc_mhh_n, COUNT(DISTINCT acc_n) AS cnt\nFROM core_ikg.cash_dist_4wk_acc_agg_ikg\n"
                    "WHERE cash_dist_acc_count > 0\nGROUP BY acc_mhh_n;\n```"),
    "labels": ["IKG", "ODM", "enhancement"], "state": "opened", "web_url": "https://devcloud.ubs.net/.../issues/1234",
    "milestone": "Sprint 42", "assignees": ["Data Science"], "created_at": "2026-09-01T09:00:00Z",
    "notes": [{"author": "Product Owner", "created": "2026-09-02T10:00:00Z", "body": "Threshold for the insight: 3 accounts or more."}],
    "attachments": [],
}

NEW_SQL = "dags/ikg/scripts/sql/ikg_cash_distribution/cash_dist_4wk_cnt_mhh_ikg.sql"
PROFILE_SQL = "dags/ikg/scripts/sql/ikg_create_profiles/household_art_profile_curr_ikg.sql"
DAG_FILE = "dags/ikg/dags/ikg_data_refresh.py"
ODM_SQL = "dags/odm/script/sql/ds_client_insights/si_cash_dist_multi_acc.sql"

GOOD_SQL = """DROP TABLE IF EXISTS {{params.IKG_SCHEMA}}.cash_dist_4wk_cnt_mhh_ikg;

CREATE TABLE {{params.IKG_SCHEMA}}.cash_dist_4wk_cnt_mhh_ikg AS
SELECT
    t.acc_mhh_n,
    COUNT(DISTINCT t.acc_n) AS mhh_cash_dist_acc_cnt_4w,
    t.acc_mhh_n AS ikg_key,
    {{params.IKG_PROFILE_DATE}}::text AS profile_date
FROM {{params.IKG_SCHEMA}}.cash_dist_4wk_acc_agg_ikg t
WHERE t.profile_date = '{{params.IKG_PROFILE_DATE}}'
    AND COALESCE(t.cash_dist_acc_count, 0) > 0
GROUP BY t.acc_mhh_n
DISTRIBUTED BY (acc_mhh_n);

ALTER TABLE {{params.IKG_SCHEMA}}.cash_dist_4wk_cnt_mhh_ikg OWNER TO {{params.IKG_TABLE_OWNER_GROUP}};
GRANT SELECT ON {{params.IKG_SCHEMA}}.cash_dist_4wk_cnt_mhh_ikg TO {{params.IKG_TABLE_READER_GROUP}};
"""
# first attempt of the scripted coder: literal schema + missing grant -> the reviewer sends it back
BAD_SQL = GOOD_SQL.replace("FROM {{params.IKG_SCHEMA}}.cash_dist_4wk_acc_agg_ikg", "FROM core_ikg.cash_dist_4wk_acc_agg_ikg") \
                  .split("ALTER TABLE")[0]

ODM_RULE = """INSERT INTO {{ params.ODM_TABLE }}
(insight_type, target_type, target_key, metric_name, metric_type, metric_val, run_id, insight_date_time,
 insight_category, insight_att_name, insight_att_val)
SELECT
    'si_cash_dist_multi_acc' AS insight_type,
    'HOUSEHOLD' AS target_type,
    h.acc_mhh_n AS target_key,
    'mhh_cash_dist_acc_cnt_4w' AS metric_name,
    'COUNT' AS metric_type,
    h.mhh_cash_dist_acc_cnt_4w::text AS metric_val,
    '{{ params.ODM_RUN_UUID }}' AS run_id,
    CURRENT_TIMESTAMP AS insight_date_time,
    'CASH' AS insight_category,
    'threshold' AS insight_att_name,
    '3' AS insight_att_val
FROM {{ params.IKG_SCHEMA }}.household_art_profile_curr_ikg h
WHERE COALESCE(h.mhh_cash_dist_acc_cnt_4w, 0) >= 3;
"""


# =============================================================================
# synthetic repositories
# =============================================================================
def make_fake_ikg_repo(root: Path) -> Path:
    """A tiny ikg-dags checkout with the folders / files the scripted story touches."""
    sql = root / "dags/ikg/scripts/sql"
    (sql / "ikg_cash_distribution").mkdir(parents=True, exist_ok=True)
    (sql / "ikg_create_profiles").mkdir(parents=True, exist_ok=True)
    (sql / "ikg_create_profiles_history").mkdir(parents=True, exist_ok=True)
    (root / "dags/ikg/dags").mkdir(parents=True, exist_ok=True)
    (sql / "ikg_cash_distribution/cash_dist_4wk_acc_agg_ikg.sql").write_text("""DROP TABLE IF EXISTS {{params.IKG_SCHEMA}}.cash_dist_4wk_acc_agg_ikg;

CREATE TABLE {{params.IKG_SCHEMA}}.cash_dist_4wk_acc_agg_ikg AS
SELECT
    m.acc_mhh_n,
    m.acc_n,
    SUM(t.txn_net_a) AS txn_net_a_sum,
    COUNT(DISTINCT t.acc_n) AS cash_dist_acc_count,
    m.acc_n AS ikg_key,
    {{params.IKG_PROFILE_DATE}}::text AS profile_date
FROM {{params.EDW_INPUT_SCHEMA}}.cash_transactions t
    INNER JOIN {{params.IKG_SCHEMA}}.master_ids_curr_ikg m ON m.acc_n = t.acc_n
WHERE t.txn_d > to_date('{{params.IKG_PROFILE_DATE}}', 'yyyymmdd') - 28
GROUP BY m.acc_mhh_n, m.acc_n
DISTRIBUTED BY (acc_n);

ALTER TABLE {{params.IKG_SCHEMA}}.cash_dist_4wk_acc_agg_ikg OWNER TO {{params.IKG_TABLE_OWNER_GROUP}};
GRANT SELECT ON {{params.IKG_SCHEMA}}.cash_dist_4wk_acc_agg_ikg TO {{params.IKG_TABLE_READER_GROUP}};
""")
    (sql / "ikg_cash_distribution/cash_dist_4wk_mhh_agg_ikg.sql").write_text("""DROP TABLE IF EXISTS {{params.IKG_SCHEMA}}.cash_dist_4wk_mhh_agg_ikg;

CREATE TABLE {{params.IKG_SCHEMA}}.cash_dist_4wk_mhh_agg_ikg AS
SELECT
    t.acc_mhh_n,
    SUM(t.txn_net_a_sum) AS mhh_cash_dist_4w,
    t.acc_mhh_n AS ikg_key,
    {{params.IKG_PROFILE_DATE}}::text AS profile_date
FROM {{params.IKG_SCHEMA}}.cash_dist_4wk_acc_agg_ikg t
WHERE t.profile_date = '{{params.IKG_PROFILE_DATE}}'
GROUP BY t.acc_mhh_n
DISTRIBUTED BY (acc_mhh_n);

ALTER TABLE {{params.IKG_SCHEMA}}.cash_dist_4wk_mhh_agg_ikg OWNER TO {{params.IKG_TABLE_OWNER_GROUP}};
GRANT SELECT ON {{params.IKG_SCHEMA}}.cash_dist_4wk_mhh_agg_ikg TO {{params.IKG_TABLE_READER_GROUP}};
""")
    (sql / "ikg_create_profiles/household_art_profile_curr_ikg.sql").write_text("""DROP TABLE IF EXISTS {{params.IKG_SCHEMA}}.household_art_profile_curr_ikg;

CREATE TABLE {{params.IKG_SCHEMA}}.household_art_profile_curr_ikg
AS
SELECT identifier ,
       unique_key ,
       acc_mhh_n ,
       acc_hh_n ,
       shh_title ,
       last_attestation_date,
       due_date ,
       mhh_assets_curr ,
       load_date ,
       {{params.IKG_PROFILE_DATE}}::text as profile_date,
       unique_key as ikg_key
FROM {{params.IKG_SCHEMA}}.art_review_daily_ikg;

ALTER TABLE {{params.IKG_SCHEMA}}.household_art_profile_curr_ikg OWNER TO {{params.IKG_TABLE_OWNER_GROUP}};
GRANT SELECT ON {{params.IKG_SCHEMA}}.household_art_profile_curr_ikg TO {{params.IKG_TABLE_READER_GROUP}};
""")
    (sql / "ikg_create_profiles_history/household_art_profile_ikg.sql").write_text("""INSERT INTO {{params.IKG_SCHEMA}}.household_art_profile_ikg
SELECT * FROM {{params.IKG_SCHEMA}}.household_art_profile_curr_ikg;
""")
    dag = ["from airflow import DAG", "from airflow.utils.task_group import TaskGroup",
           "from airflow.providers.postgres.operators.postgres import PostgresOperator", "",
           "postgres_conn_id = 'ikg_gp'", "props = {}", "all_task_map = {}", "",
           "with DAG('ikg_data_refresh') as dag:"]
    for grp, files in {"ikg_cash_distribution": ["cash_dist_4wk_acc_agg_ikg", "cash_dist_4wk_mhh_agg_ikg"],
                       "ikg_create_profiles": ["household_art_profile_curr_ikg"],
                       "ikg_create_profiles_history": ["household_art_profile_ikg"]}.items():
        dag.append(f"    with TaskGroup('{grp}') as {grp}:")
        for f in files:
            dag.append(f"        {f}=PostgresOperator(task_id='{f}',sql='{grp}/{f}.sql',postgres_conn_id=postgres_conn_id,params=props)")
        dag.append("        task_map={")
        dag += [f"        '{f}':{f}," for f in files[:-1]] + [f"        '{files[-1]}':{files[-1]}", "        }", "        all_task_map.update(task_map)", ""]
    (root / "dags/ikg/dags/ikg_data_refresh.py").write_text("\n".join(dag) + "\n")
    # the 3 standards files live in the repository (sql_validator/config) - copy the local fallbacks there
    cfgdir = root / "dags/ikg/sql_validator/config"
    cfgdir.mkdir(parents=True, exist_ok=True)
    local = Path(__file__).resolve().parent / "selftest_data" / "standards"
    for name in ("standards_config.yaml", "sql_rules.yaml", "severity_mapping.yaml"):
        if (local / name).exists():
            (cfgdir / name).write_text((local / name).read_text(encoding="utf-8"), encoding="utf-8")
    return root


def make_fake_odm_repo(root: Path) -> Path:
    sql = root / "dags/odm/script/sql"
    for f in ("ds_client_insights", "prospect_insights", "field_leader_insights", "odm_process/odm_pre_tasks"):
        (sql / f).mkdir(parents=True, exist_ok=True)
    (root / "dags/odm/dags").mkdir(parents=True, exist_ok=True)
    (sql / "ds_client_insights/si_cash_balance_high.sql").write_text("""INSERT INTO {{ params.ODM_TABLE }}
(insight_type, target_type, target_key, metric_name, metric_type, metric_val, run_id, insight_date_time,
 insight_category, insight_att_name, insight_att_val)
SELECT
    'si_cash_balance_high' AS insight_type,
    'HOUSEHOLD' AS target_type,
    h.acc_mhh_n AS target_key,
    'mhh_cash_a' AS metric_name,
    'AMOUNT' AS metric_type,
    h.mhh_cash_a::text AS metric_val,
    '{{ params.ODM_RUN_UUID }}' AS run_id,
    CURRENT_TIMESTAMP AS insight_date_time,
    'CASH' AS insight_category,
    'threshold' AS insight_att_name,
    '1000000' AS insight_att_val
FROM {{ params.IKG_SCHEMA }}.household_profile_curr_ikg h
WHERE COALESCE(h.mhh_cash_a, 0) >= 1000000;
""")
    (sql / "odm_process/odm_pre_tasks/odm_table_creation.sql").write_text("""CREATE TABLE IF NOT EXISTS {{ params.ODM_TABLE }} (
    insight_type varchar(100), target_type varchar(20), target_key varchar(50), metric_name varchar(100),
    metric_type varchar(20), metric_val text, run_id varchar(40), insight_date_time timestamp,
    insight_category varchar(50), insight_att_name varchar(100), insight_att_val text
) DISTRIBUTED BY (target_key);
""")
    (sql / "odm_client_rules_task_names.txt").write_text("si_cash_balance_high\n")
    (root / "dags/odm/dags/odm_client_insights.py").write_text("""from airflow import DAG
from airflow.providers.postgres.operators.postgres import PostgresOperator

postgres_conn_id = 'odm_gp'
props = {}
with DAG('odm_client_insights') as dag:
    si_cash_balance_high=PostgresOperator(task_id='si_cash_balance_high',sql='ds_client_insights/si_cash_balance_high.sql',postgres_conn_id=postgres_conn_id,params=props)
""")
    return root


# =============================================================================
# fake GitLab
# =============================================================================
class FakeGitLab(GitLab):
    """Stories from a dict, repositories from local folders, pushes into a local 'remote' folder."""

    def __init__(self, cfg: Config, repos: Dict[str, Path], remote: Path):
        super().__init__(cfg)
        self.local = repos
        self.remote = remote
        self.pushes = []

    def test(self):
        return "GitLab (fake)"

    def issue(self, iid, project_path=None):
        if int(iid) != int(STORY_ID):
            raise RuntimeError(f"issue {iid} not found (self-test knows only {STORY_ID})")
        st = dict(STORY)
        st["code_blocks"] = extract_code_blocks(st["description"], "description")
        return st

    def download_repo(self, key, dest, refresh=False):
        return self.local[key]

    def file(self, key, path, ref=None):
        return (self.local[key] / path).read_text(encoding="utf-8")

    def branch_exists(self, key, branch):
        return (self.remote / key / branch).exists()

    def create_branch(self, key, branch):
        (self.remote / key / branch).mkdir(parents=True, exist_ok=True)
        return {"name": branch}

    def existing_paths(self, key, paths, ref):
        return {p: (self.remote / key / ref / p).exists() or (self.local[key] / p).exists() for p in paths}

    def commit(self, key, branch, message, files):
        for p, c in files.items():
            dst = self.remote / key / branch / p
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_text(c, encoding="utf-8")
        self.pushes.append({"repo": key, "branch": branch, "message": message, "files": list(files)})
        return {"id": "abc123def456", "web_url": f"fake://{key}/{branch}", "branch_url": f"fake://{key}/-/tree/{branch}"}


# =============================================================================
# scripted model
# =============================================================================
class _Msg:
    def __init__(self, content=None, tool_calls=None):
        self.content, self.tool_calls = content, tool_calls or []


class _Call:
    def __init__(self, i, name, args):
        self.id = f"call_{i}"
        self.function = types.SimpleNamespace(name=name, arguments=json.dumps(args))


class ScriptedLLM:
    """Drives every agent deterministically through the real loop (tool calls first, then submit_result)."""

    def __init__(self, cfg, cache_dir=None):
        self.c = cfg.llm
        self.usage = {"calls": 0, "cache_hits": 0, "prompt_tokens": 0, "completion_tokens": 0, "cached_tokens": 0}
        self.n = 0
        self.tool_calls_made = []

    def check(self):
        return "OK (scripted self-test model)"

    def json_call(self, system, user, prefix=None, cache_key=None, use_cache=True):
        self.usage["calls"] += 1
        return {"title": "Spotting households that take cash out of several accounts", "problem": "Advisors want to know which households took cash distributions from three or more accounts in the last four weeks.",
                "solution": "A new weekly number on the household profile counts the accounts with a cash distribution; an insight is raised when it reaches three.",
                "how_it_flows": ["Collect last 4 weeks of cash transactions", "Count distributing accounts per household", "Add the count to the household profile", "Keep a weekly copy", "Raise the insight at 3 or more"],
                "example": "The Miller household moved cash out of 3 of their 5 accounts in September; the profile now shows 3 and the advisor gets an insight.",
                "benefits": ["Advisors see liquidity needs early", "One number, refreshed weekly", "Same rule for every household"],
                "glossary": [{"term": "profile", "meaning": "the weekly list of what we know about each household"}]}

    def cache_get(self, key):
        return None

    def cache_put(self, key, value):
        pass

    def _submit(self, args):
        self.n += 1
        return _Msg(tool_calls=[_Call(self.n, "submit_result", args)])

    def _tools(self, calls):
        self.n += 1
        self.tool_calls_made += [c[0] for c in calls]
        return _Msg(tool_calls=[_Call(f"{self.n}_{i}", name, args) for i, (name, args) in enumerate(calls)])

    def chat(self, messages, tools=None, tool_choice="auto", reasoning_effort=None):
        self.usage["calls"] += 1
        import os, time as _t
        _t.sleep(float(os.environ.get("IKG_SELFTEST_DELAY", "0") or 0))     # slow motion for UI demos
        task = next(m["content"] for m in messages if m["role"] == "user" and m["content"].startswith("TASK:"))
        t = json.loads(task[5:])
        n_tool_msgs = sum(1 for m in messages if m["role"] == "tool")
        rejected = any(m["role"] == "tool" and str(m.get("content", "")).startswith("REJECTED") for m in messages)
        if "story" in t and "repos_loaded" in t:
            return self._story(t, n_tool_msgs)
        if "requirement" in t and "story_title" in t:
            return self._design(t, n_tool_msgs)
        if "file" in t and "plan_summary" in t:
            return self._code(t, n_tool_msgs, rejected, messages)
        if "generated_files" in t:
            return self._review(t, n_tool_msgs)
        if "request" in t:
            return self._change(t, n_tool_msgs, messages)
        if "question" in t:
            return self._qa(t, n_tool_msgs)
        return self._submit({})

    # ---- story
    def _story(self, t, n):
        if n == 0:
            return self._tools([("search_code", {"repo": "ikg", "pattern": "cash_dist_4wk", "glob": "**/*.sql"}),
                                ("skill_search", {"query": "household"})])
        answered = bool(t.get("answers_from_user"))
        return self._submit({
            "summary": "Add a household-level count of accounts with a cash distribution in the last 4 weeks to the household profile and raise an ODM client insight when the count is >= 3.",
            "scope": "both", "story_type": "new column + new insight", "entities": ["household", "account"],
            "sources": [{"table": "cash_dist_4wk_acc_agg_ikg", "columns": ["acc_mhh_n", "acc_n", "cash_dist_acc_count", "profile_date"],
                         "schema_param": "{{params.IKG_SCHEMA}}", "why": "account level 4-week cash distribution aggregate (found by search_code)"}],
            "profile_changes": [{"profile_table": "household_art_profile_curr_ikg", "column": "mhh_cash_dist_acc_cnt_4w", "type": "integer",
                                 "derivation": "COUNT(DISTINCT acc_n) with cash_dist_acc_count > 0 per acc_mhh_n", "grain": "household"}],
            "odm_changes": [{"rule_type": "client", "insight_type": "si_cash_dist_multi_acc", "target_type": "HOUSEHOLD",
                             "where_logic": "mhh_cash_dist_acc_cnt_4w >= 3", "metric_name": "mhh_cash_dist_acc_cnt_4w", "metric_type": "COUNT",
                             "metric_val": "mhh_cash_dist_acc_cnt_4w", "insight_category": "CASH", "insight_att_name": "threshold", "insight_att_val": "3"}],
            "scripts_in_story": [{"where": b["where"], "language": b["language"], "purpose": "household count of distributing accounts", "code": b["code"],
                                  "reuse": "port as the intermediate table cash_dist_4wk_cnt_mhh_ikg (params instead of core_ikg, add ikg_key/profile_date)"}
                                 for b in t["story"].get("code_blocks", [])],
            "acceptance_criteria": ["new column on the household profile", "new ODM insight si_cash_dist_multi_acc", "weekly refresh"],
            "assumptions": ["household key is acc_mhh_n (statement household)"] + (["threshold = " + t["answers_from_user"][-1]] if answered else []),
            "open_questions": [] if answered else [{"question": "Which threshold should the insight use - 3 accounts as in the comment, or configurable?",
                                                     "blocking": True, "suggested_default": "3"}],
            "evidence": [{"source": "story 1234 description", "detail": "column name mhh_cash_dist_acc_cnt_4w and insight name given"},
                         {"source": "ikg_cash_distribution/cash_dist_4wk_acc_agg_ikg.sql", "detail": "account level aggregate exists"}]})

    # ---- design
    def _design(self, t, n):
        if n == 0:
            return self._tools([("sql_script_info", {"repo": "ikg", "path": "dags/ikg/scripts/sql/ikg_cash_distribution/cash_dist_4wk_acc_agg_ikg.sql"}),
                                ("dag_tasks", {"repo": "ikg", "group": "ikg_cash_distribution"}),
                                ("folder_examples", {"repo": "odm", "folder": "ds_client_insights"})])
        return self._submit({
            "summary": "New intermediate table cash_dist_4wk_cnt_mhh_ikg (household grain) from the account aggregate; add the column to the household profile; register the task in the DAG; new ODM client rule si_cash_dist_multi_acc.",
            "repos": ["ikg", "odm"],
            "files": [{"repo": "ikg", "path": NEW_SQL, "action": "create", "kind": "ikg_sql", "purpose": "household count of distributing accounts", "depends_on": [], "details": {}},
                      {"repo": "ikg", "path": PROFILE_SQL, "action": "modify", "kind": "profile_sql", "purpose": "add mhh_cash_dist_acc_cnt_4w", "depends_on": [NEW_SQL], "details": {}},
                      {"repo": "ikg", "path": DAG_FILE, "action": "modify", "kind": "dag", "purpose": "register the new task", "depends_on": [NEW_SQL], "details": {}},
                      {"repo": "odm", "path": ODM_SQL, "action": "create", "kind": "odm_rule", "purpose": "insight when count >= 3", "depends_on": [PROFILE_SQL], "details": {}}],
            "new_tables": [{"name": "cash_dist_4wk_cnt_mhh_ikg", "grain": "household", "key": "acc_mhh_n", "columns": ["acc_mhh_n", "mhh_cash_dist_acc_cnt_4w", "ikg_key", "profile_date"]}],
            "changed_tables": ["household_art_profile_curr_ikg"],
            "impact": {"consumers_of_changed_tables": ["ikg_create_profiles_history/household_art_profile_ikg.sql"], "dag_groups_touched": ["ikg_cash_distribution"],
                       "performance_notes": ["aggregate at account level is already filtered by profile_date; count is cheap"]},
            "validation": [{"name": "row count", "sql": "SELECT COUNT(*) FROM {{params.IKG_SCHEMA}}.cash_dist_4wk_cnt_mhh_ikg"},
                           {"name": "key unique", "sql": "SELECT acc_mhh_n, COUNT(*) FROM {{params.IKG_SCHEMA}}.cash_dist_4wk_cnt_mhh_ikg GROUP BY 1 HAVING COUNT(*) > 1"}],
            "airflow": {"variables": ["IKG_SCHEMA", "IKG_PROFILE_DATE"], "connections": []},
            "assumptions": [], "open_questions": [],
            "evidence": [{"source": "dag_tasks ikg_cash_distribution", "detail": "group exists with 2 tasks"}]})

    # ---- code
    def _code(self, t, n, rejected, messages):
        f = t["file"]
        if n == 0:
            calls = [("check_standards", {"repo": f["repo"], "path": f["path"], "content": "SELECT 1;"})]
            if f["action"] == "modify":
                calls.append(("read_file", {"repo": f["repo"], "path": f["path"]}))
            return self._tools(calls)
        base = {"repo": f["repo"], "path": f["path"], "explanation": "", "evidence": [{"source": f["path"], "detail": "pattern of the folder"}],
                "confidence": 90, "what_is_required": "", "standards_findings_left": [], "edits": [], "content": ""}
        fixing = bool(t.get("review_findings_to_fix")) or rejected
        if f["path"] == NEW_SQL:
            base.update(content=GOOD_SQL if fixing else BAD_SQL, explanation="Household count of accounts with a cash distribution in the last 4 weeks.",
                        confidence=92 if fixing else 70)
        elif f["path"] == PROFILE_SQL:
            orig = t.get("original_content", "")
            new = orig.replace("       mhh_assets_curr ,\n", "       mhh_assets_curr ,\n       c.mhh_cash_dist_acc_cnt_4w ,\n") \
                      .replace("FROM {{params.IKG_SCHEMA}}.art_review_daily_ikg;",
                               "FROM {{params.IKG_SCHEMA}}.art_review_daily_ikg a\n    LEFT JOIN {{params.IKG_SCHEMA}}.cash_dist_4wk_cnt_mhh_ikg c ON c.acc_mhh_n = a.acc_mhh_n;")
            base.update(content=new, explanation="Adds mhh_cash_dist_acc_cnt_4w via LEFT JOIN on acc_mhh_n.", confidence=85,
                        what_is_required="confirm the household key of art_review_daily_ikg is acc_mhh_n")
        elif f["path"] == DAG_FILE:
            anchor = "cash_dist_4wk_mhh_agg_ikg=PostgresOperator(task_id='cash_dist_4wk_mhh_agg_ikg',sql='ikg_cash_distribution/cash_dist_4wk_mhh_agg_ikg.sql',postgres_conn_id=postgres_conn_id,params=props)"
            base.update(edits=[{"find": anchor, "replace": anchor + "\n        cash_dist_4wk_cnt_mhh_ikg=PostgresOperator(task_id='cash_dist_4wk_cnt_mhh_ikg',sql='ikg_cash_distribution/cash_dist_4wk_cnt_mhh_ikg.sql',postgres_conn_id=postgres_conn_id,params=props)"},
                               {"find": "'cash_dist_4wk_mhh_agg_ikg':cash_dist_4wk_mhh_agg_ikg", "replace": "'cash_dist_4wk_mhh_agg_ikg':cash_dist_4wk_mhh_agg_ikg,\n        'cash_dist_4wk_cnt_mhh_ikg':cash_dist_4wk_cnt_mhh_ikg"}],
                        explanation="Registers the new task in the ikg_cash_distribution TaskGroup (operator + task_map).", confidence=95)
        elif f["path"] == ODM_SQL:
            base.update(content=ODM_RULE, explanation="ODM client insight: households with >= 3 distributing accounts.", confidence=88)
        else:
            base.update(content="-- generated\nSELECT 1;\n", confidence=50)
        return self._submit(base)

    # ---- review
    def _review(self, t, n):
        if n == 0:
            return self._tools([("workspace_files", {})])
        findings = []
        for repo, rep in (t.get("standards") or {}).items():
            for f in rep.get("findings", []):
                if f.get("severity") in ("critical", "high"):
                    findings.append({"file": f"{repo}/{f['file']}", "severity": f["severity"], "issue": f["message"], "fix": "follow the folder pattern (params schema, owner/grant)"})
        return self._submit({"verdict": "revise" if findings else "approve", "findings": findings, "confidence": 70 if findings else 90,
                             "what_is_required": "" if not findings else "re-check after fixes",
                             "suggestions": ["add the new column to the EDW data dictionary skill file so future stories can find it"]})

    # ---- change
    def _change(self, t, n, messages):
        q = t["request"].lower()
        if n == 0:
            return self._tools([("workspace_files", {}), ("read_file", {"repo": "ikg", "path": NEW_SQL})])
        if q.startswith(("why", "what")):
            return self._submit({"kind": "answer", "files": [], "answer": "The count uses COUNT(DISTINCT acc_n) so an account with several transactions is counted once.",
                                 "confidence": 90, "evidence": []})
        if "cnt_4w" in q and "cnt_4wk" in q:      # rename request
            cur = GOOD_SQL
            for m in messages:
                if m["role"] == "tool":
                    try:
                        j = json.loads(m["content"])
                    except (ValueError, TypeError):
                        continue
                    if isinstance(j, dict) and j.get("path") == NEW_SQL and j.get("content"):
                        cur = j["content"]
            return self._submit({"kind": "change", "answer": "Renamed the column to mhh_cash_dist_acc_cnt_4wk in the intermediate table.",
                                 "files": [{"repo": "ikg", "path": NEW_SQL, "action": "modify", "content": cur.replace("mhh_cash_dist_acc_cnt_4w", "mhh_cash_dist_acc_cnt_4wk"),
                                            "explanation": "column renamed"}],
                                 "confidence": 85, "evidence": [{"source": NEW_SQL, "detail": "column renamed"}]})
        return self._submit({"kind": "clarify", "files": [], "answer": "Which file should change?", "confidence": 50, "evidence": []})

    # ---- qa
    def _qa(self, t, n):
        if n == 0:
            return self._tools([("table_scripts", {"repo": "ikg", "table": "cash_dist_4wk_acc_agg_ikg"})])
        if "distinct" in t["question"].lower():
            return self._submit({"answer": "The count uses COUNT(DISTINCT acc_n) so an account with several transactions is counted once.",
                                 "references": [NEW_SQL]})
        return self._submit({"answer": "cash_dist_4wk_acc_agg_ikg is produced by ikg_cash_distribution/cash_dist_4wk_acc_agg_ikg.sql and read by cash_dist_4wk_mhh_agg_ikg.sql.",
                             "references": ["dags/ikg/scripts/sql/ikg_cash_distribution/cash_dist_4wk_acc_agg_ikg.sql"]})


# =============================================================================
# the test
# =============================================================================
def run(cfg: Config, ikg_repo: str = "") -> bool:
    import ikgdev
    from .store import ChatStore
    out = cfg.path(cfg.output["folder"]) / "selftest"
    shutil.rmtree(out, ignore_errors=True)
    out.mkdir(parents=True)
    cfg["storage"]["backend"] = "file"
    cfg["storage"]["folder"] = str(out / "chats")
    cfg["output"]["stories_folder"] = str(out / "stories")
    cfg["sources"]["knowledge_cache"] = str(out / "knowledge.json")
    ikg_root = Path(ikg_repo) if ikg_repo else make_fake_ikg_repo(out / "repos" / "ikg")
    if ikg_repo and not (ikg_root / cfg.knowledge["standards_repo_folder"] / "standards_config.yaml").exists():
        cfg["knowledge"]["standards_folder_override"] = str(Path(__file__).resolve().parent / "selftest_data" / "standards")
        print(f"  (note: {ikg_repo} has no {cfg.knowledge['standards_repo_folder']} - using the self-test standards fixtures)")
    odm_root = make_fake_odm_repo(out / "repos" / "odm")
    gl = FakeGitLab(cfg, {"ikg": ikg_root, "odm": odm_root}, out / "remote")
    llm = ScriptedLLM(cfg)
    ctx = ikgdev.prepare(cfg, llm=llm, gitlab=gl, need_db=False)
    results = []

    def check(name, ok, detail=""):
        results.append((name, bool(ok), detail))
        print(f"  [{'OK' if ok else 'FAIL'}] {name}" + (f"  - {detail}" if detail and not ok else ""))

    print("self-test: story -> code pipeline")
    s = ikgdev.new_session(ctx)
    a = s.ask("story 1234")
    check("story read + clarifying question asked", a.kind == "clarify" and "threshold" in a.text.lower(), a.text[:200])
    a = s.ask("use 3 accounts")
    check("generation finished", a.kind == "story", f"{a.kind}: {a.text[:200]}")
    files = {f"{f['repo']}/{f['path']}" for f in a.files}
    check("4 files generated (ikg sql, profile, dag, odm rule)", files == {f"ikg/{NEW_SQL}", f"ikg/{PROFILE_SQL}", f"ikg/{DAG_FILE}", f"odm/{ODM_SQL}"}, str(files))
    new_sql = s.ws.get("ikg", NEW_SQL) or ""
    check("review loop fixed the literal schema", "core_ikg." not in new_sql and "GRANT SELECT" in new_sql)
    dag = s.ws.get("ikg", DAG_FILE) or ""
    orig_dag = ctx.repo("ikg").read(DAG_FILE, 10 ** 8)
    check("DAG edited by find/replace (task + task_map)", "task_id='cash_dist_4wk_cnt_mhh_ikg'" in dag and "'cash_dist_4wk_cnt_mhh_ikg':cash_dist_4wk_cnt_mhh_ikg" in dag
          and len(dag) > len(orig_dag) and len(dag) - len(orig_dag) < 400)
    prof = s.ws.get("ikg", PROFILE_SQL) or ""
    check("profile script extended with the column + join", "mhh_cash_dist_acc_cnt_4w" in prof and "LEFT JOIN" in prof)
    std = (s.ws.load("review") or {}).get("standards", {})
    check("standards score >= 80 for both repos", all(v["score"] >= 80 for v in std.values()), str({k: v["score"] for k, v in std.items()}))
    check("confidence + band + evidence reported", a.confidence is not None and a.confidence_band and len(a.evidence) >= 3)
    check("what_is_required carries the human checks", any("household key" in x for x in a.what_is_required))
    want = [gl.branch_name("1234", STORY["title"], "ikg", 80), gl.branch_name("1234", STORY["title"], "odm", 80)]
    check("branch names <story>-<title>-ikg / -odm", [b["branch"] for b in a.branches] == want and all(len(b) <= 80 for b in want), str(want))
    check("agents used tools", {"search_code", "sql_script_info", "check_standards", "read_file", "workspace_files"} <= set(llm.tool_calls_made), str(set(llm.tool_calls_made)))

    req = s.ws.load("requirement")
    check("script given in the story extracted and kept in the requirement", len(story_cb := (s.ws.load("story") or {}).get("code_blocks", [])) == 1
          and "GROUP BY" in story_cb[0]["code"] and req.get("scripts_in_story") and "port" in req["scripts_in_story"][0]["reuse"], str(req.get("scripts_in_story"))[:200])

    print("self-test: follow-ups")
    a = s.ask("show plan")
    check("show plan", a.kind == "status" and NEW_SQL in a.text)
    a = s.ask("diff household_art_profile_curr_ikg.sql")
    check("diff of a modified file", "+" in a.text and "LEFT JOIN" in a.text)
    a = s.ask("why is it a distinct count?")
    check("question answered (not treated as a change)", a.kind == "answer" and "DISTINCT" in a.text)
    a = s.ask("rename the column mhh_cash_dist_acc_cnt_4w to mhh_cash_dist_acc_cnt_4wk")
    check("change request applied", a.kind == "change" and "cnt_4wk" in (s.ws.get("ikg", NEW_SQL) or ""), a.text[:200])
    a = s.ask("what tables feed cash_dist_4wk_acc_agg_ikg?")
    check("Q&A with references", a.kind == "answer" and a.evidence)
    a = s.ask("download zip")
    import zipfile
    names = zipfile.ZipFile(a.file).namelist() if a.file and Path(a.file).exists() else []
    check("zip with repository structure", a.kind == "zip" and f"ikg/{NEW_SQL}" in names and f"odm/{ODM_SQL}" in names and "_story/plan.json" in names, str(names)[:300])
    a = s.ask("push")
    check("push asks for confirmation", a.kind == "push" and s.pending and s.pending["kind"] == "push", a.text[:200])
    a = s.ask("yes")
    check("push creates branches and commits", a.kind == "push" and len(gl.pushes) == 2 and all(p["branch"].startswith("1234-") for p in gl.pushes)
          and (out / "remote/ikg" / gl.pushes[0]["branch"] / NEW_SQL).exists(), a.text[:300])
    check("branch suffixes ikg / odm", {p["branch"].rsplit("-", 1)[-1] for p in gl.pushes} == {"ikg", "odm"})

    a = s.ask("documentation on")
    check("documentation switch", a.kind == "chat" and s.documentation)
    a = s.ask("make docs")
    check("one-pager docx + slides pptx written", a.kind == "docs" and a.docs and Path(a.docs.get("docx", "")).exists() and Path(a.docs.get("pptx", "")).exists(), str(a.docs))
    if a.docs and a.docs.get("docx"):
        from docx import Document
        from pptx import Presentation
        d = Document(a.docs["docx"]); pr = Presentation(a.docs["pptx"])
        check("docx has the sections, pptx has 6 slides", any("What was built" in p.text for p in d.paragraphs) and len(pr.slides) == 6)

    print("self-test: chat persistence")
    store = ChatStore(cfg, None)
    chats = store.list_chats()
    check("chat saved with title", any(c["chat_id"] == s.chat_id and c["title"].startswith("Story 1234") for c in chats), str(chats)[:200])
    s2 = ikgdev.new_session(ctx, chat_id=s.chat_id)
    check("chat restored with story context", s2.story_id == "1234" and len(s2.history) >= 8 and s2.ws is not None)
    a = s2.ask("status")
    check("restored chat answers status", a.kind == "status" and "4 files" in a.text, a.text[:200])
    s3 = ikgdev.new_session(ctx)
    a = s3.ask("help")
    check("new chat (no story) help", a.kind == "chat" and "story" in a.text.lower())

    print("self-test: standards checker")
    src = ctx.checker.sources
    check("standards files loaded from the repository folder (sql_validator/config) or local fallback",
          all(k in src for k in ("standards_config.yaml", "sql_rules.yaml", "severity_mapping.yaml", "ikg_project_rules.yaml"))
          and (ikg_repo or "sql_validator" in src["standards_config.yaml"]) and "/standards/standards_config" not in src["standards_config.yaml"].replace("selftest_data/standards", "x"), str(src))
    rep = ctx.checker.check_files({NEW_SQL: BAD_SQL}, "ikg", {"existing_tasks": set(), "existing_files": set(), "dag_text": ""})
    check("checker flags literal schema / missing grant / missing DAG task", rep.score < 80 and {f.rule_id for f in rep.findings} >= {"IKG-PARAM-001", "IKG-DAG-001"},
          str([f.rule_id for f in rep.findings]))
    rep = ctx.checker.check_files({ODM_SQL: ODM_RULE}, "odm", {})
    check("ODM rule passes", rep.score >= 90, str([f.rule_id for f in rep.findings]))
    orig_prof = ctx.repo("ikg").read(PROFILE_SQL, 10 ** 8)
    complex_prof = orig_prof.replace("       mhh_assets_curr ,\n", "       mhh_assets_curr ,\n       CASE WHEN c.cnt >= 3 THEN 1 ELSE 0 END AS has_multi ,\n")
    rep = ctx.checker.check_files({PROFILE_SQL: complex_prof}, "ikg", {"existing_files": set(ctx.repo("ikg").files), "existing_tasks": set(),
                                                                       "original_files": {PROFILE_SQL: orig_prof}})
    check("logic added to a profile script is flagged (IKG-PROF-001)", any(f.rule_id == "IKG-PROF-001" for f in rep.findings), str([f.rule_id for f in rep.findings]))
    from .agents.specialists import complex_profile_lines
    check("simple LEFT JOIN pick-up is not flagged", not complex_profile_lines(s.ws.get("ikg", PROFILE_SQL) or "", orig_prof))

    print("self-test: web API")
    from . import webui
    from http.client import HTTPConnection
    webui.serve(ctx, host="127.0.0.1", port=18766, background=True)
    import time
    time.sleep(0.5)
    con = HTTPConnection("127.0.0.1", 18766, timeout=30)
    con.request("GET", "/api/status"); st = json.loads(con.getresponse().read())
    check("api/status", st.get("ready") and "ikg" in st.get("repos", {}))
    con.request("GET", f"/api/story?chat_id={s.chat_id}"); sj = json.loads(con.getresponse().read())
    check("api/story (files, log, plan, standards)", sj.get("story_id") == "1234" and len(sj["files"]) == 4 and sj["log"] and sj["plan"]["files"] and sj["standards"])
    con.request("GET", f"/api/file?chat_id={s.chat_id}&repo=ikg&path={DAG_FILE}"); fj = json.loads(con.getresponse().read())
    check("api/file with diff", "cash_dist_4wk_cnt_mhh_ikg" in fj.get("content", "") and fj.get("diff", "").count("\n+") >= 2)
    body = json.dumps({"chat_id": s.chat_id, "question": "status"})
    con.request("POST", "/api/ask", body, {"Content-Type": "application/json"}); j = json.loads(con.getresponse().read())
    ans = None
    for _ in range(100):
        time.sleep(0.2)
        con.request("GET", f"/api/result?job={j['job']}"); r = json.loads(con.getresponse().read())
        if r["status"] == "done":
            ans = r["answer"]; break
    check("api/ask + api/result (async job)", ans is not None and ans["kind"] == "status" and ans["story"]["story_id"] == "1234")
    con.request("POST", "/api/zip", json.dumps({"chat_id": s.chat_id}), {"Content-Type": "application/json"}); z = json.loads(con.getresponse().read())
    con.request("GET", f"/api/download?file={z['file']}"); resp = con.getresponse(); data = resp.read()
    check("api/zip + api/download", resp.status == 200 and data[:2] == b"PK")
    con.request("GET", "/"); resp = con.getresponse(); html = resp.read()
    check("index.html served", resp.status == 200 and b"Development Assistant" in html)
    webui.stop()

    ok = all(r[1] for r in results)
    print(f"\nself-test: {sum(r[1] for r in results)}/{len(results)} checks passed - {'ALL GOOD' if ok else 'FAILURES'}")
    return ok
