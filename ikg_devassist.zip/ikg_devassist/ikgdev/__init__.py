"""IKG-ODM Development Assistant - from a GitLab story to standards-checked IKG / ODM code (branches ready to push)."""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from .config import load_config, get_secret, set_secret
from .db import Greenplum
from .llm import LLM

log = logging.getLogger(__name__)
__all__ = ["load_config", "get_secret", "set_secret", "prepare", "chat_store", "new_session", "Greenplum", "LLM"]


def prepare(cfg, llm=None, gp=None, gitlab=None, rebuild: bool = False, refresh_code: bool = False,
            need_db: bool = True):
    """Download + index the repositories, build (or load) the data knowledge, return the shared DevContext.

    cfg      : load_config()
    gp       : Greenplum connection (None -> created; need_db=False -> no database, catalog/lineage tools disabled)
    gitlab   : GitLab client (None -> created; token asked at runtime)
    rebuild  : rebuild the data knowledge cache (after the metadata tables are refreshed)
    refresh_code: re-download the repositories (after the base branches changed)
    """
    from .agents.context import DevContext
    from .catalog import Catalog
    from .gitlab import GitLab
    from .repo import RepoIndex

    out = cfg.path(cfg.output["folder"])
    out.mkdir(parents=True, exist_ok=True)
    llm = llm or LLM(cfg, out / "cache")
    gitlab = gitlab or GitLab(cfg)

    # 1. code repositories
    repos = {}
    for key, r in cfg.gitlab["repos"].items():
        try:
            root = gitlab.download_repo(key, out / "repos", refresh=refresh_code)
            sql_root = (cfg.get(key, {}) or {}).get("sql_root", "")
            repos[key] = RepoIndex(key, root, sql_root).build()
        except Exception as e:  # noqa: BLE001
            log.warning("repository %s not loaded (%s) - stories for it cannot be generated", key, e)
    if not repos:
        raise RuntimeError("no repository could be loaded - check the GitLab token / project paths")

    # 2. data knowledge (metadata, graph, lineage) from Greenplum
    cat = None
    if need_db:
        gp = gp or Greenplum(cfg)
        cache = cfg.path(cfg.sources["knowledge_cache"])
        cat = Catalog(cfg)
        try:
            if cache.exists() and not rebuild:
                cat.load(cache)
                log.info("data knowledge loaded from %s (%d tables) - use rebuild=True after the metadata tables change", cache, len(cat.tables))
            else:
                cat.build(gp)
                cat.save(cache)
                log.info("data knowledge built and saved to %s", cache)
        except Exception as e:  # noqa: BLE001
            log.warning("data knowledge not available (%s) - the agents work from the code only", e)
            cat = None
    return DevContext(cfg, llm, gp, gitlab, repos, cat)


def chat_store(ctx):
    """The shared ChatStore (Greenplum table or files) - created once per context."""
    from .store import ChatStore
    if getattr(ctx, "store", None) is None:
        ctx.store = ChatStore(ctx.cfg, ctx.gp)
        try:
            ctx.store.ensure()
        except Exception as e:  # noqa: BLE001
            log.warning("chat history table not available (%s) - saving chats to files instead", e)
            ctx.store.backend = "file"
    return ctx.store


def new_session(ctx, chat_id: Optional[str] = None, title: str = ""):
    """A new chat (or a reopened one when chat_id is given: its messages and story context are restored)."""
    from .session import DevSession
    s = DevSession(ctx, chat_store(ctx), chat_id, title)
    if chat_id:
        s.restore()
    return s
