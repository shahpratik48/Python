"""
DevSession: one chat. The user types a story number; the session reads the story from GitLab, analyses it,
designs the change, writes every file, checks it against the standards, reviews it and reports confidence +
evidence. Follow-ups change the code, answer questions, download a zip or push the branch to GitLab.

  story  -> StoryAgent  -> requirement (clarifying question when something blocking is missing)
         -> DesignAgent -> plan (files to add / change, tables, DAG tasks, validation queries)
         -> CodeAgent   -> one file at a time, standards-checked
         -> ReviewAgent -> findings -> CodeAgent fixes (max_review_rounds)
         -> report: score, confidence, evidence, what is required, suggestions
"""
from __future__ import annotations

import json
import logging
import re
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

from .agents.specialists import ChangeAgent, CodeAgent, DesignAgent, QAAgent, ReviewAgent, StoryAgent
from .workspace import StoryWorkspace

log = logging.getLogger(__name__)

STORY_RE = re.compile(r"(?i)(?:^|\b)(?:story|issue|ticket|#)\s*#?\s*(\d{1,7})\b|^\s*#?(\d{1,7})\s*$")
CHANGE_WORDS = ("change", "modify", "rename", "add ", "remove", "delete", "instead", "replace", "fix", "update", "use ",
                "make it", "should be", "switch", "drop the", "move", "include", "exclude", "set ")
PUSH_WORDS = ("push", "commit", "check in", "checkin", "create branch", "publish")
ZIP_WORDS = ("zip", "download", "package")


@dataclass
class Answer:
    kind: str                           # story | clarify | change | answer | push | zip | status | error | chat
    text: str = ""
    story_id: str = ""
    title: str = ""
    files: List[dict] = field(default_factory=list)
    score: Optional[int] = None
    grade: str = ""
    confidence: Optional[int] = None
    confidence_band: str = ""
    what_is_required: List[str] = field(default_factory=list)
    suggestions: List[str] = field(default_factory=list)
    evidence: List[dict] = field(default_factory=list)
    options: List[str] = field(default_factory=list)
    log: List[str] = field(default_factory=list)
    file: Optional[str] = None
    branches: List[dict] = field(default_factory=list)
    plan: Optional[dict] = None
    seconds: float = 0.0

    def to_dict(self) -> dict:
        return self.__dict__.copy()

    def render(self) -> str:
        out = [self.text]
        if self.files:
            out.append("")
            for f in self.files:
                out.append(f"  [{f.get('status', '')}] {f['repo']}/{f['path']}  ({f.get('lines', '?')} lines, confidence {f.get('confidence', '?')})")
        if self.score is not None:
            out.append(f"\nStandards score {self.score} (grade {self.grade}) · overall confidence {self.confidence} ({self.confidence_band})")
        if self.what_is_required:
            out.append("Needs a human check: " + "; ".join(self.what_is_required))
        if self.suggestions:
            out.append("To improve generation: " + "; ".join(self.suggestions))
        if self.options:
            out.append("You can: " + "; ".join(f"({i}) {o}" for i, o in enumerate(self.options, 1)))
        if self.file:
            out.append(f"File: {self.file}")
        for b in self.branches:
            out.append(f"Branch {b.get('branch')} ({b.get('repo')}): {b.get('files')} files, {b.get('branch_url', '')}")
        return "\n".join(out)


class DevSession:
    def __init__(self, ctx, store=None, chat_id: Optional[str] = None, title: str = ""):
        self.ctx = ctx
        self.cfg = ctx.cfg
        self.store = store
        self.chat_id = chat_id or (store.new_chat() if store else "local")
        self.title = title
        self.seq = 0
        self.history: List[dict] = []
        self.story_id: Optional[str] = None
        self.ws: Optional[StoryWorkspace] = None
        self.pending: Optional[dict] = None        # {"kind": "clarify"|"push", ...}
        self.stories_root = ctx.cfg.path(ctx.cfg.output["stories_folder"])
        self._log_mark = 0

    # ------------------------------------------------------------------ persistence
    def restore(self) -> List[dict]:
        msgs = self.store.messages(self.chat_id) if self.store else []
        self.seq = max((m["seq"] for m in msgs), default=0)
        self.title = next((m["chat_title"] for m in reversed(msgs) if m.get("chat_title")), self.title)
        q = None
        for m in msgs:
            if m["role"] == "user":
                q = m["text"]
            elif m["role"] == "bot":
                pl = m.get("payload") or {}
                if pl.get("story_id"):
                    self._open_story(pl["story_id"], pl.get("title", ""))
                self.history.append({"question": q or "", "answer": pl.get("text", m["text"])[:600], "kind": pl.get("kind", "")})
                q = None
        return msgs

    def _save(self, role: str, text_: str, payload: Optional[dict] = None) -> None:
        if not self.store:
            return
        try:
            self.seq += 1
            self.store.add(self.chat_id, self.title, self.seq, role, text_, "", payload)
        except Exception as e:  # noqa: BLE001
            log.warning("chat history not saved: %s", e)

    def _open_story(self, story_id: str, title: str = "") -> None:
        self.story_id = str(story_id)
        self.ws = StoryWorkspace(self.stories_root, self.story_id)
        self.ctx.trace.sink = self.ws.log          # agent tool calls appear live in the log panel
        self._log_mark = len(self.ws.read_log(100000))
        if not self.title:
            self.title = f"Story {story_id}: {title}"[:120]

    def _new_log(self) -> List[str]:
        if not self.ws:
            return []
        lines = self.ws.read_log(100000)
        new = lines[self._log_mark:]
        self._log_mark = len(lines)
        return new

    def recent_history(self, n: int = 5) -> list:
        return self.history[-n:]

    # ------------------------------------------------------------------ public
    def ask(self, text: str) -> Answer:
        t0 = time.time()
        q = (text or "").strip()
        if not q:
            return Answer("chat", "Give me a story number (e.g. `story 1234`) and I will read it from GitLab, design and write the IKG / ODM code.")
        if not self.title:
            self.title = q[:120]
        self._save("user", q)
        try:
            ans = self._handle(q)
        except Exception as e:  # noqa: BLE001
            log.exception("session failure")
            if self.ws:
                self.ws.log(f"ERROR {e}")
            ans = Answer("error", f"Sorry - that failed: {str(e).splitlines()[0][:300]}", story_id=self.story_id or "")
        ans.seconds = round(time.time() - t0, 1)
        ans.log = self._new_log()
        ans.story_id = ans.story_id or (self.story_id or "")
        if self.ws:
            ans.files = ans.files or self._file_rows()
        self.history.append({"question": q, "answer": ans.text[:600], "kind": ans.kind})
        self._save("bot", ans.text, ans.to_dict())
        return ans

    # ------------------------------------------------------------------ routing
    def _handle(self, q: str) -> Answer:
        ql = q.lower()
        # pending confirmations
        if self.pending and self.pending["kind"] == "push":
            if re.search(r"\b(yes|y|confirm|ok|go ahead|proceed|push)\b", ql):
                self.pending = None
                return self._push(confirmed=True)
            self.pending = None
            if re.search(r"\b(no|cancel|stop)\b", ql):
                return Answer("chat", "OK - nothing was pushed. The files stay in the workspace; say `push` when ready.")
        if self.pending and self.pending["kind"] == "clarify":
            p = self.pending
            self.pending = None
            if not STORY_RE.search(q) and not any(w in ql for w in PUSH_WORDS + ZIP_WORDS):
                return self._generate(p["story_id"], extra_answers=(p.get("answers", []) + [q]))
        m = STORY_RE.search(q)
        if m and (not self.story_id or any(w in ql for w in ("story", "issue", "generate", "build", "implement", "#")) or ql.strip().isdigit()):
            sid = m.group(1) or m.group(2)
            return self._generate(sid)
        if self.ws is None:
            if any(w in ql for w in ("help", "what can you do")):
                return Answer("chat", self._help())
            return self._qa(q)
        if any(w in ql for w in PUSH_WORDS):
            return self._push(confirmed=not self.cfg.gitlab.get("push_requires_confirmation", True))
        if any(w in ql for w in ZIP_WORDS):
            return self._zip()
        if re.fullmatch(r"\s*(show\s+)?(the\s+)?(plan|design)\s*", ql):
            return self._show_plan()
        if re.fullmatch(r"\s*(show\s+)?(the\s+)?(log|logs)\s*", ql):
            return Answer("status", "Log of this story (also in the side panel):\n" + "\n".join(self.ws.read_log(60)))
        if re.fullmatch(r"\s*(status|summary|files|show files)\s*", ql):
            return self._status()
        mf = re.match(r"(?i)\s*(?:show|open|print|cat|diff)\s+(?:file\s+)?(\S+\.(?:sql|py|txt|yaml|yml|md))\s*$", q)
        if mf:
            return self._show_file(mf.group(1), diff=ql.startswith("diff"))
        if re.fullmatch(r"\s*(re-?review|review( again)?|check standards|validate)\s*", ql):
            return self._review_only()
        if re.fullmatch(r"\s*(regenerate|start over|redo)\s*", ql):
            return self._generate(self.story_id, force=True)
        if any(w in ql for w in CHANGE_WORDS) and not ql.startswith(("what", "why", "how", "which", "where", "explain", "is ", "does ")):
            return self._change(q)
        return self._qa(q)

    def _help(self) -> str:
        return ("I generate IKG / ODM code from a GitLab story.\n"
                "- `story 1234` - read the story, design and write the code (branch names `1234-<title>-ikg` / `-odm`)\n"
                "- change requests in plain English (\"use acc_mhh_n instead of acc_hh_n\", \"add a null check\")\n"
                "- `show plan`, `show file <path>`, `diff <path>`, `status`, `log`, `review`\n"
                "- `download zip`, `push` (creates the branches and commits after your confirmation)\n"
                "- any question about the code, tables, lineage or standards")

    # ------------------------------------------------------------------ generation pipeline
    def _generate(self, story_id: str, extra_answers: Optional[List[str]] = None, force: bool = False) -> Answer:
        self._open_story(story_id)
        ws, ctx = self.ws, self.ctx
        gen = self.cfg.generation
        ws.log(f"=== story {story_id}: generation started ===")
        # 1. story
        story = ws.load("story")
        if story is None or force:
            ws.log("reading the story from GitLab ...")
            story = ctx.gitlab.issue(int(story_id))
            ws.save("story", story)
        self.title = f"Story {story_id}: {story.get('title', '')}"[:120]
        ws.log(f"story: {story.get('title', '')} ({len(story.get('description', ''))} chars, {len(story.get('notes', []))} comments, "
               f"{len(story.get('code_blocks', []))} script(s) in the story)")
        # 2. requirement
        req = ws.load("requirement")
        if req is None or force or extra_answers:
            ws.log("story agent: analysing the requirement ...")
            task = {"story": {k: story.get(k) for k in ("iid", "title", "description", "labels", "notes", "attachments", "code_blocks", "web_url")},
                    "answers_from_user": extra_answers or [], "repos_loaded": list(ctx.repos)}
            req = StoryAgent(ctx, ws).go(task, f"story {story_id}")
            ws.save("requirement", req)
            ws.log(f"requirement: scope={req.get('scope')} type={req.get('story_type')} sources={len(req.get('sources', []))} "
                   f"profile_changes={len(req.get('profile_changes', []))} odm_changes={len(req.get('odm_changes', []))} "
                   f"scripts_in_story={len(req.get('scripts_in_story', []))}")
            for sc in req.get("scripts_in_story", []):
                ws.log(f"  script from {sc.get('where')}: {sc.get('purpose', '')[:80]} -> {sc.get('reuse', '')[:80]}")
        blocking = [oq for oq in req.get("open_questions", []) if oq.get("blocking")]
        if blocking and not extra_answers:
            self.pending = {"kind": "clarify", "story_id": story_id, "answers": []}
            qs = "\n".join(f"- {oq['question']} (suggested: {oq.get('suggested_default') or 'none'})" for oq in blocking)
            ws.log(f"blocked on {len(blocking)} question(s)")
            return Answer("clarify", f"Before I write code for **{story['title']}** I need:\n{qs}\n\nAnswer here (or say `use the defaults`).",
                          story_id=story_id, title=story["title"])
        if blocking and extra_answers:
            req["open_questions"] = [oq for oq in req["open_questions"] if not oq.get("blocking")]
            ws.save("requirement", req)
        # 3. plan
        plan = ws.load("plan")
        if plan is None or force or extra_answers:
            ws.log("design agent: planning files, tables and DAG changes ...")
            plan = DesignAgent(ctx, ws).go({"story_id": story_id, "story_title": story.get("title"), "requirement": req,
                                            "answers_from_user": extra_answers or []}, f"design {story_id}")
            ws.save("plan", plan)
            ws.reset_files()
            ws.log(f"plan: {len(plan.get('files', []))} file(s) in {plan.get('repos')} - " + "; ".join(f"{f['action']} {f['path']}" for f in plan.get("files", [])[:12]))
        # 4. code
        self._write_files(plan, req, story_id)
        # 5. review loop
        review = self._review(plan, req, story_id, rounds=int(gen.get("max_review_rounds", 2)))
        return self._report(story, req, plan, review)

    def _write_files(self, plan: dict, req: dict, story_id: str, only: Optional[List[str]] = None, findings: Optional[dict] = None) -> None:
        """Generate the plan's files - independent files in parallel (waves by depends_on), max generation.parallel_files."""
        import concurrent.futures as cf
        ws, ctx = self.ws, self.ctx
        files = [f for f in plan.get("files", []) if not only or f["path"] in only]
        total = len(files)
        if not files:
            return
        lock = threading.Lock()
        done_paths = set(x["path"] for x in plan.get("files", []) if only and x["path"] not in only)
        counter = [0]

        def one(f):
            repo = f["repo"]
            if repo not in ctx.repos:
                ws.log(f"skip {f['path']}: repository {repo} not loaded")
                return
            original = ctx.repo(repo).read(f["path"], 10 ** 8) if f["action"] == "modify" else None
            current = ws.get(repo, f["path"])
            with lock:
                counter[0] += 1
                n = counter[0]
            ws.log(f"code agent: [{n}/{total}] {f['action']} {repo}/{f['path']} ...")
            mx = int(self.cfg.generation.get("context_file_chars", 60000))
            task = {"story_id": story_id, "requirement_summary": req.get("summary"), "plan_summary": plan.get("summary"),
                    "file": f, "other_files_in_plan": [{"path": x["path"], "kind": x["kind"], "purpose": x["purpose"]} for x in plan.get("files", []) if x is not f],
                    "original_content": (original or "")[:mx] if original else "",
                    "original_total_chars": len(original or ""),
                    "original_note": ("original truncated here - use read_file(start_line, end_line) and submit `edits` instead of full content"
                                      if original and len(original) > mx else ""),
                    "current_generated_content": current or "",
                    "review_findings_to_fix": (findings or {}).get(f["path"], [])}
            t0 = time.time()
            res = CodeAgent(ctx, ws).go(task, f"code {f['path']}")
            with lock:
                ws.put(repo, f["path"], res["content"], original)
                meta = ws.load("files_meta", {}) or {}
                meta[f"{repo}/{f['path']}"] = {"confidence": res.get("confidence"), "explanation": res.get("explanation"),
                                               "evidence": res.get("evidence", []), "what_is_required": res.get("what_is_required", ""),
                                               "standards_findings_left": res.get("standards_findings_left", []), "action": f["action"], "kind": f.get("kind")}
                ws.save("files_meta", meta)
            ws.log(f"written {repo}/{f['path']} ({res['content'].count(chr(10)) + 1} lines, confidence {res.get('confidence')}, {time.time() - t0:.0f}s)")

        workers = max(1, int(self.cfg.generation.get("parallel_files", 3)))
        pending = list(files)
        while pending:
            wave = [f for f in pending if not (set(f.get("depends_on") or []) & {p["path"] for p in pending if p is not f})]
            if not wave:                      # circular / unknown dependencies - just run what is left
                wave = list(pending)
            if len(wave) > 1 and workers > 1:
                ws.log(f"generating {len(wave)} independent file(s) in parallel ...")
                with cf.ThreadPoolExecutor(min(workers, len(wave))) as ex:
                    list(ex.map(one, wave))
            else:
                for f in wave:
                    one(f)
            pending = [f for f in pending if f not in wave]

    def _standards(self) -> dict:
        """Deterministic check of all workspace files, per repository."""
        out = {}
        for repo, fs in self.ws.files().items():
            r = self.ctx.repo(repo)
            dag_text = "\n".join(c for p, c in fs.items() if p.endswith(".py"))
            existing_tasks = {"/".join(Path(t.sql).parts[-2:]) for t in r.tasks if t.sql}
            dag_file = self.cfg.get("ikg", {}).get("dag_file", "")
            ctx = {"existing_tasks": existing_tasks, "existing_files": set(r.files),
                   "original_files": {p: self.ws.original(repo, p) for p in fs if self.ws.original(repo, p) is not None},
                   "dag_text": dag_text or (r.read(dag_file, 10 ** 7) if repo == "ikg" and dag_file else "")}
            out[repo] = self.ctx.checker.check_files(fs, repo, ctx).to_dict()
        return out

    def _review(self, plan: dict, req: dict, story_id: str, rounds: int) -> dict:
        ws, ctx = self.ws, self.ctx
        review = {}
        skip_clean = bool(self.cfg.generation.get("skip_review_when_clean", True))
        for rnd in range(rounds + 1):
            std = self._standards()
            meta = ws.load("files_meta", {}) or {}
            clean = all(v["score"] >= 95 for v in std.values()) and all(int(m.get("confidence") or 0) >= 85 for m in meta.values())
            if skip_clean and clean and rnd > 0:
                ws.log("standards clean after the fix - reviewer round skipped")
                rv = {"verdict": "approve", "findings": [], "confidence": int(sum(int(m.get("confidence") or 0) for m in meta.values()) / max(1, len(meta))),
                      "what_is_required": "", "suggestions": review.get("agent", {}).get("suggestions", [])}
                review = {"round": rnd + 1, "standards": std, "agent": rv, "files_meta": meta}
                ws.save("review", review)
                break
            ws.log("standards: " + "; ".join(f"{k}: score {v['score']} ({v['grade']}) {len(v['findings'])} finding(s)"
                                             + (f" + {len(v['pre_existing'])} pre-existing (not scored)" if v.get('pre_existing') else "") for k, v in std.items()))
            ws.log(f"review agent: round {rnd + 1} ...")
            files = {f"{repo}/{p}": c[:20000] for repo, fs in ws.files().items() for p, c in fs.items()}
            rv = ReviewAgent(ctx, ws).go({"story_id": story_id, "requirement": req, "plan_summary": plan.get("summary"),
                                          "plan_files": plan.get("files"), "generated_files": files, "standards": std}, f"review {story_id}")
            review = {"round": rnd + 1, "standards": std, "agent": rv, "files_meta": ws.load("files_meta", {})}
            ws.save("review", review)
            fixable = [f for f in rv.get("findings", []) if f.get("severity") in ("critical", "high", "medium")]
            ws.log(f"review: {rv.get('verdict')} - {len(rv.get('findings', []))} finding(s), confidence {rv.get('confidence')}")
            if rv.get("verdict") == "approve" or not fixable or rnd == rounds:
                break
            by_file: Dict[str, list] = {}
            for f in fixable:
                p = f["file"].split("/", 1)[-1] if f["file"].split("/", 1)[0] in ctx.repos else f["file"]
                by_file.setdefault(p, []).append(f)
            ws.log(f"fixing {len(by_file)} file(s): {', '.join(by_file)}")
            self._write_files(plan, req, story_id, only=list(by_file), findings=by_file)
        return review

    def _report(self, story: dict, req: dict, plan: dict, review: dict) -> Answer:
        ws = self.ws
        std = review.get("standards", {})
        rv = review.get("agent", {})
        meta = review.get("files_meta", {}) or {}
        scores = [v["score"] for v in std.values()] or [100]
        std_score = min(scores)
        grade = min((v["grade"] for v in std.values()), default="A")
        confs = [int(m.get("confidence") or 0) for m in meta.values()] or [0]
        overall = int(round(0.4 * (sum(confs) / len(confs)) + 0.3 * int(rv.get("confidence") or 0) + 0.3 * std_score))
        band = "High" if overall >= 85 else "Medium" if overall >= 70 else "Low"
        required = [m["what_is_required"] for m in meta.values() if m.get("what_is_required")]
        if rv.get("what_is_required"):
            required.append(rv["what_is_required"])
        oq = [f"{q['question']} (assumed: {q.get('suggested_default') or 'see assumptions'})" for q in req.get("open_questions", [])]
        evidence = []
        for m in meta.values():
            evidence += m.get("evidence", [])
        evidence += req.get("evidence", []) + plan.get("evidence", [])
        summary = {"story": story.get("title"), "scope": req.get("scope"), "files": self._file_rows(), "standards": {k: {"score": v["score"], "grade": v["grade"], "passed": v["passed"]} for k, v in std.items()},
                   "overall_confidence": overall, "band": band, "what_is_required": required + oq, "suggestions": rv.get("suggestions", [])}
        ws.save("summary", summary)
        ws.log(f"=== done: overall confidence {overall} ({band}), standards {std_score} ({grade}) ===")
        branches = [{"repo": r, "branch": self.ctx.gitlab.branch_name(self.story_id, story.get("title", ""), self.cfg.gitlab["repos"][r]["branch_suffix"],
                                                                        int(self.cfg.gitlab.get("branch_name_max_length", 80)))} for r in plan.get("repos", []) if r in self.cfg.gitlab["repos"]]
        txt = (f"**{story.get('title')}** (story {self.story_id})\n\n{plan.get('summary', '')}\n\n"
               f"Generated {len(summary['files'])} file(s) for {', '.join(plan.get('repos', []))}; "
               f"standards score {std_score} ({grade}); overall confidence **{overall} ({band})** - review verdict: {rv.get('verdict')}.")
        if req.get("assumptions"):
            txt += "\n\nAssumptions: " + "; ".join(req["assumptions"][:6])
        if branches:
            txt += "\n\nBranches to be created on push: " + ", ".join(f"`{b['branch']}`" for b in branches)
        return Answer("story", txt, story_id=self.story_id, title=story.get("title", ""), files=summary["files"], score=std_score, grade=grade,
                      confidence=overall, confidence_band=band, what_is_required=summary["what_is_required"][:8],
                      suggestions=summary["suggestions"][:6], evidence=evidence[:30],
                      options=["download the code as a zip", "push the branches to GitLab", "ask for a change (e.g. 'rename column X to Y')",
                               "show the plan / a file / the diff"], branches=branches, plan={"summary": plan.get("summary"), "files": plan.get("files"),
                                                                                                 "validation": plan.get("validation"), "impact": plan.get("impact")})

    def _file_rows(self) -> List[dict]:
        meta = self.ws.load("files_meta", {}) or {}
        rows = self.ws.file_list()
        for r in rows:
            m = meta.get(f"{r['repo']}/{r['path']}", {})
            r["confidence"] = m.get("confidence")
            r["explanation"] = m.get("explanation", "")
            r["kind"] = m.get("kind", "")
        return rows

    # ------------------------------------------------------------------ follow-ups
    def _change(self, q: str) -> Answer:
        ws, ctx = self.ws, self.ctx
        ws.log(f"change agent: {q[:120]}")
        plan, req = ws.load("plan", {}), ws.load("requirement", {})
        res = ChangeAgent(ctx, ws).go({"request": q, "story_id": self.story_id, "requirement_summary": req.get("summary"),
                                       "plan_summary": plan.get("summary"), "workspace_files": ws.file_list(),
                                       "conversation": self.recent_history()}, f"change {self.story_id}")
        if res.get("kind") == "clarify":
            return Answer("clarify", res.get("answer", "Can you clarify?"), story_id=self.story_id)
        if res.get("kind") == "answer":
            return Answer("answer", res.get("answer", ""), story_id=self.story_id)
        meta = ws.load("files_meta", {}) or {}
        changed = []
        for f in res.get("files", []):
            if f["action"] == "delete":
                ws.remove(f["repo"], f["path"])
                meta.pop(f"{f['repo']}/{f['path']}", None)
                changed.append(f"deleted {f['path']}")
                continue
            original = ctx.repo(f["repo"]).read(f["path"], 10 ** 7) if f["repo"] in ctx.repos and ctx.repo(f["repo"]).exists(f["path"]) else None
            ws.put(f["repo"], f["path"], f.get("content", ""), original)
            m = meta.get(f"{f['repo']}/{f['path']}", {})
            m.update({"confidence": res.get("confidence"), "explanation": f.get("explanation", ""), "evidence": res.get("evidence", []),
                      "action": "modify" if original is not None else "create"})
            meta[f"{f['repo']}/{f['path']}"] = m
            changed.append(f"{f['action']} {f['path']}")
            if f["path"] not in [x["path"] for x in plan.get("files", [])]:
                plan.setdefault("files", []).append({"repo": f["repo"], "path": f["path"], "action": m["action"], "kind": "other", "purpose": f.get("explanation", "")})
        ws.save("files_meta", meta)
        ws.save("plan", plan)
        ws.log("changed: " + "; ".join(changed))
        std = self._standards()
        ws.log("standards after change: " + "; ".join(f"{k}: {v['score']} ({v['grade']})" for k, v in std.items()))
        rev = ws.load("review", {}) or {}
        rev["standards"] = std
        ws.save("review", rev)
        score = min((v["score"] for v in std.values()), default=100)
        txt = (res.get("answer") or "Done.") + "\n\nChanged: " + "; ".join(changed) + f"\nStandards score now {score}."
        return Answer("change", txt, story_id=self.story_id, score=score, grade=min((v["grade"] for v in std.values()), default="A"),
                      confidence=res.get("confidence"), evidence=res.get("evidence", [])[:10],
                      options=["download the code as a zip", "push the branches to GitLab", "ask for another change"])

    def _qa(self, q: str) -> Answer:
        res = QAAgent(self.ctx, self.ws).go({"question": q, "story_id": self.story_id or "", "conversation": self.recent_history()}, f"qa {q[:60]}")
        return Answer("answer", res.get("answer", ""), evidence=[{"source": r, "detail": ""} for r in res.get("references", [])][:10])

    def _show_plan(self) -> Answer:
        plan = self.ws.load("plan")
        if not plan:
            return Answer("chat", "No plan yet - give me a story number first.")
        lines = [plan.get("summary", ""), ""]
        for f in plan.get("files", []):
            lines.append(f"- {f['action']} {f['repo']}/{f['path']} - {f.get('purpose', '')}")
        if plan.get("validation"):
            lines += ["", "Validation queries:"] + [f"- {v['name']}: {v['sql']}" for v in plan["validation"][:6]]
        return Answer("status", "\n".join(lines), story_id=self.story_id, plan=plan)

    def _status(self) -> Answer:
        s = self.ws.load("summary")
        if not s:
            return Answer("status", "The story is loaded but no code has been generated yet.", story_id=self.story_id)
        return Answer("status", f"{s['story']}: {len(s['files'])} files, confidence {s['overall_confidence']} ({s['band']}), standards "
                      + ", ".join(f"{k} {v['score']}" for k, v in s["standards"].items()), story_id=self.story_id, files=self._file_rows())

    def _show_file(self, path: str, diff: bool = False) -> Answer:
        for repo, fs in self.ws.files().items():
            for p, c in fs.items():
                if p == path or p.endswith("/" + path) or Path(p).name == Path(path).name:
                    body = self.ws.diff(repo, p) if diff else c
                    return Answer("answer", f"`{repo}/{p}`:\n```\n{body[:12000]}\n```", story_id=self.story_id)
        for repo in self.ctx.repos:
            t = self.ctx.repo(repo).read(path, 12000)
            if t:
                return Answer("answer", f"`{repo}/{path}` (repository version):\n```\n{t}\n```")
        return Answer("chat", f"I have no file matching '{path}'.")

    def _review_only(self) -> Answer:
        plan, req = self.ws.load("plan", {}), self.ws.load("requirement", {})
        review = self._review(plan, req, self.story_id, rounds=0)
        story = self.ws.load("story", {})
        return self._report(story, req, plan, review)

    def _zip(self) -> Answer:
        p = self.ws.zip()
        return Answer("zip", f"Packaged {len(self.ws.file_list())} file(s) (repository folder structure kept) into {p.name}.", story_id=self.story_id, file=str(p))

    def _push(self, confirmed: bool) -> Answer:
        fs = self.ws.files()
        if not fs:
            return Answer("chat", "Nothing to push yet.")
        story = self.ws.load("story", {})
        branches = []
        for repo in fs:
            r = self.cfg.gitlab["repos"].get(repo)
            if r:
                branches.append({"repo": repo, "branch": self.ctx.gitlab.branch_name(self.story_id, story.get("title", ""), r["branch_suffix"],
                                                                                      int(self.cfg.gitlab.get("branch_name_max_length", 80))),
                                 "base": r["base_branch"], "files": len(fs[repo])})
        if not confirmed:
            self.pending = {"kind": "push"}
            txt = "I will create these branches and commit the files - reply **yes** to confirm:\n" + \
                  "\n".join(f"- {b['repo']}: `{b['branch']}` from `{b['base']}` ({b['files']} file(s))" for b in branches)
            return Answer("push", txt, story_id=self.story_id, branches=branches, options=["yes - push", "no - cancel"])
        results = []
        for repo, files in fs.items():
            if repo not in self.cfg.gitlab["repos"]:
                continue
            self.ws.log(f"pushing {len(files)} file(s) to {repo} ...")
            res = self.ctx.gitlab.publish(repo, self.story_id, story.get("title", ""), files)
            self.ws.log(f"pushed: {res}")
            results.append(res)
        self.ws.save("push", results)
        txt = "Pushed:\n" + "\n".join(f"- {r['repo']}: branch `{r['branch']}` ({'created' if r['branch_created'] else 'updated'}), "
                                      f"{r['files']} file(s), commit {r['commit']} {r.get('branch_url', '')}" for r in results)
        return Answer("push", txt, story_id=self.story_id, branches=results)
