"""
Standards checker: deterministic checks of generated SQL / Python against the three standards files
(standards_config.yaml, sql_rules.yaml, severity_mapping.yaml) plus the IKG / ODM project rules.

  findings  -> [{rule_id, name, severity, file, line, message, evidence}]
  score     -> 100 - sum(weights by severity), grade A-F, build gate pass/fail (severity_mapping.yaml)
"""
from __future__ import annotations

import fnmatch
import logging
import re
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Dict, List, Optional

import yaml

log = logging.getLogger(__name__)

KEYWORDS = ["SELECT", "FROM", "WHERE", "JOIN", "LEFT JOIN", "RIGHT JOIN", "INNER JOIN", "OUTER JOIN", "ON", "AND", "OR",
            "GROUP BY", "ORDER BY", "HAVING", "INSERT", "UPDATE", "DELETE", "CREATE", "DROP", "ALTER", "UNION", "CASE",
            "WHEN", "THEN", "ELSE", "END", "AS", "DISTINCT", "IN", "NOT", "NULL", "IS", "LIKE", "BETWEEN", "EXISTS"]


@dataclass
class Finding:
    rule_id: str
    name: str
    severity: str
    file: str
    message: str
    line: int = 0
    evidence: str = ""
    fixable: bool = False
    pre_existing: bool = False      # the flagged line already existed in the repository version (not scored)


@dataclass
class Report:
    findings: List[Finding] = field(default_factory=list)
    pre_existing: List[Finding] = field(default_factory=list)
    score: int = 100
    grade: str = "A"
    passed: bool = True
    counts: Dict[str, int] = field(default_factory=dict)
    gate_failures: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {"score": self.score, "grade": self.grade, "passed": self.passed, "counts": self.counts,
                "gate_failures": self.gate_failures, "findings": [asdict(f) for f in self.findings],
                "pre_existing": [asdict(f) for f in self.pre_existing]}

    def summary(self) -> str:
        c = self.counts
        return (f"quality score {self.score} (grade {self.grade}, {'PASS' if self.passed else 'FAIL'}): "
                f"{c.get('critical', 0)} critical, {c.get('high', 0)} high, {c.get('medium', 0)} medium, {c.get('low', 0)} low")


def _strip(sql: str) -> str:
    sql = re.sub(r"/\*.*?\*/", " ", sql, flags=re.S)
    return re.sub(r"--[^\n]*", " ", sql)


class StandardsChecker:
    def __init__(self, cfg, folder: Path):
        self.cfg = cfg
        self.folder = Path(folder)
        self.standards = self._load("standards_config.yaml")
        self.sql_rules = self._load("sql_rules.yaml")
        self.severity = self._load("severity_mapping.yaml")
        self.rules: Dict[str, dict] = {}
        for section in (self.standards.get("sql_standards") or {}).values():
            for r in section or []:
                self.rules[r["rule_id"]] = r
        for r in self.standards.get("ikg_project_rules") or []:
            self.rules[r["rule_id"]] = r
        for section in (self.sql_rules.get("optimization_rules") or {}).values():
            for r in section or []:
                self.rules[r["rule_id"]] = r
        self.sev_of: Dict[str, str] = {}
        for mapping in ("standards_severity_mapping", "optimization_severity_mapping"):
            for sev, items in (self.severity.get(mapping) or {}).items():
                for it in items or []:
                    self.sev_of[it["rule_id"]] = sev
        for cat in (self.severity.get("additional_rules_severity_mapping") or {}).values():
            for sev, items in (cat or {}).items():
                for it in items or []:
                    self.sev_of[it["rule_id"]] = sev
        cs = self.severity.get("composite_scoring") or {}
        self.weights = cs.get("weights") or {"critical": 10, "high": 5, "medium": 2, "low": 1}
        self.grades = cs.get("quality_grades") or {}
        self.gates = self.severity.get("build_gates") or {}
        self.ikg = cfg.get("ikg", {})
        self.odm = cfg.get("odm", {})

    def _load(self, name: str) -> dict:
        p = self.folder / name
        if not p.exists():
            log.warning("standards file missing: %s", p)
            return {}
        return yaml.safe_load(p.read_text(encoding="utf-8")) or {}

    def severity_for(self, rule_id: str, default: str = "medium") -> str:
        r = self.rules.get(rule_id) or {}
        return self.sev_of.get(rule_id) or r.get("severity") or default

    def enabled(self, rule_id: str, path: str = "") -> bool:
        r = self.rules.get(rule_id)
        if r is not None and not r.get("enabled", True):
            return False
        for ov in (self.standards.get("exclusions") or {}).get("rule_overrides") or []:
            if fnmatch.fnmatch(path, ov.get("path_pattern", "")) and rule_id in (ov.get("disabled_rules") or []):
                return False
        return True

    # ------------------------------------------------------------------ public
    def check_files(self, files: Dict[str, str], repo_key: str, context: Optional[dict] = None) -> Report:
        """files: {relative path: content}. context: {'new_profile_tables': [...], 'dag_text': str, 'profile_tables': set}."""
        rep = Report()
        ctx = context or {}
        for path, content in files.items():
            if any(fnmatch.fnmatch(path, pat) for pat in (self.standards.get("exclusions") or {}).get("exclude_files") or []):
                continue
            if path.endswith(".sql"):
                rep.findings += self.check_sql(path, content, repo_key, ctx)
            elif path.endswith(".py"):
                rep.findings += self.check_python(path, content)
            elif path.endswith((".R", ".r")):
                rep.findings.append(self._f("IKG-LANG-001", path, "new R code is not allowed - use SQL and Python", 1))
        rep.findings += self.check_set(files, repo_key, ctx)
        rep.findings = [f for f in rep.findings if self.enabled(f.rule_id, f.file)]
        # findings on lines that already exist in the repository version of a modified file are reported but not scored
        originals = ctx.get("original_files") or {}
        if originals:
            keep = []
            for f in rep.findings:
                orig = originals.get(f.file)
                if orig is not None and f.line > 0:
                    lines = files[f.file].splitlines()
                    txt = lines[f.line - 1].strip() if 0 < f.line <= len(lines) else ""
                    if txt and txt in orig:
                        f.pre_existing = True
                        rep.pre_existing.append(f)
                        continue
                elif orig is not None and f.rule_id in ("IKG-HIST-001",):
                    f.pre_existing = True
                    rep.pre_existing.append(f)
                    continue
                keep.append(f)
            rep.findings = keep
        self._score(rep)
        return rep

    # ------------------------------------------------------------------ sql checks
    def check_sql(self, path: str, sql: str, repo_key: str, ctx: dict) -> List[Finding]:
        out: List[Finding] = []
        clean = _strip(sql)
        lines = sql.splitlines()
        stem = Path(path).stem.lower()
        is_odm = repo_key == "odm"

        def line_of(pattern: str) -> int:
            for i, l in enumerate(lines, 1):
                if re.search(pattern, l, re.I):
                    return i
            return 0

        # --- IKG-PARAM-001 / STD-VAR-001: literal schemas
        for sch in self.ikg.get("literal_schemas_forbidden", []):
            m = re.search(rf"(?i)\b{re.escape(sch)}\.", clean)
            if m:
                out.append(self._f("IKG-PARAM-001", path, f"literal schema '{sch}.' - use the params variable", line_of(rf"\b{sch}\."), m.group(0)))
        for m in re.finditer(r"(?i)\b(?:from|join|into|table(?:\s+if\s+(?:not\s+)?exists)?)\s+([a-z_][a-z0-9_]*)\.([a-z_][a-z0-9_]*)", clean):
            if m.group(1) not in ("information_schema", "pg_catalog", "pg_class", "pg_namespace", "sqlite_master"):
                out.append(self._f("STD-VAR-001", path, f"hardcoded schema '{m.group(1)}' - use {{{{params.<SCHEMA>}}}}", line_of(rf"\b{m.group(1)}\.{m.group(2)}"), m.group(0)))
                break
        # --- STD-VAR-002: hardcoded dates
        for m in re.finditer(r"(?i)where[^;]*?('\d{4}-\d{2}-\d{2}'|'\d{8}'|to_date\s*\(\s*'\d)", clean):
            out.append(self._f("STD-VAR-002", path, "hardcoded date in WHERE - use {{params.IKG_PROFILE_DATE}}", line_of(re.escape(m.group(1))), m.group(1)))
            break
        # --- targets
        creates = re.findall(r"(?is)\bcreate\s+(?:temp(?:orary)?\s+)?table\s+(?:if\s+not\s+exists\s+)?(?:\{\{[^}]*\}\}\.|[a-z_][a-z0-9_]*\.)?([a-z_][a-z0-9_]*)", clean)
        drops = re.findall(r"(?is)\bdrop\s+table\s+(?:if\s+exists\s+)?(?:\{\{[^}]*\}\}\.|[a-z_][a-z0-9_]*\.)?([a-z_][a-z0-9_]*)", clean)
        inserts = re.findall(r"(?is)\binsert\s+into\s+(?:\{\{[^}]*\}\}\.|[a-z_][a-z0-9_]*\.)?([a-z_][a-z0-9_]*)", clean)
        creates_l = [c.lower() for c in creates]
        perm_creates = [c for c in creates_l if not re.search(rf"(?is)create\s+temp(?:orary)?\s+table\s+(?:if\s+not\s+exists\s+)?(?:\{{\{{[^}}]*\}}\}}\.|[a-z_][a-z0-9_]*\.)?{c}\b", clean)]
        if not is_odm:
            outputs = set(perm_creates) | {i.lower() for i in inserts if i.lower() not in creates_l}
            if len(outputs) > 1:
                out.append(self._f("STD-NAME-001", path, f"file produces {len(outputs)} tables: {', '.join(sorted(outputs))}", 1))
            if perm_creates and stem not in perm_creates and not any(stem.endswith(c) or c.endswith(stem) for c in perm_creates):
                out.append(self._f("STD-NAME-002", path, f"file name '{stem}' does not match created table '{perm_creates[-1]}'", 1))
            for d in drops:
                if creates_l and d.lower() not in creates_l:
                    out.append(self._f("STD-NAME-003", path, f"DROP TABLE '{d}' has no matching CREATE TABLE (created: {', '.join(creates_l)})", line_of(rf"drop\s+table[^;]*{d}"), d))
            if perm_creates:
                alters = re.findall(r"(?is)\balter\s+table\s+(?:\{\{[^}]*\}\}\.|[a-z_][a-z0-9_]*\.)?([a-z_][a-z0-9_]*)\s+owner\s+to", clean)
                grants = re.findall(r"(?is)\bgrant\s+select\s+on\s+(?:table\s+)?(?:\{\{[^}]*\}\}\.|[a-z_][a-z0-9_]*\.)?([a-z_][a-z0-9_]*)", clean)
                if not alters or not grants:
                    out.append(self._f("IKG-GRANT-001", path, "missing ALTER TABLE ... OWNER TO / GRANT SELECT for the created table", 1))
                for a in alters + grants:
                    if a.lower() not in creates_l:
                        out.append(self._f("STD-NAME-004", path, f"ALTER/GRANT references '{a}' which is not the created table", line_of(rf"(alter|grant)[^;]*{a}"), a))
                if "IKG_TABLE_OWNER_GROUP" not in sql or "IKG_TABLE_READER_GROUP" not in sql:
                    if alters or grants:
                        out.append(self._f("IKG-GRANT-001", path, "owner / reader group must be {{params.IKG_TABLE_OWNER_GROUP}} / {{params.IKG_TABLE_READER_GROUP}}", 1))
            # OPT-DIST-001 distributed by
            for c in perm_creates:
                blk = re.search(rf"(?is)create\s+table\s+(?:if\s+not\s+exists\s+)?(?:\{{\{{[^}}]*\}}\}}\.|[a-z_][a-z0-9_]*\.)?{c}\b(.*?);", clean)
                if blk and not re.search(r"(?i)distributed\s+(by|randomly|replicated)", blk.group(1)):
                    out.append(self._f("OPT-DIST-001", path, f"CREATE TABLE {c} has no DISTRIBUTED BY clause", line_of(rf"create\s+table[^;]*{c}"), c))
            # IKG-DATE-001 profile_date
            if perm_creates and "profile_date" not in clean.lower() and not re.search(r"(?i)_(map|ids|dates|lookup|dimn|ref)\b", stem):
                out.append(self._f("IKG-DATE-001", path, "no profile_date column/filter - intermediate tables carry profile_date = {{params.IKG_PROFILE_DATE}}", 1))
            # IKG-SRC-001 profile table as source
            srcs = re.findall(r"(?is)\b(?:from|join)\s+(?:\{\{[^}]*\}\}\.|[a-z_][a-z0-9_]*\.)?([a-z_][a-z0-9_]*)", clean)
            for s_ in srcs:
                if (s_.lower().endswith(self.ikg.get("profile_suffix", "_profile_curr_ikg")) or s_.lower().endswith("_profile_ikg")) and s_.lower() not in creates_l \
                        and Path(path).parent.name not in (self.ikg.get("history_folder", "ikg_create_profiles_history"),):
                    out.append(self._f("IKG-SRC-001", path, f"profile table '{s_}' used as a source - derive from the base/source tables instead", line_of(rf"(from|join)[^;]*{s_}"), s_))
        else:
            # ---- ODM rule file checks
            fn = Path(path).name
            if Path(path).parts[-2] in self.odm.get("rule_folders", {}).values() or fn.startswith(self.odm.get("rule_prefix", "si_")):
                if not stem.startswith(self.odm.get("rule_prefix", "si_")):
                    out.append(self._f("ODM-FILE-001", path, "rule file name must start with si_", 1))
                it = re.findall(r"(?is)'(si_[a-z0-9_]+)'\s*(?:as\s+)?insight_type|'(si_[a-z0-9_]+)'", clean)
                lits = {a or b for a, b in it}
                if lits and stem not in lits:
                    out.append(self._f("ODM-FILE-001", path, f"insight_type literal {sorted(lits)} differs from file name '{stem}'", 1))
                if "ODM_TABLE" not in sql or not re.search(r"(?is)insert\s+into\s+\{\{\s*params\.ODM_TABLE\s*\}\}\s*\(", clean):
                    out.append(self._f("ODM-INS-001", path, "must INSERT INTO {{ params.ODM_TABLE }} (explicit column list)", 1))
                else:
                    cols = re.search(r"(?is)insert\s+into\s+\{\{\s*params\.ODM_TABLE\s*\}\}\s*\(([^)]*)\)", clean)
                    have = {c.strip().lower() for c in cols.group(1).split(",")} if cols else set()
                    missing = [c for c in self.odm.get("insert_columns", []) if c not in have]
                    if missing:
                        out.append(self._f("ODM-INS-001", path, f"insert column list misses: {', '.join(missing)}", 1))
                if "ODM_RUN_UUID" not in sql:
                    out.append(self._f("ODM-INS-001", path, "run_id must come from {{ params.ODM_RUN_UUID }}", 1))
                tt = re.findall(r"(?is)'([A-Z]+)'\s+as\s+target_type", clean)
                for t in tt:
                    if t not in self.odm.get("target_types", []):
                        out.append(self._f("ODM-INS-001", path, f"target_type '{t}' not in {self.odm.get('target_types')}", 1))
        # --- generic query patterns
        if re.search(r"(?is)\bselect\s+\*\s+from", clean) and not re.search(r"(?is)count\s*\(\s*\*\s*\)", clean):
            out.append(self._f("STD-PAT-001", path, "SELECT * - list the columns", line_of(r"select\s+\*")))
        if re.search(r"(?is)\binsert\s+into[^;]*select\s+\*", clean):
            out.append(self._f("STD-PAT-002", path, "INSERT ... SELECT * - list the columns", line_of(r"insert\s+into")))
        if re.search(r"(?is)\bnatural\s+(left\s+|right\s+)?join\b", clean):
            out.append(self._f("STD-PAT-003", path, "NATURAL JOIN is not allowed", line_of(r"natural\s+")))
        m = re.search(r"(?is)\bgroup\s+by\s+\d+(\s*,\s*\d+)*", clean)
        if m:
            out.append(self._f("STD-PAT-004", path, "numeric GROUP BY - name the columns", line_of(r"group\s+by\s+\d"), m.group(0)))
        if re.search(r"(?is)\binsert\s+into\s+[^\s(]+\s+values", clean):
            out.append(self._f("STD-PAT-005", path, "INSERT without column list", line_of(r"insert\s+into")))
        if re.search(r"(?is)\bcross\s+join\b", clean) and "cross join" not in sql.lower().split("--")[0][:0]:
            out.append(self._f("OPT-JOIN-005", path, "CROSS JOIN - confirm it is intended and comment why", line_of(r"cross\s+join")))
        # joins without ON/USING, and join tables without alias
        for m in re.finditer(r"(?is)\b((?:left|right|inner|full)(?:\s+outer)?\s+)?join\s+((?:\{\{[^}]*\}\}\.|[a-z_][a-z0-9_]*\.)?[a-z_][a-z0-9_]*)(\s+(?:as\s+)?([a-z_][a-z0-9_]*))?\s*(on|using|join|left|right|inner|where|group|;|$)", clean):
            if m.group(1) and "cross" in m.group(1).lower():
                continue
            kw = (m.group(5) or "").lower()
            if kw not in ("on", "using") and not (m.group(4) and m.group(4).lower() in ("on", "using")):
                if m.group(4) and m.group(4).lower() not in ("on", "using") and kw in ("where", "group", ";", ""):
                    out.append(self._f("STD-PAT-007", path, f"JOIN {m.group(2)} has no ON/USING condition", line_of(rf"join\s+{re.escape(m.group(2)).replace(chr(92)+'{', '{')}"), m.group(0)[:80]))
            if not m.group(4) or m.group(4).lower() in ("on", "using"):
                out.append(self._f("STD-PAT-008", path, f"JOIN {m.group(2)} has no alias", 0, m.group(0)[:80]))
        # duplicate select columns (first CREATE/INSERT select)
        dup = self._duplicate_columns(clean)
        if dup:
            out.append(self._f("STD-PAT-006", path, f"duplicate output column(s): {', '.join(dup)}", 0))
        # formatting (low)
        for kw in ("select", "from", "where", "group by", "order by", "join", "case", "when", "then", "else", "end"):
            if re.search(rf"(?<![a-z_]){kw}(?![a-z_])", clean) and not re.search(rf"(?<![a-zA-Z_]){kw.upper()}(?![a-zA-Z_])", clean):
                out.append(self._f("STD-FMT-001", path, f"keyword '{kw}' written in lower case", line_of(rf"(?<![a-z_]){kw}(?![a-z_])"), fixable=True))
                break
        if clean.strip() and not clean.strip().endswith(";"):
            out.append(self._f("STD-FMT-005", path, "last statement is not terminated with ';'", len(lines), fixable=True))
        for i, l in enumerate(lines, 1):
            if re.match(r"^\s*,\s*[a-zA-Z_]", l):
                out.append(self._f("STD-FMT-004", path, "leading comma - use trailing commas", i, l.strip()[:60], fixable=True))
                break
        for i, l in enumerate(lines, 1):
            if "\t" in l:
                out.append(self._f("STD-FMT-002", path, "tab indentation - use 4 spaces", i, fixable=True))
                break
        if re.search(r"(?is)\bselect\s+[a-z_][a-z0-9_.]*\s*,\s*[a-z_][a-z0-9_.]*\s*,[^\n;]*\bfrom\b", clean):
            out.append(self._f("STD-FMT-003", path, "several columns on one line - one column per line", line_of(r"select\s+[a-z_][a-z0-9_.]*\s*,")))
        if re.search(r"(?i)(password|secret|api[_-]?key)\s*=\s*['\"][^'\"]+['\"]", sql):
            out.append(self._f("SEC-002", path, "credential-like literal in code", line_of(r"(password|secret|api[_-]?key)\s*=")))
        return out

    @staticmethod
    def _duplicate_columns(clean: str) -> List[str]:
        m = re.search(r"(?is)\bselect\s+(.*?)\s+from\s", clean)
        if not m:
            return []
        body, cols, depth, cur = m.group(1), [], 0, []
        for ch in body:
            depth += ch == "("
            depth -= ch == ")"
            if ch == "," and depth == 0:
                cols.append("".join(cur)); cur = []
            else:
                cur.append(ch)
        cols.append("".join(cur))
        names, dups = [], []
        for c in cols:
            c = c.strip()
            a = re.search(r"(?is)\bas\s+([a-z_][a-z0-9_]*)\s*$", c)
            toks = re.findall(r"[a-z_][a-z0-9_]*", c.lower())
            n = a.group(1).lower() if a else (toks[-1] if toks else "")
            if n and n in names and n not in dups:
                dups.append(n)
            if n:
                names.append(n)
        return dups

    # ------------------------------------------------------------------ python checks
    def check_python(self, path: str, text: str) -> List[Finding]:
        out = []
        try:
            import ast
            ast.parse(text)
        except SyntaxError as e:
            out.append(self._f("PY-SYNTAX-001", path, f"python syntax error: {e.msg}", e.lineno or 0, severity="critical"))
        for sch in self.ikg.get("literal_schemas_forbidden", []):
            if re.search(rf"['\"]{re.escape(sch)}['\"]", text):
                out.append(self._f("IKG-PARAM-001", path, f"literal schema '{sch}' in python - use props / params", 0))
        if re.search(r"(?i)(password|secret|token)\s*=\s*['\"][^'\"]{4,}['\"]", text):
            out.append(self._f("SEC-002", path, "credential-like literal in code", 0))
        return out

    # ------------------------------------------------------------------ set-level checks (across files)
    def check_set(self, files: Dict[str, str], repo_key: str, ctx: dict) -> List[Finding]:
        out = []
        if repo_key != "ikg":
            return out
        sql_root = self.ikg.get("sql_root", "dags/ikg/scripts/sql")
        dag_texts = [c for p, c in files.items() if p.endswith(".py") and "/dags/" in p] + [ctx.get("dag_text") or ""]
        dag_all = "\n".join(dag_texts)
        profile_sfx, hist_sfx = self.ikg.get("profile_suffix", "_profile_curr_ikg"), self.ikg.get("history_suffix", "_profile_ikg")
        hist_folder, prof_folder = self.ikg.get("history_folder"), self.ikg.get("profile_folder")
        for p in files:
            if p.endswith(".sql") and p.startswith(sql_root):
                rel = "/".join(Path(p).parts[-2:])
                if rel not in dag_all and ctx.get("existing_tasks") is not None and rel not in ctx.get("existing_tasks", set()) \
                        and p not in ctx.get("existing_files", set()):
                    out.append(self._f("IKG-DAG-001", p, f"'{rel}' is not referenced by any PostgresOperator task in the DAG", 0))
                stem = Path(p).stem
                if Path(p).parent.name == prof_folder and stem.endswith(profile_sfx):
                    hist = f"{sql_root}/{hist_folder}/{stem[:-len(profile_sfx)]}{hist_sfx}.sql"
                    if hist not in files and hist not in ctx.get("existing_files", set()):
                        out.append(self._f("IKG-HIST-001", p, f"new profile table needs its history script {hist}", 0))
        return out

    # ------------------------------------------------------------------ scoring
    def _f(self, rule_id: str, path: str, message: str, line: int = 0, evidence: str = "", severity: str = "", fixable: bool = False) -> Finding:
        r = self.rules.get(rule_id) or {}
        return Finding(rule_id=rule_id, name=r.get("name", rule_id), severity=severity or self.severity_for(rule_id),
                       file=path, message=message, line=line, evidence=evidence[:160], fixable=fixable or bool(r.get("auto_fixable")))

    def _score(self, rep: Report) -> None:
        counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}
        for f in rep.findings:
            counts[f.severity] = counts.get(f.severity, 0) + 1
        rep.counts = counts
        rep.score = max(0, 100 - sum(int(self.weights.get(s, 1)) * n for s, n in counts.items()))
        rep.grade = "F"
        for g, spec in sorted(self.grades.items(), key=lambda kv: -int(kv[1].get("score_min", 0))):
            if rep.score >= int(spec.get("score_min", 0)):
                rep.grade = g
                break
        gates = self.gates.get("max_allowed_issues") or {}
        rep.gate_failures = [f"{s}: {counts.get(s, 0)} > {lim}" for s, lim in gates.items() if counts.get(s, 0) > int(lim)]
        if rep.score < int(self.gates.get("min_quality_score", 80)):
            rep.gate_failures.append(f"score {rep.score} < {self.gates.get('min_quality_score', 80)}")
        rep.passed = not rep.gate_failures

    # ------------------------------------------------------------------ for prompts
    def rules_digest(self, max_chars: int = 9000) -> str:
        lines = ["## CODING STANDARDS (rule id - severity - rule)"]
        for rid, r in self.rules.items():
            lines.append(f"- {rid} [{self.severity_for(rid)}] {r.get('name', '')}: {str(r.get('description', ''))[:160]}")
        txt = "\n".join(lines)
        return txt[:max_chars]
