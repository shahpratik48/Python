"""
GitLab access (REST API v4, token asked at runtime):
  * issues  - read a story by its number (iid): title, description, labels, comments, attachments
  * repos   - download the code (archive of code_root at the base branch), read single files
  * publish - create the story branch from the base branch and commit all generated/changed files
"""
from __future__ import annotations

import io
import logging
import re
import shutil
import zipfile
from pathlib import Path
from typing import Dict, List, Optional
from urllib.parse import quote

from .config import Config, get_secret, ssl_verify

log = logging.getLogger(__name__)


class GitLab:
    def __init__(self, cfg: Config):
        self.g = cfg.gitlab
        self.base = self.g["url"].rstrip("/") + "/api/v4"
        self.verify = ssl_verify(self.g.get("ssl_verify", True))
        self._s = None

    # ------------------------------------------------------------------ http
    @property
    def s(self):
        if self._s is None:
            import requests
            self._s = requests.Session()
            self._s.headers["PRIVATE-TOKEN"] = get_secret("gitlab_token")
            self._s.verify = self.verify
        return self._s

    def _proj(self, project_path: str) -> str:
        return f"{self.base}/projects/{quote(project_path, safe='')}"

    def get(self, url: str, **params):
        r = self.s.get(url, params=params, timeout=120)
        r.raise_for_status()
        return r.json()

    def test(self) -> str:
        u = self.get(f"{self.base}/user")
        return f"GitLab user {u.get('username')} ({u.get('name')})"

    # ------------------------------------------------------------------ issues
    def issue(self, iid: int, project_path: Optional[str] = None) -> dict:
        """One story (issue) with its comments; markdown attachments listed as links."""
        pp = project_path or self.g["issues_project_path"]
        it = self.get(f"{self._proj(pp)}/issues/{int(iid)}")
        notes = []
        try:
            for n in self.get(f"{self._proj(pp)}/issues/{int(iid)}/notes", per_page=100, sort="asc"):
                if not n.get("system"):
                    notes.append({"author": (n.get("author") or {}).get("name", ""), "created": n.get("created_at", ""),
                                  "body": n.get("body", "")})
        except Exception as e:  # noqa: BLE001
            log.warning("issue notes not readable: %s", e)
        desc = it.get("description") or ""
        attachments = re.findall(r"\[([^\]]*)\]\((/uploads/[^)]+)\)", desc)
        return {"iid": it["iid"], "id": it["id"], "title": it.get("title", ""), "description": desc,
                "labels": it.get("labels", []), "state": it.get("state"), "web_url": it.get("web_url"),
                "milestone": (it.get("milestone") or {}).get("title", ""), "assignees": [a.get("name") for a in it.get("assignees", [])],
                "created_at": it.get("created_at"), "notes": notes,
                "attachments": [{"name": a, "url": self.g["url"].rstrip("/") + "/" + pp + u} for a, u in attachments]}

    def search_issues(self, text: str, project_path: Optional[str] = None, limit: int = 10) -> List[dict]:
        pp = project_path or self.g["issues_project_path"]
        rows = self.get(f"{self._proj(pp)}/issues", search=text, per_page=limit, state="all")
        return [{"iid": r["iid"], "title": r["title"], "state": r["state"], "labels": r.get("labels", [])} for r in rows]

    # ------------------------------------------------------------------ repository read
    def download_repo(self, key: str, dest: Path, refresh: bool = False) -> Path:
        """Archive of <code_root> at the base branch -> dest/<key>/ (dags/...). Cached by branch."""
        r = self.g["repos"][key]
        if r.get("local_repo_path"):
            p = Path(r["local_repo_path"])
            log.info("%s: using local checkout %s", key, p)
            return p
        target = Path(dest) / key
        marker = target / ".ref"
        if target.exists() and not refresh and marker.exists() and marker.read_text().strip() == r["base_branch"]:
            log.info("%s: using cached code %s @%s", key, target, r["base_branch"])
            return target
        if target.exists():
            shutil.rmtree(target)
        target.mkdir(parents=True)
        log.info("%s: downloading %s@%s:%s ...", key, r["project_path"], r["base_branch"], r["code_root"])
        resp = self.s.get(f"{self._proj(r['project_path'])}/repository/archive.zip",
                          params={"sha": r["base_branch"], "path": r["code_root"]}, timeout=900)
        resp.raise_for_status()
        n = 0
        with zipfile.ZipFile(io.BytesIO(resp.content)) as z:
            for m in z.infolist():
                if m.is_dir():
                    continue
                rel = m.filename.split("/", 1)[-1]
                idx = rel.find("dags/")
                if idx < 0:
                    continue
                rel = rel[idx:]
                if not rel.endswith((".sql", ".py", ".yaml", ".yml", ".json", ".txt", ".md", ".R", ".cfg", ".ini")):
                    continue
                dst = target / rel
                dst.parent.mkdir(parents=True, exist_ok=True)
                dst.write_bytes(z.read(m))
                n += 1
        marker.write_text(r["base_branch"])
        log.info("%s: %d files downloaded", key, n)
        return target

    def file(self, key: str, path: str, ref: Optional[str] = None) -> str:
        r = self.g["repos"][key]
        resp = self.s.get(f"{self._proj(r['project_path'])}/repository/files/{quote(path, safe='')}/raw",
                          params={"ref": ref or r["base_branch"]}, timeout=120)
        resp.raise_for_status()
        return resp.text

    # ------------------------------------------------------------------ publish
    @staticmethod
    def branch_name(story_id: str, title: str, suffix: str, max_len: int = 80) -> str:
        slug = re.sub(r"[^a-z0-9]+", "-", title.lower()).strip("-")
        slug = re.sub(r"-+", "-", slug)
        room = max_len - len(str(story_id)) - len(suffix) - 2
        slug = slug[:max(8, room)].rstrip("-")
        return f"{story_id}-{slug}-{suffix}"

    def branch_exists(self, key: str, branch: str) -> bool:
        r = self.g["repos"][key]
        resp = self.s.get(f"{self._proj(r['project_path'])}/repository/branches/{quote(branch, safe='')}", timeout=60)
        return resp.status_code == 200

    def create_branch(self, key: str, branch: str) -> dict:
        r = self.g["repos"][key]
        resp = self.s.post(f"{self._proj(r['project_path'])}/repository/branches",
                           data={"branch": branch, "ref": r["base_branch"]}, timeout=120)
        resp.raise_for_status()
        return resp.json()

    def existing_paths(self, key: str, paths: List[str], ref: str) -> Dict[str, bool]:
        r = self.g["repos"][key]
        out = {}
        for p in paths:
            resp = self.s.head(f"{self._proj(r['project_path'])}/repository/files/{quote(p, safe='')}",
                               params={"ref": ref}, timeout=60)
            out[p] = resp.status_code == 200
        return out

    def commit(self, key: str, branch: str, message: str, files: Dict[str, str]) -> dict:
        """One commit with every file (create or update decided against the branch)."""
        r = self.g["repos"][key]
        exists = self.existing_paths(key, list(files), branch)
        actions = [{"action": "update" if exists.get(p) else "create", "file_path": p, "content": c}
                   for p, c in files.items()]
        resp = self.s.post(f"{self._proj(r['project_path'])}/repository/commits",
                           json={"branch": branch, "commit_message": message, "actions": actions}, timeout=300)
        resp.raise_for_status()
        j = resp.json()
        j["branch_url"] = f"{self.g['url'].rstrip('/')}/{r['project_path']}/-/tree/{branch}"
        return j

    def publish(self, key: str, story_id: str, title: str, files: Dict[str, str], message: Optional[str] = None) -> dict:
        r = self.g["repos"][key]
        branch = self.branch_name(story_id, title, r["branch_suffix"], int(self.g.get("branch_name_max_length", 80)))
        created = False
        if not self.branch_exists(key, branch):
            self.create_branch(key, branch)
            created = True
        msg = message or self.g.get("commit_message_template", "{story_id}: {title}").format(story_id=story_id, title=title)
        c = self.commit(key, branch, msg, files)
        return {"repo": key, "branch": branch, "branch_created": created, "files": len(files), "commit": c.get("id", "")[:12],
                "branch_url": c.get("branch_url", ""), "commit_url": c.get("web_url", "")}
