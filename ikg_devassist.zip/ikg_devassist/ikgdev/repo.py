"""
Index of a code repository checkout (ikg-dags or odm-dags): files, SQL scripts (target table, source tables,
output columns), DAG tasks (task group -> task -> sql file), ODM rule files (insight types). Everything is
computed from the files with regexes (+ sqlglot where it parses), cached in memory, searchable by the agents.
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Dict, List, Optional, Set

log = logging.getLogger(__name__)

PARAM_RE = re.compile(r"\{\{\s*params\.([A-Za-z_]+)\s*\}\}")
TABLE_REF = r"((?:\{\{\s*params\.[A-Za-z_]+\s*\}\}|[A-Za-z_][A-Za-z0-9_]*)\.)?([A-Za-z_][A-Za-z0-9_]*)"


def _strip_comments(sql: str) -> str:
    sql = re.sub(r"/\*.*?\*/", " ", sql, flags=re.S)
    sql = re.sub(r"--[^\n]*", " ", sql)
    return sql


def _norm_table(schema: Optional[str], name: str) -> str:
    s = (schema or "").rstrip(".")
    m = PARAM_RE.search(s)
    if m:
        s = m.group(1)
    return f"{s}.{name}".lower() if s else name.lower()


@dataclass
class SqlScript:
    path: str                       # relative to repo root (dags/...)
    folder: str                     # sql sub folder (e.g. ikg_cash_distribution)
    name: str                       # file stem
    targets: List[str] = field(default_factory=list)      # tables created / inserted (schema.name with param schema names)
    sources: List[str] = field(default_factory=list)      # tables read
    columns: List[str] = field(default_factory=list)      # output columns of the (last) CREATE TABLE AS select
    params: List[str] = field(default_factory=list)       # {{params.X}} used
    distributed_by: str = ""
    has_grant: bool = False
    statements: int = 0
    size: int = 0


@dataclass
class DagTask:
    dag_file: str
    group: str
    task_id: str
    operator: str
    sql: str = ""                  # 'folder/file.sql'
    python_callable: str = ""


class RepoIndex:
    def __init__(self, key: str, root: Path, sql_root: str, dag_glob: str = "dags/*/dags/*.py"):
        self.key = key
        self.root = Path(root)
        self.sql_root = sql_root
        self.dag_glob = dag_glob
        self.files: List[str] = []
        self.scripts: Dict[str, SqlScript] = {}
        self.tasks: List[DagTask] = []
        self.producers: Dict[str, List[str]] = {}       # table -> [script path]
        self.consumers: Dict[str, List[str]] = {}       # table -> [script path]
        self.folders: Dict[str, int] = {}

    # ------------------------------------------------------------------ build
    def build(self) -> "RepoIndex":
        if not self.root.exists():
            raise FileNotFoundError(f"{self.key}: repository folder not found: {self.root}")
        for p in sorted(self.root.rglob("*")):
            if p.is_file() and not any(part.startswith(".") for part in p.relative_to(self.root).parts):
                rel = p.relative_to(self.root).as_posix()
                self.files.append(rel)
                if rel.endswith(".sql"):
                    try:
                        self.scripts[rel] = self._parse_sql(rel, p.read_text(encoding="utf-8", errors="replace"))
                    except Exception as e:  # noqa: BLE001
                        log.debug("sql parse failed %s: %s", rel, e)
        for s in self.scripts.values():
            for t in s.targets:
                self.producers.setdefault(t, []).append(s.path)
            for t in s.sources:
                self.consumers.setdefault(t, []).append(s.path)
            self.folders[s.folder] = self.folders.get(s.folder, 0) + 1
        for p in sorted(self.root.glob(self.dag_glob)):
            self.tasks += self._parse_dag(p)
        log.info("%s: %d files, %d sql scripts, %d dag tasks, %d sql folders", self.key, len(self.files),
                 len(self.scripts), len(self.tasks), len(self.folders))
        return self

    def _parse_sql(self, rel: str, text: str) -> SqlScript:
        folder = Path(rel).parent.name
        s = SqlScript(path=rel, folder=folder, name=Path(rel).stem, size=len(text))
        clean = _strip_comments(text)
        s.params = sorted(set(PARAM_RE.findall(text)))
        s.statements = len([x for x in clean.split(";") if x.strip()])
        for m in re.finditer(r"(?is)\bcreate\s+(?:temp(?:orary)?\s+)?table\s+(?:if\s+not\s+exists\s+)?" + TABLE_REF, clean):
            s.targets.append(_norm_table(m.group(1), m.group(2)))
        for m in re.finditer(r"(?is)\binsert\s+into\s+" + TABLE_REF, clean):
            s.targets.append(_norm_table(m.group(1), m.group(2)))
        for m in re.finditer(r"(?is)\b(?:from|join)\s+" + TABLE_REF + r"(?!\s*\()", clean):
            t = _norm_table(m.group(1), m.group(2))
            if t.split(".")[-1] not in ("select", "lateral", "unnest", "generate_series") and t not in s.targets:
                s.sources.append(t)
        s.targets = list(dict.fromkeys(s.targets))
        s.sources = [t for t in dict.fromkeys(s.sources) if t not in s.targets]
        md = re.search(r"(?is)distributed\s+by\s*\(([^)]*)\)", clean)
        s.distributed_by = re.sub(r"\s+", "", md.group(1)) if md else ("RANDOMLY" if re.search(r"(?i)distributed\s+randomly", clean) else "")
        s.has_grant = bool(re.search(r"(?i)\bgrant\s+select\b", clean))
        s.columns = self._output_columns(clean)
        return s

    @staticmethod
    def _output_columns(clean: str) -> List[str]:
        """Output column names of the last CREATE TABLE ... AS SELECT (alias or last identifier of each item)."""
        m = list(re.finditer(r"(?is)create\s+(?:temp(?:orary)?\s+)?table\s+(?:if\s+not\s+exists\s+)?[^;]*?\bas\s*\(?\s*select\s+(.*?)\s+from\s", clean))
        if not m:
            return []
        body = m[-1].group(1)
        if body.strip().startswith("*"):
            return ["*"]
        cols, depth, cur = [], 0, []
        for ch in body:
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
            if ch == "," and depth == 0:
                cols.append("".join(cur)); cur = []
            else:
                cur.append(ch)
        cols.append("".join(cur))
        out = []
        for c in cols:
            c = c.strip()
            if not c:
                continue
            a = re.search(r"(?is)\bas\s+([A-Za-z_][A-Za-z0-9_]*)\s*$", c)
            if a:
                out.append(a.group(1).lower()); continue
            toks = re.findall(r"[A-Za-z_][A-Za-z0-9_]*", c)
            if toks:
                out.append(toks[-1].lower())
        return out[:400]

    def _parse_dag(self, p: Path) -> List[DagTask]:
        text = p.read_text(encoding="utf-8", errors="replace")
        rel = p.relative_to(self.root).as_posix()
        out, group = [], ""
        for line in text.splitlines():
            g = re.search(r"with\s+TaskGroup\(\s*['\"]([^'\"]+)['\"]", line)
            if g:
                group = g.group(1)
            m = re.search(r"^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(PostgresOperator|PythonOperator|BashOperator|DummyOperator|BranchPythonOperator|EmailOperator|PythonSensor)\s*\((.*)$", line)
            if m:
                args = m.group(3)
                tid = re.search(r"task_id\s*=\s*['\"]([^'\"]+)['\"]", args)
                sql = re.search(r"sql\s*=\s*['\"]([^'\"]+)['\"]", args)
                pc = re.search(r"python_callable\s*=\s*([A-Za-z_][A-Za-z0-9_.]*)", args)
                out.append(DagTask(dag_file=rel, group=group, task_id=tid.group(1) if tid else m.group(1), operator=m.group(2),
                                   sql=sql.group(1) if sql else "", python_callable=pc.group(1) if pc else ""))
        return out

    # ------------------------------------------------------------------ queries
    def read(self, rel: str, max_chars: int = 60000) -> str:
        p = self.root / rel
        if not p.exists():
            return ""
        t = p.read_text(encoding="utf-8", errors="replace")
        return t if len(t) <= max_chars else t[:max_chars] + f"\n... [truncated {len(t) - max_chars} chars]"

    def exists(self, rel: str) -> bool:
        return (self.root / rel).exists()

    def search(self, pattern: str, limit: int = 40, glob: str = "") -> List[dict]:
        rx = re.compile(pattern, re.I)
        out = []
        for rel in self.files:
            if glob and not Path(rel).match(glob):
                continue
            try:
                for i, line in enumerate((self.root / rel).read_text(encoding="utf-8", errors="replace").splitlines(), 1):
                    if rx.search(line):
                        out.append({"file": rel, "line": i, "text": line.strip()[:200]})
                        if len(out) >= limit:
                            return out
            except Exception:  # noqa: BLE001
                continue
        return out

    def script_for_table(self, table: str) -> List[str]:
        t = table.lower().split(".")[-1]
        return [p for k, ps in self.producers.items() if k.split(".")[-1] == t for p in ps]

    def scripts_reading(self, table: str) -> List[str]:
        t = table.lower().split(".")[-1]
        return [p for k, ps in self.consumers.items() if k.split(".")[-1] == t for p in ps]

    def tasks_for_sql(self, sql_rel: str) -> List[DagTask]:
        tail = "/".join(Path(sql_rel).parts[-2:])
        return [t for t in self.tasks if t.sql == tail]

    def folder_examples(self, folder: str, n: int = 2) -> List[str]:
        return [p for p, s in self.scripts.items() if s.folder == folder][:n]

    def summary(self) -> dict:
        return {"repo": self.key, "files": len(self.files), "sql_scripts": len(self.scripts), "dag_tasks": len(self.tasks),
                "sql_folders": sorted(self.folders), "dag_files": sorted({t.dag_file for t in self.tasks})}

    def to_json(self) -> dict:
        return {"key": self.key, "files": self.files, "scripts": {k: asdict(v) for k, v in self.scripts.items()},
                "tasks": [asdict(t) for t in self.tasks], "folders": self.folders}
