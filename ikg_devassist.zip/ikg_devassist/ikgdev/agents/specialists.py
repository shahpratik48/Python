"""The development-assistant agents: Story, Design, Code, Review, Change, QA."""
from __future__ import annotations

import logging
from pathlib import Path
from typing import List

from .base import Agent, obj, arr, S, I, B
from .tools import build_tools

log = logging.getLogger(__name__)
PROMPTS = Path(__file__).resolve().parent.parent.parent / "prompts"
EVIDENCE = arr(obj({"source": S, "detail": S}))
QUESTION = arr(obj({"question": S, "blocking": B, "suggested_default": S}))


def _prompt(name: str) -> str:
    return (PROMPTS / f"{name}.md").read_text(encoding="utf-8")


class _DevAgent(Agent):
    strict_grounding = False

    def __init__(self, ctx, schema: dict, prompt: str, workspace=None, tools: List = None):
        self.max_steps = int(ctx.cfg.get("agents", {}).get("max_steps", 16))
        super().__init__(ctx, tools if tools is not None else build_tools(ctx, workspace), schema, prompt)

    def go(self, task: dict, label: str) -> dict:
        return self.run(task, task_label=label, use_cache=False)


# ---------------------------------------------------------------------- story
STORY_SCHEMA = obj({
    "summary": S, "scope": {"type": "string", "enum": ["ikg", "odm", "both"]},
    "story_type": S, "entities": arr(S),
    "sources": arr(obj({"table": S, "columns": arr(S), "schema_param": S, "why": S}, ["table"])),
    "profile_changes": arr(obj({"profile_table": S, "column": S, "type": S, "derivation": S, "grain": S}, ["profile_table", "column"])),
    "odm_changes": arr(obj({"rule_type": S, "insight_type": S, "target_type": S, "where_logic": S, "metric_name": S,
                            "metric_type": S, "metric_val": S, "insight_category": S, "insight_att_name": S, "insight_att_val": S}, ["rule_type", "insight_type"])),
    "acceptance_criteria": arr(S), "assumptions": arr(S), "open_questions": QUESTION, "evidence": EVIDENCE,
}, ["summary", "scope", "story_type", "sources", "profile_changes", "odm_changes", "acceptance_criteria", "assumptions", "open_questions", "evidence"])


class StoryAgent(_DevAgent):
    name = "story_agent"

    def __init__(self, ctx, workspace=None):
        super().__init__(ctx, STORY_SCHEMA, _prompt("story_agent"), workspace)


# ---------------------------------------------------------------------- design
FILE_PLAN = obj({"repo": S, "path": S, "action": {"type": "string", "enum": ["create", "modify"]}, "kind": S, "purpose": S,
                 "depends_on": arr(S), "details": {"type": "object"}}, ["repo", "path", "action", "kind", "purpose"])
DESIGN_SCHEMA = obj({
    "summary": S, "repos": arr(S), "files": arr(FILE_PLAN),
    "new_tables": arr(obj({"name": S, "grain": S, "key": S, "columns": arr(S)}, ["name"])),
    "changed_tables": arr(S),
    "impact": obj({"consumers_of_changed_tables": arr(S), "dag_groups_touched": arr(S), "performance_notes": arr(S)}, []),
    "validation": arr(obj({"name": S, "sql": S})),
    "airflow": obj({"variables": arr(S), "connections": arr(S)}, []),
    "assumptions": arr(S), "open_questions": QUESTION, "evidence": EVIDENCE,
}, ["summary", "repos", "files", "impact", "validation", "assumptions", "open_questions", "evidence"])


class DesignAgent(_DevAgent):
    name = "design_agent"

    def __init__(self, ctx, workspace=None):
        super().__init__(ctx, DESIGN_SCHEMA, _prompt("design_agent"), workspace)

    def ground(self, result: dict, task: dict):
        errs = []
        allowed = set(self.ctx.repos)
        for f in result.get("files", []):
            if f.get("repo") not in allowed:
                errs.append(f"file {f.get('path')}: repo '{f.get('repo')}' is not loaded ({sorted(allowed)})")
            if f.get("action") == "modify" and f.get("repo") in allowed and not self.ctx.repo(f["repo"]).exists(f["path"]):
                errs.append(f"file {f.get('path')}: action=modify but the file does not exist in {f['repo']} - use create or fix the path")
        if not result.get("files"):
            errs.append("plan has no files")
        n = int(self.ctx.cfg.generation.get("max_files_per_story", 25))
        if len(result.get("files", [])) > n:
            errs.append(f"plan has {len(result['files'])} files - more than {n}; simplify")
        return result, errs


# ---------------------------------------------------------------------- code
CODE_SCHEMA = obj({"repo": S, "path": S, "content": S,
                   "edits": arr(obj({"find": S, "replace": S}, ["find", "replace"])),
                   "explanation": S, "evidence": EVIDENCE, "confidence": I,
                   "what_is_required": S, "standards_findings_left": arr(S)},
                  ["repo", "path", "content", "explanation", "evidence", "confidence", "what_is_required", "standards_findings_left"])


def apply_edits(original: str, edits: list):
    """Apply find/replace edits to a file (each `find` must occur exactly once). Returns (text, errors)."""
    errs, text = [], original
    for i, e in enumerate(edits, 1):
        f = e.get("find", "")
        if not f.strip():
            errs.append(f"edit {i}: empty find")
            continue
        n = text.count(f)
        if n == 0:
            # tolerate whitespace differences at line ends
            import re as _re
            pat = r"\s*".join(_re.escape(x) for x in f.split()) if f.split() else ""
            m = list(_re.finditer(pat, text)) if pat else []
            if len(m) == 1:
                text = text[:m[0].start()] + e.get("replace", "") + text[m[0].end():]
                continue
            errs.append(f"edit {i}: `find` text not found in the original file (copy it exactly from read_file): {f[:80]!r}")
        elif n > 1:
            errs.append(f"edit {i}: `find` text occurs {n} times - include more surrounding lines to make it unique: {f[:80]!r}")
        else:
            text = text.replace(f, e.get("replace", ""), 1)
    return text, errs


class CodeAgent(_DevAgent):
    name = "code_agent"
    strict_grounding = True
    max_fix_rounds = 1

    def __init__(self, ctx, workspace=None):
        super().__init__(ctx, CODE_SCHEMA, _prompt("code_agent"), workspace)

    def ground(self, result: dict, task: dict):
        errs = []
        want = task.get("file", {})
        if want.get("path") and result.get("path") != want["path"]:
            result["path"] = want["path"]
        if want.get("repo"):
            result["repo"] = want["repo"]
        content = result.get("content", "")
        original = ""
        if want.get("action") == "modify" and result["repo"] in self.ctx.repos:
            original = self.ctx.repo(result["repo"]).read(result["path"], 10 ** 8)
        if result.get("edits"):
            if not original:
                errs.append("edits are only allowed for action=modify files - return the full content instead")
            else:
                content, e2 = apply_edits(original, result["edits"])
                errs += e2
                if not e2:
                    result["content"] = content
                    result["edits"] = []
        if len(content.strip()) < 20:
            errs.append("content is empty")
        if result["path"].endswith(".py"):
            try:
                import ast
                ast.parse(content)
            except SyntaxError as e:
                errs.append(f"python syntax error line {e.lineno}: {e.msg}")
        if original and len(content) < 0.6 * len(original):
            errs.append(f"modified file is much shorter than the original ({len(content)} vs {len(original)} chars) - return the FULL file, "
                        "or use `edits` [{find, replace}] for a large file")
        return result, errs


# ---------------------------------------------------------------------- review
REVIEW_SCHEMA = obj({"verdict": {"type": "string", "enum": ["approve", "revise"]},
                     "findings": arr(obj({"file": S, "severity": S, "issue": S, "fix": S}, ["file", "severity", "issue", "fix"])),
                     "confidence": I, "what_is_required": S, "suggestions": arr(S)},
                    ["verdict", "findings", "confidence", "what_is_required", "suggestions"])


class ReviewAgent(_DevAgent):
    name = "review_agent"

    def __init__(self, ctx, workspace=None):
        super().__init__(ctx, REVIEW_SCHEMA, _prompt("review_agent"), workspace)


# ---------------------------------------------------------------------- change
CHANGE_SCHEMA = obj({"kind": {"type": "string", "enum": ["change", "clarify", "answer"]},
                     "files": arr(obj({"repo": S, "path": S, "action": {"type": "string", "enum": ["create", "modify", "delete"]},
                                       "content": S, "edits": arr(obj({"find": S, "replace": S}, ["find", "replace"])),
                                       "explanation": S}, ["repo", "path", "action"])),
                     "answer": S, "confidence": I, "evidence": EVIDENCE}, ["kind", "files", "answer", "confidence", "evidence"])


class ChangeAgent(_DevAgent):
    name = "change_agent"
    strict_grounding = True

    def __init__(self, ctx, workspace=None):
        self.workspace = workspace
        super().__init__(ctx, CHANGE_SCHEMA, _prompt("change_agent"), workspace)

    def ground(self, result: dict, task: dict):
        errs = []
        for f in result.get("files", []):
            if f.get("action") == "delete":
                continue
            if f.get("edits"):
                base = self.workspace.get(f["repo"], f["path"]) if self.workspace is not None else None
                if base is None and f["repo"] in self.ctx.repos:
                    base = self.ctx.repo(f["repo"]).read(f["path"], 10 ** 8)
                if not base:
                    errs.append(f"{f['path']}: edits need an existing file - give the full content")
                    continue
                txt, e2 = apply_edits(base, f["edits"])
                errs += [f"{f['path']}: {x}" for x in e2]
                if not e2:
                    f["content"], f["edits"] = txt, []
            elif len((f.get("content") or "").strip()) < 20:
                errs.append(f"{f['path']}: content is empty (give the full file or edits)")
            if f["path"].endswith(".py") and f.get("content"):
                try:
                    import ast
                    ast.parse(f["content"])
                except SyntaxError as e:
                    errs.append(f"{f['path']}: python syntax error line {e.lineno}: {e.msg}")
        return result, errs


# ---------------------------------------------------------------------- qa
QA_SCHEMA = obj({"answer": S, "references": arr(S)}, ["answer", "references"])


class QAAgent(_DevAgent):
    name = "qa_agent"

    def __init__(self, ctx, workspace=None):
        super().__init__(ctx, QA_SCHEMA, _prompt("qa_agent"), workspace)
