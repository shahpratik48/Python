"""Shared context for the development-assistant agents: repositories, data catalog, standards, knowledge, LLM."""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, Optional

from .base import Trace
from ..catalog import Catalog
from ..repo import RepoIndex
from ..skills import SkillLibrary
from ..standards import StandardsChecker

log = logging.getLogger(__name__)


class DevContext:
    def __init__(self, cfg, llm, gp, gitlab, repos: Dict[str, RepoIndex], catalog: Optional[Catalog]):
        self.cfg = cfg
        self.llm = llm
        self.gp = gp
        self.gitlab = gitlab
        self.repos = repos                     # {"ikg": RepoIndex, "odm": RepoIndex}
        self.cat = catalog                     # may be None when Greenplum is not reachable
        self.skills = SkillLibrary(cfg.path(cfg.knowledge["skills_folder"]))
        repo_dirs = []
        rf = cfg.knowledge.get("standards_repo_folder", "")
        rk = cfg.knowledge.get("standards_repo", "ikg")
        if rf and rk in repos:
            repo_dirs.append(repos[rk].root / rf)
        self.checker = StandardsChecker(cfg, cfg.path(cfg.knowledge["standards_folder"]), repo_dirs)
        log.info("standards files: %s", self.checker.sources_text())
        self.trace = Trace()
        p = cfg.path(cfg.knowledge["odm_knowledge_md"])
        self.odm_knowledge = p.read_text(encoding="utf-8") if p.exists() else ""
        p = cfg.path(cfg.knowledge.get("ikg_conventions", "knowledge/ikg_conventions.md"))
        self.ikg_conventions = p.read_text(encoding="utf-8") if p.exists() else ""
        self.store = None
        self._sample_cache = {}

    def reasoning_effort(self, agent_name: str) -> Optional[str]:
        return (self.cfg.get("agents", {}).get("reasoning_effort") or {}).get(agent_name)

    def repo(self, key: str) -> RepoIndex:
        if key not in self.repos:
            raise KeyError(f"repository '{key}' is not loaded (loaded: {list(self.repos)})")
        return self.repos[key]

    def shared_context(self) -> str:
        ikg, odm = self.cfg.get("ikg", {}), self.cfg.get("odm", {})
        lines = ["## ENVIRONMENT",
                 "Greenplum (PostgreSQL dialect) schema core_ikg referenced ONLY through Airflow params, e.g. "
                 f"{ikg.get('schema_param')} (IKG tables), {ikg.get('edw_schema_param')} (EDW source tables), "
                 f"profile date {ikg.get('profile_date_param')}, owner {ikg.get('owner_param')}, reader {ikg.get('reader_param')}.",
                 "Repositories loaded: " + ", ".join(f"{k} ({r.summary()['sql_scripts']} sql, {r.summary()['dag_tasks']} tasks)" for k, r in self.repos.items()),
                 "", "## IKG CONVENTIONS", self.ikg_conventions[:7000],
                 "", "## ODM KNOWLEDGE (summary)", self.odm_knowledge[:5000],
                 "", self.checker.rules_digest(6000),
                 "", "## SKILL FILES (business definitions)", self.skills.full_text()[:4000]]
        if self.cat is not None:
            lines += ["", "## ENTITIES AND KEYS", self.cat.entity_overview()]
        return "\n".join(lines)
