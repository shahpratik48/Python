"""Tools for the development-assistant agents: repository code, data catalog, lineage, data peeks, standards."""
from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import List, Optional

from .base import Tool, obj, arr, S, I, B

log = logging.getLogger(__name__)


def build_tools(ctx, workspace=None) -> List[Tool]:
    cfg = ctx.cfg

    # ------------------------------------------------------------------ repository
    def list_folder(repo: str, path: str = "", limit: int = 200):
        r = ctx.repo(repo)
        pre = path.strip("/")
        items = sorted({(f[len(pre):].lstrip("/").split("/")[0] + ("/" if "/" in f[len(pre):].lstrip("/") else ""))
                        for f in r.files if (not pre or f.startswith(pre + "/"))})
        return {"repo": repo, "path": pre or "/", "entries": list(items)[:limit], "total": len(items)}

    def read_file(repo: str, path: str, max_chars: int = 0, start_line: int = 0, end_line: int = 0):
        r = ctx.repo(repo)
        mx = int(max_chars or cfg.generation.get("context_file_chars", 60000))
        src = "repository"
        t = None
        if workspace is not None:
            t = workspace.get(repo, path)
            src = "workspace (generated/modified)" if t is not None else src
        if t is None:
            t = r.read(path, 10 ** 8)
        if not t:
            return {"error": f"{path} not found in {repo}"}
        lines = t.splitlines()
        if start_line or end_line:
            a, b = max(1, int(start_line or 1)), int(end_line or len(lines))
            body = "\n".join(lines[a - 1:b])
            return {"repo": repo, "path": path, "source": src, "lines": f"{a}-{min(b, len(lines))} of {len(lines)}", "content": body[:mx]}
        out = {"repo": repo, "path": path, "source": src, "total_lines": len(lines), "total_chars": len(t), "content": t[:mx]}
        if len(t) > mx:
            out["note"] = f"truncated at {mx} chars - use start_line/end_line (search_code gives line numbers) to read the rest"
        return out

    def search_code(repo: str, pattern: str, glob: str = "", limit: int = 40):
        return {"matches": ctx.repo(repo).search(pattern, limit=limit, glob=glob)}

    def sql_script_info(repo: str, path: str):
        s = ctx.repo(repo).scripts.get(path)
        if not s:
            return {"error": f"{path} is not an indexed sql script"}
        d = {"path": s.path, "folder": s.folder, "targets": s.targets, "sources": s.sources, "columns": s.columns[:120],
             "params": s.params, "distributed_by": s.distributed_by, "has_grant": s.has_grant, "statements": s.statements}
        d["dag_tasks"] = [t.__dict__ for t in ctx.repo(repo).tasks_for_sql(s.path)]
        return d

    def table_scripts(repo: str, table: str):
        r = ctx.repo(repo)
        return {"table": table, "produced_by": r.script_for_table(table), "read_by": r.scripts_reading(table)[:40]}

    def folder_examples(repo: str, folder: str, n: int = 2):
        r = ctx.repo(repo)
        ex = r.folder_examples(folder, n)
        return {"folder": folder, "files": ex, "contents": {p: r.read(p, 8000) for p in ex}}

    def dag_tasks(repo: str, group: str = "", sql_file: str = ""):
        r = ctx.repo(repo)
        ts = r.tasks
        if group:
            ts = [t for t in ts if t.group == group]
        if sql_file:
            ts = [t for t in ts if sql_file in t.sql]
        return {"count": len(ts), "tasks": [t.__dict__ for t in ts[:80]],
                "groups": sorted({t.group for t in r.tasks})[:120] if not group else [group]}

    # ------------------------------------------------------------------ data catalog
    def describe_table(table: str, columns_filter: str = "", limit: int = 80):
        if ctx.cat is None:
            return {"error": "data catalog not available (no Greenplum connection)"}
        t = ctx.cat.tables.get(table.lower())
        if t is None:
            cands = [k for k in ctx.cat.tables if table.lower() in k][:10]
            return {"error": f"unknown table {table}", "similar": cands}
        cols = t.columns
        if columns_filter:
            toks = set(columns_filter.lower().replace(",", " ").split())
            cols = [c for c in cols if any(tk in c.name or tk in c.business_name.lower() or tk in c.description.lower() for tk in toks)]
        return {"table": t.name, "entity": t.entity, "grain": t.grain, "keys": t.primary_key or t.join_keys, "rows": t.row_estimate,
                "n_columns": len(t.columns), "columns": [{"column": c.name, "type": c.data_type, "business_name": c.business_name,
                                                          "description": c.description[:200]} for c in cols[:limit]]}

    def search_columns(query: str, limit: int = 25):
        if ctx.cat is None:
            return {"error": "data catalog not available"}
        return {"columns": [{"table": c.table, "column": c.name, "business_name": c.business_name,
                             "description": c.description[:200]} for c, _ in ctx.cat.search_columns(query, k=limit)]}

    def column_lineage(table: str, column: str = ""):
        if ctx.cat is None:
            return {"error": "lineage not available"}
        rows = ctx.cat.lineage_of(table, column)
        return {"table": table, "column": column, "rows": rows[:40], "note": "" if rows else "no lineage rows - check table_scripts / profile sql"}

    def table_lineage(table: str):
        if ctx.cat is None:
            return {"error": "lineage not available"}
        return {"table": table, "rows": ctx.cat.table_lineage_of(table)}

    def glossary(term: str):
        if ctx.cat is None:
            return {"note": "glossary not loaded"}
        t = term.lower().strip()
        return {k: v for k, v in ctx.cat.glossary.items() if t == k or t in k or t in v.lower()} or {"note": f"'{term}' not in glossary"}

    def db_columns(table: str, schema: str = ""):
        """Real columns of ANY table in Greenplum (EDW sources, intermediate tables) from information_schema."""
        if ctx.gp is None:
            return {"error": "no database connection"}
        sch = schema or cfg.greenplum["schema"]
        try:
            df = ctx.gp.read("select column_name, data_type from information_schema.columns where table_schema = :s and table_name = :t order by ordinal_position",
                             {"s": sch, "t": table.lower()})
            if df.empty:
                df2 = ctx.gp.read("select table_schema, table_name from information_schema.tables where table_name = :t limit 10", {"t": table.lower()})
                return {"error": f"{sch}.{table} not found", "found_in": df2.to_dict("records")}
            return {"table": f"{sch}.{table}", "columns": df.to_dict("records")[:300]}
        except Exception as e:  # noqa: BLE001
            return {"error": str(e)[:200]}

    def run_query(sql: str, limit: int = 50):
        """Read-only SELECT against Greenplum (max 50 rows) to inspect values, counts, distinct codes."""
        if ctx.gp is None or not cfg.sources.get("allow_data_queries", True):
            return {"error": "data queries not allowed / no connection"}
        s = sql.strip().rstrip(";")
        if not re.match(r"(?is)^\s*(select|with)\b", s) or re.search(r"(?i)\b(insert|update|delete|drop|create|alter|truncate|grant)\b", s):
            return {"error": "only SELECT statements are allowed"}
        if not re.search(r"(?i)\blimit\s+\d+", s):
            s += f" LIMIT {min(int(limit or 50), 50)}"
        try:
            df = ctx.gp.read(s)
            return {"rows": df.astype(str).head(50).to_dict("records"), "columns": list(df.columns)}
        except Exception as e:  # noqa: BLE001
            return {"error": str(e).split("\n")[0][:300]}

    # ------------------------------------------------------------------ standards / knowledge
    def check_standards(repo: str, path: str, content: str):
        """Run the deterministic standards checker on one file before submitting it."""
        existing = {("/".join(Path(t.sql).parts[-2:])) for t in ctx.repo(repo).tasks if t.sql} if repo in ctx.repos else set()
        originals = {}
        if repo in ctx.repos and ctx.repo(repo).exists(path):
            originals[path] = ctx.repo(repo).read(path, 10 ** 8)
        rep = ctx.checker.check_files({path: content}, repo, {"existing_tasks": existing, "original_files": originals,
                                                              "existing_files": set(ctx.repo(repo).files) if repo in ctx.repos else set()})
        return {"score": rep.score, "grade": rep.grade, "passed": rep.passed,
                "findings": [{"rule": f.rule_id, "severity": f.severity, "line": f.line, "message": f.message} for f in rep.findings],
                "pre_existing_not_scored": [{"rule": f.rule_id, "line": f.line, "message": f.message} for f in rep.pre_existing]}

    def odm_knowledge(section: str = ""):
        txt = ctx.odm_knowledge
        if section:
            m = re.search(rf"(?is)(#+\s*[^\n]*{re.escape(section)}[^\n]*\n.*?)(?=\n#+\s|\Z)", txt)
            if m:
                return {"section": section, "text": m.group(1)[:8000]}
        return {"text": txt[:12000]}

    def skill_search(query: str):
        return {"hits": ctx.skills.search(query, k=6)}

    def workspace_files():
        if workspace is None:
            return {"files": []}
        return {"files": workspace.file_list()}

    tools = [
        Tool("list_folder", "List a folder of a repository (ikg | odm). Start at '' for the root.", obj({"repo": S, "path": S, "limit": I}, ["repo"]), list_folder),
        Tool("read_file", "Read a file from a repository (generated/modified version when one exists in the story workspace). Large files: pass start_line/end_line.", obj({"repo": S, "path": S, "max_chars": I, "start_line": I, "end_line": I}, ["repo", "path"]), read_file),
        Tool("search_code", "Regex search across a repository's files (optionally a glob like 'dags/ikg/scripts/sql/**/*.sql').", obj({"repo": S, "pattern": S, "glob": S, "limit": I}, ["repo", "pattern"]), search_code),
        Tool("sql_script_info", "Parsed facts of a SQL script: target table, source tables, output columns, params, DISTRIBUTED BY, DAG tasks.", obj({"repo": S, "path": S}), sql_script_info),
        Tool("table_scripts", "Which script produces a table and which scripts read it (code lineage).", obj({"repo": S, "table": S}), table_scripts),
        Tool("folder_examples", "Two existing scripts of a SQL folder as patterns to follow.", obj({"repo": S, "folder": S, "n": I}, ["repo", "folder"]), folder_examples),
        Tool("dag_tasks", "DAG tasks (TaskGroup, task_id, sql file) - filter by group or sql file name.", obj({"repo": S, "group": S, "sql_file": S}, ["repo"]), dag_tasks),
        Tool("describe_table", "Business metadata of a profile table and its columns (data catalog).", obj({"table": S, "columns_filter": S, "limit": I}, ["table"]), describe_table),
        Tool("search_columns", "Find profile columns by business meaning (synonyms / glossary expanded).", obj({"query": S, "limit": I}, ["query"]), search_columns),
        Tool("column_lineage", "Lineage rows of a profile/intermediate table column (source table/column, logic).", obj({"table": S, "column": S}, ["table"]), column_lineage),
        Tool("table_lineage", "Table-level lineage rows mentioning a table.", obj({"table": S}), table_lineage),
        Tool("glossary", "Meaning of an abbreviation.", obj({"term": S}), glossary),
        Tool("db_columns", "Real columns + types of any Greenplum table (EDW source, intermediate, profile) from information_schema.", obj({"table": S, "schema": S}, ["table"]), db_columns),
        Tool("run_query", "Read-only SELECT (<=50 rows) to inspect data: distinct codes, counts, sample values.", obj({"sql": S, "limit": I}, ["sql"]), run_query),
        Tool("check_standards", "Deterministic standards check of a file's content (score, findings). Use before submitting code.", obj({"repo": S, "path": S, "content": S}), check_standards),
        Tool("odm_knowledge", "The ODM knowledge base (optionally one section, e.g. 'Core Tables').", obj({"section": S}, []), odm_knowledge),
        Tool("skill_search", "Search the business definition skill files.", obj({"query": S}), skill_search),
        Tool("workspace_files", "Files generated so far for this story.", obj({}, []), workspace_files),
    ]
    return tools
