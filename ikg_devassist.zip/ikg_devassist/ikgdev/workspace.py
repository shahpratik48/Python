"""
Story workspace on disk: output/stories/<story_id>/
  story.json        the GitLab issue as read
  requirement.json  the story analysis (StoryAgent)
  plan.json         the design (DesignAgent)
  files/<repo>/<path>   generated / changed files, mirroring the repository folder structure
  original/<repo>/<path> the original content of changed files (for diffs)
  review.json       standards findings + agent review + confidence per file
  log.txt           the step log shown in the UI side panel
  <story>_<repo>.zip  download package (created on demand)
"""
from __future__ import annotations

import difflib
import json
import logging
import shutil
import time
import zipfile
from pathlib import Path
from typing import Dict, List, Optional

log = logging.getLogger(__name__)


class StoryWorkspace:
    def __init__(self, root: Path, story_id: str):
        self.story_id = str(story_id)
        self.dir = Path(root) / self.story_id
        self.dir.mkdir(parents=True, exist_ok=True)
        (self.dir / "files").mkdir(exist_ok=True)
        (self.dir / "original").mkdir(exist_ok=True)
        self.log_path = self.dir / "log.txt"

    # ------------------------------------------------------------------ log
    def log(self, msg: str) -> None:
        line = f"{time.strftime('%H:%M:%S')}  {msg}"
        with self.log_path.open("a", encoding="utf-8") as f:
            f.write(line + "\n")
        log.info("[%s] %s", self.story_id, msg)

    def read_log(self, tail: int = 400) -> List[str]:
        if not self.log_path.exists():
            return []
        return self.log_path.read_text(encoding="utf-8").splitlines()[-tail:]

    # ------------------------------------------------------------------ json state
    def save(self, name: str, data) -> None:
        (self.dir / f"{name}.json").write_text(json.dumps(data, ensure_ascii=False, indent=1, default=str), encoding="utf-8")

    def load(self, name: str, default=None):
        p = self.dir / f"{name}.json"
        return json.loads(p.read_text(encoding="utf-8")) if p.exists() else default

    # ------------------------------------------------------------------ files
    def put(self, repo: str, rel: str, content: str, original: Optional[str] = None) -> None:
        p = self.dir / "files" / repo / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        if original is not None:
            o = self.dir / "original" / repo / rel
            if not o.exists():
                o.parent.mkdir(parents=True, exist_ok=True)
                o.write_text(original, encoding="utf-8")

    def get(self, repo: str, rel: str) -> Optional[str]:
        p = self.dir / "files" / repo / rel
        return p.read_text(encoding="utf-8") if p.exists() else None

    def original(self, repo: str, rel: str) -> Optional[str]:
        p = self.dir / "original" / repo / rel
        return p.read_text(encoding="utf-8") if p.exists() else None

    def remove(self, repo: str, rel: str) -> None:
        p = self.dir / "files" / repo / rel
        if p.exists():
            p.unlink()

    def files(self, repo: Optional[str] = None) -> Dict[str, Dict[str, str]]:
        """{repo: {rel path: content}}"""
        out: Dict[str, Dict[str, str]] = {}
        base = self.dir / "files"
        for rp in sorted(base.iterdir()) if base.exists() else []:
            if not rp.is_dir() or (repo and rp.name != repo):
                continue
            out[rp.name] = {}
            for p in sorted(rp.rglob("*")):
                if p.is_file():
                    out[rp.name][p.relative_to(rp).as_posix()] = p.read_text(encoding="utf-8", errors="replace")
        return out

    def file_list(self) -> List[dict]:
        rows = []
        for repo, fs in self.files().items():
            for rel, content in fs.items():
                orig = self.original(repo, rel)
                rows.append({"repo": repo, "path": rel, "status": "modified" if orig is not None else "new",
                             "lines": content.count("\n") + 1, "chars": len(content)})
        return rows

    def diff(self, repo: str, rel: str) -> str:
        new = self.get(repo, rel) or ""
        old = self.original(repo, rel)
        if old is None:
            return "\n".join(f"+{l}" for l in new.splitlines())
        return "\n".join(difflib.unified_diff(old.splitlines(), new.splitlines(), f"a/{rel}", f"b/{rel}", lineterm=""))

    # ------------------------------------------------------------------ zip
    def zip(self, repo: Optional[str] = None) -> Path:
        name = f"{self.story_id}_{repo or 'all'}_{time.strftime('%Y%m%d_%H%M%S')}.zip"
        path = self.dir / name
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
            for rp, fs in self.files(repo).items():
                for rel, content in fs.items():
                    z.writestr(f"{rp}/{rel}", content)
            for extra in ("requirement.json", "plan.json", "review.json", "log.txt"):
                p = self.dir / extra
                if p.exists():
                    z.write(p, f"_story/{extra}")
        return path

    def reset_files(self) -> None:
        for sub in ("files", "original"):
            shutil.rmtree(self.dir / sub, ignore_errors=True)
            (self.dir / sub).mkdir()
