---
name: household-definitions
description: Household concepts used across IKG profile tables
---
# Household definitions

## Statement Householding
Statement Householding is the ability to group multiple account statements with the same account
registration address in a single envelope. Accounts may be householded either automatically during the
nightly systematic update process (i.e. nightly batch cycle), or manually using the online system.
Consent requirements (to be included in the same envelope) are calculated based on the tax identification
number on the accounts. Accounts marked as Include are mailed together; those marked Pending or Exclude
are not.

## Abbreviations
- shh = Statement Household
<!-- SME: add other household abbreviations here -->
