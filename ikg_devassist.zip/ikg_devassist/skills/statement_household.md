In all profile table, acc_mhh_n - is this marketing household or statement household?

source - ubs_base_acc_features_ikg. Let's check that table's definition of acc_mhh_n.

This confirms it: acc_mhh_n = b.household_plus, while acc_market_hh_n is separately populated from b.marketing_hh_id. So acc_mhh_n is distinct from the marketing household ID - it's the "household_plus" value, which (per the lineage docs) is UBS's statement/household grouping key (distinct from marketing_hh_id).

acc_mhh_n = statement household (sourced from household_plus), not the marketing household. The marketing household is tracked separately as acc_market_hh_n (sourced from marketing_hh_id).
