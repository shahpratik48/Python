# Skills folder

Put firm knowledge here as markdown files directly in this folder (`skills/*.md`, no sub-folders). Every file is read by the **skill agent**;
statements it extracts must quote the file verbatim, so write facts plainly.

Useful content:
- business definitions (households, segments, products, insight rules)
- abbreviations used in column names, e.g. `shh` = Statement Household
- column definitions, e.g. `acc_mhh_n = statement household (sourced from household_plus)` - these are
  authoritative for every profile table and override name-based guesses
- entity definitions and how entities relate (Client is a member of a Household ...)
- code values (`txn_dep_wdrw_c`: D = Deposit, W = Withdrawal)
- notes about specific profile tables
- rules for how metadata must be written

Optional front-matter (Anthropic SKILL.md style):
```
---
name: household-definitions
description: Definitions of household types used by IKG
---
```
