---
name: ikg-metadata-standards
description: How IKG attribute metadata must be written
---
# Metadata writing standards

## Functional names
- Use Title Case business names without abbreviations, for example "Household Cash Distributions Last 4 Weeks".
- Flags end with the word Indicator; counts end with the word Count.

## Descriptions
- State the unit (USD, percent, count, days) and the time window explicitly.
- For flags state what 1 means and what 0 means.
- Name the source system or vendor when known (EDW, Black Knight, ZoomInfo, Wealth-X, Yodlee, Speedeon, Windfall).
