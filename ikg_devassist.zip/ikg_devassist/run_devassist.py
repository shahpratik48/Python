"""
IKG-ODM Development Assistant - command line.

  python run_devassist.py --selftest              offline self-test (fake GitLab + scripted model, no secrets)
  python run_devassist.py --check                 connectivity: Azure OpenAI, Greenplum, GitLab, repositories
  python run_devassist.py --story 1234            generate the code for one story, print the report, write the zip
  python run_devassist.py                         interactive chat in the terminal (the web UI is app_web.py)
"""
from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ikgdev  # noqa: E402
from ikgdev.config import load_config, get_secret  # noqa: E402


def main(argv=None):
    ap = argparse.ArgumentParser(description="IKG-ODM Development Assistant")
    ap.add_argument("--config", default=None)
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--ikg-repo", default="", help="self-test: use a real ikg-dags checkout instead of the synthetic one")
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--story", default="", help="story number to generate")
    ap.add_argument("--rebuild", action="store_true", help="rebuild the data knowledge cache")
    ap.add_argument("--refresh-code", action="store_true", help="re-download the repositories")
    ap.add_argument("--no-db", action="store_true", help="work without Greenplum (code knowledge only)")
    ap.add_argument("-v", "--verbose", action="store_true")
    a = ap.parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if a.verbose else logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    for n in ("httpx", "httpx2", "openai", "urllib3", "sqlglot"):
        logging.getLogger(n).setLevel(logging.ERROR)
    cfg = load_config(a.config)

    if a.selftest:
        from ikgdev.selftest import run
        sys.exit(0 if run(cfg, a.ikg_repo) else 1)

    get_secret("llm_api_key")
    if not a.no_db:
        get_secret("gp_password")
    if not all(r.get("local_repo_path") for r in cfg.gitlab["repos"].values()):
        get_secret("gitlab_token")

    if a.check:
        from ikgdev.gitlab import GitLab
        llm = ikgdev.LLM(cfg, cfg.path(cfg.output["folder"]) / "cache")
        print("Azure OpenAI:", llm.check())
        if not a.no_db:
            print("Greenplum   :", ikgdev.Greenplum(cfg).test())
        gl = GitLab(cfg)
        print("GitLab      :", gl.test())
        ctx = ikgdev.prepare(cfg, llm=llm, gitlab=gl, need_db=not a.no_db, rebuild=a.rebuild, refresh_code=a.refresh_code)
        for k, r in ctx.repos.items():
            print(f"repo {k}: {r.summary()}")
        print("data knowledge:", f"{len(ctx.cat.tables)} tables" if ctx.cat else "not loaded")
        return

    ctx = ikgdev.prepare(cfg, need_db=not a.no_db, rebuild=a.rebuild, refresh_code=a.refresh_code)
    s = ikgdev.new_session(ctx)
    if a.story:
        print(s.ask(f"story {a.story}").render())
        print(s.ask("download zip").render())
        return
    print("IKG-ODM Development Assistant - type a story number, a change request, 'zip', 'push', 'quit'")
    while True:
        try:
            q = input("\nyou> ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if q.lower() in ("quit", "exit", "q"):
            break
        print("\n" + s.ask(q).render())


if __name__ == "__main__":
    main()
