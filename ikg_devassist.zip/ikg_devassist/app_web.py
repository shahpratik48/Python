"""
IKG-ODM Development Assistant - ChatGPT-style web UI (Python standard library HTTP server, no extra packages).

  python app_web.py                       # asks for the secrets (hidden), then serves http://localhost:8766
  python app_web.py --port 9000 --host 0.0.0.0 --no-browser
  python app_web.py --selftest-data       # the UI on the synthetic self-test story (no secrets, scripted model)

Left: chats. Centre: the conversation. Right: generated files (diff viewer), step log, plan, quality/evidence.
"""
from __future__ import annotations

import argparse
import logging
import sys
import threading
import webbrowser
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ikgdev  # noqa: E402
from ikgdev.config import load_config, get_secret  # noqa: E402
from ikgdev import webui  # noqa: E402


def main(argv=None):
    ap = argparse.ArgumentParser(description="IKG-ODM Development Assistant web UI")
    ap.add_argument("--config", default=None)
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8766)
    ap.add_argument("--rebuild", action="store_true", help="rebuild the data knowledge cache")
    ap.add_argument("--refresh-code", action="store_true", help="re-download the repositories")
    ap.add_argument("--no-db", action="store_true")
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--selftest-data", action="store_true")
    a = ap.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    for n in ("httpx", "httpx2", "openai", "urllib3", "sqlglot"):
        logging.getLogger(n).setLevel(logging.ERROR)
    cfg = load_config(a.config)
    if a.selftest_data:
        from ikgdev.selftest import FakeGitLab, ScriptedLLM, make_fake_ikg_repo, make_fake_odm_repo
        out = cfg.path(cfg.output["folder"]) / "selftest_ui"
        out.mkdir(parents=True, exist_ok=True)
        cfg["storage"]["backend"] = "file"
        cfg["storage"]["folder"] = str(out / "chats")
        cfg["output"]["stories_folder"] = str(out / "stories")
        gl = FakeGitLab(cfg, {"ikg": make_fake_ikg_repo(out / "repos/ikg"), "odm": make_fake_odm_repo(out / "repos/odm")}, out / "remote")
        ctx = ikgdev.prepare(cfg, llm=ScriptedLLM(cfg), gitlab=gl, need_db=False)
    else:
        get_secret("llm_api_key")
        if not a.no_db:
            get_secret("gp_password")
        if not all(r.get("local_repo_path") for r in cfg.gitlab["repos"].values()):
            get_secret("gitlab_token")
        ctx = ikgdev.prepare(cfg, need_db=not a.no_db, rebuild=a.rebuild, refresh_code=a.refresh_code)
    url = f"http://{'localhost' if a.host in ('127.0.0.1', '0.0.0.0') else a.host}:{a.port}/"
    print(f"\nIKG-ODM Development Assistant UI running at {url}  (Ctrl+C to stop)")
    if not a.no_browser:
        threading.Timer(1.0, lambda: webbrowser.open_new(url)).start()
    webui.serve(ctx, host=a.host, port=a.port)


if __name__ == "__main__":
    main()
