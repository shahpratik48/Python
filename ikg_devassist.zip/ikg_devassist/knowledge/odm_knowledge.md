# ODM - Opportunity Data Model | Knowledge Base

**Schema:** `core_ikg` (PostgreSQL / Greenplum) · **Platform:** Apache Airflow (Genesis) · **Repo:** odm-dags
(https://devcloud.ubs.net/ubs/gwma/smart-technology-and-analytics/staat-data-science/staat-ds-genesis/genesis-platform/odm-dags)
**Last Reviewed:** October 2026

---

## 1. What is ODM?

ODM (**Opportunity Data Model**) is a SQL-driven **rules engine** that reads IKG client/household/account profile
tables and applies hundreds of business rules to detect client, prospect, and Field Leader opportunities ("Smart
Insights"). Every rule is a standalone `.sql` file; adding a rule means adding a file - no DAG code changes required.
An Airflow `dag_builder_util` auto-discovers the SQL files in each folder and turns them into tasks / task groups.

ODM sits between **IKG** (data preparation) and **NLG** (narrative generation):

```
IKG profiles -> ODM rule engine (3 DAGs: client / prospect / FL) -> si_odm_insights_active -> NLG narratives -> FA emails
                                                                  -> archived to si_odm_insights_archive
```

Key folders inside the repo (`dags/odm/script/sql/`):

| Folder | Rule type / DAG |
|---|---|
| `ds_client_insights/` | **Client rules** (`odm_client_rules` DAG) |
| `prospect_insights/` | **Prospect rules** (`odm_prospect_rules` DAG) |
| `field_leader_insights/` | **FL (Field Leader) rules** (`odm_fl_rules` DAG) |
| `market_event_insights/` | Market-event rules (`odm_market_event_rules` DAG) |
| `odm_process/` | Pre-tasks, post-tasks, cleanup (table creation, exclusion list, archival) |

---

## 2. The Three ODM Rule Types (DAGs)

| # | Rule type | DAG(s) | Task-name file | Rule count (sample) | Target audience |
|---|---|---|---|---|---|
| 1 | **Client rules** | `odm_client_rules` | `odm_client_rules_task_names.txt` | ~415 dynamic rule tasks across 35+ categories (account, client, household, MTP/Yodlee, WealthX, Black Knight real-estate, news/intent, estate planning, withholdings, RMD, credit card, SBL, etc.) | Individual clients/households/accounts, surfaced to their assigned FA |
| 2 | **Prospect rules** | `odm_prospect_rules` | `odm_prospect_rules_task_names.txt` | ~43 dynamic rule tasks (birthday, WealthX deltas, Speedeon movers, Black Knight MLS, Windfall life-events) | Non-client prospects scored/prioritized for FA outreach |
| 3 | **FL (Field Leader) rules** | `odm_fl_rules` (triggered via `odm_field_leader_rules`) | `odm_fl_rules_task_names.txt` | ~57 dynamic rule tasks (recruitment signals, UBS FA performance/red-flag/council rules, "top" variants) | Field Leaders - team/branch aggregated insights |

Each of the three DAGs shares the same pipeline shape:

```
start_pipeline -> <rule task groups, parallel, max_active_tasks=5> -> set_odm_exclusion.odm_exclusion_list -> [update_status_endtime] -> end
```

All three rule types write their output rows into the **same** target tables - `si_odm_insights_active` (current run)
and, on archival, `si_odm_insights_archive` - distinguished only by the `insight_type` / `insight_category` values
each rule inserts.

---

## 3. Core Tables (schema `core_ikg`)

### 3.1 `si_odm_insights_active` - current ODM rule hits

Populated every ODM run (referenced in code as `{{ params.ODM_TABLE }}`). Truncated at the start of each run, then
filled by all client/prospect/FL/market-event rule SQL files, then filtered by the exclusion post-task.

| Column | Type | Description |
|---|---|---|
| `insight_id` | serial | Surrogate primary key |
| `insight_type` | varchar | Rule identifier / insight code (e.g. `si_sbl_in_margin_call`) - this is the value matched against `odm_exclusion_insight_type.insight_type` |
| `target_type` | varchar | Entity the insight is about (e.g. `CLIENT`, `HOUSEHOLD`, `ACCOUNT`, `PROSPECT`, `FA`, `FL`) |
| `target_key` | varchar | Identifier of the target entity (client id, household id, account number, FA GPN, etc.) |
| `metric_name` | varchar | Name of the metric/measure backing the insight |
| `metric_type` | varchar | Type/classification of the metric |
| `metric_val` | varchar | Metric value supporting the insight |
| `run_id` | varchar | ODM run identifier (UUID) - ties all rows from one weekly run together, used by downstream NLG to pull only the current batch |
| `insight_date_time` | timestamp | Business date/time the insight pertains to |
| `insight_category` | varchar | Higher-level grouping of the insight (rule category/folder) |
| `insight_att_name` | varchar(100) | Optional supplemental attribute name |
| `insight_att_val` | varchar(100) | Optional supplemental attribute value |
| `insight_execution_time` | timestamp (default now) | Timestamp the row was inserted by the rule |

Distributed by `(insight_type, target_key, run_id)`.

### 3.2 `si_odm_insights_archive` - archived ODM rule hits

Identical structure to `si_odm_insights_active` (code reference: `{{ params.ODM_ARCH_TABLE }}`). Historical insights
are copied here (by `odm_archival_load` / cleanup tasks) so that `si_odm_insights_active` can be truncated and
refreshed each run while prior runs remain queryable by `run_id` / `insight_date_time`.

| Column | Type | Description |
|---|---|---|
| `insight_id` | serial | Surrogate primary key |
| `insight_type` | varchar | Rule identifier / insight code |
| `target_type` | varchar | Entity type the insight is about |
| `target_key` | varchar | Target entity identifier |
| `metric_name` | varchar | Metric name |
| `metric_type` | varchar | Metric type |
| `metric_val` | varchar | Metric value |
| `run_id` | varchar | ODM run UUID this archived row came from |
| `insight_date_time` | timestamp | Business date/time of the insight |
| `insight_category` | varchar | Rule category/grouping |
| `insight_att_name` | varchar(100) | Supplemental attribute name |
| `insight_att_val` | varchar(100) | Supplemental attribute value |
| `insight_execution_time` | timestamp | Original insertion timestamp |

Distributed by `(insight_type, target_key, run_id)`.

### 3.3 `odm_exclusion_insight_type` - excluded rule types

Controls which `insight_type` values are suppressed from the active insights table. Populated/maintained by the
post-task `odm_exclusion_list.sql`, driven by the Airflow variable `ODM_RULES_EXCLUDE_LIST` (comma-separated list of
rule/insight-type names).

| Column | Type | Description |
|---|---|---|
| `insight_type` | varchar(200) | Rule/insight type being excluded - matches `si_odm_insights_active.insight_type` |
| `excluded_date` | timestamp | When this insight type was first marked excluded |
| `last_upd_dte` | timestamp | Last time the exclusion record was updated |
| `is_curr` | int | **1 = currently excluded (active exclusion)**, **0 = historical/no-longer-excluded record** |

Distributed by `(insight_type)`.

**Logic (from `odm_exclusion_list.sql`):**
1. Every insight type listed in `ODM_RULES_EXCLUDE_LIST` that doesn't already have a current (`is_curr=1`) row is **inserted** as a new current exclusion.
2. Every existing current exclusion (`is_curr=1`) whose type is **no longer** in `ODM_RULES_EXCLUDE_LIST` is **flipped to `is_curr=0`** (effectively re-enabling that rule's output) - this is a type-2/SCD style history table, not a hard delete.
3. This lets a rule be disabled/re-enabled purely via an Airflow Variable, without SQL/DAG deployment, while preserving an audit trail of when exclusions were toggled.

> **Note:** This table controls exclusion at the **rule/insight-type level** (suppressing an entire rule's output), which is distinct from any client/household-level opt-out suppression that may exist elsewhere in the pipeline.

---

## 4. Table Creation & Lifecycle (source: `odm_process/odm_pre_tasks/odm_table_creation.sql`)

- `si_odm_insights_active` (`ODM_TABLE`) and `si_odm_insights_archive` (`ODM_ARCH_TABLE`) are both `CREATE TABLE IF NOT EXISTS` with identical DDL.
- `si_odm_insights_active` is **truncated** at the start of every ODM run (pre-task), then repopulated by all rule SQL files for that run.
- `odm_exclusion_insight_type` is created once and maintained incrementally (insert/update only, never truncated).
- Ownership/grants: `ALTER TABLE ... OWNER TO {{ params.IKG_TABLE_OWNER_GROUP }}`, `GRANT SELECT ... TO {{ params.IKG_TABLE_READER_GROUP }}`.

---

## 5. End-to-End Flow

1. **IKG** completes its weekly profile refresh and sets a fresh `ODM_RUN_UUID`.
2. **`odm_master_runner`** is triggered - runs `odm_data_quality_check` (duplicate-key checks on IKG profile tables) - triggers the rule DAGs.
3. **Rule DAGs execute** (independently/in parallel as scheduled/triggered):
   - `odm_client_rules` - client/household/account insights - `ds_client_insights/`
   - `odm_prospect_rules` - prospect insights - `prospect_insights/`
   - `odm_fl_rules` (via `odm_field_leader_rules`) - Field Leader insights - `field_leader_insights/`
   - `odm_market_event_rules` - market-event driven insights - `market_event_insights/`
   Each rule SQL file `INSERT`s rows into `si_odm_insights_active`, stamped with the current `run_id`.
4. **Post-task** `set_odm_exclusion.odm_exclusion_list` updates `odm_exclusion_insight_type` from `ODM_RULES_EXCLUDE_LIST` (see §3.3 logic). Downstream consumers should filter `si_odm_insights_active` to exclude any `insight_type` present in `odm_exclusion_insight_type` with `is_curr = 1`.
5. **Archival** (`odm_archival_load` / cleanup tasks) copies the run's rows from `si_odm_insights_active` into `si_odm_insights_archive` for historical retention.
6. `ikg_run_status.odm_run_status` is set to `COMPLETED`; **NLG** polls this status and, once complete, reads `si_odm_insights_active` (filtered by current `run_id` and exclusions) to generate FA-facing narratives/emails.

---

## 6. Quick Reference - Key Airflow Variables

| Variable | Resolves to | Purpose |
|---|---|---|
| `ODM_TABLE` | `core_ikg.si_odm_insights_active` | Current-run insight output table |
| `ODM_ARCH_TABLE` | `core_ikg.si_odm_insights_archive` | Historical archive of insights |
| `ODM_RUN_UUID` | UUID string | Identifies one weekly ODM run across both tables (`run_id` column) |
| `ODM_RULES_EXCLUDE_LIST` | comma-separated `insight_type` list | Drives inserts/updates into `odm_exclusion_insight_type` |
| `IKG_SCHEMA` | `core_ikg` | Schema containing all IKG/ODM tables |

---

## 7. Repository & Rule Discovery

- **Git repo:** `odm-dags` under `staat-ds-genesis/genesis-platform` - https://devcloud.ubs.net/ubs/gwma/smart-technology-and-analytics/staat-data-science/staat-ds-genesis/genesis-platform/odm-dags
- **To find which SQL file produces a given `insight_type`:** search for the rule name (e.g. `si_sbl_in_margin_call`) across `dags/odm/script/sql/ds_client_insights/`, `prospect_insights/`, or `field_leader_insights/` - file names mirror the `insight_type` (`odm_client_rules_task_names.txt`, `odm_prospect_rules_task_names.txt`, `odm_fl_rules_task_names.txt`).
- **To add a new rule:** drop a new `.sql` file in the correct category folder; it auto-registers as an Airflow task on next DAG parse (no code change).
- **To disable a rule without removing it:** add its `insight_type` to the `ODM_RULES_EXCLUDE_LIST` Airflow Variable - handled automatically via `odm_exclusion_insight_type`.

---

## 8. Rule SQL file conventions (for code generation)

- File name = `insight_type` = `si_<rule_name>.sql`, lower-case snake_case, placed in the category folder of its rule type.
- One `INSERT INTO {{ params.ODM_TABLE }} (insight_type, target_type, target_key, metric_name, metric_type, metric_val, run_id, insight_date_time, insight_category, insight_att_name, insight_att_val) SELECT ... ;` per file, with the column list spelled out.
- `insight_type` literal must equal the file name stem; `target_type` one of CLIENT / HOUSEHOLD / ACCOUNT / PROSPECT / FA / FL; `run_id = '{{ params.ODM_RUN_UUID }}'`; `insight_date_time` from `{{ params.ODM_PROFILE_DATE }}` (or the profile date of the source row); `insight_category` = the business category (folder-level grouping).
- Sources are the IKG profile tables (`{{ params.IKG_SCHEMA }}.<table>_profile_curr_ikg`) and other IKG tables in `IKG_SCHEMA`; never hard-code the schema.
- The WHERE clause is the business rule; metric columns carry the evidence (`metric_name` = which measure, `metric_val` = its value cast to text).
- Use the exclusion mechanism (not code deletion) to retire a rule.
