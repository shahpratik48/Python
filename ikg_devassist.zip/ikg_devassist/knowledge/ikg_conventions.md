# IKG code conventions (ikg-dags repository)

## Layout
- `dags/ikg/dags/*.py` - Airflow DAGs. The weekly pipeline is `ikg_data_refresh.py`: one `TaskGroup` per SQL folder,
  one `PostgresOperator(task_id='<file stem>', sql='<folder>/<file>.sql', postgres_conn_id=postgres_conn_id, params=props)`
  per SQL file, registered in the group's `task_map` and `all_task_map`. Task dependencies are NOT written by hand:
  `props['task_dependency']` (Airflow variable `IKG_TASK_DEP_DICT`, rebuilt by `ikg_task_dependency_refresh.py` from the
  SQL sources/targets) wires upstream tasks, so a new SQL file only needs its operator line + task_map entry.
- `dags/ikg/scripts/sql/<folder>/<table>.sql` - one SQL file = one output table, file name = table name.
  Folders group a subject (ikg_cash_distribution, ikg_base_feature, ikg_housekeeping_checklist, ...). A new subject gets a
  new folder + a new TaskGroup; a new column for an existing subject goes into that subject's folder.
- `dags/ikg/scripts/sql/ikg_create_profiles/<entity>_profile_curr_ikg.sql` - the profile tables (one per entity grain:
  household, client, account, fl_fa, prospect, ...). Columns are SELECTed from intermediate `*_ikg` tables joined on the
  entity key; the script declares the column list (CREATE TABLE ... (col type, ...)) then INSERTs / CREATE AS.
- `dags/ikg/scripts/sql/ikg_create_profiles_history/<entity>_profile_ikg.sql` - weekly history of each profile table
  (INSERT INTO <entity>_profile_ikg SELECT ... FROM <entity>_profile_curr_ikg). Every new profile table needs one.
- `dags/ikg/scripts/python/...` - Python helpers (ingestion, props, validation). `props.get_airflow_variables()` exposes
  the Airflow variables: EDW_INPUT_SCHEMA, IKG_SCHEMA (sandbox_ikg_pre_prd in UAT / core_ikg in PROD), IKG_PROFILE_DATE,
  IKG_PREV_PROFILE_DATE, IKG_TABLE_OWNER_GROUP, IKG_TABLE_READER_GROUP, IKG_INGESTION_SCHEMA, IKG_VENDOR_SCHEMA, ...
- `dags/ikg/scripts/R/` - legacy; no new R code.

## SQL file pattern (intermediate table)
```sql
DROP TABLE IF EXISTS {{params.IKG_SCHEMA}}.<table>_ikg;

CREATE TABLE {{params.IKG_SCHEMA}}.<table>_ikg AS
SELECT
    <key columns>,
    <measures>,
    <key> AS ikg_key,
    {{params.IKG_PROFILE_DATE}}::text AS profile_date
FROM {{params.IKG_SCHEMA}}.<source_ikg_table> s
...
WHERE profile_date = '{{params.IKG_PROFILE_DATE}}'
DISTRIBUTED BY (<key>);

ALTER TABLE {{params.IKG_SCHEMA}}.<table>_ikg OWNER TO {{params.IKG_TABLE_OWNER_GROUP}};
GRANT SELECT ON {{params.IKG_SCHEMA}}.<table>_ikg TO {{params.IKG_TABLE_READER_GROUP}};
```
- EDW/ADW source tables: `{{params.EDW_INPUT_SCHEMA}}.<table>` (never the literal schema core_wma_shared).
- Base ids: `master_ids_ikg` / `master_ids_curr_ikg` (account -> client -> household keys), `statement_plus_ids`,
  `intl_household_plus_ids` (acc_mhh_n = household_plus). Entity keys: acc_mhh_n (statement household), ip_cli_i
  (client), acc_i / acc_n (account), fa_i (advisor). Household aggregates are built from account-level `*_acc_*` tables.
- NEVER read a `*_profile_curr_ikg` / `*_profile_ikg` table inside an IKG script. If a story needs a column that only a
  profile table has, trace that column to its producing intermediate table (lineage) and read that table, or build the
  column in a new intermediate table from the original sources.
- Column naming: `<grain prefix>_<measure>_<window>`: `mhh_` household, `acc_` account, `cli_`/`ip_` client, `fa_`
  advisor; flags `has_`/`is_` (1/0), counts `_cnt`, amounts `_a` / `_val`, dates `_d`, windows `_4w`, `_ytd`, `_boy`,
  `_prev_year`, lags `_lag4w`. Keep abbreviations from the glossary.
- Every table ends with the OWNER / GRANT pair. DISTRIBUTED BY the key used in downstream joins.

## Rule of thumb: logic in intermediate tables, profile scripts simple
All derivation (joins across sources, aggregation, CASE, windows) is done in `<subject>/<table>_ikg.sql` at the
profile's grain. The profile script only LEFT JOINs that table on the entity key and lists the column. A script
given in the story is ported into the intermediate table file, not into the profile script.

## Adding a column to a profile table (typical story)
1. Build (or extend) the intermediate table in the subject folder (`<subject>/<table>_ikg.sql`).
2. Add the column to the profile script in `ikg_create_profiles/<entity>_profile_curr_ikg.sql` (column DDL + select
   expression, LEFT JOIN the intermediate table on the entity key; COALESCE for flags/counts).
3. Add the column to the history script in `ikg_create_profiles_history/<entity>_profile_ikg.sql`.
4. Register any new SQL file as a task in `ikg_data_refresh.py` (operator + task_map). No dependency edits.
5. If the column is needed at another grain (household vs account), aggregate in a `*_mhh_agg_ikg` style table.

## New profile table
- `ikg_create_profiles/<entity>_profile_curr_ikg.sql` + `ikg_create_profiles_history/<entity>_profile_ikg.sql` + tasks
  in both task groups; include `ikg_key`, `profile_date`, the entity keys; DISTRIBUTED BY the entity key.

## Validation checklist for every change
- performance: filter by profile_date early, aggregate before joining, distribute on the join key, no cross joins;
- impact: list every script reading a changed table (consumers) and every DAG task touched;
- review queries: row counts vs previous profile date, null share of the new column, key uniqueness at the grain.
