/* Story Autopilot - app onboarding page */
(() => {
  const $ = s => document.querySelector(s), $$ = s => Array.from(document.querySelectorAll(s));
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const xsrf = () => { const m = document.cookie.match(/(?:^|;\s*)_xsrf=([^;]+)/); return m ? decodeURIComponent(m[1]) : ""; };
  async function api(url, opt = {}) {
    const method = opt.method || "GET";
    if (!(opt.body instanceof FormData)) opt.headers = Object.assign({ "Content-Type": "application/json" }, opt.headers || {});
    if (method !== "GET") { const t = xsrf(); if (t) { opt.headers = Object.assign({}, opt.headers || {}, { "X-XSRFToken": t }); url += (url.includes("?") ? "&" : "?") + "_xsrf=" + encodeURIComponent(t); } }
    const r = await fetch("../" + url, opt);
    const b = (r.headers.get("content-type") || "").includes("json") ? await r.json() : await r.text();
    if (!r.ok) throw new Error((b && b.detail) || r.statusText);
    return b;
  }
  function toast(msg, err) { const d = document.createElement("div"); d.className = "toast" + (err ? " err" : ""); d.textContent = msg; document.body.appendChild(d); setTimeout(() => d.remove(), 4200); }
  const S = { apps: [], sel: null, defaults: {} };
  const F = () => $("#f");
  function fill(a) {
    S.sel = a ? a.app_id : null;
    const f = F();
    for (const k of ["app_id", "name", "label", "repo_url", "base_branch", "target_branch", "branch_template", "commit_template"]) f.elements[k].value = (a && a[k]) || "";
    f.elements.enabled.value = a && a.enabled === false ? "false" : "true";
    f.elements.app_id.readOnly = !!a;
    $("#formTitle").textContent = a ? `App ${a.name}` : "New app";
    $("#btnDel").style.display = a ? "" : "none";
    $("#bt").placeholder = S.defaults.branch_template || ""; $("#ct").placeholder = S.defaults.commit_template || "";
    if (a) $("#packSel").value = a.pack;
    $("#checks").style.display = "none";
    example();
    renderList();
  }
  function example() {
    const f = F(), id = (f.elements.app_id.value || "app").toLowerCase();
    $("#exBranch").textContent = (f.elements.branch_template.value || S.defaults.branch_template || "{story_id}-{app}-{feature}-ai").replace("{story_id}", "2467").replace("{app}", id).replace("{feature}", "credit-card-interests");
    $("#exCommit").textContent = (f.elements.commit_template.value || S.defaults.commit_template || "{story_id}-{app}-ai").replace("{story_id}", "2467").replace("{app}", id);
  }
  function renderList() {
    $("#apps").innerHTML = S.apps.map(a => `<div class="a ${S.sel === a.app_id ? "on" : ""}" data-id="${esc(a.app_id)}">
      <div style="display:flex;gap:8px;align-items:center"><span class="chip app">${esc(a.name)}</span><b>${esc(a.app_id)}</b><span style="flex:1"></span><span class="chip ${a.enabled ? "ok" : "bad"}">${a.enabled ? "enabled" : "off"}</span></div>
      <div class="muted" style="margin-top:4px">label <code>${esc(a.label)}</code> · ${esc(a.base_branch)} → ${esc(a.target_branch)} · ${esc(a.pack)}</div></div>`).join("") || '<div class="empty">no app yet</div>';
    $$("#apps .a").forEach(x => x.onclick = () => fill(S.apps.find(a => a.app_id === x.dataset.id)));
  }
  async function load() {
    const r = await api("api/apps?refresh=1");
    S.apps = r.apps; S.defaults = r.defaults || {};
    $("#src").innerHTML = `<span class="pill"><span class="dot ${r.source === "config" ? "warn" : "ok"}"></span>${r.source === "config" ? "config file fallback - onboarding table not readable" : "table " + esc(r.table)}</span>${r.error ? `<span class="pill" title="${esc(r.error)}">${esc(r.error.slice(0, 80))}</span>` : ""}`;
    const p = await api("api/packs");
    $("#packSel").innerHTML = p.packs.map(x => `<option value="${esc(x.name)}">${esc(x.name)} (${x.mb} MB, ${esc(x.modified)})</option>`).join("") + '<option value="">- other name (type in the app id) -</option>';
    renderList();
    fill(S.sel ? S.apps.find(a => a.app_id === S.sel) : S.apps[0]);
  }
  function row() {
    const f = F(), o = {};
    for (const k of ["app_id", "name", "label", "repo_url", "base_branch", "target_branch", "branch_template", "commit_template"]) o[k] = f.elements[k].value.trim();
    o.enabled = f.elements.enabled.value === "true";
    o.pack = $("#packSel").value || `${o.app_id}_pack.zip`;
    return o;
  }
  $("#btnNew").onclick = () => fill(null);
  $("#btnSave").onclick = async () => { try { const r = await api("api/apps", { method: "POST", body: JSON.stringify(row()) }); S.sel = r.app.app_id; toast(`${r.app.name} saved`); load(); } catch (e) { toast(e.message, true); } };
  $("#btnDel").onclick = async () => { if (!S.sel || !confirm(`Remove ${S.sel}? Stories with its label are no longer picked up.`)) return; try { await api(`api/apps/${S.sel}`, { method: "DELETE" }); S.sel = null; toast("removed"); load(); } catch (e) { toast(e.message, true); } };
  $("#btnTest").onclick = async () => {
    $("#checks").style.display = ""; $("#checks").innerHTML = "testing ...";
    try { const r = await api("api/apps/test", { method: "POST", body: JSON.stringify(row()) });
      $("#checks").innerHTML = "<h4>Test connection</h4>" + r.checks.map(c => `<div class="c"><span class="dot ${c.ok ? "ok" : "bad"}" style="margin-top:5px"></span><b style="width:150px">${esc(c.check)}</b><span class="muted">${esc(c.detail)}</span></div>`).join("");
    } catch (e) { $("#checks").textContent = e.message; }
  };
  $("#packFile").onchange = async e => {
    const f = e.target.files[0]; if (!f) return;
    const fd = new FormData(); fd.append("file", f, f.name);
    toast(`uploading ${f.name} ...`);
    try { const r = await api("api/packs/upload", { method: "POST", body: fd }); toast(`${r.saved} saved (${r.mb} MB)`); await load(); $("#packSel").value = r.saved; } catch (err) { toast(err.message, true); }
  };
  F().addEventListener("input", example);
  load().catch(e => { if (/signed in/.test(e.message)) location.href = "../"; else toast(e.message, true); });
})();
