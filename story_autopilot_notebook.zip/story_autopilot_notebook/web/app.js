/* Story Autopilot - control center */
(() => {
  const $ = s => document.querySelector(s), $$ = s => Array.from(document.querySelectorAll(s));
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const xsrf = () => { const m = document.cookie.match(/(?:^|;\s*)_xsrf=([^;]+)/); return m ? decodeURIComponent(m[1]) : ""; };
  async function api(url, opt = {}) {
    const method = opt.method || "GET";
    opt.headers = Object.assign({ "Content-Type": "application/json" }, opt.headers || {});
    if (method !== "GET") { const t = xsrf(); if (t) { opt.headers["X-XSRFToken"] = t; url += (url.includes("?") ? "&" : "?") + "_xsrf=" + encodeURIComponent(t); } }
    const r = await fetch(url, opt);
    const ct = r.headers.get("content-type") || "";
    const body = ct.includes("json") ? await r.json() : await r.text();
    if (!r.ok) throw new Error((body && body.detail) || r.statusText);
    return body;
  }
  const post = (u, b) => api(u, { method: "POST", body: JSON.stringify(b || {}) });
  function toast(msg, err) { const d = document.createElement("div"); d.className = "toast" + (err ? " err" : ""); d.textContent = msg; document.body.appendChild(d); setTimeout(() => d.remove(), 4200); }
  const ago = t => { if (!t) return "never"; const s = Math.max(0, Date.now() / 1000 - t); return s < 60 ? `${Math.round(s)}s ago` : s < 3600 ? `${Math.round(s / 60)} min ago` : `${(s / 3600).toFixed(1)} h ago`; };
  const inS = t => { if (!t) return "-"; const s = t - Date.now() / 1000; return s <= 0 ? "now" : s < 60 ? `in ${Math.round(s)}s` : `in ${Math.round(s / 60)} min`; };
  // every run time in seconds AND minutes
  const dur = x => x == null || isNaN(x) ? "-" : `${Math.round(x)}s (${(x / 60).toFixed(1)} min)`;
  const usd = x => "$" + Number(x || 0).toFixed(x && x < 1 ? 3 : 2);
  const dl = (what, label, extra) => `<a class="dl" href="api/stories/${S.sel}/download/${what}${extra || ""}" download title="download">⬇ ${esc(label)}</a>`;
  const S = { status: null, tree: null, sel: null, tab: "overview", detail: null, file: null, filter: "", open: {}, me: {} };

  // ------------------------------------------------------------------ status bar
  function renderStatus(s) {
    S.status = s;
    $("#brand").classList.toggle("on", !!s.running && !s.paused);
    const w = s.watch || {};
    const wdot = !s.running ? "bad" : w.last_error ? "warn" : "ok";
    const kdot = s.current ? "run" : s.blocked ? "warn" : "ok";
    const pct = s.usd_per_day ? Math.min(100, 100 * s.cost_today / s.usd_per_day) : 0;
    $("#pills").innerHTML = `
      <span class="pill" title="${esc(w.last_error || "")}"><span class="dot ${wdot}"></span>Watcher ${s.running ? "on" : "off"} · polled ${ago(w.last_poll)} · next ${inS(w.next_poll)}</span>
      <span class="pill"><span class="dot ${kdot}"></span>Worker: ${esc(s.current ? "#" + s.current.iid + " " + (s.current.kind === "mr_fix" ? "/ai-fix" : "story") : (s.blocked || s.worker))}</span>
      <span class="pill" title="model spend today / daily limit">$${(s.cost_today || 0).toFixed(2)} / $${s.usd_per_day} <span class="meter"><i style="width:${pct}%"></i></span></span>
      <span class="pill" title="iteration read by the watcher">${esc(w.iteration || s.iteration)}</span>
      ${s.dry_run ? '<span class="pill"><span class="dot warn"></span>DRY RUN</span>' : ""}
`;
    $("#appsLine").innerHTML = `apps: ${(s.apps || []).filter(a => a.enabled).map(a => `<span class="chip app">${esc(a.name)}</span>`).join(" ") || "none"}${s.apps_source === "config" ? ' <span class="chip warn" title="' + esc(s.apps_error || "") + '">config fallback</span>' : ""}`;
    $("#swEnabled").checked = !!s.enabled; $("#swPaused").checked = !!s.paused; $("#swDry").checked = !!s.dry_run;
    $("#btnStart").textContent = s.running ? "Stop" : "Start";
    $("#btnStart").className = "sm " + (s.running ? "danger" : "primary");
    if (!$("#board").value) $("#board").value = s.board || "";
    renderNow(s);
  }
  function renderNow(s) {
    const c = s.current;
    $("#nowDot").className = "dot " + (c ? "run" : s.running ? "ok" : "bad");
    if (!c) {
      const last = s.last;
      $("#now").innerHTML = `<div class="idle"><div class="big">◎</div>${s.running ? (s.blocked ? esc(s.blocked) : "Waiting for a ready story") : "Stopped - press Start"}</div>` +
        (last ? `<div class="lastrun"><div class="muted">Last run: <a href="#" data-open="${esc(last.iid)}">#${esc(last.iid)}</a> ${last.kind === "mr_fix" ? "/ai-fix" : "story"} · <span class="chip ${last.state === "done" ? "ok" : "bad"}">${esc(last.state)}</span></div>${pipeHtml(last.pipeline)}</div>` : "");
      $("#nowTime").textContent = "";
      $$("#now [data-open]").forEach(a => a.onclick = e => { e.preventDefault(); select(a.dataset.open); });
      return;
    }
    const pct = c.pct || 0;
    $("#nowTime").textContent = c.started ? dur(Date.now() / 1000 - c.started) : "";
    const log = (c.log || []).map(l => `<span class="ts">${esc(l.at)}</span> ${esc(l.msg)}`).join("\n");
    const live = $("#now .live"); const stick = live && live.scrollTop + live.clientHeight >= live.scrollHeight - 10;
    $("#now").innerHTML = `<div class="story"><a href="#" data-open="${esc(c.iid)}">#${esc(c.iid)}</a> ${esc(c.title || "")}</div>
      <div class="sub">${c.kind === "mr_fix" ? "MR review fix" : "story run"} · ${(c.apps || []).map(a => `<span class="chip app">${esc(a.toUpperCase())}</span>`).join(" ")} · ${esc(c.stage || "")}</div>
      <div class="bar"><i style="width:${pct}%"></i></div>
      ${pipeHtml(c.pipeline)}
      <div class="live">${log || "starting ..."}</div>`;
    const nl = $("#now .live"); if (nl && (stick || !live)) nl.scrollTop = nl.scrollHeight;
    $$("#now [data-open]").forEach(a => a.onclick = e => { e.preventDefault(); select(a.dataset.open); });
  }

  // the agents of the job, one icon each, lit up as they run (state from the server: pending | running | done | skipped | failed)
  function pipeHtml(steps) {
    if (!steps || !steps.length) return "";
    const t = x => x == null ? "" : `${Math.round(x)}s<br>${(x / 60).toFixed(1)} min`;
    const word = { pending: "waiting", running: "running", done: "done", skipped: "skipped", failed: "failed" };
    return `<div class="pipe" style="--n:${steps.length}">${steps.map(p => `
      <div class="pn ${esc(p.state)}" title="${esc(p.label)} - ${esc(p.who)} - ${word[p.state] || p.state}${p.seconds != null ? " - " + dur(p.seconds) : ""}${p.note ? " - " + esc(p.note) : ""}">
        <div class="ic">${p.icon}</div><div class="nm">${esc(p.label)}</div><div class="tm">${(p.state === "running" || p.state === "done") ? t(p.seconds) : p.state === "skipped" ? "skipped" : p.state === "failed" ? "failed" : ""}</div>
      </div>`).join("")}</div>`;
  }

  // ------------------------------------------------------------------ audit log (who did what in the control center)
  async function openAudit() {
    let m = $("#auditModal");
    if (!m) {
      m = document.createElement("div"); m.id = "auditModal"; m.className = "modal";
      m.innerHTML = `<div class="mcard"><div class="mh"><b>Control center audit log</b><span class="muted" id="auditFile"></span><span style="flex:1"></span>
          <input id="auditQ" placeholder="filter: user, action, story ..." style="width:260px"><a id="auditCsv" href="api/audit.csv" download><button class="sm">Download CSV</button></a><button class="sm" id="auditClose">✕</button></div>
        <div class="mb" id="auditBody">loading ...</div></div>`;
      document.body.appendChild(m);
      m.onclick = e => { if (e.target === m) m.remove(); };
      $("#auditClose").onclick = () => m.remove();
      let tm = null;
      $("#auditQ").oninput = e => { clearTimeout(tm); tm = setTimeout(() => loadAudit(e.target.value), 250); };
    }
    loadAudit("");
  }
  async function loadAudit(q) {
    try {
      const r = await api("api/audit?limit=500" + (q ? "&q=" + encodeURIComponent(q) : ""));
      $("#auditFile").textContent = " · also written to " + r.file;
      $("#auditCsv").href = "api/audit.csv" + (q ? "?q=" + encodeURIComponent(q) : "");
      $("#auditBody").innerHTML = r.audit.length ? `<table class="t"><tr><th>when</th><th>who</th><th>from</th><th>action</th><th>on</th><th>details</th><th>result</th></tr>${r.audit.map(a => `
        <tr><td class="mono" style="white-space:nowrap">${esc(a.ts)}</td><td><b>${esc(a.user_name || a.user_id)}</b><div class="muted">${esc(a.user_id)}</div></td>
        <td>${esc(a.source)}<div class="muted mono">${esc(a.ip)}</div></td><td>${esc(a.action)}</td><td>${esc(a.target)}</td><td>${esc(a.detail)}</td>
        <td><span class="chip ${a.outcome === "ok" ? "ok" : "bad"}">${esc(a.outcome)}</span></td></tr>`).join("")}</table>` : '<div class="empty">nothing logged yet</div>';
    } catch (e) { $("#auditBody").textContent = e.message; }
  }

  // ------------------------------------------------------------------ tree
  function stateChip(st) {
    const d = st.decision || {};
    if (st.current) return '<span class="chip run">running</span>';
    if (st.queue === "queued") return '<span class="chip warn">queued</span>';
    const L = (st.labels || []).map(x => x.toLowerCase());
    if (L.includes("ai_failed")) return '<span class="chip bad">failed</span>';
    if (L.includes("ai_blocked") || d.block) return '<span class="chip bad">blocked</span>';
    if (L.includes("agent_re_code_done")) return '<span class="chip ok">re-coded</span>';
    if (L.includes("agent_code_done")) return '<span class="chip ok">coded</span>';
    if (d.pick) return '<span class="chip warn">ready</span>';
    return "";
  }
  function storyRow(st) {
    return `<div class="st ${S.sel === st.iid ? "sel" : ""}" data-iid="${esc(st.iid)}" title="${esc((st.decision || {}).reason || "")}">
      <div class="n">#${esc(st.iid)}</div>
      <div class="t"><div>${esc(st.title)}</div>
        <div class="chips">${(st.apps || []).map(a => `<span class="chip app">${esc(a.toUpperCase())}</span>`).join("")}${stateChip(st)}${st.status ? `<span class="chip">${esc(String(st.status).replace(/^status::/i, ""))}</span>` : ""}</div></div></div>`;
  }
  function renderTree() {
    const t = S.tree;
    if (!t) return;
    if (t.error) { $("#tree").innerHTML = `<div class="empty">${esc(t.error)}</div>`; return; }
    const f = S.filter.toLowerCase();
    const match = st => !f || `#${st.iid} ${st.title} ${(st.labels || []).join(" ")} ${st.assignee || ""}`.toLowerCase().includes(f);
    const its = t.iterations || [];
    if (!its.length) { $("#tree").innerHTML = '<div class="empty">no iteration found on this board</div>'; return; }
    $("#tree").innerHTML = its.map((it, i) => {
      const rows = (it.stories || []).filter(match);
      const open = S.open[it.id] != null ? S.open[it.id] : (f ? rows.length > 0 : false);
      return `<div class="folder ${open ? "open" : ""}" data-it="${esc(it.id)}">
        <div class="fh"><span class="chev">▶</span>📁 ${esc(it.label)} ${it.state === "current" ? '<span class="tag">CURRENT</span>' : ""}<span class="cnt">${it.loaded || it.stories.length ? rows.length : ""}</span></div>
        <div class="items">${rows.map(storyRow).join("") || `<div class="muted" style="padding:6px 10px">${it.loaded || it.stories.length ? "no story matches" : "expand to load"}</div>`}</div></div>`;
    }).join("");
    $$("#tree .fh").forEach(h => h.onclick = async () => {
      const fo = h.parentElement, id = fo.dataset.it;
      const it = (S.tree.iterations || []).find(x => String(x.id) === id);
      S.open[id] = !fo.classList.contains("open");
      if (S.open[id] && it && !it.loaded && !(it.stories || []).length) {
        try { it.stories = (await api(`api/iterations/${id}/stories`)).stories; it.loaded = true; } catch (e) { toast(e.message, true); }
      }
      renderTree();
    });
    $$("#tree .st").forEach(r => r.onclick = () => select(r.dataset.iid));
  }
  async function loadTree(refresh) {
    try { S.tree = await api("api/tree" + (refresh ? "?refresh=1" : "")); } catch (e) { S.tree = { error: e.message }; }
    const cur = (S.tree.iterations || []).find(i => i.state === "current");
    if (cur && S.open[cur.id] == null) S.open[cur.id] = true;
    renderTree();
  }

  // ------------------------------------------------------------------ queue
  function renderQueue(q) {
    const items = q.queue || [];
    const hist = q.history || [];
    $("#queue").innerHTML = (items.length ? items.map((j, i) => `
      <div class="qi ${j.state}" draggable="${j.state === "queued"}" data-id="${j.id}">
        <span class="grip">${j.state === "queued" ? "⠿" : "▶"}</span><span class="pos">${j.state === "running" ? "" : i + (items[0].state === "running" ? 0 : 1)}</span>
        <div class="t"><div><a href="#" data-open="${esc(j.iid)}">#${esc(j.iid)}</a> ${esc(j.title || "")}</div>
          <div class="chips">${(j.apps || []).map(a => `<span class="chip app">${esc(a.toUpperCase())}</span>`).join("")}<span class="chip ${j.kind === "mr_fix" ? "warn" : ""}">${j.kind === "mr_fix" ? "/ai-fix" : ((j.payload || {}).kind || "story")}</span>${j.state === "running" ? '<span class="chip run">running</span>' : ""}</div></div>
        ${j.state === "queued" ? `<div class="acts"><button class="sm ghost" data-mv="top" title="to the top">⤒</button><button class="sm ghost" data-mv="up">↑</button><button class="sm ghost" data-mv="down">↓</button><button class="sm ghost" data-mv="cancel" title="remove from the queue">✕</button></div>` : ""}
      </div>`).join("") : '<div class="empty">The queue is empty.</div>') +
      (hist.length ? `<div class="hist"><div class="h">Recently finished</div>${hist.slice(0, 12).map(h => `<div class="r"><span class="when">${new Date((h.finished_at || 0) * 1000).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false })}</span>
        <span class="chip ${h.state === "done" ? "ok" : h.state === "failed" ? "bad" : "warn"}">${esc(h.state)}</span><a href="#" data-open="${esc(h.iid)}">#${esc(h.iid)}</a><span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(h.title || "")}</span>
        <span class="muted mono" title="run time">${h.started_at && h.finished_at ? dur(h.finished_at - h.started_at) : ""}</span>
        <span class="muted">${(h.result || {}).draft ? "Draft MR" : esc(((h.result || {}).reason || "").slice(0, 60))}</span></div>`).join("")}</div>` : "") +
      `<div style="margin-top:10px"><a class="dl" href="api/queue.csv" download>⬇ queue + run history (CSV)</a></div>`;
    $$("#queue [data-open]").forEach(a => a.onclick = e => { e.preventDefault(); select(a.dataset.open); });
    $$("#queue [data-mv]").forEach(b => b.onclick = async () => {
      const id = b.closest(".qi").dataset.id;
      try { renderQueue(Object.assign(q, await post(`api/queue/${id}/${b.dataset.mv}`))); } catch (e) { toast(e.message, true); }
    });
    let dragId = null;
    $$("#queue .qi[draggable=true]").forEach(el => {
      el.ondragstart = () => { dragId = el.dataset.id; el.classList.add("drag"); };
      el.ondragend = () => el.classList.remove("drag");
      el.ondragover = e => { e.preventDefault(); el.classList.add("over"); };
      el.ondragleave = () => el.classList.remove("over");
      el.ondrop = async e => {
        e.preventDefault(); el.classList.remove("over");
        const ids = $$("#queue .qi[draggable=true]").map(x => x.dataset.id).filter(x => x !== dragId);
        ids.splice(ids.indexOf(el.dataset.id), 0, dragId);
        try { renderQueue(Object.assign(q, await post("api/queue/reorder", { ids: ids.map(Number) }))); toast("queue reordered"); } catch (err) { toast(err.message, true); }
      };
    });
  }
  let lastDone = null;
  async function loadQueue() {
    try {
      const q = await api("api/queue"); renderQueue(q);
      const top = (q.history || [])[0]; const k = top ? top.id + ":" + top.state : "";
      if (lastDone !== null && k !== lastDone) { loadTree(false); if (S.sel) loadDetail(); }
      lastDone = k;
    } catch (e) { /* signed out */ }
  }

  // ------------------------------------------------------------------ story detail
  async function select(iid) {
    S.sel = String(iid); S.file = null;
    renderTree();
    await loadDetail();
  }
  async function loadDetail() {
    if (!S.sel) return;
    try { S.detail = await api(`api/stories/${S.sel}`); } catch (e) { $("#detail").innerHTML = `<div class="empty">${esc(e.message)}</div>`; return; }
    renderDetail();
  }
  const TABS = [["overview", "Overview"], ["context", "Context pack"], ["plan", "Plan"], ["files", "Files"], ["review", "Review"], ["log", "Log"], ["tokens", "Tokens"], ["outputs", "Outputs"]];
  function renderDetail() {
    const d = S.detail || {}, st = d.story || {}, se = d.session || {};
    const dec = st.decision || {};
    const nf = (se.files || []).length, nr = ((se.review || {}).findings || []).length;
    const badge = { files: nf, review: nr };
    $("#detail").innerHTML = `
      <div class="dh"><div style="flex:1;min-width:0">
          <div class="ttl"><a href="${esc(st.web_url || "#")}" target="_blank">#${esc(st.iid)}</a> ${esc(st.title || "")}</div>
          <div class="chips" style="margin-top:4px">${(st.apps || []).map(a => `<span class="chip app">${esc(String(a).toUpperCase())}</span>`).join("")}${(st.labels || []).map(l => `<span class="chip">${esc(l)}</span>`).join("")}</div>
          <div class="why">${esc(dec.reason || "")}${st.assignee ? " · assignee " + esc(st.assignee) : ""} · spent $${(d.cost_usd || 0).toFixed(2)}</div></div>
        <div style="display:flex;gap:6px">${se && Object.keys(se).length ? `<a href="api/stories/${S.sel}/download/all" download><button class="sm primary" title="every generated file + log, plan, review, findings, tokens, context pack, impact, agent outputs, runs and activity">⬇ Download all</button></a>` : ""}<button class="sm" id="btnRun" title="queue it now (the pick-up rules still apply)">Run now</button><button class="sm" id="btnRefresh">Refresh</button></div></div>
      <div class="tabs">${TABS.map(([k, n]) => `<div class="tab ${S.tab === k ? "on" : ""}" data-t="${k}">${n}${badge[k] ? `<span class="b">${badge[k]}</span>` : ""}</div>`).join("")}</div>
      <div class="pb" id="tabBody"></div>`;
    $$("#detail .tab").forEach(t => t.onclick = () => { S.tab = t.dataset.t; renderDetail(); });
    $("#btnRefresh").onclick = loadDetail;
    $("#btnRun").onclick = async () => { try { await post(`api/stories/${S.sel}/enqueue`); toast("queued"); loadQueue(); } catch (e) { toast(e.message, true); } };
    const body = $("#tabBody");
    const fn = { overview, context, plan, files, review, log, tokens, outputs }[S.tab];
    fn(body, d, se);
  }
  function overview(el, d, se) {
    const st = d.story || {}, dec = st.decision || {};
    const br = d.branches || [];
    el.innerHTML = `<div class="box"><h4>Pick-up decision</h4><div class="kv">
        <div>Decision</div><div>${dec.pick ? '<span class="chip ok">picked up</span>' : dec.block ? '<span class="chip bad">blocked</span>' : '<span class="chip">not picked</span>'} ${esc(dec.reason || "")}</div>
        <div>Kind</div><div>${esc(dec.kind || "-")}</div><div>Previous status</div><div>${esc(dec.previous_status || "-")}</div>
        <div>Status</div><div>${esc(st.status || "")}</div><div>Iteration</div><div>${esc(st.iteration || "")}</div><div>Assignee</div><div>${esc(st.assignee || "-")}</div></div></div>
      <div class="box"><h4>Branches and merge requests</h4>${br.length ? `<table class="t"><tr><th>app</th><th>branch</th><th>base → target</th><th>MR</th></tr>${br.map(b => `<tr><td>${esc(String(b.app).toUpperCase())}</td><td><code>${esc(b.branch)}</code></td><td>${esc(b.base)} → ${esc(b.target)}</td><td>${b.mr_url ? `<a href="${esc(b.mr_url)}" target="_blank">!${esc(b.mr_iid)}</a>${b.draft ? ' <span class="chip warn">Draft</span>' : ""}` : "-"}</td></tr>`).join("")}</table>` : '<span class="muted">none yet</span>'}</div>
      <div class="box"><h4>Runs</h4>${(d.jobs || []).length ? `<table class="t"><tr><th>job</th><th>kind</th><th>state</th><th>finished</th><th>run time</th><th>result</th></tr>${d.jobs.map(j => `<tr><td>${j.id}</td><td>${esc(j.kind === "mr_fix" ? "/ai-fix" : (j.payload || {}).kind || "story")}</td><td>${esc(j.state)}</td><td>${j.finished_at ? new Date(j.finished_at * 1000).toLocaleString() : "-"}</td><td class="mono">${j.started_at && j.finished_at ? dur(j.finished_at - j.started_at) : "-"}</td><td>${esc(JSON.stringify(j.result || {}).slice(0, 220))}</td></tr>`).join("")}</table>` : '<span class="muted">not run yet</span>'}</div>
      <div class="box"><h4>Activity</h4>${(d.events || []).slice(0, 40).map(e => `<div><span class="muted mono">${new Date(e.at * 1000).toLocaleString()}</span> <span class="chip">${esc(e.kind)}</span> ${esc(e.title)} <span class="muted">${esc((e.detail || "").slice(0, 200))}</span></div>`).join("") || '<span class="muted">nothing yet</span>'}</div>`;
  }
  function needSession(el, se) { if (!se || !Object.keys(se).length) { el.innerHTML = '<div class="empty">The agents have not run on this story yet.</div>'; return false; } return true; }
  function context(el, d, se) {
    if (!needSession(el, se)) return;
    const i = se.inputs || {};
    el.innerHTML = `<div class="dlbar">${dl("context", "context pack (JSON)")}${dl("knowledge", "knowledge agent")}${dl("data", "data agent")}${dl("repo", "repository agent")}${dl("story", "story agent")}</div>
      <div class="box"><h4>Story</h4>${i.story ? `<b>${esc(i.story.id)}</b> ${esc(i.story.title)} <span class="muted">(${i.story.chars} chars)</span>` : "-"}</div>
      <div class="box"><h4>Knowledge packs</h4>${(i.packs || []).map(p => `<div><span class="chip app">${esc(String(p.system).toUpperCase())}</span> ${esc(p.version)} · ${(p.counts || {}).items || 0} items · ${(p.counts || {}).folders || 0} folders · ${p.tables_available || 0} tables · ${p.dense_index ? "vectors" : "BM25"}</div>`).join("") || '<span class="muted">none (live clone)</span>'}</div>
      <div class="box"><h4>Repositories</h4>${(i.repos || []).map(r => `<div><code>${esc(r.name)}@${esc(r.branch)}</code> <span class="muted">${r.files} files${r.from_pack ? " · from the " + esc(r.from_pack.toUpperCase()) + " pack" : ""}</span></div>`).join("") || "-"}</div>
      <div class="box"><h4>Feature branches</h4>${(i.branches || []).map(b => `<div><code>${esc(b.feature)}</code> <span class="muted">from ${esc(b.base)} → ${esc(b.target)} · ${(b.commits || []).length} commit(s)</span></div>`).join("") || "-"}</div>`;
  }
  function plan(el, d, se) {
    if (!needSession(el, se)) return;
    const p = se.plan || {};
    if (!p.files) { el.innerHTML = '<div class="empty">no plan yet</div>'; return; }
    const imp = se.impact || {}, sm = imp.summary || {};
    const open = (imp.items || []).filter(x => x.covered === false && (x.risk === "high" || x.risk === "medium"));
    el.innerHTML = `<div class="dlbar">${dl("plan", "plan (JSON)")}${dl("impact", "impact analysis")}${dl("sources", "sources")}</div><div class="box"><h4>Approach</h4>${esc(p.approach)}</div>
      <div class="box"><h4>What changes where (${p.files.length})</h4>${p.files.map(f => `<div style="margin-bottom:8px"><span class="chip ${f.action === "modify" ? "warn" : "ok"}">${f.action === "modify" ? "MODIFY" : "CREATE"}</span> <code>${esc(f.path)}</code>
        <div class="muted">${esc(f.purpose)}</div>${f.where ? `<div><b>where:</b> ${esc(f.where)}</div>` : ""}${f.copy_from ? `<div><b>pattern from:</b> <code>${esc(f.copy_from)}</code></div>` : ""}</div>`).join("")}
        ${(p.registration_changes || []).length ? `<div><b>Registration / config:</b><ul>${p.registration_changes.map(r => `<li><code>${esc(r.path)}</code>: ${esc(r.what)}</li>`).join("")}</ul></div>` : ""}</div>
      ${(imp.scope || []).length ? `<div class="box"><h4>Impact (${esc((imp.scope || []).join(", ").toUpperCase())})</h4>${sm.upstream || 0} upstream · ${sm.downstream || 0} downstream · <b>${sm.not_covered || 0} not handled</b> · ${sm.orphans || 0} new table(s) nobody reads
        ${open.length ? `<table class="t" style="margin-top:6px"><tr><th>direction</th><th>affected</th><th>risk</th><th>why</th></tr>${open.map(x => `<tr><td>${esc(x.direction)}</td><td><code>${esc(x.affected)}</code></td><td><span class="sev ${esc(x.risk)}">${esc(x.risk)}</span></td><td>${esc(x.detail)}</td></tr>`).join("")}</table>` : ""}</div>` : ""}
      ${(p.questions || []).length ? `<div class="box"><h4>Open questions</h4><ul>${p.questions.map(q => `<li>${esc(q)}</li>`).join("")}</ul></div>` : ""}`;
  }
  async function files(el, d, se) {
    if (!needSession(el, se)) return;
    const fs = se.files || [];
    if (!fs.length) { el.innerHTML = '<div class="empty">no file generated</div>'; return; }
    S.file = S.file || fs[0].path;
    el.innerHTML = `<div class="files"><div class="flist">${fs.map(f => `<div class="f ${S.file === f.path ? "on" : ""}" data-p="${esc(f.path)}">${esc(f.path.split("/").pop())}<small>${esc(f.action)} · ${esc(f.language)} · ${f.confidence || 0}%</small></div>`).join("")}</div>
      <div><div class="dlbar" style="justify-content:space-between"><code class="muted">${esc(S.file)}</code><span>${dl("file", "this file", "?path=" + encodeURIComponent(S.file))}${dl("files_zip", `all ${fs.length} files (zip)`)}</span></div><pre class="code" id="fileBody">loading ...</pre></div></div>`;
    $$("#tabBody .f").forEach(x => x.onclick = () => { S.file = x.dataset.p; files(el, d, se); });
    try { $("#fileBody").textContent = (await api(`api/stories/${S.sel}/file?path=${encodeURIComponent(S.file)}`)).content; } catch (e) { $("#fileBody").textContent = e.message; }
  }
  function review(el, d, se) {
    if (!needSession(el, se)) return;
    const r = se.review || {}, conf = (se.summary || {}).confidence || {};
    const f = (r.findings || []).concat((se.findings || []).map(x => Object.assign({ from: "validator" }, x)));
    el.innerHTML = `<div class="dlbar">${dl("review", "review (JSON)")}${dl("findings", "validator findings")}</div><div class="box"><h4>Verdict</h4><div class="kv"><div>Review</div><div><b>${esc(r.verdict || "-")}</b> · score ${esc(r.score)}</div>
        <div>Confidence</div><div><b>${esc(conf.score)}</b> (${esc(conf.grade)}) <span class="muted">${esc(conf.explain || "")}</span></div><div>Summary</div><div>${esc(r.summary || "")}</div></div></div>
      <div class="box"><h4>Findings (${f.length})</h4>${f.length ? `<table class="t"><tr><th>sev</th><th>file</th><th>message</th><th>status</th></tr>${f.map(x => `<tr><td><span class="sev ${esc(x.severity)}">${esc(x.severity)}</span></td><td><code>${esc(x.path || "")}</code>${x.line ? ":" + x.line : ""}</td><td>${esc(x.message)}${x.suggestion ? `<div class="muted">→ ${esc(x.suggestion)}</div>` : ""}</td><td>${esc(x.status || x.from || "")}</td></tr>`).join("")}</table>` : '<span class="muted">none</span>'}</div>`;
  }
  async function log(el) {
    el.innerHTML = `<div class="dlbar">${dl("log", "run log")}${dl("events", "events (JSONL)")}</div><pre class="code logtxt" id="logBody">loading ...</pre>`;
    try { const t = await api(`api/stories/${S.sel}/log`); const lb = $("#logBody"); lb.textContent = t || "no log yet"; lb.scrollTop = lb.scrollHeight; } catch (e) { $("#logBody").textContent = e.message; }
  }
  function tokens(el, d, se) {
    if (!needSession(el, se)) return;
    const s = se.summary || {}, ag = s.tokens_by_agent || {}, md = s.tokens_by_model || {}, tot = s.tokens || {};
    const rows = o => Object.entries(o).map(([k, v]) => `<tr><td>${esc(k)}</td><td>${v.calls || 0}</td><td>${(v.input_tokens || v.prompt_tokens || 0).toLocaleString()}</td><td>${(v.cached_tokens || 0).toLocaleString()}</td><td>${(v.output_tokens || v.completion_tokens || 0).toLocaleString()}</td><td class="money">$${(v.cost_usd || 0).toFixed(4)}</td></tr>`).join("");
    const lim = (S.status || {}).usd_per_story;
    el.innerHTML = `<div class="dlbar">${dl("tokens", "tokens + cost (JSON)")}${dl("tokens_txt", "tokens + cost (text)")}</div>
      <div class="stats">
        <div class="stat"><div class="v money">${usd(s.cost_usd)}</div><div class="l">USD - this run</div></div>
        <div class="stat"><div class="v money">${usd(d.cost_usd)}</div><div class="l">USD - all runs of this story${lim ? ` (limit $${lim})` : ""}</div></div>
        <div class="stat"><div class="v">${(tot.total_tokens || 0).toLocaleString()}</div><div class="l">tokens (${(tot.cached_tokens || 0).toLocaleString()} cached)</div></div>
        <div class="stat"><div class="v small">${dur(s.duration_seconds)}</div><div class="l">run time</div></div></div>
      <div class="box"><h4>By agent</h4><table class="t"><tr><th>agent</th><th>calls</th><th>input</th><th>cached</th><th>output</th><th>cost (USD)</th></tr>${rows(ag)}</table></div>
      <div class="box"><h4>By model</h4><table class="t"><tr><th>model</th><th>calls</th><th>input</th><th>cached</th><th>output</th><th>cost (USD)</th></tr>${rows(md)}</table></div>`;
  }
  async function outputs(el, d, se) {
    const br = d.branches || [];
    const sm = (se || {}).summary || {};
    el.innerHTML = `<div class="box"><h4>Downloads</h4><div id="dlList" class="dlbar" style="flex-wrap:wrap">loading ...</div></div>
      ${sm.duration_seconds != null ? `<div class="stats"><div class="stat"><div class="v small">${dur(sm.duration_seconds)}</div><div class="l">last run time</div></div>
        <div class="stat"><div class="v money">${usd(sm.cost_usd)}</div><div class="l">USD - last run</div></div><div class="stat"><div class="v">${(sm.files || []).length}</div><div class="l">files generated</div></div>
        <div class="stat"><div class="v">${esc(((sm.confidence || {}).score) ?? "-")}</div><div class="l">confidence (${esc((sm.confidence || {}).grade || "")})</div></div></div>` : ""}
      <div class="box"><h4>Delivered</h4>${br.map(b => `<div><span class="chip app">${esc(String(b.app).toUpperCase())}</span> branch <code>${esc(b.branch)}</code> ${b.mr_url ? `· MR <a href="${esc(b.mr_url)}" target="_blank">!${esc(b.mr_iid)}</a>${b.draft ? " (Draft)" : ""}` : ""}</div>`).join("") || '<span class="muted">nothing pushed yet</span>'}</div>
      ${se && Object.keys(se).length ? `<div class="box"><h4>Run summary</h4><pre class="code">${esc(JSON.stringify(Object.fromEntries(Object.entries(se.summary || {}).filter(([k]) => !["tokens_by_agent", "tokens_by_model", "timings", "pricing"].includes(k))), null, 1))}</pre></div>` : ""}`;
    try {
      const r = await api(`api/stories/${S.sel}/downloads`);
      $("#dlList").innerHTML = r.all ? `<a href="api/stories/${S.sel}/download/all" download><button class="sm primary">⬇ Everything (zip): files, logs, plan, review, tokens, context pack, agents, runs</button></a>` +
        r.downloads.map(x => dl(x.name, x.label)).join("") : '<span class="muted">nothing to download yet - the agents have not run on this story</span>';
    } catch (e) { $("#dlList").textContent = e.message; }
  }

  // ------------------------------------------------------------------ controls
  async function control(b) { try { renderStatus(await post("api/control", b)); } catch (e) { toast(e.message, true); loadStatus(); } }
  $("#swEnabled").onchange = e => control({ enabled: e.target.checked });
  $("#swPaused").onchange = e => control({ paused: e.target.checked });
  $("#swDry").onchange = e => control({ dry_run: e.target.checked });
  $("#btnStart").onclick = () => control(S.status && S.status.running ? { stop: true } : { start: true });
  $("#btnPoll").onclick = () => { control({ poll_now: true }); toast("polling the board ..."); setTimeout(() => { loadTree(true); loadQueue(); }, 4000); };
  $("#btnBoard").onclick = async () => { await control({ board_url: $("#board").value.trim() }); S.open = {}; loadTree(true); };
  $("#search").oninput = e => { S.filter = e.target.value; renderTree(); };
  $("#btnAudit").onclick = openAudit;

  async function loadStatus() { try { renderStatus(await api("api/status")); } catch (e) { if (/signed in/.test(e.message)) location.reload(); } }
  loadStatus(); loadTree(false); loadQueue();
  setInterval(loadStatus, 3000);
  setInterval(loadQueue, 5000);
  setInterval(() => loadTree(false), 30000);
  setInterval(() => { if (S.sel && S.status && S.status.current && String(S.status.current.iid) === S.sel && ["overview", "plan", "review", "tokens"].includes(S.tab)) loadDetail(); }, 8000);
})();
