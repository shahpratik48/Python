# Story Autopilot - ready story in, merge request out

A watcher reads the GitLab story board every 2 minutes (configurable). A story that is ready goes into a queue. A single worker
runs the agents on it, one story at a time: story, knowledge, data, repo, planner, coder, validator, reviewer and fix (the same engine
as Agile Dev Assist, its own copy). It then commits on the story's branch, pushes and opens the merge request. Reviewers can ask for
changes with `/ai-fix ...` comments on the MR. **The automation never approves or merges.**

Two editions from one source tree:
- **notebook** (`Story_Autopilot.ipynb`): asks for every secret, starts the watcher and worker, and has buttons for the control center and the onboarding page;
- **web app** (`app_server.py`): a standalone service that keeps the watcher, worker and agents running, and serves the control center (`/`) and the onboarding page (`/onboarding/`).

## When a story is picked up (all configurable in `autopilot.criteria` / `autopilot.labels`)
| must hold | default |
|---|---|
| latest status is In progress | scoped label `status::In Progress`, story open |
| ready label | `ready_for_agent` (added in the scrum meeting) |
| at least one app label | `IKG`, `NLG`, `ODM` (from the onboarding table): picks that app's pack, repository and branches; IKG + ODM = two branches, two MRs |
| an assignee | exactly one (`multiple_assignees: block` or `first`) |

Not picked:
- **Already done:** the story has `agent_code_done`, `agent_re_code_done` or `ai_failed` and no `re_work_for_agent`.
- **Back from QA:** it came back to In progress from `status::QA`, `status::UAT` or closed, without `re_work_for_agent`.

A story that is ready but has no app label, or no assignee (or more than one when `multiple_assignees: block`), gets `ai_blocked` and **one** comment saying what is missing.

## What the worker writes
| result | GitLab |
|---|---|
| first run | branch `<story>-<app>-<feature>-ai` from the app's base branch; commit `<story>-<app>-ai` (author = assignee, committer = token owner); MR into the target branch, assigned to the assignee; story label `agent_code_done` + a comment with the links |
| rework (`re_work_for_agent`) | same branch, same MR (updated), new commit; `agent_re_code_done`; `re_work_for_agent` removed |
| open critical / high review finding or confidence < 70 | still pushed; MR opens as **Draft** with the findings in its description; the comment asks the assignee to look |
| pipeline error | nothing pushed; `ai_failed` + a comment with the reason |
| `/ai-fix <what>` on the MR | change agent on the story's files, commit + push to the same branch, reply in the thread, `ai_review_fix_done` (other comments are ignored) |

Missing labels are created once on the story project. The label `ai_working` is on the story while the worker is on it.

### Assignee as author ("shah pratik 49010206")
- **Commits:** the name and GPN are read from that field (`assignee_name_format`) and the assignee's GitLab e-mail is looked up. Each commit is **authored** by that person and **committed** by the automation's token owner.
- **MR:** the MR is **assigned** to the assignee, but GitLab records the token owner as its creator.
- **To have the MR created by the developer:** set `git.token_mode: per_user` (each developer's own token from the vault) or use an admin impersonation token.

## Control center (`/`)
| area | what it shows |
|---|---|
| top bar | watcher status (last poll, next poll), worker status, model spend today against the daily limit, the iteration, the switches (Enabled, Pause, Dry run), Start/Stop, Poll now |
| left | story board field, search box, iteration folders (`Nov 4 - 17, 2026`, current one first, collapsed until opened), one entry per story with its app labels and state |
| Now processing | the story being worked on, its stage and a live log |
| Pipeline | the queue (drag or use ↑ ↓ ⤒ to reorder, ✕ to remove) and the recently finished jobs |
| story detail | tabs: Overview (pick-up decision, branches/MRs, runs, activity), Context pack, Plan (what changes where, impact), Files, Review, Log, Tokens, Outputs |

## Onboarding (`/onboarding/`)
One row per app in Greenplum `sandbox_prj_smart_insights.story_autopilot_apps`:
- story label(s)
- enabled
- knowledge pack (upload a pack zip on the page)
- repository URL
- base branch and target branch
- optional branch and commit templates

**Test connection** checks the pack, both branches, the story label and the table. The first time, create the table with `python app_server.py --init-table` (it copies the `apps:` list of the config). If the table cannot be read, the config list is used and the control center says so.

## Switches and limits (`config/autopilot_config.yaml`)
| setting | what it controls |
|---|---|
| `autopilot.enabled` | global on/off |
| `dry_run` | decide and log, but write nothing to GitLab |
| `enabled` on each app's onboarding row | per-app on/off |
| `git.push`, `git.merge_request` | push / open the MR |
| `mr_fix.enabled` | act on `/ai-fix` comments |
| `limits.usd_per_day` | daily model spend; the queue pauses when it is reached |
| `limits.usd_per_story` | per-story model spend; the story is blocked when it is reached |
| `limits.max_minutes_per_story` | time budget per story |

The control center can override Enabled, Pause, Dry run, the story board and the iteration (kept in the local state database).

## Secrets (never in a file)
`AUTOPILOT_GIT_TOKEN` (api scope, for now the same token as Agile Dev Assist), `AGILEDEV_AZURE_OPENAI_API_KEY`,
`AUTOPILOT_GP_PASSWORD`, `AGILEDEV_SERVER_SECRET`.

They are read from, in order:
- the environment (Azure App Service Key Vault references land here);
- HashiCorp vault (`vault.provider: hashicorp`, with `VAULT_ADDR` and `VAULT_TOKEN`);
- the notebook's hidden prompts.

## Run
```
pip install -r requirements.txt
python app_server.py --check          # token owner, board, current iteration, apps, model key
python app_server.py --init-table     # first time: onboarding table in Greenplum
python app_server.py                  # watcher + worker + web app on port 8790 (AGILEDEV_AUTH_PROFILE=header behind SSO)
python app_server.py --demo           # fake GitLab + scripted model: look around without any secret
python app_server.py --run-selftest   # offline end-to-end test
```
Put the knowledge packs (`ikg_pack.zip`, `nlg_pack.zip`, `odm_pack.zip`) in `packs/`: point the pack builder's publish folder there, or upload them on the onboarding page.

Keep `knowledge_packs.unzip_dir` on local disk. Run **one** instance: the queue and the worker are single by design.
