"""Onboarded applications (IKG, NLG, ODM, ...): one row per app in a Greenplum table, written by the onboarding page.

    sandbox_prj_smart_insights.story_autopilot_apps   (autopilot.greenplum.schema / table)

A new app needs no code change: a row with its story label, knowledge pack, repository, base / target branch and (optional)
own branch / commit templates. The password comes from the vault (secrets.greenplum_password). When the table cannot be
read the `apps:` list of the config file is used (and the control center says so)."""
from __future__ import annotations

import json
import logging
import re
import sqlite3
import threading
import time
from typing import Dict, List, Optional

log = logging.getLogger(__name__)

COLUMNS = [("app_id", "varchar(40)"), ("name", "varchar(100)"), ("label", "varchar(100)"), ("enabled", "boolean"),
           ("pack", "varchar(200)"), ("repo_url", "varchar(500)"), ("base_branch", "varchar(200)"), ("target_branch", "varchar(200)"),
           ("branch_template", "varchar(200)"), ("commit_template", "varchar(200)"), ("extra", "text"),
           ("updated_by", "varchar(200)"), ("updated_at", "timestamp")]
FIELDS = [c for c, _ in COLUMNS]


def _ident(x: str) -> str:
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", x or ""):
        raise ValueError(f"not a valid SQL identifier: {x!r}")
    return x


def clean_app(row: dict) -> dict:
    a = {k: row.get(k) for k in FIELDS if k in row}
    a["app_id"] = re.sub(r"[^a-z0-9_]+", "_", str(a.get("app_id") or a.get("label") or "").strip().lower()).strip("_")
    if not a["app_id"]:
        raise ValueError("app id is required (e.g. ikg)")
    a["name"] = str(a.get("name") or a["app_id"].upper()).strip()
    a["label"] = str(a.get("label") or a["name"]).strip()
    a["enabled"] = str(a.get("enabled", True)).lower() not in ("false", "0", "no", "off", "")
    for k in ("pack", "repo_url", "base_branch", "target_branch", "branch_template", "commit_template"):
        a[k] = str(a.get(k) or "").strip()
    if not a["pack"]:
        a["pack"] = f"{a['app_id']}_pack.zip"
    ex = a.get("extra")
    a["extra"] = ex if isinstance(ex, dict) else (json.loads(ex) if isinstance(ex, str) and ex.strip().startswith("{") else {})
    return a


class AppRegistry:
    def __init__(self, cfg, password_fn=None):
        self.cfg = cfg
        self.g = dict((cfg.get("autopilot") or {}).get("greenplum") or {})
        self.password_fn = password_fn or (lambda: "")
        self._cache: Optional[List[dict]] = None
        self._at = 0.0
        self.source = ""                     # greenplum | sqlite | config
        self.error = ""
        self._lock = threading.Lock()

    # ------------------------------------------------------------------ connection
    @property
    def fq(self) -> str:
        return f"{_ident(self.g.get('schema', 'sandbox_prj_smart_insights'))}.{_ident(self.g.get('table', 'story_autopilot_apps'))}"

    def _sqlite(self) -> bool:
        return bool(self.g.get("sqlite_path"))

    def _connect(self):
        if self._sqlite():
            return sqlite3.connect(self.g["sqlite_path"])
        import psycopg2
        return psycopg2.connect(host=self.g.get("host"), port=int(self.g.get("port", 5432)), dbname=self.g.get("database"),
                                user=self.g.get("user"), password=self.password_fn(), connect_timeout=15,
                                options="-c statement_timeout=60000")

    def _table(self) -> str:
        return _ident(self.g.get("table", "story_autopilot_apps")) if self._sqlite() else self.fq

    def ensure_table(self) -> str:
        """Creates the table when missing (+ owner / grant on Greenplum). Returns what was done."""
        cols = ", ".join(f"{c} {('text' if self._sqlite() and t.startswith(('varchar', 'timestamp')) else t)}" for c, t in COLUMNS)
        con = self._connect()
        try:
            cur = con.cursor()
            if self._sqlite():
                cur.execute(f"create table if not exists {self._table()} ({cols})")
            else:
                cur.execute(f"create table if not exists {self.fq} ({cols}) distributed by (app_id)")
                if self.g.get("owner_role"):
                    cur.execute(f"alter table {self.fq} owner to {_ident(self.g['owner_role'])}")
                if self.g.get("reader_role"):
                    cur.execute(f"grant select on {self.fq} to {_ident(self.g['reader_role'])}")
            con.commit()
        finally:
            con.close()
        return f"table {self._table()} ready"

    # ------------------------------------------------------------------ read
    def all(self, refresh: bool = False) -> List[dict]:
        with self._lock:
            ttl = float(self.g.get("cache_seconds", 60))
            if self._cache is not None and not refresh and time.time() - self._at < ttl:
                return self._cache
            rows, src, err = None, "", ""
            if self.g.get("enabled", True):
                try:
                    con = self._connect()
                    try:
                        cur = con.cursor()
                        cur.execute(f"select {', '.join(FIELDS)} from {self._table()} order by app_id")
                        rows = [clean_app(dict(zip(FIELDS, r))) for r in cur.fetchall()]
                        src = "sqlite" if self._sqlite() else "greenplum"
                    finally:
                        con.close()
                except Exception as e:  # noqa: BLE001
                    err = f"{type(e).__name__}: {str(e)[:200]}"
                    log.warning("onboarding table not readable (%s) - using the apps list of the config file", err)
            if rows is None or (not rows and not src):
                rows, src = [clean_app(a) for a in (self.cfg.get("apps") or [])], "config"
            self._cache, self._at, self.source, self.error = rows, time.time(), src, err
            return rows

    def enabled(self) -> List[dict]:
        return [a for a in self.all() if a["enabled"]]

    def get(self, app_id: str) -> Optional[dict]:
        return next((a for a in self.all() if a["app_id"] == app_id), None)

    def label_map(self) -> Dict[str, str]:
        """lower-cased story label -> app id, for every ENABLED app (a label may list aliases: 'IKG, ikg-app')."""
        out = {}
        for a in self.enabled():
            for lab in str(a["label"]).split(","):
                if lab.strip():
                    out[lab.strip().lower()] = a["app_id"]
        return out

    # ------------------------------------------------------------------ write (onboarding page)
    def save(self, row: dict, user: str = "") -> dict:
        a = clean_app(row)
        a["updated_by"], a["updated_at"] = user, time.strftime("%Y-%m-%d %H:%M:%S")
        self.ensure_table()
        con = self._connect()
        try:
            cur = con.cursor()
            ph = "?" if self._sqlite() else "%s"
            cur.execute(f"delete from {self._table()} where app_id = {ph}", (a["app_id"],))
            vals = [json.dumps(a["extra"]) if k == "extra" else a.get(k) for k in FIELDS]
            if self._sqlite():
                vals = [int(v) if isinstance(v, bool) else v for v in vals]
            cur.execute(f"insert into {self._table()} ({', '.join(FIELDS)}) values ({', '.join([ph] * len(FIELDS))})", vals)
            con.commit()
        finally:
            con.close()
        self._cache = None
        return a

    def delete(self, app_id: str) -> None:
        con = self._connect()
        try:
            cur = con.cursor()
            ph = "?" if self._sqlite() else "%s"
            cur.execute(f"delete from {self._table()} where app_id = {ph}", (app_id,))
            con.commit()
        finally:
            con.close()
        self._cache = None

    def seed_from_config(self, user: str = "config") -> int:
        """First start: copy the config file's apps into an empty table."""
        self.ensure_table()
        cur_rows = [a for a in self.all(refresh=True)] if self.source != "config" else []
        if cur_rows:
            return 0
        n = 0
        for a in self.cfg.get("apps") or []:
            self.save(a, user)
            n += 1
        return n
