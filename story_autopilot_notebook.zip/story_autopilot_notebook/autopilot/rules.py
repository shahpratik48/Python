"""Pick-up rules - pure functions (no GitLab calls), driven entirely by `autopilot.criteria` / `autopilot.labels`.

A story is picked up when ALL hold:
  1. its LATEST status is In progress (the scoped label, issue open)
  2. it has the ready label (ready_for_agent)
  3. it has at least one onboarded app label (IKG / NLG / ODM ...) - that picks the app's pack(s) and repository(ies)
  4. it has an assignee (exactly one unless multiple_assignees = first)
and it is not stopped:
  * agent_code_done / agent_re_code_done / ai_failed on it -> only again with the rework label (re_work_for_agent)
  * it came back to In progress FROM QA / UAT / closed -> only with the rework label
Missing criteria 3 / 4 on a story that IS ready -> blocked (ai_blocked + one comment saying what is missing)."""
from __future__ import annotations

from typing import Dict, List, Optional


def _lname(ev: dict) -> str:
    return str(((ev.get("label") or {}).get("name")) or "")


def status_history(label_events: List[dict], state_events: List[dict], prefix: str = "status::") -> List[dict]:
    """Chronological status changes: [{at, status}] where status is a status:: label or 'closed'. A scoped label swap is one
    remove + one add at the same moment; a reopen restores the status label the story still carries."""
    evs = []
    for e in label_events or []:
        n = _lname(e)
        if n.lower().startswith(prefix.lower()):
            evs.append((str(e.get("created_at") or ""), 1 if e.get("action") == "add" else 0, e.get("action"), n))
    for e in state_events or []:
        st = str(e.get("state") or "")
        if st in ("closed", "reopened"):
            evs.append((str(e.get("created_at") or ""), 2, st, ""))
    evs.sort(key=lambda x: (x[0], x[1]))          # at the same time: removes first, then adds, then state changes
    out, current, label_now = [], None, None
    for at, _, action, name in evs:
        if action == "add":
            label_now = name
            if current != "closed":
                current = name
                out.append({"at": at, "status": name})
        elif action == "remove":
            if label_now == name:
                label_now = None
        elif action == "closed":
            current = "closed"
            out.append({"at": at, "status": "closed"})
        elif action == "reopened":
            current = label_now
            if label_now:
                out.append({"at": at, "status": label_now})
    return out


def previous_status(history: List[dict], in_progress: str) -> Optional[str]:
    """The status the story had just before its LATEST move into In progress (None = it never had one, e.g. To do)."""
    ip = in_progress.lower()
    idx = max((i for i, h in enumerate(history) if str(h["status"]).lower() == ip), default=None)
    if idx is None:
        return None
    for h in reversed(history[:idx]):
        if str(h["status"]).lower() != ip:
            return h["status"]
    return None


def decide(issue: dict, label_events: List[dict], state_events: List[dict], cfg: dict, app_labels: Dict[str, str]) -> dict:
    """-> {pick, kind (new | rework), apps, reason, block, previous_status, assignee}. `app_labels` maps a lower-cased
    story label to an enabled app id. `cfg` = the autopilot config section."""
    c, L = cfg.get("criteria") or {}, cfg.get("labels") or {}
    labels = [str(x) for x in (issue.get("labels") or [])]
    low = {x.lower() for x in labels}
    ip = str(c.get("in_progress_label", "status::In Progress"))
    ready = str(c.get("ready_label", "ready_for_agent")).lower()
    rework = str(L.get("rework", "re_work_for_agent")).lower()
    stop = {str(x).lower() for x in (L.get("stop_labels") or [])}
    apps = []
    for lab in labels:
        a = app_labels.get(lab.lower())
        if a and a not in apps:
            apps.append(a)
    out = {"pick": False, "kind": "", "apps": apps, "reason": "", "block": "", "previous_status": None, "assignee": None,
           "labels": labels}
    if str(issue.get("state", "opened")) != "opened":
        out["reason"] = "story is closed"
        return out
    if ip.lower() not in low:
        out["reason"] = f"latest status is not {ip}"
        return out
    if ready not in low:
        out["reason"] = f"no {c.get('ready_label', 'ready_for_agent')} label"
        return out
    hist = status_history(label_events, state_events, str(c.get("status_label_prefix", "status::")))
    prev = previous_status(hist, ip)
    out["previous_status"] = prev
    has_rework = rework in low
    stopped = sorted(low & stop)
    back_from = {str(x).lower() for x in (c.get("rework_from") or [])}
    if stopped and not has_rework:
        out["reason"] = f"already done ({', '.join(stopped)}) - add {L.get('rework', 're_work_for_agent')} to run it again"
        return out
    if prev and prev.lower() in back_from and not has_rework:
        out["reason"] = f"came back to In progress from {prev} - add {L.get('rework', 're_work_for_agent')} to run it again"
        return out
    missing = []
    if c.get("require_app_label", True) and not apps:
        missing.append("an application label (" + ", ".join(sorted({v.upper() for v in app_labels.values()})) + ")")
    asg = issue.get("assignees") or ([issue["assignee"]] if issue.get("assignee") else [])
    if c.get("require_assignee", True):
        if not asg:
            missing.append("an assignee")
        elif len(asg) > 1 and str(c.get("multiple_assignees", "block")) == "block":
            missing.append("exactly one assignee (it has " + str(len(asg)) + ")")
    if asg:
        out["assignee"] = asg[0]
    if missing:
        out["block"] = "needs " + " and ".join(missing)
        out["reason"] = "blocked: " + out["block"]
        return out
    out["pick"] = True
    out["kind"] = "rework" if has_rework else "new"
    out["reason"] = ("rework requested" if has_rework else "ready") + f" - apps {', '.join(a.upper() for a in apps)}"
    return out
