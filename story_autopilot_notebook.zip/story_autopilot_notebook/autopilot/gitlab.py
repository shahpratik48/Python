"""GitLab REST client for the story board and the merge requests (python-requests, the automation's token).

Everything the watcher and the worker need: iterations, issues of an iteration, label / state history, labels (created once
when missing), comments, users, branches, merge requests (find / create / update as Draft, assignee) and MR discussions
(the /ai-fix comments and the replies in their threads). The automation NEVER approves or merges: there is no call for it."""
from __future__ import annotations

import logging
import re
import time
from typing import Dict, List, Optional
from urllib.parse import quote

from agiledev.gitclient import parse_project_url

log = logging.getLogger(__name__)


class GitLabError(RuntimeError):
    pass


class GitLab:
    def __init__(self, project_url: str, token: str, ssl_verify=True, dry_run: bool = False, timeout: int = 60):
        self.info = parse_project_url(project_url)
        self.base = self.info["base"]
        self.web = self.info["web"]
        self.project = self.info["project"]
        self.token = token or ""
        self.verify = ssl_verify
        self.dry_run = dry_run
        self.timeout = timeout
        self._s = None
        self._labels: Optional[Dict[str, dict]] = None
        self._users: Dict[str, dict] = {}
        self.writes: List[dict] = []            # what was (or, in dry run, would have been) written - shown in the log

    # ------------------------------------------------------------------ http
    @property
    def s(self):
        if self._s is None:
            import requests
            self._s = requests.Session()
            self._s.headers["PRIVATE-TOKEN"] = self.token
            self._s.verify = self.verify
        return self._s

    def proj(self, project: str = "") -> str:
        return f"{self.base}/projects/{quote(project or self.project, safe='')}"

    def _req(self, method: str, url: str, **kw):
        for attempt in range(4):
            r = self.s.request(method, url, timeout=self.timeout, **kw)
            if r.status_code in (429, 502, 503, 504) and attempt < 3:
                time.sleep(float(r.headers.get("Retry-After") or 2 * (attempt + 1)))
                continue
            if r.status_code >= 400:
                msg = r.text[:300].replace(self.token, "***") if self.token else r.text[:300]
                raise GitLabError(f"{method} {url.replace(self.base, '')} -> {r.status_code}: {msg}")
            return r.json() if r.content else {}
        return {}

    def get(self, url: str, **params):
        return self._req("GET", url, params=params)

    def get_all(self, url: str, max_pages: int = 20, **params) -> list:
        out, page = [], 1
        params.setdefault("per_page", 100)
        while page <= max_pages:
            r = self.s.get(url, params=dict(params, page=page), timeout=self.timeout)
            if r.status_code >= 400:
                raise GitLabError(f"GET {url.replace(self.base, '')} -> {r.status_code}: {r.text[:300]}")
            rows = r.json()
            out += rows if isinstance(rows, list) else [rows]
            nxt = r.headers.get("X-Next-Page", "")
            if not nxt or not rows:
                break
            page = int(nxt)
        return out

    def write(self, method: str, url: str, what: str, **kw):
        """Every write goes through here: logged, and skipped in dry run."""
        self.writes.append({"at": time.strftime("%H:%M:%S"), "what": what, "dry_run": self.dry_run})
        if self.dry_run:
            log.info("DRY RUN - not written: %s", what)
            return {"dry_run": True}
        return self._req(method, url, **kw)

    # ------------------------------------------------------------------ who am I
    def whoami(self) -> dict:
        u = self.get(f"{self.base}/user")
        return {"id": u.get("id"), "username": u.get("username"), "name": u.get("name", ""),
                "email": u.get("commit_email") or u.get("public_email") or u.get("email") or ""}

    def user(self, user_id) -> dict:
        k = str(user_id)
        if k not in self._users:
            try:
                self._users[k] = self.get(f"{self.base}/users/{user_id}")
            except GitLabError:
                self._users[k] = {}
        return self._users[k]

    # ------------------------------------------------------------------ iterations + issues
    def iterations(self, state: str = "all", limit: int = 12) -> List[dict]:
        rows = []
        for url in (f"{self.proj()}/iterations", ):
            try:
                rows = self.get_all(url, max_pages=3, state=state, include_ancestors="true")
            except GitLabError as e:
                log.warning("iterations not readable: %s", e)
        rows = [r for r in rows if isinstance(r, dict)]
        rows.sort(key=lambda r: str(r.get("start_date") or ""), reverse=True)
        return [{"id": r.get("id"), "iid": r.get("iid"), "title": r.get("title") or "", "start_date": r.get("start_date"),
                 "due_date": r.get("due_date"), "state": r.get("state"), "label": iteration_label(r)} for r in rows[:limit]]

    def current_iteration(self) -> Optional[dict]:
        cur = [r for r in self.iterations("current", 3)]
        return cur[0] if cur else None

    def issues(self, iteration="current", states=("opened",), labels: str = "") -> List[dict]:
        params = {"scope": "all"}
        if iteration:
            params["iteration_id"] = "Current" if str(iteration).lower() == "current" else str(iteration)
        if labels:
            params["labels"] = labels
        out = []
        for st in states or ["opened"]:
            out += self.get_all(f"{self.proj()}/issues", state=st, **params)
        return out

    def issue(self, iid) -> dict:
        return self.get(f"{self.proj()}/issues/{iid}")

    def label_events(self, iid) -> List[dict]:
        return self.get_all(f"{self.proj()}/issues/{iid}/resource_label_events", max_pages=5)

    def state_events(self, iid) -> List[dict]:
        try:
            return self.get_all(f"{self.proj()}/issues/{iid}/resource_state_events", max_pages=5)
        except GitLabError:
            return []

    # ------------------------------------------------------------------ labels
    def labels(self, refresh: bool = False) -> Dict[str, dict]:
        if self._labels is None or refresh:
            rows = self.get_all(f"{self.proj()}/labels", max_pages=10, include_ancestor_groups="true")
            self._labels = {str(r.get("name", "")).lower(): r for r in rows}
        return self._labels

    def ensure_label(self, name: str, color: str = "#7c3aed", description: str = "Story Autopilot") -> bool:
        """Create the label on the story project once when it does not exist (project or group level). True = created."""
        if not name or name.lower() in self.labels():
            return False
        self.write("POST", f"{self.proj()}/labels", f"create label {name}", json={"name": name, "color": color, "description": description})
        self._labels[name.lower()] = {"name": name}
        return True

    def set_labels(self, iid, add: List[str] = (), remove: List[str] = ()) -> None:
        add = [a for a in add if a]
        remove = [r for r in remove if r and r not in add]
        if not add and not remove:
            return
        body = {}
        if add:
            body["add_labels"] = ",".join(add)
        if remove:
            body["remove_labels"] = ",".join(remove)
        self.write("PUT", f"{self.proj()}/issues/{iid}", f"story #{iid}: labels +{add} -{remove}", json=body)

    def comment(self, iid, body: str) -> dict:
        return self.write("POST", f"{self.proj()}/issues/{iid}/notes", f"story #{iid}: comment", json={"body": body})

    # ------------------------------------------------------------------ repository projects (the app repos)
    def branches(self, project: str, search: str = "") -> List[dict]:
        return self.get_all(f"{self.proj(project)}/repository/branches", max_pages=3, search=search) if search else \
            self.get_all(f"{self.proj(project)}/repository/branches", max_pages=3)

    def find_mr(self, project: str, source: str, target: str = "") -> Optional[dict]:
        params = {"state": "opened", "source_branch": source}
        if target:
            params["target_branch"] = target
        rows = self.get_all(f"{self.proj(project)}/merge_requests", max_pages=1, **params)
        return rows[0] if rows else None

    def create_mr(self, project: str, source: str, target: str, title: str, description: str, assignee_id=None, draft: bool = False,
                  labels: str = "") -> dict:
        body = {"source_branch": source, "target_branch": target, "title": ("Draft: " + title) if draft else title,
                "description": description, "remove_source_branch": True}
        if assignee_id:
            body["assignee_id"] = assignee_id
        if labels:
            body["labels"] = labels
        return self.write("POST", f"{self.proj(project)}/merge_requests", f"open MR {source} -> {target}" + (" (Draft)" if draft else ""), json=body)

    def update_mr(self, project: str, mr_iid, title: str = None, description: str = None, draft: Optional[bool] = None, assignee_id=None) -> dict:
        body = {}
        if title is not None:
            t = re.sub(r"^(Draft:\s*|\[Draft\]\s*|WIP:\s*)", "", title, flags=re.I)
            body["title"] = ("Draft: " + t) if draft else t
        if description is not None:
            body["description"] = description
        if assignee_id:
            body["assignee_id"] = assignee_id
        if not body:
            return {}
        return self.write("PUT", f"{self.proj(project)}/merge_requests/{mr_iid}", f"update MR !{mr_iid}" + (" (Draft)" if draft else ""), json=body)

    def mr_comment(self, project: str, mr_iid, body: str) -> dict:
        return self.write("POST", f"{self.proj(project)}/merge_requests/{mr_iid}/notes", f"MR !{mr_iid}: comment", json={"body": body})

    def mr_discussions(self, project: str, mr_iid) -> List[dict]:
        return self.get_all(f"{self.proj(project)}/merge_requests/{mr_iid}/discussions", max_pages=10)

    def reply_discussion(self, project: str, mr_iid, discussion_id: str, body: str) -> dict:
        return self.write("POST", f"{self.proj(project)}/merge_requests/{mr_iid}/discussions/{discussion_id}/notes",
                          f"MR !{mr_iid}: reply in thread", json={"body": body})

    def mr(self, project: str, mr_iid) -> dict:
        return self.get(f"{self.proj(project)}/merge_requests/{mr_iid}")


_MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


def iteration_label(it: dict) -> str:
    """'Nov 4 - 17, 2026' (as GitLab shows a cadence iteration), or its title when it has one and no dates."""
    s, d = str(it.get("start_date") or ""), str(it.get("due_date") or "")
    try:
        ys, ms, ds = (int(x) for x in s.split("-"))
        yd, md, dd = (int(x) for x in d.split("-"))
        if ys == yd and ms == md:
            return f"{_MONTHS[ms - 1]} {ds} - {dd}, {yd}"
        if ys == yd:
            return f"{_MONTHS[ms - 1]} {ds} - {_MONTHS[md - 1]} {dd}, {yd}"
        return f"{_MONTHS[ms - 1]} {ds}, {ys} - {_MONTHS[md - 1]} {dd}, {yd}"
    except Exception:  # noqa: BLE001
        return it.get("title") or f"iteration {it.get('iid') or it.get('id')}"


def parse_assignee(name: str, fmt: str = "last_first_gpn") -> dict:
    """'shah pratik 49010206' -> {first: Pratik, last: Shah, gpn: 49010206, display: 'Pratik Shah'}."""
    raw = " ".join(str(name or "").split())
    m = re.search(r"(\d{5,})\s*$", raw)
    gpn = m.group(1) if m else ""
    words = (raw[: m.start()] if m else raw).replace(",", " ").split()
    if fmt.startswith("last_first") and len(words) >= 2:
        last, first = words[0], " ".join(words[1:])
    elif len(words) >= 2:
        first, last = " ".join(words[:-1]), words[-1]
    else:
        first, last = (words[0] if words else ""), ""
    first, last = first.title(), last.title()
    return {"first": first, "last": last, "gpn": gpn, "display": " ".join(x for x in (first, last) if x) or raw}
