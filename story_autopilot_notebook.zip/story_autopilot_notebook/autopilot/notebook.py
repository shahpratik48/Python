"""Notebook edition: buttons to start / stop the watcher + worker and to open the control center and the onboarding page.

    from autopilot.notebook import panel
    panel(svc, cfg, port=8790)

The web server runs in a background thread of the kernel (dev login, no SSO). The open buttons are HTML in the notebook output,
so the window opens in YOUR browser - also when JupyterLab runs on a remote server (jupyter-server-proxy link)."""
from __future__ import annotations

import json
import socket

_SERVERS = {}


def start_ui(svc, cfg, port: int = 8790):
    from agiledev.config import Config
    from .server import serve
    if port in _SERVERS:
        return _SERVERS[port]
    c = Config(dict(cfg))
    c["auth"] = dict(cfg.get("auth") or {}, mode="dev", dev_allow_any_user=True, admins=[])
    srv = serve(c, svc, "0.0.0.0", port, background=True)
    _SERVERS[port] = srv
    return srv


def stop_ui(port: int = 8790):
    s = _SERVERS.pop(port, None)
    if s is not None:
        s.stop()


def _open_buttons(port: int) -> str:
    local = f"http://localhost:{port}/"
    try:
        ip = socket.gethostbyname(socket.gethostname())
    except Exception:  # noqa: BLE001
        ip = socket.gethostname()
    style = ("padding:10px 18px;border-radius:12px;border:0;cursor:pointer;font-size:15px;font-weight:700;margin-right:10px;"
             "color:#04131a;background:linear-gradient(135deg,#2dd4bf,#38bdf8);box-shadow:0 4px 14px rgba(45,212,191,.35)")
    return f"""
<div style="font-family:sans-serif;font-size:14px;line-height:1.7">
  <button id="sa-cc-{port}" style="{style}">🛰 Open the control center</button>
  <button id="sa-ob-{port}" style="{style};background:linear-gradient(135deg,#a78bfa,#38bdf8)">🧩 Open app onboarding</button>
  <div style="color:#888;font-size:12px">direct links: <a href="{local}" target="_blank">{local}</a> · <a href="http://{ip}:{port}/" target="_blank">http://{ip}:{port}/</a>
  · sign in with your e-mail (local dev login)</div>
</div>
<script>
(function(){{
  function base(){{
    const p = location.pathname, m = p.match(/^(.*?)\\/(lab|notebooks|tree|voila|doc)(\\/|$)/);
    if (m && location.hostname !== 'localhost' && location.hostname !== '127.0.0.1') return location.origin + m[1] + '/proxy/{port}/';
    if (location.hostname === 'localhost' || location.hostname === '127.0.0.1') return '{local}';
    return 'http://' + location.hostname + ':{port}/';
  }}
  document.getElementById('sa-cc-{port}').onclick = () => window.open(base(), '_blank', 'noopener,width=1500,height=950');
  document.getElementById('sa-ob-{port}').onclick = () => window.open(base() + 'onboarding/', '_blank', 'noopener,width=1300,height=950');
}})();
</script>"""


def panel(svc, cfg, port: int = 8790):
    """Start the UI server once and show: Start / Stop / Poll now (watcher + worker + agents) and the two open buttons."""
    start_ui(svc, cfg, port)
    try:
        from IPython.display import HTML, display
    except Exception:  # noqa: BLE001
        print(f"control center: http://localhost:{port}/   onboarding: http://localhost:{port}/onboarding/")
        return
    try:
        import ipywidgets as w
        out = w.Output()
        b_start = w.Button(description="Start watcher + worker", button_style="success", icon="play", layout=w.Layout(width="230px"))
        b_stop = w.Button(description="Stop", button_style="danger", icon="stop", layout=w.Layout(width="120px"))
        b_poll = w.Button(description="Poll now", icon="refresh", layout=w.Layout(width="120px"))
        b_stat = w.Button(description="Status", icon="info", layout=w.Layout(width="120px"))

        def show(x):
            with out:
                out.clear_output()
                print(json.dumps(x, indent=1, default=str)[:4000])

        import getpass as _gp
        import socket as _so
        who = _gp.getuser()
        host = _so.gethostname()

        def aud(action, detail="", outcome="ok"):
            try:
                svc.state.audit(who, action, "", detail, user_name=f"{who} (notebook)", ip=host, source="notebook", outcome=outcome)
            except Exception:  # noqa: BLE001
                pass

        def on_start(_):
            try:
                r = svc.start()
                aud("start watcher + worker", f"token owner {r.get('token_owner')}")
                show(r)
            except Exception as e:  # noqa: BLE001
                aud("start watcher + worker", f"{type(e).__name__}: {str(e)[:300]}", "failed")
                show({"error": f"{type(e).__name__}: {e}"})

        def on_stop(_):
            svc.stop()
            aud("stop watcher + worker")
            show({"stopped": True})

        def on_poll(_):
            aud("manual poll", "watcher running" if svc.running else "one-off poll")
            show(svc.poll_once() if not svc.running else (svc.poll_now() or {"poll": "requested"}))

        def on_stat(_):
            st = svc.status()
            show(dict({k: st[k] for k in ("running", "enabled", "paused", "dry_run", "worker", "blocked", "cost_today", "usd_per_day", "apps_source")},
                      current=(st.get("current") or {}).get("iid"), queue=[(j["iid"], j["kind"], j["state"]) for j in svc.state.queue()],
                      watch={k: st["watch"].get(k) for k in ("iteration", "seen", "queued", "last_error")}))
        b_start.on_click(on_start)
        b_stop.on_click(on_stop)
        b_poll.on_click(on_poll)
        b_stat.on_click(on_stat)
        display(w.HBox([b_start, b_stop, b_poll, b_stat]))
        display(HTML(_open_buttons(port)))
        display(out)
    except ImportError:
        display(HTML(_open_buttons(port) + "<div style='color:#888'>ipywidgets not installed: use svc.start() / svc.stop() / svc.poll_now() in a cell.</div>"))
