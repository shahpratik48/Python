"""Story Autopilot web app: the control center (/) and the onboarding page (/onboarding).

Standard-library HTTP server (same core as Agile Dev Assist), SSO via auth.mode header | oidc | dev, the signed session
cookie. Changing switches, the queue order or the onboarding table needs an admin (auth.admins) when that list is set."""
from __future__ import annotations

import json
import logging
import mimetypes
import re
import secrets as pysecrets
import threading
import time
from pathlib import Path
from typing import Optional

from agiledev.auth import COOKIE, Auth
from agiledev.config import Config, get_secret, load_config
from agiledev.webcore import HTTPError, Request, Response, Router, Server, _page, parse_multipart  # noqa: F401

from .service import Autopilot

log = logging.getLogger(__name__)
WEB = Path(__file__).resolve().parent.parent / "web"
router = Router()
route = router.route


class Core:
    def __init__(self, cfg: Config, svc: Autopilot):
        self.cfg, self.svc = cfg, svc
        self.auth = Auth(cfg, get_secret(cfg, "server_secret", allow_prompt=False, required=False))


def user(core: Core, r: Request) -> dict:
    try:
        u = core.auth.user_from_request(r.headers, r.cookies, r.client)
    except PermissionError as e:
        raise HTTPError(403, str(e))
    if not u:
        raise HTTPError(401, "not signed in")
    if not core.auth.allowed(u["user_id"]):
        raise HTTPError(403, "user not allowed")
    return u


def client_ip(r: Request) -> str:
    """The person's address: the first X-Forwarded-For hop behind the SSO gateway / proxy, else the direct peer."""
    fwd = r.header("x-forwarded-for")
    return (fwd.split(",")[0].strip() if fwd else "") or r.client or ""


def audit(core: Core, r: Request, u: Optional[dict], action: str, target: str = "", detail: str = "", outcome: str = "ok",
          source: str = "") -> None:
    """Audit trail of the control center: who (e-mail, name, IP), what, on what, when. Identity only - never a secret."""
    try:
        u = u or {}
        core.svc.state.audit(u.get("user_id", "anonymous"), action, target, detail, user_name=u.get("display_name", ""), ip=client_ip(r),
                             source=source or ("onboarding page" if "/apps" in r.path or "/packs" in r.path else "control center"), outcome=outcome)
    except Exception as e:  # noqa: BLE001
        log.warning("audit not written: %s", e)


def _job_label(core: Core, jid) -> str:
    j = next((x for x in core.svc.state._x("select id, kind, iid, title from queue where id=?", (int(jid),))), None)
    return f"job {jid}: #{j['iid']} {j['kind']} {str(j['title'] or '')[:80]}" if j else f"job {jid}"


def admin(core: Core, r: Request, action: str = "") -> dict:
    u = user(core, r)
    if (core.cfg.get("auth") or {}).get("admins") and not core.auth.is_admin(u["user_id"]):
        audit(core, r, u, action or f"{r.path}", "", "refused: not an administrator (auth.admins)", outcome="denied")
        raise HTTPError(403, "only an administrator (auth.admins) can change this")
    return u


def _cookie(core: Core, resp: Response, u: dict, r: Request) -> None:
    secure = bool(core.cfg.auth.get("secure_cookies", False)) or r.header("x-forwarded-proto") == "https"
    resp.headers.append(("Set-Cookie", f"{COOKIE}={core.auth.sign(u)}; Max-Age={int(core.auth.ttl)}; Path=/; HttpOnly; SameSite=Lax" + ("; Secure" if secure else "")))


def _page_or_login(core: Core, r: Request, name: str) -> Response:
    try:
        u = core.auth.user_from_request(r.headers, r.cookies, r.client)
    except PermissionError as e:
        return Response.html(_page("Access refused", str(e)), 403)
    if not u:
        if core.auth.mode == "oidc":
            return Response.redirect("auth/login", 302)
        if core.auth.mode == "header":
            return Response.html(_page("Not signed in", "Open Story Autopilot through the corporate single sign-on URL."), 401)
        return Response.html((WEB / "login.html").read_text(encoding="utf-8"))
    return Response.html((WEB / name).read_text(encoding="utf-8"))


# ----------------------------------------------------------------------------- pages
@route("GET", "/")
def index(core: Core, r: Request):
    return _page_or_login(core, r, "index.html")


@route("GET", "/onboarding/?")
def onboarding(core: Core, r: Request):
    return _page_or_login(core, r, "onboarding.html")


@route("GET", "/(?:onboarding/)?static/(?P<name>[A-Za-z0-9_.-]+)")
def static(core: Core, r: Request, name: str):
    p = WEB / name
    if not p.is_file():
        raise HTTPError(404, "not found")
    return Response(200, p.read_bytes(), mimetypes.guess_type(name)[0] or "application/octet-stream", [("Cache-Control", "no-cache")])


@route("POST", "/(?:onboarding/)?auth/dev-login")
def dev_login(core: Core, r: Request):
    if core.auth.mode != "dev":
        raise HTTPError(404, "not found")
    uid = r.fields.get("user", "").strip()
    if not uid:
        raise HTTPError(400, "user id required")
    try:
        u = core.auth.normalize({"user_id": uid, "display_name": r.fields.get("name", "").strip() or uid, "email": uid if "@" in uid else ""})
    except PermissionError as e:
        raise HTTPError(400, str(e))
    audit(core, r, u, "sign in", "", "local dev login")
    resp = Response.redirect("../", 303)
    _cookie(core, resp, u, r)
    return resp


@route("GET", "/auth/login")
def login(core: Core, r: Request):
    if core.auth.mode != "oidc":
        return Response.redirect("../", 302)
    state = pysecrets.token_urlsafe(16)
    cb = f"{'https' if r.header('x-forwarded-proto') == 'https' else 'http'}://{r.header('host')}/auth/callback"
    resp = Response.redirect(core.auth.oidc_login_url(cb, state), 302)
    resp.headers.append(("Set-Cookie", f"autopilot_oidc_state={state}; Max-Age=600; Path=/; HttpOnly"))
    return resp


@route("GET", "/auth/callback")
def callback(core: Core, r: Request):
    if r.cookies.get("autopilot_oidc_state") != r.query.get("state", ""):
        raise HTTPError(400, "state mismatch")
    cb = f"{'https' if r.header('x-forwarded-proto') == 'https' else 'http'}://{r.header('host')}/auth/callback"
    try:
        u = core.auth.oidc_exchange(r.query.get("code", ""), cb, get_secret(core.cfg, "oidc_client_secret", allow_prompt=False, required=False))
    except PermissionError as e:
        raise HTTPError(403, str(e))
    audit(core, r, u, "sign in", "", "single sign-on (OIDC)")
    resp = Response.redirect("../", 303)
    _cookie(core, resp, u, r)
    return resp


@route("POST", "/auth/logout")
def logout(core: Core, r: Request):
    try:
        audit(core, r, core.auth.user_from_request(r.headers, r.cookies, r.client), "sign out")
    except Exception:  # noqa: BLE001
        pass
    resp = Response.json({"ok": True, "logout_url": core.auth.logout_url()})
    resp.headers.append(("Set-Cookie", f"{COOKIE}=; Max-Age=0; Path=/"))
    return resp


@route("GET", "/api/health")
def health(core: Core, r: Request):
    return Response.json({"ok": True, "product": "Story Autopilot", "running": core.svc.running})


# ----------------------------------------------------------------------------- control center
@route("GET", "/api/me")
def me(core: Core, r: Request):
    u = user(core, r)
    adm = not (core.cfg.get("auth") or {}).get("admins") or core.auth.is_admin(u["user_id"])
    return Response.json(dict(u, admin=adm))


@route("GET", "/api/status")
def status(core: Core, r: Request):
    user(core, r)
    return Response.json(core.svc.status())


@route("GET", "/api/tree")
def tree(core: Core, r: Request):
    user(core, r)
    try:
        return Response.json(core.svc.tree(refresh=r.query.get("refresh") == "1"))
    except Exception as e:  # noqa: BLE001
        return Response.json({"board": core.svc.board_url(), "iterations": [], "error": f"{type(e).__name__}: {str(e)[:300]}"})


@route("GET", "/api/iterations/(?P<iid>[^/]+)/stories")
def iteration_stories(core: Core, r: Request, iid: str):
    user(core, r)
    return Response.json({"stories": core.svc.stories_of(iid)})


@route("GET", "/api/stories/(?P<iid>\\d+)")
def story(core: Core, r: Request, iid: str):
    user(core, r)
    return Response.json(core.svc.story_detail(iid))


@route("GET", "/api/stories/(?P<iid>\\d+)/file")
def story_file(core: Core, r: Request, iid: str):
    user(core, r)
    return Response.json({"path": r.query.get("path", ""), "content": core.svc.story_file(iid, r.query.get("path", ""))})


@route("GET", "/api/stories/(?P<iid>\\d+)/log")
def story_log(core: Core, r: Request, iid: str):
    user(core, r)
    p = core.svc.story_dir(iid) / "chat" / "log.txt"
    txt = p.read_text(encoding="utf-8", errors="replace")[-200000:] if p.exists() else ""
    return Response.text(txt)


# ---- downloads of a story's run: everything as one zip, or one artifact at a time
DOWNLOADS = {   # name -> (file in the story's agent folder, label)
    "log": ("log.txt", "run log"), "events": ("events.jsonl", "events"), "plan": ("plan.json", "plan"), "review": ("review.json", "review"),
    "findings": ("findings.json", "validator findings"), "summary": ("run_summary.json", "run summary"), "tokens": ("tokens.json", "tokens + cost"),
    "tokens_txt": ("tokens.txt", "tokens + cost (text)"), "context": ("pack.json", "context pack"), "impact": ("impact.json", "impact analysis"),
    "sources": ("sources.json", "sources"), "story": ("story_result.json", "story agent"), "knowledge": ("knowledge.json", "knowledge agent"),
    "data": ("data.json", "data agent"), "repo": ("repo.json", "repository agent"), "files_zip": ("", "generated files (zip)")}


def _chat_dir(core: Core, iid: str) -> Path:
    d = core.svc.stories_root / str(iid) / "chat"
    if not d.is_dir():
        raise HTTPError(404, "the agents have not run on this story yet")
    return d


@route("GET", "/api/stories/(?P<iid>\\d+)/downloads")
def story_downloads(core: Core, r: Request, iid: str):
    user(core, r)
    d = core.svc.stories_root / str(iid) / "chat"
    have = [{"name": k, "label": lab, "file": f or f"story_{iid}_files.zip"} for k, (f, lab) in DOWNLOADS.items()
            if (f and (d / f).exists()) or (not f and (d / "files").is_dir())]
    return Response.json({"downloads": have, "all": d.is_dir()})


@route("GET", "/api/stories/(?P<iid>\\d+)/download/all")
def story_download_all(core: Core, r: Request, iid: str):
    """One zip: every generated file + log, events, plan, review, findings, tokens, context pack, impact, sources, the agents'
    outputs, savepoints and this story's audit / activity. The git worktrees (repos/) are left out: the branch is on GitLab."""
    u = user(core, r)
    import io
    import zipfile
    d = _chat_dir(core, iid)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted(d.rglob("*")):
            rel = f.relative_to(d)
            if f.is_file() and rel.parts[0] not in ("repos",) and not f.name.endswith(".zip") and not f.name.startswith("."):
                z.write(f, f"story_{iid}/{rel.as_posix()}")
        st = core.svc.state
        z.writestr(f"story_{iid}/autopilot/runs.json", json.dumps(st.jobs_of(iid), indent=1, default=str))
        z.writestr(f"story_{iid}/autopilot/branches_and_mrs.json", json.dumps(st.branches(iid), indent=1, default=str))
        z.writestr(f"story_{iid}/autopilot/activity.json", json.dumps(st.events(iid, 1000), indent=1, default=str))
        z.writestr(f"story_{iid}/autopilot/story.json", json.dumps(st.story(iid), indent=1, default=str))
    audit(core, r, u, "download", f"story #{iid}", "everything (zip)")
    return Response(200, buf.getvalue(), "application/zip", [("Content-Disposition", f"attachment; filename=story_{iid}_{time.strftime('%Y%m%d_%H%M')}.zip")])


@route("GET", "/api/stories/(?P<iid>\\d+)/download/(?P<what>[a-z_]+)")
def story_download(core: Core, r: Request, iid: str, what: str):
    u = user(core, r)
    d = _chat_dir(core, iid)
    if what == "file":
        rel = r.query.get("path", "").strip().lstrip("/")
        f = (d / "files" / rel).resolve()
        if not rel or (d / "files").resolve() not in f.parents or not f.is_file():
            raise HTTPError(404, "no such generated file")
        audit(core, r, u, "download", f"story #{iid}", f"file {rel}")
        return Response.file(f, f.name)
    if what == "files_zip":
        import io
        import zipfile
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            for f in sorted((d / "files").rglob("*")):
                if f.is_file():
                    z.write(f, f.relative_to(d / "files").as_posix())
        audit(core, r, u, "download", f"story #{iid}", "generated files (zip)")
        return Response(200, buf.getvalue(), "application/zip", [("Content-Disposition", f"attachment; filename=story_{iid}_files.zip")])
    if what not in DOWNLOADS:
        raise HTTPError(404, "unknown download")
    f = d / DOWNLOADS[what][0]
    if not f.is_file():
        raise HTTPError(404, f"{DOWNLOADS[what][1]} not written yet")
    audit(core, r, u, "download", f"story #{iid}", DOWNLOADS[what][1])
    return Response.file(f, f"story_{iid}_{f.name}")


@route("GET", "/api/queue.csv")
def queue_csv(core: Core, r: Request):
    u = user(core, r)
    import csv
    import io
    buf = io.StringIO()
    w = csv.writer(buf)
    cols = ["id", "kind", "iid", "title", "state", "enqueued", "started", "finished", "seconds", "minutes", "result"]
    w.writerow(cols)
    fmt = lambda t: time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(t)) if t else ""  # noqa: E731
    for j in core.svc.state.queue() + core.svc.state.history(100000):
        sec = round((j.get("finished_at") or 0) - (j.get("started_at") or 0), 1) if j.get("finished_at") and j.get("started_at") else ""
        w.writerow([j["id"], j["kind"], j["iid"], j.get("title", ""), j["state"], fmt(j.get("enqueued_at")), fmt(j.get("started_at")), fmt(j.get("finished_at")),
                    sec, round(sec / 60, 2) if sec != "" else "", json.dumps(j.get("result") or {}, default=str)[:2000]])
    audit(core, r, u, "download", "runs", "queue + run history (csv)")
    return Response(200, buf.getvalue().encode("utf-8"), "text/csv; charset=utf-8",
                    [("Content-Disposition", f"attachment; filename=story_autopilot_runs_{time.strftime('%Y%m%d_%H%M')}.csv")])


@route("POST", "/api/stories/(?P<iid>\\d+)/enqueue")
def story_enqueue(core: Core, r: Request, iid: str):
    u = admin(core, r, "run now")
    try:
        jid = core.svc.enqueue_manual(iid)
    except ValueError as e:
        audit(core, r, u, "run now", f"story #{iid}", str(e), outcome="refused")
        raise HTTPError(400, str(e))
    audit(core, r, u, "run now", f"story #{iid}", f"queued as job {jid}" if jid else "already queued")
    return Response.json({"queued": jid is not None, "id": jid})


@route("GET", "/api/queue")
def queue(core: Core, r: Request):
    user(core, r)
    return Response.json({"queue": core.svc.state.queue(), "history": core.svc.state.history(40)})


@route("POST", "/api/queue/reorder")
def queue_reorder(core: Core, r: Request):
    u = admin(core, r, "queue reorder")
    ids = [int(x) for x in (r.json().get("ids") or [])]
    before = [f"#{j['iid']}" for j in core.svc.state.queue(("queued",))]
    core.svc.state.reorder(ids)
    after = [f"#{j['iid']}" for j in core.svc.state.queue(("queued",))]
    audit(core, r, u, "queue reorder (drag)", "", f"{' > '.join(before)}  ->  {' > '.join(after)}")
    return Response.json({"queue": core.svc.state.queue()})


@route("POST", "/api/queue/(?P<jid>\\d+)/(?P<what>top|up|down|bottom|cancel)")
def queue_move(core: Core, r: Request, jid: str, what: str):
    u = admin(core, r, f"queue {what}")
    audit(core, r, u, "remove from queue" if what == "cancel" else f"queue move {what}", _job_label(core, jid))
    if what == "cancel":
        core.svc.state.cancel(int(jid))
    else:
        core.svc.state.move(int(jid), what)
    return Response.json({"queue": core.svc.state.queue()})


@route("GET", "/api/events")
def events(core: Core, r: Request):
    user(core, r)
    return Response.json({"events": core.svc.state.events(None, 150)})


@route("POST", "/api/control")
def control(core: Core, r: Request):
    b = r.json()
    what = ", ".join(k for k in ("start", "stop", "poll_now", "enabled", "paused", "dry_run", "board_url", "iteration") if k in b) or "control"
    u = admin(core, r, what)
    s = core.svc
    onoff = lambda v: "on" if v else "off"  # noqa: E731
    if "enabled" in b and bool(b["enabled"]) != s.enabled:
        s.set_enabled(bool(b["enabled"]))
        audit(core, r, u, "global switch", "Enabled", f"turned {onoff(b['enabled'])}")
    if "paused" in b and bool(b["paused"]) != s.paused:
        s.set_paused(bool(b["paused"]))
        audit(core, r, u, "pause worker" if b["paused"] else "resume worker", "worker")
    if "dry_run" in b and bool(b["dry_run"]) != s.dry_run:
        s.state.set_setting("dry_run", bool(b["dry_run"]))
        audit(core, r, u, "dry run", "GitLab writes", f"dry run turned {onoff(b['dry_run'])}")
    if b.get("board_url") and str(b["board_url"]).strip() != s.board_url():
        old = s.board_url()
        s.set_board(str(b["board_url"]))
        audit(core, r, u, "story board changed", str(b["board_url"]).strip(), f"was {old}")
    if "iteration" in b and str(b["iteration"] or "") != str(s.state.setting("iteration", "") or ""):
        s.state.set_setting("iteration", str(b["iteration"] or ""))
        audit(core, r, u, "iteration changed", str(b["iteration"] or "current"))
    msg = ""
    if b.get("start") and not s.running:
        try:
            info = s.start()
        except Exception as e:  # noqa: BLE001
            audit(core, r, u, "start watcher + worker", "", f"{type(e).__name__}: {str(e)[:300]}", outcome="failed")
            raise HTTPError(400, f"cannot start: {type(e).__name__}: {e}")
        audit(core, r, u, "start watcher + worker", "", f"token owner {info.get('token_owner')}, iteration {info.get('current_iteration')}")
    if b.get("stop") and s.running:
        cur = s.current
        s.stop()
        audit(core, r, u, "stop watcher + worker", "", f"story #{cur['iid']} was running" if cur else "worker was idle")
    if b.get("poll_now"):
        if s.running:
            s.poll_now()
        else:
            threading.Thread(target=s.poll_once, daemon=True).start()
        msg = "poll started"
        audit(core, r, u, "manual poll", s.board_url(), "watcher running" if s.running else "one-off poll (watcher stopped)")
    return Response.json(dict(s.status(), message=msg))


# ----------------------------------------------------------------------------- audit log
@route("GET", "/api/audit")
def audit_list(core: Core, r: Request):
    user(core, r)
    return Response.json({"audit": core.svc.state.audits(int(r.query.get("limit", 500) or 500), r.query.get("q", "")),
                          "file": str(core.svc.state.audit_file)})


@route("GET", "/api/audit.csv")
def audit_csv(core: Core, r: Request):
    u = user(core, r)
    import csv
    import io
    buf = io.StringIO()
    w = csv.writer(buf)
    cols = ["ts", "user_id", "user_name", "ip", "source", "action", "target", "detail", "outcome"]
    w.writerow(cols)
    for row in core.svc.state.audits(100000, r.query.get("q", "")):
        w.writerow([row.get(c, "") for c in cols])
    audit(core, r, u, "audit log downloaded", "", f"filter '{r.query.get('q', '')}'" if r.query.get("q") else "")
    return Response(200, buf.getvalue().encode("utf-8"), "text/csv; charset=utf-8",
                    [("Content-Disposition", f"attachment; filename=story_autopilot_audit_{time.strftime('%Y%m%d_%H%M')}.csv")])


# ----------------------------------------------------------------------------- onboarding
@route("GET", "/api/apps")
def apps(core: Core, r: Request):
    user(core, r)
    reg = core.svc.apps
    rows = reg.all(refresh=r.query.get("refresh") == "1")
    return Response.json({"apps": rows, "source": reg.source, "error": reg.error, "table": reg._table() if reg.source != "config" else reg.fq,
                          "defaults": {k: (core.cfg.autopilot.get("git") or {}).get(k) for k in ("branch_template", "commit_template")}})


@route("POST", "/api/apps")
def apps_save(core: Core, r: Request):
    u = admin(core, r, "app save")
    try:
        a = core.svc.apps.save(r.json(), u["user_id"])
    except ValueError as e:
        raise HTTPError(400, str(e))
    except Exception as e:  # noqa: BLE001
        raise HTTPError(500, f"onboarding table not written: {type(e).__name__}: {str(e)[:300]}")
    core.svc.state.event("onboarding", "", f"app {a['app_id']} saved by {u['user_id']}")
    audit(core, r, u, "app saved", a["app_id"], f"label {a['label']}, {a['base_branch']} -> {a['target_branch']}, pack {a['pack']}, "
                                                f"{'enabled' if a['enabled'] else 'disabled'}, repo {a['repo_url']}")
    return Response.json({"app": a})


@route("DELETE", "/api/apps/(?P<app_id>[a-z0-9_]+)")
def apps_delete(core: Core, r: Request, app_id: str):
    u = admin(core, r, "app remove")
    core.svc.apps.delete(app_id)
    audit(core, r, u, "app removed", app_id)
    core.svc.state.event("onboarding", "", f"app {app_id} removed by {u['user_id']}")
    return Response.json({"deleted": app_id})


@route("POST", "/api/apps/test")
def apps_test(core: Core, r: Request):
    """Test connection for one app row (not yet saved is fine): pack, repository + branches, story label, Greenplum."""
    u_test = user(core, r)
    from .apps import clean_app
    try:
        a = clean_app(r.json())
    except ValueError as e:
        raise HTTPError(400, str(e))
    s = core.svc
    out = []
    pdir = core.cfg.path((core.cfg.get("knowledge_packs") or {}).get("dir", "packs"))
    z = pdir / a["pack"]
    out.append({"check": "knowledge pack", "ok": z.exists(), "detail": f"{z} ({z.stat().st_size // 1048576} MB)" if z.exists() else f"{z.name} not in {pdir} - upload it below"})
    from agiledev.gitworkspace import GitWorkspace
    ws = GitWorkspace(core.cfg, core.cfg.path(core.cfg.storage.get("git_mirrors_dir", "data/cache/git")))
    for br in (a["base_branch"], a["target_branch"]):
        if not br:
            continue
        try:
            ok = ws.remote_branch_exists(a["repo_url"], s.token, br)
            out.append({"check": f"branch {br}", "ok": ok, "detail": "found" if ok else "not found in the repository"})
        except Exception as e:  # noqa: BLE001
            out.append({"check": f"branch {br}", "ok": False, "detail": str(e)[:200]})
    try:
        labs = s.gl.labels(refresh=True)
        miss = [x.strip() for x in a["label"].split(",") if x.strip() and x.strip().lower() not in labs]
        out.append({"check": "story label", "ok": not miss, "detail": "exists on the story board" if not miss else f"{', '.join(miss)} not on the story board yet (created on first use)"})
    except Exception as e:  # noqa: BLE001
        out.append({"check": "story label", "ok": False, "detail": str(e)[:200]})
    try:
        s.apps.ensure_table()
        out.append({"check": "onboarding table", "ok": True, "detail": s.apps._table()})
    except Exception as e:  # noqa: BLE001
        out.append({"check": "onboarding table", "ok": False, "detail": f"{type(e).__name__}: {str(e)[:200]}"})
    audit(core, r, u_test, "test connection", a["app_id"], "; ".join(f"{c['check']}: {'ok' if c['ok'] else 'FAILED'}" for c in out))
    return Response.json({"checks": out})


@route("GET", "/api/packs")
def packs(core: Core, r: Request):
    user(core, r)
    pdir = core.cfg.path((core.cfg.get("knowledge_packs") or {}).get("dir", "packs"))
    pdir.mkdir(parents=True, exist_ok=True)
    return Response.json({"dir": str(pdir), "packs": [{"name": p.name, "mb": round(p.stat().st_size / 1048576, 1),
                                                       "modified": time.strftime("%Y-%m-%d %H:%M", time.localtime(p.stat().st_mtime))}
                                                      for p in sorted(pdir.glob("*.zip"))]})


@route("POST", "/api/packs/upload")
def packs_upload(core: Core, r: Request):
    u = admin(core, r, "pack upload")
    up = (r.files.get("file") or [None])[0]
    if not up:
        raise HTTPError(400, "no file")
    name, data = up
    if not re.fullmatch(r"[A-Za-z0-9_.-]+\.zip", Path(name).name):
        raise HTTPError(400, "a pack is a .zip file named like ikg_pack.zip")
    lim = float((core.cfg.get("knowledge_packs") or {}).get("max_zip_mb", 1024))
    if len(data) > lim * 1048576:
        raise HTTPError(400, f"larger than {lim:.0f} MB")
    import zipfile
    import io
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            if not any(n.endswith("manifest.json") for n in zf.namelist()):
                raise HTTPError(400, "not a knowledge pack (no manifest.json inside)")
    except zipfile.BadZipFile:
        raise HTTPError(400, "not a zip file")
    pdir = core.cfg.path((core.cfg.get("knowledge_packs") or {}).get("dir", "packs"))
    pdir.mkdir(parents=True, exist_ok=True)
    part = pdir / (Path(name).name + ".part")
    part.write_bytes(data)
    part.replace(pdir / Path(name).name)                   # atomic: a running story never sees half a pack
    core.svc.state.event("onboarding", "", f"pack {Path(name).name} uploaded by {u['user_id']}", f"{len(data) // 1048576} MB")
    audit(core, r, u, "pack uploaded", Path(name).name, f"{round(len(data) / 1048576, 1)} MB")
    return Response.json({"saved": Path(name).name, "mb": round(len(data) / 1048576, 1)})


# ----------------------------------------------------------------------------- entry
def serve(cfg: Optional[Config] = None, svc: Optional[Autopilot] = None, host: Optional[str] = None, port: Optional[int] = None,
          background: bool = False) -> Server:
    cfg = cfg or load_config()
    svc = svc or Autopilot(cfg)
    core = Core(cfg, svc)
    host = host or cfg.server.get("host", "0.0.0.0")
    port = int(port or cfg.server.get("port", 8790))
    srv = Server(core, host, port, router, name="autopilot-web")
    srv.svc = svc
    log.info("Story Autopilot listening on http://%s:%d/ (auth %s)", host, port, core.auth.mode)
    if background:
        return srv.start_background()
    srv.run()
    return srv
