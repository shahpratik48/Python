"""
The tools the agent can call. Each tool is a pure function over already-
gathered evidence (the changeset from change_analyzer.py, and Project 1's
Hierarchy/SrcIndex for structural reachability) -- the agent decides WHEN
and WHETHER to call each one; nothing here makes impact decisions itself,
it only answers factual questions the agent asks.

`AgentToolbox` bundles the evidence once per run and exposes each tool as
a bound method; `TOOL_SCHEMAS` is the OpenAI/Azure-OpenAI-compatible
function-calling schema list passed to the LLM.
"""
from __future__ import annotations

import json
from typing import Dict, List, Optional

from nlg_dag_agent.pipeline import Hierarchy

from .change_analyzer import FileChange


class AgentToolbox:
    def __init__(self, hierarchy_after: Hierarchy, file_changes: List[FileChange],
                 hierarchy_before: Optional[Hierarchy] = None):
        """hierarchy_after = built from `branch` (the code as it will be).
        hierarchy_before = built from `base_branch` (the code as it was) --
        optional, but needed to correctly assess REMOVED functions/calls:
        querying `hierarchy_after` for a function that no longer exists
        obviously finds nothing, so removed-function impact must be
        checked against the pre-change state instead. When not provided,
        `ref="before"` calls fall back to `hierarchy_after` with a warning
        in the response so the agent knows the answer may be incomplete."""
        self.hierarchy_after = hierarchy_after
        self.hierarchy_before = hierarchy_before
        self.file_changes = file_changes
        self._by_path = {fc.new_path or fc.old_path: fc for fc in file_changes}

    def _pick_hierarchy(self, ref: str) -> Hierarchy:
        if ref == "before":
            return self.hierarchy_before or self.hierarchy_after
        return self.hierarchy_after

    def _task_to_dag_map(self, h: Hierarchy) -> Dict[str, str]:
        cache_attr = "_full_task_id_to_dag"
        cached = getattr(h, cache_attr, None)
        if cached is not None:
            return cached
        mapping = {}
        for dag, group, task in h.all_tasks():
            mapping[task.full_task_id] = dag.dag_id
        try:
            setattr(h, cache_attr, mapping)
        except Exception:
            pass
        return mapping

    def _normalize_hits(self, h: Hierarchy, hits: List[dict]) -> List[dict]:
        """Some of Hierarchy's impact_of_* helpers don't all return the
        same dict shape (e.g. impact_of_file's hits have no 'dag' key,
        unlike impact_of_function/impact_of_target_type) -- normalize so
        every tool result the agent sees is consistently shaped."""
        task_to_dag = self._task_to_dag_map(h)
        out = []
        for hit in hits:
            hit = dict(hit)
            if "dag" not in hit and "task" in hit:
                hit["dag"] = task_to_dag.get(hit["task"], "")
            out.append(hit)
        return out

    # ------------------------------------------------------------ tools
    def list_changed_files(self) -> dict:
        """The starting map: every changed file with its change_type and a
        one-line summary of BOTH function-level deltas AND top-level
        (module import/constant, class attribute, whole-class) deltas --
        changes are not limited to inside function/method bodies, so
        always check both lists, not just function_level_changes."""
        out = []
        for fc in self.file_changes:
            func_summary = None
            top_summary = None
            if fc.is_python:
                func_summary = [f"{c.kind}:{(c.owner_class + '.' if c.owner_class else '')}{c.name}"
                                 + (" [body changed, no call delta -- inspect snippet]" if c.body_changed_beyond_calls else "")
                                 for c in fc.function_changes]
                top_summary = [f"{c.kind}:[{c.scope}]:{c.key}" for c in fc.top_level_changes]
            out.append({
                "old_path": fc.old_path, "new_path": fc.new_path, "change_type": fc.change_type,
                "is_python": fc.is_python,
                "function_level_changes": func_summary,
                "top_level_changes (module imports/constants, class attributes, whole classes)": top_summary,
            })
        return {"changed_files": out}

    def get_top_level_change_detail(self, file_path: str, key: str) -> dict:
        """Full old/new source for one specific module-level or
        class-attribute change (from top_level_changes above) -- e.g. an
        import, a constant, a config dict, or a class attribute."""
        fc = self._by_path.get(file_path)
        if not fc:
            return {"error": f"No changed file matches path '{file_path}'. Call list_changed_files first."}
        for c in fc.top_level_changes:
            if c.key == key:
                return {"key": c.key, "scope": c.scope, "kind": c.kind,
                        "old_snippet": c.old_snippet, "new_snippet": c.new_snippet}
        return {"error": f"No top-level change with key '{key}' found in {file_path}."}

    def get_function_change_detail(self, file_path: str, function_name: str) -> dict:
        """Full old/new source snippet and calls_added/calls_removed for
        one specific function/method change in one file."""
        fc = self._by_path.get(file_path)
        if not fc:
            return {"error": f"No changed file matches path '{file_path}'. Call list_changed_files first."}
        for c in fc.function_changes:
            if c.name == function_name:
                return {"name": c.name, "owner_class": c.owner_class, "kind": c.kind,
                        "calls_added": c.calls_added, "calls_removed": c.calls_removed,
                        "old_snippet": c.old_snippet, "new_snippet": c.new_snippet}
        return {"error": f"No function change named '{function_name}' found in {file_path}."}

    def get_raw_diff(self, file_path: str) -> dict:
        """The raw unified diff hunk for a changed file -- use this for
        non-Python files (yaml/sql/ini), or to see exact line-level
        changes for a Python file beyond the function-level summary."""
        fc = self._by_path.get(file_path)
        if not fc:
            return {"error": f"No changed file matches path '{file_path}'."}
        return {"file_path": file_path, "change_type": fc.change_type, "diff": fc.raw_diff or "(no diff text -- e.g. a pure rename)"}

    def get_callers_of_function(self, function_name: str, ref: str = "after") -> dict:
        """Every file that contains a call to this function/method NAME.
        Use ref="before" for a function/call that was REMOVED (to see who
        used to depend on it, since it no longer exists in the after
        state); default ref="after" for added/modified functions."""
        h = self._pick_hierarchy(ref)
        files = set()
        for dag, group, task in h.all_tasks():
            for m in list(task.methods) + list(task.call_chain):
                bare = m.name.rsplit(".", 1)[-1]
                if bare == function_name and m.called_from:
                    files.update(m.called_from)
        note = ("Empty means no task in this hierarchy calls this name directly or via its call-chain.")
        if ref == "before" and self.hierarchy_before is None:
            note += " WARNING: no separate before-state hierarchy was available; this used the after-state instead."
        return {"function_name": function_name, "ref": ref, "caller_files": sorted(files), "note": note}

    def get_tasks_using_method(self, function_or_method_name: str, ref: str = "after") -> dict:
        """Every DAG task whose resolved method OR call-chain includes this
        function/method name. Use ref="before" for removed functions/calls."""
        h = self._pick_hierarchy(ref)
        hits = self._normalize_hits(h, h.impact_of_function(function_or_method_name))
        return {"function_or_method_name": function_or_method_name, "ref": ref, "tasks": hits}

    def get_tasks_using_file(self, file_path: str, ref: str = "after") -> dict:
        """Every DAG task wired (directly or via call-chain) to a given
        file path -- substring match, so a bare filename like
        'db_utils.py' also works. Use ref="before" for a deleted/renamed
        file's OLD path."""
        h = self._pick_hierarchy(ref)
        hits = self._normalize_hits(h, h.impact_of_file(file_path))
        return {"file_path": file_path, "ref": ref, "tasks": hits}

    def get_tasks_using_target_type(self, target_type: str, ref: str = "after") -> dict:
        """Every DAG task that uses a given target_type -- use this for
        yaml/config changes (e.g. a changed insight_group_layout or rules
        file) to find which tasks are affected."""
        h = self._pick_hierarchy(ref)
        hits = self._normalize_hits(h, h.impact_of_target_type(target_type))
        return {"target_type": target_type, "ref": ref, "tasks": hits}

    def get_dag_hierarchy_summary(self, ref: str = "after") -> dict:
        """A compact list of every DAG and its top-level TaskGroups, for
        orientation -- use this once, early, if you need the lay of the
        land before diving into specific files/functions."""
        h = self._pick_hierarchy(ref)
        out = []
        for dag in h.dags:
            out.append({"dag_id": dag.dag_id, "top_level_groups": [g.group_id for g in dag.groups],
                        "top_level_tasks": [t.task_id for t in dag.tasks]})
        return {"ref": ref, "dags": out}


def make_tool_schemas() -> List[dict]:
    """OpenAI/Azure-OpenAI function-calling tool schemas, one per
    AgentToolbox method above."""
    def tool(name, description, params, required):
        return {"type": "function", "function": {
            "name": name, "description": description,
            "parameters": {"type": "object", "properties": params, "required": required},
        }}

    return [
        tool("list_changed_files",
             "Get the full list of changed files in this branch, with change_type "
             "(added/deleted/renamed/modified), a one-line function-level change summary, AND a "
             "one-line top-level change summary (module imports/constants, class attributes, whole "
             "classes added/removed) for Python files. Changes are NOT limited to inside function "
             "bodies -- always check both lists. ALWAYS call this first.",
             {}, []),
        tool("get_top_level_change_detail",
             "Get the full old/new source for one specific MODULE-level or CLASS-ATTRIBUTE change "
             "(from top_level_changes) -- e.g. a changed import, a module constant/config dict, or a "
             "class attribute that isn't a method.",
             {"file_path": {"type": "string"}, "key": {"type": "string"}}, ["file_path", "key"]),
        tool("get_function_change_detail",
             "Get the full old/new source and calls_added/calls_removed for one specific "
             "function/method change. If calls_added/calls_removed are both empty but the function "
             "is still marked 'modified', the change is something other than a call (e.g. a changed "
             "literal, condition, or logic) -- read old_snippet vs new_snippet to see exactly what.",
             {"file_path": {"type": "string"}, "function_name": {"type": "string"}},
             ["file_path", "function_name"]),
        tool("get_raw_diff",
             "Get the raw unified diff for a changed file -- required for non-Python "
             "(yaml/sql/ini) files, optional for deeper line-level detail on Python files.",
             {"file_path": {"type": "string"}}, ["file_path"]),
        tool("get_callers_of_function",
             "Find every file that calls a given function/method name anywhere in the "
             "indexed codebase. Use ref='before' for a REMOVED function/call (to see who used "
             "to depend on it); ref='after' (default) for added/modified ones.",
             {"function_name": {"type": "string"},
              "ref": {"type": "string", "enum": ["before", "after"], "description": "default 'after'"}},
             ["function_name"]),
        tool("get_tasks_using_method",
             "Find every DAG task that actually executes a given function/method name today "
             "(directly or via its call-chain). This is the primary structural-reachability check. "
             "Use ref='before' for a REMOVED function.",
             {"function_or_method_name": {"type": "string"},
              "ref": {"type": "string", "enum": ["before", "after"], "description": "default 'after'"}},
             ["function_or_method_name"]),
        tool("get_tasks_using_file",
             "Find every DAG task wired to a given file path (substring match). Use ref='before' "
             "with the OLD path for a deleted/renamed file.",
             {"file_path": {"type": "string"},
              "ref": {"type": "string", "enum": ["before", "after"], "description": "default 'after'"}},
             ["file_path"]),
        tool("get_tasks_using_target_type",
             "Find every DAG task that uses a given target_type -- use for yaml/config changes.",
             {"target_type": {"type": "string"},
              "ref": {"type": "string", "enum": ["before", "after"], "description": "default 'after'"}},
             ["target_type"]),
        tool("get_dag_hierarchy_summary",
             "Get a compact overview of every DAG and its top-level TaskGroups/tasks, for orientation.",
             {"ref": {"type": "string", "enum": ["before", "after"], "description": "default 'after'"}}, []),
        tool("finalize_report",
             "Call this EXACTLY ONCE, when you have gathered enough evidence to make a final, "
             "confident impact determination for every change. This ends the analysis.",
             {
                 "changes": {
                     "type": "array",
                     "description": "One entry per DISTINCT change you identified (a function change, "
                                     "a file rename, a config value change, etc.) -- not one entry per file.",
                     "items": {
                         "type": "object",
                         "properties": {
                             "file": {"type": "string"},
                             "change_description": {"type": "string",
                                 "description": "Plain-English description of exactly what changed."},
                             "change_kind": {"type": "string",
                                 "enum": ["function_added", "function_removed", "function_modified",
                                           "call_added", "call_removed", "function_body_changed_non_call",
                                           "file_renamed", "file_added", "file_deleted",
                                           "module_import_changed", "module_constant_changed",
                                           "class_attribute_changed", "class_added", "class_removed",
                                           "config_value_changed", "other"]},
                             "has_impact": {"type": "boolean",
                                 "description": "false if you determined this change has NO meaningful "
                                                 "downstream impact (e.g. a comment, an unreachable "
                                                 "private helper, a brand-new function nothing calls yet)."},
                             "impacted_dags": {"type": "array", "items": {"type": "string"}},
                             "impacted_task_groups": {"type": "array", "items": {"type": "string"}},
                             "impacted_tasks": {"type": "array", "items": {"type": "string"}},
                             "impacted_methods": {"type": "array", "items": {"type": "string"}},
                             "impact_reasoning": {"type": "string",
                                 "description": "WHY -- cite specific evidence from the tools you called "
                                                 "(caller files, task names, etc.), or explain why there "
                                                 "is no impact."},
                             "testing_scope_note": {"type": "string",
                                 "description": "One sentence: what should a tester specifically verify "
                                                 "because of this change?"},
                         },
                         "required": ["file", "change_description", "change_kind", "has_impact",
                                       "impact_reasoning"],
                     },
                 },
                 "overall_summary": {"type": "string",
                     "description": "2-4 sentences: overall testing scope for this branch as a whole."},
                 "functional_summary": {"type": "string",
                     "description": "3-6 sentences explaining, for someone who has NOT read the code, "
                                     "what this branch actually DOES: the functional/business purpose "
                                     "(what capability changed, for which products/target_types/insight "
                                     "types) AND the technical means (which files/functions/methods "
                                     "changed to achieve it). Write it so a reader who understands the "
                                     "business but not the code can understand the 'why', and a reader "
                                     "who knows the code but not the business context can understand the "
                                     "'what changed technically'. This is distinct from overall_summary "
                                     "(which is about testing scope) -- this is about explaining the "
                                     "PURPOSE of the change."},
             },
             ["changes", "overall_summary", "functional_summary"]),
    ]
