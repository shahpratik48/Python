"""
CID (client-identifying) attribute masking compliance check.

Deterministic and rule-based -- unlike the impact-assessment agent, these
are clear-cut policy violations, not judgment calls, so no LLM is
involved here.

Grounded in the real repo structure:
  - config/input_data_config/<target_type>.yml has a top-level
    <target_type>: {sql_column_mapping: {attr: sql_expr, ...}} block with
    the REAL (unmasked) SQL expression per attribute.
  - config/input_data_config_dummy/<target_type>.yml mirrors that same
    structure, but CID attributes are masked, e.g.
    `ip_frst_x: substring(MD5(b.ip_frst_x),1,8)`. An attribute is
    considered CID here if it appears with an MD5(...) expression
    ANYWHERE in input_data_config_dummy -- that's the working definition
    used throughout this module.
  - sql_column_mapping/<target_type>/**/*.yml files are flat
    {attr: sql_expr} dicts (a different, per-insight_type mapping,
    distinct from the inline sql_column_mapping key inside
    input_data_config).

Three checks:
  1. config/input_data_config_dummy/<target_type>.yml should exist
     alongside config/input_data_config/<target_type>.yml -- checked on
     both the branch and the base branch.
  2. A known-CID attribute present in config/input_data_config/<tt>.yml
     must have a masked (MD5-wrapped) counterpart in
     config/input_data_config_dummy/<tt>.yml -- flagged as high severity
     if the attribute was newly added on this branch, medium if it's a
     pre-existing gap the branch didn't introduce.
  3. A known-CID attribute already defined in
     config/input_data_config/<tt>.yml must NOT also appear as a key in
     any config/sql_column_mapping/<tt>/**/*.yml file.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None

MD5_PATTERN = re.compile(r"\bmd5\s*\(", re.IGNORECASE)
INPUT_DATA_CONFIG_PREFIX = "config/input_data_config/"
INPUT_DATA_CONFIG_DUMMY_PREFIX = "config/input_data_config_dummy/"
SQL_COLUMN_MAPPING_PREFIX = "sql_column_mapping/"


@dataclass
class CidViolation:
    target_type: str
    attribute: str
    violation_type: str   # "missing_dummy_file" | "cid_not_masked_in_dummy" | "cid_duplicated_in_sql_column_mapping"
    detail: str
    severity: str = "high"


def _load_yaml_dict(raw_files: Dict[str, str], path: str) -> dict:
    if yaml is None or path not in raw_files:
        return {}
    try:
        data = yaml.safe_load(raw_files[path])
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def _sql_column_mapping_of(raw_files: Dict[str, str], path: str, target_type: str) -> dict:
    data = _load_yaml_dict(raw_files, path)
    inner = data.get(target_type, data)  # files nest under the target_type key, same convention as context_gatherer.py
    if isinstance(inner, dict):
        mapping = inner.get("sql_column_mapping", {})
        return mapping if isinstance(mapping, dict) else {}
    return {}


def _target_types_from_input_data_config(raw_files: Dict[str, str]) -> Set[str]:
    out = set()
    for path in raw_files:
        if path.startswith(INPUT_DATA_CONFIG_PREFIX) and path.endswith((".yml", ".yaml")):
            name = path[len(INPUT_DATA_CONFIG_PREFIX):].rsplit(".", 1)[0]
            if "/" not in name:
                out.add(name)
    return out


def build_global_cid_registry(raw_files: Dict[str, str]) -> Set[str]:
    """Every attribute name masked with MD5(...) ANYWHERE across all
    input_data_config_dummy files -- the working definition of "this
    attribute name is CID" used by every check in this module."""
    registry = set()
    for path in raw_files:
        if not (path.startswith(INPUT_DATA_CONFIG_DUMMY_PREFIX) and path.endswith((".yml", ".yaml"))):
            continue
        tt = path[len(INPUT_DATA_CONFIG_DUMMY_PREFIX):].rsplit(".", 1)[0]
        mapping = _sql_column_mapping_of(raw_files, path, tt)
        for attr, expr in mapping.items():
            if isinstance(expr, str) and MD5_PATTERN.search(expr):
                registry.add(attr)
    return registry


def check_cid_compliance(hierarchy_after, hierarchy_before=None,
                          branch_name: str = "branch", base_branch_name: str = "base branch") -> List[CidViolation]:
    """Runs all three checks against the branch's current state
    (hierarchy_after), using hierarchy_before (if provided) both to know
    which attributes were newly added on this branch (for severity) and
    to confirm the dummy file also exists on the base branch."""
    violations: List[CidViolation] = []
    raw_after = hierarchy_after.src_index.raw_files
    raw_before = hierarchy_before.src_index.raw_files if hierarchy_before else {}

    global_cid = build_global_cid_registry(raw_after)
    if raw_before:
        global_cid |= build_global_cid_registry(raw_before)

    for tt in sorted(_target_types_from_input_data_config(raw_after)):
        real_path = f"{INPUT_DATA_CONFIG_PREFIX}{tt}.yml"
        dummy_path = f"{INPUT_DATA_CONFIG_DUMMY_PREFIX}{tt}.yml"

        if dummy_path not in raw_after:
            violations.append(CidViolation(
                tt, "(file)", "missing_dummy_file",
                f"{dummy_path} does not exist on '{branch_name}', but {real_path} does.",
            ))
        if raw_before and dummy_path not in raw_before:
            violations.append(CidViolation(
                tt, "(file)", "missing_dummy_file",
                f"{dummy_path} does not exist on '{base_branch_name}' either, but {real_path} does.",
                severity="medium",
            ))
        if dummy_path not in raw_after:
            continue

        real_mapping_after = _sql_column_mapping_of(raw_after, real_path, tt)
        real_mapping_before = _sql_column_mapping_of(raw_before, real_path, tt) if raw_before else {}
        dummy_mapping_after = _sql_column_mapping_of(raw_after, dummy_path, tt)
        added_attrs = (set(real_mapping_after) - set(real_mapping_before)) if raw_before else set()

        for attr in sorted(real_mapping_after):
            if attr not in global_cid:
                continue

            dummy_expr = dummy_mapping_after.get(attr)
            is_masked = isinstance(dummy_expr, str) and MD5_PATTERN.search(dummy_expr)
            is_newly_added = attr in added_attrs
            if not is_masked:
                violations.append(CidViolation(
                    tt, attr, "cid_not_masked_in_dummy",
                    f"'{attr}' is a known CID attribute" + (" newly added" if is_newly_added else "") +
                    f" in {real_path}, but is missing or not MD5-masked in {dummy_path}.",
                    severity="high" if is_newly_added else "medium",
                ))

            for path in raw_after:
                if not (path.startswith(f"{SQL_COLUMN_MAPPING_PREFIX}{tt}/") and path.endswith((".yml", ".yaml"))):
                    continue
                flat = _load_yaml_dict(raw_after, path)
                if attr in flat:
                    violations.append(CidViolation(
                        tt, attr, "cid_duplicated_in_sql_column_mapping",
                        f"'{attr}' is a CID attribute already defined in {real_path}, but is also present "
                        f"in {path} (sql_column_mapping/) -- should not be duplicated there.",
                    ))

    return violations
