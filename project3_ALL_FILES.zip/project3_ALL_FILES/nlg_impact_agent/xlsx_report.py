"""
Exports an ImpactReport (agent.py) to a workbook with:

  1. `Change Impact Detail` -- same DAG/sub-DAG/TaskGroup/task/method/file
     shape as Project 1's DAG Hierarchy sheet, one row per (change,
     impacted task) pair, PLUS the requested "Change & Impact" column
     describing exactly what changed and why it does/doesn't matter.
  2. `Changes (no task match)` -- changes the agent judged to have no
     current DAG-level impact (new/unreachable code, removed-but-unused
     code, cosmetic changes), still listed for visibility/audit, not lost.
  3. `Testing Scope Summary` -- every unique impacted DAG / TaskGroup /
     task / method / file, for deciding what to test, plus the overall
     narrative summary.
  4. `README` legend sheet.
"""
from __future__ import annotations

from typing import List

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

from .agent import ImpactReport
from .transcript_format import _truncate, _pretty

HEADER_FONT = Font(name="Arial", bold=True, color="FFFFFF")
HEADER_FILL = PatternFill(start_color="305496", end_color="305496", fill_type="solid")
IMPACT_FILL = PatternFill(start_color="FDEDED", end_color="FDEDED", fill_type="solid")
NO_IMPACT_FILL = PatternFill(start_color="EAF6EC", end_color="EAF6EC", fill_type="solid")
BODY_FONT = Font(name="Arial", size=10)
WRAP = Alignment(vertical="top", wrap_text=True)


def _style_sheet(ws, col_widths: List[int]):
    ws.freeze_panes = "A2"
    for cell in ws[1]:
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(vertical="center", horizontal="center", wrap_text=True)
    ws.auto_filter.ref = ws.dimensions
    for i, w in enumerate(col_widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.font = BODY_FONT
            cell.alignment = WRAP


def _write_detail_sheet(wb: Workbook, report: ImpactReport):
    ws = wb.create_sheet("Change Impact Detail")
    headers = ["Change & Impact", "File", "Change Kind", "Has Impact", "DAG", "Sub-DAG / TaskGroup",
               "Task", "Method / Function", "Impacted Method(s)", "Impact Reasoning", "Testing Scope Note"]
    ws.append(headers)

    no_match_rows = []
    for c in report.changes:
        change_impact = f"{c.get('change_description', '')}"
        impacted_dags = c.get("impacted_dags") or []
        impacted_groups = c.get("impacted_task_groups") or []
        impacted_tasks = c.get("impacted_tasks") or []
        impacted_methods = c.get("impacted_methods") or []
        has_impact = bool(c.get("has_impact"))

        rows_written = 0
        if impacted_tasks:
            for i, task in enumerate(impacted_tasks):
                ws.append([change_impact, c.get("file", ""), c.get("change_kind", ""), "Y" if has_impact else "N",
                           (impacted_dags[i] if i < len(impacted_dags) else (impacted_dags[0] if impacted_dags else "")),
                           (impacted_groups[i] if i < len(impacted_groups) else ""),
                           task, c.get("file", ""), ", ".join(impacted_methods),
                           c.get("impact_reasoning", ""), c.get("testing_scope_note", "")])
                rows_written += 1
        elif impacted_dags:
            for dag in impacted_dags:
                ws.append([change_impact, c.get("file", ""), c.get("change_kind", ""), "Y" if has_impact else "N",
                           dag, "", "", c.get("file", ""), ", ".join(impacted_methods),
                           c.get("impact_reasoning", ""), c.get("testing_scope_note", "")])
                rows_written += 1
        if rows_written == 0:
            no_match_rows.append(c)

    widths = [40, 34, 20, 10, 22, 26, 32, 30, 30, 50, 40]
    _style_sheet(ws, widths)
    impact_col = 4
    for row in ws.iter_rows(min_row=2):
        fill = IMPACT_FILL if row[impact_col - 1].value == "Y" else NO_IMPACT_FILL
        for cell in row:
            cell.fill = fill
    return ws, no_match_rows


def _write_no_match_sheet(wb: Workbook, no_match_rows: List[dict]):
    ws = wb.create_sheet("Changes (no task match)")
    headers = ["Change & Impact", "File", "Change Kind", "Has Impact", "Impact Reasoning", "Testing Scope Note"]
    ws.append(headers)
    for c in no_match_rows:
        ws.append([c.get("change_description", ""), c.get("file", ""), c.get("change_kind", ""),
                   "Y" if c.get("has_impact") else "N", c.get("impact_reasoning", ""),
                   c.get("testing_scope_note", "")])
    widths = [45, 34, 20, 10, 55, 40]
    _style_sheet(ws, widths)
    return ws


def _write_summary_sheet(wb: Workbook, report: ImpactReport):
    ws = wb.create_sheet("Summary")
    ws.column_dimensions["A"].width = 30
    ws.column_dimensions["B"].width = 100

    dags, groups, tasks, methods, files = set(), set(), set(), set(), set()
    n_impact, n_no_impact = 0, 0
    for c in report.changes:
        if c.get("has_impact"):
            n_impact += 1
        else:
            n_no_impact += 1
        dags.update(c.get("impacted_dags") or [])
        groups.update(c.get("impacted_task_groups") or [])
        tasks.update(c.get("impacted_tasks") or [])
        methods.update(c.get("impacted_methods") or [])
        if c.get("file"):
            files.add(c["file"])

    header_rows = [
        ("Branch", report.branch),
        ("Base branch", report.base_branch),
        ("Commits in range", str(len(report.compare.commits))),
        ("Files changed (in scope)", str(len(report.compare.diffs))),
        ("", ""),
        ("What this branch does", report.functional_summary or "(not provided)"),
        ("", ""),
        ("Testing scope summary", report.overall_summary),
        ("", ""),
    ]
    for r in header_rows:
        ws.append(r)
    bold_rows = list(range(1, 5)) + [6, 8]

    ws.append(("Changes in this branch, one row each", ""))
    change_table_header_row = ws.max_row + 1
    ws.append(("File", "What changed / why it matters"))
    for c in report.changes:
        combined = c.get("change_description", "")
        if c.get("impact_reasoning"):
            combined += "  |  " + c["impact_reasoning"]
        if c.get("testing_scope_note"):
            combined += "  |  Test: " + c["testing_scope_note"]
        ws.append((c.get("file", ""), combined))

    ws.append(("", ""))
    footer_start = ws.max_row + 1
    footer_rows = [
        ("Distinct changes assessed", str(len(report.changes))),
        ("Changes WITH impact", str(n_impact)),
        ("Changes with NO current impact", str(n_no_impact)),
        ("", ""),
        ("Impacted DAGs", ", ".join(sorted(dags)) or "(none)"),
        ("Impacted TaskGroups", ", ".join(sorted(groups)) or "(none)"),
        ("Impacted Tasks", ", ".join(sorted(tasks)) or "(none)"),
        ("Impacted Methods/Functions", ", ".join(sorted(methods)) or "(none)"),
        ("Changed Files", ", ".join(sorted(files)) or "(none)"),
    ]
    for r in footer_rows:
        ws.append(r)

    for row in ws.iter_rows():
        for cell in row:
            cell.font = BODY_FONT
            cell.alignment = WRAP
    for i in bold_rows + [change_table_header_row - 1, change_table_header_row] + \
             list(range(footer_start, footer_start + len(footer_rows))):
        if i <= ws.max_row:
            ws.cell(row=i, column=1).font = Font(name="Arial", bold=True)
    for cell in ws[change_table_header_row]:
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
    return ws


def _write_transcript_sheet(wb: Workbook, report: ImpactReport):
    ws = wb.create_sheet("Tool Call Transcript")
    headers = ["Step", "Tool Called", "Arguments", "Result (truncated for readability)"]
    ws.append(headers)

    step = 0
    for msg in report.transcript:
        role = msg.get("role")
        if role == "assistant" and msg.get("tool_calls"):
            for tc in msg["tool_calls"]:
                step += 1
                name = tc.get("function", {}).get("name", "?")
                raw_args = tc.get("function", {}).get("arguments") or "{}"
                import json as _json
                try:
                    args = _json.loads(raw_args)
                except Exception:
                    args = raw_args
                label = "FINAL: finalize_report" if name == "finalize_report" else name
                ws.append([step, label, _pretty(args), ""])
        elif role == "tool":
            import json as _json
            raw = msg.get("content", "")
            try:
                parsed = _json.loads(raw)
                parsed = _truncate(parsed, max_list_items=8, max_str_len=500)
                pretty = _pretty(parsed)
            except Exception:
                pretty = raw[:500]
            if ws.max_row > 1:
                ws.cell(row=ws.max_row, column=4, value=pretty)

    widths = [8, 30, 45, 65]
    _style_sheet(ws, widths)
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.font = Font(name="Consolas", size=9)
            cell.alignment = WRAP
    if step == 0:
        ws.append(["-", "(no tool calls recorded in this transcript)", "", ""])
    return ws, step


def _write_cid_compliance_sheet(wb: Workbook, report: ImpactReport):
    ws = wb.create_sheet("CID Masking Compliance")
    headers = ["Severity", "Violation Type", "Basis", "Target Type", "Attribute", "Detail"]
    ws.append(headers)
    severity_order = {"high": 0, "medium": 1, "low": 2}
    violations = sorted(report.cid_violations, key=lambda v: severity_order.get(v.severity, 9))
    for v in violations:
        ws.append([v.severity.upper(), v.violation_type, v.basis, v.target_type, v.attribute, v.detail])
    widths = [12, 34, 16, 22, 30, 68]
    _style_sheet(ws, widths)
    high_fill = PatternFill(start_color="FDEDED", end_color="FDEDED", fill_type="solid")
    med_fill = PatternFill(start_color="FBF7EC", end_color="FBF7EC", fill_type="solid")
    for row in ws.iter_rows(min_row=2):
        fill = high_fill if row[0].value == "HIGH" else (med_fill if row[0].value == "MEDIUM" else None)
        if fill:
            for cell in row:
                cell.fill = fill
    return ws, len(violations)


def _write_legend_sheet(wb: Workbook):
    ws = wb.create_sheet("README", 0)
    ws.column_dimensions["A"].width = 30
    ws.column_dimensions["B"].width = 105
    rows = [
        ("Workbook", "Branch change-impact analysis, produced by an LLM agent that autonomously "
                      "inspected the actual code diff and the current DAG hierarchy to determine "
                      "exact impact -- not a simple 'file touched = everything impacted' heuristic."),
        ("Sheet: Change Impact Detail", "One row per (change, impacted task) pair. 'Change & Impact' "
                                          "describes exactly what changed; 'Has Impact' / row color "
                                          "(red = impact, green = no impact) shows the agent's "
                                          "determination; 'Impact Reasoning' cites the specific "
                                          "evidence (task/caller counts, etc.) the agent used."),
        ("Sheet: Changes (no task match)", "Changes the agent investigated but found no impacted DAG "
                                            "task for (e.g. a new function nothing calls yet, an unused "
                                            "removed helper, a cosmetic change) -- kept visible for audit "
                                            "rather than silently dropped."),
        ("Sheet: Summary", "Start here. What this branch does (functional purpose AND technical means, "
                             "in plain language), the testing-scope summary, a plain-English row for "
                             "every distinct change in the branch, and a roll-up of every unique "
                             "impacted DAG/TaskGroup/task/method/file."),
        ("Sheet: CID Masking Compliance", "Deterministic-first, rule-based check -- NOT part of the "
                                            "agent's tool-calling loop, and SCOPED to this branch: only "
                                            "attributes that were actually added or modified by this "
                                            "branch, in a config/input_data_config/<tt>.yml file this "
                                            "branch itself changed, are ever checked -- not a whole-"
                                            "repository audit. An attribute is treated as CID (client-"
                                            "identifying) via any of three signals, shown in the Basis "
                                            "column: 'md5_registry' -- it's already MD5-masked somewhere "
                                            "in config/input_data_config_dummy/ (an established pattern, "
                                            "checked first, free); 'name_heuristic' -- its name matches a "
                                            "known PII pattern (email, ssn, phone, dob, address, account/"
                                            "client name, etc. -- checked second, free; attribute names "
                                            "that look like boolean flags, e.g. has_email or email_flag, "
                                            "are explicitly excluded, since a flag indicating presence of "
                                            "data is not itself the data); 'llm_judgment' -- not caught "
                                            "by either of the above, so an LLM is asked to judge the "
                                            "attribute name and its SQL expression (given the target_"
                                            "type's already-known CID attributes as calibration examples) "
                                            "-- checked last, only for genuinely ambiguous attributes, so "
                                            "cost stays bounded to however many changed attributes an "
                                            "actual branch introduces. All three signals except "
                                            "md5_registry should be spot-checked manually -- they are "
                                            "signals, not certainties. Flags: (1) a target_type's dummy "
                                            "file missing on the branch and/or base branch, for "
                                            "target_types this branch changed; (2) a CID attribute added "
                                            "or modified by this branch in config/input_data_config/<tt>."
                                            "yml with no masked counterpart in the dummy file (HIGH "
                                            "severity if newly added, MEDIUM if modified but still "
                                            "unmasked); (3) a CID attribute added/changed by this branch "
                                            "that also appears in a sql_column_mapping/<tt>/**/*.yml file "
                                            "for the same target_type, where it should not be duplicated."),
        ("Sheet: Tool Call Transcript", "Every question the agent asked and every answer it got back, in "
                                          "order -- the literal audit trail behind every conclusion in "
                                          "this workbook. Long results (e.g. a 92-task list) are "
                                          "automatically shortened to the first few items plus a count, "
                                          "so it stays readable."),
        ("Why this needs an agent, not just parsing", "Parsing the codebase into a hierarchy of DAGs, "
                                              "tasks, and methods is pure static analysis -- deterministic, "
                                              "no judgment calls needed. Deciding whether a SPECIFIC code "
                                              "change actually matters is different: it is not a lookup -- "
                                              "an LLM agent autonomously inspects the diff and the "
                                              "hierarchy (via tool calls it chooses itself, in whatever "
                                              "order and however many times it needs) and reasons about "
                                              "each change individually before concluding."),
    ]
    for r in rows:
        ws.append(r)
    for row in ws.iter_rows():
        for cell in row:
            cell.font = BODY_FONT
            cell.alignment = WRAP
    ws["A1"].font = Font(name="Arial", bold=True, size=13)
    for i in range(2, len(rows) + 1):
        ws.cell(row=i, column=1).font = Font(name="Arial", bold=True)
    return ws


def default_output_filename(report: ImpactReport, prefix: str = "change_impact") -> str:
    """Branch-aware default filename, e.g. change_impact_feature_my-change.xlsx.
    Sanitizes the branch name (replaces '/' and any other filesystem-unsafe
    character with '_') so it's always safe to use directly as a filename,
    regardless of how the branch itself is named (feature/x, release/2026.3,
    etc.)."""
    import re
    safe_branch = re.sub(r"[^A-Za-z0-9._-]+", "_", report.branch).strip("_")
    return f"{prefix}_{safe_branch}.xlsx"


def export_xlsx(report: ImpactReport, output_path: str) -> str:
    wb = Workbook()
    wb.remove(wb.active)

    _, no_match_rows = _write_detail_sheet(wb, report)
    _write_no_match_sheet(wb, no_match_rows)
    _write_summary_sheet(wb, report)
    _write_cid_compliance_sheet(wb, report)
    _write_transcript_sheet(wb, report)
    _write_legend_sheet(wb)

    import os
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    wb.save(output_path)
    return output_path
