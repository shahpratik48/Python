"""
Thin client around GitLab's repository `compare` API -- the actual source
of truth for "what changed between branch and base_branch": which files
were added, modified, deleted, or renamed, the commits in between, and a
unified diff per file. No local git clone involved.

https://docs.gitlab.com/ee/api/repositories.html#compare-branches-tags-or-commits
"""
from __future__ import annotations

import urllib.parse
from dataclasses import dataclass, field
from typing import List, Optional

from nlg_impact_agent.config import ImpactSettings


@dataclass
class FileDiff:
    old_path: str
    new_path: str
    diff: str                  # unified diff text (may be empty for pure renames with no content change)
    new_file: bool = False
    deleted_file: bool = False
    renamed_file: bool = False
    change_type: str = ""      # "added" | "deleted" | "renamed" | "modified" -- derived, see below

    def __post_init__(self):
        if self.new_file:
            self.change_type = "added"
        elif self.deleted_file:
            self.change_type = "deleted"
        elif self.renamed_file:
            self.change_type = "renamed"
        else:
            self.change_type = "modified"


@dataclass
class CommitInfo:
    id: str
    short_id: str
    title: str
    author_name: str
    created_at: str


@dataclass
class CompareResult:
    branch: str
    base_branch: str
    base_commit_sha: Optional[str]
    head_commit_sha: Optional[str]
    commits: List[CommitInfo] = field(default_factory=list)
    diffs: List[FileDiff] = field(default_factory=list)

    def changed_python_files(self) -> List[FileDiff]:
        return [d for d in self.diffs if (d.new_path.endswith(".py") or d.old_path.endswith(".py"))]

    def changed_non_python_files(self) -> List[FileDiff]:
        return [d for d in self.diffs if not (d.new_path.endswith(".py") or d.old_path.endswith(".py"))]


def _project_id_lookup(requests_mod, base_url: str, project_path: str, token: str) -> int:
    encoded = urllib.parse.quote(project_path, safe="")
    url = f"{base_url.rstrip('/')}/api/v4/projects/{encoded}"
    r = requests_mod.get(url, headers={"PRIVATE-TOKEN": token}, timeout=30)
    r.raise_for_status()
    return r.json()["id"]


def get_compare(settings: ImpactSettings) -> CompareResult:
    """Calls GitLab's `repository/compare` endpoint for
    from=base_branch, to=branch, restricted to nlg-dags' own subtree
    (dags/nlg/dags + dags/nlg/src). Deliberately does NOT pass straight=true:
    GitLab's default (straight=false) diffs from the MERGE BASE of
    base_branch and branch, not from base_branch's current tip -- so this
    isolates exactly the commits made ON the branch itself, regardless of
    how far base_branch has moved forward independently since the branch
    was created. (straight=true would diff the two tips directly, which
    would incorrectly pull in base_branch's own forward progress as if it
    were part of the branch's changes.)"""
    import requests
    project_id = _project_id_lookup(requests, settings.gitlab_url, settings.nlg_project_path, settings.gitlab_token)
    url = f"{settings.gitlab_url.rstrip('/')}/api/v4/projects/{project_id}/repository/compare"
    params = {"from": settings.base_branch, "to": settings.branch}
    r = requests.get(url, headers={"PRIVATE-TOKEN": settings.gitlab_token}, params=params, timeout=120)
    r.raise_for_status()
    data = r.json()

    commits = [CommitInfo(id=c.get("id", ""), short_id=c.get("short_id", ""), title=c.get("title", ""),
                            author_name=c.get("author_name", ""), created_at=c.get("created_at", ""))
               for c in data.get("commits", [])]

    prefix_dags = settings.nlg_dags_subpath.strip("/") + "/"
    prefix_src = settings.nlg_src_subpath.strip("/") + "/"

    diffs = []
    for d in data.get("diffs", []):
        old_path, new_path = d.get("old_path", ""), d.get("new_path", "")
        # only files inside nlg-dags' own dags/src subtrees are in scope
        in_scope = any(p.startswith(prefix_dags) or p.startswith(prefix_src) for p in (old_path, new_path) if p)
        if not in_scope:
            continue
        diffs.append(FileDiff(
            old_path=_strip_known_prefix(old_path, prefix_dags, prefix_src),
            new_path=_strip_known_prefix(new_path, prefix_dags, prefix_src),
            diff=d.get("diff", ""),
            new_file=bool(d.get("new_file")), deleted_file=bool(d.get("deleted_file")),
            renamed_file=bool(d.get("renamed_file")),
        ))

    commit_block = data.get("commit") or {}
    return CompareResult(
        branch=settings.branch, base_branch=settings.base_branch,
        base_commit_sha=data.get("diff_refs", {}).get("base_sha") if isinstance(data.get("diff_refs"), dict) else None,
        head_commit_sha=commit_block.get("id"),
        commits=commits, diffs=diffs,
    )


def _strip_known_prefix(path: str, *prefixes: str) -> str:
    if not path:
        return path
    for p in prefixes:
        if path.startswith(p):
            return path[len(p):]
    return path
