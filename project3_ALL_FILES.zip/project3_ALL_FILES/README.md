# nlg_impact_agent (Project 3)

A **genuinely agentic** branch change-impact analyzer -- similar in spirit to
Project 1 (reuses its LLM/GitLab/DB configuration and its DAG hierarchy for
structural reachability), but a fundamentally different kind of system: where
Project 1 is deterministic parsing, this project has to make **judgment
calls** about whether a specific code change actually matters, and that
judgment is delegated to an LLM **agent** that autonomously investigates the
codebase via tool calls it chooses itself.

## What "agent" means here, concretely

Given a branch, most of the pipeline is the same kind of deterministic static
analysis as Projects 1/2 (see "What's deterministic" below) -- but the last,
essential step cannot be: **whether a given change has real downstream
impact isn't a lookup, it's a judgment call.** A brand-new function nothing
calls yet, a comment-only change, and a change to a function used by 90+
tasks should NOT be treated the same way just because they're all "changes."

So the agent is handed:
- the full changeset (which files/functions/calls changed, and how)
- **tools** to query the DAG hierarchy (which tasks execute which code,
  today, both before and after the change)

and is told to investigate however it sees fit -- there is no scripted
sequence of tool calls. It decides which changes need a closer look, which
tool answers a given question, whether to double-check a surprising result,
and when it has enough evidence to conclude. Only once it's confident does it
call `finalize_report` with its reasoned, evidence-cited conclusions.

## Changes aren't limited to inside a function/method

A code change can happen anywhere: inside a function/method body, but also
as a module-level import, a module-level constant/config dict, a
class-level attribute (not a method), or a whole class added/removed.
`change_analyzer.py`'s `diff_top_level()` covers all of these, separately
from `diff_functions()` -- and `list_changed_files()` always returns both
lists, with the system prompt explicitly instructing the agent to check
both rather than assume changes only happen inside function bodies.
Validated against a real 8-change scenario (function/call-level changes
plus a new module constant, a modified import, and a class attribute) --
every category detected correctly, including a case where a function body
changed (a call's *arguments* changed) without any call being added or
removed, which now surfaces an explicit "body changed, no call delta --
inspect snippet" flag so the agent doesn't mistake "no new calls" for "no
change."

## What's deterministic vs. what's agentic

| Step | How |
|---|---|
| Find changed files (added/modified/deleted/renamed) | GitLab Compare API -- deterministic, `git_diff.py` |
| Find changed functions/methods, and changed calls within them | AST diff -- deterministic, `change_analyzer.py` |
| Build the DAG/TaskGroup/Task hierarchy (before AND after) | Reuses `nlg_dag_agent.build_hierarchy()` verbatim -- deterministic |
| Decide whether a specific change has real impact, and on what | **The LLM agent**, via autonomous tool use -- `agent.py` / `agent_tools.py` / `agent_llm_client.py` |

Keeping the first three deterministic means every tool the agent calls
returns trustworthy, reproducible facts -- the agent's only real job is
*interpreting* those facts, not gathering them from scratch.

## Validated end-to-end (mocked LLM, real code + real hierarchy)

No live LLM/GitLab access is available in this development environment, so
the agent's tool-calling loop itself was validated with a scripted mock LLM
that calls the SAME tools a real model would, against a real, controlled
6-change scenario built from the actual repo content (a modified dispatch
call, a new unreachable function, a removed unused function, a file rename,
a config value change, and a comment-only change). Every tool correctly
answered against Project 1's real hierarchy:

- The modified call inside `generate_rule_narratives` -> **92 tasks** found
  via `get_tasks_using_method` (correctly identified as wide impact).
- The new `validate_narrative_output` function -> **0 tasks** (correctly
  `has_impact: false` -- nothing calls it yet).
- The removed `chunk_string_with_split` -> **0 callers** in the before-state
  (correctly `has_impact: false` -- it was unused).
- The `db_utils.py -> database_utils.py` rename -> **68 tasks** routed
  through the old path in the before-state (correctly flagged high-risk).
- The yaml `materiality` change -> **5 tasks** using `client_bknight`
  (correctly scoped, not overstated to "everything").
- The comment-only change -> didn't even register as a function-level change
  in the first place (AST-identical detection filtered it out before the
  agent ever saw it).

Only the actual LLM call (deciding *when* to call which tool, and writing
the final reasoning text) is unverified here, for lack of network access to
a real endpoint -- the mechanics it runs on (dispatch, message threading,
termination, and the tools' answers) are proven correct against real data.

## Only the branch's own commits are analyzed -- never develop's independent progress

`git_diff.py` diffs from the **merge base** of `branch` and `base_branch`,
not from `base_branch`'s current tip. This matters: if `develop` moves
forward with unrelated commits after your branch was created, a direct
tip-to-tip diff would incorrectly attribute develop's own progress to your
branch. The merge-base diff isolates exactly the commits made *on the
branch itself*, regardless of how far `develop` has moved since. `develop`
(or whatever `base_branch` is) is used only as the comparison point for
computing the text/AST diff and as the "before" state for reachability
checks -- never as a source of changes to report on.

## CID attribute masking compliance (deterministic, not agentic)

A separate, rule-based check -- no LLM involved, since these are clear
policy violations rather than judgment calls. An attribute is treated as
CID (client-identifying) if it's MD5-masked anywhere in
`config/input_data_config_dummy/`. Three checks, run automatically as part
of every `analyze_branch_impact()` call and available at
`report.cid_violations`:

1. **Dummy file parity** -- `config/input_data_config_dummy/<target_type>.yml`
   should exist alongside `config/input_data_config/<target_type>.yml`, on
   both the branch and the base branch.
2. **Unmasked CID attribute** -- a known-CID attribute present in
   `input_data_config/<tt>.yml` must have a masked (MD5-wrapped) counterpart
   in the corresponding `input_data_config_dummy/<tt>.yml` -- HIGH severity
   if it was newly added on this branch, MEDIUM if it's a pre-existing gap.
3. **CID attribute duplicated in `sql_column_mapping/`** -- a CID attribute
   already defined in `input_data_config/<tt>.yml` must not also appear as
   a key in any `sql_column_mapping/<tt>/**/*.yml` file.

Validated against the real repository (no branch changes, baseline audit
only): **25 genuine violations found**, including two target_types
(`market_event`, `market_event_bank_im`) that have `input_data_config/`
entries with no `input_data_config_dummy/` counterpart at all today.

## Files

| File | Purpose |
|---|---|
| `nlg_impact_agent/config.py` | `ImpactSettings` -- extends `nlg_dag_agent.config.Settings` (same LLM/GitLab/DB config) with `branch` (required), `base_branch` (default `develop`). Raises if local dirs are set -- GitLab only. |
| `nlg_impact_agent/git_diff.py` | GitLab Compare API client: file-level changes + unified diffs + commits between two refs. |
| `nlg_impact_agent/change_analyzer.py` | AST-diffs old vs. new file content into function/method-level added/removed/modified records, with call-level added/removed detail. |
| `nlg_impact_agent/agent_tools.py` | The tools the agent can call (changeset queries + `Hierarchy.impact_of_*` wrappers, before/after aware) and their function-calling schemas. |
| `nlg_impact_agent/agent_llm_client.py` | The tool-calling chat loop (Azure OpenAI / gateway function-calling protocol). |
| `nlg_impact_agent/agent.py` | Orchestration: `analyze_branch_impact()` ties git_diff + change_analyzer + before/after hierarchies + cid_check + the agent loop together. |
| `nlg_impact_agent/cid_check.py` | Deterministic CID attribute masking compliance check (no LLM) -- three rules described below. |
| `nlg_impact_agent/verification.py` | `verify_report()` -- re-checks the agent's cited evidence against fresh tool results, catching misquoted/fabricated numbers. |
| `nlg_impact_agent/transcript_format.py` | `format_transcript()` / `export_transcript()` -- turns the raw tool-call transcript into a readable, plain-text rendering with intelligent truncation of large results. |
| `nlg_impact_agent/xlsx_report.py` | Exports the result to a 5-sheet workbook (see below); also `default_output_filename()`, the shared branch-aware filename helper used by all three entry points. |
| `nlg_impact_agent/__main__.py` | CLI. |
| `run_impact_agent.ipynb` | Notebook walkthrough. |
| `airflow_dag_nlg_impact_agent.py` | On-demand Airflow DAG -- branch supplied via `dag_run.conf`. |
| `sample_output/change_impact_feature_validate-output.xlsx` | Sample output from the validated mock-LLM run described above -- filename shows the branch-aware naming in practice. |

## Output filenames include the branch name

Every entry point defaults to `change_impact_<branch>.xlsx`, with the branch
name sanitized (`/` and anything else unsafe in a filename replaced with
`_`) via the shared `default_output_filename()` helper -- e.g.
`feature/my-change` becomes `change_impact_feature_my-change.xlsx`. This
keeps reports from different branches from overwriting each other by
default. Override it any time by passing an explicit path.

## Quick start -- notebook

```python
from nlg_impact_agent import ImpactSettings, analyze_branch_impact, export_xlsx, default_output_filename

settings = ImpactSettings(branch="feature/my-change", base_branch="develop", llm_provider="azure_openai")
settings.resolve_secrets(interactive=True)   # GitLab token + LLM key

report = analyze_branch_impact(settings, progress=print)
export_xlsx(report, default_output_filename(report))   # -> change_impact_feature_my-change.xlsx
```

## Quick start -- CLI

```bash
# --xlsx omitted -> defaults to change_impact_feature_my-change.xlsx
python -m nlg_impact_agent analyze --branch feature/my-change

python -m nlg_impact_agent analyze --branch feature/my-change --base-branch release/2026.3
python -m nlg_impact_agent analyze --branch feature/my-change --xlsx custom_name.xlsx   # override
```

## Quick start -- Airflow

Drop `nlg_impact_agent/` and `airflow_dag_nlg_impact_agent.py` into your
`dags/` folder alongside `nlg_dag_agent/`. Trigger the `nlg_impact_agent` DAG
(no schedule -- on-demand only) with:
```json
{"branch": "feature/my-change"}
{"branch": "feature/my-change", "base_branch": "release/2026.3"}
```
via `dag_run.conf`.

## Output columns (`Change Impact Detail` sheet)

`Change & Impact` (what changed, in plain English) - `File` - `Change Kind`
(`function_added`/`function_removed`/`function_modified`/`call_added`/
`call_removed`/`file_renamed`/`file_added`/`file_deleted`/
`config_value_changed`/`other`) - `Has Impact` (Y/N, row colored red/green)
- `DAG` / `Sub-DAG / TaskGroup` / `Task` / `Method / Function` (one row per
impacted task) - `Impacted Method(s)` - `Impact Reasoning` (cites the
specific evidence the agent used) - `Testing Scope Note` (what a tester
should specifically verify).

Changes with no impacted task go to a separate `Changes (no task match)`
sheet (kept visible, not dropped) rather than being force-fit into the main
sheet with empty DAG/task columns. A `Testing Scope Summary` sheet aggregates
every unique impacted DAG/TaskGroup/task/method/file plus the agent's overall
narrative summary.

## Known limitations / extension points

- **Name-based reachability**, same convention as Projects 1/2 -- a shared
  function name across unrelated classes could be conflated. The agent is
  prompted to cross-check with `get_callers_of_function` on surprising
  results, but this is a structural limitation of the underlying analysis.
- **`max_agent_iterations`** (default 40) is a safety cap, not an accuracy
  knob -- raise it for unusually large changesets rather than expecting the
  agent to skip investigation.
- Building the "before" hierarchy on every run costs an extra
  `build_hierarchy()` call (roughly doubling the non-agent part of the
  runtime) -- necessary for correctly assessing removed functions/calls, but
  worth knowing about for very large repos.
- The GitLab Compare scope is restricted to `nlg_dags_subpath`/`nlg_src_subpath`
  (same as Projects 1/2) -- a change entirely outside `dags/nlg/dags` and
  `dags/nlg/src` won't appear in the changeset.
- Cost/time scale with changeset size (each distinct change may need several
  tool calls, each a network round-trip to the LLM) -- there's no caching of
  conclusions between runs; every invocation re-investigates from scratch,
  which is intentional (a branch's code and its hierarchy can change between
  runs) but means re-running on an unchanged branch redoes the same work.
