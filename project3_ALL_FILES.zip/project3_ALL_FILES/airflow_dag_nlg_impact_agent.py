"""
airflow_dag_nlg_impact_agent.py
--------------------------------
Runs the branch change-impact agent as an Airflow DAG. This one is
on-demand only (no schedule) -- trigger it manually or from CI with the
branch to analyze passed via `dag_run.conf`:

    {"branch": "feature/my-change"}
    {"branch": "feature/my-change", "base_branch": "release/2026.3"}

Secrets (GitLab token, LLM key) come from the same Airflow Variable(s)
already used by nlg_dag_agent -- GENESIS_DDLC_IKG_GIT_SECRET by default.

The `nlg_dag_agent` and `nlg_impact_agent` packages must both be
importable from this DAG file -- drop both folders next to it in your
dags repo.
"""
from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.models import Variable

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from nlg_impact_agent.config import ImpactSettings
from nlg_impact_agent.agent import analyze_branch_impact
from nlg_impact_agent.xlsx_report import export_xlsx, default_output_filename


OUTPUT_DIR = Variable.get("NLG_IMPACT_AGENT_OUTPUT_DIR", default_var="/opt/airflow/data/cid/nlg/impact_agent")


def task_analyze_branch(**kwargs):
    conf = (kwargs.get("dag_run").conf if kwargs.get("dag_run") else {}) or {}
    branch = conf.get("branch")
    if not branch:
        raise ValueError('dag_run.conf must include {"branch": "<branch to analyze>"} to trigger this DAG.')
    base_branch = conf.get("base_branch", "develop")

    settings = ImpactSettings(branch=branch, base_branch=base_branch)
    settings.resolve_secrets(interactive=False)   # Airflow Variable -> raise if missing
    if not settings.llm_enabled:
        raise RuntimeError("nlg_impact_agent requires a working LLM key -- none resolved from Airflow Variables.")

    report = analyze_branch_impact(settings, progress=print)

    out_path = os.path.join(OUTPUT_DIR, default_output_filename(report))
    export_xlsx(report, out_path)

    ti = kwargs["ti"]
    ti.xcom_push(key="output_path", value=out_path)
    ti.xcom_push(key="changes_assessed", value=len(report.changes))
    ti.xcom_push(key="changes_with_impact", value=sum(1 for c in report.changes if c.get("has_impact")))
    ti.xcom_push(key="overall_summary", value=report.overall_summary)
    print(f"Impact report for {branch} vs {base_branch} -> {out_path}")
    print(f"{len(report.changes)} change(s) assessed, "
          f"{sum(1 for c in report.changes if c.get('has_impact'))} with impact.")
    print("Overall summary:", report.overall_summary)


default_args = {
    "owner": "NLG",
    "retry_delay": timedelta(minutes=2),
    "retries": 0,   # an agent run is expensive (many LLM calls) -- don't auto-retry on failure
    "email_on_failure": True,
}

with DAG(
    dag_id="nlg_impact_agent",
    default_args=default_args,
    description="Agentic branch change-impact analysis for the NLG pipeline -- trigger with "
                 '{"branch": "<name>"} in dag_run.conf.',
    start_date=datetime(2024, 1, 1),
    schedule_interval=None,   # on-demand only
    catchup=False,
    tags=["NLG", "agent", "impact-analysis", "on-demand"],
) as dag:

    analyze_branch_task = PythonOperator(
        task_id="analyze_branch",
        python_callable=task_analyze_branch,
    )
