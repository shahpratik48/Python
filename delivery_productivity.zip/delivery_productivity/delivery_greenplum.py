"""
Greenplum persistence.

EIGHT tables, all lower_snake_case -- four at POD level and four at CREW
level. They are deliberately separate: a pod row and a crew roll-up in the
same table would double-count on any naive SUM.

    pod_issue_detail                    one row per closed issue, per pod
    pod_mr_detail                       one row per merged MR, per pod
    pod_issue_monthly_summary           issue parameters per pod per month
    pod_mr_monthly_summary              MR parameters per pod per month

    crew_rollup_issue_detail            the same issues, crew-wide
    crew_rollup_mr_detail               the same MRs, crew-wide
    crew_rollup_issue_monthly_summary   issue parameters per crew per month
    crew_rollup_mr_monthly_summary      MR parameters per crew per month

Every table carries the scope it belongs to (pod_name or crew_name), so one
pod can be reloaded without touching another.

**Load strategy.** History does not change, but the current month does --
it is still being written as the month runs. So:

    * settled months are collected from GitLab and loaded ONCE. On every
      later run they are READ BACK FROM THESE TABLES instead, so a daily
      job neither re-scans twenty months of GitLab nor rewrites history.
      That is the expensive part of the run, and it is skipped entirely.
    * the CURRENT month is re-fetched, deleted and reloaded on every run,
      because its numbers move until the month ends.

`crew_issue_monthly_summary` is the authority on what has been loaded, not
the detail tables: a month in which the crew closed nothing still gets a
summary row, whereas it would leave no detail rows at all and would
otherwise be re-fetched forever.

The decision is made from what is actually in the table (`SELECT DISTINCT
month_key`), not from a marker file or a run log, so it stays correct even
if a run is interrupted half way or the tables are truncated by hand.

Inserts use COPY rather than row-by-row execute: a single round trip
instead of one per row, which matters once the detail tables run to
thousands of issues.
"""
from __future__ import annotations

import csv
import io
import threading
from typing import Dict, List, Optional, Sequence

from delivery_metrics import METRIC_DEFS
from delivery_settings import get_logger

log = get_logger("delivery.greenplum")

# Serialises DDL within this process. Pods run concurrently and share the
# same four tables, so several would otherwise issue CREATE TABLE IF NOT
# EXISTS at the same moment -- and that is NOT atomic: both see the table
# missing, both create it, and one loses with
#   duplicate key value violates unique constraint "pg_type_typname_nsp_index"
_DDL_LOCK = threading.Lock()

ISSUE_DETAIL_COLS = [
    ("scope_name", "varchar(200)"), ("crew_name", "varchar(200)"),
    ("month_key", "varchar(7)"), ("pod_name", "varchar(200)"), ("issue_iid", "integer"), ("project_path", "varchar(500)"),
    ("folders", "varchar(500)"), ("title", "varchar(1000)"), ("author_name", "varchar(200)"),
    ("assignee_name", "varchar(200)"), ("measured_from", "varchar(30)"),
    ("start_at", "timestamp"), ("closed_at", "timestamp"), ("cycle_time_days", "numeric(12,2)"),
    ("is_flagged", "boolean"), ("iteration_name", "varchar(300)"),
    ("iteration_start_date", "varchar(20)"), ("iteration_end_date", "varchar(20)"),
    ("epic_id", "varchar(50)"), ("epic_name", "varchar(500)"), ("web_url", "varchar(1000)"),
    ("in_scope", "boolean"), ("scope_reason", "varchar(300)"),
    ("load_timestamp", "timestamp"),
]

MR_DETAIL_COLS = [
    ("scope_name", "varchar(200)"), ("crew_name", "varchar(200)"),
    ("month_key", "varchar(7)"), ("pod_name", "varchar(200)"), ("mr_iid", "integer"), ("project_path", "varchar(500)"),
    ("folders", "varchar(500)"), ("title", "varchar(1000)"), ("author_name", "varchar(200)"),
    ("first_commit_at", "timestamp"), ("merged_at", "timestamp"),
    ("lead_time_hours", "numeric(12,2)"), ("is_flagged", "boolean"),
    ("web_url", "varchar(1000)"), ("mr_id", "varchar(50)"),
    ("target_project_id", "varchar(50)"), ("source_branch", "varchar(500)"),
    ("target_branch", "varchar(500)"), ("mr_created_at", "timestamp"),
    ("first_approved_at", "timestamp"), ("in_scope", "boolean"),
    ("scope_reason", "varchar(300)"), ("load_timestamp", "timestamp"),
]

ISSUE_SUMMARY_COLS = [
    ("scope_name", "varchar(200)"), ("crew_name", "varchar(200)"),
    ("month_key", "varchar(7)"), ("is_baseline_month", "boolean"),
    ("closed_issue_count", "integer"), ("closed_per_pod", "numeric(12,2)"),
    ("pod_count", "integer"), ("issues_total", "integer"),
    ("issues_out_of_scope", "integer"), ("issue_throughput", "numeric(12,2)"),
    ("cycle_time_days", "numeric(12,2)"),
    ("issues_flagged", "integer"), ("measured_from_in_progress", "integer"),
    ("measured_from_iteration", "integer"), ("measured_from_created", "integer"),
    ("throughput_shift_pct", "numeric(12,2)"), ("cycle_time_shift_pct", "numeric(12,2)"),
    ("load_timestamp", "timestamp"),
]

MR_SUMMARY_COLS = [
    ("scope_name", "varchar(200)"), ("crew_name", "varchar(200)"),
    ("month_key", "varchar(7)"), ("is_baseline_month", "boolean"),
    ("merged_mr_count", "integer"), ("mrs_total", "integer"),
    ("mrs_out_of_scope", "integer"), ("author_count", "integer"),
    ("merged_per_author", "numeric(12,2)"),
    ("merged_mr_per_author", "numeric(12,2)"), ("lead_time_hours", "numeric(12,2)"),
    ("mrs_flagged", "integer"), ("mr_per_author_shift_pct", "numeric(12,2)"),
    ("lead_time_shift_pct", "numeric(12,2)"), ("load_timestamp", "timestamp"),
]


def _connect(settings):
    import psycopg2
    log.info("Connecting to Greenplum %s:%s/%s as %s",
             settings.gp_host, settings.gp_port, settings.gp_db, settings.gp_user)
    return psycopg2.connect(host=settings.gp_host, port=settings.gp_port,
                            dbname=settings.gp_db, user=settings.gp_user,
                            password=settings.gp_password, connect_timeout=30)


def _is_already_exists(exc) -> bool:
    """True for the several ways a concurrent CREATE reports 'already there'.

    Greenplum raises a UniqueViolation on pg_type rather than DuplicateTable
    when two sessions create the same table at once, so matching on the
    exception class alone is not enough.
    """
    txt = ("%s %s" % (type(exc).__name__, exc)).lower()
    return ("alreadyexists" in txt or "duplicatetable" in txt
            or "already exists" in txt or "pg_type_typname_nsp_index" in txt)


def ensure_tables(settings, level: str = "pod", progress=None) -> None:
    """Creates the four tables for `level`, applies grants, adds missing columns.

    Safe to call repeatedly and from several threads. Call it ONCE up front,
    before pods run in parallel: doing the DDL inside each pod's load is what
    made concurrent runs collide.
    """
    def say(m):
        log.info(m)
        if progress:
            progress(m)

    schema = settings.gp_schema
    it, mt, isum_t, msum_t = _tables(settings, level)
    specs = [(it, ISSUE_DETAIL_COLS), (mt, MR_DETAIL_COLS),
             (isum_t, ISSUE_SUMMARY_COLS), (msum_t, MR_SUMMARY_COLS)]

    with _DDL_LOCK:
        conn = _connect(settings)
        try:
            conn.autocommit = False
            cur = conn.cursor()
            for tbl, cols in specs:
                try:
                    cur.execute(_ddl(schema, tbl, cols))
                    conn.commit()
                except Exception as e:
                    conn.rollback()
                    if not _is_already_exists(e):
                        raise
                    # another session created it a moment ago -- that is the
                    # desired end state, so carry on
                    log.info("%s.%s already created by a concurrent run.", schema, tbl)
                try:
                    _ensure_columns(cur, schema, tbl, cols)
                    conn.commit()
                except Exception as e:
                    conn.rollback()
                    if not _is_already_exists(e):
                        raise

            for tbl, _cols in specs:
                for sql in ("ALTER TABLE %s.%s OWNER TO %s"
                            % (schema, tbl, settings.gp_owner_group),
                            "GRANT SELECT ON %s.%s TO %s"
                            % (schema, tbl, settings.gp_reader_group)):
                    try:
                        cur.execute(sql)
                        conn.commit()
                    except Exception as e:
                        # a permissions gap must not lose the data load
                        conn.rollback()
                        log.warning("Could not apply '%s': %s", sql, e)
            say("%s-level tables ready in %s (owner %s, read access %s)."
                % (level, schema, settings.gp_owner_group, settings.gp_reader_group))
        finally:
            conn.close()


def _ddl(schema: str, table: str, cols) -> str:
    body = ",\n  ".join("%s %s" % (n, t) for n, t in cols)
    return "CREATE TABLE IF NOT EXISTS %s.%s (\n  %s\n)" % (schema, table, body)


def _existing_months(cur, schema: str, table: str) -> set:
    cur.execute("SELECT DISTINCT month_key FROM %s.%s" % (schema, table))
    return {r[0] for r in cur.fetchall() if r[0]}


def _copy(cur, schema: str, table: str, cols, rows: List[Sequence]) -> int:
    if not rows:
        return 0
    # Fail loudly and specifically. A row that is the wrong LENGTH otherwise
    # reaches COPY and surfaces as
    #   invalid input syntax for integer: "13.0"
    # which points at a column that is merely downstream of the real mistake.
    bad = next((r for r in rows if len(r) != len(cols)), None)
    if bad is not None:
        raise ValueError(
            "%s.%s expects %d value(s) per row but got %d. The row list and the column list "
            "have drifted apart -- they must be kept in the same order.\n  columns: %s"
            % (schema, table, len(cols), len(bad), ", ".join(n for n, _t in cols)))
    int_at = {i for i, (_n, t) in enumerate(cols) if t.lower().startswith("integer")}
    buf = io.StringIO()
    w = csv.writer(buf, quoting=csv.QUOTE_MINIMAL, lineterminator="\n")
    for r in rows:
        out = []
        for i, v in enumerate(r):
            if v is None:
                out.append("")
            elif i in int_at and isinstance(v, float):
                # a count arriving as 13.0 is still a count; Postgres will not
                # coerce it, so round here rather than fail the whole load
                out.append(int(round(v)))
            else:
                out.append(v)
        w.writerow(out)
    buf.seek(0)
    names = ", ".join(n for n, _t in cols)
    cur.copy_expert("COPY %s.%s (%s) FROM STDIN WITH (FORMAT csv, NULL '')"
                    % (schema, table, names), buf)
    return len(rows)


def _ts(d):
    return d.strftime("%Y-%m-%d %H:%M:%S") if d else None


def _ensure_columns(cur, schema: str, table: str, cols) -> None:
    """Adds any column the table is missing.

    CREATE TABLE IF NOT EXISTS silently leaves an existing table alone, so a
    schema change would otherwise fail at COPY time with a column-count
    mismatch. Checking information_schema and issuing a targeted ALTER keeps
    already-deployed tables usable without a manual migration.
    """
    cur.execute("SELECT column_name FROM information_schema.columns "
                "WHERE table_schema = %s AND table_name = %s", (schema, table))
    have = {r[0].lower() for r in cur.fetchall()}
    for name, typ in cols:
        if name.lower() not in have:
            log.info("Adding missing column %s.%s.%s (%s)", schema, table, name, typ)
            cur.execute("ALTER TABLE %s.%s ADD COLUMN %s %s" % (schema, table, name, typ))


def _table_exists(cur, schema: str, table: str) -> bool:
    cur.execute("SELECT 1 FROM information_schema.tables "
                "WHERE table_schema = %s AND table_name = %s", (schema, table))
    return cur.fetchone() is not None


def _tables(settings, level):
    if level == "pod":
        return (settings.tbl_pod_issue_detail, settings.tbl_pod_mr_detail,
                settings.tbl_pod_issue_summary, settings.tbl_pod_mr_summary)
    return (settings.tbl_crew_issue_detail, settings.tbl_crew_mr_detail,
            settings.tbl_crew_issue_summary, settings.tbl_crew_mr_summary)


def loaded_months(settings, level="pod", scope_name="") -> set:
    """Months already persisted, judged from the issue summary table.

    Returns an empty set (rather than raising) when the schema or tables do
    not exist yet, or when the database cannot be reached -- a first run,
    or an unreachable database, should fall back to fetching everything
    from GitLab rather than failing.
    """
    try:
        conn = _connect(settings)
    except Exception as e:
        log.warning("Greenplum unreachable (%s) -- treating every month as not yet loaded, "
                    "so this run will fetch the full history from GitLab.", e)
        return set()
    try:
        cur = conn.cursor()
        tbl = _tables(settings, level)[2]        # the issue summary is the authority
        if not _table_exists(cur, settings.gp_schema, tbl):
            log.info("%s.%s does not exist yet -- first run, full history will be fetched.",
                     settings.gp_schema, tbl)
            return set()
        # scoped by name, so one pod's history never masks another's
        cur.execute("SELECT DISTINCT month_key FROM %s.%s WHERE scope_name = %%s"
                    % (settings.gp_schema, tbl), (scope_name,))
        months = {r[0] for r in cur.fetchall() if r[0]}
        log.info("%s '%s': %d month(s) already loaded.", level, scope_name, len(months))
        return months
    except Exception as e:
        log.warning("Could not read loaded months (%s) -- will fetch the full history.", e)
        return set()
    finally:
        conn.close()


def _fetch(cur, schema, table, cols, months, scope_name=""):
    names = ", ".join(n for n, _t in cols)
    cur.execute("SELECT %s FROM %s.%s WHERE month_key = ANY(%%s) AND scope_name = %%s"
                % (names, schema, table), (list(months), scope_name))
    return [dict(zip([n for n, _t in cols], r)) for r in cur.fetchall()]


def read_detail(settings, months, level="pod", scope_name=""):
    """Rebuilds IssueRow / MRRow objects for already-loaded months.

    This is what makes the incremental run cheap: settled months come back
    from the database in one query each, instead of re-walking every project
    in GitLab for twenty months of history.
    """
    from delivery_metrics import IssueRow, MRRow, parse_ts
    if not months:
        return [], []
    conn = _connect(settings)
    try:
        cur = conn.cursor()
        it, mt = _tables(settings, level)[0], _tables(settings, level)[1]
        if not _table_exists(cur, settings.gp_schema, it):
            return [], []
        irows = _fetch(cur, settings.gp_schema, it, ISSUE_DETAIL_COLS, months, scope_name)
        mrows = _fetch(cur, settings.gp_schema, mt, MR_DETAIL_COLS, months, scope_name)
    finally:
        conn.close()

    def _as_dt(v):
        return v if hasattr(v, "year") else parse_ts(v)

    issues = [IssueRow(
        pod_name=r.get("pod_name") or "",
        project_path=r["project_path"] or "", folders=r["folders"] or "",
        iid=r["issue_iid"], title=r["title"] or "", author=r["author_name"] or "",
        assignee=r["assignee_name"] or "", month=r["month_key"],
        measured_from=r["measured_from"] or "", start_at=_as_dt(r["start_at"]),
        closed_at=_as_dt(r["closed_at"]),
        cycle_days=float(r["cycle_time_days"]) if r["cycle_time_days"] is not None else None,
        flagged=bool(r["is_flagged"]), iteration_name=r["iteration_name"] or "",
        iteration_start=r["iteration_start_date"] or "", iteration_end=r["iteration_end_date"] or "",
        epic_id=r["epic_id"] or "", epic_name=r["epic_name"] or "",
        web_url=r["web_url"] or "", in_scope=bool(r.get("in_scope")),
        scope_reason=r.get("scope_reason") or "") for r in irows]

    mrs = [MRRow(
        pod_name=r.get("pod_name") or "",
        project_path=r["project_path"] or "", folders=r["folders"] or "", iid=r["mr_iid"],
        title=r["title"] or "", author=r["author_name"] or "",
        month=r["month_key"], first_commit_at=_as_dt(r["first_commit_at"]),
        merged_at=_as_dt(r["merged_at"]),
        lead_hours=float(r["lead_time_hours"]) if r["lead_time_hours"] is not None else None,
        flagged=bool(r["is_flagged"]), web_url=r["web_url"] or "",
        mr_id=r.get("mr_id") or "", target_project_id=r.get("target_project_id") or "",
        source_branch=r.get("source_branch") or "", target_branch=r.get("target_branch") or "",
        created_at=_as_dt(r.get("mr_created_at")),
        first_approved_at=_as_dt(r.get("first_approved_at")),
        in_scope=bool(r.get("in_scope")), scope_reason=r.get("scope_reason") or "")
        for r in mrows]

    log.info("Read back from Greenplum: %d issue(s) and %d merge request(s) across %d "
             "settled month(s).", len(issues), len(mrs), len(months))
    return issues, mrs


def load(settings, ser, stats, months: List[str], issues, mrs,
         current_month: str, progress=None, fetched_months=None,
         level="pod", scope_name="", crew_name="", pod_count=1) -> Dict[str, object]:
    """Creates the tables if needed and writes the months that were fetched
    this run -- which is normally just the current month.

    `fetched_months` is what the caller actually pulled from GitLab. Passing
    it keeps the write set identical to the fetch set, so a month that was
    read back from the database is never rewritten with the same rows it
    came from.
    """
    def say(m):
        log.info(m)
        if progress:
            progress(m)

    import datetime as _dt
    now = _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    schema = settings.gp_schema
    result = {"schema": schema, "level": level, "scope": scope_name, "tables": {},
              "months_loaded": [], "months_skipped": [],
              "current_month_reloaded": current_month}

    # only months up to and including the current one are eligible
    eligible = [m for m in months if m <= current_month]

    conn = _connect(settings)
    try:
        conn.autocommit = False
        cur = conn.cursor()
        # Tables are created by ensure_tables() BEFORE the pods start, so no
        # DDL happens here. Several pods loading at once would otherwise race
        # on CREATE TABLE for the four tables they share -- and
        # CREATE TABLE IF NOT EXISTS is not atomic, so one of them loses.
        it, mt, isum_t, msum_t = _tables(settings, level)
        specs = [(it, ISSUE_DETAIL_COLS), (mt, MR_DETAIL_COLS),
                 (isum_t, ISSUE_SUMMARY_COLS), (msum_t, MR_SUMMARY_COLS)]


        # write exactly what was fetched; fall back to computing it if the
        # caller did not say
        if fetched_months is not None:
            to_load = [m for m in eligible if m in set(fetched_months)]
        else:
            present = _existing_months(cur, schema, isum_t)
            to_load = [m for m in eligible if m == current_month or m not in present]
        skipped = [m for m in eligible if m not in to_load]
        result["months_loaded"], result["months_skipped"] = to_load, skipped
        say("Months already loaded: %d. To load now: %d (of which the current month, %s, is "
            "always reloaded)." % (len(skipped), len(to_load), current_month))
        if skipped:
            log.info("Skipping settled months: %s", ", ".join(skipped))

        load_set = set(to_load)
        idx = {m: i for i, m in enumerate(months)}

        # remove anything we are about to rewrite
        # scoped delete -- reloading one pod must not disturb another
        for tbl, _cols in specs:
            cur.execute("DELETE FROM %s.%s WHERE month_key = ANY(%%s) AND scope_name = %%s"
                        % (schema, tbl), (list(load_set), scope_name))
        conn.commit()

        # ---- detail rows ----
        irows = [[scope_name, crew_name, i.month, i.pod_name, i.iid, i.project_path, i.folders, i.title, i.author, i.assignee,
                  i.measured_from, _ts(i.start_at), _ts(i.closed_at), i.cycle_days,
                  bool(i.flagged), i.iteration_name, i.iteration_start, i.iteration_end,
                  i.epic_id, i.epic_name, i.web_url, bool(i.in_scope), i.scope_reason, now]
                 for i in issues if i.month in load_set]
        mrows = [[scope_name, crew_name, m.month, m.pod_name, m.iid, m.project_path, m.folders, m.title, m.author,
                  _ts(m.first_commit_at), _ts(m.merged_at), m.lead_hours, bool(m.flagged),
                  m.web_url, m.mr_id, m.target_project_id, m.source_branch, m.target_branch,
                  _ts(m.created_at), _ts(m.first_approved_at), bool(m.in_scope),
                  m.scope_reason, now]
                 for m in mrs if m.month in load_set]

        # ---- summary rows ----
        isum, msum = [], []
        for m in to_load:
            s = stats[m]
            i = idx[m]
            base = m in set(getattr(ser, "baseline_months", []) or [settings.baseline_month])
            # order MUST match ISSUE_SUMMARY_COLS exactly -- _copy() asserts it
            isum.append([scope_name, crew_name, m, base,
                         s.closed_count,          # closed_issue_count
                         s.throughput,            # closed_per_pod
                         pod_count,               # pod_count
                         s.issues_total, s.issues_out_of_scope,
                         s.throughput,            # issue_throughput (same figure)
                         s.cycle_time, s.issues_flagged,
                         s.from_in_progress, s.from_iteration, s.from_created,
                         ser.shift_pct["throughput"][i], ser.shift_pct["cycle_time"][i], now])
            # order MUST match MR_SUMMARY_COLS exactly -- _copy() asserts it
            msum.append([scope_name, crew_name, m, base,
                         s.mr_count, s.mrs_total, s.mrs_out_of_scope, s.author_count,
                         s.mr_per_author,         # merged_per_author
                         s.mr_per_author,         # merged_mr_per_author (same figure)
                         s.lead_time, s.mrs_flagged,
                         ser.shift_pct["mr_per_author"][i],
                         ser.shift_pct["lead_time"][i], now])

        for tbl, cols, rows in [(it, ISSUE_DETAIL_COLS, irows), (mt, MR_DETAIL_COLS, mrows),
                                (isum_t, ISSUE_SUMMARY_COLS, isum),
                                (msum_t, MR_SUMMARY_COLS, msum)]:
            n = _copy(cur, schema, tbl, cols, rows)
            result["tables"][tbl] = n
            say("  %s.%s <- %d row(s)" % (schema, tbl, n))

        conn.commit()
        say("Greenplum load complete.")
        return result
    except Exception:
        conn.rollback()
        log.exception("Greenplum load failed and was rolled back -- no partial data was left "
                      "behind.")
        raise
    finally:
        conn.close()
