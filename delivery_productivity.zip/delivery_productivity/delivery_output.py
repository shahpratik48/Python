"""
The two deliverables: a workbook and a web page, each carrying the SAME
content and the SAME embedded chart.

Both open with the monthly table -- every month from the start of the window
through the current one, with the **baseline row highlighted** and a
**shift-from-baseline** block covering baseline to current month. Then the
chart. Then the full detail: every closed issue and every merged MR in the
window, sorted newest first, flagged or not.

The chart is the identical PNG in both -- embedded as a drawing in the
workbook and base64-inlined in the page, so the HTML stays a single
self-contained file that survives being emailed.
"""
from __future__ import annotations

import base64
import datetime as _dt
import html as _html
import os
from typing import Dict, List, Optional

from openpyxl import Workbook
from openpyxl.drawing.image import Image as XLImage
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from delivery_metrics import (FROM_CREATED, FROM_ITERATION, LOWER_IS_BETTER, METRIC_DEFS,
                        month_label)
from delivery_settings import get_logger

log = get_logger("delivery.output")

C_HEAD, C_HEAD_TX = "305496", "FFFFFF"
C_ALT, C_BASE_BG = "FAFBFC", "FFF3CD"      # baseline row highlight
C_FLAG_BG, C_FLAG_TX = "FDECEC", "9B1C1C"
C_OK_BG, C_OK_TX = "E6F5EC", "0B6B36"
C_BORDER = "E6E8EB"

F_TITLE = Font(name="Calibri", size=16, bold=True)
F_H2 = Font(name="Calibri", size=12, bold=True, color=C_HEAD)
F_SUB = Font(name="Calibri", size=9, italic=True, color="666666")
F_HEAD = Font(name="Calibri", size=10, bold=True, color=C_HEAD_TX)
F_BODY = Font(name="Calibri", size=10)
FILL_HEAD = PatternFill("solid", start_color=C_HEAD, end_color=C_HEAD)
FILL_ALT = PatternFill("solid", start_color=C_ALT, end_color=C_ALT)
FILL_BASE = PatternFill("solid", start_color=C_BASE_BG, end_color=C_BASE_BG)
FILL_FLAG = PatternFill("solid", start_color=C_FLAG_BG, end_color=C_FLAG_BG)
C_OUT_BG = "F0F0F0"
FILL_OUT = PatternFill("solid", start_color=C_OUT_BG, end_color=C_OUT_BG)
_thin = Side(style="thin", color=C_BORDER)
BORDER = Border(left=_thin, right=_thin, top=_thin, bottom=_thin)
WRAP = Alignment(vertical="top", wrap_text=True)


def _dt_str(d) -> str:
    return d.strftime("%Y-%m-%d %H:%M") if d else ""


def _num(v, nd=2):
    return round(float(v), nd) if v is not None else None


# ------------------------------------------------------------------ shared
POD_COL = "POD_name"          # prefixed on the crew report's list sheets only
WINDOW_HEADERS = ["3-Month Window", "Issue Throughput (per pod)", "Cycle Time (Days)",
                  "Merged MR per Author", "Lead Time (Hrs)"]
SHIFT_HEADERS = ["3-Month Window", "Issue Throughput (per pod)", "Cycle Time (Days)",
                 "Merged MR per Author", "Lead Time (Hrs)", "Overall"]
ISSUE_POD_COL = "POD_name"          # prefixed on the crew report's list sheets only
ISSUE_WINDOW_HEADERS = ["3-Month Window", "Months", "Closed (all)", "Closed per pod",
                        "Reached in progress", "Trimmed (slowest %)", "Measured",
                        "Cycle Time (Days)"]
MR_POD_COL = "POD_name"          # prefixed on the crew report's list sheets only
MR_WINDOW_HEADERS = ["3-Month Window", "Months", "Merged MRs", "Distinct Authors",
                     "Merged MR per Author", "Lead Time measured", "Excluded (>1yr / none)",
                     "Lead Time (Hrs)"]
ISSUE_HEADERS = ["Scope", "Scope Reason", "Closed At", "Month", "Issue IID", "Title",
                 "Author", "Assignee", "Measured From", "Start Date", "Cycle Time (Days)",
                 "Flagged", "Iteration", "Iteration Start", "Iteration End", "Epic ID",
                 "Epic Name", "Folders", "Project Path", "Link"]
MR_HEADERS = ["Scope", "Scope Reason", "Merged At", "Month", "MR IID", "MR ID",
              "Target Project ID", "Title", "Author", "Author GPN", "Author Email",
              "Source Branch", "Target Branch", "Created At", "First Approved At",
              "First Commit At", "Lead Time (Hrs)", "Flagged", "Folders", "Project Path",
              "Link"]


def _desc(windows):
    """Newest window first -- that is what people look at, and it keeps every
    sheet consistent with the others."""
    return list(reversed(list(windows)))


def window_rows(windows):
    return [[w.label, _num(w.throughput), _num(w.cycle_time), _num(w.mr_per_author),
             _num(w.lead_time)] for w in _desc(windows)]


def shift_rows(ser):
    """Shift of every window against the baseline window, newest first."""
    rows = []
    for j in range(len(ser.window_labels) - 1, -1, -1):
        rows.append([ser.window_labels[j]]
                    + [_num(ser.shift_pct[k][j], 1) for k, _l, _x in METRIC_DEFS]
                    + [_num(ser.gain_actual[j], 1)])
    return rows


def issue_window_rows(windows, trim_pct):
    return [[w.label, "%s..%s" % (w.months[0], w.months[-1]) if w.months else "",
             w.closed_total, _num(w.throughput), w.in_progress_count,
             "%d (%g%%)" % (w.trimmed_count, trim_pct),
             max(0, w.in_progress_count - w.trimmed_count), _num(w.cycle_time)]
            for w in _desc(windows)]


def mr_window_rows(windows):
    return [[w.label, "%s..%s" % (w.months[0], w.months[-1]) if w.months else "",
             w.mr_count, w.author_count, _num(w.mr_per_author),
             w.lead_measured, w.lead_excluded, _num(w.lead_time)]
            for w in _desc(windows)]


def mr_author_table(mrs, windows):
    """Merged MRs per author per window, newest window first."""
    labels = [w.label for w in _desc(windows)]
    span = {w.label: set(w.months) for w in windows}
    authors = sorted({(r.author_display or r.author) for r in mrs})
    rows = []
    for a in authors:
        vals = [sum(1 for r in mrs
                    if (r.author_display or r.author) == a and r.month in span[l])
                for l in labels]
        gpn = next((r.author_gpn for r in mrs
                    if (r.author_display or r.author) == a and r.author_gpn), "")
        rows.append([a, gpn] + vals)
    totals = [sum(1 for r in mrs if r.month in span[l]) for l in labels]
    rows.append(["All authors", ""] + totals)
    return ["Author", "GPN"] + labels, rows


def issue_rows(issues, include_pod=False):
    """Every closed issue, newest first -- in scope or not.

    The Scope column says whether the row fed the metrics and the graph, and
    Scope Reason says why not when it did not, so an excluded issue is
    visible and explained rather than silently missing.
    """
    rows = sorted(issues, key=lambda i: (i.closed_at or _dt.datetime.min.replace(
        tzinfo=_dt.timezone.utc)), reverse=True)
    body = [["In scope" if i.in_scope else "Out of scope", i.scope_reason,
             _dt_str(i.closed_at), i.month, i.iid, i.title, i.author, i.assignee,
             i.measured_from, _dt_str(i.start_at), _num(i.cycle_days),
             "Y" if i.flagged else "N", i.iteration_name, i.iteration_start, i.iteration_end,
             i.epic_id, i.epic_name, i.folders, i.project_path, i.web_url] for i in rows]
    if include_pod:
        body = [[i.pod_name] + b for i, b in zip(rows, body)]
    return body, rows


def mr_rows(mrs, include_pod=False):
    """Every merged MR, newest first -- in scope or not."""
    rows = sorted(mrs, key=lambda m: (m.merged_at or _dt.datetime.min.replace(
        tzinfo=_dt.timezone.utc)), reverse=True)
    body = [["In scope" if m.in_scope else "Out of scope", m.scope_reason,
             _dt_str(m.merged_at), m.month, m.iid, m.mr_id, m.target_project_id,
             m.title, m.author_display or m.author, m.author_gpn, m.author_email,
             m.source_branch, m.target_branch,
             _dt_str(m.created_at), _dt_str(m.first_approved_at), _dt_str(m.first_commit_at),
             _num(m.lead_hours), "Y" if m.flagged else "N",
             m.folders, m.project_path, m.web_url] for m in rows]
    if include_pod:
        body = [[m.pod_name] + b for m, b in zip(rows, body)]
    return body, rows


_DASH_IMG_ROW = 22          # the chart is placed below the explanatory block


def _dashboard_notes(ws, settings, ser, label):
    """A short account of how every percentage on the chart is derived.

    Kept on the sheet itself rather than only in the README: the workbook is
    what gets forwarded, and a reader asked to act on "+102%" should be able
    to see what it is a percentage OF without going anywhere else.
    """
    base_months = ", ".join(ser.baseline_months) or settings.baseline_month
    anchor = ser.baseline_label or "n/a"
    charted = ("%s to %s" % (ser.window_labels[0], ser.window_labels[-1])
               if ser.window_labels else "")

    lines = [
        ("How the percentages on this chart are calculated", "head"),
        ("", ""),
        ("Each panel headline compares the LAST point on its line with the BASELINE point -- "
         "both are 3-month window averages, in that panel's own units:", "body"),
        ("        shift  =  (last window - baseline window) / |baseline window| x 100", "mono"),
        ("", ""),
        ("Cycle Time and Lead Time are LOWER-IS-BETTER, so their sign is flipped. A lead time "
         "falling from 200h to 100h reads +50%, not -50%. Positive therefore always means "
         "better, on every panel.", "body"),
        ("", ""),
        ("Overall Productivity Gain is the plain, unweighted MEAN of the four panel figures:", "body"),
        ("        Overall  =  (Throughput % + Cycle Time % + MR per Author % + Lead Time %) / 4",
         "mono"),
        ("You can check both by eye: each headline against the two ends of its own line, and "
         "the overall against the four titles.", "body"),
        ("", ""),
        ("Baseline    the %s window, pooling %s -- not a single month, since one quiet month "
         "would distort every percentage on the chart." % (anchor, base_months), "body"),
        ("Anchor      aspiration starts ON the actual at %s and is not drawn before it."
         % anchor, "body"),
        ("X axis      consecutive 3-month windows stepping one month at a time "
         "(Nov 24-Jan 25, Dec 24-Feb 25, ...). Each figure is computed from that window's whole "
         "population, not by averaging monthly numbers.", "body"),
        ("Charted     %s. The month in progress is EXCLUDED -- it is incomplete by definition, "
         "so any window containing it would read as a false decline." % charted, "body"),
        ("Aspiration  the baseline improved by %.0f%% over %d months, drawn in each panel's own "
         "units." % (settings.target_gain_pct, settings.target_months), "body"),
        ("", ""),
        ("Read the four panels, not just the headline: the mean is unweighted, so one volatile "
         "metric can carry it. A percentage against a small baseline also exaggerates.", "warn"),
    ]
    for i, (text, kind) in enumerate(lines, start=1):
        c = ws.cell(row=i, column=1, value=text)
        if kind == "head":
            c.font = Font(name="Calibri", size=13, bold=True, color=C_HEAD)
        elif kind == "mono":
            c.font = Font(name="Consolas", size=10, bold=True, color="1A1A1A")
        elif kind == "warn":
            c.font = Font(name="Calibri", size=9.5, italic=True, color=C_FLAG_TX)
        else:
            c.font = Font(name="Calibri", size=9.5, color="333333")
    ws.column_dimensions["A"].width = 150


# ------------------------------------------------------------------ XLSX
class _Sheet:
    def __init__(self, ws, widths=None):
        self.ws, self.row = ws, 1
        if widths:
            for i, w in enumerate(widths, start=1):
                ws.column_dimensions[get_column_letter(i)].width = w

    def title(self, text, font=F_TITLE):
        c = self.ws.cell(row=self.row, column=1, value=text)
        c.font = font
        self.row += 1

    def blank(self, n=1):
        self.row += n

    def table(self, headers, rows, highlight=None, flag_col=None, autofilter=False,
              pct_cols=None, scope_col=None):
        """`pct_cols` are 0-based column indexes holding a percentage shift.

        Those cells are written as real percentages and coloured by direction
        -- green when better, red when worse -- so the table reads at a glance
        without anyone tracing which metrics invert.
        """
        first = self.row
        for i, h in enumerate(headers, start=1):
            c = self.ws.cell(row=self.row, column=i, value=h)
            c.font, c.fill, c.border = F_HEAD, FILL_HEAD, BORDER
            c.alignment = Alignment(vertical="center", horizontal="center", wrap_text=True)
        self.row += 1
        for ri, r in enumerate(rows):
            fill = None
            if highlight and highlight(r):
                fill = FILL_BASE
            elif scope_col is not None and str(r[scope_col]).lower().startswith("out"):
                fill = FILL_OUT          # excluded from the metrics
            elif flag_col is not None and str(r[flag_col]).upper() == "Y":
                fill = FILL_FLAG
            elif ri % 2:
                fill = FILL_ALT
            for i, v in enumerate(r, start=1):
                c = self.ws.cell(row=self.row, column=i, value=v)
                c.font, c.border, c.alignment = F_BODY, BORDER, WRAP
                if fill:
                    c.fill = fill
                if pct_cols and (i - 1) in pct_cols and isinstance(v, (int, float)):
                    good = v >= 0
                    c.value = float(v) / 100.0
                    c.number_format = "+0.0%;-0.0%"
                    c.font = Font(name="Calibri", size=10, bold=True,
                                  color=(C_OK_TX if good else C_FLAG_TX))
                    c.fill = PatternFill("solid",
                                         start_color=(C_OK_BG if good else C_FLAG_BG),
                                         end_color=(C_OK_BG if good else C_FLAG_BG))
                    c.alignment = Alignment(vertical="top", horizontal="right")
            self.row += 1
        if autofilter and rows:
            # A worksheet supports ONE autofilter, so this is set only on the
            # detail table of each sheet -- otherwise whichever table was
            # written last would quietly take it.
            self.ws.auto_filter.ref = "A%d:%s%d" % (first, get_column_letter(len(headers)),
                                                    self.row - 1)
        # Deliberately NO freeze_panes. Sheets here hold several stacked
        # tables, and freezing on each one leaves the last table's header row
        # frozen -- locking every row above it and making the sheet look as
        # though it will not scroll.
        self.row += 1


def write_xlsx(settings, ser, windows, months, issues, mrs, chart_png, current_month,
               output_dir, label=None, include_pod=False, file_prefix=None) -> str:
    """The workbook. Six sheets; every summary table is per 3-month window,
    matching what the chart plots."""
    name = label or settings.crew_name
    wb = Workbook()
    wb.remove(wb.active)
    base_lab = ser.baseline_label or ""

    # ---- Summary ----
    sh = _Sheet(wb.create_sheet("Summary"), [22, 24, 20, 22, 18, 14])
    sh.title("Delivery Productivity  -  %s" % name)
    sh.title("3-month rolling windows | baseline %s (%s) | %s to %s | generated %s"
             % (base_lab, ", ".join(ser.baseline_months),
                ser.window_labels[0] if ser.window_labels else "",
                ser.window_labels[-1] if ser.window_labels else "",
                _dt.datetime.now().strftime("%Y-%m-%d %H:%M")), F_SUB)
    sh.title("The current month (%s) is excluded: it is incomplete, so any window containing "
             "it would read low." % current_month, F_SUB)
    sh.blank()
    sh.title("Parameters per window  (baseline window highlighted)", F_H2)
    sh.table(WINDOW_HEADERS, window_rows(windows),
             highlight=lambda r: r[0] == base_lab)
    sh.title("Shift against baseline %s" % base_lab, F_H2)
    sh.title("Positive is always better -- Cycle Time and Lead Time are lower-is-better, so "
             "their sign is already inverted. Green = better, red = worse.", F_SUB)
    sh.table(SHIFT_HEADERS, shift_rows(ser),
             highlight=lambda r: r[0] == base_lab, pct_cols=[1, 2, 3, 4, 5])

    # ---- Dashboard ----
    if chart_png and os.path.exists(chart_png):
        ws2 = wb.create_sheet("Dashboard")
        _dashboard_notes(ws2, settings, ser, name)
        img = XLImage(chart_png)
        scale = 1400.0 / float(img.width or 1400)
        img.width = int((img.width or 1400) * scale)
        img.height = int((img.height or 900) * scale)
        ws2.add_image(img, "A%d" % (_DASH_IMG_ROW + 1))
        log.info("Chart embedded into the workbook.")

    # ---- Issues-summary ----
    sh3 = _Sheet(wb.create_sheet("Issues-summary"), [22, 20, 14, 16, 20, 20, 12, 18])
    sh3.title("Issues  -  %s" % name)
    sh3.title("Issue Throughput counts EVERY closed issue in the window, divided by %d pod(s). "
              "Cycle Time uses only issues that reached in progress, with the slowest %g%% of "
              "the window removed before averaging."
              % (settings.pod_count, settings.issue_slowest_trim_pct), F_SUB)
    sh3.blank()
    sh3.title("Per 3-month window", F_H2)
    sh3.table(ISSUE_WINDOW_HEADERS,
              issue_window_rows(windows, settings.issue_slowest_trim_pct),
              highlight=lambda r: r[0] == base_lab)

    # ---- MR-summary ----
    sh4 = _Sheet(wb.create_sheet("MR-summary"), [22, 20, 14, 16, 20, 18, 20, 16])
    sh4.title("Merge requests  -  %s" % name)
    sh4.title("Merged MR per Author counts EVERY merged MR in the window, including those with "
              "a lead time over a year. Lead Time excludes those.", F_SUB)
    sh4.blank()
    sh4.title("Per 3-month window", F_H2)
    sh4.table(MR_WINDOW_HEADERS, mr_window_rows(windows),
              highlight=lambda r: r[0] == base_lab)
    sh4.title("Merged per author, per window", F_H2)
    ah, ar = mr_author_table(mrs, windows)
    sh4.table(ah, ar)

    # ---- Issue List ----
    irows, _ = issue_rows(issues, include_pod)
    ihdr = ([POD_COL] + ISSUE_HEADERS) if include_pod else ISSUE_HEADERS
    ioff = 1 if include_pod else 0
    sh5 = _Sheet(wb.create_sheet("Issue List"),
                 [12, 34, 18, 10, 11, 46, 20, 20, 16, 18, 16, 9, 22, 14, 14, 10, 26, 34, 46, 44])
    sh5.title("All closed issues  -  %s" % name)
    sh5.title("Newest closed first. EVERY closed issue counts towards Issue Throughput; the "
              "Scope column marks those eligible for Cycle Time.", F_SUB)
    sh5.blank()
    sh5.table(ihdr, irows, flag_col=11 + ioff, scope_col=ioff, autofilter=True)

    # ---- MR List ----
    mrows, _ = mr_rows(mrs, include_pod)
    mhdr = ([POD_COL] + MR_HEADERS) if include_pod else MR_HEADERS
    sh6 = _Sheet(wb.create_sheet("MR List"),
                 [12, 30, 18, 10, 10, 12, 16, 44, 24, 14, 24, 28, 20, 18, 18, 18, 14, 9, 30,
                  46, 44])
    sh6.title("All merged merge requests  -  %s" % name)
    sh6.title("Newest merged first. EVERY merged MR counts towards Merged MR per Author; the "
              "Scope column marks those inside the one-year limit used for Lead Time.", F_SUB)
    sh6.blank()
    sh6.table(mhdr, mrows, flag_col=17 + ioff, scope_col=ioff, autofilter=True)

    os.makedirs(output_dir, exist_ok=True)
    safe = file_prefix or "".join(
        c if (c.isalnum() or c in "._-") else "_" for c in name).strip("_")
    path = os.path.join(output_dir, "%s_%s.xlsx"
                        % (safe, _dt.datetime.now().strftime("%Y%m%d_%H%M%S")))
    wb.save(path)
    log.info("XLSX written: %s", path)
    return path


# ------------------------------------------------------------------ HTML
_CSS = """
body{font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;margin:0;padding:24px;
background:#f6f7f9;color:#1a1a1a}
.wrap{max-width:1500px;margin:0 auto;background:#fff;padding:28px 32px;border-radius:10px;
box-shadow:0 1px 3px rgba(0,0,0,.08)}
h1{margin:0 0 4px;font-size:24px} h2{margin:30px 0 10px;font-size:18px;
border-bottom:2px solid #e6e8eb;padding-bottom:6px}
.sub{color:#666;font-size:13px;margin-bottom:16px}
table{border-collapse:collapse;width:100%;margin:8px 0;font-size:12.5px}
th{background:#305496;color:#fff;text-align:left;padding:8px 10px;font-weight:600;
cursor:pointer;white-space:nowrap;position:sticky;top:0}
td{border-bottom:1px solid #e6e8eb;padding:6px 9px;vertical-align:top}
tbody tr:nth-child(even) td{background:#fafbfc}
tbody tr.flag td{background:#fdecec}
tbody tr.outscope td{background:#f2f2f2;color:#777}
tbody tr.baseline td{background:#fff3cd;font-weight:600}
.tbl{margin:10px 0 20px}
.bar{display:flex;gap:10px;align-items:center;margin-bottom:4px}
.filter{flex:0 0 300px;padding:6px 10px;border:1px solid #cfd4da;border-radius:6px;font-size:13px}
.count{font-size:12px;color:#666}
.scroll{max-height:520px;overflow:auto;border:1px solid #e6e8eb;border-radius:6px}
.cards{display:flex;flex-wrap:wrap;gap:12px;margin:14px 0}
.card{flex:1 1 190px;background:#f8f9fb;border:1px solid #e6e8eb;border-radius:8px;padding:12px 14px}
.card .k{font-size:11px;color:#666;text-transform:uppercase;letter-spacing:.4px}
.card .v{font-size:23px;font-weight:700;margin-top:3px}
.good{color:#0b6b36}.bad{color:#9b1c1c}
td.pos{background:#e6f5ec;color:#0b6b36;font-weight:700;text-align:right}
td.neg{background:#fdecec;color:#9b1c1c;font-weight:700;text-align:right}
.note{background:#f2f6ff;border-left:3px solid #305496;padding:9px 13px;margin:10px 0;
font-size:13px;color:#33415c}
img.chart{width:100%;border:1px solid #e6e8eb;border-radius:8px}
a{color:#305496}
.foot{margin-top:30px;padding-top:14px;border-top:1px solid #e6e8eb;color:#777;font-size:12px}
"""

_JS = """
(function(){
 function num(s){var t=String(s).replace(/,/g,'').trim().replace(/^[#!]/,'');
  var m=t.match(/^-?\\d+(\\.\\d+)?/); if(!m) return null;
  var rest=t.slice(m[0].length).trim(); if(rest&&/[\\d\\-\\/:]/.test(rest)) return null;
  return parseFloat(m[0]);}
 function blank(s){return s===''||s==='\\u2014'||s==='-';}
 document.querySelectorAll('table.data').forEach(function(tb){
  var heads=tb.tHead?tb.tHead.rows[0].cells:null; if(!heads) return;
  Array.prototype.forEach.call(heads,function(th,i){
   th.title='Click to sort';
   th.addEventListener('click',function(){
    var dir=th.dataset.dir==='asc'?'desc':'asc';
    Array.prototype.forEach.call(heads,function(o){o.dataset.dir='';});
    th.dataset.dir=dir;
    var body=tb.tBodies[0], rows=Array.prototype.slice.call(body.rows);
    rows.sort(function(a,b){
     var x=(a.cells[i]||{}).innerText||'', y=(b.cells[i]||{}).innerText||'';
     x=x.trim();y=y.trim();
     if(blank(x)&&blank(y))return 0; if(blank(x))return 1; if(blank(y))return -1;
     var nx=num(x),ny=num(y),r;
     if(nx!==null&&ny!==null)r=nx-ny; else r=x.localeCompare(y,undefined,{numeric:true});
     return dir==='asc'?r:-r;});
    rows.forEach(function(r){body.appendChild(r);});});});
  var box=tb.closest('.tbl').querySelector('.filter');
  var cnt=tb.closest('.tbl').querySelector('.count');
  if(cnt&&tb.tBodies[0])cnt.textContent=tb.tBodies[0].rows.length+' row(s)';
  if(box)box.addEventListener('input',function(){
   var t=box.value.toLowerCase(),n=0;
   Array.prototype.forEach.call(tb.tBodies[0].rows,function(r){
    var hit=!t||(r.innerText||'').toLowerCase().indexOf(t)>-1;
    r.style.display=hit?'':'none'; if(hit)n++;});
   if(cnt)cnt.textContent=t?n+' of '+tb.tBodies[0].rows.length+' row(s)':
    tb.tBodies[0].rows.length+' row(s)';});});
})();
"""


def _e(x):
    return _html.escape(str(x if x is not None else ""))


def _html_table(headers, rows, row_class=None, link_col=None, filter_hint="Filter rows...",
                scroll=True, pct_cols=None, scope_col=None):
    head = "".join("<th>%s</th>" % _e(h) for h in headers)
    body = []
    for r in rows:
        cls = row_class(r) if row_class else ""
        if scope_col is not None and str(r[scope_col]).lower().startswith("out"):
            cls = "outscope"          # excluded from the metrics
        cells = []
        for i, v in enumerate(r):
            if link_col is not None and i == link_col and v:
                cells.append('<td><a href="%s" target="_blank">open</a></td>' % _e(v))
            elif pct_cols and i in pct_cols and isinstance(v, (int, float)):
                cells.append('<td class="%s">%+.1f%%</td>' % ("pos" if v >= 0 else "neg", v))
            else:
                cells.append("<td>%s</td>" % _e(v))
        body.append('<tr class="%s">%s</tr>' % (cls, "".join(cells)))
    inner = ('<table class="data"><thead><tr>%s</tr></thead><tbody>%s</tbody></table>'
             % (head, "".join(body)))
    if scroll:
        inner = '<div class="scroll">%s</div>' % inner
    return ('<div class="tbl"><div class="bar">'
            '<input class="filter" type="text" placeholder="%s"><span class="count"></span>'
            "</div>%s</div>" % (_e(filter_hint), inner))


def write_html(settings, ser, windows, months, issues, mrs, chart_png, current_month,
               output_dir, label=None, include_pod=False, file_prefix=None) -> str:
    name = label or settings.crew_name
    gen = _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    base_lab = ser.baseline_label or ""

    chart_tag = ""
    if chart_png and os.path.exists(chart_png):
        with open(chart_png, "rb") as fh:
            b64 = base64.b64encode(fh.read()).decode("ascii")
        chart_tag = ('<img class="chart" alt="dashboard" src="data:image/png;base64,%s">' % b64)

    cards = []
    og = ser.overall_gain
    cards.append('<div class="card"><div class="k">Overall Productivity Gain</div>'
                 '<div class="v %s">%s</div></div>'
                 % ("good" if (og is not None and og >= 0) else "bad",
                    "n/a" if og is None else "%+.2f%%" % og))
    for k, lbl, _lower in METRIC_DEFS:
        v = ser.progress_pct.get(k)
        cards.append('<div class="card"><div class="k">%s</div><div class="v %s">%s</div></div>'
                     % (_e(lbl), "good" if (v is not None and v >= 0) else "bad",
                        "n/a" if v is None else "%+.2f%%" % v))

    irows, _ = issue_rows(issues, include_pod)
    ihdr = ([POD_COL] + ISSUE_HEADERS) if include_pod else ISSUE_HEADERS
    ioff = 1 if include_pod else 0
    mrows, _ = mr_rows(mrs, include_pod)
    mhdr = ([POD_COL] + MR_HEADERS) if include_pod else MR_HEADERS
    ahdr, arows = mr_author_table(mrs, windows)

    body = """
<h1>Delivery Productivity &mdash; %s</h1>
<div class="sub">3-month rolling windows &nbsp;|&nbsp; baseline %s (%s) &nbsp;|&nbsp; %s to %s
&nbsp;|&nbsp; generated %s</div>
<div class="note">The current month (%s) is excluded &mdash; it is incomplete, so any window
containing it would read low.</div>
<div class="cards">%s</div>

<h2>Parameters per window</h2>
<div class="note">Newest window first. The <b>baseline window is highlighted</b>. Cycle Time and
Lead Time are lower-is-better.</div>
%s

<h2>Shift against baseline %s</h2>
<div class="note">Positive is always better &mdash; the sign for Cycle Time and Lead Time is
already inverted. <b>Overall</b> is the plain mean of the four.</div>
%s

<h2>Dashboard</h2>
%s

<h2>Issues &mdash; per window</h2>
<div class="note"><b>Issue Throughput</b> counts <b>every</b> closed issue in the window divided by
the number of pods. <b>Cycle Time</b> uses only issues that reached <i>in progress</i>, with the
slowest %g%% of the window removed before averaging.</div>
%s

<h2>Merge requests &mdash; per window</h2>
<div class="note"><b>Merged MR per Author</b> counts <b>every</b> merged MR in the window,
including those with a lead time over a year. <b>Lead Time</b> excludes those.</div>
%s

<h2>Merged per author, per window</h2>
%s

<h2>Issues &mdash; all closed</h2>
<div class="note">Every closed issue, newest first. All of them count towards Issue Throughput; the
<b>Scope</b> column marks those eligible for Cycle Time.</div>
%s

<h2>Merge requests &mdash; all merged</h2>
<div class="note">Every merged MR, newest first. All of them count towards Merged MR per Author;
the <b>Scope</b> column marks those inside the one-year limit used for Lead Time.</div>
%s

<div class="foot">Merge requests are fetched once for the crew and attributed to pods by matching
the author's GPN against pod membership. A person in two pods has their merge requests counted in
both pods, but only once at crew level.</div>
""" % (_e(name), _e(base_lab), _e(", ".join(ser.baseline_months)),
       _e(ser.window_labels[0] if ser.window_labels else ""),
       _e(ser.window_labels[-1] if ser.window_labels else ""), _e(gen), _e(current_month),
       "".join(cards),
       _html_table(WINDOW_HEADERS, window_rows(windows),
                   row_class=lambda r: "baseline" if r[0] == base_lab else "",
                   filter_hint="Filter windows...", scroll=False),
       _e(base_lab),
       _html_table(SHIFT_HEADERS, shift_rows(ser),
                   row_class=lambda r: "baseline" if r[0] == base_lab else "",
                   filter_hint="Filter windows...", scroll=False, pct_cols=[1, 2, 3, 4, 5]),
       chart_tag, settings.issue_slowest_trim_pct,
       _html_table(ISSUE_WINDOW_HEADERS,
                   issue_window_rows(windows, settings.issue_slowest_trim_pct),
                   row_class=lambda r: "baseline" if r[0] == base_lab else "",
                   filter_hint="Filter windows...", scroll=False),
       _html_table(MR_WINDOW_HEADERS, mr_window_rows(windows),
                   row_class=lambda r: "baseline" if r[0] == base_lab else "",
                   filter_hint="Filter windows...", scroll=False),
       _html_table(ahdr, arows, filter_hint="Filter authors..."),
       _html_table(ihdr, irows,
                   row_class=lambda r: "flag" if str(r[11 + ioff]).upper() == "Y" else "",
                   link_col=19 + ioff, filter_hint="Filter issues...", scope_col=ioff),
       _html_table(mhdr, mrows,
                   row_class=lambda r: "flag" if str(r[17 + ioff]).upper() == "Y" else "",
                   link_col=20 + ioff, filter_hint="Filter merge requests...", scope_col=ioff))

    doc = ("<!DOCTYPE html><html><head><meta charset='utf-8'><title>Delivery Productivity - %s"
           "</title><style>%s</style></head><body><div class='wrap'>%s</div>"
           "<script>%s</script></body></html>" % (_e(name), _CSS, body, _JS))

    os.makedirs(output_dir, exist_ok=True)
    safe = file_prefix or "".join(
        c if (c.isalnum() or c in "._-") else "_" for c in name).strip("_")
    path = os.path.join(output_dir, "%s_%s.html"
                        % (safe, _dt.datetime.now().strftime("%Y%m%d_%H%M%S")))
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(doc)
    log.info("HTML written: %s", path)
    return path
