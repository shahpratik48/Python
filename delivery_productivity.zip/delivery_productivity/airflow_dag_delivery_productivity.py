"""
airflow_dag_delivery_productivity.py
-------------------------------------
Pod and crew delivery productivity.

For every pod in delivery_config.json: an XLSX, an HTML report and four pod
tables. Then a crew roll-up from the same data: one more XLSX, HTML and four
crew tables.

Two tasks:

    run_reports  ->  summarise

Collection, reporting and the database load happen in one pass. Splitting
them across tasks would mean collecting twice, which doubles the slowest
part of the job; the reports are written before the load, so a Greenplum
failure still leaves the files on disk.

Schedule: 18:00 America/New_York, Monday to Friday.

Secrets come from Airflow Variables:
    GENESIS_DDLC_IKG_GIT_SECRET   GitLab token
    GREENPLUM_PASSWORD            Greenplum password

Deploy alongside the delivery_*.py modules and delivery_config.json in the
SAME folder.
"""
from __future__ import annotations

import os
import sys
from datetime import datetime, timedelta

import pendulum
from airflow import DAG
from airflow.models import Variable
from airflow.operators.python import PythonOperator

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from delivery_main import run_all
from delivery_settings import DeliverySettings, get_logger, setup_logging

HERE = os.path.dirname(os.path.abspath(__file__))
EST = pendulum.timezone("America/New_York")


def _var(k, d=None):
    try:
        return Variable.get(k, default_var=d)
    except Exception:
        return d


def task_run_reports(**kwargs):
    log_path = setup_logging("INFO", log_dir=HERE)
    log = get_logger("delivery.dag")
    conf = (kwargs.get("dag_run").conf if kwargs.get("dag_run") else {}) or {}

    s = DeliverySettings()
    s.output_dir = HERE
    s.gp_schema = _var("DELIVERY_GP_SCHEMA", s.gp_schema)
    s.max_workers = int(_var("DELIVERY_MAX_WORKERS", str(s.max_workers)))
    s.resolve_secrets(interactive=False)

    # A one-off full reload after a definition change, without editing code.
    force = str(conf.get("force_full_refresh",
                         _var("DELIVERY_FORCE_FULL_REFRESH", "false"))).lower() == "true"
    pod_workers = int(conf.get("pod_workers", _var("DELIVERY_POD_WORKERS", "3")))
    only_crew = conf.get("crew") or None

    results = run_all(s, progress=print, force_full_refresh=force,
                      pod_workers=pod_workers, only_crew=only_crew)

    payload, failures = [], []
    for rr in results:
        entry = {"crew": rr.crew, "pods": [], "crew_outputs": {}}
        for p in rr.pods:
            if p.error:
                failures.append("%s / %s: %s" % (rr.crew, p.name, p.error))
                continue
            entry["pods"].append({"pod": p.name, "xlsx": p.xlsx_path, "html": p.html_path,
                                   "issues": len(p.issues), "mrs": len(p.mrs),
                                   "gain": p.series.overall_gain,
                                   "months_fetched": p.months_fetched})
        if rr.crew_result:
            cr = rr.crew_result
            entry["crew_outputs"] = {"xlsx": cr.xlsx_path, "html": cr.html_path,
                                      "issues": len(cr.issues), "mrs": len(cr.mrs),
                                      "gain": cr.series.overall_gain}
        payload.append(entry)

    ti = kwargs["ti"]
    ti.xcom_push(key="results", value=payload)
    ti.xcom_push(key="failures", value=failures)
    ti.xcom_push(key="log_path", value=log_path)

    if failures:
        # every healthy pod still produced its reports; the task goes red so
        # the failure is not silently absorbed
        raise RuntimeError("%d pod(s) failed:\n%s" % (len(failures), "\n".join(failures)))
    log.info("All pods and crew roll-ups completed.")


def task_summarise(**kwargs):
    ti = kwargs["ti"]
    results = ti.xcom_pull(task_ids="run_reports", key="results") or []
    failures = ti.xcom_pull(task_ids="run_reports", key="failures") or []
    print("=" * 72)
    for e in results:
        print("CREW %s" % e["crew"])
        for p in e["pods"]:
            print("   pod %-18s issues=%-6s mrs=%-5s gain=%s%%  %s"
                  % (p["pod"], p["issues"], p["mrs"], p["gain"],
                     os.path.basename(p["xlsx"] or "")))
        c = e.get("crew_outputs") or {}
        if c:
            print("   CREW ROLL-UP        issues=%-6s mrs=%-5s gain=%s%%  %s"
                  % (c["issues"], c["mrs"], c["gain"], os.path.basename(c["xlsx"] or "")))
    for f in failures:
        print("FAILED: %s" % f)
    print("=" * 72)


default_args = {
    "owner": "STAAT-DS",
    "retries": 1,
    "retry_delay": timedelta(minutes=10),
    "email_on_failure": True,
}

with DAG(
    dag_id="delivery_pod_crew_productivity",
    default_args=default_args,
    description="Per-pod and crew delivery productivity: XLSX + HTML with an embedded "
                "dashboard, and eight Greenplum tables.",
    start_date=datetime(2026, 1, 1, tzinfo=EST),
    schedule_interval="0 18 * * 1-5",        # 18:00 EST, Monday-Friday
    catchup=False,
    max_active_runs=1,
    tags=["gitlab", "pod", "crew", "productivity", "greenplum"],
) as dag:

    t1 = PythonOperator(task_id="run_reports", python_callable=task_run_reports)
    t2 = PythonOperator(task_id="summarise", python_callable=task_summarise,
                        trigger_rule="all_done")

    t1 >> t2
