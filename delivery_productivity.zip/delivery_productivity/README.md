# Pod & Crew Delivery Productivity

One report per **pod**, then a **crew roll-up** from the same data. XLSX and HTML, each with the
dashboard embedded, plus Greenplum tables.

| Level | Outputs |
|---|---|
| Each pod | 1 XLSX · 1 HTML · **4 tables** |
| Crew | 1 XLSX · 1 HTML · **4 tables** (separate from the pod tables) |

With three pods under one crew that is **8 files and 8 tables**.

---

# Greenplum tables

**Schema: `sandbox_prj_smart_insights`** (`DELIVERY_GP_SCHEMA` to change)

**Ten tables in total** — two for configuration, four per pod scope, four for the crew roll-up.

### Configuration (created by `setup_config_tables.py`, run once)

| Table | Contents |
|---|---|
| `sandbox_prj_smart_insights.delivery_org_hierarchy` | one row per pod, with its full org path |
| `sandbox_prj_smart_insights.delivery_pod_links` | one row per issue/MR link |

### Pod level

| Table | Contents |
|---|---|
| `sandbox_prj_smart_insights.pod_issue_detail` | one row per closed issue, in scope or not |
| `sandbox_prj_smart_insights.pod_mr_detail` | one row per merged MR, in scope or not |
| `sandbox_prj_smart_insights.pod_issue_monthly_summary` | issue parameters per pod per month |
| `sandbox_prj_smart_insights.pod_mr_monthly_summary` | MR parameters per pod per month |

### Crew level

| Table | Contents |
|---|---|
| `sandbox_prj_smart_insights.crew_rollup_issue_detail` | the same issues, crew-wide |
| `sandbox_prj_smart_insights.crew_rollup_mr_detail` | the same MRs, crew-wide |
| `sandbox_prj_smart_insights.crew_rollup_issue_monthly_summary` | issue parameters per crew per month |
| `sandbox_prj_smart_insights.crew_rollup_mr_monthly_summary` | MR parameters per crew per month |

**The two sets are deliberately separate**, and deliberately *not* named like the crew-level project's
tables. A pod row and a crew roll-up in the same table would double-count on any naive `SUM`, and
reusing the other project's names would let the two overwrite each other.

Every row carries `scope_name` (the pod or crew name) and `crew_name`, so one pod reloads without
disturbing another. Detail rows also carry `pod_name`.

### Ownership

Applied to every table after creation, and re-applied on each run:

```sql
ALTER TABLE <schema>.<table> OWNER TO <IKG_TABLE_OWNER_GROUP>;
GRANT SELECT ON <schema>.<table> TO <IKG_TABLE_READER_GROUP>;
```

Defaults are `erd_gpdb_prj_smart_insights` and `erd_gpdb_prj_smart_insights_ro`. The schema is
assumed to exist and is not created.

---

# Output files

```
<Pod Name>_pod_productivity_<timestamp>.xlsx
<Pod Name>_pod_productivity_<timestamp>.html
<Pod Name>_pod_productivity_dashboard.png

<Crew Name>_crew_productivity_<timestamp>.xlsx
<Crew Name>_crew_productivity_<timestamp>.html
<Crew Name>_crew_productivity_dashboard.png
```

### Six worksheets in every workbook

| # | Sheet | Contents |
|---|---|---|
| 1 | Summary | Monthly parameters (baseline months highlighted) · Shift against baseline, green when better, red when worse |
| 2 | Dashboard | the chart |
| 3 | Issues-summary | per month: Closed · From in progress · From opened · Avg business days · Flagged · Not measurable |
| 4 | MR-summary | By state · Merged — elapsed time · Merged per author |
| 5 | Issue List | every closed issue, **newest closed first** |
| 6 | MR List | every merged MR, **newest merged first** |

No frozen panes anywhere. The autofilter is on the two list sheets only.

**On the crew report, both list sheets lead with a `POD_name` column** so every row is attributable.
Pod reports omit it — the pod is already in the file name.

---


# The four parameters

Everything is computed **per 3-month window**, from that window's whole population — not by
averaging monthly figures. The slowest-15% trim and the MRs-per-author ratio are both defined over
the window, and neither survives being computed monthly and then averaged.

| Parameter | Definition |
|---|---|
| **Issue Throughput** | **every** closed issue in the window ÷ number of pods — scope is irrelevant here |
| **Cycle Time (Days)** | only issues that reached **In Progress**; sort by cycle time, drop the slowest **15%**, average the rest |
| **Merged MR per Author** | **every** merged MR in the window ÷ distinct authors — including MRs older than a year |
| **Lead Time (Hrs)** | merged MRs with a lead time **under one year**, averaged |

Note the deliberate asymmetry: *Merged MR per Author* counts the year-plus MRs, *Lead Time* does not.
They answer different questions from the same population — how much is landing, versus how long the
landings take.

# Where the data comes from

## Only active configuration is used

Every read of `delivery_org_hierarchy` and `delivery_pod_links` filters on
**`COALESCE(is_active, true)`** — in the reporting job and in the dashboard UI alike. Inactive pods
and inactive links take no part in any pod or crew calculation.

`COALESCE` rather than a bare `WHERE is_active`: a row inserted by hand without the flag would
otherwise be `NULL` and vanish silently. Retiring something has to be deliberate, so `NULL` counts as
active. The run logs how many rows were excluded:

```
Excluded as inactive: 1 pod row(s) and 2 link row(s).
```

**The crew's throughput divisor is the count of ACTIVE pods in `delivery_org_hierarchy`** — not the
number of pods that happened to report. A pod that is active but misconfigured, or that failed on the
day, still counts in the divisor; otherwise a broken pod would quietly flatter the crew's per-pod
figure. That case is flagged:

```
Crew 'STAAT Data Science': 4 active pod(s) in the hierarchy but only 3 have usable links.
Throughput still divides by 4.
```

**Issues** — each pod's `link_type='issue'` rows in `delivery_pod_links` are **group** paths. Every
project beneath each group is scanned.

**Merge requests** — a single group, `mr_source.mr_link` in `delivery_config.json`, fetched **once
per crew**. Pods do not fetch separately: the same repositories serve several pods, so per-pod
fetching would pull the same MRs repeatedly and then have to de-duplicate them. `link_type='mr'`
rows are no longer used.

## Attribution by GPN

GitLab carries the GPN inside the author's display name (`Lastname Firstname 43704137`). It is
lifted out into its own column and matched against `crew_pod_pod_member`:

| Level | Rule |
|---|---|
| **Pod** | MRs whose author GPN belongs to that pod. A person in two pods has their MRs counted in **both**. |
| **Crew** | MRs whose author GPN belongs to **any** pod of the crew, each counted **once** — shared membership does not inflate the crew. |

The MR list carries **Author**, **Author GPN** and **Author Email** separately. Where the author name
has no GPN the MR cannot be attributed, and the run logs how many were affected.

## Baseline, shift and the chart

The baseline is the **`Nov 25-Jan 26` window** — the same pooled calculation as every other window,
so the aspiration starts exactly on the actual there.

Each panel headline compares the **last point on its line** with the **baseline point** — both are
3-month window averages:

```
shift = (last window − baseline window) / |baseline window| × 100
```

sign-flipped for Cycle Time and Lead Time, so **positive always means better**. **Overall** is the
plain mean of the four.

Worked example — *Merged MR per Author*, with monthly values 3.00 (May), 9.75 (Jun), 9.40 (Jul) and
baseline months 4.75, 3.33, 2.25:

```
baseline window  (Nov 25-Jan 26) = (4.75 + 3.33 + 2.25) / 3 = 3.44
last window      (May 26-Jul 26) = (3.00 + 9.75 + 9.40) / 3 = 7.38
shift = (7.38 − 3.44) / 3.44 × 100 = +114.35%
```

Both endpoints are **window averages**, matching the plotted line. Comparing the last single *month*
(9.40) instead would read +173%, which is a defensible number but describes a different period from
the line beneath the title — so the two would appear to contradict each other.

The chart plots **3-month rolling windows** — `Nov 24-Jan 25`, `Dec 24-Feb 25`, … through
`May 26-Jul 26`. Every window is labelled on the x axis. The **current month is excluded entirely**:
it is incomplete, so any window containing it would read as a false decline. The aspiration anchor is
the `Nov 25-Jan 26` window, so **aspiration starts precisely on the actual there** and nothing is
drawn before it.

The **Issues-summary** and **MR-summary** sheets list every window with its underlying counts, so the
chart can be reconciled line by line.

---

# Files

| File | Purpose |
|---|---|
| `delivery_config.json` | Reporting window, baseline and thresholds **only** |
| `setup_config_tables.py` | **Run once** — creates and seeds the two configuration tables |
| `HOW_TO_CONFIGURE.md` | How to add a division, stream, crew, pod or link |
| `delivery_settings.py` | Config loading and validation, secrets, logging |
| `delivery_gitlab.py` | GitLab client — project resolution, issues, MRs, iterations, parallel fetching |
| `delivery_metrics.py` | The four parameters, scope rules, baseline, aspiration, shift |
| `delivery_charts.py` | The dashboard figure |
| `delivery_output.py` | XLSX and HTML generation |
| `delivery_greenplum.py` | Table creation, grants, incremental load |
| `delivery_main.py` | `run_all()` — pods in parallel, then the crew roll-up |
| `airflow_dag_delivery_productivity.py` | Airflow DAG, **18:00 EST Mon–Fri** |
| `run_delivery_productivity.ipynb` | Notebook |

---

# Performance

The job is network-bound, and it now spans several pods.

**Parallel on two levels.** Pods run concurrently (`pod_workers`, default 3) and the fetching inside
each pod is itself parallel (`DELIVERY_MAX_WORKERS`, default 32). They multiply, so `pod_workers` is
kept modest — together they decide how many connections a shared GitLab instance sees. Lower either
if you start seeing 429s; the client already retries those with backoff.

**The crew roll-up costs nothing extra.** It reuses the pod data rather than re-querying. The crew
covers every project of every pod, so fetching again would double the slowest part of the run *and*
risk numbers that disagree with the pod reports they summarise.

**Loading is incremental, at the fetch level.** Settled months are collected once; after that only
the **current month** is re-fetched, deleted and rewritten, per pod. `pod_issue_monthly_summary` is
the authority on what has been loaded — a month where a pod closed nothing still gets a summary row,
whereas the detail table would leave no trace and be re-fetched forever.

The `updated_after` sent to GitLab moves with it: `2024-11-01` on the first run, the current month's
first day on every run afterwards.

If Greenplum is unreachable or the tables do not exist, the run falls back to fetching the full
history rather than failing.

## Forcing a full refresh

After any definition or config change, stored history is no longer comparable:

```python
run_all(settings, force_full_refresh=True)
```

From Airflow, trigger with config `{"force_full_refresh": true}`.

---

# Running it

**Notebook** — open `run_delivery_productivity.ipynb` and run the cells. It prompts for both
credentials.

**Airflow** — deploy the DAG beside the `delivery_*.py` files **and `delivery_config.json`**. Two
tasks: `run_reports → summarise`, at **18:00 America/New_York, Monday to Friday**.

Optional trigger config: `{"force_full_refresh": true}`, `{"pod_workers": 5}`,
`{"crew": "STAAT Data Science"}`.

Secrets resolve as environment variable → Airflow Variable → prompt (notebook only):

| Secret | Airflow Variable |
|---|---|
| GitLab token | `GENESIS_DDLC_IKG_GIT_SECRET` |
| Greenplum password | `GREENPLUM_PASSWORD` |

## Environment variables

| Variable | Default |
|---|---|
| `DELIVERY_CONFIG_FILE` | `delivery_config.json` beside the scripts |
| `DELIVERY_MAX_WORKERS` | 32 |
| `DELIVERY_GP_SCHEMA` | sandbox_prj_smart_insights |
| `DELIVERY_LOAD_GP` | true |
| `IKG_TABLE_OWNER_GROUP` | erd_gpdb_prj_smart_insights |
| `IKG_TABLE_READER_GROUP` | erd_gpdb_prj_smart_insights_ro |
| `DELIVERY_IN_PROGRESS_LABELS` | `in progress,in-progress,doing,wip` |

---

# Diagnosing a pod that produces nothing

Every configured path is resolved explicitly and the outcome logged per path:

```
  project   ubs/.../staat-ds-insights-home -> 1 project(s)
  group     ubs/.../ds-data                -> 3 project(s)
  FAILED    ubs/.../typo                   -- not found as a project or a group (404)
```

A path may name a **project or a group** — projects are tried first, then groups, and a group is
expanded including sub-groups **and shared projects**. A repository shared into a group is still the
crew's work, and excluding it previously lost whole pods whose repos live under a different parent.

If a pod resolves to **no projects at all**, or collects no issues and no merge requests, the run
**fails for that pod with the reason named**:

```
pod 'DS Data' issues: None of the 1 configured path(s) resolved to a project:
  - ubs/.../ds-data (the token cannot read this path (401/403))
Check the paths in delivery_pod_links and that the token can read them.
```

Previously these cases were indistinguishable — "not a project", "not a group", "no access" and
"empty group" all returned an empty list, so the pod produced an empty report with no clue why.
The four now report differently:

| Symptom | Meaning |
|---|---|
| `not found as a project or a group (404)` | the path in `delivery_pod_links` is wrong |
| `the token cannot read this path (401/403)` | the path is right; the token lacks access |
| `group exists but contains no readable, non-archived project` | right group, nothing in it |
| `request failed` | network or timeout — the exception is logged above it |

The other pods still complete; only the failing one stops, and the task then goes red so the failure
is not absorbed.

# Column alignment

The COPY row lists and the column lists in `delivery_greenplum.py` are positional and **must stay in
the same order**. When they drift, values land in the wrong column and Postgres reports it as a type
error pointing at an innocent column:

```
InvalidTextRepresentation: invalid input syntax for integer: "13.0"
CONTEXT: COPY pod_issue_monthly_summary, line 1, column issues_total: "13.0"
```

`issues_total` was fine; a *throughput* value had shifted into it because two columns had been added
without extending the row.

Two guards now make that impossible to miss:

* **`_copy()` asserts the row length** against the column list and raises a message naming the table,
  both counts and the expected columns — before anything reaches the database.
* **Integer columns coerce a whole-number float.** A count arriving as `13.0` is still a count;
  Postgres will not coerce it, so rounding here beats failing an entire load over a formatting
  detail.

# Concurrency and DDL

Pods run in parallel and **share** the same four tables. `CREATE TABLE IF NOT EXISTS` is *not*
atomic, so several pods creating the same table at once produced:

```
psycopg2.errors.UniqueViolation: duplicate key value violates unique constraint
  "pg_type_typname_nsp_index"
DETAIL: Key (typname, typnamespace)=(pod_issue_detail, 42355703) already exists.
```

The loser's whole load was rolled back, so that pod failed while the others succeeded — which looked
like a problem with the pod rather than a race.

Three changes:

1. **`ensure_tables()` runs once, up front, single-threaded** — before any pod starts. All DDL is
   removed from the per-pod load path.
2. **A process-wide lock** serialises DDL, in case `ensure_tables` is ever called concurrently.
3. **A concurrent create is treated as the desired end state.** Greenplum reports it as a
   `UniqueViolation` on `pg_type` rather than `DuplicateTable`, so the check matches on the message
   as well as the class. A genuine error — a permissions failure, say — still raises.

**Verified:** three threads calling `ensure_tables` at once made 12 CREATE attempts against 4 tables
with **zero exceptions**, and a full three-pod run against a database that raises on duplicate CREATE
completed with **no failed pods**.

# Resilience

**One pod failing does not stop the rest.** It is logged and reported, the other pods still produce
their reports, and the crew roll-up is built from those that succeeded. The task then fails so the
problem is not silently absorbed.

---

# Validation performed

Tested end to end against a mocked GitLab across 21 months and the three configured pods:

- **Per-pod outputs** — 3 pods produced 3 XLSX, 3 HTML and 3 PNGs; the crew roll-up added its own
  set, 12 files in total.
- **Roll-up reconciles** — crew issue and MR totals equal the sum of the pods exactly
  (378 issues, 693 MRs).
- **`POD_name` column** — present as the first column on both crew list sheets with all three pod
  names, absent on pod reports.
- **Six worksheets** in every workbook, none with frozen panes, both list sheets sorted descending by
  closed / merged date.
- **Incremental load** — run 1 fetched 21 months per pod; run 2 fetched only `2026-07` per pod
  (`updated_after` = `2026-07-01`), read 20 months back from Greenplum, and produced identical
  totals.
- **Table scoping** — all 8 tables written, `pod_*` scoped by the three pod names and `crew_rollup_*`
  by the crew name.
