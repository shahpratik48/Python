# Pod & Crew Delivery Productivity

One report per **pod**, then a **crew roll-up** from the same data. XLSX and HTML, each with the
dashboard embedded, plus Greenplum tables.

| Level | Outputs |
|---|---|
| Each pod | 1 XLSX · 1 HTML · **4 tables** |
| Crew | 1 XLSX · 1 HTML · **4 tables** (separate from the pod tables) |

With three pods under one crew that is **8 files and 8 tables**.

---

# Greenplum tables

**Schema: `sandbox_prj_smart_insights`** (`DELIVERY_GP_SCHEMA` to change)

**Ten tables in total** — two for configuration, four per pod scope, four for the crew roll-up.

### Configuration (created by `setup_config_tables.py`, run once)

| Table | Contents |
|---|---|
| `sandbox_prj_smart_insights.delivery_org_hierarchy` | one row per pod, with its full org path |
| `sandbox_prj_smart_insights.delivery_pod_links` | one row per issue/MR link |

### Pod level

| Table | Contents |
|---|---|
| `sandbox_prj_smart_insights.pod_issue_detail` | one row per closed issue, in scope or not |
| `sandbox_prj_smart_insights.pod_mr_detail` | one row per merged MR, in scope or not |
| `sandbox_prj_smart_insights.pod_issue_monthly_summary` | issue parameters per pod per month |
| `sandbox_prj_smart_insights.pod_mr_monthly_summary` | MR parameters per pod per month |

### Crew level

| Table | Contents |
|---|---|
| `sandbox_prj_smart_insights.crew_rollup_issue_detail` | the same issues, crew-wide |
| `sandbox_prj_smart_insights.crew_rollup_mr_detail` | the same MRs, crew-wide |
| `sandbox_prj_smart_insights.crew_rollup_issue_monthly_summary` | issue parameters per crew per month |
| `sandbox_prj_smart_insights.crew_rollup_mr_monthly_summary` | MR parameters per crew per month |

**The two sets are deliberately separate**, and deliberately *not* named like the crew-level project's
tables. A pod row and a crew roll-up in the same table would double-count on any naive `SUM`, and
reusing the other project's names would let the two overwrite each other.

Every row carries `scope_name` (the pod or crew name) and `crew_name`, so one pod reloads without
disturbing another. Detail rows also carry `pod_name`.

### Ownership

Applied to every table after creation, and re-applied on each run:

```sql
ALTER TABLE <schema>.<table> OWNER TO <IKG_TABLE_OWNER_GROUP>;
GRANT SELECT ON <schema>.<table> TO <IKG_TABLE_READER_GROUP>;
```

Defaults are `erd_gpdb_prj_smart_insights` and `erd_gpdb_prj_smart_insights_ro`. The schema is
assumed to exist and is not created.

---

# Output files

```
<Pod Name>_pod_productivity_<timestamp>.xlsx
<Pod Name>_pod_productivity_<timestamp>.html
<Pod Name>_pod_productivity_dashboard.png

<Crew Name>_crew_productivity_<timestamp>.xlsx
<Crew Name>_crew_productivity_<timestamp>.html
<Crew Name>_crew_productivity_dashboard.png
```

### Six worksheets in every workbook

| # | Sheet | Contents |
|---|---|---|
| 1 | Summary | Monthly parameters (baseline months highlighted) · Shift against baseline, green when better, red when worse |
| 2 | Dashboard | the chart |
| 3 | Issues-summary | per month: Closed · From in progress · From opened · Avg business days · Flagged · Not measurable |
| 4 | MR-summary | By state · Merged — elapsed time · Merged per author |
| 5 | Issue List | every closed issue, **newest closed first** |
| 6 | MR List | every merged MR, **newest merged first** |

No frozen panes anywhere. The autofilter is on the two list sheets only.

**On the crew report, both list sheets lead with a `POD_name` column** so every row is attributable.
Pod reports omit it — the pod is already in the file name.

---

# The four parameters

| Parameter | Definition | Direction |
|---|---|---|
| **Issue Throughput** | in-scope issues closed ÷ number of pods | higher is better |
| **Cycle Time (Days)** | average elapsed **business** days, first *In Progress* → last closed | **lower** is better |
| **Merged MR per Author** | in-scope merged MRs ÷ distinct authors | higher is better |
| **Lead Time (Hrs)** | average hours, first commit → merged | **lower** is better |

A pod report divides throughput by 1; the crew roll-up divides by however many pods reported, so the
two are on the same per-pod scale.

## Scope

Metrics and the graph use **in-scope** items only. The detail tables list **everything**, with
`Scope` and `Scope Reason` columns and out-of-scope rows greyed.

**Issues** are in scope when they **reached In Progress and were then closed** — measured first
in-progress → **last** closed, so a reopened issue counts to its final closure. Excluded:

| Reason |
|---|
| never moved to in progress (measured from iteration assignment) |
| never moved to in progress (measured from creation) |
| slowest 15% of issues closed in *month* |

**A closed date is enough.** Where the state history has no closed event, or records one before the
in-progress transition, the issue's own `closed_at` is used instead — GitLab reporting a `closed_at`
means the issue was closed, so it stays in scope. Where the transition is recorded *after* the
closure it still counts towards throughput but contributes no cycle time, and says so in its
`Scope Reason`.

The trim is per month and skipped where a month has fewer than three in-scope issues — a percentile
over one or two items means nothing.

**Merge requests** are in scope when **merged** with a **lead time under one year**. Opened,
closed-without-merging and locked MRs never enter the data.

## Baseline, shift and the chart

The baseline is the **mean of Nov-25, Dec-25 and Jan-26** per parameter, not one month — a
single-month baseline lets one quiet month distort every percentage.

```
shift = (value − baseline) / |baseline| × 100
```

sign-flipped for Cycle Time and Lead Time, so **positive always means better**. **Overall** is the
plain mean of the four.

The chart plots **3-month rolling windows** — `Nov 24-Jan 25`, `Dec 24-Feb 25`, … Each point is the
average of those months. The aspiration anchor is the `Nov 25-Jan 26` window, which spans exactly the
baseline months, so **aspiration starts precisely on the actual there** and nothing is drawn before
it.

---

# Files

| File | Purpose |
|---|---|
| `delivery_config.json` | Reporting window, baseline and thresholds **only** |
| `setup_config_tables.py` | **Run once** — creates and seeds the two configuration tables |
| `HOW_TO_CONFIGURE.md` | How to add a division, stream, crew, pod or link |
| `delivery_settings.py` | Config loading and validation, secrets, logging |
| `delivery_gitlab.py` | GitLab client — project resolution, issues, MRs, iterations, parallel fetching |
| `delivery_metrics.py` | The four parameters, scope rules, baseline, aspiration, shift |
| `delivery_charts.py` | The dashboard figure |
| `delivery_output.py` | XLSX and HTML generation |
| `delivery_greenplum.py` | Table creation, grants, incremental load |
| `delivery_main.py` | `run_all()` — pods in parallel, then the crew roll-up |
| `airflow_dag_delivery_productivity.py` | Airflow DAG, **18:00 EST Mon–Fri** |
| `run_delivery_productivity.ipynb` | Notebook |

---

# Performance

The job is network-bound, and it now spans several pods.

**Parallel on two levels.** Pods run concurrently (`pod_workers`, default 3) and the fetching inside
each pod is itself parallel (`DELIVERY_MAX_WORKERS`, default 32). They multiply, so `pod_workers` is
kept modest — together they decide how many connections a shared GitLab instance sees. Lower either
if you start seeing 429s; the client already retries those with backoff.

**The crew roll-up costs nothing extra.** It reuses the pod data rather than re-querying. The crew
covers every project of every pod, so fetching again would double the slowest part of the run *and*
risk numbers that disagree with the pod reports they summarise.

**Loading is incremental, at the fetch level.** Settled months are collected once; after that only
the **current month** is re-fetched, deleted and rewritten, per pod. `pod_issue_monthly_summary` is
the authority on what has been loaded — a month where a pod closed nothing still gets a summary row,
whereas the detail table would leave no trace and be re-fetched forever.

The `updated_after` sent to GitLab moves with it: `2024-11-01` on the first run, the current month's
first day on every run afterwards.

If Greenplum is unreachable or the tables do not exist, the run falls back to fetching the full
history rather than failing.

## Forcing a full refresh

After any definition or config change, stored history is no longer comparable:

```python
run_all(settings, force_full_refresh=True)
```

From Airflow, trigger with config `{"force_full_refresh": true}`.

---

# Running it

**Notebook** — open `run_delivery_productivity.ipynb` and run the cells. It prompts for both
credentials.

**Airflow** — deploy the DAG beside the `delivery_*.py` files **and `delivery_config.json`**. Two
tasks: `run_reports → summarise`, at **18:00 America/New_York, Monday to Friday**.

Optional trigger config: `{"force_full_refresh": true}`, `{"pod_workers": 5}`,
`{"crew": "STAAT Data Science"}`.

Secrets resolve as environment variable → Airflow Variable → prompt (notebook only):

| Secret | Airflow Variable |
|---|---|
| GitLab token | `GENESIS_DDLC_IKG_GIT_SECRET` |
| Greenplum password | `GREENPLUM_PASSWORD` |

## Environment variables

| Variable | Default |
|---|---|
| `DELIVERY_CONFIG_FILE` | `delivery_config.json` beside the scripts |
| `DELIVERY_MAX_WORKERS` | 32 |
| `DELIVERY_GP_SCHEMA` | sandbox_prj_smart_insights |
| `DELIVERY_LOAD_GP` | true |
| `IKG_TABLE_OWNER_GROUP` | erd_gpdb_prj_smart_insights |
| `IKG_TABLE_READER_GROUP` | erd_gpdb_prj_smart_insights_ro |
| `DELIVERY_IN_PROGRESS_LABELS` | `in progress,in-progress,doing,wip` |

---

# Diagnosing a pod that produces nothing

Every configured path is resolved explicitly and the outcome logged per path:

```
  project   ubs/.../staat-ds-insights-home -> 1 project(s)
  group     ubs/.../ds-data                -> 3 project(s)
  FAILED    ubs/.../typo                   -- not found as a project or a group (404)
```

A path may name a **project or a group** — projects are tried first, then groups, and a group is
expanded including sub-groups **and shared projects**. A repository shared into a group is still the
crew's work, and excluding it previously lost whole pods whose repos live under a different parent.

If a pod resolves to **no projects at all**, or collects no issues and no merge requests, the run
**fails for that pod with the reason named**:

```
pod 'DS Data' issues: None of the 1 configured path(s) resolved to a project:
  - ubs/.../ds-data (the token cannot read this path (401/403))
Check the paths in delivery_pod_links and that the token can read them.
```

Previously these cases were indistinguishable — "not a project", "not a group", "no access" and
"empty group" all returned an empty list, so the pod produced an empty report with no clue why.
The four now report differently:

| Symptom | Meaning |
|---|---|
| `not found as a project or a group (404)` | the path in `delivery_pod_links` is wrong |
| `the token cannot read this path (401/403)` | the path is right; the token lacks access |
| `group exists but contains no readable, non-archived project` | right group, nothing in it |
| `request failed` | network or timeout — the exception is logged above it |

The other pods still complete; only the failing one stops, and the task then goes red so the failure
is not absorbed.

# Concurrency and DDL

Pods run in parallel and **share** the same four tables. `CREATE TABLE IF NOT EXISTS` is *not*
atomic, so several pods creating the same table at once produced:

```
psycopg2.errors.UniqueViolation: duplicate key value violates unique constraint
  "pg_type_typname_nsp_index"
DETAIL: Key (typname, typnamespace)=(pod_issue_detail, 42355703) already exists.
```

The loser's whole load was rolled back, so that pod failed while the others succeeded — which looked
like a problem with the pod rather than a race.

Three changes:

1. **`ensure_tables()` runs once, up front, single-threaded** — before any pod starts. All DDL is
   removed from the per-pod load path.
2. **A process-wide lock** serialises DDL, in case `ensure_tables` is ever called concurrently.
3. **A concurrent create is treated as the desired end state.** Greenplum reports it as a
   `UniqueViolation` on `pg_type` rather than `DuplicateTable`, so the check matches on the message
   as well as the class. A genuine error — a permissions failure, say — still raises.

**Verified:** three threads calling `ensure_tables` at once made 12 CREATE attempts against 4 tables
with **zero exceptions**, and a full three-pod run against a database that raises on duplicate CREATE
completed with **no failed pods**.

# Resilience

**One pod failing does not stop the rest.** It is logged and reported, the other pods still produce
their reports, and the crew roll-up is built from those that succeeded. The task then fails so the
problem is not silently absorbed.

---

# Validation performed

Tested end to end against a mocked GitLab across 21 months and the three configured pods:

- **Per-pod outputs** — 3 pods produced 3 XLSX, 3 HTML and 3 PNGs; the crew roll-up added its own
  set, 12 files in total.
- **Roll-up reconciles** — crew issue and MR totals equal the sum of the pods exactly
  (378 issues, 693 MRs).
- **`POD_name` column** — present as the first column on both crew list sheets with all three pod
  names, absent on pod reports.
- **Six worksheets** in every workbook, none with frozen panes, both list sheets sorted descending by
  closed / merged date.
- **Incremental load** — run 1 fetched 21 months per pod; run 2 fetched only `2026-07` per pod
  (`updated_after` = `2026-07-01`), read 20 months back from Greenplum, and produced identical
  totals.
- **Table scoping** — all 8 tables written, `pod_*` scoped by the three pod names and `crew_rollup_*`
  by the crew name.
