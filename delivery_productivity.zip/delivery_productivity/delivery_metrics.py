"""
The four delivery parameters, per month, for the whole crew.

    Issue Throughput        issues closed in the month, DIVIDED BY THE NUMBER
                            OF PODS in the crew -- the crew spans several
                            pods, so a raw count says more about headcount
                            than about delivery
    Cycle Time (Days)       average elapsed BUSINESS days per closed issue
                            (weekends excluded)
    Merged MR per Author    merged MRs / distinct authors
    Lead Time (Hrs)         average elapsed hours per merged MR

SCOPE -- which items feed the metrics and the graph:

    Issues      only those that actually reached IN PROGRESS and were then
                CLOSED. Measured from the FIRST in-progress transition to the
                LAST closed event. An issue that never went in progress is
                reported but not counted: its elapsed time would describe how
                long it sat in a backlog, not how long the work took.
                The slowest 15% by cycle time are then trimmed, so a handful
                of stale tickets cannot dominate the average.

    Merge requests   merged only, and only where the lead time is under one
                year. A year-old branch is noise rather than signal.

Everything outside that is still listed in full in the detail tables, marked
"Out of scope" with the reason -- excluded from the arithmetic, never hidden.

Cycle Time start point, in priority order -- kept for reporting, since an
out-of-scope issue still shows how it would have been measured:

    1. the first time the issue moved to IN PROGRESS   (the only in-scope case)
    2. otherwise, the day an ITERATION was assigned to it
    3. otherwise, the creation date

Which of the three was used is carried on every issue row, because an
iteration-based figure reads differently from an in-progress one and a
reader should be able to see which they are looking at.

Elapsed time is measured in BUSINESS days: Saturdays and Sundays are
excluded entirely, so an issue opened Friday and closed Monday counts as
roughly one day rather than three. Public holidays are not accounted for.

Lead Time runs from the FIRST FILE CHECK-IN -- the earliest commit on the
merge request -- to the merge itself. Only merged MRs are considered at
all; opened, closed-without-merging and locked ones never enter the data.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Sequence, Tuple

from delivery_settings import get_logger

log = get_logger("delivery.metrics")

METRIC_DEFS = [
    ("throughput", "Issue Throughput", False),
    ("cycle_time", "Cycle Time (Days)", True),
    ("mr_per_author", "Merged MR per Author", False),
    ("lead_time", "Lead Time (Hrs)", True),
]
METRIC_KEYS = [m[0] for m in METRIC_DEFS]
LOWER_IS_BETTER = {a: low for a, _l, low in METRIC_DEFS}

ONE_YEAR_HOURS = 365 * 24.0        # merge requests slower than this are noise

FROM_IN_PROGRESS = "in_progress"
FROM_ITERATION = "iteration_assigned"
FROM_CREATED = "created"


# ------------------------------------------------------------------ time
def parse_ts(v: Optional[str]) -> Optional[datetime]:
    if not v:
        return None
    t = str(v).strip().replace("Z", "+00:00")
    try:
        dt = datetime.fromisoformat(t)
    except ValueError:
        for f in ("%Y-%m-%dT%H:%M:%S.%f%z", "%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%d"):
            try:
                dt = datetime.strptime(t, f)
                break
            except ValueError:
                continue
        else:
            return None
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt.astimezone(timezone.utc)


def elapsed_days(a: datetime, b: datetime) -> Optional[float]:
    """Fractional BUSINESS days between two instants, excluding Sat/Sun.

    Walks the interval a day at a time and counts only the portion falling
    on a weekday, so Friday afternoon to Monday morning is well under one
    business day rather than three. Whole weekends contribute nothing.
    """
    if not a or not b or b < a:
        return None
    total, cur, guard = 0.0, a, 0
    while cur < b and guard < 4000:
        nxt = (cur + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
        seg_end = min(nxt, b)
        if cur.weekday() < 5:                     # Mon=0 .. Fri=4
            total += (seg_end - cur).total_seconds() / 86400.0
        cur, guard = seg_end, guard + 1
    return round(total, 2)


def elapsed_hours(a: datetime, b: datetime) -> Optional[float]:
    if not a or not b or b < a:
        return None
    return round((b - a).total_seconds() / 3600.0, 2)


def month_key(dt: datetime) -> str:
    return dt.strftime("%Y-%m")


def month_range(start: str, end: str) -> List[str]:
    y, m = (int(x) for x in start.split("-"))
    ey, em = (int(x) for x in end.split("-"))
    out = []
    while (y, m) <= (ey, em):
        out.append("%04d-%02d" % (y, m))
        m += 1
        if m > 12:
            y, m = y + 1, 1
    return out


def month_label(mk: str) -> str:
    y, m = mk.split("-")
    return "%s %s" % (["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul",
                       "Aug", "Sep", "Oct", "Nov", "Dec"][int(m) - 1], y[2:])


def month_start(mk: str) -> datetime:
    return datetime.strptime(mk + "-01", "%Y-%m-%d").replace(tzinfo=timezone.utc)


# ------------------------------------------------------------------ rows
@dataclass
class IssueRow:
    project_path: str
    folders: str
    iid: int
    title: str
    author: str
    assignee: str
    month: str
    measured_from: str
    start_at: Optional[datetime]
    closed_at: Optional[datetime]
    cycle_days: Optional[float]
    flagged: bool
    iteration_name: str = ""
    iteration_start: str = ""
    iteration_end: str = ""
    epic_id: str = ""
    epic_name: str = ""
    web_url: str = ""
    pod_name: str = ""            # which pod this belongs to, for the crew roll-up
    in_scope: bool = False        # counted in the metrics and the graph
    scope_reason: str = ""        # why it was excluded, when it was


@dataclass
class MRRow:
    project_path: str
    folders: str
    iid: int
    title: str
    author: str
    month: str
    first_commit_at: Optional[datetime]
    merged_at: Optional[datetime]
    lead_hours: Optional[float]
    flagged: bool
    web_url: str = ""
    mr_id: str = ""                       # global MR id, distinct from the per-project iid
    target_project_id: str = ""
    source_branch: str = ""
    target_branch: str = ""
    created_at: Optional[datetime] = None
    first_approved_at: Optional[datetime] = None
    pod_name: str = ""
    author_gpn: str = ""
    author_display: str = ""      # the name with the GPN stripped off
    author_email: str = ""
    in_scope: bool = False
    scope_reason: str = ""


@dataclass
class MonthStats:
    month: str
    closed_count: int = 0            # raw issues closed
    throughput: Optional[float] = None   # closed_count / pod_count
    state_counts: Dict[str, int] = field(default_factory=dict)   # opened/merged/closed/locked
    cycle_time: Optional[float] = None
    mr_count: int = 0
    author_count: int = 0
    mr_per_author: Optional[float] = None
    lead_time: Optional[float] = None
    issues_flagged: int = 0
    mrs_flagged: int = 0
    from_in_progress: int = 0
    from_iteration: int = 0
    from_created: int = 0
    issues_total: int = 0          # every closed issue, in scope or not
    issues_out_of_scope: int = 0
    mrs_total: int = 0
    mrs_out_of_scope: int = 0

    @property
    def from_opened(self) -> int:
        """Issues whose clock started at the iteration assignment or, failing
        that, at creation -- both are "opened" in the crew's terms."""
        return self.from_iteration + self.from_created

    @property
    def not_measurable(self) -> int:
        return max(0, self.closed_count - self.from_in_progress - self.from_opened)

    @property
    def issues_in_scope(self) -> int:
        return self.closed_count

    def value(self, k):
        return getattr(self, k)


# ------------------------------------------------------------------ helpers
def first_in_progress(events: List[dict], wanted: Sequence[str]) -> Optional[datetime]:
    """Earliest moment an 'in progress' style label was ADDED."""
    w = [x.lower() for x in wanted]
    stamps = []
    for ev in events or []:
        if str(ev.get("action", "")).lower() != "add":
            continue
        name = str((ev.get("label") or {}).get("name", "")).lower()
        if not name:
            continue
        tail = name.split("::")[-1].strip()
        if any(x == name or x == tail or x in name for x in w):
            ts = parse_ts(ev.get("created_at"))
            if ts:
                stamps.append(ts)
    return min(stamps) if stamps else None


def last_closed(events: List[dict]) -> Optional[datetime]:
    """The LAST time the issue was closed, from its state history.

    An issue reopened and closed again should be measured to the final
    closure, not the first -- the work genuinely continued past it.
    """
    stamps = []
    for ev in events or []:
        if str(ev.get("state", "")).lower() == "closed":
            ts = parse_ts(ev.get("created_at"))
            if ts:
                stamps.append(ts)
    return max(stamps) if stamps else None


def first_iteration_assigned(events: List[dict]) -> Optional[datetime]:
    """Earliest moment an iteration was ADDED to the issue."""
    stamps = []
    for ev in events or []:
        if str(ev.get("action", "")).lower() not in ("add", "added"):
            continue
        ts = parse_ts(ev.get("created_at"))
        if ts:
            stamps.append(ts)
    return min(stamps) if stamps else None


def _iteration_name(it: dict, lookup: Dict[int, dict]):
    """The name a board would show for this iteration, plus its dates.

    Priority: the iteration's own title, then its CADENCE name (which is what
    is normally displayed, since iteration titles are usually null), then a
    date range, and only as a last resort the bare id.
    """
    if not it:
        return "", "", ""
    ref = lookup.get(it.get("id")) or {}
    title = str(it.get("title") or ref.get("title") or "").strip()
    cadence = str(ref.get("cadence") or (it.get("iteration_cadence") or {}).get("title")
                  or "").strip()
    start = str(it.get("start_date") or ref.get("start") or "")
    due = str(it.get("due_date") or ref.get("due") or "")

    if title and cadence and title.lower() != cadence.lower():
        name = "%s - %s" % (cadence, title)
    else:
        name = title or cadence
    if not name:
        name = ("%s to %s" % (start, due)) if (start and due) else ("Iteration %s" % it.get("id"))
    return name, start, due


_GPN_RE = re.compile(r"(?<![0-9])(\d{4,12})(?![0-9])")


def split_author(raw_name: str):
    """Splits 'Lastname Firstname 43704137' into (display name, GPN).

    GitLab carries the GPN inside the display name, but pod membership is
    keyed on the GPN alone -- so it has to be lifted out before an MR can be
    attributed to a pod.

    The LAST standalone run of 4-12 digits is taken. Real GPNs are eight
    digits; the range is deliberately wider so an unusual one still matches,
    and taking the last occurrence means a name containing a number does not
    displace the identifier that follows it.
    """
    name = str(raw_name or "").strip()
    if not name:
        return "", ""
    found = _GPN_RE.findall(name)
    if not found:
        return name, ""
    gpn = found[-1]
    display = name.replace(gpn, "").strip(" -,\t")
    return (display or name), gpn


def _person(o, fallback="unknown") -> str:
    if not o:
        return fallback
    return str(o.get("name") or o.get("username") or fallback)


# ------------------------------------------------------------------ collect
def collect_issues(client, settings, months: List[str], progress=None) -> List[IssueRow]:
    """Every closed issue for ONE pod.

    The pod's issue links are GROUP paths, so each is expanded to every
    project beneath it. Scope is recorded per issue but nothing is dropped:
    Issue Throughput counts them all, and Cycle Time filters later.
    """
    from delivery_gitlab import folder_trail, parallel_map

    def say(msg):
        log.info(msg)
        if progress:
            progress(msg)

    workers = int(getattr(settings, "max_workers", 12))
    earliest = month_start(months[0]).isoformat()
    in_window = set(months)
    pod = getattr(settings, "pod", None)
    pod_name = pod.name if pod else ""

    try:
        iteration_lookup = client.group_iterations(pod.group_path if pod else "")
    except Exception as e:
        log.warning("Iteration lookup unavailable (%s).", e)
        iteration_lookup = {}

    issue_paths = list(pod.issue_projects) if pod else []
    say("Pod '%s': resolving %d issue group(s)..." % (pod_name, len(issue_paths)))
    projects = client.resolve_projects(issue_paths, "pod '%s' issues" % pod_name)
    say("  %d project(s); fetching closed issues with %d worker(s)..."
        % (len(projects), workers))

    def _issues_for(proj):
        try:
            return proj, client.closed_issues(proj["id"], earliest)
        except Exception as e:
            log.error("  issues failed for %s: %s", proj.get("path_with_namespace"), e)
            return proj, []

    pending = []
    for res in parallel_map(_issues_for, projects, workers, progress, "projects"):
        if not res:
            continue
        proj, issues = res
        for iss in issues:
            closed = parse_ts(iss.get("closed_at"))
            if closed and month_key(closed) in in_window:
                pending.append((proj, iss, closed))
    say("  %d closed issue(s) in window; fetching label history..." % len(pending))

    def _labels(item):
        proj, iss, _c = item
        try:
            return client.issue_label_events(proj["id"], iss.get("iid"))
        except Exception:
            return []

    label_sets = parallel_map(_labels, pending, workers, progress, "label history")

    starts, bases = [], []
    for ev in label_sets:
        ip = first_in_progress(ev or [], settings.in_progress_labels)
        starts.append(ip)
        bases.append(FROM_IN_PROGRESS if ip else "")

    need_iter = [i for i, b in enumerate(bases) if b != FROM_IN_PROGRESS]
    if need_iter:
        say("  %d issue(s) never reached in progress; checking iteration history..."
            % len(need_iter))

        def _iters(i):
            proj, iss, _c = pending[i]
            try:
                return client.issue_iteration_events(proj["id"], iss.get("iid"))
            except Exception:
                return []

        for i, ev in zip(need_iter, parallel_map(_iters, need_iter, workers, progress,
                                                 "iteration history")):
            it_start = first_iteration_assigned(ev or [])
            if it_start is not None:
                starts[i] = it_start
                bases[i] = FROM_ITERATION

    in_prog_idx = [i for i, b in enumerate(bases) if b == FROM_IN_PROGRESS]
    last_closed_at = {}
    if in_prog_idx:
        say("  %d issue(s) reached in progress; fetching state history..." % len(in_prog_idx))

        def _states(i):
            proj, iss, _c = pending[i]
            try:
                return client.issue_state_events(proj["id"], iss.get("iid"))
            except Exception:
                return []

        for i, ev in zip(in_prog_idx, parallel_map(_states, in_prog_idx, workers, progress,
                                                   "state history")):
            lc = last_closed(ev or [])
            if lc:
                last_closed_at[i] = lc

    rows: List[IssueRow] = []
    for k, ((proj, iss, closed), _lab) in enumerate(zip(pending, label_sets)):
        start, measured = starts[k], bases[k]
        if start is None:
            start = parse_ts(iss.get("created_at"))
            measured = FROM_CREATED if start else ""

        api_closed = closed
        in_scope, reason = False, ""
        if measured == FROM_IN_PROGRESS:
            lc = last_closed_at.get(k)
            closed = lc if (lc is not None and start is not None and lc >= start) else api_closed
            if closed is not None:
                in_scope = True
                if start is not None and closed < start:
                    reason = ("in-progress recorded after closure; counted for throughput, "
                              "but cycle time is not measurable")
            else:
                reason = "no closed date"
        elif measured == FROM_ITERATION:
            reason = "never moved to in progress (measured from iteration assignment)"
        elif measured == FROM_CREATED:
            reason = "never moved to in progress (measured from creation)"
        else:
            reason = "no usable start date"

        days = elapsed_days(start, closed) if start else None
        it = iss.get("iteration") or {}
        ep = iss.get("epic") or {}
        ppath = proj.get("path_with_namespace", "")
        it_name, it_start, it_due = _iteration_name(it, iteration_lookup)
        rows.append(IssueRow(
            project_path=ppath, folders=folder_trail(ppath, pod.group_path if pod else ""),
            iid=iss.get("iid"), title=str(iss.get("title", ""))[:300],
            author=_person(iss.get("author")), assignee=_person(iss.get("assignee"), "unassigned"),
            month=month_key(closed), measured_from=measured, start_at=start, closed_at=closed,
            cycle_days=days,
            flagged=bool(days is not None and days > settings.issue_sla_days),
            in_scope=in_scope, scope_reason=reason, pod_name=pod_name,
            iteration_name=it_name, iteration_start=it_start, iteration_end=it_due,
            epic_id=str(ep.get("id") or ""), epic_name=str(ep.get("title") or ""),
            web_url=str(iss.get("web_url", ""))))

    from collections import Counter as _C
    mix = _C(r.measured_from for r in rows)
    say("Pod '%s': %d closed issue(s) [in-progress %d | iteration %d | created %d]"
        % (pod_name, len(rows), mix.get(FROM_IN_PROGRESS, 0), mix.get(FROM_ITERATION, 0),
           mix.get(FROM_CREATED, 0)))
    return rows


def collect_merge_requests(client, settings, months: List[str], mr_group: str,
                           progress=None) -> List[MRRow]:
    """Every merged MR under ONE group, fetched ONCE for the whole crew.

    Pods are not fetched separately: the same repository serves several pods,
    so per-pod fetching would pull the same merge requests repeatedly and
    then have to de-duplicate them. Attribution to pods happens afterwards,
    by author GPN.
    """
    from delivery_gitlab import folder_trail, parallel_map

    def say(msg):
        log.info(msg)
        if progress:
            progress(msg)

    workers = int(getattr(settings, "max_workers", 12))
    earliest = month_start(months[0]).isoformat()
    in_window = set(months)

    say("Resolving MR group '%s'..." % mr_group)
    projects = client.resolve_projects([mr_group], "crew merge requests")
    say("  %d project(s); fetching merged MRs with %d worker(s)..." % (len(projects), workers))

    def _mrs_for(proj):
        try:
            return proj, client.merge_requests_all(proj["id"], earliest)
        except Exception as e:
            log.error("  merge requests failed for %s: %s", proj.get("path_with_namespace"), e)
            return proj, []

    pending = []
    for res in parallel_map(_mrs_for, projects, workers, progress, "projects"):
        if not res:
            continue
        proj, mrs = res
        for mr in mrs:
            if str(mr.get("state", "")).lower() != "merged":
                continue
            merged = parse_ts(mr.get("merged_at"))
            if merged and month_key(merged) in in_window:
                pending.append((proj, mr, merged))
    say("  %d merged MR(s) in window; fetching commit history..." % len(pending))

    def _commits(item):
        proj, mr, _m = item
        try:
            return client.mr_commits(proj["id"], mr.get("iid"))
        except Exception:
            return []

    commit_sets = parallel_map(_commits, pending, workers, progress, "commit history")

    def _approval(item):
        proj, mr, _m = item
        try:
            return client.mr_first_approved_at(proj["id"], mr.get("iid"))
        except Exception:
            return None

    approvals = parallel_map(_approval, pending, workers, progress, "approvals")

    rows: List[MRRow] = []
    for (proj, mr, merged), commits, approved in zip(pending, commit_sets, approvals):
        stamps = [t for t in (parse_ts(c.get("committed_date") or c.get("created_at"))
                              for c in (commits or [])) if t]
        first = min(stamps) if stamps else None
        hours = elapsed_hours(first, merged) if first else None

        # Every merged MR counts towards Merged MR per Author. Only LEAD TIME
        # excludes the year-plus ones, so the two measures answer different
        # questions from the same population.
        if hours is None:
            in_scope, reason = False, "no commit history, so lead time cannot be measured"
        elif hours > ONE_YEAR_HOURS:
            in_scope, reason = False, "lead time over one year"
        else:
            in_scope, reason = True, ""

        raw_author = _person(mr.get("author"))
        display, gpn = split_author(raw_author)
        ppath = proj.get("path_with_namespace", "")
        rows.append(MRRow(
            project_path=ppath, folders=folder_trail(ppath, mr_group),
            iid=mr.get("iid"), title=str(mr.get("title", ""))[:300],
            author=raw_author, month=month_key(merged),
            first_commit_at=first, merged_at=merged, lead_hours=hours,
            flagged=bool(hours is not None and hours > settings.mr_sla_hours),
            web_url=str(mr.get("web_url", "")), mr_id=str(mr.get("id") or ""),
            target_project_id=str(mr.get("target_project_id") or proj.get("id") or ""),
            source_branch=str(mr.get("source_branch") or ""),
            target_branch=str(mr.get("target_branch") or ""),
            created_at=parse_ts(mr.get("created_at")), first_approved_at=approved,
            author_gpn=gpn, author_display=display,
            author_email=str((mr.get("author") or {}).get("public_email")
                             or (mr.get("author") or {}).get("email") or ""),
            in_scope=in_scope, scope_reason=reason))

    known = sum(1 for r in rows if r.author_gpn)
    say("Collected %d merged MR(s) crew-wide -- %d with a GPN, %d within one year."
        % (len(rows), known, sum(1 for r in rows if r.in_scope)))
    if rows and known < len(rows):
        log.warning("%d merge request(s) have no GPN in the author name and cannot be "
                    "attributed to a pod.", len(rows) - known)
    return rows


def attribute_mrs(mrs: List[MRRow], members, crew: str, pod: Optional[str] = None
                  ) -> List[MRRow]:
    """The merge requests belonging to a pod, or to a whole crew.

    Matching is on author GPN against pod membership. A person in two pods
    has their MRs counted in BOTH pods -- that is what the pod view is for.
    At crew level each MR appears ONCE however many of its author's pods sit
    in that crew, so the crew is not inflated by shared membership.
    """
    if pod:
        gpns = {m.gpn for m in members if m.crew == crew and m.pod == pod}
    else:
        gpns = {m.gpn for m in members if m.crew == crew}
    if not gpns:
        return []
    seen, out = set(), []
    for r in mrs:
        if r.author_gpn and r.author_gpn in gpns and r.mr_id not in seen:
            seen.add(r.mr_id)          # de-duplicates the crew view
            out.append(r)
    return out


# ------------------------------------------------------------------ windows
@dataclass
class WindowStats:
    """The four parameters for ONE 3-month window, computed from the raw rows
    of that window rather than by averaging monthly figures.

    Pooling matters: the slowest-15% trim and the MRs-per-author ratio are
    both defined over the window's whole population, and neither survives
    being computed monthly and then averaged.
    """
    label: str
    months: List[str] = field(default_factory=list)
    # issues
    closed_total: int = 0            # every closed issue, in scope or not
    throughput: Optional[float] = None    # closed_total / pod_count
    in_progress_count: int = 0       # reached in progress -> eligible for cycle time
    trimmed_count: int = 0           # dropped as the slowest 15%
    cycle_time: Optional[float] = None
    # merge requests
    mr_count: int = 0                # every merged MR attributed here
    author_count: int = 0            # distinct authors among them
    mr_per_author: Optional[float] = None
    lead_measured: int = 0           # those with a lead time under one year
    lead_excluded: int = 0           # dropped as over a year or unmeasurable
    lead_time: Optional[float] = None
    pod_count: int = 1

    def value(self, k):
        return getattr(self, k)


def window_stats(label: str, wmonths: List[str], issues: List[IssueRow], mrs: List[MRRow],
                 pod_count: int, trim_pct: float) -> WindowStats:
    """One window's figures, from the rows that fall inside it."""
    ws = WindowStats(label=label, months=list(wmonths), pod_count=max(1, pod_count))
    mset = set(wmonths)

    # ---- Issue Throughput: EVERY closed issue, scope irrelevant ----
    win_issues = [i for i in issues if i.month in mset]
    ws.closed_total = len(win_issues)
    ws.throughput = round(ws.closed_total / float(ws.pod_count), 2)

    # ---- Cycle Time: only issues that reached in progress, slowest trimmed ----
    eligible = [i for i in win_issues
                if i.measured_from == FROM_IN_PROGRESS and i.cycle_days is not None]
    ws.in_progress_count = len(eligible)
    if eligible:
        eligible.sort(key=lambda i: i.cycle_days)
        n_drop = int(len(eligible) * float(trim_pct) / 100.0)
        kept = eligible[:len(eligible) - n_drop] if n_drop else eligible
        ws.trimmed_count = len(eligible) - len(kept)
        if kept:
            ws.cycle_time = round(sum(i.cycle_days for i in kept) / len(kept), 2)

    # ---- Merged MR per Author: ALL merged MRs, including the year-plus ones ----
    win_mrs = [r for r in mrs if r.month in mset]
    ws.mr_count = len(win_mrs)
    authors = {r.author_gpn or r.author for r in win_mrs}
    ws.author_count = len(authors)
    if authors:
        ws.mr_per_author = round(ws.mr_count / float(ws.author_count), 2)

    # ---- Lead Time: the year-plus ones excluded ----
    lead = [r.lead_hours for r in win_mrs
            if r.lead_hours is not None and r.lead_hours <= ONE_YEAR_HOURS]
    ws.lead_measured = len(lead)
    ws.lead_excluded = len(win_mrs) - len(lead)
    if lead:
        ws.lead_time = round(sum(lead) / len(lead), 2)
    return ws


def build_windows(issues: List[IssueRow], mrs: List[MRRow], months: List[str],
                  pod_count: int, trim_pct: float, window: int = 3,
                  current_month: Optional[str] = None):
    """Every 3-month window, oldest first. The current month is excluded --
    it is incomplete, so any window containing it would read low."""
    usable = [m for m in months if not current_month or m < current_month]
    if len(usable) < window:
        usable = list(months)
    labels, spans = window_slices(usable, window)
    out = []
    for lab, (a, b) in zip(labels, spans):
        out.append(window_stats(lab, usable[a:b], issues, mrs, pod_count, trim_pct))
    return out


# ------------------------------------------------------------------ summarise
@dataclass
class Series:
    """Everything the chart draws, built directly from the window list."""
    window_labels: List[str] = field(default_factory=list)
    windows: List = field(default_factory=list)
    baseline_label: str = ""
    baseline_index: Optional[int] = None
    baseline_months: List[str] = field(default_factory=list)
    actual: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    actual_prev: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    actual_curr: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    aspiration: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    baseline: Dict[str, Optional[float]] = field(default_factory=dict)
    shift_pct: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    progress_pct: Dict[str, Optional[float]] = field(default_factory=dict)
    gain_actual: List[Optional[float]] = field(default_factory=list)
    gain_prev: List[Optional[float]] = field(default_factory=list)
    gain_curr: List[Optional[float]] = field(default_factory=list)
    gain_asp: List[Optional[float]] = field(default_factory=list)
    overall_gain: Optional[float] = None


def _split(vals, bi):
    """One series in two segments. The anchor sits in BOTH so they join."""
    if bi is None:
        return list(vals), [None] * len(vals)
    return ([v if i <= bi else None for i, v in enumerate(vals)],
            [v if i >= bi else None for i, v in enumerate(vals)])


def _mean(vals):
    v = [x for x in vals if x is not None]
    return round(sum(v) / len(v), 2) if v else None


def window_slices(months: Sequence[str], window: int = 3):
    """Consecutive spans stepping one month at a time:
    Nov 24-Jan 25, Dec 24-Feb 25, Jan 25-Mar 25, ..."""
    labels, spans = [], []
    for i in range(len(months) - window + 1):
        labels.append("%s-%s" % (month_label(months[i]), month_label(months[i + window - 1])))
        spans.append((i, i + window))
    return labels, spans


def gain(metric: str, value: Optional[float], base: Optional[float]) -> Optional[float]:
    """Percentage improvement against the baseline, sign-corrected so that a
    positive number always means better."""
    if value is None or base in (None, 0):
        return None
    raw = (value - base) / abs(base) * 100.0
    return round(-raw if LOWER_IS_BETTER[metric] else raw, 2)


def ramp_at(offset: Optional[int], target_pct: float, target_months: int) -> Optional[float]:
    """Aspiration ramp: 0% at the anchor, linear to the target, then flat.
    None before the anchor -- the ambition starts at the reference point."""
    if offset is None or offset < 0 or target_months <= 0:
        return None
    return round(min(offset / float(target_months), 1.0) * target_pct, 2)


def build_series(windows: List[WindowStats], settings) -> Series:
    """The chart series, straight from the windows.

    The baseline is the window STARTING at baseline_month -- Nov 25-Jan 26 by
    default. Because the aspiration is anchored on that window's own actual,
    the two meet there exactly.
    """
    ser = Series(windows=list(windows),
                 window_labels=[w.label for w in windows])
    if not windows:
        return ser

    bm = settings.baseline_month
    bi = next((i for i, w in enumerate(windows) if w.months and w.months[0] == bm), None)
    ser.baseline_index = bi
    if bi is not None:
        ser.baseline_label = windows[bi].label
        ser.baseline_months = list(windows[bi].months)

    for k in METRIC_KEYS:
        vals = [w.value(k) for w in windows]
        vals = [float(v) if v is not None else None for v in vals]
        ser.actual[k] = vals
        base = vals[bi] if bi is not None else None
        ser.baseline[k] = base
        ser.actual_prev[k], ser.actual_curr[k] = _split(vals, bi)
        ser.shift_pct[k] = [gain(k, v, base) for v in vals]

        lower = LOWER_IS_BETTER[k]
        asp = []
        for j in range(len(windows)):
            step = ramp_at(None if bi is None else j - bi,
                           settings.target_gain_pct, settings.target_months)
            if base is None or step is None:
                asp.append(None)
            else:
                f = (1 - step / 100.0) if lower else (1 + step / 100.0)
                asp.append(round(base * f, 2))
        ser.aspiration[k] = asp

        latest = next((v for v in reversed(vals) if v is not None), None)
        ser.progress_pct[k] = gain(k, latest, base)

    for j in range(len(windows)):
        ser.gain_actual.append(_mean([ser.shift_pct[k][j] for k in METRIC_KEYS]))
        ser.gain_asp.append(ramp_at(None if bi is None else j - bi,
                                    settings.target_gain_pct, settings.target_months))
    ser.gain_prev, ser.gain_curr = _split(ser.gain_actual, bi)
    # Overall = the mean of the four panel headlines, so the arithmetic a
    # reader can do by eye from the four titles always holds.
    ser.overall_gain = _mean([ser.progress_pct[k] for k in METRIC_KEYS])

    log.info("Series: %d window(s), baseline %s (%s), overall gain %s%%",
             len(windows), ser.baseline_label or "n/a",
             ", ".join(ser.baseline_months) or "n/a", ser.overall_gain)
    return ser
