# New pod: DS Data — configuration files

Adds **DS Data** under the existing crew *STAAT Data Science*, alongside Insights and Conv. Insights.

| | |
|---|---|
| **Pod name** | DS Data |
| **Key** | `ds_data` |
| **Issue URL** | `ubs/gwma/…/staat-data-science/staat-ds-data/ds-data/staat-ds-data-engineering` |
| **MR URL** | `ubs/gwma/…/staat-ds-genesis/genesis-platform/ds-data-dags` (label `ds-data-dags`) |
| **Group** | `ubs/gwma/…/staat-data-science/staat-ds-data/ds-data` |

## Where to copy these

```
project5/pods.json          ->  your gitlab_productivity/  folder   (replaces existing)
project6/pods.json          ->  your productivity_dashboard/ folder (replaces existing)
project6/org_config.json    ->  your productivity_dashboard/ folder (replaces existing)
```

Both projects keep their **own copy** of `pods.json` — they are identical in content, but each
project reads the one sitting beside its scripts, so both must be replaced.

Project 6 additionally needs `org_config.json`, which is what places the pod in the org tree. Project
5 has no org hierarchy and needs only `pods.json`.

## What changes after you drop these in

No code changes, no redeploy of the modules.

| Project | Before | After |
|---|---|---|
| **5** — reports | 8 files (2 pods × 4) | **12 files** (3 pods × 4) |
| **6** — dashboard | 4 figures (2 pods × 2) | **6 figures** (3 pods × 2) |

Project 6's **Pod** filter will now list `Insights, Conv. Insights, DS Data`, and selecting the crew
*STAAT Data Science* resolves to all three.

## Confirming it worked

**Project 5** — the first log line of the metrics DAG's Task 1:

```
Collecting issues for 3 configured pod(s): Insights, Conv. Insights, DS Data
```

**Project 6** — the *Check the org configuration* cell in the notebook:

```
pod          : Insights, Conv. Insights, DS Data
missing pod keys: none
```

`missing pod keys` must be empty. Anything listed there is a key in `org_config.json` with no
matching entry in `pods.json`.

## Note on the single MR repository

DS Data has **one** MR repo, against 3 for Insights and 7 for Conv. Insights. That is fine — nothing
assumes a minimum. Its per-repository table will simply have one column. Add more later by extending
`mr_repos` in `pods.json`; both a labelled map and a bare list are accepted.
