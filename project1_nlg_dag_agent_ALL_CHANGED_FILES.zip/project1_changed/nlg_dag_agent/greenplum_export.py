"""
Exports the combined `nlg_hierarchy` row-set (see report_rows.combined_rows)
to a Greenplum table -- dropping and recreating it every run, then applying
the standing GRANT/ALTER statements for this schema.

Connection resolution, in order:
  1. Inside Airflow: `PostgresHook(postgres_conn_id=settings.postgres_conn_id_var)`,
     schema name from the Airflow Variable named `settings.greenplum_schema_var`
     (falls back to `settings.greenplum_schema` if that Variable isn't set).
  2. Local/notebook: a direct psycopg2 connection using
     settings.greenplum_host/port/db/user/schema, with the password read
     from GREENPLUM_PASSWORD or prompted interactively (never hard-coded).

Usage:
    from nlg_dag_agent import build_hierarchy, Settings
    from nlg_dag_agent.greenplum_export import export_to_greenplum

    settings = Settings()
    settings.resolve_secrets(interactive=True)
    settings.resolve_greenplum_password(interactive=True)
    hierarchy = build_hierarchy(settings)
    export_to_greenplum(hierarchy, settings)
"""
from __future__ import annotations

from typing import List, Optional, Tuple

from .config import Settings
from .pipeline import Hierarchy
from .report_rows import combined_rows, COMBINED_COLUMNS

# All COMBINED_COLUMNS are free-form text in practice (paths, names, notes,
# semi-colon-joined lists) -- a single TEXT type per column keeps the DDL
# simple and avoids truncation surprises on long call-chain/notes values.
_DDL_COLUMNS = ", ".join(f'"{c}" TEXT' for c in COMBINED_COLUMNS)

_GRANT_TEMPLATE = """
GRANT SELECT ON {schema}.{table} TO {select_grantee};
GRANT TRUNCATE ON {schema}.{table} TO {truncate_grantee};
ALTER TABLE {schema}.{table} OWNER TO {new_owner};
"""


def _get_connection(settings: Settings) -> Tuple[object, str, str]:
    """Returns (dbapi_connection, schema, mode) where mode is 'airflow' or 'local'."""
    try:
        from airflow.hooks.postgres_hook import PostgresHook
        from airflow.models import Variable
        hook = PostgresHook(postgres_conn_id=settings.postgres_conn_id_var)
        conn = hook.get_conn()
        schema = Variable.get(settings.greenplum_schema_var, default_var=settings.greenplum_schema)
        return conn, schema, "airflow"
    except Exception:
        pass

    import psycopg2
    if not settings.greenplum_password:
        settings.resolve_greenplum_password(interactive=True)
    conn = psycopg2.connect(
        host=settings.greenplum_host, port=settings.greenplum_port,
        dbname=settings.greenplum_db, user=settings.greenplum_user,
        password=settings.greenplum_password,
    )
    return conn, settings.greenplum_schema, "local"


def _quoted_ident(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def build_ddl(schema: str, table: str) -> List[str]:
    """Returns the list of DDL/DML statements this export runs, in order --
    exposed separately so it can be unit-tested/inspected without a live
    database connection."""
    fq = f"{_quoted_ident(schema)}.{_quoted_ident(table)}"
    return [
        f"DROP TABLE IF EXISTS {fq};",
        f"CREATE TABLE {fq} ({_DDL_COLUMNS});",
    ]


def build_grant_statements(schema: str, table: str, settings: Settings) -> str:
    fq_schema, fq_table = _quoted_ident(schema), _quoted_ident(table)
    return _GRANT_TEMPLATE.format(
        schema=fq_schema, table=fq_table,
        select_grantee=settings.greenplum_grant_select_to,
        truncate_grantee=settings.greenplum_grant_truncate_to,
        new_owner=settings.greenplum_new_owner,
    )


def export_to_greenplum(hierarchy: Hierarchy, settings: Optional[Settings] = None,
                          batch_size: int = 5000) -> dict:
    """Drops/recreates {schema}.{table} (defaults to core_nlg.nlg_hierarchy
    style config, see Settings), inserts the combined hierarchy+product+yaml
    row-set, and applies the standing GRANT/ALTER statements. Returns a
    small summary dict."""
    settings = settings or hierarchy.settings
    rows = combined_rows(hierarchy)

    conn, schema, mode = _get_connection(settings)
    table = settings.nlg_hierarchy_table
    try:
        cur = conn.cursor()
        for stmt in build_ddl(schema, table):
            cur.execute(stmt)

        fq = f"{_quoted_ident(schema)}.{_quoted_ident(table)}"
        col_list = ", ".join(_quoted_ident(c) for c in COMBINED_COLUMNS)
        placeholders = ", ".join(["%s"] * len(COMBINED_COLUMNS))
        insert_sql = f"INSERT INTO {fq} ({col_list}) VALUES ({placeholders})"

        values = [[r.get(c, "") for c in COMBINED_COLUMNS] for r in rows]
        for i in range(0, len(values), batch_size):
            batch = values[i:i + batch_size]
            try:
                cur.executemany(insert_sql, batch)
            except AttributeError:
                for row in batch:
                    cur.execute(insert_sql, row)

        for stmt in build_grant_statements(schema, table, settings).strip().split(";"):
            stmt = stmt.strip()
            if stmt:
                cur.execute(stmt + ";")

        conn.commit()
    finally:
        try:
            conn.close()
        except Exception:
            pass

    return {"schema": schema, "table": table, "rows_written": len(rows), "connection_mode": mode}
