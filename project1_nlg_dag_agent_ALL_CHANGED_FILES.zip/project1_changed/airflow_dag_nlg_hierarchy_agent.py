"""
airflow_dag_nlg_hierarchy_agent.py
-----------------------------------
Deploy this file into your Airflow `dags/` folder (next to `nlg_master.py`)
to run the exact same hierarchy-extraction/impact-analysis agent as an
Airflow DAG -- no interactive prompts, no notebook required.

Secrets are pulled from Airflow Variables (never hard-coded):
  - GENESIS_DDLC_IKG_GIT_SECRET  -> GitLab token AND LLM key (per the
    original config, both default to this same Variable name; override
    with GITLAB_TOKEN_VAR / LLM_AIRFLOW_SECRET_VAR env vars if they differ).
  - Greenplum: uses the Airflow Connection named by POSTGRES_CONN_ID_VAR
    (default "IKG_POSTGRES_CONN_ID") for host/port/db/user/password, and
    the Airflow Variable named by GREENPLUM_SCHEMA_VAR (default
    "NLG_SCHEMA") for the target schema. Writes to {schema}.nlg_hierarchy,
    dropping and recreating the table each run. Set the Airflow Variable
    NLG_AGENT_WRITE_TO_GREENPLUM=false to skip this step.

Trigger it two ways:
  1. On its own schedule (e.g. nightly) to keep `nlg_hierarchy.json` fresh.
  2. On-demand with `dag_run.conf` for ad-hoc impact analysis, e.g.:
        {"changed_file": "nlg_main_class.py"}
        {"target_type": "client_windfall"}
        {"question": "What breaks if I change generate_rule_narratives?"}

The `nlg_dag_agent` package must be importable from this DAG file -- either
drop the `nlg_dag_agent/` folder next to this file in your dags repo, or
install it as a package available on the Airflow workers.
"""
from __future__ import annotations

import json
import os
from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.models import Variable

# `nlg_dag_agent` ships alongside this file (see README) -- add its parent
# directory to sys.path if it isn't already importable as a package.
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from nlg_dag_agent.config import Settings
from nlg_dag_agent.pipeline import build_hierarchy, run_impact_analysis, ask
from nlg_dag_agent.xlsx_export import export_xlsx
from nlg_dag_agent.greenplum_export import export_to_greenplum


OUTPUT_PATH = Variable.get("NLG_AGENT_OUTPUT_PATH", default_var="/opt/airflow/data/cid/nlg/agent/nlg_hierarchy.json")
OUTPUT_XLSX_PATH = Variable.get("NLG_AGENT_OUTPUT_XLSX_PATH",
                                 default_var="/opt/airflow/data/cid/nlg/agent/nlg_hierarchy.xlsx")
WRITE_TO_GREENPLUM = Variable.get("NLG_AGENT_WRITE_TO_GREENPLUM", default_var="true").lower() == "true"


def _build_settings() -> Settings:
    s = Settings()
    # Point at the GitLab copy of nlg-dags (dags/nlg/dags + dags/nlg/src) --
    # already the default in Settings, override via env vars if needed.
    s.resolve_secrets(interactive=False)   # Airflow Variable -> raise if missing
    return s


def task_build_hierarchy(**kwargs):
    settings = _build_settings()
    hierarchy = build_hierarchy(settings)
    hierarchy.save_json(OUTPUT_PATH)
    export_xlsx(hierarchy, OUTPUT_XLSX_PATH)
    ti = kwargs["ti"]
    ti.xcom_push(key="dag_count", value=len(hierarchy.dags))
    ti.xcom_push(key="output_path", value=OUTPUT_PATH)
    ti.xcom_push(key="output_xlsx_path", value=OUTPUT_XLSX_PATH)
    print(f"Extracted {len(hierarchy.dags)} DAGs -> {OUTPUT_PATH} and {OUTPUT_XLSX_PATH}")

    if WRITE_TO_GREENPLUM:
        # settings.postgres_conn_id_var (Airflow Connection id) and
        # settings.greenplum_schema_var (Airflow Variable name for the
        # schema) drive this -- no password needed here, PostgresHook
        # reads it from the Connection.
        result = export_to_greenplum(hierarchy, settings)
        ti.xcom_push(key="greenplum_rows_written", value=result["rows_written"])
        print(f"Greenplum: wrote {result['rows_written']} rows to "
              f"{result['schema']}.{result['table']} (connection: {result['connection_mode']})")


def task_impact_analysis(**kwargs):
    conf = (kwargs.get("dag_run").conf if kwargs.get("dag_run") else {}) or {}
    changed_file = conf.get("changed_file")
    target_type = conf.get("target_type")
    function_name = conf.get("function")
    question = conf.get("question")

    if not any([changed_file, target_type, function_name, question]):
        print("No dag_run.conf provided (changed_file / target_type / function / question) -- skipping.")
        return

    settings = _build_settings()
    hierarchy = build_hierarchy(settings)

    if question:
        answer = ask(hierarchy, question)
        print("Q:", question)
        print("A:", answer)
    else:
        result = run_impact_analysis(hierarchy, changed_file=changed_file,
                                       target_type=target_type, function_name=function_name)
        print(json.dumps(result, indent=2, default=str))


default_args = {
    "owner": "NLG",
    "retry_delay": timedelta(minutes=2),
    "retries": 1,
    "email_on_failure": True,
}

with DAG(
    dag_id="nlg_hierarchy_agent",
    default_args=default_args,
    description="Static+LLM agent that maps DAG -> sub-DAG -> task -> method -> file "
                "for the NLG pipeline, and answers impact-analysis questions.",
    start_date=datetime(2024, 1, 1),
    schedule_interval=Variable.get("NLG_AGENT_SCHEDULE", default_var=None),
    catchup=False,
    tags=["NLG", "agent", "impact-analysis"],
) as dag:

    build_hierarchy_task = PythonOperator(
        task_id="build_hierarchy",
        python_callable=task_build_hierarchy,
    )

    impact_analysis_task = PythonOperator(
        task_id="impact_analysis_on_demand",
        python_callable=task_impact_analysis,
    )

    build_hierarchy_task >> impact_analysis_task
