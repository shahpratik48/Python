"""
Gathers everything needed to reconstruct the SQL query built for one
(target_type, insight_type) pair: the resolved config values, and the
source of the functions that actually build the query.

Grounded in the real code path found in nlg-src/src/utils/utils_main.py
(`run_nlg_of_insight_type`) and nlg-src/src/utils/utils_narratives.py
(`fetch_data_with_insights` and its `_for_cl` / `_for_fl` / `_for_pr`
variants):

    nlg_db_tables            <- config/input_data_config/<target_type>.yml
    col_name_mapping         <- nlg_db_tables['sql_column_mapping'],
                                 updated by sql_column_mapping/<tt>/<it>.(yml|json) if present
    ref_table_columns_to_retrieve <- ref_table_columns/<tt>/<it>.yml (optional)
    fields_not_null          <- group_logic/<tt>/<it>.yml['fields_not_null'] (optional)
    insights_target_user_type <- nlg_db_tables['insights_target_user_type']  (picks the fetch_* variant)
"""
from __future__ import annotations

import configparser
import json
import posixpath
from dataclasses import dataclass, field
from typing import Dict, List, Optional

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None

from nlg_dag_agent.pipeline import Hierarchy

# Functions in nlg-src that actually build the fetch-data SQL. Extend this
# list if your codebase adds more variants -- the tracer sends whichever of
# these are relevant to the resolved `insights_target_user_type`.
DISPATCHER_FUNCTION = "fetch_data_with_insights"
VARIANT_BY_USER_TYPE = {
    "fa": "fetch_data_with_insights_for_cl",
    "fa_ma": "fetch_data_with_insights_for_cl",
    "fl": "fetch_data_with_insights_for_fl",
}
PROSPECT_VARIANT = "fetch_data_with_insights_for_pr"
HELPER_FUNCTIONS = ["generate_sql_for_ref_tbl", "inject_input_data_for_dummy_households"]

# The real schema/table settings (what the code calls `nlg_db_tables` /
# `si_nlg_settings`) live in one shared, environment-sectioned INI file --
# NOT in config/input_data_config/<target_type>.yml (that file only
# supplies the column mapping / join column / target_key_conversion /
# insights_target_user_type). Confirmed against the real nlg-src content:
# config/nlg_db_tables.ini has sections like [dev_active], [prod_active], ...
# each a flat key=value block including e.g. `input_tbl_<target_type> = ...`.
NLG_DB_TABLES_INI_PATH = "config/nlg_db_tables.ini"
DEFAULT_ODM_ENV = "prod_active"


@dataclass
class QueryContext:
    target_type: str
    insight_type: str
    odm_env: str = DEFAULT_ODM_ENV
    nlg_db_tables: dict = field(default_factory=dict)          # from config/nlg_db_tables.ini[odm_env]
    input_data_config: dict = field(default_factory=dict)      # from config/input_data_config/<target_type>.yml
    col_name_mapping: dict = field(default_factory=dict)
    ref_table_columns_to_retrieve: dict = field(default_factory=dict)
    fields_not_null: Optional[list] = None
    insights_target_user_type: str = "fa"
    is_prospect_run: bool = False
    variant_function: Optional[str] = None
    source_files: Dict[str, str] = field(default_factory=dict)   # path -> content, everything sent to the LLM
    warnings: List[str] = field(default_factory=list)


def _find_file(src_index, folder: str, target_type: str, insight_type: str) -> Optional[str]:
    """Mirrors utils_common.load_yaml_files_by_name_and_env: looks for
    <folder>/<target_type>/<insight_type>.yml (or .json) among the indexed
    files."""
    candidates = [
        f"{folder}/{target_type}/{insight_type}.yml",
        f"{folder}/{target_type}/{insight_type}.yaml",
        f"{folder}/{target_type}/{insight_type}.json",
    ]
    for c in candidates:
        if c in src_index.raw_files:
            return c
    return None


def _load_yaml(src_index, path: str) -> dict:
    if yaml is None:
        return {}
    try:
        data = yaml.safe_load(src_index.raw_files[path])
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _load_json(src_index, path: str) -> dict:
    try:
        data = json.loads(src_index.raw_files[path])
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _load_nlg_db_tables(src_index, odm_env: str, warnings: List[str]) -> dict:
    if NLG_DB_TABLES_INI_PATH not in src_index.raw_files:
        warnings.append(f"{NLG_DB_TABLES_INI_PATH} not found -- cannot resolve schema/table names.")
        return {}
    parser = configparser.ConfigParser()
    try:
        parser.read_string(src_index.raw_files[NLG_DB_TABLES_INI_PATH])
    except Exception as e:
        warnings.append(f"Failed to parse {NLG_DB_TABLES_INI_PATH}: {e}")
        return {}
    if odm_env not in parser:
        warnings.append(f"Section [{odm_env}] not found in {NLG_DB_TABLES_INI_PATH} -- "
                         f"available sections: {parser.sections()}")
        return {}
    return dict(parser[odm_env])


def gather_context(hierarchy: Hierarchy, target_type: str, insight_type: str,
                    is_prospect_run: bool = False, odm_env: str = DEFAULT_ODM_ENV) -> QueryContext:
    src_index = hierarchy.src_index
    ctx = QueryContext(target_type=target_type, insight_type=insight_type,
                        is_prospect_run=is_prospect_run, odm_env=odm_env)

    # 1) config/nlg_db_tables.ini[odm_env] -- the REAL source of table/schema
    #    names (what the code calls `nlg_db_tables` / `si_nlg_settings`).
    ctx.nlg_db_tables = _load_nlg_db_tables(src_index, odm_env, ctx.warnings)
    if NLG_DB_TABLES_INI_PATH in src_index.raw_files:
        ctx.source_files[NLG_DB_TABLES_INI_PATH] = (
            f"[{odm_env}]\n" + "\n".join(f"{k} = {v}" for k, v in ctx.nlg_db_tables.items()))  # trimmed to the relevant section only

    # 2) config/input_data_config/<target_type>.yml -- column mapping, join
    #    column, target_key_conversion, and which fetch_* variant to use.
    idc_path = None
    for cand in (f"config/input_data_config/{target_type}.yml", f"config/input_data_config_dummy/{target_type}.yml"):
        if cand in src_index.raw_files:
            idc_path = cand
            break
    if idc_path:
        data = _load_yaml(src_index, idc_path)
        ctx.input_data_config = data.get(target_type, data)
        ctx.source_files[idc_path] = src_index.raw_files[idc_path]
    else:
        ctx.warnings.append(f"No config/input_data_config/{target_type}.yml found -- "
                             f"cannot resolve insights_target_user_type/join column/base column mapping.")

    ctx.insights_target_user_type = ctx.input_data_config.get("insights_target_user_type", "fa")
    ctx.col_name_mapping = dict(ctx.input_data_config.get("sql_column_mapping", {}))

    # 2) sql_column_mapping/<tt>/<it>.(yml|json) -- overrides/extends the base mapping above
    scm_path = _find_file(src_index, "sql_column_mapping", target_type, insight_type)
    if scm_path:
        overrides = _load_json(src_index, scm_path) if scm_path.endswith(".json") else _load_yaml(src_index, scm_path)
        ctx.col_name_mapping.update(overrides)
        ctx.source_files[scm_path] = src_index.raw_files[scm_path]

    # 3) ref_table_columns/<tt>/<it>.yml
    rtc_path = _find_file(src_index, "ref_table_columns", target_type, insight_type)
    if rtc_path:
        ctx.ref_table_columns_to_retrieve = _load_yaml(src_index, rtc_path)
        ctx.source_files[rtc_path] = src_index.raw_files[rtc_path]

    # 4) group_logic/<tt>/<it>.yml -- only fields_not_null feeds the SQL
    gl_path = _find_file(src_index, "group_logic", target_type, insight_type)
    if gl_path:
        gl_data = _load_yaml(src_index, gl_path)
        ctx.fields_not_null = gl_data.get("fields_not_null")
        ctx.source_files[gl_path] = src_index.raw_files[gl_path]

    # 5) rules/<tt>/<it>.yml -- confirms the insight_type is real; not used
    #    in the SQL itself (used later for narrative text generation), but
    #    included for context.
    rules_path = _find_file(src_index, "rules", target_type, insight_type)
    if rules_path:
        ctx.source_files[rules_path] = src_index.raw_files[rules_path]
    else:
        ctx.warnings.append(f"No rules/{target_type}/{insight_type}.yml found -- "
                             f"insight_type may not actually be defined for this target_type.")

    # 6) pick + load the query-building function source
    if is_prospect_run and ctx.insights_target_user_type == "fa":
        ctx.variant_function = PROSPECT_VARIANT
    else:
        ctx.variant_function = VARIANT_BY_USER_TYPE.get(ctx.insights_target_user_type)

    for fname in [DISPATCHER_FUNCTION, ctx.variant_function] + HELPER_FUNCTIONS:
        if not fname:
            continue
        fi = src_index.functions.get(fname)
        if fi:
            ctx.source_files.setdefault(fi.file, src_index.raw_files[fi.file])
        else:
            ctx.warnings.append(f"Could not locate function `{fname}` in nlg-src.")

    if ctx.variant_function is None:
        ctx.warnings.append(f"Unrecognized insights_target_user_type "
                             f"'{ctx.insights_target_user_type}' -- cannot pick a fetch_data_with_insights_* variant.")

    return ctx


def list_all_target_types(hierarchy: Hierarchy) -> List[str]:
    """Every target_type that has at least one insight_type defined --
    i.e. every immediate child folder of rules/ in the indexed nlg-src,
    regardless of how deeply the actual .yml files are nested underneath
    (rules/<target_type>/<insight_type>.yml, or rules/<target_type>/
    <subfolder>/<insight_type>.yml, or deeper -- all supported, since only
    the folder immediately after `rules/` is used as the target_type)."""
    out = set()
    for path in hierarchy.src_index.raw_files:
        if not path.startswith("rules/"):
            continue
        parts = path.split("/")
        if len(parts) >= 3 and path.endswith((".yml", ".yaml")):
            out.add(parts[1])
    return sorted(out)


def list_insight_types_for_target_type(hierarchy: Hierarchy, target_type: str) -> List[str]:
    """Every insight_type defined for a target_type, from rules/<target_type>/*.yml file names
    (at any nesting depth underneath, e.g. rules/<target_type>/<subfolder>/<insight_type>.yml)."""
    prefix = f"rules/{target_type}/"
    out = []
    for path in hierarchy.src_index.raw_files:
        if path.startswith(prefix) and path.endswith((".yml", ".yaml")):
            name = posixpath.basename(path).rsplit(".", 1)[0]
            out.append(name)
    return sorted(set(out))
