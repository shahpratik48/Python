"""
airflow_dag_gitlab_metrics.py  --  DAG 1
-----------------------------------------
Issue throughput and merge request cycle time, for the current month plus
the previous three.

Three tasks, run in order:

    collect_issue_metrics -> collect_mr_metrics -> build_html_report
                                                 -> build_daily_report

Tasks 1 and 2 each push their results to XCom; the reporting tasks consume
them. Splitting collection from reporting means a GitLab outage during
Task 2 leaves Task 1's work visible in the logs and XCom rather than losing
the whole run.

The fourth task writes a second, single-day report: what breached its SLA
today, plus -- the actionable part -- work that is still open and will
breach today unless it is finished. That is why this DAG runs at 6pm: the
at-risk list is only useful while there is still a chance to act on it.

Schedule: 18:00 America/New_York, Monday to Friday.

Credentials come from the Airflow Variable GENESIS_DDLC_IKG_GIT_SECRET
(override with the GITLAB_TOKEN_VAR env var), exactly as in the other
projects. Deploy this file together with the gl_*.py modules in the SAME
folder.
"""
from __future__ import annotations

import os
import sys
from datetime import datetime, timedelta

import pendulum
from airflow import DAG
from airflow.models import Variable
from airflow.operators.python import PythonOperator

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from gl_client import GitLabClient
from gl_metrics import (collect_issue_metrics, collect_mr_metrics, metrics_to_payload,
                        month_window, payload_to_metrics)
from gl_daily import (at_risk_to_payload, collect_at_risk_issues, collect_at_risk_mrs,
                      day_bounds, issues_closed_on_day, mrs_merged_on_day)
from gl_report import build_daily_report, build_metrics_report, write_report
from gl_settings import ALL_PODS, GitLabSettings, get_logger, setup_logging
from gl_summary import build_pod_summary, build_shift_rows, months_with_baseline
from gl_xlsx import export_daily_xlsx, export_metrics_xlsx

HERE = os.path.dirname(os.path.abspath(__file__))
EST = pendulum.timezone("America/New_York")


def _var(key, default=None):
    try:
        return Variable.get(key, default_var=default)
    except Exception:
        return default


def _settings(pod=None) -> GitLabSettings:
    s = GitLabSettings(pod=pod) if pod is not None else GitLabSettings()
    s.output_dir = HERE
    s.baseline_month = _var("GL_BASELINE_MONTH", s.baseline_month)
    s.months_back = int(_var("GL_MONTHS_BACK", str(s.months_back)))
    s.issue_sla_business_days = float(_var("GL_ISSUE_SLA_DAYS", str(s.issue_sla_business_days)))
    s.mr_sla_hours = float(_var("GL_MR_SLA_HOURS", str(s.mr_sla_hours)))
    s.log_level = _var("GL_LOG_LEVEL", s.log_level)
    s.resolve_token(interactive=False)          # Airflow Variable, never prompts
    return s


def task_collect_issues(**kwargs):
    """Runs for every pod. Each pod has its own issue board, so they are
    collected and reported entirely separately."""
    log_path = setup_logging("INFO", log_dir=HERE)
    log = get_logger("dag1.task1")
    ti = kwargs["ti"]

    for pod in ALL_PODS:
        s = _settings(pod)
        log.info("--- Task 1 for pod '%s' (project %s) ---", pod.name, s.project_path)
        report_months, all_months, earliest = months_with_baseline(s.months_back, s.baseline_month)
        metrics, summaries = collect_issue_metrics(GitLabClient(s), s, all_months, earliest)
        ti.xcom_push(key="issue_payload_%s" % pod.key,
                     value=metrics_to_payload(metrics, summaries, [], {}))
        log.info("Pod '%s': %d issue(s), %d over the %.4g-business-day SLA.",
                 pod.name, len(metrics), sum(x.flagged_count for x in summaries.values()),
                 s.issue_sla_business_days)

    s0 = _settings(ALL_PODS[0])
    report_months, all_months, _ = months_with_baseline(s0.months_back, s0.baseline_month)
    ti.xcom_push(key="report_months", value=report_months)
    ti.xcom_push(key="all_months", value=all_months)
    ti.xcom_push(key="log_path", value=log_path)


def task_collect_mrs(**kwargs):
    """Runs for every pod. The pods have different code repositories -- three
    for Insights, seven for Conv. Insights -- so each is summed only over
    its own."""
    setup_logging("INFO", log_dir=HERE)
    log = get_logger("dag1.task2")
    ti = kwargs["ti"]

    for pod in ALL_PODS:
        s = _settings(pod)
        log.info("--- Task 2 for pod '%s' across %s ---", pod.name, ", ".join(s.code_repos))
        _report_months, all_months, earliest = months_with_baseline(s.months_back, s.baseline_month)
        metrics, summaries = collect_mr_metrics(GitLabClient(s), s, all_months, earliest)
        ti.xcom_push(key="mr_payload_%s" % pod.key,
                     value=metrics_to_payload([], {}, metrics, summaries))
        log.info("Pod '%s': %d MR(s), %d over the %.4g-hour SLA.",
                 pod.name, len(metrics), sum(x.flagged_count for x in summaries.values()),
                 s.mr_sla_hours)


def task_build_report(**kwargs):
    """One HTML report and one XLSX per pod, same content and styling."""
    log_path = setup_logging("INFO", log_dir=HERE)
    log = get_logger("dag1.task3")
    ti = kwargs["ti"]

    report_months = ti.xcom_pull(task_ids="collect_issue_metrics", key="report_months") or []
    all_months = ti.xcom_pull(task_ids="collect_issue_metrics", key="all_months") or report_months
    log_path = ti.xcom_pull(task_ids="collect_issue_metrics", key="log_path") or log_path
    from gl_metrics import MonthIssueSummary, MonthMRSummary

    outputs = {}
    for pod in ALL_PODS:
        s = _settings(pod)
        ipay = ti.xcom_pull(task_ids="collect_issue_metrics", key="issue_payload_%s" % pod.key) or {}
        mpay = ti.xcom_pull(task_ids="collect_mr_metrics", key="mr_payload_%s" % pod.key) or {}
        issue_metrics, issue_summaries, _, _ = payload_to_metrics(ipay)
        _, _, mr_metrics, mr_summaries = payload_to_metrics(mpay)
        for m in all_months:
            issue_summaries.setdefault(m, MonthIssueSummary(month=m))
            mr_summaries.setdefault(m, MonthMRSummary(month=m))

        summary_rows = build_pod_summary(list(report_months) + [s.baseline_month],
                                         issue_summaries, mr_summaries, s.baseline_month)
        shift_rows, baseline = build_shift_rows(summary_rows, s.baseline_month)

        html = build_metrics_report(s, report_months, issue_metrics, issue_summaries,
                                    mr_metrics, mr_summaries, log_path,
                                    summary_rows, shift_rows, baseline)
        html_path = write_report(html, s.output_dir, "", pod=pod, kind="last_3_months")
        xlsx_path = export_metrics_xlsx(s, report_months, summary_rows, shift_rows, baseline,
                                        issue_summaries, issue_metrics, mr_summaries, mr_metrics,
                                        s.output_dir)
        outputs[pod.key] = {"html": html_path, "xlsx": xlsx_path}
        log.info("Pod '%s': html=%s xlsx=%s", pod.name, html_path, xlsx_path)
        print("Pod %s -> %s | %s" % (pod.name, html_path, xlsx_path))

    ti.xcom_push(key="report_paths", value=outputs)


def task_build_daily_report(**kwargs):
    """A single-day report per pod: what breached today, and what will breach
    today unless it is finished."""
    log_path = setup_logging("INFO", log_dir=HERE)
    log = get_logger("dag1.task4")
    ti = kwargs["ti"]

    start, end, now = day_bounds()
    month = now.strftime("%Y-%m")
    from gl_metrics import MonthIssueSummary, MonthMRSummary

    outputs = {}
    for pod in ALL_PODS:
        s = _settings(pod)
        log.info("--- Task 4 for pod '%s' -- %s (month to date %s) ---", pod.name, now.date(), month)
        ipay = ti.xcom_pull(task_ids="collect_issue_metrics", key="issue_payload_%s" % pod.key) or {}
        mpay = ti.xcom_pull(task_ids="collect_mr_metrics", key="mr_payload_%s" % pod.key) or {}
        issue_metrics, issue_summaries, _, _ = payload_to_metrics(ipay)
        _, _, mr_metrics, mr_summaries = payload_to_metrics(mpay)

        closed_today = issues_closed_on_day(issue_metrics, start, end)
        merged_today = mrs_merged_on_day(mr_metrics, start, end)

        # the at-risk view needs currently open work, which the monthly
        # collectors never fetch -- so this reporting task calls GitLab
        client = GitLabClient(s)
        at_risk_issues = collect_at_risk_issues(client, s, now)
        at_risk_mrs = collect_at_risk_mrs(client, s, now)

        html = build_daily_report(s, now, month, closed_today, merged_today,
                                  at_risk_issues, at_risk_mrs,
                                  issue_summaries.get(month) or MonthIssueSummary(month=month),
                                  mr_summaries.get(month) or MonthMRSummary(month=month),
                                  list(s.code_repos), log_path)
        path = write_report(html, s.output_dir, "", pod=pod, kind="daily")
        xlsx_path = export_daily_xlsx(
            s, now, month, closed_today, merged_today, at_risk_issues, at_risk_mrs,
            issue_summaries.get(month) or MonthIssueSummary(month=month),
            mr_summaries.get(month) or MonthMRSummary(month=month),
            list(s.code_repos), s.output_dir)
        outputs[pod.key] = {"html": path, "xlsx": xlsx_path}
        ti.xcom_push(key="at_risk_%s" % pod.key,
                     value=at_risk_to_payload(at_risk_issues, at_risk_mrs))
        log.info("Pod '%s' daily: %d issue breach(es), %d MR breach(es), "
                 "%d issue(s) and %d MR(s) still at risk.", pod.name,
                 len(closed_today), len(merged_today), len(at_risk_issues), len(at_risk_mrs))
        print("Pod %s daily -> %s | %s" % (pod.name, path, xlsx_path))

    ti.xcom_push(key="daily_report_paths", value=outputs)


default_args = {
    "owner": "STAAT-DS",
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
    "email_on_failure": True,
}

with DAG(
    dag_id="gitlab_productivity_metrics",
    default_args=default_args,
    description="Per-pod issue and MR metrics for the current month plus the previous three, "
                "against a fixed baseline month, in HTML and XLSX, plus a daily at-risk report.",
    start_date=datetime(2026, 1, 1, tzinfo=EST),
    schedule_interval="0 18 * * 1-5",        # 18:00 EST, Monday-Friday
    catchup=False,
    max_active_runs=1,
    tags=["gitlab", "metrics", "productivity"],
) as dag:

    t1 = PythonOperator(task_id="collect_issue_metrics", python_callable=task_collect_issues)
    t2 = PythonOperator(task_id="collect_mr_metrics", python_callable=task_collect_mrs)
    t3 = PythonOperator(task_id="build_html_report", python_callable=task_build_report)
    t4 = PythonOperator(task_id="build_daily_report", python_callable=task_build_daily_report)

    t1 >> t2 >> t3 >> t4
