"""Agile Dev Assist web app - entry point.

    python app_server.py                     # serve (auth.mode from the config; secrets from environment variables)
    python app_server.py --selftest          # demo server with the scripted model and sample inputs (no secrets)
    python app_server.py --check             # verify the model key / connectivity and exit
    python app_server.py --run-selftest      # offline end-to-end test of the engine, no server
    python app_server.py --bench bench/ikg.yaml [--scripted]      # regression set: real stories vs the files their merged MRs touched
    python app_server.py --bench-compare bench/results/a.json bench/results/b.json

Environment variables (names from config secrets:): AGILEDEV_AZURE_OPENAI_API_KEY, AGILEDEV_SERVER_SECRET,
AGILEDEV_OIDC_CLIENT_SECRET (oidc only). Per-user git tokens / Greenplum passwords are entered in the UI.
"""
from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from agiledev.config import load_config  # noqa: E402


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config")
    ap.add_argument("--host")
    ap.add_argument("--port", type=int)
    ap.add_argument("--auth", choices=["header", "oidc", "dev"], help="override auth.mode")
    ap.add_argument("--selftest", action="store_true", help="scripted model, sample inputs, dev login")
    ap.add_argument("--run-selftest", action="store_true")
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--bench", help="run the regression set described by this yaml (see agiledev/bench.py)")
    ap.add_argument("--bench-compare", nargs=2, metavar=("BEFORE_JSON", "AFTER_JSON"))
    ap.add_argument("--scripted", action="store_true", help="--bench with the offline scripted model (smoke run, no key)")
    ap.add_argument("--open", action="store_true", help="open the browser")
    a = ap.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    for n in ("httpx", "httpx2", "openai", "sqlglot", "uvicorn.access"):
        logging.getLogger(n).setLevel(logging.WARNING)
    cfg = load_config(a.config)
    if a.auth:
        cfg["auth"]["mode"] = a.auth
    if a.selftest:
        cfg["auth"]["mode"] = "dev"
        cfg["storage"]["data_dir"] = "data_selftest"
        cfg["storage"]["db_file"] = "data_selftest/agiledev.db"
        cfg["storage"]["llm_cache_dir"] = "data_selftest/cache/llm"
        cfg["storage"]["repo_cache_dir"] = "data_selftest/cache/repos"
        from agiledev.selftest import make_sample_inputs
        paths = make_sample_inputs(cfg.path("data_selftest/samples"))
        print("sample inputs:", {k: str(v) for k, v in paths.items()})
    if a.run_selftest:
        from agiledev.selftest import run_selftest
        run_selftest(cfg, cfg.path("data_selftest/engine"))
        return
    if a.bench:
        from agiledev.bench import run_bench
        from pathlib import Path
        run_bench(cfg, Path(a.bench), cfg.path("bench/results"), scripted=a.scripted)
        return
    if a.bench_compare:
        from agiledev.bench import compare
        from pathlib import Path
        print(compare(Path(a.bench_compare[0]), Path(a.bench_compare[1])))
        return
    if a.check:
        from agiledev.llm import LLM
        print("Azure OpenAI:", LLM(cfg, cfg.path(cfg.storage["llm_cache_dir"])).check())
        return
    from agiledev.server import serve
    serve(cfg, a.host, a.port, selftest=a.selftest, open_browser=a.open)


if __name__ == "__main__":
    main()
