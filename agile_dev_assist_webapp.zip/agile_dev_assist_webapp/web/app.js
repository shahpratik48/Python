/* Agile Dev Assist UI: drag-and-drop inputs, chat with live milestones, right panel (plan / files / review / log / tokens / outputs). */
(() => {
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => Array.from(el.querySelectorAll(s));
  // served behind jupyter-server-proxy (…/proxy/8780/) or at the root: every URL is RELATIVE to the page, and
  // non-GET requests carry Jupyter's _xsrf token (header + query) so the proxy lets them through
  if (!location.pathname.endsWith("/")) location.replace(location.pathname + "/" + location.search);
  const xsrf = () => { const m = document.cookie.match(/(?:^|;\s*)_xsrf=([^;]+)/); return m ? decodeURIComponent(m[1]) : ""; };
  const rel = url => url.replace(/^\//, "");
  const api = async (url, opt = {}) => {
    url = rel(url);
    const method = (opt.method || "GET").toUpperCase();
    if (method !== "GET") { const t = xsrf(); if (t) { opt.headers = Object.assign({}, opt.headers || {}, { "X-XSRFToken": t }); url += (url.includes("?") ? "&" : "?") + "_xsrf=" + encodeURIComponent(t); } }
    const r = await fetch(url, opt);
    if (r.status === 401) { location.reload(); throw new Error("signed out"); }
    const ct = r.headers.get("content-type") || "";
    const body = ct.includes("json") ? await r.json() : await r.text();
    if (!r.ok) throw new Error((body && body.detail) || body || r.statusText);
    return body;
  };
  const post = (url, data) => api(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data || {}) });
  const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const md = s => esc(s).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/(https?:\/\/[^\s)]+)/g, '<a href="$1" target="_blank">$1</a>');
  const toast = (msg, bad) => { const t = $("#toast"); t.textContent = msg; t.className = "toast show" + (bad ? " bad" : ""); clearTimeout(t._t); t._t = setTimeout(() => t.className = "toast", bad ? 6000 : 3000); };

  // ---------------------------------------------------------------- icons (inline SVG per name)
  const SVG = {
    story: '<svg viewBox="0 0 24 24"><path d="M6 3h9l5 5v13H6z"/><path d="M14 3v6h6M9 13h6M9 17h6"/></svg>',
    skills: '<svg viewBox="0 0 24 24"><path d="M12 3l2.5 5.5L20 9l-4 4 1 6-5-3-5 3 1-6-4-4 5.5-.5z"/></svg>',
    gp: '<svg viewBox="0 0 24 24"><ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/></svg>',
    git: '<svg viewBox="0 0 24 24"><circle cx="6" cy="5" r="2.5"/><circle cx="6" cy="19" r="2.5"/><circle cx="18" cy="9" r="2.5"/><path d="M6 7.5v9M18 11.5c0 3-3 4-6 4H9"/></svg>',
    gloss: '<svg viewBox="0 0 24 24"><path d="M4 5a2 2 0 012-2h12a2 2 0 012 2v14a2 2 0 01-2 2H6a2 2 0 01-2-2z"/><path d="M8 7h8M8 11h8M8 15h5"/></svg>',
    std: '<svg viewBox="0 0 24 24"><path d="M9 11l2 2 4-4"/><path d="M12 3l8 3v6c0 5-3.5 8.5-8 9-4.5-.5-8-4-8-9V6z"/></svg>',
    agent: '<svg viewBox="0 0 24 24"><rect x="4" y="7" width="16" height="12" rx="3"/><circle cx="9" cy="13" r="1.5"/><circle cx="15" cy="13" r="1.5"/><path d="M12 3v4M8 21v-2M16 21v-2"/></svg>',
    plan: '<svg viewBox="0 0 24 24"><path d="M4 6h16M4 12h10M4 18h7"/><circle cx="18" cy="17" r="3"/></svg>',
    code: '<svg viewBox="0 0 24 24"><path d="M8 8l-4 4 4 4M16 8l4 4-4 4M14 5l-4 14"/></svg>',
    review: '<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="6"/><path d="M20 20l-4.5-4.5M8.5 11l2 2 3-3"/></svg>',
    data: '<svg viewBox="0 0 24 24"><path d="M4 19h16M7 16V9M12 16V5M17 16v-6"/></svg>',
    run: '<svg viewBox="0 0 24 24"><path d="M7 4l12 8-12 8z"/></svg>',
    push: '<svg viewBox="0 0 24 24"><path d="M12 19V5M5 12l7-7 7 7"/><path d="M5 21h14"/></svg>',
    zip: '<svg viewBox="0 0 24 24"><path d="M12 4v12M6 11l6 6 6-6"/><path d="M4 20h16"/></svg>',
    log: '<svg viewBox="0 0 24 24"><path d="M5 4h14v16H5z"/><path d="M8 8h8M8 12h8M8 16h5"/></svg>',
    tokens: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8"/><path d="M12 8v8M9 10.5h4.5a1.5 1.5 0 010 3H9"/></svg>',
  };
  const INPUTS = [
    { id: "story", name: "Story", cls: "b-story", svg: "story", hint: "git issue / file / paste" },
    { id: "knowledge", name: "Knowledge", cls: "b-skills", svg: "skills", hint: "skills, standards & conventions, glossary / data dictionary (md yml txt csv xlsx docx html) - or a knowledge pack zip (ikg_pack.zip)" },
    { id: "greenplum", name: "Data", cls: "b-gp", svg: "gp", hint: "Greenplum tables / query" },
    { id: "repo", name: "Code repo", cls: "b-git", svg: "git", hint: "GitLab / GitHub project or local folder" },
  ];
  const AGENTS = [
    { id: "story_agent", name: "Story", svg: "story" }, { id: "knowledge_agent", name: "Knowledge", svg: "skills" },
    { id: "data_agent", name: "Data", svg: "data" }, { id: "repo_agent", name: "Repo", svg: "git" },
    { id: "planner_agent", name: "Planner", svg: "plan" }, { id: "coder_agent", name: "Coder", svg: "code" },
    { id: "reviewer_agent", name: "Reviewer", svg: "review" }, { id: "change_agent", name: "Change", svg: "agent" },
  ];
  const TOOLS = [
    { id: "branch", name: "Feature branch", svg: "git" }, { id: "run", name: "Run", svg: "run" }, { id: "push", name: "Push & MR", svg: "push" }, { id: "zip", name: "Download zip", svg: "zip" },
    { id: "log", name: "Log / plan", svg: "log" }, { id: "tokens", name: "Tokens", svg: "tokens" }, { id: "docs", name: "Docs (docx/pptx)", svg: "gloss" },
  ];
  const STAGES = ["story", "knowledge", "data", "repo", "plan", "generate", "validate", "review", "fix", "outputs"];

  const fmtSecs = v => { const n = Number(v); if (!isFinite(n)) return String(v ?? ""); return (n >= 10 ? n.toFixed(0) : n.toFixed(1)) + "s" + (n >= 60 ? ` (${(n / 60).toFixed(1)} min)` : ""); };
  const S = { me: null, chatId: null, state: null, nextEvent: 0, poll: null, file: null, counts: {} };

  function renderIcons() {
    $("#inputIcons").innerHTML = INPUTS.map(i => `<div class="icon input" draggable="true" data-kind="input" data-id="${i.id}" title="${i.hint}">
      <div class="badge ${i.cls}">${SVG[i.svg]}<span class="count" id="cnt-${i.id}" style="display:none"></span></div><div class="name">${i.name}</div></div>`).join("");
    $("#agentIcons").innerHTML = AGENTS.map(a => `<div class="icon agent" draggable="true" data-kind="agent" data-id="${a.id}" id="ag-${a.id}" title="${a.id}">
      <div class="badge">${SVG[a.svg]}</div><div class="name">${a.name}</div></div>`).join("");
    $("#toolIcons").innerHTML = TOOLS.map(t => `<div class="icon tool" draggable="true" data-kind="tool" data-id="${t.id}">
      <div class="badge b-tool">${SVG[t.svg]}</div><div class="name">${t.name}</div></div>`).join("");
    $$(".icon").forEach(el => {
      el.addEventListener("dragstart", e => { e.dataTransfer.setData("text/plain", JSON.stringify({ kind: el.dataset.kind, id: el.dataset.id })); e.dataTransfer.effectAllowed = "copy"; });
      el.addEventListener("click", () => activate(el.dataset.kind, el.dataset.id));
    });
    const chat = $("#chat");
    chat.addEventListener("dragover", e => { e.preventDefault(); chat.classList.add("dragover"); });
    chat.addEventListener("dragleave", () => chat.classList.remove("dragover"));
    chat.addEventListener("drop", e => {
      e.preventDefault(); chat.classList.remove("dragover");
      if (e.dataTransfer.files && e.dataTransfer.files.length) { openModal("files-drop", { files: e.dataTransfer.files }); return; }
      try { const d = JSON.parse(e.dataTransfer.getData("text/plain")); activate(d.kind, d.id, true); } catch (_) { }
    });
  }

  // ---------------------------------------------------------------- templates (saved inputs, per user)
  async function loadTemplates() {
    try {
      const r = await api("/api/templates"); S.templates = r.templates || [];
      const box = $("#templateIcons");
      box.innerHTML = S.templates.length ? S.templates.map(t => `<div class="icon template ${t.prebuilt ? "prebuilt" : ""} ${t.prebuilt && !t.available ? "unavailable" : ""}" data-kind="template" data-id="${esc(t.id)}" title="${esc(describeTemplate(t))}">
        ${t.prebuilt ? "" : '<span class="x" title="delete template">✕</span>'}<div class="badge ${t.prebuilt ? "b-skills" : ""}">${SVG[t.prebuilt ? "skills" : "std"]}</div><div class="name">${esc(t.name)}${t.prebuilt ? "<small> pack</small>" : ""}</div></div>`).join("")
        : `<div class="tpl-empty">none yet - add inputs to a chat, then ＋ save</div>`;
      $$(".icon.template", box).forEach(el => {
        el.onclick = e => { if (e.target.classList.contains("x")) return; applyTemplate(el.dataset.id); };
        if ($(".x", el)) $(".x", el).onclick = async e => { e.stopPropagation(); const t = S.templates.find(x => x.id === el.dataset.id); if (!confirm(`Delete template "${t ? t.name : el.dataset.id}"?`)) return; await api(`/api/templates/${el.dataset.id}`, { method: "DELETE" }); loadTemplates(); };
      });
    } catch (e) { /* ignore */ }
  }
  function describeTemplate(t) {
    const s = t.summary || {}; const parts = [];
    if (t.prebuilt) {
      const g = t.git || {};
      return `${t.name} system template (every user): the nightly ${t.system} knowledge pack ${(t.pack_meta || {}).version || ""} - pre-analysed, indexed repository, tables, conventions, rules` +
        (t.available ? "" : "\n⚠ " + (s.note || "pack missing")) + `\ngit: branch from ${g.base_branch || "default"}, named ${g.branch_template || ""}, MR to ${g.mr_target || g.base_branch || "default"}` +
        "\nclick to load into the current chat, then add the story and any extra inputs";
    }
    if (s.story) parts.push("story: " + s.story); if (s.knowledge || s.skills || s.standards || s.glossary) parts.push(((s.knowledge || 0) + (s.skills || 0) + (s.standards || 0) + (s.glossary || 0)) + " knowledge");
    if ((s.packs || []).length) parts.push("pack " + s.packs.join(", "));
    if (s.tables) parts.push(s.tables + " tables"); if (s.queries) parts.push(s.queries + " queries"); if ((s.repos || []).length) parts.push("repo " + s.repos.join(", "));
    return (parts.join(" · ") || "empty") + "\nclick to load into the current chat";
  }
  async function saveTemplate() {
    if (!S.chatId) { toast("open the chat whose inputs you want to save"); return; }
    const name = prompt("Template name (e.g. IKG beneficiary stories):"); if (!name || !name.trim()) return;
    try { const t = await post("/api/templates", { name: name.trim(), chat_id: S.chatId }); toast(`template "${t.name}" saved`); loadTemplates(); } catch (e) { toast(e.message, true); }
  }
  async function applyTemplate(tid) {
    if (!S.chatId) { await newChat(); }
    const t = (S.templates || []).find(x => x.id === tid);
    try { let r = await post(`/api/chats/${S.chatId}/template/${tid}`, {}); if (r && r.task) { toast("loading the knowledge pack ..."); r = await waitTask(r, p => toast("⏳ " + p)); } toast(`template "${t ? t.name : tid}" loaded`); await loadChat(S.chatId); await loadChats(); showTab("inputs"); }
    catch (e) { toast(e.message, true); }
  }
  $("#btnSaveTemplate").onclick = saveTemplate;

  function activate(kind, id, viaDrag) {
    if (!S.chatId) { toast("create or open a chat first"); return; }
    if (kind === "input") openModal(id);
    else if (kind === "agent") { if (viaDrag) addToPipeline(id); else showAgentInfo(id); }
    else if (kind === "tool") tool(id);
  }
  // ---------------------------------------------------------------- agent pipeline (order of the next run)
  const PIPE_AGENTS = ["story_agent", "knowledge_agent", "data_agent", "repo_agent", "planner_agent", "coder_agent", "reviewer_agent"];
  function renderPipeline() {
    const p = (S.state && S.state.pipeline) || PIPE_AGENTS; const box = $("#plItems");
    box.innerHTML = p.length ? p.map((a, i) => `<span class="pl-item" draggable="true" data-a="${a}"><span class="n">${i + 1}</span>${esc(a.replace("_agent", ""))}<span class="x" title="remove from the pipeline">✕</span></span>${i < p.length - 1 ? '<span class="pl-arrow">›</span>' : ""}`).join("")
      : `<span class="pl-empty">empty - drag agent icons here or press reset</span>`;
    $$(".pl-item", box).forEach(el => {
      $(".x", el).onclick = () => savePipeline(p.filter(a => a !== el.dataset.a));
      el.addEventListener("dragstart", e => { e.dataTransfer.setData("text/plain", JSON.stringify({ kind: "pipe", id: el.dataset.a })); el.classList.add("dragging"); });
      el.addEventListener("dragend", () => el.classList.remove("dragging"));
      el.addEventListener("dragover", e => { e.preventDefault(); el.classList.add("over"); });
      el.addEventListener("dragleave", () => el.classList.remove("over"));
      el.addEventListener("drop", e => { e.preventDefault(); e.stopPropagation(); el.classList.remove("over"); try { const d = JSON.parse(e.dataTransfer.getData("text/plain")); if (d.kind === "pipe" || d.kind === "agent") moveInPipeline(d.id, el.dataset.a); } catch (_) { } });
    });
  }
  function moveInPipeline(id, before) {
    if (!PIPE_AGENTS.includes(id) || id === before) return;
    const p = ((S.state && S.state.pipeline) || PIPE_AGENTS).filter(a => a !== id); p.splice(p.indexOf(before), 0, id); savePipeline(p);
  }
  function addToPipeline(id) {
    if (!PIPE_AGENTS.includes(id)) { toast(`${id} is not part of the run pipeline (it answers change requests after the run)`); return; }
    const p = (S.state && S.state.pipeline) || PIPE_AGENTS; if (p.includes(id)) { toast(`${id.replace("_agent", "")} is already in the pipeline`); return; }
    savePipeline([...p, id]);
  }
  async function savePipeline(p) {
    try { const r = await api(`/api/chats/${S.chatId}/pipeline`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ pipeline: p }) });
      S.state = Object.assign(S.state || {}, { pipeline: r.pipeline }); renderPipeline(); } catch (e) { toast(e.message, true); }
  }
  $("#plReset").onclick = () => savePipeline(PIPE_AGENTS);
  const plBox = $("#pipeline");
  plBox.addEventListener("dragover", e => { e.preventDefault(); plBox.classList.add("dragover"); });
  plBox.addEventListener("dragleave", () => plBox.classList.remove("dragover"));
  plBox.addEventListener("drop", e => { e.preventDefault(); plBox.classList.remove("dragover"); try { const d = JSON.parse(e.dataTransfer.getData("text/plain")); if (d.kind === "agent") addToPipeline(d.id); else if (d.kind === "pipe") { const p = ((S.state && S.state.pipeline) || PIPE_AGENTS).filter(a => a !== d.id); savePipeline([...p, d.id]); } } catch (_) { } });

  // ---------------------------------------------------------------- modals (one form per input)
  // repository name next to a project URL / folder field, so people see they typed the right project
  function repoName(v) {
    v = (v || "").trim().replace(/[\\/]+$/, "");
    if (!v) return "";
    let m = v.match(/^(https?:\/\/[^/]+\/)(.+)$/);
    let p = m ? m[2] : v;
    p = p.replace(/\/-\/(tree|issues|blob|merge_requests)\/.*$/, "").replace(/\.git$/, "").replace(/\/(issues|tree|blob)\/.*$/, "");
    const parts = p.split(/[\\/]+/).filter(Boolean);
    return parts.length ? parts[parts.length - 1] : "";
  }
  function repoHint(inp) {
    if (!inp || !inp.dataset.hint) return;
    const h = $("#" + inp.dataset.hint); if (!h) return;
    const n = repoName(inp.value);
    h.innerHTML = n ? `→ repository <b>${esc(n)}</b>` : "";
  }
  document.addEventListener("input", e => { if (e.target && e.target.dataset && e.target.dataset.hint) repoHint(e.target); });
  const MODALS = {
    story: {
      title: "Story", badge: "b-story", svg: "story", sub: "Where is the story? A git issue (project URL + number) or a file in a repository, an uploaded file, or pasted text.",
      body: `<div class="seg" id="storyMode"><span class="on" data-v="git">Git issue / file</span><span data-v="file">Upload file</span><span data-v="text">Paste text</span></div>
        <div data-mode="git"><label>Git project URL (GitLab or GitHub) <span class="repohint" id="s_url_hint"></span></label><input id="s_url" data-hint="s_url_hint" placeholder="https://devcloud.ubs.net/group/project  or  .../-/issues/123">
          <label>Git token (optional - the read token given at launch is used when empty)</label><input id="s_token" type="password" placeholder="leave empty to use the read token">
          <div class="row"><div style="flex:1"><label>Issue number</label><input id="s_issue" placeholder="123"></div><div style="flex:2"><label>or file path in the repo</label><input id="s_path" placeholder="stories/STORY-123.md"></div><div style="flex:1"><label>branch</label><input id="s_ref" placeholder="main"></div></div></div>
        <div data-mode="file" style="display:none"><label>Story file (md, txt, docx, doc, html, xlsx, csv, yaml ...)</label><input type="file" id="s_file"></div>
        <div data-mode="text" style="display:none"><label>Story id</label><input id="s_id" placeholder="STORY-123"><label>Title</label><input id="s_title"><label>Story text</label><textarea id="s_text" style="min-height:180px"></textarea></div>`,
      submit: async () => {
        const mode = $("#storyMode .on").dataset.v;
        const fd = new FormData(); fd.append("mode", mode);
        if (mode === "git") { fd.append("url", $("#s_url").value); fd.append("token", $("#s_token").value); fd.append("issue", $("#s_issue").value); fd.append("path", $("#s_path").value); fd.append("ref", $("#s_ref").value); }
        else if (mode === "file") { const f = $("#s_file").files[0]; if (!f) throw new Error("choose a file"); fd.append("file", f); }
        else { fd.append("text", $("#s_text").value); fd.append("title", $("#s_title").value); fd.append("story_id", $("#s_id").value); }
        let r = await api(`/api/chats/${S.chatId}/inputs/story`, { method: "POST", body: fd });
        r = await waitTask(r, p => progress("⏳ " + p));
        toast(`story ${r.id}: ${r.title}`); storyCard(r);
      }
    },
    knowledge: docModal("knowledge", "Knowledge", "b-skills", "skills", "Skills, how-tos, patterns, coding standards, naming conventions, review rules (the validator turns clear rules into checks), glossary / data dictionary files (name containing gloss or dictionary: read row by row) - or a System Knowledge Pack zip (ikg_pack.zip / odm_pack.zip / nlg_pack.zip: the pre-analysed, indexed knowledge of a whole system, repository and tables included)."),
    repo: {
      title: "Code repository", badge: "b-git", svg: "git", sub: "The complete code is downloaded with YOUR token, indexed, and used for patterns, conventions and the files to modify.",
      body: `<label>Project URL - or a local folder path on this machine (e.g. C:\\work\\ikg-dags or /home/me/ikg-dags) for local testing <span class="repohint" id="r_url_hint"></span></label><input id="r_url" data-hint="r_url_hint" placeholder="https://devcloud.ubs.net/group/project (optionally /-/tree/branch)">
        <label>Git token (optional - the read token given at launch is used when empty)</label><input id="r_token" type="password" placeholder="leave empty to use the read token">
        <div class="row"><div style="flex:1"><label>Branch (default: project default)</label><input id="r_branch" placeholder="ikg-master"></div>
        <div style="flex:1"><label>Short name (default: project name)</label><input id="r_name"></div><div style="flex:1"><label>Sub-folder only (optional)</label><input id="r_sub" placeholder="dags/ikg"></div></div>
        <label style="display:flex;gap:8px;align-items:center"><input type="checkbox" id="r_refresh" style="width:auto"> re-sync even if cached (incremental git fetch - seconds)</label>`,
      submit: async () => {
        let r = await post(`/api/chats/${S.chatId}/inputs/repo`, { url: $("#r_url").value, token: $("#r_token").value, branch: $("#r_branch").value, name: $("#r_name").value, subpath: $("#r_sub").value, refresh: $("#r_refresh").checked });
        r = await waitTask(r, p => progress("⏳ " + p));
        toast(`repository ${r.name}@${r.branch}: ${r.files} files`); inputCard("repo", `${r.name}@${r.branch}: ${r.files} files indexed (${Object.entries(r.languages).map(([k, v]) => k + " " + v).join(", ")})`);
      }
    },
    greenplum: {
      title: "Greenplum tables / query", badge: "b-gp", svg: "gp", sub: "Connection details stay in memory for your session. Tables are introspected (columns, types, keys, comments, sample rows); a read-only query can be added as input.",
      body: `<div class="row"><div style="flex:3"><label>Host</label><input id="g_host" placeholder="greenplum-rdsp.zur.swissbank.com"></div><div style="flex:1"><label>Port</label><input id="g_port" value="5432"></div><div style="flex:2"><label>Database</label><input id="g_db" placeholder="gprdsp"></div></div>
        <div class="row"><div style="flex:1"><label>User</label><input id="g_user"></div><div style="flex:1"><label>Password</label><input id="g_pw" type="password" placeholder="leave empty to reuse"></div><div style="flex:1"><label>Schema</label><input id="g_schema" placeholder="core_ikg"></div></div>
        <label>Tables (comma or newline separated; schema.table allowed) <a href="#" id="g_list">list tables of the schema</a></label><textarea id="g_tables" placeholder="account_profile_curr_ikg, client_dim"></textarea>
        <label>Read-only query (optional)</label><textarea id="g_query" placeholder="select ... from ... limit 100"></textarea>
        <label style="display:flex;gap:8px;align-items:center"><input type="checkbox" id="g_refresh" style="width:auto"> re-read the tables even if described today (cache)</label>
        <div id="g_sqlite_wrap" style="display:none"><label>Local test: path of a sqlite file playing the database (leave empty for a real Greenplum)</label><input id="g_sqlite" placeholder="data_selftest/samples/sample_gp.db"></div>`,
      submit: async () => {
        const body = { host: $("#g_host").value, port: $("#g_port").value, database: $("#g_db").value, user: $("#g_user").value, password: $("#g_pw").value,
          schema: $("#g_schema").value, tables: $("#g_tables").value.split(/[\n,]/).map(s => s.trim()).filter(Boolean), query: $("#g_query").value, sqlite_path: $("#g_sqlite").value, refresh: $("#g_refresh").checked };
        let r = await post(`/api/chats/${S.chatId}/inputs/greenplum`, body);
        r = await waitTask(r, p => progress("⏳ " + p));
        toast(`${r.tables.length} table(s) added`); inputCard("greenplum", `${r.tables.map(t => t.schema + "." + t.table + " (" + t.columns + " cols)").join(", ")}${r.query ? ", query " + r.query.name + " (" + r.query.row_count + " rows)" : ""}`);
      },
      after: () => {
        const d = (S.me && S.me.greenplum_defaults) || {};
        if (d.host) $("#g_host").value = d.host; if (d.port) $("#g_port").value = d.port; if (d.database) $("#g_db").value = d.database;
        if (d.user) $("#g_user").value = d.user; if (d.schema) $("#g_schema").value = d.schema;
        if (S.me && (S.me.selftest || S.me.local_test)) $("#g_sqlite_wrap").style.display = "";
        $("#g_list").onclick = async e => { e.preventDefault(); try { const r = await post(`/api/chats/${S.chatId}/inputs/greenplum`, { action: "list", host: $("#g_host").value, port: $("#g_port").value, database: $("#g_db").value, user: $("#g_user").value, password: $("#g_pw").value, schema: $("#g_schema").value, sqlite_path: $("#g_sqlite").value }); $("#g_tables").value = r.tables.join("\n"); } catch (err) { $("#modalErr").textContent = err.message; } };
      }
    },
    push: {
      title: "Push a branch", badge: "b-tool", svg: "push", ok: "Push selected files", sub: "Choose which files go to this repository; the branch is created from the base branch and the commit is made with YOUR token, so it appears under your name. Push again with another URL for files that belong to a different repository.",
      body: `<label>Git project URL <span class="repohint" id="p_url_hint"></span></label><input id="p_url" data-hint="p_url_hint"><label>Your PERSONAL git token (required - the branch and commit are created under your name; the read token is never used)</label><input id="p_token" type="password" placeholder="required" required>
        <div class="row"><div style="flex:1"><label>Base branch (create from)</label><input id="p_base" placeholder="ikg-master"></div><div style="flex:2"><label>New branch name (convention: storyid-system-feature, e.g. 2400-ikg-beneficiary-enrichment)</label><input id="p_branch"></div></div>
        <div class="row"><div style="flex:1"><label>Merge request target branch (optional - empty = branch only, no MR)</label><input id="p_mr" placeholder="ikg-master"></div><div style="flex:2"><label>Commit message / MR title (optional - "agile_dev_assist:" is always put in front)</label><input id="p_msg" placeholder="agile_dev_assist: 2547: IRA & TOD beneficiaries (for Pratik)"></div></div>
        <div style="font-size:11.5px;color:var(--muted);margin-top:2px">With a target branch: create branch → commit → open a merge request from the new branch to the target (reusing an open one if it exists). The MR description lists the files and the confidence score.</div>
        <div class="row" style="align-items:center;margin-top:8px"><label style="margin:0">Files to push</label><span style="flex:1"></span><button type="button" class="mini" id="p_all">all</button><button type="button" class="mini" id="p_none">none</button></div>
        <div id="p_files" class="pushfiles"></div>`,
      submit: async () => {
        if (!$("#p_token").value.trim()) throw new Error("your personal git token is required to push");
        const paths = $$("#p_files input:checked").map(i => i.value);
        if (!paths.length) throw new Error("select at least one file to push");
        const r = await post(`/api/chats/${S.chatId}/push`, { url: $("#p_url").value, token: $("#p_token").value, branch: $("#p_branch").value, base_branch: $("#p_base").value, message: $("#p_msg").value, paths, mr_target: $("#p_mr").value });
        toast(`pushed ${r.files} file(s) to ${r.branch}` + (r.mr_url ? ` · MR !${r.mr_iid}` : "")); addSystem(`Pushed ${r.files} file(s) to ${r.branch} as ${r.pushed_as}: ${r.branch_url}` + (r.mr_url ? `\nMerge request ${r.mr_created ? "created" : "already open"} → ${r.mr_target}: ${r.mr_url}` : "")); loadChat(S.chatId);
      },
      after: async () => {
        const r = await api(`/api/chats/${S.chatId}/branch-suggestion`);
        $("#p_url").value = r.repo_url || ""; $("#p_base").value = r.base_branch || ""; $("#p_branch").value = r.branch || ""; $("#p_mr").value = r.mr_target || r.base_branch || ""; repoHint($("#p_url"));
        if (r.source === "template") toast(`git conventions of the ${(r.system || "").toUpperCase()} template applied - edit if needed`);
        const files = (S.state && S.state.files) || [];
        const pushed = (S.state && S.state.pushed) || {};        // path -> [{branch, project}] from earlier pushes
        $("#p_files").innerHTML = files.length ? files.map(f => `<label class="pf"><input type="checkbox" value="${esc(f.path)}" ${pushed[f.path] ? "" : "checked"}>
          <span class="pf-path">${esc(f.path)}</span><small>${esc(f.language)} · ${esc(f.action)}${pushed[f.path] ? " · pushed to " + pushed[f.path].map(x => esc(x.project + "@" + x.branch)).join(", ") : ""}</small>
          <span class="x" title="remove from this push">✕</span></label>`).join("") : "<span style='color:var(--muted)'>nothing generated yet</span>";
        $$("#p_files .pf .x").forEach(x => x.onclick = e => { e.preventDefault(); const lab = x.closest(".pf"); lab.querySelector("input").checked = false; lab.classList.add("off"); });
        $$("#p_files .pf input").forEach(i => i.onchange = () => i.closest(".pf").classList.toggle("off", !i.checked));
        $("#p_all").onclick = () => $$("#p_files .pf input").forEach(i => { i.checked = true; i.closest(".pf").classList.remove("off"); });
        $("#p_none").onclick = () => $$("#p_files .pf input").forEach(i => { i.checked = false; i.closest(".pf").classList.add("off"); });
        $("#p_url").onchange = async () => { const s = await api(`/api/chats/${S.chatId}/branch-suggestion?url=` + encodeURIComponent($("#p_url").value)); $("#p_branch").value = s.branch; };
      }
    },
    branch: {
      title: "Feature branch (checkout)", badge: "b-git", svg: "git", ok: "Create branch(es)",
      sub: "Step 1 of 3 - checkout. The feature branch is created from the base branch (ikg-master / odm-master / nlg-master) as this chat's private copy; every Run then commits on it (step 2) and Push & MR sends it (step 3). Do this before the first Run. Tick every repository the story touches (e.g. ODM and NLG).",
      body: `<div id="br_rows"></div>
        <div style="font-size:11.5px;color:var(--muted);margin-top:6px">Base branch = where the feature branch starts (from the system template, editable). The merge target is chosen in Push & MR. The read token is enough to check out; nothing is created on GitLab until you push.</div>
        <label>Git token (optional - the read token given at launch is used when empty)</label><input id="br_token" type="password" placeholder="leave empty to use the read token">`,
      submit: async () => {
        const rows = $$("#br_rows .brrow").filter(r => $(".br_on", r).checked).map(r => ({ system: r.dataset.system, repo_url: $(".br_url", r).value.trim(), base: $(".br_base", r).value.trim(), feature: $(".br_feat", r).value.trim(), target: $(".br_tgt", r).value.trim() }));
        if (!rows.length) throw new Error("tick at least one repository");
        for (const r of rows) if (!r.repo_url || !r.base || !r.feature) throw new Error("repository URL, base branch and feature branch are required for every ticked row");
        let r = await post(`/api/chats/${S.chatId}/branches`, { branches: rows, token: $("#br_token").value });
        r = await waitTask(r, p => progress("⏳ " + p));
        toast(`${r.branches.length} feature branch(es) checked out`); await loadChat(S.chatId);
        if (S.pendingRun !== undefined) { const instr = S.pendingRun; delete S.pendingRun; addSystem("Feature branch ready - starting the run."); runNow(instr); }
      },
      after: async () => {
        const r = await api(`/api/chats/${S.chatId}/branches`);
        const have = {}; (r.branches || []).forEach(b => have[b.system] = b);
        const rows = (r.templates || []).map(t => ({ ...t, custom: false })).concat([{ system: "", name: "Other", repo_url: "", base: "", target: "", feature: "", custom: true }]);
        $("#br_rows").innerHTML = rows.map(t => `<div class="brrow ${have[t.system] ? "have" : ""}" data-system="${esc(t.system)}">
          <label class="brhead"><input type="checkbox" class="br_on" ${have[t.system] ? "disabled" : ""}> <b>${esc(t.name)}</b> ${have[t.system] ? `<small>already checked out: ${esc(have[t.system].feature)} (${(have[t.system].commits || []).length} commit(s))</small>` : ""}</label>
          <div class="row"><div style="flex:3"><label>Repository URL</label><input class="br_url" value="${esc(t.repo_url || "")}" placeholder="https://devcloud.ubs.net/.../odm-dags"></div></div>
          <div class="row"><div style="flex:1"><label>Base branch (from)</label><input class="br_base" value="${esc(t.base || "")}" placeholder="odm-master"></div>
          <div style="flex:2"><label>Feature branch (new)</label><input class="br_feat" value="${esc(t.feature || "")}" placeholder="2400-odm-feature-name"><input type="hidden" class="br_tgt" value="${esc(t.target || "")}"></div></div></div>`).join("");
        $$("#br_rows .brrow").forEach(row => { $$("input:not(.br_on)", row).forEach(i => i.oninput = () => { if (!$(".br_on", row).disabled) $(".br_on", row).checked = true; }); });
        if (!(S.state && S.state.inputs && S.state.inputs.story)) toast("tip: set the story first - the feature branch name is derived from it", true);
      }
    },
    pushbranch: {
      title: "Push & merge request", badge: "b-tool", svg: "push", ok: "Push & open MR",
      sub: "Step 3 of 3 - send. For every feature branch of this chat: the private copy is refreshed from its base branch, every commit is stamped with the owner of YOUR token, the branch is pushed and a merge request to the target branch is opened. Branch, commits and MR all carry your name.",
      body: `<div id="pb_list"></div>
        <label>Your PERSONAL git token (required)</label><input id="pb_token" type="password" placeholder="required" required>
        <label>Commit message (optional - replaces the last commit's message; "agile_dev_assist:" prefixes the MR title)</label><input id="pb_msg" placeholder="2400: beneficiary enrichment - profile columns + validation">
        <label style="display:flex;gap:8px;align-items:center;margin-top:8px"><input type="checkbox" id="pb_mr" checked style="width:auto"> open / update the merge request to the target branch</label>`,
      submit: async () => {
        const tok = $("#pb_token").value.trim(); if (!tok) throw new Error("your personal git token is required");
        const slugs = $$("#pb_list input.pb_on:checked").map(i => i.value); if (!slugs.length) throw new Error("select at least one branch");
        for (const slug of slugs) {
          const tgt = $(`#pb_list .pbrow[data-slug="${slug}"] .pb_tgt`).value.trim();
          const r = await post(`/api/chats/${S.chatId}/branches/${slug}/push`, { token: tok, message: $("#pb_msg").value, create_mr: $("#pb_mr").checked, mr_target: tgt });
          if (r.pushed) { toast(`pushed ${r.branch} (${r.commits} commit(s)) as ${r.pushed_as}` + (r.mr_url ? ` · MR !${r.mr_iid}` : "")); addSystem(`Pushed ${r.branch} as ${r.pushed_as}: ${r.branch_url}` + (r.mr_url ? `\nMerge request ${r.mr_created ? "created" : "already open"} → ${r.mr_target}: ${r.mr_url}` : "") + ((r.target_conflicts || {}).conflicts ? `\nCONFLICTS with ${r.mr_target}: ${(r.target_conflicts.files || []).join(", ")}` : "")); }
          else { toast(`${r.branch}: not pushed - ${r.reason || "rebase conflicts: " + (r.conflicts || []).join(", ")}`, true); addSystem(`${r.branch} not pushed: ${r.reason || "rebase conflicts in " + (r.conflicts || []).join(", ") + ". " + (r.hint || "")}`); }
        }
        loadChat(S.chatId);
      },
      after: async () => {
        const r = await api(`/api/chats/${S.chatId}/branches`);
        $("#pb_list").innerHTML = (r.branches || []).map(b => `<div class="pbrow" data-slug="${esc(b.slug)}">
          <label class="brhead"><input type="checkbox" class="pb_on" value="${esc(b.slug)}" checked> <b>${esc(b.feature)}</b> <small>${esc(b.project)} · ${(b.commits || []).length} commit(s) · ${(b.changed || []).length} file(s) changed${b.pushed ? " · pushed " + esc(b.pushed.at) + " as " + esc(b.pushed.pushed_as || "") : ""}</small></label>
          <div class="row"><div style="flex:1"><label>Merge request target (branch is refreshed from ${esc(b.base)} first)</label><input class="pb_tgt" value="${esc(b.target || b.base)}"></div><div style="flex:3"><label>Files on the branch</label><div class="pushfiles" style="max-height:120px">${(b.changed || []).map(c => `<div class="pf"><span class="pf-path">${esc(c.path)}</span><small>${esc(c.status)}</small></div>`).join("") || "<span style='color:var(--muted)'>no commits yet - run first</span>"}</div></div></div></div>`).join("") || "<span style='color:var(--muted)'>no feature branch - create one with the Feature branch tool</span>";
      }
    },
    "files-drop": {
      title: "Files dropped - what are they?", badge: "b-skills", svg: "skills", sub: "Choose the input these files belong to.",
      body: `<div class="seg" id="fd_kind"><span class="on" data-v="skills">Skills</span><span data-v="standards">Standards</span><span data-v="story">Story</span></div><div id="fd_list" style="margin-top:10px;font-size:12.5px"></div>`,
      submit: async (ctx) => {
        const kind = $("#fd_kind .on").dataset.v;
        if (kind === "story") { const fd = new FormData(); fd.append("mode", "file"); fd.append("file", ctx.files[0]); const r = await api(`/api/chats/${S.chatId}/inputs/story`, { method: "POST", body: fd }); storyCard(r); return; }
        await uploadDocs(kind, ctx.files);
      },
      after: (ctx) => { $("#fd_list").innerHTML = Array.from(ctx.files).map(f => `• ${esc(f.name)} (${Math.round(f.size / 1024)} KB)`).join("<br>"); }
    },
  };
  function docModal(kind, title, badge, svg, sub) {
    return {
      title, badge, svg, sub: sub + " Accepted: md, yml, yaml, txt, csv, xls, xlsx, doc, docx, html" + (kind === "knowledge" ? ", zip (knowledge pack)." : "."),
      body: `<div class="drop" id="d_drop">drop files here or click to choose (multiple allowed)</div><input type="file" id="d_files" multiple style="display:none"><div id="d_list" style="margin-top:8px;font-size:12.5px"></div>`,
      submit: async () => { const fs = $("#d_files")._files || $("#d_files").files; if (!fs || !fs.length) throw new Error("choose at least one file"); await uploadDocs(kind, fs); },
      after: () => {
        const inp = $("#d_files"), drop = $("#d_drop");
        const show = fs => { inp._files = fs; $("#d_list").innerHTML = Array.from(fs).map(f => `• ${esc(f.name)}`).join("<br>"); };
        drop.onclick = () => inp.click(); inp.onchange = () => show(inp.files);
        drop.ondragover = e => { e.preventDefault(); drop.classList.add("over"); }; drop.ondragleave = () => drop.classList.remove("over");
        drop.ondrop = e => { e.preventDefault(); drop.classList.remove("over"); show(e.dataTransfer.files); };
      }
    };
  }
  async function uploadDocs(kind, files) {
    const fd = new FormData(); fd.append("kind", kind); Array.from(files).forEach(f => fd.append("files", f));
    let r0 = await api(`/api/chats/${S.chatId}/inputs/docs`, { method: "POST", body: fd });
    r0 = await waitTask(r0, p => progress("⏳ " + p));
    const r = Array.isArray(r0) ? r0 : (r0.documents || []);
    if (!Array.isArray(r0) && (r0.packs || []).length && Array.from(files).some(f => /\.zip$/i.test(f.name))) { const pk = r0.packs[r0.packs.length - 1]; toast(`knowledge pack ${pk.system} ${pk.version} attached`); inputCard("knowledge", `${pk.system.toUpperCase()} knowledge pack ${pk.version}: ${(pk.counts || {}).folders || 0} folders, ${(pk.counts || {}).tables_described || 0} tables, ${(pk.counts || {}).items || 0} indexed items, repository ${pk.repo_name} included`); }
    toast(`${r.length} ${kind} file(s) added`); inputCard(kind, r.map(d => d.name + " (" + d.chars + " chars)").join(", "));
  }

  // long inputs (repo download, table introspection, story from git) run as server tasks: poll with progress
  async function waitTask(r, onProgress) {
    if (!r || !r.task) return r;
    for (;;) {
      await new Promise(res => setTimeout(res, 1000));
      const t = await api(`api/tasks/${r.task}`);
      if (onProgress) onProgress(t.progress || "");
      if (t.status === "done") return t.result;
      if (t.status === "failed") throw new Error(t.error || "failed");
    }
  }
  const progress = msg => { const el = $("#modalProgress"); if (el) { el.textContent = msg; el.style.display = msg ? "" : "none"; } };
  function storyCard(r) { if (r && r.summary_text) addMessage("assistant", r.summary_text); }

  let modalCtx = null;
  function openModal(id, ctx) {
    const m = MODALS[id]; if (!m) return; modalCtx = ctx || {};
    $("#modal").innerHTML = `<h3><span class="badge ${m.badge}">${SVG[m.svg]}</span>${m.title}</h3><div class="sub">${m.sub}</div>${m.body}
      <div class="err" id="modalErr"></div><div id="modalProgress" style="display:none;margin-top:10px;color:var(--accent2);font-size:12.5px">⏳</div><div class="actions"><button id="modalCancel">cancel</button><button class="primary" id="modalOk">${m.ok || "Add"}</button></div>`;
    $("#modalBg").classList.add("open");
    $$(".seg").forEach(seg => seg.onclick = e => { if (e.target.tagName !== "SPAN") return; $$("span", seg).forEach(s => s.classList.remove("on")); e.target.classList.add("on");
      const v = e.target.dataset.v; $$("[data-mode]", $("#modal")).forEach(d => d.style.display = d.dataset.mode === v ? "" : "none"); });
    $("#modalCancel").onclick = closeModal;
    $("#modalOk").onclick = async () => { $("#modalOk").disabled = true; $("#modalOk").textContent = "working…"; $("#modalErr").textContent = ""; progress("⏳ working ...");
      try { await m.submit(modalCtx); closeModal(); loadChat(S.chatId); loadChats(); } catch (e) { $("#modalErr").textContent = e.message; progress(""); } finally { $("#modalOk").disabled = false; $("#modalOk").textContent = m.ok || "Add"; } };
    if (m.after) m.after(modalCtx);
  }
  function closeModal() { $("#modalBg").classList.remove("open"); }
  $("#modalBg").addEventListener("click", e => { if (e.target.id === "modalBg") closeModal(); });

  function showAgentInfo(id) {
    const info = { story_agent: "Turns the story into a structured requirement (goal, functional requirements, business rules, acceptance criteria, open questions).",
      knowledge_agent: "Reads the knowledge documents (skills, standards, glossary); extracts the definitions that matter and machine-checkable rules for the validator. With a knowledge pack the system's conventions, definitions and rules come pre-built (no model call) and only your extra documents are read.",
      data_agent: "Explains the Greenplum tables: grain, keys, joins, columns needed, data rules.", repo_agent: "Studies the repository: where the change belongs, patterns to imitate, files to modify, conventions.",
      planner_agent: "Produces the plan: files to create / modify with purpose and outline, steps, test plan, risks.", coder_agent: "Writes each file (parallel), fixes validator and reviewer findings, applies chat change requests.",
      reviewer_agent: "Independent review of all files against story, standards and data: findings with severity, requirement coverage, score, verdict.", change_agent: "Interprets a follow-up request in the chat and decides which files change." };
    const st = (S.state && S.state.events || []).filter(e => e.agent === id);
    const tk = S.state && S.state.summary && S.state.summary.tokens_by_agent && S.state.summary.tokens_by_agent[id];
    addSystem(`${id}: ${info[id] || ""}${st.length ? " - last: " + st[st.length - 1].title : ""}${tk ? " - tokens " + tk.total_tokens + " in " + tk.calls + " call(s)" : ""}`);
  }
  async function tool(id) {
    if (id === "run") return runNow("");
    if (id === "branch") return openModal("branch");
    if (id === "push") return openModal((S.state && S.state.branches && S.state.branches.length) ? "pushbranch" : "push");
    if (id === "zip") return window.open(`api/chats/${S.chatId}/download/zip`);
    if (id === "log") { showTab("log"); return; }
    if (id === "tokens") { showTab("tokens"); return; }
    if (id === "docs") { try { const r = await post(`/api/chats/${S.chatId}/docs`, { enabled: true }); toast(r.files.length ? "documentation written: " + r.files.join(", ") : "documentation will be written after the next run"); await loadChat(S.chatId); showTab("outputs"); } catch (e) { toast(e.message, true); } }
  }

  // ---------------------------------------------------------------- chats
  async function loadChats() {
    const rows = await api("/api/chats");
    $("#chatList").innerHTML = rows.map(c => `<div class="chat-item ${c.chat_id === S.chatId ? "active" : ""}" data-id="${c.chat_id}">
      <span class="st ${c.status || ""}"></span><span class="t" title="${esc(c.title)}">${esc(c.title || c.chat_id)}</span><span class="x" title="delete this chat">✕</span></div>`).join("") || `<div style="color:var(--muted);font-size:12px;padding:6px">no chats yet</div>`;
    $$(".chat-item").forEach(el => {
      el.onclick = e => { if (e.target.classList.contains("x")) return; openChat(el.dataset.id); };
      $(".x", el).onclick = async e => { e.stopPropagation(); if (!confirm("Delete this chat and all its inputs / outputs?")) return; await api(`/api/chats/${el.dataset.id}`, { method: "DELETE" }); if (S.chatId === el.dataset.id) { S.chatId = null; S.state = null; renderEmpty(); } loadChats(); };
    });
  }
  async function newChat() { const c = await post("/api/chats", {}); await loadChats(); openChat(c.chat_id); }
  function renderEmpty() {
    $("#chatTitle").textContent = "no chat"; setRunState(false);
    $("#chat").innerHTML = `<div class="welcome"><h2>Welcome to Agile Dev Assist</h2>Create a new chat, then drag the inputs into this window.<div class="drops">${INPUTS.map(i => `<span>${i.name}</span>`).join("")}</div></div>`;
    ["inputs", "plan", "review", "tokens", "outputs"].forEach(p => $("#pane-" + p).innerHTML = ""); $("#fileList").innerHTML = ""; $("#fileEditor").value = ""; $("#logText").textContent = ""; if ($("#logSummary")) $("#logSummary").innerHTML = "";
    $$(".icon.agent").forEach(a => a.classList.remove("busy", "done"));
    $("#plItems").innerHTML = "";
  }
  function resetPanels() {
    ["inputs", "plan", "review", "tokens", "outputs"].forEach(p => $("#pane-" + p).innerHTML = "");
    $("#fileList").innerHTML = ""; $("#fileEditor").value = ""; $("#fileDiff").innerHTML = ""; $("#fileName").textContent = "select a file"; $("#fileMeta").innerHTML = "";
    $("#btnDownloadFile").disabled = true; $("#btnViewCode").disabled = true; $("#btnViewDiff").disabled = true; $("#fileSaved").textContent = "";
    $("#logText").textContent = ""; $("#confPill").style.display = "none";
    ["nFiles", "nFind"].forEach(i => { $("#" + i).style.display = "none"; $("#" + i).textContent = "0"; });
    $$(".icon.agent").forEach(a => a.classList.remove("busy", "done")); $$(".icon.input .count").forEach(c => c.style.display = "none");
    $("#plItems").innerHTML = ""; S.file = null; S.state = null; S.counts = {};
  }
  async function openChat(id) {
    if (S.poll) clearInterval(S.poll);
    S.chatId = id; S.nextEvent = 0; $("#chat").innerHTML = ""; resetPanels();
    await loadChat(id); await loadChats();
    S.poll = setInterval(pollEvents, 1500);
  }
  async function loadChat(id) {
    const st = await api(`/api/chats/${id}`); S.state = st;
    $("#chatTitle").textContent = st.chat ? st.chat.title : id;
    renderMessages(st); renderInputs(st); renderPlan(st); renderFiles(st); renderReview(st); renderTokens(st); renderLogSummary(st); renderOutputs(st); renderPipeline();
    S.nextEvent = (st.events || []).length;
    setRunState(st.busy || st.running);
  }
  function setRunState(busy) { const el = $("#runState"); el.textContent = busy ? "⏳ working…" : ""; el.style.display = busy ? "" : "none"; el.className = "pill"; $("#btnSend").disabled = !!busy; $("#btnRun").disabled = !!busy; }

  // ---------------------------------------------------------------- chat rendering + live events
  function renderMessages(st) {
    const chat = $("#chat"); chat.innerHTML = "";
    if (!(st.messages || []).length && !(st.events || []).length) chat.innerHTML = `<div class="welcome"><h2>${esc(st.chat ? st.chat.title : "New chat")}</h2>Start from a system template on the left (IKG / ODM / NLG = the nightly knowledge pack with repository, tables, conventions and git branch rules), then drag the Story in. Extra knowledge documents (skills, standards, glossary), Greenplum tables or a live repository clone can be added on top. Drag agent icons to build the pipeline (order / remove). Then press Run or type instructions.<div class="drops">${INPUTS.map(i => `<span>${i.name}</span>`).join("")}</div></div>`;
    // interleave messages and milestone blocks by time
    const items = [...(st.messages || []).map(m => ({ t: m.ts || 0, m })), ...(st.events || []).map(e => ({ t: e.t || 0, e }))].sort((a, b) => a.t - b.t);
    for (const it of items) { if (it.m) { ms = null; addMessage(it.m.role, it.m.text, false, it.m.meta); } else mergeEvents([it.e]); }
    chat.scrollTop = chat.scrollHeight;
  }
  const CARD = { story: ["b-story", "story", "Story"], skills: ["b-skills", "skills", "Knowledge"], knowledge: ["b-skills", "skills", "Knowledge"], pack: ["b-skills", "skills", "Knowledge pack"], glossary: ["b-std", "std", "Glossary / data dictionary"],
    standards: ["b-skills", "skills", "Knowledge"], greenplum: ["b-gp", "gp", "Data (Greenplum)"], repo: ["b-git", "git", "Code repository"], publish: ["b-tool", "push", "Pushed"], template: ["b-std", "std", "Template"] };
  function inputCard(kind, text) {
    const w = $(".welcome", $("#chat")); if (w) w.remove();
    const [cls, svg, label] = CARD[kind];
    const body = text.replace(/^[a-z]+:\s*/i, "");
    const items = body.split(/,\s*(?![^()]*\))/).map(x => x.trim()).filter(Boolean);
    const el = document.createElement("div"); el.className = "msg input c-" + kind;
    el.innerHTML = `<div class="ih"><span class="badge ${cls}">${SVG[svg]}</span>${label}</div><div class="ib">${items.length > 1 ? items.map(x => `<span class="chip">${esc(x)}</span>`).join("") : esc(body)}</div>`;
    $("#chat").appendChild(el); return el;
  }
  function addMessage(role, text, scroll = true, meta) {
    if (role === "system" && meta && CARD[meta.kind]) { const el = inputCard(meta.kind, text); if (scroll) $("#chat").scrollTop = $("#chat").scrollHeight; return el; }
    const w = $(".welcome", $("#chat")); if (w) w.remove();
    const el = document.createElement("div"); el.className = "msg " + role; el.innerHTML = md(text);
    $("#chat").appendChild(el); if (scroll) $("#chat").scrollTop = $("#chat").scrollHeight; return el;
  }
  const addSystem = t => addMessage("system", t);
  let ms = null;   // current milestones block
  const STAGE_OF = { story_agent: ["story"], knowledge_agent: ["knowledge"], data_agent: ["data"], repo_agent: ["repo"], planner_agent: ["plan"],
    coder_agent: ["generate", "validate"], reviewer_agent: ["review", "fix"] };
  function stagesFor(pipeline) {
    if (!pipeline || !pipeline.length) return STAGES;
    const out = []; for (const a of pipeline) for (const st of (STAGE_OF[a] || [])) out.push(st);
    if (pipeline.includes("coder_agent") && !pipeline.includes("planner_agent")) out.splice(out.indexOf("generate"), 0, "plan");
    out.push("outputs"); return out;
  }
  function milestoneBlock(pipeline) {
    if (ms && ms.isConnected) return ms;
    ms = document.createElement("div"); ms.className = "milestones";
    ms.innerHTML = `<div style="display:flex;justify-content:space-between;font-size:12.5px"><b id="msTitle">starting…</b><span id="msPct">0%</span></div><div class="bar"><div id="msBar"></div></div>
      <div class="steps">${stagesFor(pipeline).map(s => `<span class="step" data-s="${s}">${s}</span>`).join("")}</div><div class="mini-log" id="msLog"></div>`;
    $("#chat").appendChild(ms); return ms;
  }
  const AGENT_OF_STAGE = { story: "story_agent", knowledge: "knowledge_agent", data: "data_agent", repo: "repo_agent", plan: "planner_agent", generate: "coder_agent", validate: "coder_agent", review: "reviewer_agent", fix: "coder_agent" };
  function setStep(b, stage, cls) { const el = $(`.step[data-s="${stage}"]`, b); if (!el) return; el.classList.remove("active", "done", "skipped", "failed"); el.classList.add(cls); }
  function mergeEvents(evs) {
    for (const e of evs) {
      if (e.type === "input") continue;                       // inputs are shown as cards (chat messages), never as a progress block
      if (e.type === "milestone" && (e.pct === 0 || e.title === "run started" || e.title === "change requested")) { ms = null; milestoneBlock(e.pipeline); }
      if (["milestone", "agent", "file", "result", "log", "error"].includes(e.type)) {
        const b = milestoneBlock(e.pipeline);
        if (e.type === "milestone") { $("#msTitle", b).textContent = e.title; if (e.pct != null) { $("#msPct", b).textContent = e.pct + "%"; $("#msBar", b).style.width = e.pct + "%"; }
          if (e.stage) { if (!e.parallel) $$(".step.active", b).forEach(s => { if (s.dataset.s !== e.stage && !["knowledge", "data", "repo"].includes(s.dataset.s)) { s.classList.remove("active"); s.classList.add("done"); } }); setStep(b, e.stage, "active");
            const ic = $("#ag-" + AGENT_OF_STAGE[e.stage]); if (ic) ic.classList.add("busy"); } }
        if (e.stage_done) { setStep(b, e.stage_done, e.type === "error" ? "failed" : "done"); const ic = $("#ag-" + AGENT_OF_STAGE[e.stage_done]); if (ic) { ic.classList.add("done"); ic.classList.remove("busy"); } }
        if (e.stage_skipped) setStep(b, e.stage_skipped, "skipped");
        if (e.kind === "done") $$(".step.active", b).forEach(s => { s.classList.remove("active"); s.classList.add("done"); });
        if (e.type === "agent" && e.agent) { const ic = $("#ag-" + e.agent); if (ic) { ic.classList.add("done"); ic.classList.remove("busy"); } }
        const line = document.createElement("div"); line.className = e.type === "error" ? "err" : ""; line.textContent = `${e.ts} ${e.title}${e.detail ? " — " + String(e.detail).slice(0, 160) : ""}`;
        const lg = $("#msLog", b); lg.appendChild(line); lg.scrollTop = lg.scrollHeight;
      }
    }
    $("#chat").scrollTop = $("#chat").scrollHeight;
  }
  async function pollEvents() {
    if (!S.chatId) return;
    try {
      const r = await api(`/api/chats/${S.chatId}/events?since=${S.nextEvent}`);
      if (r.events.length) { mergeEvents(r.events); S.nextEvent = r.next; if (($(".tab.active") || {}).dataset?.tab === "log") loadLog(); }
      const wasBusy = $("#btnSend").disabled; setRunState(r.busy || r.running);
      if (wasBusy && !(r.busy || r.running)) { await loadChat(S.chatId); loadChats(); $$(".icon.agent").forEach(a => a.classList.remove("busy")); }
      else if (r.events.some(e => e.type === "file" || e.type === "result")) { const st = await api(`/api/chats/${S.chatId}`); S.state = st; renderFiles(st); renderPlan(st); renderReview(st); renderInputs(st); }
    } catch (e) { /* transient */ }
  }

  // ---------------------------------------------------------------- send / run
  async function send() {
    const t = $("#composer").value.trim(); if (!t || !S.chatId) return;
    $("#composer").value = ""; addMessage("user", t); setRunState(true);
    try { const r = await post(`/api/chats/${S.chatId}/message`, { text: t }); if (r.reply) { addMessage("assistant", r.reply); setRunState(false); loadChat(S.chatId); } }
    catch (e) { toast(e.message, true); setRunState(false); }
  }
  async function runNow(instr) {
    if (!S.chatId) return; setRunState(true);
    const rp = $("#chkReplan"), replan = !!(rp && rp.checked);
    try { await post(`/api/chats/${S.chatId}/run`, { instructions: instr || "", replan }); addSystem(replan ? "Run started - a NEW plan will be made and stored for this story" : "Run started"); if (rp) rp.checked = false; }
    catch (e) {
      setRunState(false);
      if (/feature branch first/i.test(e.message)) { addSystem("A feature branch is required before the first run: every run is committed on it. Create it now (repository, base branch, branch name are prefilled from the story and template), then press Run again."); toast("create a feature branch first", true); S.pendingRun = instr || ""; openModal("branch"); return; }
      toast(e.message, true);
    }
  }
  $("#btnSend").onclick = send; $("#btnRun").onclick = () => runNow($("#composer").value.trim());
  $("#composer").addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } });
  $("#btnNewChat").onclick = newChat;
  $("#btnLogout").onclick = async () => { let r = {}; try { r = await post("auth/logout", {}); } catch (e) { /* signed out anyway */ } if (r && r.logout_url) location.href = r.logout_url; else location.reload(); };

  // ---------------------------------------------------------------- right panel
  function showTab(name) { $$(".tab").forEach(t => t.classList.toggle("active", t.dataset.tab === name)); $$(".pane").forEach(p => p.classList.toggle("active", p.id === "pane-" + name)); if (name === "log") loadLog(); }
  $$(".tab").forEach(t => t.onclick = () => showTab(t.dataset.tab));
  function renderInputs(st) {
    const i = st.inputs || {}; const n = k => (i[k] || []).length;
    const cnt = { story: i.story ? 1 : 0, knowledge: n("knowledge") + n("packs"), greenplum: n("tables") + n("queries"), repo: n("repos") };
    for (const [k, v] of Object.entries(cnt)) { const el = $("#cnt-" + k); if (el) { el.textContent = v; el.style.display = v ? "" : "none"; } }
    const chips = (arr, kind) => arr.map(d => `<span class="chip">${esc(d.name)} <small>${d.chars || ""}</small><span class="x" data-k="${kind}" data-n="${esc(d.name)}">✕</span></span>`).join("") || "<span style='color:var(--muted)'>none</span>";
    $("#pane-inputs").innerHTML = `
      <div class="box"><h4>Story</h4>${i.story ? `<b>${esc(i.story.id)}</b> ${esc(i.story.title)} <small style="color:var(--muted)">(${i.story.chars} chars, ${esc(i.story.source.type || "")})</small> <span class="chip"><span class="x" data-del="story">✕ remove</span></span>` : "<span style='color:var(--muted)'>not set - drag the Story icon into the chat</span>"}</div>
      <div class="box"><h4>Knowledge packs <small style="color:var(--muted);font-weight:400">pre-built, indexed knowledge of a system (nightly)</small></h4><div class="chips">${(i.packs || []).map(p => `<span class="chip pack" title="${esc(JSON.stringify(p.counts || {}))}">${esc(p.system.toUpperCase())} ${esc(p.version)} <small>${(p.counts || {}).folders || 0} folders · ${(p.counts || {}).tables_described || 0} tables · ${(p.counts || {}).conventions || 0} conventions · ${(p.counts || {}).items || 0} items · ${p.model_layer ? "model layer" : "facts only"} · ${p.dense_index ? "vectors" : "BM25"}</small><span class="x" data-del="pack" data-n="${esc(p.system)}">✕</span></span>`).join("") || "<span style='color:var(--muted)'>none - load an IKG / ODM / NLG template or drop a <code>*_pack.zip</code> on Knowledge</span>"}</div></div>
      <div class="box"><h4>Knowledge <small style="color:var(--muted);font-weight:400">skills, standards & conventions, glossary / data dictionary</small></h4><div class="chips">${chips(i.knowledge || [], "knowledge")}</div></div>
      <div class="box"><h4>Greenplum</h4><div class="chips">${(i.tables || []).map(t => `<span class="chip">${esc(t.schema)}.${esc(t.table)} <small>${t.columns} cols</small><span class="x" data-del="table" data-s="${esc(t.schema)}" data-n="${esc(t.table)}">✕</span></span>`).join("")}${(i.queries || []).map(q => `<span class="chip">query ${esc(q.name)} <small>${q.row_count} rows</small><span class="x" data-del="query" data-n="${esc(q.name)}">✕</span></span>`).join("")}${(i.tables || []).length || (i.queries || []).length ? "" : "<span style='color:var(--muted)'>none</span>"}</div></div>
      <div class="box"><h4>Repositories</h4><div class="chips">${(i.repos || []).map(r => `<span class="chip">${esc(r.name)}@${esc(r.branch)} <small>${r.files} files · ${Object.entries(r.languages).map(([k, v]) => k + " " + v).join(", ")}${r.from_pack ? " · from the " + esc(r.from_pack.toUpperCase()) + " pack" : ""}</small>${r.from_pack ? "" : `<span class="x" data-del="repo" data-n="${esc(r.name)}">✕</span>`}</span>`).join("") || "<span style='color:var(--muted)'>none</span>"}</div></div>
      ${i.git_defaults && (i.git_defaults.base_branch || i.git_defaults.mr_target) ? `<div class="box"><h4>Git conventions (from the template)</h4><div>system <b>${esc(i.git_defaults.system || "")}</b> · branch from <b>${esc(i.git_defaults.base_branch || "default")}</b> · name <code>${esc(i.git_defaults.branch_template || "")}</code> · merge request to <b>${esc(i.git_defaults.mr_target || i.git_defaults.base_branch || "")}</b></div></div>` : ""}
      <div class="box"><h4>Feature branches <small style="color:var(--muted);font-weight:400">this chat's checkouts; every run commits here</small></h4><div class="chips">${(i.branches || []).map(b => `<span class="chip" title="${esc(b.repo_url || "")}">${esc(b.feature)} <small>${esc(b.project || "")} · from ${esc(b.base)} → ${esc(b.target)} · ${(b.commits || []).length} commit(s)${b.pushed ? " · pushed as " + esc(b.pushed.pushed_as || "") + (b.pushed.mr_iid ? " · MR !" + esc(String(b.pushed.mr_iid)) : "") : " · local"}</small><span class="x" data-del="branch" data-n="${esc(b.slug)}">✕</span></span>`).join("") || "<span style='color:var(--muted)'>none - use the Feature branch tool (checkout from ikg-master / odm-master / nlg-master)</span>"}</div></div>
      <div class="box"><h4>Instructions given</h4>${(i.instructions || []).map(x => `<div>• ${esc(x)}</div>`).join("") || "<span style='color:var(--muted)'>none</span>"}</div>`;
    $$("#pane-inputs .chip .x").forEach(x => x.onclick = async () => {
      const d = x.dataset, c = S.chatId;
      try {
        if (d.k) await api(`/api/chats/${c}/inputs/docs/${d.k}/${encodeURIComponent(d.n)}`, { method: "DELETE" });
        else if (d.del === "story") { if (!confirm("Remove the story from this chat?")) return; await api(`/api/chats/${c}/inputs/story`, { method: "DELETE" }); }
        else if (d.del === "table") await api(`/api/chats/${c}/inputs/table/${encodeURIComponent(d.s)}/${encodeURIComponent(d.n)}`, { method: "DELETE" });
        else if (d.del === "query") await api(`/api/chats/${c}/inputs/query/${encodeURIComponent(d.n)}`, { method: "DELETE" });
        else if (d.del === "repo") await api(`/api/chats/${c}/inputs/repo/${encodeURIComponent(d.n)}`, { method: "DELETE" });
        else if (d.del === "branch") { if (!confirm("Remove this feature branch from the chat? (the remote branch, if pushed, stays)")) return; await api(`/api/chats/${c}/branches/${encodeURIComponent(d.n)}`, { method: "DELETE" }); }
        else if (d.del === "pack") { if (!confirm("Remove the " + d.n.toUpperCase() + " knowledge pack (and its repository copy / tables) from this chat?")) return; await api(`/api/chats/${c}/inputs/pack/${encodeURIComponent(d.n)}`, { method: "DELETE" }); }
        toast("removed"); loadChat(c);
      } catch (e) { toast(e.message, true); }
    });
  }
  function renderPlan(st) {
    const p = st.plan || {};
    if (!p.files) { $("#pane-plan").innerHTML = "<div class='box' style='color:var(--muted)'>no plan yet</div>"; return; }
    const src = st.sources || {}; const ag = st.agent_outputs || [];
    const agLink = n => `<span class="aglink"><b>${esc(n.replace("_agent", ""))}</b> <a href="api/chats/${S.chatId}/agent/${n}.json" target="_blank" title="view the JSON in a new browser tab">view</a> · <a href="api/chats/${S.chatId}/agent/${n}.json?download=1" download title="download the JSON file">download</a></span>`;
    const li = arr => (arr || []).map(x => `<li>${esc(typeof x === "string" ? x : (x.ref || x.path || x.name || x.table || JSON.stringify(x)))}${x.agents ? ` <small>(${x.agents.map(a => a.replace("_agent", "")).join(", ")})</small>` : ""}${x.repo && x.path ? ` <small>${esc(x.repo)}</small>` : ""}</li>`).join("");
    const docs = src.documents || {};
    $("#pane-plan").innerHTML = `<div class="box"><h4>Approach</h4>${esc(p.approach)}</div>
      <div class="box"><h4>Files (${p.files.length})</h4>${p.files.map(f => `<div class="pf-row"><b>${esc(f.action)}</b> <code>${esc(f.path)}</code> <small>[${esc(f.language)}]</small><div style="color:var(--muted);font-size:12px">${esc(f.purpose)}</div></div>`).join("")}</div>
      ${(p.questions || []).length ? `<div class="box"><h4>Open questions</h4><ul>${p.questions.map(q => `<li>${esc(q)}</li>`).join("")}</ul></div>` : ""}
      ${(p.notes || []).length ? `<div class="box"><h4>Adjustments made to the plan</h4><ul>${p.notes.map(q => `<li>${esc(q)}</li>`).join("")}</ul></div>` : ""}
      ${Object.keys(src).length ? `<div class="box"><h4>Sources used for this code</h4>
        <div class="legend" style="margin-bottom:6px"><b>used by</b> = the agents that read it · <b>how</b> = context pack (retrieved once by a reader agent and given to planner / coder / reviewer), look-up (an agent fetched it with a tool during its work), BM25 = exact keyword retrieval, embeddings = search by meaning</div>
        <table class="tk src"><tr><th>source</th><th>kind</th><th>used by</th><th>how</th><th>what was taken</th></tr>
        ${src.story ? `<tr><td>${esc(src.story.id || "")} ${esc(src.story.title || "")}<br><small>${esc((src.story.source || {}).type || "")} ${esc((src.story.source || {}).url || (src.story.source || {}).name || "")}</small></td><td>story</td><td>story → all</td><td>context pack (story agent)</td><td>${esc(src.story.extracted || "")}</td></tr>` : ""}
        ${(src.packs || []).map(p => `<tr><td><b>${esc((p.system || "").toUpperCase())} knowledge pack</b> ${esc(p.version || "")}<br><small>built ${esc(String(p.built_at || "").slice(0, 16))} · repo ${esc(p.repo || "")} · ${p.dense_index ? "vectors" : "BM25"}</small></td><td>knowledge pack</td><td>${(p.used_by || []).join(", ")}</td><td>${esc(p.process || "")}</td><td>${esc(p.extracted || "")}</td></tr>`).join("")}
        ${(src.pack_lookups || []).map(x => `<tr><td><code>${esc(x.ref)}</code></td><td>pack look-up</td><td>${(x.agents || []).join(", ")}</td><td>look-up in the knowledge pack (exact, no model call)</td><td>folder / table / DAG facts, companion rules, exemplar, impact</td></tr>`).join("")}
        ${(src.documents || []).map(d => `<tr><td><code>${esc(d.name)}</code><br><small>${d.chars || ""} chars</small></td><td>${esc(d.kind)}</td><td>${(d.used_by || ["knowledge"]).join(", ")}</td><td>${esc(d.process || "context pack (knowledge agent)")}</td><td>${esc(d.extracted)}</td></tr>`).join("")}
        ${(src.tables || []).map(t => `<tr><td><code>${esc(t.table)}</code></td><td>data table</td><td>${(t.used_by || ["data"]).join(", ")}</td><td>${esc(t.process || "context pack (data agent)")}</td><td>${esc(t.extracted)}</td></tr>`).join("")}
        ${(src.queries || []).map(q => `<tr><td><code>${esc(q.name)}</code></td><td>query</td><td>data</td><td>context pack (data agent)</td><td>${esc(q.extracted)}</td></tr>`).join("")}
        ${(src.repositories || []).map(r => `<tr><td><code>${esc(r.name)}@${esc(r.branch || "")}</code><br><small>${esc(r.url || "")}</small></td><td>code repository</td><td>repo, planner, coder, reviewer</td><td>BM25 index${(src.semantic_index || {}).enabled ? " + embeddings" : ""} · look-ups (search_repo, read_file)</td><td>${esc(r.extracted || "")}</td></tr>`).join("")}
        ${(src.repository_files || []).map(f => `<tr><td><a href="#" class="openfile" data-p="${esc(f.path)}"><code>${esc(f.path)}</code></a></td><td>repository file</td><td>${(f.used_by || ["repo"]).join(", ")}</td><td>${esc(f.process || "")}</td><td>${f.roles.map(esc).join(" · ")}</td></tr>`).join("")}
        ${(src.glossary_terms_looked_up || []).map(x => `<tr><td><code>${esc(x.ref)}</code></td><td>term</td><td>${(x.agents || []).join(", ")}</td><td>look-up (define_term)</td><td>glossary / standards definition</td></tr>`).join("")}
        ${(src.semantic_searches || []).map(x => `<tr><td>"${esc(x.ref)}"</td><td>phrase</td><td>${(x.agents || []).join(", ")}</td><td>embeddings (search by meaning)</td><td>candidates confirmed against the exact index</td></tr>`).join("")}
        ${(src.user_instructions || []).map(x => `<tr><td>${esc(x)}</td><td>instruction</td><td>all</td><td>context pack</td><td>typed in the chat</td></tr>`).join("")}
        </table>
        ${(src.repository_searches || []).length ? `<details><summary>Repository searches (${src.repository_searches.length})</summary><div class="ext">${src.repository_searches.map(x => esc(x.ref) + " <small>(" + (x.agents || []).join(", ") + ")</small>").join(" · ")}</div></details>` : ""}
        ${(src.knowledge_sections_read || []).length ? `<details><summary>Skills / standards sections read (${src.knowledge_sections_read.length})</summary><div class="ext">${src.knowledge_sections_read.map(x => esc(x.ref)).join(", ")}</div></details>` : ""}
        </div>` : ""}
      ${ag.length ? `<div class="box"><h4>Agent outputs (JSON)</h4><div class="aglinks">${ag.map(agLink).join("")}</div></div>` : ""}
      <div class="row"><a class="btn" href="api/chats/${S.chatId}/download/plan" download>download full plan.json (steps, test plan, risks)</a></div>`;
  }
  function renderFiles(st) {
    const files = st.files || []; $("#nFiles").textContent = files.length; $("#nFiles").style.display = files.length ? "" : "none";
    $("#fileList").innerHTML = files.map(f => `<div class="${S.file === f.path ? "active" : ""}" data-p="${esc(f.path)}" title="${esc(f.purpose)}">${esc(f.path.split("/").pop())}<br><span class="lang">${esc(f.language)} · ${esc(f.action)} · ${f.confidence || 0}%${f.unsafe ? " · ⚠ not changed" : ""}</span></div>`).join("");
    $$("#fileList div").forEach(el => el.onclick = () => openFile(el.dataset.p));
    if (S.file && !files.some(f => f.path === S.file)) { S.file = null; $("#fileEditor").value = ""; }
    if (!S.file && files.length) openFile(files[0].path);
  }
  async function openFile(p) {
    const f = await api(`/api/chats/${S.chatId}/files/${p}`); S.file = p;
    $$("#fileList div").forEach(el => el.classList.toggle("active", el.dataset.p === p));
    $("#fileName").textContent = p; $("#fileEditor").value = f.content; $("#fileSaved").textContent = "edits save automatically"; $("#btnDownloadFile").disabled = false;
    $("#btnViewCode").disabled = false; $("#btnViewDiff").disabled = false; S.diffShown = false; setFileView(false);
    $("#fileMeta").innerHTML = `<b>${esc(f.language)}</b> · ${esc(f.action)} · confidence ${f.confidence}% · ${esc(f.purpose)}<br>${esc(f.explanation || "")}${(f.assumptions || []).length ? "<br>assumptions: " + f.assumptions.map(esc).join("; ") : ""}`;
  }
  function setFileView(diff) {
    $("#fileEditor").style.display = diff ? "none" : ""; $("#fileDiff").style.display = diff ? "" : "none";
    $("#btnViewCode").classList.toggle("active", !diff); $("#btnViewDiff").classList.toggle("active", diff);
  }
  $("#btnViewCode").onclick = () => setFileView(false);
  $("#btnViewDiff").onclick = async () => {
    const d = await api(`/api/chats/${S.chatId}/diff/${S.file}`);
    const cls = l => l.startsWith("+++") || l.startsWith("---") ? "meta" : l.startsWith("@@") ? "hunk" : l.startsWith("+") ? "add" : l.startsWith("-") ? "del" : "ctx";
    $("#fileDiff").innerHTML = (d.new_file ? `<span class="meta">new file (${d.added} lines)</span>` : `<span class="meta">${d.added} added · ${d.removed} removed vs repository</span>`)
      + d.diff.split("\n").map(l => `<span class="${cls(l)}">${esc(l)}</span>`).join("");
    setFileView(true);
  };
  let saveTimer = null;
  async function autosaveFile() {
    if (!S.file || !S.chatId) return;
    try { const r = await api(`/api/chats/${S.chatId}/files/${S.file}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ content: $("#fileEditor").value }) });
      $("#fileSaved").textContent = `saved ${new Date().toLocaleTimeString()} · ${r.findings.length} finding(s)`; const st = await api(`/api/chats/${S.chatId}`); S.state = st; renderReview(st); }
    catch (e) { $("#fileSaved").textContent = "not saved: " + e.message; }
  }
  $("#fileEditor").addEventListener("input", () => { $("#fileSaved").textContent = "editing…"; clearTimeout(saveTimer); saveTimer = setTimeout(autosaveFile, 1200); });
  $("#fileEditor").addEventListener("blur", () => { if ($("#fileSaved").textContent === "editing…") { clearTimeout(saveTimer); autosaveFile(); } });
  $("#btnDownloadFile").onclick = () => { const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([$("#fileEditor").value])); a.download = S.file.split("/").pop(); a.click(); };
  $("#pane-review").addEventListener("click", e => { const a = e.target.closest("a.openfile"); if (a) { e.preventDefault(); if (a.dataset.p) { showTab("files"); openFile(a.dataset.p); } } });
  $("#pane-plan").addEventListener("click", e => { const a = e.target.closest("a.openfile"); if (a) { e.preventDefault(); const p = a.dataset.p; if ((S.state.files || []).some(f => f.path === p)) { showTab("files"); openFile(p); } else toast("repository file (not generated) - open it in the repository"); } });
  function renderReview(st) {
    const r = st.review || {}, f = st.findings || [], s = st.summary || {};
    { const cp = $("#confPill"), cc = s.confidence || {}; if (cc.score != null) { cp.textContent = `confidence ${cc.score} · ${cc.grade}`; cp.className = "pill conf " + (cc.grade || "").toLowerCase(); cp.style.display = ""; } else { cp.style.display = "none"; } }
    const all = [...(r.findings || []).map(x => ({ ...x, from: "reviewer" })), ...f.map(x => ({ ...x, from: "validator" }))];
    $("#nFind").textContent = all.length; $("#nFind").style.display = all.length ? "" : "none";
    if (!s.files) { $("#pane-review").innerHTML = "<div class='box' style='color:var(--muted)'>no run yet</div>"; return; }
    const c = s.confidence || {};
    const confBox = c.score != null ? `<div class="box conf ${(c.grade || "").toLowerCase()}"><div class="row" style="align-items:center;gap:16px"><div><div class="score big">${c.score}</div><small>confidence · ${esc(c.grade)}</small></div>
        <div style="flex:1;font-size:12px"><div><b>how it is built:</b> ${esc(c.explain || "")}</div>
        ${(c.to_raise || []).length ? `<div style="margin-top:4px"><b>to raise it:</b> ${c.to_raise.map(esc).join("; ")}</div>` : ""}
        ${(c.blocking || []).length ? `<ul class="blocklist">${c.blocking.map(b => `<li><span class="sev ${esc(b.severity)}">${esc(b.severity)}</span> <a href="#" class="openfile" data-p="${esc(b.path || "")}">${esc(b.path || "?")}</a>${b.line ? ` <small>line ${b.line}</small>` : ""} <small>(${esc(b.from)})</small><br>${esc(b.message || "")}${b.suggestion ? `<br><i>→ ${esc(b.suggestion)}</i>` : ""}</li>`).join("")}</ul>` : ""}
        </div></div></div>` : "";
    $("#pane-review").innerHTML = confBox + `<div class="box"><div class="row" style="align-items:center;gap:24px;margin-bottom:8px"><h4 style="margin:0">Findings (${all.length})</h4>
        <div><span class="score" style="font-size:20px">${s.quality_score ?? "-"}</span> <small>validator quality</small></div>
        <div><span class="score" style="font-size:20px">${r.score ?? "-"}</span> <small>reviewer score · ${esc(r.verdict || "no review")}</small></div></div>
        ${r.skipped ? `<div style="color:var(--warn,#e6a23c);margin-bottom:6px">review skipped: ${esc(r.skipped)}</div>` : ""}
        ${r.summary ? `<div style="margin-bottom:6px">${esc(r.summary)}</div>` : ""}
        <div class="legend"><b>severity</b> critical = wrong result / breaks / unregistered script · high = requirement missed or convention violated · medium = quality · low = style · info<br>
        <b>status</b> <span class="st fixed">fixed</span> = sent back to the coder and regenerated, validator re-run · <span class="st open">open</span> = still in the code - fix by hand or ask in the chat · <span class="st suggestion">suggestion</span> = medium / low reviewer advice, not applied automatically · validator findings are always the current state of the files</div>
        ${(() => {
          const SEV = { critical: 0, high: 1, medium: 2, low: 3, info: 4 };
          const bySev = (a, b) => (SEV[a.severity] ?? 9) - (SEV[b.severity] ?? 9) || String(a.path || "").localeCompare(String(b.path || ""));
          const withSt = all.map(x => ({ ...x, st: x.from === "validator" ? "open" : (x.status || "open") }));
          const groups = [["open", "Open - still in the code", withSt.filter(x => x.st === "open" && !x.pre_existing)], ["fixed", "Fixed - regenerated and re-validated", withSt.filter(x => x.st === "fixed")], ["suggestion", "Suggestions - not applied automatically", withSt.filter(x => x.st !== "open" && x.st !== "fixed" && !x.pre_existing)], ["suggestion", "Pre-existing - already so in the repository file, not introduced by this change (never blocks)", withSt.filter(x => x.pre_existing)]];
          return groups.filter(g => g[2].length).map(([k, title, items]) => `<h4 style="margin:10px 0 4px"><span class="st ${k}">${k}</span> ${title} <small style="color:var(--muted);font-weight:400">(${items.length}: ${["critical", "high", "medium", "low"].map(sv => items.filter(i => i.severity === sv).length + " " + sv).filter(t => !t.startsWith("0 ")).join(", ") || "info"})</small></h4>` + items.sort(bySev).map(x => { const st = x.st; return `<div class="finding ${st}"><span class="sev ${x.severity}">${esc(x.severity)}</span><div><b><a href="#" class="openfile" data-p="${esc(x.path || "")}">${esc(x.path)}</a></b>${x.line ? ":" + x.line : ""} <small>(${esc(x.kind || "")}, ${x.from})</small> <span class="st ${st}">${st}</span><br>${esc(x.message)}${x.suggestion ? "<br><i>" + esc(x.suggestion) + "</i>" : ""}${x.fixed_by ? `<br><small style="color:var(--muted)">${esc(x.fixed_by)}</small>` : ""}</div></div>`; }).join("")).join("") || "<span style='color:var(--muted)'>none</span>";
        })()}</div>`;
  }
  function renderLogSummary(st) {
    const s = st.summary || {}, t = s.timings, box = $("#logSummary"); if (!box) return;
    if (!t) { box.innerHTML = ""; return; }
    const ag = n => esc(String(n).replace("_agent", ""));
    box.innerHTML = `<div class="box"><div class="row" style="gap:24px;align-items:flex-start;flex-wrap:wrap">
        <div><h4 style="margin:0 0 4px">Stages · ${fmtSecs(t.total_seconds)} total</h4><table class="tk"><tr><th>stage</th><th>time</th></tr>${(t.stages || []).map(x => `<tr><td>${esc(x.stage)}</td><td>${fmtSecs(x.seconds)}</td></tr>`).join("")}</table></div>
        <div><h4 style="margin:0 0 4px">Agents</h4><table class="tk"><tr><th>agent</th><th>tasks</th><th>time</th><th title="time spent in deterministic grounding checks (code, no model)">of which checks</th><th>steps</th><th>re-plans</th><th>cached</th></tr>${(t.agents || []).map(a => `<tr><td>${ag(a.agent)}</td><td>${a.tasks}</td><td>${fmtSecs(a.seconds)}</td><td>${fmtSecs(a.grounding_seconds || 0)}</td><td>${a.steps}</td><td>${a.fix_rounds || 0}</td><td>${a.cached ? a.cached + " ✓" : ""}</td></tr>`).join("")}</table></div>
        <div><h4 style="margin:0 0 4px">Slowest tasks</h4><table class="tk"><tr><th>task</th><th>time</th><th>steps</th></tr>${(t.slowest_tasks || []).map(x => `<tr><td>${ag(x.agent)} · ${esc(x.task)}</td><td>${fmtSecs(x.seconds)}</td><td>${x.steps}${x.fix_rounds ? " (+" + x.fix_rounds + " re-plan)" : ""}</td></tr>`).join("")}</table></div></div>
      ${(s.recommendations || []).length ? `<h4 style="margin:10px 0 4px">Faster and cheaper next time</h4><ul style="margin:0;padding-left:18px">${s.recommendations.map(r => `<li>${esc(r)}</li>`).join("")}</ul>` : ""}</div>`;
  }
  (function logSplitter() {                       // drag the bar between the stage summary and the log text to give either more room
    const bar = $("#logSplit"), top = $("#logSummary"); if (!bar || !top) return;
    let y0 = 0, h0 = 0;
    const move = e => { const h = Math.max(60, h0 + (e.clientY - y0)); top.style.maxHeight = h + "px"; top.style.height = h + "px"; };
    const up = () => { document.removeEventListener("mousemove", move); document.removeEventListener("mouseup", up); };
    bar.onmousedown = e => { y0 = e.clientY; h0 = top.getBoundingClientRect().height; document.addEventListener("mousemove", move); document.addEventListener("mouseup", up); e.preventDefault(); };
  })();
  async function loadLog() { if (!S.chatId) return; $("#logText").textContent = await api(`/api/chats/${S.chatId}/text/log`); $("#dlLog").href = `api/chats/${S.chatId}/download/log`; $("#logText").scrollTop = $("#logText").scrollHeight; }
  $("#btnRefreshLog").onclick = loadLog;
  function renderTokens(st) {
    const s = st.summary || {}; const t = s.tokens, by = s.tokens_by_agent || {};
    if (!t) { $("#pane-tokens").innerHTML = "<div class='box' style='color:var(--muted)'>no run yet</div>"; return; }
    const pr = (s.tokens_pricing || (st.summary || {}).pricing || {}); const fmt = n => (n || 0).toLocaleString(); const usd = n => "$" + (n || 0).toFixed(3);
    const row = (k, v) => `<tr><td>${esc(k)}</td><td>${v.calls}</td><td>${fmt(v.input_tokens)}</td><td>${fmt(v.cached_input_tokens)}</td><td>${fmt(v.output_tokens)}</td><td><b>${fmt(v.total_tokens)}</b></td><td><b>${usd(v.cost_usd)}</b></td><td>${fmtSecs(v.seconds_in_calls)}</td></tr>`;
    $("#pane-tokens").innerHTML = `<div class="box row" style="gap:28px"><div><div class="score">${usd(t.cost_usd)}</div><small>cost of this run</small></div>
        <div><div class="score" style="font-size:22px">${fmt(t.input_tokens)}</div><small>input tokens (uncached) · ${usd(t.cost_input)}</small></div>
        <div><div class="score" style="font-size:22px">${fmt(t.cached_input_tokens)}</div><small>cached input tokens · ${usd(t.cost_cached_input)}</small></div>
        <div><div class="score" style="font-size:22px">${fmt(t.output_tokens)}</div><small>output tokens incl. ${fmt(t.reasoning_tokens)} reasoning · ${usd(t.cost_output)}</small></div></div>
      <div class="box"><table class="tk"><tr><th>agent</th><th>calls</th><th>input</th><th>cached</th><th>output</th><th>total</th><th>cost</th><th>time</th></tr>${Object.entries(by).sort((a, b) => b[1].total_tokens - a[1].total_tokens).map(([k, v]) => row(k, v)).join("")}${row("TOTAL", t)}</table>
        <div style="font-size:11px;color:var(--muted);margin-top:6px">${t.calls} calls · ${t.cache_hits} result-cache hits · ${t.rate_limit_hits || 0} rate-limit hits · ${fmtSecs(s.duration_seconds)} · prices per 1M tokens: input $${(st.summary || {}).pricing ? "" : ""}${pr.input ?? 1.25}, cached $${pr.cached_input ?? 0.125}, output $${pr.output ?? 10} (llm.pricing_per_1m in the config)</div></div>
      ${(() => {
        const bm = s.tokens_by_model || {}; const ks = Object.keys(bm);
        if (!ks.length) return "";
        const usd4 = n => "$" + (n || 0).toFixed(4);
        const rows = ks.sort((a, b) => (bm[b].cost_usd || 0) - (bm[a].cost_usd || 0)).map(k => { const m = bm[k]; const p = m.pricing || {};
          const price = m.kind === "embeddings" ? `$${p.input}/1M` : `in $${p.input} · cached $${p.cached_input} · out $${p.output} /1M`;
          return `<tr><td><b>${esc(m.label || k)}</b><br><small style="color:var(--muted)">deployment ${esc(k)}</small></td><td>${m.calls}</td><td>${fmt(m.input_tokens)}</td><td>${fmt(m.cached_input_tokens)}</td><td>${fmt(m.output_tokens)}${m.reasoning_tokens ? `<br><small style="color:var(--muted)">${fmt(m.reasoning_tokens)} reasoning</small>` : ""}</td><td>${usd4(m.cost_input)}</td><td>${usd4(m.cost_cached_input)}</td><td>${usd4(m.cost_output)}</td><td><b>${usd4(m.cost_usd)}</b></td><td><small>${esc((m.agents || []).join(", "))}</small></td><td><small style="color:var(--muted)">${price}</small></td></tr>`; }).join("");
        const tot = ks.reduce((a, k) => a + (bm[k].cost_usd || 0), 0);
        return `<details class="box bymodel"><summary><b>Cost and tokens by model</b> <small style="color:var(--muted)">(${ks.length} model${ks.length > 1 ? "s" : ""} · ${usd4(tot)} - click to expand)</small></summary>
          <table class="tk" style="margin-top:8px"><tr><th>model</th><th>calls</th><th>input</th><th>cached</th><th>output</th><th>input $</th><th>cached $</th><th>output $</th><th>cost</th><th>used by</th><th>price</th></tr>${rows}</table>
          <div style="font-size:11px;color:var(--muted);margin-top:6px">Each model is priced at its own rate (llm.pricing_per_1m_by_deployment in the config): the readers and mechanical fixes run on GPT-4o mini, the planner, coder and reviewer on GPT-5, search by meaning on the embedding model. The agent table above is priced the same way.</div></details>`;
      })()}
      <div class="box legend" style="font-size:12px;line-height:1.5"><h4>What the numbers mean</h4>
        <b>Input tokens</b> = everything sent <i>to</i> the model: the agent's instructions, the story, the extracted knowledge / data / repository context, the tool results it read, and - on every step of an agent - the whole conversation so far. One agent step = one call, so an agent that takes 6 steps sends its context 6 times.<br>
        <b>Cached input tokens</b> = the part of that input which was identical to a prompt the model had already seen in the last few minutes (Azure prompt caching). The same system prompt, the same shared coder context and the first part of a growing conversation are repeated on every step, so most of the input is served from the cache at 1/10 of the price. A high cached share is good: it is repetition that was <i>not</i> paid in full.<br>
        <b>Output tokens</b> = what the model wrote: the plan, the generated files, the review, and its hidden reasoning (counted and billed as output).<br>
        <b>0 calls for story / data / knowledge / repo</b> = their result was reused from the result cache (same inputs as a previous run - see "result reused from cache" in the Log), so no model call was made and nothing was billed. The planner, coder and reviewer always run, because their result depends on the current plan and code.<br>
        <b>embeddings row</b> (only when embeddings.enabled) = texts embedded for the search-by-meaning index: files, tables, columns, glossary rows and document paragraphs, billed at the embedding price and cached by text hash, so a second story on the same inputs embeds only the query.<br>
        <b>Where the tokens go</b>: the planner (reads everything, loops until the plan is grounded), the coder (one call per file, sharing one cached context), the reviewer (reads all generated files and diffs) and the fix passes (coder again for each finding). Fewer planner rounds and fewer review fixes = fewer tokens.</div>
      <div class="row"><a class="btn" href="api/chats/${S.chatId}/download/tokens" download>download tokens.txt</a></div>`;
  }
  function renderOutputs(st) {
    const s = st.summary || {}; const has = (st.files || []).length;
    const dl = (w, l) => `<a class="btn" href="api/chats/${S.chatId}/download/${w}" download>${l}</a>`;
    $("#pane-outputs").innerHTML = `<div class="box"><h4>Downloads</h4><div class="row">${has ? dl("zip", "⬇ zip (all files + plan, review, log, tokens)") : "<span style='color:var(--muted)'>run first</span>"} ${dl("log", "log.txt")} ${dl("plan", "plan.json")} ${dl("tokens", "tokens.txt")} ${dl("review", "review.json")} ${dl("findings", "findings.json")} ${dl("pack", "context pack")} ${dl("inputs", "inputs.json")} ${dl("summary", "run_summary.json")}</div></div>
      <div class="box"><h4>Git branch</h4><div style="font-size:12.5px;color:var(--muted);margin-bottom:8px">Choose the files, the repository and the branch; the commit is made with your token (your name on the commit). Push several times to send files to different repositories.</div><button class="primary" id="btnPush" ${has ? "" : "disabled"}>Push a branch…</button>
        ${Object.keys(st.pushed || {}).length ? `<div style="margin-top:8px;font-size:12px"><b>pushed so far</b><ul style="margin:4px 0 0 16px">${Object.entries(st.pushed).map(([p, hs]) => `<li><code>${esc(p)}</code> → ${hs.map(h => `<a href="${esc(h.url)}" target="_blank">${esc(h.project)}@${esc(h.branch)}</a>`).join(", ")}</li>`).join("")}</ul>
        ${(st.files || []).filter(f => !(st.pushed || {})[f.path]).length ? `<div style="color:var(--warn);margin-top:4px">not pushed yet: ${(st.files || []).filter(f => !(st.pushed || {})[f.path]).map(f => esc(f.path.split("/").pop())).join(", ")}</div>` : ""}</div>` : ""}</div>
      <div class="box"><h4>Savepoints</h4><div style="font-size:12.5px;color:var(--muted);margin-bottom:6px">A named snapshot of the generated code (zip). One is saved automatically after every run; save your own before asking for changes. In the chat: "save as savepoint-2", "revert to savepoint-1", "list savepoints".</div>
        <div class="row"><button id="btnSavepoint" ${has ? "" : "disabled"}>＋ save point</button></div>
        ${(st.savepoints || []).length ? `<table class="sptable"><tr><th>name</th><th>when</th><th>files</th><th>confidence</th><th></th></tr>${[...st.savepoints].reverse().map(sp => `<tr><td><b>${esc(sp.name)}</b>${sp.note ? `<br><small>${esc(sp.note)}</small>` : ""}</td><td><small>${esc(sp.created)}</small></td><td>${sp.files.length}</td><td>${sp.confidence ?? "-"}</td><td><a class="btn" href="api/chats/${S.chatId}/savepoints/${encodeURIComponent(sp.name)}/download" download>zip</a> <button class="sp-restore" data-n="${esc(sp.name)}">revert to this</button></td></tr>`).join("")}</table>` : ""}</div>
      ${s.files ? `<div class="box"><h4>Last run</h4><div class="kv"><b>finished</b><span>${esc(s.finished)}</span><b>duration</b><span>${fmtSecs(s.duration_seconds)}</span><b>files</b><span>${s.files.length}</span><b>confidence</b><span>${(s.confidence || {}).score ?? "-"} ${esc((s.confidence || {}).grade || "")}</span><b>quality</b><span>${s.quality_score}</span><b>review</b><span>${esc((s.review || {}).verdict || "")} ${(s.review || {}).score || ""}</span><b>tokens</b><span>${(s.tokens || {}).total_tokens}</span></div></div>` : ""}
      <div class="box"><h4>Documentation (optional)</h4><div style="color:var(--muted);font-size:12.5px;margin-bottom:6px">One-pager (docx) and slides (pptx) for non-technical readers.</div>
        <div class="row">${(st.docs || []).map(d => `<a class="btn" href="api/chats/${S.chatId}/docfile/${encodeURIComponent(d.split("/").pop())}" download>${esc(d.split("/").pop())}</a>`).join("")}<button id="btnDocs" ${has ? "" : "disabled"}>Generate docx + pptx</button></div></div>`;
    const bd = $("#btnDocs"); if (bd) bd.onclick = () => tool("docs");
    const b = $("#btnPush"); if (b) b.onclick = () => tool("push");
    const sb = $("#btnSavepoint"); if (sb) sb.onclick = async () => { const n = prompt("Savepoint name (leave empty for savepoint-N):", ""); if (n === null) return; try { const r = await post(`/api/chats/${S.chatId}/savepoints`, { name: n }); toast(`savepoint ${r.name} saved`); loadChat(S.chatId); } catch (e) { toast(e.message, true); } };
    $$(".sp-restore").forEach(x => x.onclick = async () => { if (!confirm(`Revert the generated code to savepoint "${x.dataset.n}"? (the current state is kept as a before-restore savepoint)`)) return; try { await post(`/api/chats/${S.chatId}/savepoints/${encodeURIComponent(x.dataset.n)}/restore`, {}); toast("reverted"); loadChat(S.chatId); showTab("files"); } catch (e) { toast(e.message, true); } });
  }

  // ---------------------------------------------------------------- resizable panels
  function splitter(el, side) {
    let drag = false;
    el.addEventListener("mousedown", e => { drag = true; el.classList.add("active"); e.preventDefault(); });
    window.addEventListener("mousemove", e => { if (!drag) return;
      if (side === "left") document.documentElement.style.setProperty("--left", Math.max(180, Math.min(520, e.clientX)) + "px");
      else document.documentElement.style.setProperty("--right", Math.max(300, Math.min(window.innerWidth * 0.7, window.innerWidth - e.clientX)) + "px"); });
    window.addEventListener("mouseup", () => { if (drag) { drag = false; el.classList.remove("active"); try { localStorage.setItem("cf-left", getComputedStyle(document.documentElement).getPropertyValue("--left")); localStorage.setItem("cf-right", getComputedStyle(document.documentElement).getPropertyValue("--right")); } catch (_) { } } });
  }
  splitter($("#splitL"), "left"); splitter($("#splitR"), "right");
  try { const l = localStorage.getItem("cf-left"), r = localStorage.getItem("cf-right"); if (l) document.documentElement.style.setProperty("--left", l); if (r) document.documentElement.style.setProperty("--right", r); } catch (_) { }

  // ---------------------------------------------------------------- start
  (async () => {
    renderIcons();
    S.me = await api("/api/me"); $("#userPill").textContent = S.me.display_name || S.me.user_id;
    try { const h = await api("/api/health"); S.me.selftest = h.selftest; } catch (_) { }
    await loadChats(); await loadTemplates(); renderEmpty();
    const rows = await api("/api/chats");
    if (rows.length && !rows[0].story_id && rows[0].status === "new") openChat(rows[0].chat_id);   // latest chat still empty: reuse it
    else await newChat();                                                                            // otherwise start a fresh chat
  })();
})();
