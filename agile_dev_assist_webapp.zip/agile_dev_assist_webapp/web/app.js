/* Agile Dev Assist UI: drag-and-drop inputs, chat with live milestones, right panel (plan / files / review / log / tokens / outputs). */
(() => {
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => Array.from(el.querySelectorAll(s));
  // served behind jupyter-server-proxy (…/proxy/8780/) or at the root: every URL is RELATIVE to the page, and
  // non-GET requests carry Jupyter's _xsrf token (header + query) so the proxy lets them through
  if (!location.pathname.endsWith("/")) location.replace(location.pathname + "/" + location.search);
  const xsrf = () => { const m = document.cookie.match(/(?:^|;\s*)_xsrf=([^;]+)/); return m ? decodeURIComponent(m[1]) : ""; };
  const rel = url => url.replace(/^\//, "");
  const api = async (url, opt = {}) => {
    url = rel(url);
    const method = (opt.method || "GET").toUpperCase();
    if (method !== "GET") { const t = xsrf(); if (t) { opt.headers = Object.assign({}, opt.headers || {}, { "X-XSRFToken": t }); url += (url.includes("?") ? "&" : "?") + "_xsrf=" + encodeURIComponent(t); } }
    const r = await fetch(url, opt);
    if (r.status === 401) { location.reload(); throw new Error("signed out"); }
    const ct = r.headers.get("content-type") || "";
    const body = ct.includes("json") ? await r.json() : await r.text();
    if (!r.ok) throw new Error((body && body.detail) || body || r.statusText);
    return body;
  };
  const post = (url, data) => api(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data || {}) });
  const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const md = s => esc(s).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/(https?:\/\/[^\s)]+)/g, '<a href="$1" target="_blank">$1</a>');
  const toast = (msg, bad) => { const t = $("#toast"); t.textContent = msg; t.className = "toast show" + (bad ? " bad" : ""); clearTimeout(t._t); t._t = setTimeout(() => t.className = "toast", bad ? 6000 : 3000); };

  // ---------------------------------------------------------------- icons (inline SVG per name)
  const SVG = {
    story: '<svg viewBox="0 0 24 24"><path d="M6 3h9l5 5v13H6z"/><path d="M14 3v6h6M9 13h6M9 17h6"/></svg>',
    skills: '<svg viewBox="0 0 24 24"><path d="M12 3l2.5 5.5L20 9l-4 4 1 6-5-3-5 3 1-6-4-4 5.5-.5z"/></svg>',
    gp: '<svg viewBox="0 0 24 24"><ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/></svg>',
    git: '<svg viewBox="0 0 24 24"><circle cx="6" cy="5" r="2.5"/><circle cx="6" cy="19" r="2.5"/><circle cx="18" cy="9" r="2.5"/><path d="M6 7.5v9M18 11.5c0 3-3 4-6 4H9"/></svg>',
    gloss: '<svg viewBox="0 0 24 24"><path d="M4 5a2 2 0 012-2h12a2 2 0 012 2v14a2 2 0 01-2 2H6a2 2 0 01-2-2z"/><path d="M8 7h8M8 11h8M8 15h5"/></svg>',
    std: '<svg viewBox="0 0 24 24"><path d="M9 11l2 2 4-4"/><path d="M12 3l8 3v6c0 5-3.5 8.5-8 9-4.5-.5-8-4-8-9V6z"/></svg>',
    agent: '<svg viewBox="0 0 24 24"><rect x="4" y="7" width="16" height="12" rx="3"/><circle cx="9" cy="13" r="1.5"/><circle cx="15" cy="13" r="1.5"/><path d="M12 3v4M8 21v-2M16 21v-2"/></svg>',
    plan: '<svg viewBox="0 0 24 24"><path d="M4 6h16M4 12h10M4 18h7"/><circle cx="18" cy="17" r="3"/></svg>',
    code: '<svg viewBox="0 0 24 24"><path d="M8 8l-4 4 4 4M16 8l4 4-4 4M14 5l-4 14"/></svg>',
    review: '<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="6"/><path d="M20 20l-4.5-4.5M8.5 11l2 2 3-3"/></svg>',
    data: '<svg viewBox="0 0 24 24"><path d="M4 19h16M7 16V9M12 16V5M17 16v-6"/></svg>',
    run: '<svg viewBox="0 0 24 24"><path d="M7 4l12 8-12 8z"/></svg>',
    push: '<svg viewBox="0 0 24 24"><path d="M12 19V5M5 12l7-7 7 7"/><path d="M5 21h14"/></svg>',
    zip: '<svg viewBox="0 0 24 24"><path d="M12 4v12M6 11l6 6 6-6"/><path d="M4 20h16"/></svg>',
    log: '<svg viewBox="0 0 24 24"><path d="M5 4h14v16H5z"/><path d="M8 8h8M8 12h8M8 16h5"/></svg>',
    tokens: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8"/><path d="M12 8v8M9 10.5h4.5a1.5 1.5 0 010 3H9"/></svg>',
  };
  const INPUTS = [
    { id: "story", name: "Story", cls: "b-story", svg: "story", hint: "git issue / file / paste" },
    { id: "skills", name: "Skills", cls: "b-skills", svg: "skills", hint: "md yml txt csv xlsx docx html" },
    { id: "greenplum", name: "Greenplum", cls: "b-gp", svg: "gp", hint: "tables / query" },
    { id: "repo", name: "Git repo", cls: "b-git", svg: "git", hint: "project URL + token" },
    { id: "glossary", name: "Glossary", cls: "b-gloss", svg: "gloss", hint: "data dictionary files" },
    { id: "standards", name: "Standards", cls: "b-std", svg: "std", hint: "conventions files" },
  ];
  const AGENTS = [
    { id: "story_agent", name: "Story", svg: "story" }, { id: "knowledge_agent", name: "Knowledge", svg: "skills" },
    { id: "data_agent", name: "Data", svg: "data" }, { id: "repo_agent", name: "Repo", svg: "git" },
    { id: "planner_agent", name: "Planner", svg: "plan" }, { id: "coder_agent", name: "Coder", svg: "code" },
    { id: "reviewer_agent", name: "Reviewer", svg: "review" }, { id: "change_agent", name: "Change", svg: "agent" },
  ];
  const TOOLS = [
    { id: "run", name: "Run", svg: "run" }, { id: "push", name: "Push branch", svg: "push" }, { id: "zip", name: "Download zip", svg: "zip" },
    { id: "log", name: "Log / plan", svg: "log" }, { id: "tokens", name: "Tokens", svg: "tokens" }, { id: "docs", name: "Docs (docx/pptx)", svg: "gloss" },
  ];
  const STAGES = ["story", "knowledge", "data", "repo", "plan", "generate", "validate", "review", "fix", "outputs"];

  const S = { me: null, chatId: null, state: null, nextEvent: 0, poll: null, file: null, counts: {} };

  function renderIcons() {
    $("#inputIcons").innerHTML = INPUTS.map(i => `<div class="icon input" draggable="true" data-kind="input" data-id="${i.id}" title="${i.hint}">
      <div class="badge ${i.cls}">${SVG[i.svg]}<span class="count" id="cnt-${i.id}" style="display:none"></span></div><div class="name">${i.name}</div></div>`).join("");
    $("#agentIcons").innerHTML = AGENTS.map(a => `<div class="icon agent" draggable="true" data-kind="agent" data-id="${a.id}" id="ag-${a.id}" title="${a.id}">
      <div class="badge">${SVG[a.svg]}</div><div class="name">${a.name}</div></div>`).join("");
    $("#toolIcons").innerHTML = TOOLS.map(t => `<div class="icon tool" draggable="true" data-kind="tool" data-id="${t.id}">
      <div class="badge b-tool">${SVG[t.svg]}</div><div class="name">${t.name}</div></div>`).join("");
    $$(".icon").forEach(el => {
      el.addEventListener("dragstart", e => { e.dataTransfer.setData("text/plain", JSON.stringify({ kind: el.dataset.kind, id: el.dataset.id })); e.dataTransfer.effectAllowed = "copy"; });
      el.addEventListener("click", () => activate(el.dataset.kind, el.dataset.id));
    });
    const chat = $("#chat");
    chat.addEventListener("dragover", e => { e.preventDefault(); chat.classList.add("dragover"); });
    chat.addEventListener("dragleave", () => chat.classList.remove("dragover"));
    chat.addEventListener("drop", e => {
      e.preventDefault(); chat.classList.remove("dragover");
      if (e.dataTransfer.files && e.dataTransfer.files.length) { openModal("files-drop", { files: e.dataTransfer.files }); return; }
      try { const d = JSON.parse(e.dataTransfer.getData("text/plain")); activate(d.kind, d.id, true); } catch (_) { }
    });
  }

  function activate(kind, id, viaDrag) {
    if (!S.chatId) { toast("create or open a chat first"); return; }
    if (kind === "input") openModal(id);
    else if (kind === "agent") { if (viaDrag) addToPipeline(id); else showAgentInfo(id); }
    else if (kind === "tool") tool(id);
  }
  // ---------------------------------------------------------------- agent pipeline (order of the next run)
  const PIPE_AGENTS = ["story_agent", "knowledge_agent", "data_agent", "repo_agent", "planner_agent", "coder_agent", "reviewer_agent"];
  function renderPipeline() {
    const p = (S.state && S.state.pipeline) || PIPE_AGENTS; const box = $("#plItems");
    box.innerHTML = p.length ? p.map((a, i) => `<span class="pl-item" draggable="true" data-a="${a}"><span class="n">${i + 1}</span>${esc(a.replace("_agent", ""))}<span class="x" title="remove from the pipeline">✕</span></span>${i < p.length - 1 ? '<span class="pl-arrow">›</span>' : ""}`).join("")
      : `<span class="pl-empty">empty - drag agent icons here or press reset</span>`;
    $$(".pl-item", box).forEach(el => {
      $(".x", el).onclick = () => savePipeline(p.filter(a => a !== el.dataset.a));
      el.addEventListener("dragstart", e => { e.dataTransfer.setData("text/plain", JSON.stringify({ kind: "pipe", id: el.dataset.a })); el.classList.add("dragging"); });
      el.addEventListener("dragend", () => el.classList.remove("dragging"));
      el.addEventListener("dragover", e => { e.preventDefault(); el.classList.add("over"); });
      el.addEventListener("dragleave", () => el.classList.remove("over"));
      el.addEventListener("drop", e => { e.preventDefault(); e.stopPropagation(); el.classList.remove("over"); try { const d = JSON.parse(e.dataTransfer.getData("text/plain")); if (d.kind === "pipe" || d.kind === "agent") moveInPipeline(d.id, el.dataset.a); } catch (_) { } });
    });
  }
  function moveInPipeline(id, before) {
    if (!PIPE_AGENTS.includes(id) || id === before) return;
    const p = ((S.state && S.state.pipeline) || PIPE_AGENTS).filter(a => a !== id); p.splice(p.indexOf(before), 0, id); savePipeline(p);
  }
  function addToPipeline(id) {
    if (!PIPE_AGENTS.includes(id)) { toast(`${id} is not part of the run pipeline (it answers change requests after the run)`); return; }
    const p = (S.state && S.state.pipeline) || PIPE_AGENTS; if (p.includes(id)) { toast(`${id.replace("_agent", "")} is already in the pipeline`); return; }
    savePipeline([...p, id]);
  }
  async function savePipeline(p) {
    try { const r = await api(`/api/chats/${S.chatId}/pipeline`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ pipeline: p }) });
      S.state = Object.assign(S.state || {}, { pipeline: r.pipeline }); renderPipeline(); } catch (e) { toast(e.message, true); }
  }
  $("#plReset").onclick = () => savePipeline(PIPE_AGENTS);
  const plBox = $("#pipeline");
  plBox.addEventListener("dragover", e => { e.preventDefault(); plBox.classList.add("dragover"); });
  plBox.addEventListener("dragleave", () => plBox.classList.remove("dragover"));
  plBox.addEventListener("drop", e => { e.preventDefault(); plBox.classList.remove("dragover"); try { const d = JSON.parse(e.dataTransfer.getData("text/plain")); if (d.kind === "agent") addToPipeline(d.id); else if (d.kind === "pipe") { const p = ((S.state && S.state.pipeline) || PIPE_AGENTS).filter(a => a !== d.id); savePipeline([...p, d.id]); } } catch (_) { } });

  // ---------------------------------------------------------------- modals (one form per input)
  const MODALS = {
    story: {
      title: "Story", badge: "b-story", svg: "story", sub: "Where is the story? A git issue (project URL + number) or a file in a repository, an uploaded file, or pasted text.",
      body: `<div class="seg" id="storyMode"><span class="on" data-v="git">Git issue / file</span><span data-v="file">Upload file</span><span data-v="text">Paste text</span></div>
        <div data-mode="git"><label>Git project URL (GitLab or GitHub)</label><input id="s_url" placeholder="https://devcloud.ubs.net/group/project  or  .../-/issues/123">
          <label>Git token (your personal access token, kept in memory for this session)</label><input id="s_token" type="password" placeholder="leave empty to reuse the one already given">
          <div class="row"><div style="flex:1"><label>Issue number</label><input id="s_issue" placeholder="123"></div><div style="flex:2"><label>or file path in the repo</label><input id="s_path" placeholder="stories/STORY-123.md"></div><div style="flex:1"><label>branch</label><input id="s_ref" placeholder="main"></div></div></div>
        <div data-mode="file" style="display:none"><label>Story file (md, txt, docx, doc, html, xlsx, csv, yaml ...)</label><input type="file" id="s_file"></div>
        <div data-mode="text" style="display:none"><label>Story id</label><input id="s_id" placeholder="STORY-123"><label>Title</label><input id="s_title"><label>Story text</label><textarea id="s_text" style="min-height:180px"></textarea></div>`,
      submit: async () => {
        const mode = $("#storyMode .on").dataset.v;
        const fd = new FormData(); fd.append("mode", mode);
        if (mode === "git") { fd.append("url", $("#s_url").value); fd.append("token", $("#s_token").value); fd.append("issue", $("#s_issue").value); fd.append("path", $("#s_path").value); fd.append("ref", $("#s_ref").value); }
        else if (mode === "file") { const f = $("#s_file").files[0]; if (!f) throw new Error("choose a file"); fd.append("file", f); }
        else { fd.append("text", $("#s_text").value); fd.append("title", $("#s_title").value); fd.append("story_id", $("#s_id").value); }
        let r = await api(`/api/chats/${S.chatId}/inputs/story`, { method: "POST", body: fd });
        r = await waitTask(r, p => progress("⏳ " + p));
        toast(`story ${r.id}: ${r.title}`); storyCard(r);
      }
    },
    skills: docModal("skills", "Skills", "b-skills", "skills", "Knowledge files the code must respect (business definitions, how-tos, patterns)."),
    glossary: docModal("glossary", "Glossary / data dictionary", "b-gloss", "gloss", "Column and term definitions, data dictionaries, abbreviations."),
    standards: docModal("standards", "Standards & conventions", "b-std", "std", "Coding standards, naming conventions, review rules - the validator turns clear rules into checks."),
    repo: {
      title: "Git repository (code)", badge: "b-git", svg: "git", sub: "The complete code is downloaded with YOUR token, indexed, and used for patterns, conventions and the files to modify.",
      body: `<label>Project URL - or a local folder path on this machine (e.g. C:\\work\\ikg-dags or /home/me/ikg-dags) for local testing</label><input id="r_url" placeholder="https://devcloud.ubs.net/group/project (optionally /-/tree/branch)">
        <label>Git token</label><input id="r_token" type="password" placeholder="leave empty to reuse the one already given">
        <div class="row"><div style="flex:1"><label>Branch (default: project default)</label><input id="r_branch" placeholder="ikg-master"></div>
        <div style="flex:1"><label>Short name (default: project name)</label><input id="r_name"></div><div style="flex:1"><label>Sub-folder only (optional)</label><input id="r_sub" placeholder="dags/ikg"></div></div>
        <label style="display:flex;gap:8px;align-items:center"><input type="checkbox" id="r_refresh" style="width:auto"> re-download even if cached</label>`,
      submit: async () => {
        let r = await post(`/api/chats/${S.chatId}/inputs/repo`, { url: $("#r_url").value, token: $("#r_token").value, branch: $("#r_branch").value, name: $("#r_name").value, subpath: $("#r_sub").value, refresh: $("#r_refresh").checked });
        r = await waitTask(r, p => progress("⏳ " + p));
        toast(`repository ${r.name}@${r.branch}: ${r.files} files`); inputCard("repo", `${r.name}@${r.branch}: ${r.files} files indexed (${Object.entries(r.languages).map(([k, v]) => k + " " + v).join(", ")})`);
      }
    },
    greenplum: {
      title: "Greenplum tables / query", badge: "b-gp", svg: "gp", sub: "Connection details stay in memory for your session. Tables are introspected (columns, types, keys, comments, sample rows); a read-only query can be added as input.",
      body: `<div class="row"><div style="flex:3"><label>Host</label><input id="g_host" placeholder="greenplum-rdsp.zur.swissbank.com"></div><div style="flex:1"><label>Port</label><input id="g_port" value="5432"></div><div style="flex:2"><label>Database</label><input id="g_db" placeholder="gprdsp"></div></div>
        <div class="row"><div style="flex:1"><label>User</label><input id="g_user"></div><div style="flex:1"><label>Password</label><input id="g_pw" type="password" placeholder="leave empty to reuse"></div><div style="flex:1"><label>Schema</label><input id="g_schema" placeholder="core_ikg"></div></div>
        <label>Tables (comma or newline separated; schema.table allowed) <a href="#" id="g_list">list tables of the schema</a></label><textarea id="g_tables" placeholder="account_profile_curr_ikg, client_dim"></textarea>
        <label>Read-only query (optional)</label><textarea id="g_query" placeholder="select ... from ... limit 100"></textarea>
        <div id="g_sqlite_wrap" style="display:none"><label>Local test: path of a sqlite file playing the database (leave empty for a real Greenplum)</label><input id="g_sqlite" placeholder="data_selftest/samples/sample_gp.db"></div>`,
      submit: async () => {
        const body = { host: $("#g_host").value, port: $("#g_port").value, database: $("#g_db").value, user: $("#g_user").value, password: $("#g_pw").value,
          schema: $("#g_schema").value, tables: $("#g_tables").value.split(/[\n,]/).map(s => s.trim()).filter(Boolean), query: $("#g_query").value, sqlite_path: $("#g_sqlite").value };
        let r = await post(`/api/chats/${S.chatId}/inputs/greenplum`, body);
        r = await waitTask(r, p => progress("⏳ " + p));
        toast(`${r.tables.length} table(s) added`); inputCard("greenplum", `${r.tables.map(t => t.schema + "." + t.table + " (" + t.columns + " cols)").join(", ")}${r.query ? ", query " + r.query.name + " (" + r.query.row_count + " rows)" : ""}`);
      },
      after: () => {
        const d = (S.me && S.me.greenplum_defaults) || {};
        if (d.host) $("#g_host").value = d.host; if (d.port) $("#g_port").value = d.port; if (d.database) $("#g_db").value = d.database;
        if (d.user) $("#g_user").value = d.user; if (d.schema) $("#g_schema").value = d.schema;
        if (S.me && (S.me.selftest || S.me.local_test)) $("#g_sqlite_wrap").style.display = "";
        $("#g_list").onclick = async e => { e.preventDefault(); try { const r = await post(`/api/chats/${S.chatId}/inputs/greenplum`, { action: "list", host: $("#g_host").value, port: $("#g_port").value, database: $("#g_db").value, user: $("#g_user").value, password: $("#g_pw").value, schema: $("#g_schema").value, sqlite_path: $("#g_sqlite").value }); $("#g_tables").value = r.tables.join("\n"); } catch (err) { $("#modalErr").textContent = err.message; } };
      }
    },
    push: {
      title: "Push a branch", badge: "b-tool", svg: "push", ok: "Push", sub: "The branch is created from the base branch and the commit is made with YOUR token, so it appears under your name.",
      body: `<label>Git project URL</label><input id="p_url"><label>Your git token</label><input id="p_token" type="password" placeholder="leave empty to reuse the one already given">
        <div class="row"><div style="flex:1"><label>Base branch (create from)</label><input id="p_base" placeholder="ikg-master"></div><div style="flex:2"><label>New branch name (suggested: storyid-repo-feature)</label><input id="p_branch"></div></div>
        <label>Commit message (optional)</label><input id="p_msg"><div id="p_files" style="font-size:12px;color:var(--muted);margin-top:8px"></div>`,
      submit: async () => {
        const r = await post(`/api/chats/${S.chatId}/push`, { url: $("#p_url").value, token: $("#p_token").value, branch: $("#p_branch").value, base_branch: $("#p_base").value, message: $("#p_msg").value });
        toast(`pushed to ${r.branch}`); addSystem(`Pushed ${r.files} file(s) to ${r.branch} as ${r.pushed_as}: ${r.branch_url}`); loadChat(S.chatId);
      },
      after: async () => {
        const r = await api(`/api/chats/${S.chatId}/branch-suggestion`);
        $("#p_url").value = r.repo_url || ""; $("#p_base").value = r.base_branch || ""; $("#p_branch").value = r.branch || "";
        $("#p_files").textContent = r.files.length ? "files: " + r.files.join(", ") : "nothing generated yet";
        $("#p_url").onchange = async () => { const s = await api(`/api/chats/${S.chatId}/branch-suggestion?url=` + encodeURIComponent($("#p_url").value)); $("#p_branch").value = s.branch; };
      }
    },
    "files-drop": {
      title: "Files dropped - what are they?", badge: "b-skills", svg: "skills", sub: "Choose the input these files belong to.",
      body: `<div class="seg" id="fd_kind"><span class="on" data-v="skills">Skills</span><span data-v="glossary">Glossary</span><span data-v="standards">Standards</span><span data-v="story">Story</span></div><div id="fd_list" style="margin-top:10px;font-size:12.5px"></div>`,
      submit: async (ctx) => {
        const kind = $("#fd_kind .on").dataset.v;
        if (kind === "story") { const fd = new FormData(); fd.append("mode", "file"); fd.append("file", ctx.files[0]); const r = await api(`/api/chats/${S.chatId}/inputs/story`, { method: "POST", body: fd }); storyCard(r); return; }
        await uploadDocs(kind, ctx.files);
      },
      after: (ctx) => { $("#fd_list").innerHTML = Array.from(ctx.files).map(f => `• ${esc(f.name)} (${Math.round(f.size / 1024)} KB)`).join("<br>"); }
    },
  };
  function docModal(kind, title, badge, svg, sub) {
    return {
      title, badge, svg, sub: sub + " Accepted: md, yml, yaml, txt, csv, xls, xlsx, doc, docx, html.",
      body: `<div class="drop" id="d_drop">drop files here or click to choose (multiple allowed)</div><input type="file" id="d_files" multiple style="display:none"><div id="d_list" style="margin-top:8px;font-size:12.5px"></div>`,
      submit: async () => { const fs = $("#d_files")._files || $("#d_files").files; if (!fs || !fs.length) throw new Error("choose at least one file"); await uploadDocs(kind, fs); },
      after: () => {
        const inp = $("#d_files"), drop = $("#d_drop");
        const show = fs => { inp._files = fs; $("#d_list").innerHTML = Array.from(fs).map(f => `• ${esc(f.name)}`).join("<br>"); };
        drop.onclick = () => inp.click(); inp.onchange = () => show(inp.files);
        drop.ondragover = e => { e.preventDefault(); drop.classList.add("over"); }; drop.ondragleave = () => drop.classList.remove("over");
        drop.ondrop = e => { e.preventDefault(); drop.classList.remove("over"); show(e.dataTransfer.files); };
      }
    };
  }
  async function uploadDocs(kind, files) {
    const fd = new FormData(); fd.append("kind", kind); Array.from(files).forEach(f => fd.append("files", f));
    const r = await api(`/api/chats/${S.chatId}/inputs/docs`, { method: "POST", body: fd });
    toast(`${r.length} ${kind} file(s) added`); inputCard(kind, r.map(d => d.name + " (" + d.chars + " chars)").join(", "));
  }

  // long inputs (repo download, table introspection, story from git) run as server tasks: poll with progress
  async function waitTask(r, onProgress) {
    if (!r || !r.task) return r;
    for (;;) {
      await new Promise(res => setTimeout(res, 1000));
      const t = await api(`api/tasks/${r.task}`);
      if (onProgress) onProgress(t.progress || "");
      if (t.status === "done") return t.result;
      if (t.status === "failed") throw new Error(t.error || "failed");
    }
  }
  const progress = msg => { const el = $("#modalProgress"); if (el) { el.textContent = msg; el.style.display = msg ? "" : "none"; } };
  function storyCard(r) { if (r && r.summary_text) addMessage("assistant", r.summary_text); }

  let modalCtx = null;
  function openModal(id, ctx) {
    const m = MODALS[id]; if (!m) return; modalCtx = ctx || {};
    $("#modal").innerHTML = `<h3><span class="badge ${m.badge}">${SVG[m.svg]}</span>${m.title}</h3><div class="sub">${m.sub}</div>${m.body}
      <div class="err" id="modalErr"></div><div id="modalProgress" style="display:none;margin-top:10px;color:var(--accent2);font-size:12.5px">⏳</div><div class="actions"><button id="modalCancel">cancel</button><button class="primary" id="modalOk">${m.ok || "Add"}</button></div>`;
    $("#modalBg").classList.add("open");
    $$(".seg").forEach(seg => seg.onclick = e => { if (e.target.tagName !== "SPAN") return; $$("span", seg).forEach(s => s.classList.remove("on")); e.target.classList.add("on");
      const v = e.target.dataset.v; $$("[data-mode]", $("#modal")).forEach(d => d.style.display = d.dataset.mode === v ? "" : "none"); });
    $("#modalCancel").onclick = closeModal;
    $("#modalOk").onclick = async () => { $("#modalOk").disabled = true; $("#modalOk").textContent = "working…"; $("#modalErr").textContent = ""; progress("⏳ working ...");
      try { await m.submit(modalCtx); closeModal(); loadChat(S.chatId); loadChats(); } catch (e) { $("#modalErr").textContent = e.message; progress(""); } finally { $("#modalOk").disabled = false; $("#modalOk").textContent = m.ok || "Add"; } };
    if (m.after) m.after(modalCtx);
  }
  function closeModal() { $("#modalBg").classList.remove("open"); }
  $("#modalBg").addEventListener("click", e => { if (e.target.id === "modalBg") closeModal(); });

  function showAgentInfo(id) {
    const info = { story_agent: "Turns the story into a structured requirement (goal, functional requirements, business rules, acceptance criteria, open questions).",
      knowledge_agent: "Reads skills, glossary and standards; extracts the definitions that matter and machine-checkable rules for the validator.",
      data_agent: "Explains the Greenplum tables: grain, keys, joins, columns needed, data rules.", repo_agent: "Studies the repository: where the change belongs, patterns to imitate, files to modify, conventions.",
      planner_agent: "Produces the plan: files to create / modify with purpose and outline, steps, test plan, risks.", coder_agent: "Writes each file (parallel), fixes validator and reviewer findings, applies chat change requests.",
      reviewer_agent: "Independent review of all files against story, standards and data: findings with severity, requirement coverage, score, verdict.", change_agent: "Interprets a follow-up request in the chat and decides which files change." };
    const st = (S.state && S.state.events || []).filter(e => e.agent === id);
    const tk = S.state && S.state.summary && S.state.summary.tokens_by_agent && S.state.summary.tokens_by_agent[id];
    addSystem(`${id}: ${info[id] || ""}${st.length ? " - last: " + st[st.length - 1].title : ""}${tk ? " - tokens " + tk.total_tokens + " in " + tk.calls + " call(s)" : ""}`);
  }
  async function tool(id) {
    if (id === "run") return runNow("");
    if (id === "push") return openModal("push");
    if (id === "zip") return window.open(`api/chats/${S.chatId}/download/zip`);
    if (id === "log") { showTab("log"); return; }
    if (id === "tokens") { showTab("tokens"); return; }
    if (id === "docs") { try { const r = await post(`/api/chats/${S.chatId}/docs`, { enabled: true }); toast(r.files.length ? "documentation written: " + r.files.join(", ") : "documentation will be written after the next run"); await loadChat(S.chatId); showTab("outputs"); } catch (e) { toast(e.message, true); } }
  }

  // ---------------------------------------------------------------- chats
  async function loadChats() {
    const rows = await api("/api/chats");
    $("#chatList").innerHTML = rows.map(c => `<div class="chat-item ${c.chat_id === S.chatId ? "active" : ""}" data-id="${c.chat_id}">
      <span class="st ${c.status || ""}"></span><span class="t" title="${esc(c.title)}">${esc(c.title || c.chat_id)}</span><span class="x" title="delete this chat">✕</span></div>`).join("") || `<div style="color:var(--muted);font-size:12px;padding:6px">no chats yet</div>`;
    $$(".chat-item").forEach(el => {
      el.onclick = e => { if (e.target.classList.contains("x")) return; openChat(el.dataset.id); };
      $(".x", el).onclick = async e => { e.stopPropagation(); if (!confirm("Delete this chat and all its inputs / outputs?")) return; await api(`/api/chats/${el.dataset.id}`, { method: "DELETE" }); if (S.chatId === el.dataset.id) { S.chatId = null; S.state = null; renderEmpty(); } loadChats(); };
    });
  }
  async function newChat() { const c = await post("/api/chats", {}); await loadChats(); openChat(c.chat_id); }
  function renderEmpty() {
    $("#chatTitle").textContent = "no chat"; setRunState(false);
    $("#chat").innerHTML = `<div class="welcome"><h2>Welcome to Agile Dev Assist</h2>Create a new chat, then drag the inputs into this window.<div class="drops">${INPUTS.map(i => `<span>${i.name}</span>`).join("")}</div></div>`;
    ["inputs", "plan", "review", "tokens", "outputs"].forEach(p => $("#pane-" + p).innerHTML = ""); $("#fileList").innerHTML = ""; $("#fileEditor").value = ""; $("#logText").textContent = "";
    $$(".icon.agent").forEach(a => a.classList.remove("busy", "done"));
    $("#plItems").innerHTML = "";
  }
  async function openChat(id) {
    if (S.poll) clearInterval(S.poll);
    S.chatId = id; S.nextEvent = 0; S.file = null; $("#chat").innerHTML = ""; $("#fileEditor").value = ""; $("#fileList").innerHTML = "";
    $$(".icon.agent").forEach(a => a.classList.remove("busy", "done"));
    await loadChat(id); await loadChats();
    S.poll = setInterval(pollEvents, 1500);
  }
  async function loadChat(id) {
    const st = await api(`/api/chats/${id}`); S.state = st;
    $("#chatTitle").textContent = st.chat ? st.chat.title : id;
    renderMessages(st); renderInputs(st); renderPlan(st); renderFiles(st); renderReview(st); renderTokens(st); renderOutputs(st); renderPipeline();
    S.nextEvent = (st.events || []).length;
    setRunState(st.busy || st.running);
  }
  function setRunState(busy) { const el = $("#runState"); el.textContent = busy ? "⏳ working…" : ""; el.style.display = busy ? "" : "none"; el.className = "pill"; $("#btnSend").disabled = !!busy; $("#btnRun").disabled = !!busy; }

  // ---------------------------------------------------------------- chat rendering + live events
  function renderMessages(st) {
    const chat = $("#chat"); chat.innerHTML = "";
    if (!(st.messages || []).length && !(st.events || []).length) chat.innerHTML = `<div class="welcome"><h2>${esc(st.chat ? st.chat.title : "New chat")}</h2>Drag the inputs here: a story is required; skills, glossary, standards, Greenplum tables and a git repository make the code accurate. Drag agent icons to build the pipeline (order / remove). Then press Run or type instructions.<div class="drops">${INPUTS.map(i => `<span>${i.name}</span>`).join("")}</div></div>`;
    // interleave messages and milestone blocks by time
    const items = [...(st.messages || []).map(m => ({ t: m.ts || 0, m })), ...(st.events || []).map(e => ({ t: e.t || 0, e }))].sort((a, b) => a.t - b.t);
    for (const it of items) { if (it.m) { ms = null; addMessage(it.m.role, it.m.text, false, it.m.meta); } else mergeEvents([it.e]); }
    chat.scrollTop = chat.scrollHeight;
  }
  const CARD = { story: ["b-story", "story", "Story"], skills: ["b-skills", "skills", "Skills"], glossary: ["b-gloss", "gloss", "Glossary / data dictionary"],
    standards: ["b-std", "std", "Standards & conventions"], greenplum: ["b-gp", "gp", "Greenplum"], repo: ["b-git", "git", "Git repository"], publish: ["b-tool", "push", "Pushed"] };
  function inputCard(kind, text) {
    const w = $(".welcome", $("#chat")); if (w) w.remove();
    const [cls, svg, label] = CARD[kind];
    const body = text.replace(/^[a-z]+:\s*/i, "");
    const items = body.split(/,\s*(?![^()]*\))/).map(x => x.trim()).filter(Boolean);
    const el = document.createElement("div"); el.className = "msg input c-" + kind;
    el.innerHTML = `<div class="ih"><span class="badge ${cls}">${SVG[svg]}</span>${label}</div><div class="ib">${items.length > 1 ? items.map(x => `<span class="chip">${esc(x)}</span>`).join("") : esc(body)}</div>`;
    $("#chat").appendChild(el); return el;
  }
  function addMessage(role, text, scroll = true, meta) {
    if (role === "system" && meta && CARD[meta.kind]) { const el = inputCard(meta.kind, text); if (scroll) $("#chat").scrollTop = $("#chat").scrollHeight; return el; }
    const w = $(".welcome", $("#chat")); if (w) w.remove();
    const el = document.createElement("div"); el.className = "msg " + role; el.innerHTML = md(text);
    $("#chat").appendChild(el); if (scroll) $("#chat").scrollTop = $("#chat").scrollHeight; return el;
  }
  const addSystem = t => addMessage("system", t);
  let ms = null;   // current milestones block
  const STAGE_OF = { story_agent: ["story"], knowledge_agent: ["knowledge"], data_agent: ["data"], repo_agent: ["repo"], planner_agent: ["plan"],
    coder_agent: ["generate", "validate"], reviewer_agent: ["review", "fix"] };
  function stagesFor(pipeline) {
    if (!pipeline || !pipeline.length) return STAGES;
    const out = []; for (const a of pipeline) for (const st of (STAGE_OF[a] || [])) out.push(st);
    if (pipeline.includes("coder_agent") && !pipeline.includes("planner_agent")) out.splice(out.indexOf("generate"), 0, "plan");
    out.push("outputs"); return out;
  }
  function milestoneBlock(pipeline) {
    if (ms && ms.isConnected) return ms;
    ms = document.createElement("div"); ms.className = "milestones";
    ms.innerHTML = `<div style="display:flex;justify-content:space-between;font-size:12.5px"><b id="msTitle">starting…</b><span id="msPct">0%</span></div><div class="bar"><div id="msBar"></div></div>
      <div class="steps">${stagesFor(pipeline).map(s => `<span class="step" data-s="${s}">${s}</span>`).join("")}</div><div class="mini-log" id="msLog"></div>`;
    $("#chat").appendChild(ms); return ms;
  }
  const AGENT_OF_STAGE = { story: "story_agent", knowledge: "knowledge_agent", data: "data_agent", repo: "repo_agent", plan: "planner_agent", generate: "coder_agent", validate: "coder_agent", review: "reviewer_agent", fix: "coder_agent" };
  function setStep(b, stage, cls) { const el = $(`.step[data-s="${stage}"]`, b); if (!el) return; el.classList.remove("active", "done", "skipped", "failed"); el.classList.add(cls); }
  function mergeEvents(evs) {
    for (const e of evs) {
      if (e.type === "input") continue;                       // inputs are shown as cards (chat messages), never as a progress block
      if (e.type === "milestone" && (e.pct === 0 || e.title === "run started" || e.title === "change requested")) { ms = null; milestoneBlock(e.pipeline); }
      if (["milestone", "agent", "file", "result", "log", "error"].includes(e.type)) {
        const b = milestoneBlock(e.pipeline);
        if (e.type === "milestone") { $("#msTitle", b).textContent = e.title; if (e.pct != null) { $("#msPct", b).textContent = e.pct + "%"; $("#msBar", b).style.width = e.pct + "%"; }
          if (e.stage) { if (!e.parallel) $$(".step.active", b).forEach(s => { if (s.dataset.s !== e.stage && !["knowledge", "data", "repo"].includes(s.dataset.s)) { s.classList.remove("active"); s.classList.add("done"); } }); setStep(b, e.stage, "active");
            const ic = $("#ag-" + AGENT_OF_STAGE[e.stage]); if (ic) ic.classList.add("busy"); } }
        if (e.stage_done) { setStep(b, e.stage_done, e.type === "error" ? "failed" : "done"); const ic = $("#ag-" + AGENT_OF_STAGE[e.stage_done]); if (ic) { ic.classList.add("done"); ic.classList.remove("busy"); } }
        if (e.stage_skipped) setStep(b, e.stage_skipped, "skipped");
        if (e.kind === "done") $$(".step.active", b).forEach(s => { s.classList.remove("active"); s.classList.add("done"); });
        if (e.type === "agent" && e.agent) { const ic = $("#ag-" + e.agent); if (ic) { ic.classList.add("done"); ic.classList.remove("busy"); } }
        const line = document.createElement("div"); line.className = e.type === "error" ? "err" : ""; line.textContent = `${e.ts} ${e.title}${e.detail ? " — " + String(e.detail).slice(0, 160) : ""}`;
        const lg = $("#msLog", b); lg.appendChild(line); lg.scrollTop = lg.scrollHeight;
      }
    }
    $("#chat").scrollTop = $("#chat").scrollHeight;
  }
  async function pollEvents() {
    if (!S.chatId) return;
    try {
      const r = await api(`/api/chats/${S.chatId}/events?since=${S.nextEvent}`);
      if (r.events.length) { mergeEvents(r.events); S.nextEvent = r.next; }
      const wasBusy = $("#btnSend").disabled; setRunState(r.busy || r.running);
      if (wasBusy && !(r.busy || r.running)) { await loadChat(S.chatId); loadChats(); $$(".icon.agent").forEach(a => a.classList.remove("busy")); }
      else if (r.events.some(e => e.type === "file" || e.type === "result")) { const st = await api(`/api/chats/${S.chatId}`); S.state = st; renderFiles(st); renderPlan(st); renderReview(st); renderInputs(st); }
    } catch (e) { /* transient */ }
  }

  // ---------------------------------------------------------------- send / run
  async function send() {
    const t = $("#composer").value.trim(); if (!t || !S.chatId) return;
    $("#composer").value = ""; addMessage("user", t); setRunState(true);
    try { const r = await post(`/api/chats/${S.chatId}/message`, { text: t }); if (r.reply) { addMessage("assistant", r.reply); setRunState(false); } }
    catch (e) { toast(e.message, true); setRunState(false); }
  }
  async function runNow(instr) {
    if (!S.chatId) return; setRunState(true);
    try { await post(`/api/chats/${S.chatId}/run`, { instructions: instr || "" }); addSystem("Run started"); } catch (e) { toast(e.message, true); setRunState(false); }
  }
  $("#btnSend").onclick = send; $("#btnRun").onclick = () => runNow($("#composer").value.trim());
  $("#composer").addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } });
  $("#btnNewChat").onclick = newChat;
  $("#btnLogout").onclick = async () => { await post("auth/logout", {}); location.reload(); };

  // ---------------------------------------------------------------- right panel
  function showTab(name) { $$(".tab").forEach(t => t.classList.toggle("active", t.dataset.tab === name)); $$(".pane").forEach(p => p.classList.toggle("active", p.id === "pane-" + name)); if (name === "log") loadLog(); }
  $$(".tab").forEach(t => t.onclick = () => showTab(t.dataset.tab));
  function renderInputs(st) {
    const i = st.inputs || {}; const n = k => (i[k] || []).length;
    const cnt = { story: i.story ? 1 : 0, skills: n("skills"), greenplum: n("tables") + n("queries"), repo: n("repos"), glossary: n("glossary"), standards: n("standards") };
    for (const [k, v] of Object.entries(cnt)) { const el = $("#cnt-" + k); if (el) { el.textContent = v; el.style.display = v ? "" : "none"; } }
    const chips = (arr, kind) => arr.map(d => `<span class="chip">${esc(d.name)} <small>${d.chars || ""}</small><span class="x" data-k="${kind}" data-n="${esc(d.name)}">✕</span></span>`).join("") || "<span style='color:var(--muted)'>none</span>";
    $("#pane-inputs").innerHTML = `
      <div class="box"><h4>Story</h4>${i.story ? `<b>${esc(i.story.id)}</b> ${esc(i.story.title)} <small style="color:var(--muted)">(${i.story.chars} chars, ${esc(i.story.source.type || "")})</small> <span class="chip"><span class="x" data-del="story">✕ remove</span></span>` : "<span style='color:var(--muted)'>not set - drag the Story icon into the chat</span>"}</div>
      <div class="box"><h4>Skills</h4><div class="chips">${chips(i.skills || [], "skills")}</div></div>
      <div class="box"><h4>Glossary / data dictionary</h4><div class="chips">${chips(i.glossary || [], "glossary")}</div></div>
      <div class="box"><h4>Standards & conventions</h4><div class="chips">${chips(i.standards || [], "standards")}</div></div>
      <div class="box"><h4>Greenplum</h4><div class="chips">${(i.tables || []).map(t => `<span class="chip">${esc(t.schema)}.${esc(t.table)} <small>${t.columns} cols</small><span class="x" data-del="table" data-s="${esc(t.schema)}" data-n="${esc(t.table)}">✕</span></span>`).join("")}${(i.queries || []).map(q => `<span class="chip">query ${esc(q.name)} <small>${q.row_count} rows</small><span class="x" data-del="query" data-n="${esc(q.name)}">✕</span></span>`).join("")}${(i.tables || []).length || (i.queries || []).length ? "" : "<span style='color:var(--muted)'>none</span>"}</div></div>
      <div class="box"><h4>Repositories</h4><div class="chips">${(i.repos || []).map(r => `<span class="chip">${esc(r.name)}@${esc(r.branch)} <small>${r.files} files · ${Object.entries(r.languages).map(([k, v]) => k + " " + v).join(", ")}</small><span class="x" data-del="repo" data-n="${esc(r.name)}">✕</span></span>`).join("") || "<span style='color:var(--muted)'>none</span>"}</div></div>
      <div class="box"><h4>Instructions given</h4>${(i.instructions || []).map(x => `<div>• ${esc(x)}</div>`).join("") || "<span style='color:var(--muted)'>none</span>"}</div>`;
    $$("#pane-inputs .chip .x").forEach(x => x.onclick = async () => {
      const d = x.dataset, c = S.chatId;
      try {
        if (d.k) await api(`/api/chats/${c}/inputs/docs/${d.k}/${encodeURIComponent(d.n)}`, { method: "DELETE" });
        else if (d.del === "story") { if (!confirm("Remove the story from this chat?")) return; await api(`/api/chats/${c}/inputs/story`, { method: "DELETE" }); }
        else if (d.del === "table") await api(`/api/chats/${c}/inputs/table/${encodeURIComponent(d.s)}/${encodeURIComponent(d.n)}`, { method: "DELETE" });
        else if (d.del === "query") await api(`/api/chats/${c}/inputs/query/${encodeURIComponent(d.n)}`, { method: "DELETE" });
        else if (d.del === "repo") await api(`/api/chats/${c}/inputs/repo/${encodeURIComponent(d.n)}`, { method: "DELETE" });
        toast("removed"); loadChat(c);
      } catch (e) { toast(e.message, true); }
    });
  }
  function renderPlan(st) {
    const p = st.plan || {};
    if (!p.files) { $("#pane-plan").innerHTML = "<div class='box' style='color:var(--muted)'>no plan yet</div>"; return; }
    $("#pane-plan").innerHTML = `<div class="box"><h4>Approach</h4>${esc(p.approach)}</div>
      <div class="box"><h4>Files (${p.files.length})</h4>${p.files.map(f => `<div style="margin:6px 0"><b>${esc(f.action)}</b> <code>${esc(f.path)}</code> <small>[${esc(f.language)}]</small><div style="color:var(--muted);font-size:12px">${esc(f.purpose)}</div><ul>${(f.outline || []).map(o => `<li>${esc(o)}</li>`).join("")}</ul></div>`).join("")}</div>
      <div class="box"><h4>Steps</h4><ol>${(p.steps || []).map(s => `<li>${esc(s)}</li>`).join("")}</ol></div>
      <div class="box"><h4>Test plan</h4><ul>${(p.test_plan || []).map(s => `<li>${esc(s)}</li>`).join("")}</ul></div>
      ${(p.risks || []).length ? `<div class="box"><h4>Risks</h4><ul>${p.risks.map(s => `<li>${esc(s)}</li>`).join("")}</ul></div>` : ""}
      ${(p.questions || []).length ? `<div class="box"><h4>Open questions</h4><ul>${p.questions.map(s => `<li>${esc(s)}</li>`).join("")}</ul></div>` : ""}
      <div class="row"><a class="btn" href="api/chats/${S.chatId}/download/plan" download>download plan.json</a></div>`;
  }
  function renderFiles(st) {
    const files = st.files || []; $("#nFiles").textContent = files.length; $("#nFiles").style.display = files.length ? "" : "none";
    $("#fileList").innerHTML = files.map(f => `<div class="${S.file === f.path ? "active" : ""}" data-p="${esc(f.path)}" title="${esc(f.purpose)}">${esc(f.path.split("/").pop())}<br><span class="lang">${esc(f.language)} · ${esc(f.action)} · ${f.confidence || 0}%</span></div>`).join("");
    $$("#fileList div").forEach(el => el.onclick = () => openFile(el.dataset.p));
    if (S.file && !files.some(f => f.path === S.file)) { S.file = null; $("#fileEditor").value = ""; }
    if (!S.file && files.length) openFile(files[0].path);
  }
  async function openFile(p) {
    const f = await api(`/api/chats/${S.chatId}/files/${p}`); S.file = p;
    $$("#fileList div").forEach(el => el.classList.toggle("active", el.dataset.p === p));
    $("#fileName").textContent = p; $("#fileEditor").value = f.content; $("#btnSaveFile").disabled = false; $("#btnDownloadFile").disabled = false;
    $("#fileMeta").innerHTML = `<b>${esc(f.language)}</b> · ${esc(f.action)} · confidence ${f.confidence}% · ${esc(f.purpose)}<br>${esc(f.explanation || "")}${(f.assumptions || []).length ? "<br>assumptions: " + f.assumptions.map(esc).join("; ") : ""}`;
  }
  $("#btnSaveFile").onclick = async () => { const r = await api(`/api/chats/${S.chatId}/files/${S.file}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ content: $("#fileEditor").value }) }); toast(`saved (${r.findings.length} finding(s))`); loadChat(S.chatId); };
  $("#btnDownloadFile").onclick = () => { const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([$("#fileEditor").value])); a.download = S.file.split("/").pop(); a.click(); };
  function renderReview(st) {
    const r = st.review || {}, f = st.findings || [], s = st.summary || {};
    const all = [...(r.findings || []).map(x => ({ ...x, from: "reviewer" })), ...f.map(x => ({ ...x, from: "validator" }))];
    $("#nFind").textContent = all.length; $("#nFind").style.display = all.length ? "" : "none";
    if (!s.files) { $("#pane-review").innerHTML = "<div class='box' style='color:var(--muted)'>no run yet</div>"; return; }
    $("#pane-review").innerHTML = `<div class="box row"><div><div class="score">${s.quality_score ?? "-"}</div><small>validator quality</small></div>
      <div style="margin-left:20px"><div class="score">${r.score ?? "-"}</div><small>reviewer score · ${esc(r.verdict || "no review")}</small></div></div>
      ${r.summary ? `<div class="box">${esc(r.summary)}</div>` : ""}
      <div class="box"><h4>Findings (${all.length})</h4>${all.map(x => `<div class="finding"><span class="sev ${x.severity}">${esc(x.severity)}</span><div><b>${esc(x.path)}</b>${x.line ? ":" + x.line : ""} <small>(${esc(x.kind || "")}, ${x.from})</small><br>${esc(x.message)}${x.suggestion ? "<br><i>" + esc(x.suggestion) + "</i>" : ""}</div></div>`).join("") || "<span style='color:var(--muted)'>none</span>"}</div>
      ${(r.requirements_coverage || []).length ? `<div class="box"><h4>Requirement coverage</h4>${r.requirements_coverage.map(c => `<div>${c.covered ? "✅" : "❌"} ${esc(c.requirement)} <small style="color:var(--muted)">${esc(c.where || "")}</small></div>`).join("")}</div>` : ""}`;
  }
  async function loadLog() { if (!S.chatId) return; $("#logText").textContent = await api(`/api/chats/${S.chatId}/text/log`); $("#dlLog").href = `api/chats/${S.chatId}/download/log`; $("#logText").scrollTop = $("#logText").scrollHeight; }
  $("#btnRefreshLog").onclick = loadLog;
  function renderTokens(st) {
    const s = st.summary || {}; const t = s.tokens, by = s.tokens_by_agent || {};
    if (!t) { $("#pane-tokens").innerHTML = "<div class='box' style='color:var(--muted)'>no run yet</div>"; return; }
    const row = (k, v) => `<tr><td>${esc(k)}</td><td>${v.calls}</td><td>${v.cache_hits}</td><td>${v.prompt_tokens}</td><td>${v.completion_tokens}</td><td>${v.reasoning_tokens}</td><td>${v.cached_tokens}</td><td><b>${v.total_tokens}</b></td><td>${v.seconds_in_calls}</td></tr>`;
    $("#pane-tokens").innerHTML = `<div class="box row"><div><div class="score">${t.total_tokens}</div><small>total tokens · ${t.calls} calls · ${t.cache_hits} cache hits · ${t.rate_limit_hits || 0} rate-limit hits · ${s.duration_seconds}s</small></div></div>
      <div class="box"><table class="tk"><tr><th>agent</th><th>calls</th><th>cache</th><th>prompt</th><th>completion</th><th>reasoning</th><th>cached</th><th>total</th><th>secs</th></tr>${Object.entries(by).sort((a, b) => b[1].total_tokens - a[1].total_tokens).map(([k, v]) => row(k, v)).join("")}${row("TOTAL", t)}</table></div>
      <div class="row"><a class="btn" href="api/chats/${S.chatId}/download/tokens" download>download tokens.txt</a></div>`;
  }
  function renderOutputs(st) {
    const s = st.summary || {}; const has = (st.files || []).length;
    const dl = (w, l) => `<a class="btn" href="api/chats/${S.chatId}/download/${w}" download>${l}</a>`;
    $("#pane-outputs").innerHTML = `<div class="box"><h4>Downloads</h4><div class="row">${has ? dl("zip", "⬇ zip (all files + plan, review, log, tokens)") : "<span style='color:var(--muted)'>run first</span>"} ${dl("log", "log.txt")} ${dl("plan", "plan.json")} ${dl("tokens", "tokens.txt")} ${dl("review", "review.json")} ${dl("findings", "findings.json")} ${dl("pack", "context pack")} ${dl("inputs", "inputs.json")} ${dl("summary", "run_summary.json")}</div></div>
      <div class="box"><h4>Git branch</h4><div style="font-size:12.5px;color:var(--muted);margin-bottom:8px">Creates the branch from the base branch and commits every generated file with your token (your name on the commit). Suggested name: storyid-repo-feature.</div><button class="primary" id="btnPush" ${has ? "" : "disabled"}>Push a branch…</button></div>
      ${s.files ? `<div class="box"><h4>Last run</h4><div class="kv"><b>finished</b><span>${esc(s.finished)}</span><b>duration</b><span>${s.duration_seconds}s</span><b>files</b><span>${s.files.length}</span><b>quality</b><span>${s.quality_score}</span><b>review</b><span>${esc((s.review || {}).verdict || "")} ${(s.review || {}).score || ""}</span><b>tokens</b><span>${(s.tokens || {}).total_tokens}</span></div></div>` : ""}
      <div class="box"><h4>Documentation (optional)</h4><div style="color:var(--muted);font-size:12.5px;margin-bottom:6px">One-pager (docx) and slides (pptx) for non-technical readers.</div>
        <div class="row">${(st.docs || []).map(d => `<a class="btn" href="api/chats/${S.chatId}/docfile/${encodeURIComponent(d.split("/").pop())}" download>${esc(d.split("/").pop())}</a>`).join("")}<button id="btnDocs" ${has ? "" : "disabled"}>Generate docx + pptx</button></div></div>`;
    const bd = $("#btnDocs"); if (bd) bd.onclick = () => tool("docs");
    const b = $("#btnPush"); if (b) b.onclick = () => openModal("push");
  }

  // ---------------------------------------------------------------- resizable panels
  function splitter(el, side) {
    let drag = false;
    el.addEventListener("mousedown", e => { drag = true; el.classList.add("active"); e.preventDefault(); });
    window.addEventListener("mousemove", e => { if (!drag) return;
      if (side === "left") document.documentElement.style.setProperty("--left", Math.max(180, Math.min(520, e.clientX)) + "px");
      else document.documentElement.style.setProperty("--right", Math.max(300, Math.min(window.innerWidth * 0.7, window.innerWidth - e.clientX)) + "px"); });
    window.addEventListener("mouseup", () => { if (drag) { drag = false; el.classList.remove("active"); try { localStorage.setItem("cf-left", getComputedStyle(document.documentElement).getPropertyValue("--left")); localStorage.setItem("cf-right", getComputedStyle(document.documentElement).getPropertyValue("--right")); } catch (_) { } } });
  }
  splitter($("#splitL"), "left"); splitter($("#splitR"), "right");
  try { const l = localStorage.getItem("cf-left"), r = localStorage.getItem("cf-right"); if (l) document.documentElement.style.setProperty("--left", l); if (r) document.documentElement.style.setProperty("--right", r); } catch (_) { }

  // ---------------------------------------------------------------- start
  (async () => {
    renderIcons();
    S.me = await api("/api/me"); $("#userPill").textContent = S.me.display_name || S.me.user_id;
    try { const h = await api("/api/health"); S.me.selftest = h.selftest; } catch (_) { }
    await loadChats(); renderEmpty();
    const rows = await api("/api/chats");
    if (rows.length && !rows[0].story_id && rows[0].status === "new") openChat(rows[0].chat_id);   // latest chat still empty: reuse it
    else await newChat();                                                                            // otherwise start a fresh chat
  })();
})();
