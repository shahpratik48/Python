# Knowledge packs

Drop the nightly packs here (or point `knowledge_packs.dir` in the config at the Knowledge Pack builder's `output/` folder):

    packs/ikg_pack.zip
    packs/odm_pack.zip
    packs/nlg_pack.zip

Each is the complete, indexed knowledge of one system (repository facts, tables, conventions, graph, cards). The
prebuilt templates IKG / ODM / NLG in the UI attach the matching pack to a new chat together with the system's git
conventions (base branch, merge-request target, branch name pattern). Users can still add their own documents, tables
and a live repository on top.
