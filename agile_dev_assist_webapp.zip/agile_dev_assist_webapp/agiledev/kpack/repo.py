"""A RepoIndex over the repository copy inside a knowledge pack whose expensive questions - how is a folder registered,
which files change together, which file is the typical example - are answered from the pack's pre-computed facts
(exact, instant) instead of being re-derived by scanning files on every call."""
from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional

from ..repoindex import RepoIndex


class PackRepoIndex(RepoIndex):
    def __init__(self, pack, root: Path, name: str = "", max_files: int = 12000):
        self.pack = pack
        super().__init__(root, name, max_files)

    # ------------------------------------------------------------------ registration
    def registration_candidates(self, folder: str, k: int = 6) -> List[dict]:
        folder = folder.strip("/")
        reg = self.pack.structure.get("registration", {}).get(folder)
        if reg is None:
            # a new folder: inherit from the nearest existing parent / sibling folder of the pack
            parent = folder.rsplit("/", 1)[0] if "/" in folder else ""
            sibs = [f for f in self.pack.structure.get("registration", {}) if f.startswith(parent + "/") and f.count("/") == folder.count("/")]
            reg = self.pack.structure["registration"].get(sibs[0]) if sibs else None
            if reg is None:
                return super().registration_candidates(folder, k)
            reg = dict(reg, inherited_from=sibs[0])
        out = []
        for d in reg.get("dynamic", []):
            out.append({"path": d["path"], "mentions": 99, "of": 0, "example_line": "", "automatic": True,
                        "reason": f"AUTOMATIC: {d['path']} walks {d['root']} ({d['via']}) - every script in {folder} runs without a registration entry "
                                  f"(folder = task group, file stem = task id); nothing to add here" + (f" [rule inherited from {reg['inherited_from']}]" if reg.get("inherited_from") else "")})
        for s in reg.get("static", []):
            out.append({"path": s["path"], "mentions": s.get("count", 1), "of": 0, "example_line": s.get("example_line", ""),
                        "reason": f"STATIC: lists the scripts of {folder} by name ({s.get('count', 1)} entries, e.g. {s.get('example_line', '')}) - new scripts in {folder} must be added here"})
        if not out:
            for c in reg.get("candidates", [])[:k]:
                out.append({"path": c["path"], "mentions": 1, "of": 0, "example_line": c.get("example_line", ""), "reason": "LIKELY: " + c.get("reason", "")})
        return out[:k]

    # ------------------------------------------------------------------ companions
    def companions(self, path: str, names: Optional[List[str]] = None, k: int = 8) -> List[dict]:
        path = path.strip("/")
        if path not in self.files:
            return self.companions_for_new(path, k)
        out, seen = [], set()
        for c in self.pack.companions(path):
            exp = c.get("expected", "")
            if c["relation"] == "sibling":
                folder_c = c["companion_folder_or_file"]
                cands = [f for f in self.files if f.startswith(folder_c + "/") and Path(f).stem == exp]
                for f in cands[:1]:
                    if f not in seen:
                        seen.add(f)
                        out.append({"path": f, "relation": "sibling", "example_line": "",
                                    "reason": f"{c['rule']} (pack companion rule, {c['occurrences']} occurrences) - when {path} changes this file usually needs the same change"})
            else:
                f = c["companion_folder_or_file"]
                if f in self.files and f not in seen:
                    seen.add(f)
                    out.append({"path": f, "relation": "configuration", "example_line": c["example"].get("line", ""),
                                "reason": f"{c['rule']} (pack companion rule) - a new / renamed script needs its entry here"})
        # readers of the tables this script builds (impact) - from the pack graph, no grep
        for t in self.pack.structure.get("script_tables", {}).get(path, [])[:3]:
            for r in self.pack.structure.get("tables", {}).get(t, {}).get("read_by", [])[:4]:
                if r != path and r not in seen:
                    seen.add(r)
                    out.append({"path": r, "relation": "consumer", "example_line": "", "reason": f"reads {t} which {path} builds (pack lineage)"})
        return out[:k] if out else super().companions(path, names, k)

    def companions_for_new(self, path: str, k: int = 8) -> List[dict]:
        path = path.strip("/")
        if path in self.files:
            return self.companions(path, k=k)
        folder = path.rsplit("/", 1)[0] if "/" in path else ""
        stem, ext = Path(path).stem, Path(path).suffix
        out, seen = [], set()
        for c in self.pack.structure.get("companion_patterns", []):
            if c["folder"] != folder:
                continue
            from .pack import _apply_stem_rule
            if c["relation"] == "sibling":
                new_stem = _apply_stem_rule(stem, c.get("stem_rule", ""), c["example"])
                comp_ext = Path(c["example"]["companion"]).suffix or ext
                new_path = f"{c['companion_folder_or_file']}/{new_stem}{comp_ext}"
                if new_path in seen:
                    continue
                seen.add(new_path)
                out.append({"path": new_path, "relation": "sibling_to_create", "example_line": "", "exists": new_path in self.files,
                            "reason": f"{c['rule']} ({c['occurrences']} existing pairs, e.g. {c['example']['file']} <-> {c['example']['companion']}) - the new {path} needs the analogous file"})
            else:
                f = c["companion_folder_or_file"]
                if f in self.files and f not in seen:
                    seen.add(f)
                    out.append({"path": f, "relation": "configuration", "example_line": c["example"].get("line", ""), "exists": True,
                                "reason": f"{c['rule']} - the new {stem} needs an entry like '{c['example'].get('line', '')[:80]}'"})
        return out[:k] if out else super().companions_for_new(path, k)

    # ------------------------------------------------------------------ examples
    def examples(self, language: str, folder: str = "", k: int = 2) -> List[str]:
        ex = self.pack.exemplar(folder.strip("/"))
        base = super().examples(language, folder, k)
        if ex.get("file") and ex["file"] not in base:
            return [ex["file"]] + base[: max(0, k - 1)]
        return base

    def exemplar(self, folder: str) -> dict:
        return self.pack.exemplar(folder.strip("/"))

    def folder_card(self, folder: str) -> str:
        return self.pack.card("folder", folder.strip("/"))
