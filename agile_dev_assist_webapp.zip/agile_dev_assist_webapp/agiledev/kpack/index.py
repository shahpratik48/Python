"""The pack's search indexes: BM25 (exact) over every knowledge item + a dense vector store (Azure embeddings, one numpy
matrix) fused by reciprocal rank at query time. Built once per pack; embeddings are cached by text hash across builds
so a weekly rebuild embeds only what changed. Used by the builder (to write index/) and by consumers (Pack.search)."""
from __future__ import annotations

import hashlib
import json
import logging
import math
import pickle
import re
import threading
import time
from collections import Counter, OrderedDict
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np

from ..repoindex import tokenize

log = logging.getLogger("kpack.index")
_LOAD_LOCK = threading.Lock()
_IDENT = re.compile(r"\b(si_[a-z0-9_]+|[a-z][a-z0-9]*(?:_[a-z0-9]+){1,})\b", re.I)


def _h(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8", "replace")).hexdigest()[:32]


class BM25:
    """Okapi BM25 over the pack items as an inverted index in numpy arrays (term -> postings of item ids + term counts):
    a query touches only the postings of its own terms (milliseconds on 12k items). The arrays are cached next to the
    pack (index/bm25_cache.npz), so a pack is tokenised once - the first time it is opened - and loads in ~20 ms after."""

    def __init__(self):
        self.items: List[dict] = []
        self._pending: List[Counter] = []
        self.vocab: Dict[str, int] = {}
        self.ptr = self.docs = self.tf = self.dl = None
        self.kind_codes = None
        self.kinds_list: List[str] = []
        self.avgdl = 1.0

    # build ------------------------------------------------------------------------------------------------------------
    def add(self, item: dict) -> None:
        self.items.append(item)
        self._pending.append(Counter(tokenize(item.get("title", "") * 2 + " " + item.get("text", ""))))

    def add_counts(self, item: dict, counts: Counter) -> None:          # old packs: pickled term counts
        self.items.append(item); self._pending.append(Counter(counts))

    def finish(self) -> None:
        rows, cols, vals, dl = [], [], [], []
        vocab = self.vocab
        for i, c in enumerate(self._pending):
            dl.append(sum(c.values()))
            for w, n in c.items():
                rows.append(vocab.setdefault(w, len(vocab))); cols.append(i); vals.append(n)
        self._pending = []
        r = np.asarray(rows, dtype=np.int32)
        order = np.argsort(r, kind="stable")
        r = r[order]
        self.docs = np.asarray(cols, dtype=np.int32)[order]
        self.tf = np.minimum(np.asarray(vals, dtype=np.int32)[order], 65535).astype(np.uint16)
        self.ptr = np.searchsorted(r, np.arange(len(vocab) + 1)).astype(np.int64)
        self.dl = np.asarray(dl, dtype=np.float32)
        self.avgdl = float(self.dl.mean()) if len(dl) else 1.0
        self._kinds()

    def _kinds(self) -> None:
        self.kinds_list = sorted({it.get("kind", "") for it in self.items})
        code = {k: i for i, k in enumerate(self.kinds_list)}
        self.kind_codes = np.asarray([code[it.get("kind", "")] for it in self.items], dtype=np.int16)

    # compatibility: df / tf as the old pickled attributes expected them (rarely used)
    @property
    def df(self) -> Counter:
        return Counter({w: int(self.ptr[j + 1] - self.ptr[j]) for w, j in self.vocab.items()})

    # cache ------------------------------------------------------------------------------------------------------------
    def save(self, path: Path, sig: str) -> None:
        words = "\n".join(sorted(self.vocab, key=self.vocab.get)).encode("utf-8")
        tmp = Path(str(path) + ".part.npz")
        np.savez(tmp, ptr=self.ptr, docs=self.docs, tf=self.tf, dl=self.dl, vocab=np.frombuffer(words, dtype=np.uint8),
                 sig=np.frombuffer(sig.encode(), dtype=np.uint8))
        tmp.replace(path)

    @classmethod
    def from_cache(cls, path: Path, items: List[dict], sig: str) -> Optional["BM25"]:
        try:
            z = np.load(path)
            if bytes(z["sig"]).decode() != sig:
                return None
            bm = cls()
            bm.items = items
            words = bytes(z["vocab"]).decode("utf-8").split("\n") if z["vocab"].size else []
            bm.vocab = {w: i for i, w in enumerate(words)}
            bm.ptr, bm.docs, bm.tf, bm.dl = z["ptr"], z["docs"], z["tf"], z["dl"]
            if len(bm.dl) != len(items):
                return None
            bm.avgdl = float(bm.dl.mean()) if len(bm.dl) else 1.0
            bm._kinds()
            return bm
        except Exception:  # noqa: BLE001
            return None

    # query ------------------------------------------------------------------------------------------------------------
    def search(self, query: str, k: int = 12, kinds: Optional[List[str]] = None, k1: float = 1.4, b: float = 0.7) -> List[dict]:
        q = tokenize(query)
        if not q or not self.items:
            return []
        n = len(self.items)
        scores = np.zeros(n, dtype=np.float32)
        norm = k1 * (1 - b + b * self.dl / self.avgdl)
        hit = False
        for t in q:
            j = self.vocab.get(t)
            if j is None:
                continue
            a, e = int(self.ptr[j]), int(self.ptr[j + 1])
            if a == e:
                continue
            d, f = self.docs[a:e], self.tf[a:e].astype(np.float32)
            idf = math.log(1 + (n - (e - a) + 0.5) / ((e - a) + 0.5))
            scores[d] += idf * f * (k1 + 1) / (f + norm[d])
            hit = True
        if not hit:
            return []
        if kinds:
            want = [self.kinds_list.index(x) for x in kinds if x in self.kinds_list]
            if not want:
                return []
            scores[~np.isin(self.kind_codes, want)] = 0
        nz = int(np.count_nonzero(scores))
        if not nz:
            return []
        top = min(k, nz)
        idx = np.argpartition(-scores, top - 1)[:top]
        idx = idx[np.argsort(-scores[idx], kind="stable")]
        return [dict(self.items[i], score=round(float(scores[i]), 2)) for i in idx]


class _Unpickler(pickle.Unpickler):
    """Packs built before the dict format pickled the BM25 class under the builder's module name: map it here."""
    def find_class(self, module, name):
        if name == "BM25":
            return _OldBM25
        return super().find_class(module, name)


class _OldBM25:                       # the class pickled by format-1 packs (attributes items, tf, df, avgdl)
    pass


def _load_bm25(data: bytes) -> BM25:
    """Packs of format 1 shipped index/bm25.pkl (items + term counts): turned into the postings index."""
    import io
    obj = _Unpickler(io.BytesIO(data)).load()
    items = obj.items if isinstance(obj, _OldBM25) else obj["items"]
    tfs = obj.tf if isinstance(obj, _OldBM25) else obj["tf"]
    bm = BM25()
    for it, c in zip(items, tfs or []):
        bm.add_counts(it, c)
    bm.finish()
    return bm


def compact_item(it: dict) -> dict:
    """A code chunk is written as header + span into raw/repo/<file> instead of repeating the code (pack format 2)."""
    if it.get("kind") == "chunk" and it.get("span") and "text" in it:
        hdr, _, body = it["text"].partition("\n")
        out = {k: v for k, v in it.items() if k != "text"}
        out["hdr"] = hdr
        out["len"] = len(body)
        return out
    return it


def load_items(pack_dir: Path) -> List[dict]:
    """items.jsonl of a pack, with code chunks materialised from raw/repo (format 2) - works for format 1 too."""
    pack_dir = Path(pack_dir)
    p = pack_dir / "items.jsonl"
    if not p.exists():
        return []
    texts: Dict[str, str] = {}
    out = []
    for ln in p.read_text(encoding="utf-8").splitlines():
        if not ln.strip():
            continue
        it = json.loads(ln)
        if "text" not in it and it.get("span"):
            f = it.get("file", "")
            if f not in texts:
                fp = pack_dir / "raw" / "repo" / f
                texts[f] = fp.read_text(encoding="utf-8", errors="replace") if fp.exists() else ""
            a, b = it["span"]
            it["text"] = it.get("hdr", "") + "\n" + texts[f][a:b]
        out.append(it)
    return out


class PackIndex:
    """index/bm25.pkl + index/vectors.npy + index/vector_ids.json inside a pack folder; embedding cache shared across packs."""

    def __init__(self, pack_dir: Path, emb_cfg: dict, llm=None, cache_dir: Optional[Path] = None, write_bm25: bool = False):
        self.pack_dir = Path(pack_dir)
        self.write_bm25 = write_bm25                  # format 2: no bm25.pkl in the pack - rebuilt from items.jsonl on load (~1 s)
        self.dir = Path(pack_dir) / "index"
        self.dir.mkdir(parents=True, exist_ok=True)
        self._explicit = set((emb_cfg or {}).keys())
        self.s = dict({"enabled": True, "deployment": "text-embedding-3-small", "dimensions": 512, "batch_size": 64, "min_score": 0.2,
                       "rrf_k": 60, "bm25_candidates": 40, "dense_candidates": 40}, **(emb_cfg or {}))
        self.llm = llm
        self.cache_dir = Path(cache_dir) if cache_dir else self.dir
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.bm25: Optional[BM25] = None
        self.ids: List[str] = []
        self.M: Optional[np.ndarray] = None
        self.by_key: Dict[str, dict] = {}
        self._qcache: Dict[str, List[float]] = {}
        self._rcache: "OrderedDict[str, List[dict]]" = OrderedDict()
        self.status = {"items": 0, "dense": False, "embedded_now": 0, "from_cache": 0, "error": "", "seconds": 0.0}

    # ------------------------------------------------------------------ build
    def build(self, items: List[dict], progress=None) -> dict:
        say = progress or (lambda m: None)
        t0 = time.time()
        bm = BM25()
        for it in items:
            bm.add(it)
        bm.finish()
        self.bm25 = bm
        if self.write_bm25:
            (self.dir / "bm25.pkl").write_bytes(pickle.dumps({"items": bm.items, "tf": bm.tf, "df": bm.df, "avgdl": bm.avgdl}, protocol=4))   # plain dict: loadable by any consumer
        else:
            old_p = self.dir / "bm25.pkl"
            if old_p.exists():
                old_p.unlink()
        self.by_key = {f"{it['kind']}|{it['ref']}": it for it in items}
        self.status.update({"items": len(items)})
        if not self.s.get("enabled") or self.llm is None:
            self.status.update({"dense": False, "error": "embeddings disabled" if not self.s.get("enabled") else "no model client"})
            return self._done(t0)
        if not self._resolve_deployment(say):
            return self._done(t0)
        cache = self._load_cache()
        max_chars = int(self.s.get("max_chars", 1200))
        texts = {k: (it.get("title", "") + "\n" + it.get("text", ""))[:max_chars] for k, it in self.by_key.items()}
        # which items get a dense vector (every item is in BM25 regardless): embeddings.dense_items = "all" | "head" (the
        # first chunk of every file + every non-chunk item - a tenth of the tokens, same recall on how-to / where questions)
        mode = str(self.s.get("dense_items", "head")).lower()
        per_file = int(self.s.get("chunks_per_file", 1))
        has_head = {it.get("file") for it in self.by_key.values() if it.get("kind") == "chunk" and str(it.get("ref", "")).endswith("#0")}

        def dense(it: dict) -> bool:
            if mode == "all":
                return True
            if it.get("kind") == "chunk":
                try:
                    return int(str(it.get("ref", "")).rsplit("#", 1)[-1]) < per_file
                except ValueError:
                    return True
            if it.get("kind") == "file" and it.get("ref") in has_head:
                return False                                   # the file's head chunk already carries its context header
            return True
        wanted = [k for k, it in self.by_key.items() if dense(it)]
        todo = [k for k in wanted if _h(texts[k]) not in cache]
        new = {}
        bs = int(self.s["batch_size"])
        max_tokens = int(self.s.get("max_batch_tokens", 12000))          # ~chars/4 per request - keeps one request well under the TPM quota
        batches, cur, cur_tok = [], [], 0
        for k in todo:
            t = len(texts[k]) // 4 + 8
            if cur and (len(cur) >= bs or cur_tok + t > max_tokens):
                batches.append(cur); cur, cur_tok = [], 0
            cur.append(k); cur_tok += t
        if cur:
            batches.append(cur)
        deadline = t0 + 60 * float(self.s.get("max_minutes", 8))
        failed, skipped = [0], [0]
        try:
            say(f"embedding {len(todo)} new items in {len(batches)} batches ({len(wanted) - len(todo)} from cache, {len(self.by_key) - len(wanted)} BM25-only by dense_items={mode}) ...")
            import concurrent.futures as cf
            lock = threading.Lock()
            done = [0]
            fh = self._cache_file().open("a", encoding="utf-8")

            def one(batch):
                if time.time() > deadline:                 # time cap: the rest stays BM25-only this build and is embedded next time
                    skipped[0] += len(batch)
                    return
                try:
                    vecs = self.llm.embed([texts[k] for k in batch], self.s)
                except Exception as e:  # noqa: BLE001
                    with lock:
                        failed[0] += len(batch)
                        if failed[0] <= len(batch):
                            log.warning("embedding batch failed (%s) - its items stay BM25-only this build", str(e)[:160])
                    return
                with lock:
                    for k, v in zip(batch, vecs):          # write-through: progress survives a later failure / time cap
                        h = _h(texts[k]); new[h] = v
                        fh.write(h + "\t" + json.dumps([round(x, 6) for x in v]) + "\n")
                    fh.flush()
                    done[0] += len(batch)
                    if done[0] % (bs * 10) < len(batch):
                        say(f"embedded {done[0]}/{len(todo)} ...")
            try:
                with cf.ThreadPoolExecutor(int(self.s.get("parallel", 2))) as ex:
                    for f in cf.as_completed([ex.submit(one, b) for b in batches]):
                        f.result()
            finally:
                fh.close()
        except Exception as e:  # noqa: BLE001
            self.status["error"] = f"{type(e).__name__}: {str(e)[:200]}"
            log.warning("embedding failed: %s", self.status["error"])
        if failed[0] or skipped[0]:
            self.status["partial"] = {"failed": failed[0], "time_capped": skipped[0]}
            say(f"dense index partial: {failed[0]} items failed (rate limit), {skipped[0]} left for the next build (time cap {self.s.get('max_minutes', 8)} min); BM25 covers them")
        cache.update(new)
        rows, ids = [], []
        for k in wanted:
            v = cache.get(_h(texts[k]))
            if v is not None:
                rows.append(v); ids.append(k)
        if rows:
            M = np.asarray(rows, dtype=np.float32)
            M /= (np.linalg.norm(M, axis=1, keepdims=True) + 1e-9)
            self.M, self.ids = M, ids
            np.save(self.dir / "vectors.npy", np.asarray(M, dtype=np.float16))     # float16: half the size, same ranking
            (self.dir / "vector_ids.json").write_text(json.dumps(ids), encoding="utf-8")
            self.status.update({"dense": True, "embedded_now": len(new), "from_cache": len(ids) - len(new)})
        return self._done(t0)

    def _resolve_deployment(self, say) -> bool:
        """Probes the configured embeddings deployment with one tiny call; on 404 DeploymentNotFound tries `deployment_candidates`
        in order and remembers the first that answers (data/cache/embeddings/deployment.txt)."""
        probe = self.cache_dir / "deployment.txt"
        tried = []
        cands = [self.s.get("deployment")] + [c for c in (self.s.get("deployment_candidates") or []) if c != self.s.get("deployment")]
        if probe.exists():
            known = probe.read_text(encoding="utf-8").strip()
            if known in cands:
                cands = [known] + [c for c in cands if c != known]
        versions = [self.s.get("api_version") or ""] + [v for v in ("2024-02-01", "2023-05-15") if v != (self.s.get("api_version") or "")]
        last_err = ""
        for c in cands:
            if not c:
                continue
            for ver in versions:
                self.s["deployment"], self.s["api_version"] = c, ver
                self.llm._emb_client = None                      # the client is bound to an api-version: rebuild it per attempt
                try:
                    self.llm.embed(["probe"], self.s)
                    probe.write_text(c, encoding="utf-8")
                    if tried:
                        say(f"embeddings: using deployment {c!r} (api-version {ver or 'same as chat'}) after {', '.join(tried)} failed")
                    return True
                except Exception as e:  # noqa: BLE001
                    msg = str(e)
                    last_err = f"{type(e).__name__}: {msg[:200]}"
                    if "DeploymentNotFound" in msg:
                        tried.append(c); break                   # the name is wrong - no point trying other api-versions
                    if "api-version" in msg.lower() or "apiversion" in msg.lower() or "404" in msg or "400" in msg:
                        tried.append(f"{c}@{ver or 'chat'}"); continue
                    self.status["error"] = f"{last_err} - BM25 only"
                    log.warning("embedding failed: %s", self.status["error"])
                    return False
        self.status["error"] = f"no embeddings deployment found (tried {', '.join(tried)}; last error {last_err}) - set embeddings.deployment to your Azure embeddings deployment name - BM25 only"
        log.warning(self.status["error"])
        return False

    def _done(self, t0):
        self.status["seconds"] = round(time.time() - t0, 1)
        self.status["embeddings"] = {k: self.s.get(k) for k in ("deployment", "dimensions", "api_version", "endpoint", "min_score", "rrf_k", "bm25_candidates", "dense_candidates")}
        (self.dir / "status.json").write_text(json.dumps(self.status, indent=1), encoding="utf-8")
        return self.status

    def _cache_file(self) -> Path:
        return self.cache_dir / f"emb_{re.sub(r'[^a-z0-9_-]', '_', str(self.s['deployment']).lower())}_{self.s['dimensions']}.jsonl"

    def _load_cache(self) -> Dict[str, List[float]]:
        out = {}
        f = self._cache_file()
        if f.exists():
            for ln in f.read_text(encoding="utf-8").splitlines():
                try:
                    h, v = ln.split("\t", 1); out[h] = json.loads(v)
                except ValueError:
                    continue
        return out

    # ------------------------------------------------------------------ load (consumers)
    def load(self, lazy: bool = True) -> bool:
        """Opens the pack's index. lazy=True only reads status / vectors and defers the BM25 index to the first search
        (a consumer that only reads facts or cards pays nothing). Returns False when the pack has no items."""
        self._loaded = False
        if not ((self.dir / "bm25.pkl").exists() or (self.pack_dir / "items.jsonl").exists()):
            return False
        st = self.dir / "status.json"
        if st.exists():
            try:
                saved = json.loads(st.read_text(encoding="utf-8"))
                self.status.update(saved)
                for k, v in (saved.get("embeddings") or {}).items():      # the pack knows its own embedding settings
                    if v not in (None, "") and k not in self._explicit:
                        self.s[k] = v
            except Exception:  # noqa: BLE001
                pass
        if not lazy:
            self._ensure()
        return True

    def _items_sig(self) -> str:
        p = self.pack_dir / "items.jsonl"
        st = p.stat()
        return f"{st.st_size}|{int(st.st_mtime)}|v2"

    def _ensure(self) -> None:
        if getattr(self, "_loaded", True) and self.bm25 is not None:
            return
        with _LOAD_LOCK:
            if self.bm25 is not None and getattr(self, "_loaded", False):
                return
            t0 = time.time()
            p = self.dir / "bm25.pkl"
            if p.exists():
                self.bm25 = _load_bm25(p.read_bytes())
            else:
                items = load_items(self.pack_dir)
                sig = self._items_sig()
                cache = self.dir / "bm25_cache.npz"
                bm = BM25.from_cache(cache, items, sig) if cache.exists() else None
                if bm is None:
                    bm = BM25()
                    for it in items:
                        bm.add(it)
                    bm.finish()
                    try:
                        bm.save(cache, sig)              # next open of this pack: ~20 ms
                    except OSError:
                        pass
                self.bm25 = bm
            self._by_key = {f"{it['kind']}|{it['ref']}": it for it in self.bm25.items}
            v, i = self.dir / "vectors.npy", self.dir / "vector_ids.json"
            if v.exists() and i.exists() and self.s.get("enabled"):
                try:
                    self.M = np.asarray(np.load(v), dtype=np.float32); self.ids = json.loads(i.read_text(encoding="utf-8"))
                    self.status["dense"] = len(self.ids) == self.M.shape[0]
                except Exception as e:  # noqa: BLE001
                    log.warning("vector store not loadable: %s", e)
            self.status["items"] = len(self._by_key)
            self.status["load_seconds"] = round(time.time() - t0, 3)
            self._loaded = True

    @property
    def by_key(self) -> Dict[str, dict]:
        if getattr(self, "_loaded", True) is False:
            self._ensure()
        return self._by_key

    @by_key.setter
    def by_key(self, v):
        self._by_key = v

    # ------------------------------------------------------------------ query
    def _embed_query(self, q: str):
        if self.llm is None:
            return None
        h = _h(q.strip().lower())
        v = self._qcache.get(h)
        if v is None:
            try:
                v = self.llm.embed([q[:2000]], self.s)[0]
            except Exception as e:  # noqa: BLE001
                log.warning("query embedding failed: %s", e)
                return None
            self._qcache[h] = v
        a = np.asarray(v, dtype=np.float32)
        return a / (np.linalg.norm(a) + 1e-9)

    def search(self, query: str, k: int = 12, kinds: Optional[List[str]] = None) -> List[dict]:
        if getattr(self, "_loaded", True) is False:
            self._ensure()
        if self.bm25 is None:
            return []
        ck = json.dumps([query.strip().lower(), sorted(kinds or []), int(k)])
        if ck in self._rcache:
            self._rcache.move_to_end(ck)
            return [dict(x) for x in self._rcache[ck]]
        n_b, n_d, rrf_k = int(self.s["bm25_candidates"]), int(self.s["dense_candidates"]), float(self.s["rrf_k"])
        ranks: Dict[str, dict] = {}
        for r, h in enumerate(self.bm25.search(query, k=n_b, kinds=kinds)):
            key = f"{h['kind']}|{h['ref']}"
            ranks[key] = {"item": h, "bm25_rank": r + 1, "score": 1.0 / (rrf_k + r + 1)}
        if self.M is not None and self.ids:
            qv = self._embed_query(query)
            if qv is not None:
                sims = self.M @ qv
                r = 0
                for j in np.argsort(-sims)[: n_d * 3]:
                    key = self.ids[int(j)]
                    it = self.by_key.get(key)
                    if it is None or (kinds and it["kind"] not in kinds) or float(sims[j]) < float(self.s["min_score"]):
                        continue
                    r += 1
                    e = ranks.setdefault(key, {"item": dict(it, score=0.0), "score": 0.0})
                    e["dense_rank"], e["dense"] = r, round(float(sims[j]), 3)
                    e["score"] += 1.0 / (rrf_k + r)
                    if r >= n_d:
                        break
        idents = {m.lower() for m in _IDENT.findall(query)}
        for e in ranks.values():
            ref, title = str(e["item"].get("ref", "")).lower(), str(e["item"].get("title", "")).lower()
            if any(i == ref or ref.endswith("." + i) or ref.endswith("/" + i) or i == title for i in idents):
                e["score"] += 0.02
        ordered = sorted(ranks.values(), key=lambda e: -e["score"])
        out, per_kind = [], Counter()
        for e in ordered:
            kind = e["item"]["kind"]
            if per_kind[kind] >= (max(4, (2 * k) // 3) if kind in ("chunk", "file") else max(3, k // 2)) and len(ordered) > k:
                continue
            per_kind[kind] += 1
            via = "both" if "bm25_rank" in e and "dense_rank" in e else ("dense" if "dense_rank" in e else "bm25")
            out.append(dict(e["item"], score=round(e["score"] * 100, 2), via=via, dense=e.get("dense")))
            if len(out) >= k:
                break
        self._rcache[ck] = [dict(x) for x in out]
        while len(self._rcache) > 500:
            self._rcache.popitem(last=False)
        return out
