"""Deterministic validation of generated files (no model): syntax per language, notebook structure, Airflow DAG
sanity, and the rule list the knowledge agent extracted from the standards documents (regex rules)."""
from __future__ import annotations

import ast
import json
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import List

SEV = ("critical", "high", "medium", "low", "info")


def language_of(path: str, declared: str = "") -> str:
    d = (declared or "").lower()
    if d in ("airflow_dag", "dag"):
        return "airflow_dag"
    ext = Path(path).suffix.lower().lstrip(".")
    return {"py": "python", "sql": "sql", "r": "r", "ipynb": "ipynb", "yaml": "yaml", "yml": "yaml", "json": "json",
            "sh": "shell", "md": "markdown"}.get(ext, d or "text")


def validate_file(path: str, content: str, language: str = "", rules: List[dict] = None, sql_dialect: str = "postgres",
                  existing: str = None) -> List[dict]:
    """existing: the file as it is in the repository (modify mode) - statements that were already there are never
    reported as syntax errors (the parser cannot know every Greenplum / Jinja construct; what runs in production is right)."""
    lang = language_of(path, language)
    findings = []
    if lang in ("python", "airflow_dag"):
        findings += _python(path, content)
        if lang == "airflow_dag" or "DAG(" in content or "from airflow" in content:
            findings += _airflow(path, content)
    elif lang == "sql":
        findings += _sql(path, content, sql_dialect, existing)
    elif lang == "r":
        findings += _r(path, content)
    elif lang == "ipynb":
        findings += _ipynb(path, content)
    elif lang == "yaml":
        findings += _yaml(path, content)
    elif lang == "json":
        findings += _json(path, content)
    if not content.strip():
        findings.append(_f(path, "critical", "syntax", "file is empty"))
    findings += _rules(path, content, lang, rules or [])
    return findings


def _f(path, sev, kind, msg, line=0, rule=""):
    return {"path": path, "severity": sev, "kind": kind, "message": msg, "line": line, "rule": rule}


# ----------------------------------------------------------------------------- languages
def _python(path, content):
    out = []
    try:
        tree = ast.parse(content)
    except SyntaxError as e:
        return [_f(path, "critical", "syntax", f"Python syntax error: {e.msg}", e.lineno or 0)]
    names = set()
    imported = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imported.update(a.asname or a.name.split(".")[0] for a in node.names)
        elif isinstance(node, ast.ImportFrom):
            imported.update(a.asname or a.name for a in node.names)
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            names.add(node.name)
    if re.search(r"(?m)^\s*(print\(.*password|password\s*=\s*['\"][^'\"]{4,}['\"])", content):
        out.append(_f(path, "high", "security", "a literal password appears in the code"))
    if re.search(r"(?i)(api[_-]?key|secret|token)\s*=\s*['\"][A-Za-z0-9+/=_-]{12,}['\"]", content):
        out.append(_f(path, "critical", "security", "a literal secret / token / API key appears in the code"))
    if "TODO" in content or "FIXME" in content:
        out.append(_f(path, "low", "completeness", "TODO / FIXME left in the file"))
    try:
        from pyflakes.api import check as pf_check
        from pyflakes.reporter import Reporter
        import io
        buf = io.StringIO()
        pf_check(content, path, Reporter(buf, buf))
        for line in buf.getvalue().splitlines():
            m = re.match(r".*:(\d+):\d*:?\s*(.*)", line)
            if m and "imported but unused" not in m.group(2):
                out.append(_f(path, "medium", "lint", m.group(2), int(m.group(1))))
    except Exception:  # noqa: BLE001  (pyflakes optional)
        pass
    return out


def _airflow(path, content):
    out = []
    if "DAG(" not in content and "@dag" not in content:
        out.append(_f(path, "high", "airflow", "no DAG object defined (DAG(...) or @dag)"))
    if "dag_id" not in content and "DAG(" in content and not re.search(r"DAG\(\s*['\"]", content):
        out.append(_f(path, "medium", "airflow", "DAG created without an explicit dag_id"))
    if re.search(r"(?m)^(?!\s)(?!from|import|#|\"\"\"|'''|def |class |with |@|[A-Za-z_][\w]*\s*=|\)|\s*$)", content) and False:
        pass
    if "schedule" not in content and "schedule_interval" not in content:
        out.append(_f(path, "low", "airflow", "no schedule / schedule_interval given (None is fine but be explicit)"))
    if "catchup" not in content:
        out.append(_f(path, "low", "airflow", "catchup not set explicitly (default True may backfill)"))
    return out


_JINJA_QUOTED = re.compile(r"'\s*\{\{.*?\}\}\s*'", re.S)
_JINJA = re.compile(r"\{\{.*?\}\}|\{%.*?%\}|\$\{[^}]*\}", re.S)


def _sql_stmts(content: str) -> List[str]:
    return [s for s in content.split(";") if s.strip() and not re.fullmatch(r"(?s)\s*(--[^\n]*\n?\s*)*", s)]


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"--[^\n]*", "", s)).strip().lower()


def _sql_body(s: str) -> str:
    """Make a templated Greenplum statement parseable: quoted Jinja -> string literal, bare Jinja -> identifier,
    Greenplum-only clauses removed (DISTRIBUTED BY / RANDOMLY, WITH (appendonly...))."""
    body = _JINJA_QUOTED.sub("'__param__'", s)
    body = _JINJA.sub("__param__", body)
    body = re.sub(r"(?is)\bdistributed\s+(by\s*\([^)]*\)|randomly|replicated)", "", body)
    body = re.sub(r"(?is)\bwith\s*\(\s*(appendonly|appendoptimized|orientation|compresstype|compresslevel)[^)]*\)", "", body)
    body = re.sub(r"(?is)\bpartition\s+by\s+(range|list)\s*\([^)]*\)\s*\(.*\)\s*$", "", body)
    return body


def _unbalanced(s: str) -> str:
    """A cheap, dialect-free check: parentheses and quotes must balance (comments and string contents ignored)."""
    t = re.sub(r"--[^\n]*", "", s)
    t = re.sub(r"/\*.*?\*/", "", t, flags=re.S)
    t = re.sub(r"'(?:[^']|'')*'", "''", t)
    if t.count("'") % 2:
        return "unbalanced single quotes"
    depth = 0
    for ch in t:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth < 0:
                return "closing parenthesis without an opening one"
    if depth:
        return f"{depth} parenthesis(es) not closed"
    if t.count('"') % 2:
        return "unbalanced double quotes"
    return ""


def _sql(path, content, dialect, existing=None):
    out = []
    old = {_norm(s) for s in _sql_stmts(existing)} if existing else set()
    stmts = _sql_stmts(content)
    for i, s in enumerate(stmts, 1):
        if _norm(s) in old:
            continue                                            # unchanged statement from the repository: trusted
        line = content[:content.index(s)].count("\n") + 1 if s in content else 0
        ub = _unbalanced(s)
        if ub:
            out.append(_f(path, "high", "syntax", f"SQL statement {i}: {ub}", line))
            continue
        try:
            import sqlglot
            import logging as _lg
            _lg.getLogger("sqlglot").setLevel(_lg.ERROR)
            try:
                sqlglot.parse_one(_sql_body(s), read=dialect)
            except Exception as e:  # noqa: BLE001
                msg = str(e).split("\n")[0][:200]
                if "Invalid expression" in msg or "Required keyword" in msg or "Expected" in msg or "Expecting" in msg \
                        or "ParseError" in type(e).__name__:
                    # the parser does not know every Greenplum / templated construct: a warning for the reviewer, never a blocker
                    out.append(_f(path, "medium", "syntax_warning", f"SQL statement {i} could not be fully parsed ({dialect}) - "
                                                                      f"check it by hand: {msg}", line))
        except ImportError:
            pass
    if re.search(r"(?i)\bselect\s+\*\s+from\b", content) and re.search(r"(?i)\binsert\s+into\b", content):
        out.append(_f(path, "medium", "quality", "INSERT ... SELECT * - list the columns explicitly"))
    if re.search(r"(?i)\bdrop\s+table\b(?!\s+if\s+exists)", content):
        out.append(_f(path, "medium", "safety", "DROP TABLE without IF EXISTS"))
    return out


def _r(path, content):
    out = []
    if shutil.which("Rscript"):
        with tempfile.NamedTemporaryFile("w", suffix=".R", delete=False) as f:
            f.write(content)
        r = subprocess.run(["Rscript", "-e", f"invisible(parse(file='{f.name}'))"], capture_output=True, text=True, timeout=60)
        if r.returncode != 0:
            out.append(_f(path, "critical", "syntax", "R parse error: " + (r.stderr.strip().splitlines() or ["?"])[-1][:200]))
    else:
        for o, c in (("(", ")"), ("{", "}"), ("[", "]")):
            if content.count(o) != content.count(c):
                out.append(_f(path, "high", "syntax", f"unbalanced {o}{c} in R file"))
    return out


def _ipynb(path, content):
    out = []
    try:
        nb = json.loads(content)
    except Exception as e:  # noqa: BLE001
        return [_f(path, "critical", "syntax", f"notebook is not valid JSON: {e}")]
    if "cells" not in nb or "nbformat" not in nb:
        out.append(_f(path, "critical", "syntax", "notebook lacks cells / nbformat"))
        return out
    for i, c in enumerate(nb.get("cells", []), 1):
        if c.get("cell_type") == "code":
            src = "".join(c.get("source", []))
            src = re.sub(r"(?m)^\s*[%!].*$", "", src)                     # magics / shell lines
            try:
                ast.parse(src)
            except SyntaxError as e:
                out.append(_f(path, "critical", "syntax", f"cell {i}: Python syntax error: {e.msg}", e.lineno or 0))
    return out


def _yaml(path, content):
    try:
        import yaml
        yaml.safe_load(content)
        return []
    except Exception as e:  # noqa: BLE001
        return [_f(path, "critical", "syntax", f"YAML does not parse: {str(e)[:200]}")]


def _json(path, content):
    try:
        json.loads(content)
        return []
    except Exception as e:  # noqa: BLE001
        return [_f(path, "critical", "syntax", f"JSON does not parse: {e}")]


# ----------------------------------------------------------------------------- rules from the standards
def _rules(path, content, lang, rules):
    out = []
    for r in rules:
        try:
            langs = [x.lower() for x in (r.get("languages") or [])]
            if langs and lang not in langs and "any" not in langs:
                continue
            pat = r.get("pattern", "")
            if not pat:
                continue
            rx = re.compile(pat, re.I | re.M)
            if r.get("must_match"):
                if not rx.search(content):
                    out.append(_f(path, r.get("severity", "medium"), "standard", r.get("message", f"required pattern missing: {pat}"), 0, r.get("id", "")))
            else:
                for m in rx.finditer(content):
                    line = content.count("\n", 0, m.start()) + 1
                    out.append(_f(path, r.get("severity", "medium"), "standard", r.get("message", f"forbidden pattern: {pat}"), line, r.get("id", "")))
                    break
        except re.error:
            continue
    return out


def score(findings: List[dict]) -> int:
    pen = {"critical": 40, "high": 15, "medium": 5, "low": 1, "info": 0}
    return max(0, 100 - sum(pen.get(f.get("severity", "low"), 1) for f in findings))
