"""Configuration + runtime secrets (never persisted).

`secrets:` in the yaml maps a secret name to the ENVIRONMENT VARIABLE that carries it in the web app; the notebook
asks with a hidden prompt when the variable is not set. Per-user tokens (git, Greenplum) never go through here: they
are entered in the UI and kept in the user's in-memory session.
"""
from __future__ import annotations

import getpass
import logging
import os
from pathlib import Path
from typing import Dict, Optional

import yaml

log = logging.getLogger(__name__)

PACKAGE_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG = PACKAGE_ROOT / "config" / "agiledev_config.yaml"

_SECRETS: Dict[str, str] = {}
_LABELS = {"llm_api_key": "Azure OpenAI key", "embeddings_api_key": "Azure OpenAI EMBEDDINGS key (only if the embedder is on another resource)", "server_secret": "server cookie secret",
           "oidc_client_secret": "OIDC client secret"}


class Config(dict):
    def __getattr__(self, k):
        try:
            v = self[k]
        except KeyError as e:
            raise AttributeError(k) from e
        return Config(v) if isinstance(v, dict) else v

    def path(self, rel: str) -> Path:
        p = Path(rel)
        return p if p.is_absolute() else PACKAGE_ROOT / p


def load_config(path: Optional[str] = None) -> Config:
    p = Path(path) if path else DEFAULT_CONFIG
    cfg = Config(yaml.safe_load(p.read_text(encoding="utf-8")) or {})
    cfg["_path"] = str(p)
    # auth profile: config/auth/<name>.yaml replaces the auth block. Chosen by the environment variable AGILEDEV_AUTH_PROFILE
    # (web app: dev | header | oidc), else by `auth_profile:` in the main config, else the main config's own auth block.
    prof = os.environ.get("AGILEDEV_AUTH_PROFILE", "") or str(cfg.get("auth_profile") or "")
    if prof:
        pf = p.parent / "auth" / f"{prof}.yaml"
        if not pf.exists():
            raise RuntimeError(f"auth profile {prof!r} not found: {pf}")
        cfg["auth"] = (yaml.safe_load(pf.read_text(encoding="utf-8")) or {}).get("auth") or {}
        cfg["_auth_profile"] = prof
        log.info("auth profile: %s (%s)", prof, pf)
    log.info("config loaded: %s", p)
    return cfg


def env_var_for(cfg: Config, name: str) -> str:
    return str((cfg.get("secrets") or {}).get(name) or f"AGILEDEV_{name.upper()}")


def get_secret(cfg: Config, name: str, allow_prompt: bool = True, required: bool = True) -> str:
    """cache -> environment variable (name from config) -> hidden prompt (notebook) -> error."""
    if name in _SECRETS:
        return _SECRETS[name]
    env = env_var_for(cfg, name)
    val = os.environ.get(env, "")
    if not val and allow_prompt:
        try:
            val = getpass.getpass(f"{_LABELS.get(name, name)} (env {env} not set; input hidden): ").strip()
        except Exception:  # noqa: BLE001  (no terminal)
            val = ""
    if not val:
        if required:
            raise RuntimeError(f"{_LABELS.get(name, name)} not provided: set environment variable {env}")
        return ""
    _SECRETS[name] = val
    return val


def set_secret(name: str, value: str) -> None:
    _SECRETS[name] = value


def ssl_verify(value):
    if isinstance(value, str) and value.lower() not in ("true", "false"):
        return value
    return not (isinstance(value, str) and value.lower() == "false") and bool(value)


def fmt_secs(seconds) -> str:
    """'45s' below a minute, '1413s (23.6 min)' from a minute on - every screen and chat line uses this."""
    try:
        v = float(seconds)
    except (TypeError, ValueError):
        return str(seconds)
    base = f"{v:.0f}s" if v >= 10 else f"{v:.1f}s"
    return base + (f" ({v / 60:.1f} min)" if v >= 60 else "")
