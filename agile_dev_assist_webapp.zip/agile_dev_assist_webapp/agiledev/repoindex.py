"""Repository index: every code file -> language, size, symbols (functions / classes / tables / DAG ids), head.
Retrieval: BM25-style scoring of a query (story text, plan) against path + symbols + content tokens, so the agents
see the handful of existing files that matter (patterns, conventions, the file a change belongs to)."""
from __future__ import annotations

import json
import math
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, List, Optional

LANG = {"py": "python", "sql": "sql", "r": "r", "ipynb": "ipynb", "yaml": "yaml", "yml": "yaml", "json": "json",
        "sh": "shell", "md": "markdown", "txt": "text", "cfg": "config", "ini": "config", "toml": "config", "csv": "csv"}
_TOK = re.compile(r"[A-Za-z_][A-Za-z0-9_]{2,}")
_STOP = set("the and for with from this that into select where join order group having union insert update delete "
            "create table view import def class return none true false self print else elif while break".split())


def tokenize(text: str) -> List[str]:
    out = []
    for t in _TOK.findall(text or ""):
        t = t.lower()
        if t in _STOP:
            continue
        out.append(t)
        if "_" in t:
            out.extend(p for p in t.split("_") if len(p) > 2 and p not in _STOP)
    return out


def symbols_of(lang: str, text: str) -> List[str]:
    syms = []
    if lang == "python":
        syms += re.findall(r"(?m)^\s*(?:def|class)\s+([A-Za-z_]\w*)", text)
        syms += re.findall(r"dag_id\s*=\s*['\"]([^'\"]+)['\"]", text)
        syms += re.findall(r"task_id\s*=\s*['\"]([^'\"]+)['\"]", text)
    elif lang == "sql":
        syms += re.findall(r"(?i)(?:create\s+(?:or\s+replace\s+)?(?:temp\s+|temporary\s+)?(?:table|view)|insert\s+into|from|join)\s+([A-Za-z_][\w.{}]*)", text)
    elif lang == "r":
        syms += re.findall(r"(?m)^\s*([A-Za-z_.][\w.]*)\s*(?:<-|=)\s*function", text)
    elif lang == "ipynb":
        try:
            nb = json.loads(text)
            for c in nb.get("cells", []):
                src = "".join(c.get("source", []))
                syms += re.findall(r"(?m)^\s*(?:def|class)\s+([A-Za-z_]\w*)", src)
        except Exception:  # noqa: BLE001
            pass
    return list(dict.fromkeys(s.strip("{}") for s in syms))[:80]


class RepoIndex:
    CACHE = ".agiledev_index.pkl"

    def __init__(self, root: Path, name: str = "", max_files: int = 6000):
        self.root = Path(root)
        self.name = name or self.root.name
        self.files: Dict[str, dict] = {}
        self.df: Counter = Counter()
        self.tf: Dict[str, Counter] = {}
        self.max_files = max_files
        if not self._load_cache():
            self._build()
            self._save_cache()

    # the index of a downloaded repository is kept next to it and reused while the download marker is unchanged
    def _stamp(self):
        m = self.root / ".agiledev_ref"
        try:
            return (m.read_text() if m.exists() else "") + f"|{self.max_files}|{sum(1 for p in self.root.rglob('*') if p.is_file())}"
        except Exception:  # noqa: BLE001
            return ""

    def _load_cache(self) -> bool:
        import pickle
        p = self.root / self.CACHE
        if not p.exists():
            return False
        try:
            d = pickle.loads(p.read_bytes())
            if d.get("stamp") != self._stamp():
                return False
            self.files, self.df, self.tf = d["files"], d["df"], d["tf"]
            return True
        except Exception:  # noqa: BLE001
            return False

    def _save_cache(self) -> None:
        import pickle
        try:
            (self.root / self.CACHE).write_bytes(pickle.dumps({"stamp": self._stamp(), "files": self.files, "df": self.df, "tf": self.tf}, protocol=4))
        except Exception:  # noqa: BLE001
            pass

    def _build(self):
        n = 0
        for p in sorted(self.root.rglob("*")):
            if not p.is_file() or p.name.startswith(".") or "/." in str(p.relative_to(self.root)).replace("\\", "/") or ".git_checkout" in p.parts:
                continue
            rel = str(p.relative_to(self.root)).replace("\\", "/")
            ext = p.suffix.lower().lstrip(".")
            lang = LANG.get(ext, ext or "text")
            try:
                text = p.read_text(encoding="utf-8", errors="replace")
            except Exception:  # noqa: BLE001
                continue
            syms = symbols_of(lang, text)
            self.files[rel] = {"path": rel, "language": lang, "chars": len(text), "lines": text.count("\n") + 1,
                               "symbols": syms, "head": text[:300], "folder": rel.rsplit("/", 1)[0] if "/" in rel else ""}
            toks = Counter(tokenize(rel) * 3 + tokenize(" ".join(syms)) * 2 + tokenize(text[:20000]))
            self.tf[rel] = toks
            self.df.update(toks.keys())
            n += 1
            if n >= self.max_files:
                break

    # ------------------------------------------------------------------ retrieval
    def search(self, query: str, k: int = 12, languages: Optional[List[str]] = None, folder_prefix: str = "") -> List[dict]:
        q = Counter(tokenize(query))
        if not q:
            return []
        N = max(1, len(self.files))
        scores = []
        for rel, tf in self.tf.items():
            f = self.files[rel]
            if languages and f["language"] not in languages:
                continue
            if folder_prefix and not rel.startswith(folder_prefix):
                continue
            s, dl = 0.0, sum(tf.values()) or 1
            for t, qn in q.items():
                if t in tf:
                    idf = math.log(1 + (N - self.df[t] + 0.5) / (self.df[t] + 0.5))
                    tfv = tf[t] * 2.2 / (tf[t] + 1.2 * (0.25 + 0.75 * dl / 400))
                    s += idf * tfv * min(qn, 3)
            if s > 0:
                scores.append((s, rel))
        scores.sort(reverse=True)
        return [dict(self.files[rel], score=round(s, 2)) for s, rel in scores[:k]]

    def read(self, rel: str, max_chars: int = 60000) -> str:
        p = self.root / rel
        if not p.is_file() or rel not in self.files:
            raise FileNotFoundError(rel)
        t = p.read_text(encoding="utf-8", errors="replace")
        return t if len(t) <= max_chars else t[:max_chars] + f"\n...[truncated {len(t) - max_chars} chars]"

    def grep(self, pattern: str, max_hits: int = 40, flags=re.I) -> List[dict]:
        rx = re.compile(pattern, flags)
        hits = []
        for rel in self.files:
            try:
                for i, line in enumerate((self.root / rel).read_text(encoding="utf-8", errors="replace").splitlines(), 1):
                    if rx.search(line):
                        hits.append({"path": rel, "line": i, "text": line.strip()[:200]})
                        if len(hits) >= max_hits:
                            return hits
            except Exception:  # noqa: BLE001
                continue
        return hits

    def summary(self) -> dict:
        langs = Counter(f["language"] for f in self.files.values())
        folders = Counter(f["folder"].split("/")[0] if f["folder"] else "(root)" for f in self.files.values())
        return {"name": self.name, "files": len(self.files), "languages": dict(langs.most_common()),
                "top_folders": dict(folders.most_common(25)),
                "folder_tree": self.tree(depth=3)}

    def tree(self, depth: int = 3, max_entries: int = 300) -> List[str]:
        seen = defaultdict(int)
        for rel in self.files:
            parts = rel.split("/")
            for d in range(1, min(depth, len(parts) - 1) + 1):
                seen["/".join(parts[:d]) + "/"] += 1
        out = sorted(seen.items())[:max_entries]
        return [f"{p} ({n} files)" for p, n in out]

    def examples(self, language: str, folder: str = "", k: int = 2) -> List[str]:
        cands = [r for r, f in self.files.items() if f["language"] == language and (not folder or r.startswith(folder))]
        cands.sort(key=lambda r: abs(self.files[r]["chars"] - 4000))
        return cands[:k]


    # ------------------------------------------------------------------ change-impact helpers
    def registration_candidates(self, folder: str, k: int = 6) -> List[dict]:
        """Files that REGISTER the scripts of a folder (a DAG listing SQL tasks, a config list, a task-name file):
        every file outside the folder that mentions the stems of several files of that folder."""
        folder = folder.strip("/")
        sibs = [r for r in self.files if (r.rsplit("/", 1)[0] if "/" in r else "") == folder]
        stems = {Path(r).stem for r in sibs if len(Path(r).stem) > 3}
        if not stems:
            return []
        hits = []
        for rel in self.files:
            if rel.startswith(folder + "/") or self.files[rel]["language"] not in ("python", "yaml", "json", "config", "text", "shell"):
                continue
            try:
                text = (self.root / rel).read_text(encoding="utf-8", errors="replace")
            except Exception:  # noqa: BLE001
                continue
            found = [st for st in stems if st in text]
            if len(found) >= max(2, min(3, len(stems) // 4)):
                sample = next((l.strip() for l in text.splitlines() if found[0] in l), "")[:200]
                hits.append({"path": rel, "mentions": len(found), "of": len(stems), "example_line": sample,
                             "reason": f"mentions {len(found)} of the {len(stems)} scripts of {folder}/ - new scripts there must be registered here"})
        hits.sort(key=lambda h: -h["mentions"])
        return hits[:k]

    def references(self, name: str, max_hits: int = 40) -> List[dict]:
        """Where a table / function / file stem is used (impact of changing it)."""
        return self.grep(r"\b" + re.escape(name) + r"\b", max_hits)
