"""Repository index: every code file -> language, size, symbols (functions / classes / tables / DAG ids), head.
Retrieval: BM25-style scoring of a query (story text, plan) against path + symbols + content tokens, so the agents
see the handful of existing files that matter (patterns, conventions, the file a change belongs to)."""
from __future__ import annotations

import json
import math
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, List, Optional

LANG = {"py": "python", "sql": "sql", "r": "r", "ipynb": "ipynb", "yaml": "yaml", "yml": "yaml", "json": "json",
        "sh": "shell", "md": "markdown", "txt": "text", "cfg": "config", "ini": "config", "toml": "config", "csv": "csv"}
_TOK = re.compile(r"[A-Za-z_][A-Za-z0-9_]{2,}")
_STOP = set("the and for with from this that into select where join order group having union insert update delete "
            "create table view import def class return none true false self print else elif while break".split())


def tokenize(text: str) -> List[str]:
    out = []
    for t in _TOK.findall(text or ""):
        t = t.lower()
        if t in _STOP:
            continue
        out.append(t)
        if "_" in t:
            out.extend(p for p in t.split("_") if len(p) > 2 and p not in _STOP)
    return out


def symbols_of(lang: str, text: str) -> List[str]:
    syms = []
    if lang == "python":
        syms += re.findall(r"(?m)^\s*(?:def|class)\s+([A-Za-z_]\w*)", text)
        syms += re.findall(r"dag_id\s*=\s*['\"]([^'\"]+)['\"]", text)
        syms += re.findall(r"task_id\s*=\s*['\"]([^'\"]+)['\"]", text)
    elif lang == "sql":
        syms += re.findall(r"(?i)(?:create\s+(?:or\s+replace\s+)?(?:temp\s+|temporary\s+)?(?:table|view)|insert\s+into|from|join)\s+([A-Za-z_][\w.{}]*)", text)
    elif lang == "r":
        syms += re.findall(r"(?m)^\s*([A-Za-z_.][\w.]*)\s*(?:<-|=)\s*function", text)
    elif lang == "ipynb":
        try:
            nb = json.loads(text)
            for c in nb.get("cells", []):
                src = "".join(c.get("source", []))
                syms += re.findall(r"(?m)^\s*(?:def|class)\s+([A-Za-z_]\w*)", src)
        except Exception:  # noqa: BLE001
            pass
    return list(dict.fromkeys(s.strip("{}") for s in syms))[:80]


class RepoIndex:
    CACHE = ".agiledev_index.pkl"

    def __init__(self, root: Path, name: str = "", max_files: int = 6000):
        self.root = Path(root)
        self.name = name or self.root.name
        self.files: Dict[str, dict] = {}
        self.df: Counter = Counter()
        self.tf: Dict[str, Counter] = {}
        self.max_files = max_files
        self.idents: Dict[str, set] = {}          # identifier -> files that contain it (built once; makes every look-up a dict hit)
        self._texts: Dict[str, str] = {}          # file texts read on demand and kept in memory (no repeated disk scans)
        self._texts_bytes = 0
        if not self._load_cache():
            self._build()
            self._save_cache()
        if not self.idents:                        # cache from an older version: build the identifier index now
            self._build_idents()
            self._save_cache()

    # the index of a downloaded repository is kept next to it and reused while the download marker is unchanged
    def _stamp(self):
        m = self.root / ".agiledev_ref"
        try:
            return (m.read_text() if m.exists() else "") + f"|{self.max_files}|{sum(1 for p in self.root.rglob('*') if p.is_file())}"
        except Exception:  # noqa: BLE001
            return ""

    def _load_cache(self) -> bool:
        import pickle
        p = self.root / self.CACHE
        if not p.exists():
            return False
        try:
            d = pickle.loads(p.read_bytes())
            if d.get("stamp") != self._stamp():
                return False
            self.files, self.df, self.tf = d["files"], d["df"], d["tf"]
            self.idents = d.get("idents") or {}
            return True
        except Exception:  # noqa: BLE001
            return False

    def _save_cache(self) -> None:
        import pickle
        try:
            (self.root / self.CACHE).write_bytes(pickle.dumps({"stamp": self._stamp(), "files": self.files, "df": self.df, "tf": self.tf, "idents": self.idents}, protocol=4))
        except Exception:  # noqa: BLE001
            pass

    def _build(self):
        n = 0
        for p in sorted(self.root.rglob("*")):
            if not p.is_file() or p.name.startswith(".") or "/." in str(p.relative_to(self.root)).replace("\\", "/") or ".git_checkout" in p.parts:
                continue
            rel = str(p.relative_to(self.root)).replace("\\", "/")
            ext = p.suffix.lower().lstrip(".")
            lang = LANG.get(ext, ext or "text")
            try:
                text = p.read_text(encoding="utf-8", errors="replace")
            except Exception:  # noqa: BLE001
                continue
            syms = symbols_of(lang, text)
            self.files[rel] = {"path": rel, "language": lang, "chars": len(text), "lines": text.count("\n") + 1,
                               "symbols": syms, "head": text[:300], "folder": rel.rsplit("/", 1)[0] if "/" in rel else ""}
            toks = Counter(tokenize(rel) * 3 + tokenize(" ".join(syms)) * 2 + tokenize(text[:20000]))
            self.tf[rel] = toks
            self.df.update(toks.keys())
            self._add_idents(rel, text)
            n += 1
            if n >= self.max_files:
                break

    _IDENT = re.compile(r"[A-Za-z_][A-Za-z0-9_]{3,}")

    def _add_idents(self, rel: str, text: str) -> None:
        for w in set(self._IDENT.findall(text[:400000])):
            self.idents.setdefault(w.lower(), set()).add(rel)

    def _build_idents(self) -> None:
        self.idents = {}
        for rel in self.files:
            self._add_idents(rel, self.text(rel))

    def text(self, rel: str) -> str:
        """File text, read once and kept in memory (bounded): the look-ups below never rescan the repository on disk."""
        t = self._texts.get(rel)
        if t is None:
            try:
                t = (self.root / rel).read_text(encoding="utf-8", errors="replace")
            except Exception:  # noqa: BLE001
                t = ""
            if self._texts_bytes + len(t) <= 96 * 1024 * 1024:
                self._texts[rel] = t
                self._texts_bytes += len(t)
        return t

    def files_with(self, *words: str) -> set:
        """Files whose text contains ALL the given identifiers (dict look-ups, no file reads)."""
        sets = [self.idents.get(w.lower(), set()) for w in words if w]
        if not sets:
            return set()
        out = set(sets[0])
        for x in sets[1:]:
            out &= x
        return out

    def _line_with(self, rel: str, word: str) -> tuple:
        rx = re.compile(r"\b" + re.escape(word) + r"\b", re.I)
        for i, ln in enumerate(self.text(rel).splitlines(), 1):
            if rx.search(ln):
                return i, ln.strip()[:200]
        return 0, ""

    # ------------------------------------------------------------------ retrieval
    def search(self, query: str, k: int = 12, languages: Optional[List[str]] = None, folder_prefix: str = "") -> List[dict]:
        q = Counter(tokenize(query))
        if not q:
            return []
        N = max(1, len(self.files))
        scores = []
        for rel, tf in self.tf.items():
            f = self.files[rel]
            if languages and f["language"] not in languages:
                continue
            if folder_prefix and not rel.startswith(folder_prefix):
                continue
            s, dl = 0.0, sum(tf.values()) or 1
            for t, qn in q.items():
                if t in tf:
                    idf = math.log(1 + (N - self.df[t] + 0.5) / (self.df[t] + 0.5))
                    tfv = tf[t] * 2.2 / (tf[t] + 1.2 * (0.25 + 0.75 * dl / 400))
                    s += idf * tfv * min(qn, 3)
            if s > 0:
                scores.append((s, rel))
        scores.sort(reverse=True)
        return [dict(self.files[rel], score=round(s, 2)) for s, rel in scores[:k]]

    def read(self, rel: str, max_chars: int = 60000) -> str:
        p = self.root / rel
        if not p.is_file() or rel not in self.files:
            raise FileNotFoundError(rel)
        t = p.read_text(encoding="utf-8", errors="replace")
        return t if len(t) <= max_chars else t[:max_chars] + f"\n...[truncated {len(t) - max_chars} chars]"

    def grep(self, pattern: str, max_hits: int = 40, flags=re.I) -> List[dict]:
        rx = re.compile(pattern, flags)
        literals = [w for w in self._IDENT.findall(re.sub(r"\\[bBdDwWsS]|\[[^\]]*\]|\\.", " ", pattern)) if "|" not in pattern and "?" not in pattern[:1]]
        cands = self.files_with(*literals) if literals else set(self.files)     # files that cannot match are never read
        hits = []
        for rel in self.files:
            if rel not in cands:
                continue
            try:
                for i, line in enumerate(self.text(rel).splitlines(), 1):
                    if rx.search(line):
                        hits.append({"path": rel, "line": i, "text": line.strip()[:200]})
                        if len(hits) >= max_hits:
                            return hits
            except Exception:  # noqa: BLE001
                continue
        return hits

    def summary(self) -> dict:
        langs = Counter(f["language"] for f in self.files.values())
        folders = Counter(f["folder"].split("/")[0] if f["folder"] else "(root)" for f in self.files.values())
        return {"name": self.name, "files": len(self.files), "languages": dict(langs.most_common()),
                "top_folders": dict(folders.most_common(25)),
                "folder_tree": self.tree(depth=3)}

    def tree(self, depth: int = 3, max_entries: int = 300) -> List[str]:
        seen = defaultdict(int)
        for rel in self.files:
            parts = rel.split("/")
            for d in range(1, min(depth, len(parts) - 1) + 1):
                seen["/".join(parts[:d]) + "/"] += 1
        out = sorted(seen.items())[:max_entries]
        return [f"{p} ({n} files)" for p, n in out]

    def examples(self, language: str, folder: str = "", k: int = 2) -> List[str]:
        cands = [r for r, f in self.files.items() if f["language"] == language and (not folder or r.startswith(folder))]
        cands.sort(key=lambda r: abs(self.files[r]["chars"] - 4000))
        return cands[:k]


    # ------------------------------------------------------------------ change-impact helpers (identifier index: no file scans)
    _REG_LANGS = ("python", "yaml", "json", "config", "text", "shell", "toml", "airflow_dag", "markdown")

    def _scan_folder(self, fold: str) -> List[dict]:
        """Files outside `fold` that mention its scripts: score = 3 (names the folder) + 2 per file name + 1 per stem."""
        sibs = [r for r in self.files if (r.rsplit("/", 1)[0] if "/" in r else "") == fold]
        stems = {Path(r).stem for r in sibs if len(Path(r).stem) > 3}
        names = {Path(r).name for r in sibs}
        fname = fold.rsplit("/", 1)[-1]
        score: Counter = Counter()
        name_hits: Dict[str, list] = defaultdict(list)
        stem_hits: Dict[str, list] = defaultdict(list)
        for st in stems:
            for rel in self.idents.get(st.lower(), ()):
                if (fold and rel.startswith(fold + "/")) or self.files[rel]["language"] not in self._REG_LANGS:
                    continue
                stem_hits[rel].append(st)
        for rel, sts in stem_hits.items():
            # a stem followed by its extension in the text = the file is named (stronger evidence)
            text = self.text(rel)
            nm = [n for n in names if Path(n).stem in sts and n in text]
            name_hits[rel] = nm
            score[rel] = 2 * len(nm) + len(sts)
        folder_hit = set()
        if len(fname) > 3:
            for rel in self.idents.get(fname.lower(), ()):
                if (fold and rel.startswith(fold + "/")) or self.files[rel]["language"] not in self._REG_LANGS:
                    continue
                if re.search(r"['\"/]" + re.escape(fname) + r"['\"/]", self.text(rel)):
                    folder_hit.add(rel); score[rel] += 3
        need = max(2, min(3, len(stems) // 4)) if len(stems) > 1 else 1
        hits = []
        for rel, sc in score.most_common(40):
            fh, nm, sts = rel in folder_hit, name_hits.get(rel, []), stem_hits.get(rel, [])
            if not (fh or nm or len(sts) >= need):
                continue
            key = (nm or sts or [fname])[0]
            line, sample = self._line_with(rel, key)
            why = []
            if fh:
                why.append(f"names the folder {fname}/")
            if nm:
                why.append(f"lists {len(nm)} of its {len(names)} script file(s) by name")
            elif sts:
                why.append(f"mentions {len(sts)} of its {len(stems)} script(s)")
            hits.append({"path": rel, "mentions": sc, "of": len(stems), "example_line": sample,
                         "reason": ", ".join(why) + f" - new scripts in {fold or '/'} must be registered here"})
        hits.sort(key=lambda h: -h["mentions"])
        return hits

    def registration_candidates(self, folder: str, k: int = 6) -> List[dict]:
        """Files that REGISTER the scripts of a folder (a DAG listing SQL tasks, a config list, a task-name file).
        Evidence, strongest first: the file names the folder itself ("ikg_x/" or TaskGroup('ikg_x')), it names sibling
        files with their extension (sql='ikg_x/foo.sql'), or it mentions several sibling stems. A folder with a single
        script (or a brand-new folder) falls back to how the SIBLING folders of the same parent are registered."""
        folder = folder.strip("/")
        hits = self._scan_folder(folder) if any(self.files[r]["folder"] == folder for r in self.files) or folder else []
        if not hits and "/" in folder:
            parent = folder.rsplit("/", 1)[0]
            sib_folders = sorted({r.rsplit("/", 1)[0] for r in self.files if r.startswith(parent + "/") and r.rsplit("/", 1)[0].count("/") == folder.count("/")
                                  and r.rsplit("/", 1)[0] != folder})[:6]
            agg: Dict[str, dict] = {}
            for sf in sib_folders:
                for h in self._scan_folder(sf)[:3]:
                    a = agg.setdefault(h["path"], {"path": h["path"], "mentions": 0, "of": 0, "example_line": h["example_line"], "folders": []})
                    a["mentions"] += h["mentions"]
                    a["folders"].append(sf.rsplit("/", 1)[-1])
            hits = [dict(a, reason=f"registers the scripts of the sibling folder(s) {', '.join(a['folders'][:3])} - a new script in {folder}/ "
                                   "is registered here the same way (new folder = new group, copy the shape of an existing one)")
                    for a in agg.values() if len(a["folders"]) >= min(2, len(sib_folders))]
            hits.sort(key=lambda h: -h["mentions"])
        return hits[:k]

    def companions(self, path: str, names: Optional[List[str]] = None, k: int = 8) -> List[dict]:
        """Files that usually change TOGETHER with `path` (a history / archive / snapshot script of the same table in a
        sibling folder, a config that lists the table, a test, a doc) - deterministic, from names and references:
          * same stem in another folder, or the stem with one token removed / added (x_profile_curr_ikg -> x_profile_ikg)
          * files mentioning the stem or one of `names` (table names) - configs, DAGs, docs, tests."""
        path = path.strip("/")
        stem = Path(path).stem
        folder = path.rsplit("/", 1)[0] if "/" in path else ""
        toks = stem.split("_")
        variants = {stem}
        if len(toks) > 2:
            for i in range(len(toks)):
                variants.add("_".join(toks[:i] + toks[i + 1:]))
        hits, seen = [], {path}
        for rel in self.files:
            if rel in seen:
                continue
            st = Path(rel).stem
            if st in variants:
                seen.add(rel)
                hits.append({"path": rel, "relation": "sibling", "example_line": "",
                             "reason": f"same table / stem as {stem} in {rel.rsplit('/', 1)[0] if '/' in rel else '/'} - when {path} changes "
                                       f"(new column, new table) this file usually needs the same change"})
        words = [w for w in {stem, *(names or []), *(Path(h["path"]).stem for h in hits)} if w and len(w) > 4]
        for w in words:
            for rel in sorted(self.idents.get(w.lower(), ())):
                if rel in seen or (folder and rel.startswith(folder + "/")):
                    continue
                meta = self.files[rel]
                if meta["language"] not in ("python", "yaml", "json", "config", "text", "shell", "sql", "markdown", "r", "airflow_dag"):
                    continue
                seen.add(rel)
                line, sample = self._line_with(rel, w)
                kind = "configuration" if meta["language"] in ("python", "yaml", "json", "config", "text", "airflow_dag") else "consumer"
                hits.append({"path": rel, "relation": kind, "example_line": sample,
                             "reason": f"mentions {w} (line {line}) - a {'config / registration entry' if kind == 'configuration' else 'reader of the table'}"
                                       f" that may need the same change (new table -> new entry; new column -> extend)"})
                if len(hits) >= 4 * k:
                    break
        hits.sort(key=lambda h: {"sibling": 0, "configuration": 1}.get(h["relation"], 2))
        return hits[:k]

    def companions_for_new(self, path: str, k: int = 8) -> List[dict]:
        """What a NEW file at `path` will need, learnt from its future siblings: if the existing files of that folder
        have a same-stem file in another folder (history / archive script) and entries in configs, the new file needs
        the analogous file (path derived by the same stem transformation) and the same config entries."""
        path = path.strip("/")
        if path in self.files:
            return self.companions(path, k=k)
        folder = path.rsplit("/", 1)[0] if "/" in path else ""
        stem, ext = Path(path).stem, Path(path).suffix
        sibs = [r for r in self.files if (r.rsplit("/", 1)[0] if "/" in r else "") == folder and r != path]
        sibs.sort(key=lambda r: -sum(1 for t in Path(r).stem.split("_") if t in stem.split("_")))   # most similar name first
        out, seen = [], set()
        for sib in sibs[:3]:
            sstem = Path(sib).stem
            for c in self.companions(sib, k=k):
                if c["relation"] == "sibling":
                    cstem = Path(c["path"]).stem
                    st, ct = sstem.split("_"), cstem.split("_")
                    removed = [t for t in st if t not in ct]
                    added = [t for t in ct if t not in st]
                    nt = [t for t in stem.split("_") if t not in removed] + added
                    new_path = (c["path"].rsplit("/", 1)[0] + "/" if "/" in c["path"] else "") + "_".join(nt) + Path(c["path"]).suffix
                    if new_path in seen or new_path == path:
                        continue
                    seen.add(new_path)
                    out.append({"path": new_path, "relation": "sibling_to_create", "example_line": "", "exists": new_path in self.files,
                                "reason": f"{sib} has its companion {c['path']} - the new {path} needs the analogous file (copy that shape)"})
                else:
                    if c["path"] in seen:
                        continue
                    seen.add(c["path"])
                    out.append({"path": c["path"], "relation": c["relation"], "example_line": c["example_line"], "exists": True,
                                "reason": f"{c['path']} has an entry for {sstem} ({c['example_line'][:80]}) - the new {stem} needs one too"})
            if out:
                break
        return out[:k]

    def references(self, name: str, max_hits: int = 40) -> List[dict]:
        """Where a table / function / file stem is used (impact of changing it) - only files that contain the identifier are read."""
        rx = re.compile(r"\b" + re.escape(name) + r"\b", re.I)
        hits = []
        for rel in sorted(self.idents.get(name.lower().split(".")[-1], ())):
            for i, line in enumerate(self.text(rel).splitlines(), 1):
                if rx.search(line):
                    hits.append({"path": rel, "line": i, "text": line.strip()[:200]})
                    if len(hits) >= max_hits:
                        return hits
        return hits
