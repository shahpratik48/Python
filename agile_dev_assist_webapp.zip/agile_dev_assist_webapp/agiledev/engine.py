"""The engine: one ChatSession = one chat of one user. Inputs -> context pack -> agents -> files -> validation ->
review -> regeneration -> outputs (files, zip, plan, log, token stats) -> optional git push.

Everything the session produces lives in its folder:
    inputs.json  pack.json  plan.json  files/<path>  review.json  findings.json  run_summary.json
    log.txt  tokens.txt  tokens.json  events.jsonl  history.json  agiledev_<story>.zip
"""
from __future__ import annotations

import concurrent.futures as cf
import io
import json
import logging
import threading
import time
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Callable, Dict, List, Optional

from .agents.context import AgentContext
from .agents.specialists import (StoryAgent, KnowledgeAgent, DataAgent, RepoAgent, PlannerAgent, CoderAgent,
                                 ReviewerAgent, ChangeAgent)
from .contextpack import build_pack, save_pack
from .gitclient import GitClient
from .inputs import SessionInputs, normalise_story
from .readers import read_document
from .validators import validate_file, score as quality_score

log = logging.getLogger(__name__)

DEFAULT_PIPELINE = ["story_agent", "knowledge_agent", "data_agent", "repo_agent", "planner_agent", "coder_agent", "reviewer_agent"]
STAGES = [("story", "Understanding the story"), ("knowledge", "Reading skills, glossary and standards"),
          ("data", "Analysing the tables"), ("repo", "Studying the repository"), ("plan", "Planning the files"),
          ("generate", "Generating the code"), ("validate", "Validating"), ("review", "Reviewing"),
          ("fix", "Regenerating after review"), ("outputs", "Writing the outputs")]


class ChatSession:
    def __init__(self, cfg, llm, folder: Path, user: str, chat_id: str, on_event: Optional[Callable[[dict], None]] = None):
        self.cfg, self.llm = cfg, llm
        self.folder = Path(folder)
        self.folder.mkdir(parents=True, exist_ok=True)
        self.user, self.chat_id = user, chat_id
        self.inputs = SessionInputs.load(self.folder)
        self.on_event = on_event
        self.events: List[dict] = []
        self.history: List[dict] = []
        self.files: Dict[str, dict] = {}
        self.plan: dict = {}
        self.review: dict = {}
        self.findings: List[dict] = []
        self.summary: dict = {}
        self.ctx: Optional[AgentContext] = None
        self.running = False
        self._lock = threading.Lock()
        self._log_fh = None
        self._load_state()

    # ------------------------------------------------------------------ events + log
    def event(self, type_: str, title: str, detail: str = "", pct: Optional[int] = None, **extra) -> dict:
        e = {"ts": datetime.now().strftime("%H:%M:%S"), "t": time.time(), "type": type_, "title": title, "detail": detail, "pct": pct, **extra}
        self.events.append(e)
        try:
            with open(self.folder / "events.jsonl", "a", encoding="utf-8") as fh:
                fh.write(json.dumps(e, ensure_ascii=False, default=str) + "\n")
        except Exception:  # noqa: BLE001
            pass
        self.log(f"[{type_}] {title}" + (f" - {detail}" if detail else ""))
        if self.on_event:
            try:
                self.on_event(e)
            except Exception:  # noqa: BLE001
                pass
        return e

    def log(self, line: str) -> None:
        try:
            with open(self.folder / "log.txt", "a", encoding="utf-8") as fh:
                fh.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} {line}\n")
        except Exception:  # noqa: BLE001
            pass

    def _trace_sink(self, row: dict) -> None:
        self.log(f"[trace] {row['agent']} {row['task']} step {row['step']} {row['kind']} {row['name']} {row['detail']}" + ("" if row["ok"] else " (issue)"))
        if row["kind"] in ("done", "cache"):
            self.event("agent", f"{row['agent']}: {row['task']} {'(cache)' if row['kind'] == 'cache' else 'done'}", row["detail"], agent=row["agent"])

    # ------------------------------------------------------------------ inputs (called by the UI)
    def set_story_text(self, text: str, title: str = "", story_id: str = "", source: Optional[dict] = None) -> dict:
        s = self.inputs.set_story(normalise_story(text, title, story_id, source))
        self.event("input", f"story: {s['id']} {s['title']}", f"{s['chars']} chars", kind="story")
        return s

    def set_story_from_git(self, url: str, token: str, issue: str = "", path: str = "", ref: str = "") -> dict:
        gc = GitClient(url, token, self.cfg.git.get("ssl_verify", True), self.cfg.git.get("default_provider", "gitlab"))
        issue = issue or gc.info.get("issue")
        if issue:
            it = gc.issue(issue)
            text = f"# {it['title']}\n\n{it['description']}\n\n" + "\n\n".join(f"**comment by {n['author']}**\n{n['body']}" for n in it["notes"])
            src = {"type": "git_issue", "url": it.get("web_url") or url, "project": gc.project, "issue": it["id"]}
            return self.set_story_text(text, it["title"], it["id"], src)
        if path:
            ref = ref or gc.info.get("branch") or gc.project_info().get("default_branch") or "main"
            content = gc.file(path, ref)
            doc = read_document(Path(path).name, content.encode("utf-8"), "story")
            src = {"type": "git_file", "url": url, "project": gc.project, "path": path, "ref": ref}
            return self.set_story_text(doc["text"], "", "", src)
        raise ValueError("give an issue number or a file path in the repository")

    def set_story_from_file(self, name: str, data: bytes) -> dict:
        doc = read_document(name, data, "story", int(self.cfg.inputs.get("max_doc_chars", 120000)))
        return self.set_story_text(doc["text"], "", "", {"type": "upload", "name": name})

    def add_documents(self, kind: str, files: List[tuple]) -> List[dict]:
        out = []
        for name, data in files:
            out.append(self.inputs.add_document(kind, name, data, int(self.cfg.inputs.get("max_doc_chars", 120000))))
            self.event("input", f"{kind}: {name}", f"{out[-1]['chars']} chars", kind=kind)
        return out

    def add_local_repo(self, path: str, name: str = "", branch: str = "local") -> dict:
        """A repository already on this machine (a checkout or an unzipped copy) - for local testing and offline work."""
        p = Path(path).expanduser()
        if not p.is_dir():
            raise ValueError(f"folder not found: {p}")
        name = name or p.name
        rec = self.inputs.add_repo(name, f"file://{p}", branch, p, self.cfg.inputs.repo, {"provider": "local", "project": str(p)})
        self.event("input", f"local repository {name}: {rec['files']} files indexed", json.dumps(rec["languages"]), kind="repo")
        return rec

    def add_repo(self, url: str, token: str, branch: str = "", name: str = "", subpath: str = "", refresh: bool = False,
                 progress=None) -> dict:
        rc = self.cfg.inputs.repo
        say = progress or (lambda msg: None)
        if url.startswith("file://") or (url and not url.startswith("http") and Path(url).expanduser().is_dir()):
            say("indexing the local folder ...")
            return self.add_local_repo(url.replace("file://", ""), name, branch or "local")
        say("contacting the git server ...")
        gc = GitClient(url, token, self.cfg.git.get("ssl_verify", True), self.cfg.git.get("default_provider", "gitlab"))
        info = gc.project_info()
        branch = branch or gc.info.get("branch") or info.get("default_branch") or "main"
        name = name or gc.project.rsplit("/", 1)[-1]
        cache_root = self.cfg.path(self.cfg.storage.get("repo_cache_dir", "data/cache/repos")) / _safe(self.user) / _safe(f"{gc.project}@{branch}")
        self.event("input", f"repository {name}@{branch}: downloading", url, kind="repo")
        d = gc.download(cache_root, branch, rc.get("code_extensions", ["py", "sql"]), int(rc.get("max_file_kb", 400)),
                        int(rc.get("max_files", 6000)), float(rc.get("cache_hours", 24)), refresh, subpath, progress=say,
                        use_git_cli=bool(rc.get("use_git_cli", True)))
        say("indexing files (symbols, search index) ...")
        rec = self.inputs.add_repo(name, url, branch, cache_root, rc, {"provider": gc.provider, "project": gc.project, "web_url": info.get("web_url", "")})
        self.event("input", f"repository {name}@{branch}: {rec['files']} files indexed" + (" (cached)" if d.get("cached") else ""), json.dumps(rec["languages"]), kind="repo")
        return rec

    def add_tables(self, gp, schema: str, tables: List[str], progress=None, refresh: bool = False) -> List[dict]:
        out = []
        n = int(self.cfg.inputs.greenplum.get("sample_rows", 5))
        todo = tables[: int(self.cfg.inputs.greenplum.get("max_tables", 50))]
        pairs = []
        for t in todo:
            sch, name = (t.split(".", 1) if "." in t else (schema, t))
            pairs.append((sch.strip(), name.strip()))
        t0 = time.time()
        # per-user on-disk cache of table descriptions (catalog + sample): a table already described today is not read again
        gcfg = self.cfg.inputs.greenplum
        hours = float(gcfg.get("cache_hours", 24) or 0)
        cdir = self.cfg.path(self.cfg.storage.get("data_dir", "data")) / "cache" / "gp" / _safe(self.user) / _safe(f"{gp.conn_info.get('host', 'local')}_{gp.conn_info.get('database', '')}")
        cdir.mkdir(parents=True, exist_ok=True)
        described, fresh_pairs = [], []
        for sch, name in pairs:
            f = cdir / f"{_safe(sch)}.{_safe(name)}.json"
            if hours and not refresh and f.exists() and (time.time() - f.stat().st_mtime) / 3600 <= hours:
                try:
                    described.append(json.loads(f.read_text(encoding="utf-8")))
                    continue
                except Exception:  # noqa: BLE001
                    pass
            fresh_pairs.append((sch, name))
        if described and progress:
            progress(f"{len(described)} table(s) taken from today's cache ...")
        if fresh_pairs:
            for d in gp.describe_many(fresh_pairs, n, progress=progress, sample_timeout_s=int(gcfg.get("sample_timeout_seconds", 15))):
                described.append(d)
                try:
                    (cdir / f"{_safe(d['schema'])}.{_safe(d['table'])}.json").write_text(json.dumps(d, ensure_ascii=False, default=str), encoding="utf-8")
                except Exception:  # noqa: BLE001
                    pass
        for d in described:
            out.append(self.inputs.add_table(d))
            self.event("input", f"table {d['schema']}.{d['table']}: {out[-1]['columns']} columns", kind="table")
        self.log(f"{len(described)} table(s) described in {time.time() - t0:.1f}s")
        return out

    def add_query(self, gp, sql: str, name: str = "") -> dict:
        q = gp.query(sql, 200)
        q["name"] = name
        r = self.inputs.add_query(q)
        self.event("input", f"query {r['name']}: {r['row_count']} rows", kind="query")
        return r

    # ------------------------------------------------------------------ the run
    def run(self, instructions: str = "", pipeline: Optional[List[str]] = None) -> dict:
        """Runs the agent pipeline of this chat (inputs.pipeline, editable in the UI) in order.
        Stages per agent: story | knowledge, data, repo (parallel) | planner | coder (generate + validate) | reviewer (+ fix)."""
        if self.inputs.story is None:
            raise ValueError("add a story first (drag the Story icon into the chat)")
        with self._lock:
            if self.running:
                raise RuntimeError("a run is already in progress for this chat")
            self.running = True
        t0 = time.time()
        budget = float(self.cfg.product.get("max_run_minutes", 5)) * 60
        pipe = [a for a in (pipeline or self.inputs.pipeline or DEFAULT_PIPELINE) if a in DEFAULT_PIPELINE]
        if "coder_agent" in pipe and "planner_agent" not in pipe:
            pipe.insert(pipe.index("coder_agent"), "planner_agent")          # the coder needs a plan
        try:
            if instructions:
                self.inputs.add_instruction(instructions)
            self.event("milestone", "run started", f"budget {budget / 60:.0f} min - pipeline: " + " > ".join(a.replace("_agent", "") for a in pipe), pct=0, pipeline=pipe)
            pack = build_pack(self.inputs, self.cfg)
            save_pack(pack, self.folder)
            self.event("log", "context pack built", json.dumps(pack["chars"]))
            ctx = AgentContext(self.cfg, self.llm, self.inputs, pack, self._trace_sink, deadline=t0 + budget)
            self.ctx = ctx
            n_steps = max(1, len(pipe))
            pct = lambda i: int(5 + 85 * i / n_steps)  # noqa: E731
            step = 0
            # ---- story
            if "story_agent" in pipe:
                self._stage("story", pct(step)); step += 1
                StoryAgent(ctx).execute()
                self.event("result", "requirements", json.dumps({k: ctx.story.get(k) for k in ("summary", "feature_name", "target_languages")}), kind="story")
            else:
                st = self.inputs.story
                ctx.story = {"summary": st.get("text", "")[:2000], "goal": st.get("title", ""), "feature_name": st.get("title", "")[:60],
                             "functional_requirements": [], "business_rules": [], "acceptance_criteria": st.get("acceptance_criteria", []), "target_languages": []}
                self.event("log", "story agent skipped - the story text is used as is")
            # ---- knowledge, data, repo: independent -> parallel
            group = [(a, k) for a, k in (("knowledge_agent", "knowledge"), ("data_agent", "data"), ("repo_agent", "repo")) if a in pipe]
            if group:
                for _, k in group:
                    self._stage(k, pct(step), running=True)
                agents = {"knowledge_agent": KnowledgeAgent, "data_agent": DataAgent, "repo_agent": RepoAgent}
                with cf.ThreadPoolExecutor(len(group)) as ex:
                    futs = {ex.submit(agents[a](ctx).execute): k for a, k in group}
                    for f in cf.as_completed(futs):
                        try:
                            f.result()
                            self.event("milestone", f"{futs[f]} done", stage_done=futs[f])
                        except Exception as e:  # noqa: BLE001
                            self.event("error", f"{futs[f]} agent failed (continuing)", str(e)[:300], stage_done=futs[f])
                step += len(group)
                if ctx.knowledge.get("rules"):
                    self.event("log", f"{len(ctx.knowledge['rules'])} checkable rule(s) extracted from the standards")
            # ---- plan
            if "planner_agent" in pipe:
                self._stage("plan", pct(step)); step += 1
                PlannerAgent(ctx).execute()
                ctx.pack = build_pack(self.inputs, self.cfg, query_hint=ctx.story.get("summary", ""), plan=ctx.plan)
                save_pack(ctx.pack, self.folder)
                self.plan = ctx.plan
                self._save_json("plan.json", self.plan)
                self.event("result", f"plan: {len(self.plan.get('files', []))} file(s)", self.plan.get("approach", ""), kind="plan",
                           files=[{"path": f["path"], "action": f["action"], "language": f["language"]} for f in self.plan.get("files", [])], stage_done="plan")
            # ---- code
            if "coder_agent" in pipe:
                self._stage("generate", pct(step)); step += 1
                self._generate(ctx)
                self.event("milestone", "generation done", stage_done="generate")
                self._stage("validate", pct(step))
                self._validate_and_fix(ctx)
                self.event("milestone", "validation done", stage_done="validate")
            # ---- review (+ fix)
            if "reviewer_agent" in pipe and self.files:
                if not ctx.out_of_time():
                    self._stage("review", pct(step)); step += 1
                    rev = ReviewerAgent(ctx).execute(self.findings)
                    self.review = rev
                    self._save_json("review.json", rev)
                    self.event("result", f"review: {rev.get('verdict')} score {rev.get('score')}", rev.get("summary", ""), kind="review",
                               findings=len(rev.get("findings", [])), stage_done="review")
                    sev = set(self.cfg.generation.get("review_fix_severities", ["critical", "high"]))
                    to_fix = [f for f in rev.get("findings", []) if f.get("severity") in sev and f.get("path") in self.files]
                    if to_fix and not ctx.out_of_time():
                        self._stage("fix", pct(step))
                        self._fix(ctx, to_fix, "review")
                        self._validate_and_fix(ctx, rounds=1)
                        self.event("milestone", "fixes applied", stage_done="fix")
                    else:
                        self.event("log", "no critical / high review finding - nothing to regenerate", stage_skipped="fix")
                else:
                    self.event("log", "time budget used up - review skipped", stage_skipped="review")
            self._stage("outputs", 95)
            self._write_outputs(t0)
            self.event("milestone", "run complete", f"{len(self.files)} file(s), quality {self.summary.get('quality_score')}, "
                       f"{self.summary.get('duration_seconds')}s, {self.summary.get('tokens', {}).get('total_tokens', 0)} tokens", pct=100, kind="done", stage_done="outputs")
            return self.summary
        except Exception as e:
            log.exception("run failed")
            self.event("error", "run failed", f"{type(e).__name__}: {e}", kind="failed")
            self._write_outputs(t0, failed=str(e))
            raise
        finally:
            self.running = False

    def _stage(self, key: str, pct: int, running: bool = False) -> None:
        title = dict(STAGES).get(key, key)
        self.event("milestone", title, pct=pct, stage=key, parallel=running)

    def _existing(self, path: str, repo: str = "") -> Optional[str]:
        for idx in self.inputs.indexes():
            if (not repo or idx.name == repo) and path in idx.files:
                return idx.read(path, 10 ** 7)
        return None

    def _generate(self, ctx: AgentContext) -> None:
        files = ctx.plan.get("files", [])
        done = {}

        def one(spec):
            if ctx.out_of_time():
                return spec["path"], None
            existing = self._existing(spec["path"], spec.get("repo", "")) if spec["action"] == "modify" else None
            r = CoderAgent(ctx).write(spec, existing, "modify" if existing is not None else "create")
            return spec["path"], r
        # files without dependencies first (parallel), then dependants
        order = sorted(files, key=lambda f: len(f.get("depends_on") or []))
        with cf.ThreadPoolExecutor(int(self.cfg.generation.get("parallel_files", 4))) as ex:
            for path, r in ex.map(one, order):
                if r is None:
                    self.event("log", f"{path}: skipped (time budget)")
                    continue
                spec = next(f for f in files if f["path"] == path)
                rec = {"path": path, "language": r.get("language") or spec["language"], "content": r.get("content", ""),
                       "action": spec["action"], "purpose": spec["purpose"], "explanation": r.get("explanation", ""),
                       "assumptions": r.get("assumptions", []), "confidence": r.get("confidence", 0), "repo": spec.get("repo", "")}
                self.files[path] = rec
                ctx.files[path] = rec
                self._save_file(rec)
                self.event("file", f"{spec['action']}: {path}", f"{len(rec['content'])} chars, confidence {rec['confidence']}", kind="file",
                           path=path, language=rec["language"])

    def _validate_and_fix(self, ctx: AgentContext, rounds: Optional[int] = None) -> None:
        rounds = int(self.cfg.generation.get("validate_fix_rounds", 2)) if rounds is None else rounds
        dialect = (ctx.data or {}).get("sql_dialect") or "postgres"
        for rnd in range(rounds + 1):
            findings = []
            for p, f in self.files.items():
                existing = self._existing(p, f.get("repo", "")) if f.get("action") == "modify" else None
                findings += validate_file(p, f["content"], f.get("language", ""), ctx.rules, "postgres" if "green" in dialect.lower() else dialect,
                                          existing=existing)
            self.findings = findings
            ctx.findings = findings
            self._save_json("findings.json", findings)
            blocking = [x for x in findings if x["severity"] in ("critical", "high")]
            self.event("result", f"validation: {len(findings)} finding(s), {len(blocking)} blocking, score {quality_score(findings)}",
                       "; ".join(f"{x['path']}: {x['message']}" for x in blocking[:5]), kind="validation", findings=len(findings))
            if not blocking or rnd == rounds or ctx.out_of_time():
                return
            self._fix(ctx, blocking, "validator")

    def _fix(self, ctx: AgentContext, findings: List[dict], who: str) -> None:
        by_path: Dict[str, List[dict]] = {}
        for f in findings:
            by_path.setdefault(f["path"], []).append(f)

        def one(path):
            rec = self.files[path]
            spec = {"path": path, "language": rec["language"], "purpose": rec["purpose"], "outline": [], "repo": rec.get("repo", "")}
            r = CoderAgent(ctx).write(spec, rec["content"], "fix", by_path[path])
            return path, r
        with cf.ThreadPoolExecutor(int(self.cfg.generation.get("parallel_files", 4))) as ex:
            for path, r in ex.map(one, list(by_path)):
                if r.get("content"):
                    self.files[path]["content"] = r["content"]
                    self.files[path]["explanation"] = r.get("explanation", self.files[path]["explanation"])
                    if r.get("confidence"):
                        self.files[path]["confidence"] = r["confidence"]
                    ctx.files[path] = self.files[path]
                    self._save_file(self.files[path])
                    self.event("file", f"fixed ({who}): {path}", "; ".join(f["message"][:80] for f in by_path[path][:3]), kind="file",
                               path=path, language=self.files[path]["language"])

    # ------------------------------------------------------------------ follow-up changes in the chat
    def change(self, request: str) -> dict:
        if not self.files:
            raise ValueError("nothing generated yet - run the story first")
        with self._lock:
            if self.running:
                raise RuntimeError("a run is already in progress")
            self.running = True
        t0 = time.time()
        try:
            ctx = self.ctx or self._rebuild_ctx()
            ctx.deadline = t0 + float(self.cfg.product.get("max_run_minutes", 5)) * 60
            self.event("milestone", "change requested", request[:200], pct=0)
            r = ChangeAgent(ctx).execute(request, self.history)
            if r.get("needs_clarification") and r.get("question"):
                self.event("milestone", "question", r["question"], pct=100, kind="done")
                return {"reply": r["question"], "changed": []}
            changed = []
            for ch in r.get("changes", []):
                p = ch["path"]
                if ch["action"] == "delete":
                    self.files.pop(p, None)
                    ctx.files.pop(p, None)
                    try:
                        (self.folder / "files" / p).unlink()
                    except Exception:  # noqa: BLE001
                        pass
                    changed.append(p)
                    continue
                rec = self.files.get(p)
                spec = {"path": p, "language": ch.get("language") or (rec or {}).get("language", ""), "purpose": ch.get("purpose") or (rec or {}).get("purpose", ""),
                        "outline": ch.get("instructions", []), "repo": (rec or {}).get("repo", "")}
                existing = rec["content"] if rec else self._existing(p)
                mode = "fix" if rec else ("modify" if existing is not None else "create")
                out = CoderAgent(ctx).write(spec, existing, mode, [{"path": p, "severity": "high", "message": i} for i in ch.get("instructions", [])], request)
                if out.get("content"):
                    self.files[p] = {"path": p, "language": out.get("language") or spec["language"], "content": out["content"],
                                     "action": (rec or {}).get("action", "create"), "purpose": spec["purpose"],
                                     "explanation": out.get("explanation", ""), "assumptions": out.get("assumptions", []),
                                     "confidence": out.get("confidence", 0), "repo": spec["repo"]}
                    ctx.files[p] = self.files[p]
                    self._save_file(self.files[p])
                    changed.append(p)
                    self.event("file", f"changed: {p}", out.get("explanation", "")[:200], kind="file", path=p, language=self.files[p]["language"])
            if changed:
                self._validate_and_fix(ctx, rounds=1)
            self._write_outputs(t0)
            self.event("milestone", "change complete", f"{len(changed)} file(s)", pct=100, kind="done")
            return {"reply": r.get("reply", ""), "changed": changed, "understanding": r.get("understanding", "")}
        finally:
            self.running = False

    def _rebuild_ctx(self) -> AgentContext:
        pack = build_pack(self.inputs, self.cfg)
        ctx = AgentContext(self.cfg, self.llm, self.inputs, pack, self._trace_sink)
        ctx.plan = self.plan
        ctx.files = self.files
        st = self._load_json("story_result.json") or {}
        ctx.story = st
        kn = self._load_json("knowledge.json") or {}
        ctx.knowledge, ctx.rules = kn, kn.get("rules", [])
        self.ctx = ctx
        return ctx

    # ------------------------------------------------------------------ outputs
    def _write_outputs(self, t0: float, failed: str = "") -> None:
        stats = self.llm.token_stats() if hasattr(self.llm, "token_stats") else {"total": {}, "by_agent": {}}
        self.summary = {"user": self.user, "chat_id": self.chat_id, "story": {k: self.inputs.story.get(k) for k in ("id", "title")} if self.inputs.story else None,
                        "files": [{"path": p, "language": f["language"], "action": f["action"], "chars": len(f["content"]), "confidence": f.get("confidence")} for p, f in self.files.items()],
                        "quality_score": quality_score(self.findings) if self.files else 0, "review": {k: self.review.get(k) for k in ("verdict", "score", "summary")},
                        "findings": len(self.findings), "duration_seconds": round(time.time() - t0, 1), "tokens": stats["total"],
                        "tokens_by_agent": stats["by_agent"], "failed": failed, "finished": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
        self._save_json("run_summary.json", self.summary)
        self._save_json("tokens.json", stats)
        if self.ctx:
            self._save_json("story_result.json", self.ctx.story)
            self._save_json("knowledge.json", self.ctx.knowledge)
            self._save_json("data.json", self.ctx.data)
            self._save_json("repo.json", self.ctx.repo)
        try:
            txt = self.llm.token_stats_text() if hasattr(self.llm, "token_stats_text") else json.dumps(stats, indent=1)
            (self.folder / "tokens.txt").write_text(txt, encoding="utf-8")
            self.log("\n" + txt)
        except Exception:  # noqa: BLE001
            pass
        if self.files and (bool(self.cfg.generation.get("docs", False)) or getattr(self, "docs_wanted", False)):
            try:
                from .docgen import write_docs
                self.docs = write_docs(self)
                for d in self.docs:
                    self.event("result", f"documentation: {Path(d).name}", kind="docs", path=d)
            except Exception as e:  # noqa: BLE001
                self.event("error", "documentation failed", str(e)[:200])
        self.make_zip()

    def make_zip(self) -> Path:
        sid = _safe((self.inputs.story or {}).get("id", "run"))
        zp = self.folder / f"agiledev_{sid}.zip"
        with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
            for p, f in self.files.items():
                z.writestr(p, f["content"])
            for name in ("plan.json", "review.json", "findings.json", "run_summary.json", "tokens.txt", "log.txt", "pack.json"):
                fp = self.folder / name
                if fp.exists():
                    z.write(fp, f"_agiledev/{name}")
            z.writestr("_agiledev/README.txt", self.readme_text())
            for d in getattr(self, "docs", []) or []:
                if Path(d).exists():
                    z.write(d, f"_agiledev/{Path(d).name}")
        return zp

    def readme_text(self) -> str:
        s = self.inputs.story or {}
        lines = [f"Agile Dev Assist output for story {s.get('id', '')}: {s.get('title', '')}", f"user: {self.user}  chat: {self.chat_id}",
                 "", "Approach:", self.plan.get("approach", ""), "", "Files:"]
        for p, f in self.files.items():
            lines.append(f"  {f['action']:7s} {p}  [{f['language']}]  {f['purpose']}")
        if self.review:
            lines += ["", f"Review: {self.review.get('verdict')} score {self.review.get('score')} - {self.review.get('summary', '')}"]
        return "\n".join(lines)

    # ------------------------------------------------------------------ publish
    def publish(self, url: str, token: str, branch: str, base_branch: str, message: str = "", author: Optional[dict] = None,
                paths: Optional[List[str]] = None) -> dict:
        if not self.files:
            raise ValueError("nothing to push")
        gc = GitClient(url, token, self.cfg.git.get("ssl_verify", True), self.cfg.git.get("default_provider", "gitlab"))
        who = gc.whoami()
        s = self.inputs.story or {}
        msg = message or self.cfg.git.get("commit_message_template", "{story_id}: {title}").format(
            story_id=s.get("id", ""), title=s.get("title", "")[:80], user=who.get("name") or self.user)
        files = {p: f["content"] for p, f in self.files.items() if not paths or p in paths}
        self.event("input", f"pushing {len(files)} file(s) to {gc.project} branch {branch}", f"as {who.get('username')} from {base_branch}", kind="publish")
        r = gc.publish(branch, base_branch, msg, files, author or {"name": who.get("name"), "email": who.get("email")})
        r["pushed_as"] = who.get("username")
        self._save_json("publish.json", r)
        self.event("result", f"pushed: {r['branch']}", r.get("branch_url", ""), kind="publish", url=r.get("branch_url", ""))
        return r

    def suggest_branch(self, repo_url: str = "") -> str:
        s = self.inputs.story or {}
        feature = (self.ctx.story.get("feature_name") if self.ctx and self.ctx.story else "") or \
            (self._load_json("story_result.json") or {}).get("feature_name") or s.get("title", "change")
        repo = ""
        if repo_url:
            from .gitclient import parse_project_url
            repo = parse_project_url(repo_url).get("project", "").rsplit("/", 1)[-1]
        elif self.inputs.repos:
            repo = self.inputs.repos[0]["name"]
        return GitClient.branch_name(self.cfg.git.get("branch_template", "{story_id}-{repo}-{feature}"), s.get("id", "story"),
                                     repo or "repo", feature, int(self.cfg.git.get("branch_name_max_length", 80)))

    # ------------------------------------------------------------------ edits from the UI
    def update_file(self, path: str, content: str) -> dict:
        rec = self.files.get(path) or {"path": path, "language": "", "action": "create", "purpose": "edited in the UI",
                                       "explanation": "", "assumptions": [], "confidence": 0, "repo": ""}
        rec["content"] = content
        from .validators import language_of
        rec["language"] = rec["language"] or language_of(path)
        self.files[path] = rec
        if self.ctx:
            self.ctx.files[path] = rec
        self._save_file(rec)
        fnd = validate_file(path, content, rec["language"], self.ctx.rules if self.ctx else [])
        self.findings = [f for f in self.findings if f["path"] != path] + fnd
        self._save_json("findings.json", self.findings)
        self.event("file", f"edited in the UI: {path}", f"{len(fnd)} finding(s)", kind="file", path=path, language=rec["language"])
        self.make_zip()
        return {"path": path, "findings": fnd}

    # ------------------------------------------------------------------ persistence
    def _save_file(self, rec: dict) -> None:
        p = self.folder / "files" / rec["path"]
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(rec["content"], encoding="utf-8")
        self._save_json("files_meta.json", {k: {x: v for x, v in f.items() if x != "content"} for k, f in self.files.items()})

    def _save_json(self, name: str, data) -> None:
        try:
            (self.folder / name).write_text(json.dumps(data, ensure_ascii=False, indent=1, default=str), encoding="utf-8")
        except Exception as e:  # noqa: BLE001
            log.warning("%s not saved: %s", name, e)

    def _load_json(self, name: str):
        p = self.folder / name
        if p.exists():
            try:
                return json.loads(p.read_text(encoding="utf-8"))
            except Exception:  # noqa: BLE001
                return None
        return None

    def _load_state(self) -> None:
        self.plan = self._load_json("plan.json") or {}
        self.review = self._load_json("review.json") or {}
        self.findings = self._load_json("findings.json") or []
        self.summary = self._load_json("run_summary.json") or {}
        self.history = self._load_json("history.json") or []
        meta = self._load_json("files_meta.json") or {}
        for p, m in meta.items():
            fp = self.folder / "files" / p
            if fp.exists():
                self.files[p] = dict(m, content=fp.read_text(encoding="utf-8"))
        ev = self.folder / "events.jsonl"
        if ev.exists():
            try:
                self.events = [json.loads(l) for l in ev.read_text(encoding="utf-8").splitlines() if l.strip()]
            except Exception:  # noqa: BLE001
                self.events = []

    def add_history(self, role: str, text: str, **extra) -> dict:
        m = {"role": role, "text": text, "ts": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), **extra}
        self.history.append(m)
        self._save_json("history.json", self.history)
        return m

    def state(self) -> dict:
        return {"chat_id": self.chat_id, "user": self.user, "inputs": self.inputs.overview(), "plan": self.plan,
                "files": [{k: v for k, v in f.items() if k != "content"} for f in self.files.values()],
                "review": self.review, "findings": self.findings, "summary": self.summary, "running": self.running,
                "docs": [d for d in (getattr(self, "docs", []) or []) if Path(d).exists()],
                "pipeline": list(self.inputs.pipeline or DEFAULT_PIPELINE), "default_pipeline": DEFAULT_PIPELINE,
                "history": self.history, "events": self.events[-400:]}


def _safe(s: str) -> str:
    import re
    return re.sub(r"[^A-Za-z0-9._@-]+", "_", str(s))[:120] or "x"
