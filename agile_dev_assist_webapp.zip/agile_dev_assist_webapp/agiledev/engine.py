"""The engine: one ChatSession = one chat of one user. Inputs -> context pack -> agents -> files -> validation ->
review -> regeneration -> outputs (files, zip, plan, log, token stats) -> optional git push.

Everything the session produces lives in its folder:
    inputs.json  pack.json  plan.json  files/<path>  review.json  findings.json  run_summary.json
    log.txt  tokens.txt  tokens.json  events.jsonl  history.json  agiledev_<story>.zip
"""
from __future__ import annotations

import concurrent.futures as cf
import io
import json
import re
import logging
import threading
import time
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Callable, Dict, List, Optional

from .agents.context import AgentContext
from .config import fmt_secs
from .agents.specialists import (StoryAgent, KnowledgeAgent, DataAgent, RepoAgent, PlannerAgent, CoderAgent,
                                 ReviewerAgent, ChangeAgent)
from .contextpack import build_pack, save_pack
from .gitclient import GitClient
from .inputs import SessionInputs, normalise_story
from .readers import read_document
from .validators import validate_file, score as quality_score

log = logging.getLogger(__name__)

DEFAULT_PIPELINE = ["story_agent", "knowledge_agent", "data_agent", "repo_agent", "planner_agent", "coder_agent", "reviewer_agent"]
STAGES = [("story", "Understanding the story"), ("knowledge", "Knowledge: packs and documents"),
          ("data", "Analysing the tables"), ("repo", "Studying the repository"), ("plan", "Planning the files"),
          ("generate", "Generating the code"), ("validate", "Validating"), ("review", "Reviewing"),
          ("fix", "Regenerating after review"), ("outputs", "Writing the outputs")]


class ChatSession:
    def __init__(self, cfg, llm, folder: Path, user: str, chat_id: str, on_event: Optional[Callable[[dict], None]] = None):
        self.cfg, self.llm = cfg, llm
        self.folder = Path(folder)
        self.folder.mkdir(parents=True, exist_ok=True)
        self.user, self.chat_id = user, chat_id
        self.inputs = SessionInputs.load(self.folder)
        self.on_event = on_event
        self.events: List[dict] = []
        self.history: List[dict] = []
        self.files: Dict[str, dict] = {}
        self._rule_hits: Dict[tuple, int] = {}
        self._stuck: List[dict] = []
        self.plan: dict = {}
        self.review: dict = {}
        self.findings: List[dict] = []
        self.summary: dict = {}
        self.ctx: Optional[AgentContext] = None
        self.running = False
        self._lock = threading.Lock()
        self._log_fh = None
        self._load_state()

    def _fresh_llm(self) -> None:
        base = getattr(self, "_base_llm", None) or self.llm
        self._base_llm = base
        self.llm = base.child() if hasattr(base, "child") else base

    # ------------------------------------------------------------------ events + log
    def event(self, type_: str, title: str, detail: str = "", pct: Optional[int] = None, **extra) -> dict:
        e = {"ts": datetime.now().strftime("%H:%M:%S"), "t": time.time(), "type": type_, "title": title, "detail": detail, "pct": pct, **extra}
        self.events.append(e)
        try:
            with open(self.folder / "events.jsonl", "a", encoding="utf-8") as fh:
                fh.write(json.dumps(e, ensure_ascii=False, default=str) + "\n")
        except Exception:  # noqa: BLE001
            pass
        self.log(f"[{type_}] {title}" + (f" - {detail}" if detail else ""))
        if self.on_event:
            try:
                self.on_event(e)
            except Exception:  # noqa: BLE001
                pass
        return e

    def log(self, line: str) -> None:
        try:
            with open(self.folder / "log.txt", "a", encoding="utf-8") as fh:
                fh.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} {line}\n")
        except Exception:  # noqa: BLE001
            pass

    def _trace_sink(self, row: dict) -> None:
        self.log(f"[trace] {row['agent']} {row['task']} step {row['step']} {row['kind']} {row['name']} {row['detail']}" + ("" if row["ok"] else " (issue)"))
        if row["kind"] in ("done", "cache"):
            self.event("agent", f"{row['agent']}: {row['task']} {'(cache)' if row['kind'] == 'cache' else 'done'}", row["detail"], agent=row["agent"])

    # ------------------------------------------------------------------ inputs (called by the UI)
    def set_story_text(self, text: str, title: str = "", story_id: str = "", source: Optional[dict] = None) -> dict:
        s = self.inputs.set_story(normalise_story(text, title, story_id, source))
        self.event("input", f"story: {s['id']} {s['title']}", f"{s['chars']} chars", kind="story")
        return s

    def set_story_from_git(self, url: str, token: str, issue: str = "", path: str = "", ref: str = "") -> dict:
        gc = GitClient(url, token, self.cfg.git.get("ssl_verify", True), self.cfg.git.get("default_provider", "gitlab"))
        issue = issue or gc.info.get("issue")
        if issue:
            it = gc.issue(issue)
            text = f"# {it['title']}\n\n{it['description']}\n\n" + "\n\n".join(f"**comment by {n['author']}**\n{n['body']}" for n in it["notes"])
            src = {"type": "git_issue", "url": it.get("web_url") or url, "project": gc.project, "issue": it["id"]}
            return self.set_story_text(text, it["title"], it["id"], src)
        if path:
            ref = ref or gc.info.get("branch") or gc.project_info().get("default_branch") or "main"
            content = gc.file(path, ref)
            doc = read_document(Path(path).name, content.encode("utf-8"), "story")
            src = {"type": "git_file", "url": url, "project": gc.project, "path": path, "ref": ref}
            return self.set_story_text(doc["text"], "", "", src)
        raise ValueError("give an issue number or a file path in the repository")

    def set_story_from_file(self, name: str, data: bytes) -> dict:
        doc = read_document(name, data, "story", int(self.cfg.inputs.get("max_doc_chars", 120000)))
        return self.set_story_text(doc["text"], "", "", {"type": "upload", "name": name})

    def add_documents(self, kind: str, files: List[tuple]) -> List[dict]:
        out = []
        for name, data in files:
            out.append(self.inputs.add_document(kind, name, data, int(self.cfg.inputs.get("max_doc_chars", 120000))))
            self.event("input", f"{kind}: {name}", f"{out[-1]['chars']} chars", kind=kind)
        return out

    def add_local_repo(self, path: str, name: str = "", branch: str = "local") -> dict:
        """A repository already on this machine (a checkout or an unzipped copy) - for local testing and offline work."""
        p = Path(path).expanduser()
        if not p.is_dir():
            raise ValueError(f"folder not found: {p}")
        name = name or p.name
        rec = self.inputs.add_repo(name, f"file://{p}", branch, p, self.cfg.inputs.repo, {"provider": "local", "project": str(p)})
        self.event("input", f"local repository {name}: {rec['files']} files indexed", json.dumps(rec["languages"]), kind="repo")
        return rec

    def add_repo(self, url: str, token: str, branch: str = "", name: str = "", subpath: str = "", refresh: bool = False,
                 progress=None) -> dict:
        rc = self.cfg.inputs.repo
        say = progress or (lambda msg: None)
        if url.startswith("file://") or (url and not url.startswith("http") and Path(url).expanduser().is_dir()):
            say("indexing the local folder ...")
            return self.add_local_repo(url.replace("file://", ""), name, branch or "local")
        say("contacting the git server ...")
        gc = GitClient(url, token, self.cfg.git.get("ssl_verify", True), self.cfg.git.get("default_provider", "gitlab"))
        info = gc.project_info()
        branch = branch or gc.info.get("branch") or info.get("default_branch") or "main"
        name = name or gc.project.rsplit("/", 1)[-1]
        cache_root = self.cfg.path(self.cfg.storage.get("repo_cache_dir", "data/cache/repos")) / _safe(self.user) / _safe(f"{gc.project}@{branch}")
        self.event("input", f"repository {name}@{branch}: downloading", url, kind="repo")
        d = gc.download(cache_root, branch, rc.get("code_extensions", ["py", "sql"]), int(rc.get("max_file_kb", 400)),
                        int(rc.get("max_files", 6000)), float(rc.get("cache_hours", 24)), refresh, subpath, progress=say,
                        use_git_cli=bool(rc.get("use_git_cli", True)))
        say("indexing files (symbols, search index) ...")
        rec = self.inputs.add_repo(name, url, branch, cache_root, rc, {"provider": gc.provider, "project": gc.project, "web_url": info.get("web_url", "")})
        self.event("input", f"repository {name}@{branch}: {rec['files']} files indexed" + (" (cached)" if d.get("cached") else ""), json.dumps(rec["languages"]), kind="repo")
        return rec

    def apply_inputs(self, src_folder: Path, data: dict) -> dict:
        """Load the inputs of a saved template into this chat: story, documents (files copied), tables and queries (with
        their stored descriptions - no Greenplum round trip), repositories (the cached clone is reused - no download),
        pipeline. Instant when the caches are still there; a repository whose cache is gone is reported for re-adding."""
        import shutil
        src_folder = Path(src_folder)
        loaded = {"story": None, "docs": {}, "tables": 0, "queries": 0, "repos": [], "missing_repos": []}
        if data.get("story"):
            self.inputs.story = data["story"]
            loaded["story"] = data["story"].get("title")
        for kind, docs in (data.get("docs") or {}).items():
            if kind not in self.inputs.docs:
                continue
            for d in docs:
                srcf = src_folder / "inputs" / kind / d["name"]
                if srcf.exists():
                    (self.folder / "inputs" / kind).mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(srcf, self.folder / "inputs" / kind / d["name"])
                self.inputs.docs[kind] = [x for x in self.inputs.docs[kind] if x["name"] != d["name"]] + [d]
                loaded["docs"][kind] = loaded["docs"].get(kind, 0) + 1
        for t in data.get("tables") or []:
            self.inputs.tables = [x for x in self.inputs.tables if (x["schema"], x["table"]) != (t["schema"], t["table"])] + [t]
            loaded["tables"] += 1
        for q in data.get("queries") or []:
            self.inputs.queries = [x for x in self.inputs.queries if x.get("name") != q.get("name")] + [q]
            loaded["queries"] += 1
        for r in data.get("repos") or []:
            if Path(r.get("path", "")).exists():
                self.inputs.repos = [x for x in self.inputs.repos if x["name"] != r["name"]] + [r]
                loaded["repos"].append(f"{r['name']}@{r.get('branch', '')}")
            else:
                loaded["missing_repos"].append(r.get("url") or r["name"])
        if data.get("pipeline"):
            self.inputs.pipeline = list(data["pipeline"])
        loaded["packs"] = []
        for pk in data.get("packs") or []:
            zp = Path(pk.get("zip", ""))
            if zp.exists():
                try:
                    rec = self.inputs.add_pack(zp.name, zp.read_bytes(), zp.parent, emb_cfg=dict(self.cfg.get("embeddings") or {}), cfg_repo=self.cfg.inputs.get("repo", {}))
                    loaded["packs"].append(f"{rec['system']} {rec['version']}")
                except Exception as e:  # noqa: BLE001
                    loaded["missing_repos"].append(f"pack {pk.get('name')}: {e}")
            else:
                loaded["missing_repos"].append(f"pack {pk.get('name')} (zip gone)")
        if data.get("git_defaults"):
            self.inputs.set_git_defaults(**data["git_defaults"])
        self.inputs._save()
        self.event("input", "template loaded", json.dumps(loaded), kind="template")
        return loaded

    def attach_pack(self, name: str, data: bytes, progress=None) -> dict:
        """Attach a System Knowledge Pack zip (project 6 output) to this chat."""
        kp = self.cfg.get("knowledge_packs") or {}
        shared = self.cfg.path(kp.get("shared_cache_dir", "data/packs"))
        rec = self.inputs.add_pack(name, data, shared, emb_cfg=dict(self.cfg.get("embeddings") or {}), cfg_repo=self.cfg.inputs.get("repo", {}), progress=progress)
        self.event("input", f"knowledge pack {rec['system']} {rec['version']} attached",
                   f"{rec['counts'].get('items', 0)} items, {rec['counts'].get('folders', 0)} folders, {rec.get('tables_added', 0)} tables, repo {rec['repo_name']}", kind="pack")
        return rec

    def add_tables(self, gp, schema: str, tables: List[str], progress=None, refresh: bool = False) -> List[dict]:
        out = []
        n = int(self.cfg.inputs.greenplum.get("sample_rows", 5))
        todo = tables[: int(self.cfg.inputs.greenplum.get("max_tables", 50))]
        pairs = []
        for t in todo:
            sch, name = (t.split(".", 1) if "." in t else (schema, t))
            pairs.append((sch.strip(), name.strip()))
        t0 = time.time()
        # per-user on-disk cache of table descriptions (catalog + sample): a table already described today is not read again
        gcfg = self.cfg.inputs.greenplum
        hours = float(gcfg.get("cache_hours", 24) or 0)
        cdir = self.cfg.path(self.cfg.storage.get("data_dir", "data")) / "cache" / "gp" / _safe(self.user) / _safe(f"{gp.conn_info.get('host', 'local')}_{gp.conn_info.get('database', '')}")
        cdir.mkdir(parents=True, exist_ok=True)
        described, fresh_pairs = [], []
        for sch, name in pairs:
            f = cdir / f"{_safe(sch)}.{_safe(name)}.json"
            if hours and not refresh and f.exists() and (time.time() - f.stat().st_mtime) / 3600 <= hours:
                try:
                    described.append(json.loads(f.read_text(encoding="utf-8")))
                    continue
                except Exception:  # noqa: BLE001
                    pass
            fresh_pairs.append((sch, name))
        if described and progress:
            progress(f"{len(described)} table(s) taken from today's cache ...")
        if fresh_pairs:
            for d in gp.describe_many(fresh_pairs, n, progress=progress, sample_timeout_s=int(gcfg.get("sample_timeout_seconds", 15))):
                described.append(d)
                try:
                    (cdir / f"{_safe(d['schema'])}.{_safe(d['table'])}.json").write_text(json.dumps(d, ensure_ascii=False, default=str), encoding="utf-8")
                except Exception:  # noqa: BLE001
                    pass
        for d in described:
            out.append(self.inputs.add_table(d))
            self.event("input", f"table {d['schema']}.{d['table']}: {out[-1]['columns']} columns", kind="table")
        self.log(f"{len(described)} table(s) described in {fmt_secs(time.time() - t0)}")
        return out

    def add_query(self, gp, sql: str, name: str = "") -> dict:
        q = gp.query(sql, 200)
        q["name"] = name
        r = self.inputs.add_query(q)
        self.event("input", f"query {r['name']}: {r['row_count']} rows", kind="query")
        return r

    # ------------------------------------------------------------------ the run
    # ------------------------------------------------------------------ plan lock: same story -> same plan
    def _plan_lock_cfg(self) -> dict:
        return dict((self.cfg.get("generation") or {}).get("plan_lock") or {})

    def _plan_fingerprint(self, ctx) -> dict:
        """Everything that SHOULD change the plan, and nothing that should not (chat id, branch name, time, run number):
        story text + code blocks, user instructions, attached documents and tables (by content hash), knowledge pack
        versions, base branch commit (configurable), planner deployment, plan_version."""
        import hashlib as _hl
        pl = self._plan_lock_cfg()
        st = self.inputs.story or {}
        norm = lambda t: " ".join(str(t or "").split())  # noqa: E731
        docs = []
        for kind, lst in (self.inputs.docs or {}).items():
            for d in lst or []:
                docs.append([kind, d.get("sha") or _hl.sha256(str(d.get("text", "")).encode("utf-8", "replace")).hexdigest()[:16]])
        fp = {"plan_version": str(pl.get("plan_version", "1")),
              "planner": self.llm.deployment_for("planner_agent") if hasattr(self.llm, "deployment_for") else "",
              "story": {"id": str(st.get("id", "")), "title": norm(st.get("title")), "text": _hl.sha256(norm(st.get("text")).encode("utf-8", "replace")).hexdigest(),
                        "code": [_hl.sha256(norm(b.get("code")).encode("utf-8", "replace")).hexdigest()[:16] for b in (st.get("code_blocks") or [])]},
              "instructions": sorted({norm(i) for i in (self.inputs.instructions or []) if norm(i)}),
              "docs": sorted(docs),
              "tables": sorted(str(t.get("name") or t.get("table") or "") for t in (self.inputs.tables or [])),
              "packs": sorted(f"{p.get('system')}@{p.get('version')}" for p in (self.inputs.packs or [])),
              "repos": sorted(f"{r.get('name')}" for r in (self.inputs.repos or []) if not r.get("from_branch"))}
        if pl.get("include_base_commit", True):
            fp["base"] = sorted(f"{b.get('repo_url')}@{b.get('base')}:{b.get('base_sha')}" for b in (self.inputs.branches or []))
        else:
            fp["base"] = sorted(f"{b.get('repo_url')}@{b.get('base')}" for b in (self.inputs.branches or []))
        if pl.get("scope", "shared") == "user":
            fp["user"] = self.user
        return fp

    def _plan_lock_path(self, fp: dict) -> Path:
        import hashlib as _hl
        key = _hl.sha256(json.dumps(fp, sort_keys=True).encode()).hexdigest()[:32]
        root = self.cfg.path(self.cfg.storage.get("plan_lock_dir", "data/cache/plans")) if hasattr(self.cfg, "path") else Path("data/cache/plans")
        root.mkdir(parents=True, exist_ok=True)
        return root / f"plan_{key}.json"

    def _locked_plan(self, ctx, replan: bool):
        pl = self._plan_lock_cfg()
        if not pl.get("enabled", True) or pl.get("scope") == "off":
            return None, None
        fp = self._plan_fingerprint(ctx)
        path = self._plan_lock_path(fp)
        if replan or not path.is_file():
            return None, path
        try:
            rec = json.loads(path.read_text(encoding="utf-8"))
            return rec.get("plan"), path
        except Exception:  # noqa: BLE001
            return None, path

    def run(self, instructions: str = "", pipeline: Optional[List[str]] = None, replan: bool = False) -> dict:
        """Runs the agent pipeline of this chat (inputs.pipeline, editable in the UI) in order.
        Stages per agent: story | knowledge, data, repo (parallel) | planner | coder (generate + validate) | reviewer (+ fix)."""
        if self.inputs.story is None:
            raise ValueError("add a story first (drag the Story icon into the chat)")
        with self._lock:
            if self.running:
                raise RuntimeError("a run is already in progress for this chat")
            self.running = True
        t0 = time.time()
        if instructions and instructions.strip().lower().startswith("/replan"):
            replan, instructions = True, instructions.strip()[len("/replan"):].strip()
        self._fresh_llm()                                   # this run's own token counters (the server's client is shared)
        budget = float(self.cfg.product.get("max_run_minutes", 5)) * 60
        pipe = [a for a in (pipeline or self.inputs.pipeline or DEFAULT_PIPELINE) if a in DEFAULT_PIPELINE]
        # every run starts from the repository as it is: nothing from an earlier run is "already there"
        self.files, self.findings, self.review, self.plan = {}, [], {}, {}
        self._rule_hits, self._stuck = {}, []
        if "coder_agent" in pipe and "planner_agent" not in pipe:
            pipe.insert(pipe.index("coder_agent"), "planner_agent")          # the coder needs a plan
        try:
            if instructions:
                self.inputs.add_instruction(instructions)
            self.event("milestone", "run started", f"budget {budget / 60:.0f} min - pipeline: " + " > ".join(a.replace("_agent", "") for a in pipe), pct=0, pipeline=pipe)
            pack = build_pack(self.inputs, self.cfg)
            save_pack(pack, self.folder)
            self.event("log", "context pack built", json.dumps(pack["chars"]))
            ctx = AgentContext(self.cfg, self.llm, self.inputs, pack, self._trace_sink, deadline=t0 + budget)
            self.ctx = ctx
            self._attach_semantic(ctx)
            n_steps = max(1, len(pipe))
            pct = lambda i: int(5 + 85 * i / n_steps)  # noqa: E731
            step = 0
            # ---- story
            if "story_agent" in pipe:
                self._stage("story", pct(step)); step += 1
                StoryAgent(ctx).execute()
                self.event("result", "requirements", json.dumps({k: ctx.story.get(k) for k in ("summary", "feature_name", "target_languages")}), kind="story")
            else:
                st = self.inputs.story
                ctx.story = {"summary": st.get("text", "")[:2000], "goal": st.get("title", ""), "feature_name": st.get("title", "")[:60],
                             "functional_requirements": [], "business_rules": [], "acceptance_criteria": st.get("acceptance_criteria", []), "target_languages": []}
                self.event("log", "story agent skipped - the story text is used as is")
            # ---- knowledge, data, repo: independent -> parallel
            group = [(a, k) for a, k in (("knowledge_agent", "knowledge"), ("data_agent", "data"), ("repo_agent", "repo")) if a in pipe]
            if group:
                for _, k in group:
                    self._stage(k, pct(step), running=True)
                agents = {"knowledge_agent": KnowledgeAgent, "data_agent": DataAgent, "repo_agent": RepoAgent}
                with cf.ThreadPoolExecutor(len(group)) as ex:
                    futs = {ex.submit(agents[a](ctx).execute): k for a, k in group}
                    for f in cf.as_completed(futs):
                        try:
                            f.result()
                            self.event("milestone", f"{futs[f]} done", stage_done=futs[f])
                        except Exception as e:  # noqa: BLE001
                            self.event("error", f"{futs[f]} agent failed (continuing)", str(e)[:300], stage_done=futs[f])
                step += len(group)
                if ctx.knowledge.get("rules"):
                    self.event("log", f"{len(ctx.knowledge['rules'])} checkable rule(s) extracted from the standards")
            # ---- plan
            if "planner_agent" in pipe:
                self._stage("plan", pct(step)); step += 1
                locked, lock_path = self._locked_plan(ctx, replan)
                if locked:
                    ctx.plan = json.loads(json.dumps(locked))
                    ctx.timings.append({"agent": "planner_agent", "task": "plan (locked)", "seconds": 0.0, "steps": 0, "fix_rounds": 0, "cached": True, "issues": 0})
                    self.event("log", f"plan reused - the same story with the same inputs was planned before ({len(ctx.plan.get('files', []))} file(s)); "
                                      "tick 'new plan' next to Run (or type /replan) to plan again")
                else:
                    PlannerAgent(ctx).execute()
                    t_sn = time.time()
                    self._ensure_registrations(ctx)
                    ctx.timings.append({"agent": "safety_net", "task": "registration / companion check (code)", "seconds": round(time.time() - t_sn, 1), "steps": 0, "fix_rounds": 0, "cached": False, "issues": 0})
                    if lock_path is not None and ctx.plan.get("files"):
                        try:
                            lock_path.write_text(json.dumps({"fingerprint": self._plan_fingerprint(ctx), "created": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                                                             "by": self.user, "chat": self.chat_id, "plan": ctx.plan}, ensure_ascii=False, indent=1, default=str), encoding="utf-8")
                            self.event("log", ("new plan stored for this story" + (" (replaces the previous one)" if replan else "")
                                               + " - every later run of the same story with the same inputs reuses it"))
                        except Exception as e:  # noqa: BLE001
                            log.warning("plan lock not written: %s", e)
                ctx.pack = build_pack(self.inputs, self.cfg, query_hint=ctx.story.get("summary", ""), plan=ctx.plan)
                save_pack(ctx.pack, self.folder)
                self.plan = ctx.plan
                self._save_json("plan.json", self.plan)
                self.event("result", f"plan: {len(self.plan.get('files', []))} file(s)", self.plan.get("approach", ""), kind="plan",
                           files=[{"path": f["path"], "action": f["action"], "language": f["language"]} for f in self.plan.get("files", [])], stage_done="plan")
            # ---- code (generation + validation may use the budget only up to the review reserve: the review always runs)
            reserve = min(0.3 * budget, float(self.cfg.product.get("review_reserve_minutes", 4)) * 60) if "reviewer_agent" in pipe else 0
            if "coder_agent" in pipe:
                ctx.deadline = t0 + budget - reserve
                self._stage("generate", pct(step)); step += 1
                self._generate(ctx)
                self.event("milestone", "generation done", stage_done="generate")
                self._stage("validate", pct(step))
                self._validate_and_fix(ctx)
                self.event("milestone", "validation done", stage_done="validate")
                ctx.deadline = t0 + budget
            # ---- review (+ fix)
            if "reviewer_agent" in pipe and self.files:
                if not ctx.out_of_time() or reserve:
                    self._stage("review", pct(step)); step += 1
                    prev = self._load_json("review.json") or None
                    rev = ReviewerAgent(ctx).execute(self.findings, previous=prev if prev and prev.get("file_hashes") else None)
                    if rev.get("incremental"):
                        inc = rev["incremental"]
                        self.event("log", f"review scope: {len(inc.get('reviewed', []))} file(s) reviewed, {len(inc.get('carried_over', []))} unchanged since the last review (findings carried over)")
                    self.review = rev
                    self._save_json("review.json", rev)
                    self.event("result", f"review: {rev.get('verdict')} score {rev.get('score')}", rev.get("summary", ""), kind="review",
                               findings=len(rev.get("findings", [])), stage_done="review")
                    sev = set(self.cfg.generation.get("review_fix_severities", ["critical", "high"]))
                    to_fix = [f for f in rev.get("findings", []) if f.get("severity") in sev and f.get("path") in self.files]
                    to_fix = [f for f in to_fix if f.get("status") != "fixed"]      # carried-over findings already fixed stay fixed
                    for f in rev.get("findings", []) or []:          # status of every review finding, shown in the UI
                        if f.get("status") == "fixed":
                            continue
                        f["status"] = "open" if f in to_fix else ("suggestion" if f.get("severity") in ("medium", "low", "info") else "open")
                    if to_fix and not ctx.out_of_time():
                        self._stage("fix", pct(step))
                        self._fix(ctx, self._with_examples(ctx, to_fix), "review")
                        self._validate_and_fix(ctx, rounds=1)
                        for f in to_fix:
                            f["status"] = "fixed"
                            f["fixed_by"] = "coder fix pass after the review; validator re-run on the regenerated file"
                        self.event("milestone", "fixes applied", f"{len(to_fix)} review finding(s) sent to the coder and regenerated", stage_done="fix")
                    elif to_fix:
                        for f in to_fix:
                            f["status"] = "open"
                            f["fixed_by"] = "not fixed: time budget used up - fix by hand or ask in the chat"
                        self.event("log", f"{len(to_fix)} critical / high review finding(s) NOT fixed - time budget used up", stage_skipped="fix")
                    else:
                        self.event("log", "no critical / high review finding - nothing to regenerate", stage_skipped="fix")
                    self.review = rev
                    self._save_json("review.json", rev)
                else:
                    self.review = {"skipped": f"time budget ({budget / 60:.0f} min) used up before the review - raise product.max_run_minutes in the config",
                                   "findings": [], "verdict": "skipped", "score": None}
                    self._save_json("review.json", self.review)
                    self.event("log", "time budget used up - review skipped", stage_skipped="review")
            self._stage("outputs", 95)
            self._write_outputs(t0)
            if self.files:
                try:
                    self.save_point(f"run-{sum(1 for x in self.savepoints() if x['name'].startswith('run-')) + 1}", note="automatic savepoint after the run")
                except Exception as e:  # noqa: BLE001
                    log.warning("auto savepoint failed: %s", e)
                self.commit_to_branches(f"run {sum(1 for x in self.savepoints() if x['name'].startswith('run-'))}")
            self.event("milestone", "run complete", f"{len(self.files)} file(s), confidence {self.summary.get('confidence', {}).get('score')} "
                       f"({self.summary.get('confidence', {}).get('grade')}), quality {self.summary.get('quality_score')}, "
                       f"{fmt_secs(self.summary.get('duration_seconds'))}, {self.summary.get('tokens', {}).get('total_tokens', 0)} tokens, ${self.summary.get('cost_usd') or 0:.2f}", pct=100, kind="done", stage_done="outputs")
            return self.summary
        except Exception as e:
            log.exception("run failed")
            self.event("error", "run failed", f"{type(e).__name__}: {e}", kind="failed")
            self._write_outputs(t0, failed=str(e))
            raise
        finally:
            self.running = False

    def _stage(self, key: str, pct: int, running: bool = False) -> None:
        title = dict(STAGES).get(key, key)
        self.event("milestone", title, pct=pct, stage=key, parallel=running)

    def _ensure_registrations(self, ctx: AgentContext) -> None:
        """Safety net after the planner: a NEW script in a folder whose siblings are registered somewhere (DAG task list,
        config, task-name file) gets that file added to the plan as a modify - unless the planner declined it with a reason.
        A script that is never registered never runs; this is the defect the planner is most likely to argue away."""
        plan = ctx.plan or {}
        files = plan.get("files") or []
        planned = {f["path"] for f in files}
        # a decline only counts when it says WHICH planned file runs the new script; "the existing operator already
        # registers the folder" is the sentence that leaves a new script unregistered
        runs = re.compile(r"\b(called|invoked|included|executed|sourced|run by|runs it|runs the|\\i\b|imports?|wrapped)")
        declined = {x.get("path") for x in plan.get("registration_changes") or []
                    if "not needed" in str(x.get("what", "")).lower() and runs.search(str(x.get("what", "")).lower())}
        declined_any = {x.get("path") for x in plan.get("registration_changes") or [] if "not needed" in str(x.get("what", "")).lower()}
        pack_mode = bool(self.inputs.packs)             # with a knowledge pack only PROVEN rules complete the plan by code
        from .kpack.repo import PackRepoIndex
        added = []
        for f in list(files):
            if f.get("action") != "create" or f.get("language", "").lower() not in ("sql", "python", "r", "shell", "ipynb"):
                continue
            folder = f["path"].rsplit("/", 1)[0] if "/" in f["path"] else ""
            for idx in self.inputs.indexes():
                if f.get("repo") and idx.name != f.get("repo"):
                    continue
                for c in idx.registration_candidates(folder)[:3 if pack_mode else 1]:
                    if c["path"] in planned or c["path"] in declined:
                        continue
                    if pack_mode and not PackRepoIndex.is_proven(c):
                        continue                          # pack mode: only registries the pack proved; the rest is the planner's call
                    spec = {"path": c["path"], "action": "modify", "language": idx.files[c["path"]]["language"],
                            "purpose": f"register {f['path'].rsplit('/', 1)[-1]} exactly like its siblings ({c['reason']}); example line: {c.get('example_line', '')}",
                            "outline": [f"add the entry for {f['path'].rsplit('/', 1)[-1]} next to the neighbouring entries, same style and order",
                                        "change nothing else"],
                            "depends_on": [f["path"]], "repo": f.get("repo", ""), "requirements_covered": f.get("requirements_covered", [])}
                    files.append(spec)
                    planned.add(c["path"])
                    plan.setdefault("registration_changes", []).append({"path": c["path"], "what": spec["purpose"]})
                    added.append(c["path"])
        # companions are deterministic too: the history / archive script of the same table, the config / name registries
        # that list its siblings. Planned, declined with a reason, or added here - never silently absent.
        for f in list(files):
            if f.get("language", "").lower() not in ("sql", "python", "r"):
                continue
            for idx in self.inputs.indexes():
                if f.get("repo") and idx.name != f.get("repo"):
                    continue
                if not idx.files:
                    continue
                cands = idx.companions(f["path"], (ctx.story or {}).get("tables_mentioned", [])) if f["path"] in idx.files \
                    else idx.companions_for_new(f["path"])
                for c in cands[:4]:
                    if c["relation"] == "consumer" or c["path"] in planned or c["path"] in declined_any:
                        continue
                    if pack_mode and not (c["relation"] == "sibling_to_create" or "pack companion rule" in c.get("reason", "")):
                        continue                          # pack mode: only learnt companion rules, never loose name mentions
                    exists = c.get("exists", True) and c["path"] in idx.files
                    spec = {"path": c["path"], "action": "modify" if exists else "create",
                            "language": idx.files[c["path"]]["language"] if exists else (f.get("language") or "sql"),
                            "purpose": (f"add the entry for {f['path'].rsplit('/', 1)[-1]} exactly like the sibling entries ({c['reason'][:160]})"
                                        if exists else f"companion of {f['path']}: {c['reason'][:200]}"),
                            "outline": ["copy the shape of the sibling entry / file; change nothing else"],
                            "depends_on": [f["path"]], "repo": f.get("repo", ""), "requirements_covered": f.get("requirements_covered", [])}
                    files.append(spec)
                    planned.add(c["path"])
                    plan.setdefault("registration_changes", []).append({"path": c["path"], "what": spec["purpose"]})
                    added.append(c["path"])
        if added:
            plan["files"] = files
            ctx.plan = plan
            plan.setdefault("notes", []).append("added by the safety net (registration / companion files found in the repository): " + ", ".join(added))
            self.event("log", "registration / companion files added to the plan by the safety net: " + ", ".join(added))

    def _existing(self, path: str, repo: str = "") -> Optional[str]:
        for idx in self.inputs.indexes():
            if (not repo or idx.name == repo) and path in idx.files:
                return idx.read(path, 10 ** 7)
        return None

    def _generate(self, ctx: AgentContext) -> None:
        files = ctx.plan.get("files", [])
        done = {}

        def one(spec):
            if ctx.out_of_time():
                return spec["path"], None
            existing = self._existing(spec["path"], spec.get("repo", "")) if spec["action"] == "modify" else None
            try:
                r = CoderAgent(ctx).write(spec, existing, "modify" if existing is not None else "create")
            except Exception as e:  # noqa: BLE001 - one file must not kill the whole run
                self.event("log", f"{spec['path']}: coder failed - {type(e).__name__}: {str(e)[:200]}", level="error")
                return spec["path"], {"error": f"{type(e).__name__}: {e}"}
            return spec["path"], r
        # files without dependencies first (parallel), then dependants
        order = sorted(files, key=lambda f: len(f.get("depends_on") or []))
        with cf.ThreadPoolExecutor(int(self.cfg.generation.get("parallel_files", 4))) as ex:
            for path, r in ex.map(one, order):
                if r is None:
                    self.event("log", f"{path}: skipped (time budget)")
                    continue
                if r.get("error"):
                    ctx.plan.setdefault("notes", []).append(f"{path}: not generated - {r['error'][:200]}")
                    continue
                spec = next(f for f in files if f["path"] == path)
                if spec["action"] == "modify":
                    before = self._existing(path, spec.get("repo", ""))
                    if before is not None and (r.get("content") or "").strip() == before.strip():
                        # the coder read the file and found nothing to add: an unchanged file is not an output - it is removed
                        # from the plan, the files, the review and the push (the log keeps the reason)
                        self.event("log", f"{path}: unchanged - not part of the output ({(r.get('explanation') or '')[:160]})")
                        ctx.plan["files"] = [f for f in (ctx.plan.get("files") or []) if f["path"] != path]
                        ctx.plan["registration_changes"] = [x for x in (ctx.plan.get("registration_changes") or []) if x.get("path") != path]
                        self.files.pop(path, None); ctx.files.pop(path, None)
                        continue
                rec = {"path": path, "language": r.get("language") or spec["language"], "content": r.get("content", ""),
                       "action": spec["action"], "purpose": spec["purpose"], "explanation": r.get("explanation", ""),
                       "assumptions": r.get("assumptions", []), "confidence": r.get("confidence", 0), "repo": spec.get("repo", "")}
                if r.get("unsafe"):
                    rec["unsafe"] = r["unsafe"]
                    self.event("log", f"{path}: {r['unsafe']}", level="error")
                    ctx.plan.setdefault("notes", []).append(f"{path}: {r['unsafe']} - the change still has to be made (ask in the chat or by hand)")
                self.files[path] = rec
                ctx.files[path] = rec
                self._save_file(rec)
                self.event("file", f"{spec['action']}: {path}", f"{len(rec['content'])} chars, confidence {rec['confidence']}", kind="file",
                           path=path, language=rec["language"])

    def _validate_and_fix(self, ctx: AgentContext, rounds: Optional[int] = None) -> None:
        rounds = int(self.cfg.generation.get("validate_fix_rounds", 2)) if rounds is None else rounds
        dialect = (ctx.data or {}).get("sql_dialect") or "postgres"
        for rnd in range(rounds + 1):
            findings = []
            for p, f in self.files.items():
                existing = self._existing(p, f.get("repo", "")) if f.get("action") == "modify" else None
                findings += validate_file(p, f["content"], f.get("language", ""), ctx.rules, "postgres" if "green" in dialect.lower() else dialect,
                                          existing=existing)
            for p, f in self.files.items():                       # a modify that could not be made safely is a blocking fact
                if f.get("unsafe"):
                    findings.append({"path": p, "severity": "high", "kind": "not_changed", "line": 0,
                                     "message": f"file NOT changed: {f['unsafe']}",
                                     "suggestion": "ask in the chat ('add the registration of <file> to the DAG') or make the change by hand"})
            self.findings = findings
            ctx.findings = findings
            self._save_json("findings.json", findings)
            blocking = [x for x in findings if x["severity"] in ("critical", "high") and x.get("kind") != "not_changed"]
            # loop guard: the same rule on the same file after a fix means the coder cannot satisfy it - stop paying for retries
            retry, stuck = [], []
            for x in blocking:
                key = (x["path"], x.get("rule") or x.get("kind"), (x.get("message") or "")[:60])
                n = self._rule_hits.get(key, 0)
                (stuck if n >= 2 else retry).append(x)
                self._rule_hits[key] = n + 1
            if stuck:
                self.event("log", f"{len(stuck)} finding(s) recur after a fix - not retried (see 'Faster and cheaper'): " +
                           "; ".join(f"{x['path'].rsplit('/', 1)[-1]}: {x['message'][:60]}" for x in stuck[:4]))
                self._stuck += [{"path": x["path"], "rule": x.get("rule") or x.get("kind"), "message": x["message"]} for x in stuck]
            self.event("result", f"validation: {len(findings)} finding(s), {len(blocking)} blocking, score {quality_score(findings)}",
                       "; ".join(f"{x['path']}: {x['message']}" for x in blocking[:5]), kind="validation", findings=len(findings))
            if not retry or rnd == rounds or ctx.out_of_time():
                return
            self._fix(ctx, self._with_examples(ctx, retry), "validator")

    def _with_examples(self, ctx: AgentContext, findings: List[dict]) -> List[dict]:
        """A rule finding ('end every created table with GRANT SELECT ...') gets the line of a sibling file that satisfies the
        rule, verbatim - the coder then copies instead of guessing the exact parameter names."""
        rules = {r.get("id"): r for r in (ctx.rules or [])}
        out = []
        for f in findings:
            f = dict(f)
            r = rules.get(f.get("rule"))
            if r and r.get("pattern"):
                try:
                    rx = re.compile(r["pattern"], re.I | re.M)
                except re.error:
                    rx = None
                folder = f["path"].rsplit("/", 1)[0] if "/" in f["path"] else ""
                for idx in self.inputs.indexes():
                    sibs = [p for p in idx.files if (p.rsplit("/", 1)[0] if "/" in p else "") == folder and p != f["path"]][:6]
                    for sp in sibs:
                        text = idx.read(sp, 200000)
                        m = rx.search(text) if rx else None
                        if m and r.get("must_match"):
                            line = text[text.rfind("\n", 0, m.start()) + 1: text.find("\n", m.end()) if text.find("\n", m.end()) > 0 else len(text)]
                            f["example_from_sibling"] = {"file": sp, "line": line.strip()[:300]}
                            break
                    if f.get("example_from_sibling"):
                        break
            out.append(f)
        return out

    def _fix(self, ctx: AgentContext, findings: List[dict], who: str) -> None:
        by_path: Dict[str, List[dict]] = {}
        for f in findings:
            by_path.setdefault(f["path"], []).append(f)

        def one(path):
            rec = self.files[path]
            spec = {"path": path, "language": rec["language"], "purpose": rec["purpose"], "outline": [], "repo": rec.get("repo", "")}
            r = CoderAgent(ctx).write(spec, rec["content"], "fix", by_path[path])
            return path, r
        with cf.ThreadPoolExecutor(int(self.cfg.generation.get("parallel_files", 4))) as ex:
            for path, r in ex.map(one, list(by_path)):
                if r.get("content"):
                    if r.get("unsafe"):
                        self.event("log", f"{path}: fix rejected - {r['unsafe']}", level="error")
                        continue
                    base = self._existing(path, self.files[path].get("repo", "")) if self.files[path].get("action") == "modify" else None
                    if base is not None and r["content"].strip() == base.strip():
                        self.event("log", f"{path}: unchanged after the fix - removed from the output")
                        self.files.pop(path, None); ctx.files.pop(path, None)
                        if self.plan: self.plan["files"] = [f for f in (self.plan.get("files") or []) if f["path"] != path]
                        continue
                    self.files[path]["content"] = r["content"]
                    self.files[path]["explanation"] = r.get("explanation", self.files[path]["explanation"])
                    if r.get("confidence"):
                        self.files[path]["confidence"] = r["confidence"]
                    ctx.files[path] = self.files[path]
                    self._save_file(self.files[path])
                    self.event("file", f"fixed ({who}): {path}", "; ".join(f["message"][:80] for f in by_path[path][:3]), kind="file",
                               path=path, language=self.files[path]["language"])

    # ------------------------------------------------------------------ follow-up changes in the chat
    def change(self, request: str) -> dict:
        if not self.files:
            raise ValueError("nothing generated yet - run the story first")
        with self._lock:
            if self.running:
                raise RuntimeError("a run is already in progress")
            self.running = True
        t0 = time.time()
        try:
            self._fresh_llm()
            ctx = self.ctx or self._rebuild_ctx()
            ctx.llm = self.llm
            ctx.deadline = t0 + float(self.cfg.product.get("max_run_minutes", 5)) * 60
            self.event("milestone", "change requested", request[:200], pct=0)
            r = ChangeAgent(ctx).execute(request, self.history)
            if r.get("needs_clarification") and r.get("question"):
                self.event("milestone", "question", r["question"], pct=100, kind="done")
                return {"reply": r["question"], "changed": []}
            changed = []
            for ch in r.get("changes", []):
                p = ch["path"]
                if ch["action"] == "delete":
                    self.files.pop(p, None)
                    ctx.files.pop(p, None)
                    try:
                        (self.folder / "files" / p).unlink()
                    except Exception:  # noqa: BLE001
                        pass
                    changed.append(p)
                    continue
                rec = self.files.get(p)
                spec = {"path": p, "language": ch.get("language") or (rec or {}).get("language", ""), "purpose": ch.get("purpose") or (rec or {}).get("purpose", ""),
                        "outline": ch.get("instructions", []), "repo": (rec or {}).get("repo", "")}
                existing = rec["content"] if rec else self._existing(p)
                mode = "fix" if rec else ("modify" if existing is not None else "create")
                out = CoderAgent(ctx).write(spec, existing, mode, [{"path": p, "severity": "high", "message": i} for i in ch.get("instructions", [])], request)
                if out.get("content"):
                    self.files[p] = {"path": p, "language": out.get("language") or spec["language"], "content": out["content"],
                                     "action": (rec or {}).get("action", "create"), "purpose": spec["purpose"],
                                     "explanation": out.get("explanation", ""), "assumptions": out.get("assumptions", []),
                                     "confidence": out.get("confidence", 0), "repo": spec["repo"]}
                    ctx.files[p] = self.files[p]
                    self._save_file(self.files[p])
                    changed.append(p)
                    self.event("file", f"changed: {p}", out.get("explanation", "")[:200], kind="file", path=p, language=self.files[p]["language"])
            if changed:
                self._validate_and_fix(ctx, rounds=1)
            self._write_outputs(t0)
            self.event("milestone", "change complete", f"{len(changed)} file(s)", pct=100, kind="done")
            return {"reply": r.get("reply", ""), "changed": changed, "understanding": r.get("understanding", "")}
        finally:
            self.running = False

    def _attach_semantic(self, ctx: AgentContext) -> None:
        """Second retriever (by meaning) when embeddings.enabled; the index is built lazily on the first search_similar call
        and its vectors are cached by text hash under the user's llm cache folder."""
        from .semantic import SemanticIndex, settings
        if not settings(self.cfg).get("enabled"):
            ctx.semantic = None
            return
        if getattr(self, "_semantic", None) is None:
            self._semantic = SemanticIndex(self.cfg, self.llm, self.inputs, self.llm.cache_dir)
        ctx.semantic = self._semantic
        self.event("log", f"semantic search ON (embeddings deployment {settings(self.cfg).get('deployment')}): agents may call search_similar "
                          "for plain-English phrases; every hit is confirmed against the exact index before it is used")

    def _rebuild_ctx(self) -> AgentContext:
        pack = build_pack(self.inputs, self.cfg)
        ctx = AgentContext(self.cfg, self.llm, self.inputs, pack, self._trace_sink)
        self._attach_semantic(ctx)
        ctx.plan = self.plan
        ctx.files = self.files
        st = self._load_json("story_result.json") or {}
        ctx.story = st
        kn = self._load_json("knowledge.json") or {}
        ctx.knowledge, ctx.rules = kn, kn.get("rules", [])
        ctx.data = self._load_json("data.json") or {}
        ctx.repo = self._load_json("repo.json") or {}
        ctx.review = self.review or {}
        self.ctx = ctx
        return ctx

    # ------------------------------------------------------------------ confidence
    def confidence(self) -> dict:
        """One number a developer can act on, built from three independent signals and capped by what is still open:
             40 % validator quality  (deterministic checks: syntax, Airflow, SQL parse, team rules)
             35 % reviewer score     (independent reviewer agent: requirements, story code, registration, impact, standards)
             25 % coder confidence   (the coder's own, averaged over the files)
           caps: review skipped -> max 70; open critical finding -> max 50; open high finding -> max 75;
                 a file below 60 coder confidence -> max 80; open questions in the plan -> -2 each (max -10).
           grade: High >= 85, Medium >= 70, Low < 70. The parts and caps are returned so the UI can explain the number."""
        if not self.files:
            return {"score": None, "grade": "none", "parts": {}, "caps": [], "explain": "no files generated"}
        q = quality_score(self.findings)
        rev = self.review or {}
        r_score = rev.get("score")
        coder = [f.get("confidence") for f in self.files.values() if isinstance(f.get("confidence"), (int, float))]
        c_mean = round(sum(coder) / len(coder), 1) if coder else None
        parts = {"validator_quality": q, "reviewer_score": r_score, "coder_confidence": c_mean}
        if r_score is None:
            score = 0.6 * q + 0.4 * (c_mean if c_mean is not None else q)
        else:
            score = 0.40 * q + 0.35 * r_score + 0.25 * (c_mean if c_mean is not None else r_score)
        caps = []
        open_sev = {f.get("severity") for f in self.findings} | {f.get("severity") for f in rev.get("findings", []) or [] if f.get("status") != "fixed"}
        if rev.get("skipped") or r_score is None:
            caps.append(("review did not run", 70))
        if "critical" in open_sev:
            caps.append(("an open critical finding", 50))
        elif "high" in open_sev:
            caps.append(("an open high finding", 75))
        if coder and min(coder) < 60:
            caps.append((f"a file with coder confidence {min(coder)}", 80))
        for why, cap in caps:
            score = min(score, cap)
        stuck_note = ""
        if getattr(self, "_stuck", None):
            byf = {}
            for x in self._stuck:
                byf.setdefault(x["path"].rsplit("/", 1)[-1], set()).add(str(x.get("rule") or "")[:30] or x["message"][:30])
            stuck_note = ("the same validator rule kept failing on the same file after a fix (" +
                          "; ".join(f"{k}: {', '.join(sorted(v))}" for k, v in list(byf.items())[:3]) +
                          ") - the rule's regex or its documented exception is probably wrong for this file type: check the standards text, "
                          "or add the file's folder to the rule's exempt list; the loop was stopped to save tokens")
        nq = len((self.plan or {}).get("questions") or [])
        if nq:
            score -= min(10, 2 * nq)
            caps.append((f"{nq} open question(s) in the plan", -min(10, 2 * nq)))
        score = int(round(max(0, min(100, score))))
        grade = "High" if score >= 85 else "Medium" if score >= 70 else "Low"
        explain = (f"40% validator {q} + 35% reviewer {r_score if r_score is not None else '-'} + 25% coder {c_mean if c_mean is not None else '-'}"
                   + ("; capped by " + ", ".join(f"{w} (max {c})" if c > 0 else f"{w} ({c})" for w, c in caps) if caps else ""))
        blocking = [{"path": f.get("path"), "line": f.get("line"), "severity": f.get("severity"), "message": f.get("message"), "from": "validator"}
                    for f in self.findings if f.get("severity") in ("critical", "high")]
        blocking += [{"path": f.get("path"), "line": f.get("line"), "severity": f.get("severity"), "message": f.get("message"),
                      "suggestion": f.get("suggestion"), "from": "reviewer"}
                     for f in (rev.get("findings", []) or []) if f.get("severity") in ("critical", "high") and f.get("status") != "fixed"]
        to_raise = [stuck_note, f"fix the {len(blocking)} blocking finding(s) listed below" if blocking else "",
                    "run the review (raise product.max_run_minutes)" if r_score is None else "",
                    "answer the open questions of the plan and re-run" if nq else ""]
        return {"score": score, "grade": grade, "parts": parts, "caps": [{"reason": w, "cap": c} for w, c in caps],
                "explain": explain, "to_raise": [t for t in to_raise if t], "blocking": blocking,
                "open_questions": list((self.plan or {}).get("questions") or [])}

    # ------------------------------------------------------------------ sources (what contributed to the generated code)
    def sources(self) -> dict:
        """Everything that contributed to this run's code, per source, with WHAT was taken from it: the story (requirements,
        rules, code blocks), every document (definitions / conventions / rules extracted from that file), every table
        (columns described, columns actually used in the generated code, sample rows), queries, repositories and the
        repository files (pattern imitated / modified / registration / companion / read / in context), terms looked up."""
        ov = self.inputs.overview()
        used = (self.ctx.used if self.ctx else []) or []
        pack = self._load_json("pack.json") or {}
        story_r = self._load_json("story_result.json") or {}
        kn = self._load_json("knowledge.json") or {}
        repo_r = self._load_json("repo.json") or {}
        gen_text = "\n".join(f.get("content", "") for f in self.files.values())
        by_tool: Dict[str, Dict[str, set]] = {}
        for u in used:
            by_tool.setdefault(u["tool"], {}).setdefault(u["ref"], set()).add(u["agent"].replace("_agent", ""))

        def refs(tool):
            return [{"ref": r, "agents": sorted(a)} for r, a in sorted(by_tool.get(tool, {}).items())]

        # ---- story
        st = ov.get("story") or {}
        story = None
        if st:
            cb = story_r.get("code_in_story") or []
            story = {"id": st.get("id"), "title": st.get("title"), "source": st.get("source", {}),
                     "extracted": f"{len(story_r.get('functional_requirements') or [])} requirements, {len(story_r.get('business_rules') or [])} business rules, "
                                  f"{len(story_r.get('acceptance_criteria') or [])} acceptance criteria, {len(cb)} code block(s) used as specification, "
                                  f"tables mentioned: {', '.join(story_r.get('tables_mentioned') or []) or '-'}"}
        # ---- documents: what the knowledge agent took from each file
        docs = []
        for kind in ("knowledge",):
            for d in (ov.get(kind) or []):
                name = d["name"]
                defs = [x for x in kn.get("definitions", []) if name.lower() in str(x.get("source", "")).lower()]
                conv = [x for x in kn.get("conventions", []) if name.lower() in str(x.get("source", "")).lower()]
                parts = []
                if defs:
                    parts.append(f"{len(defs)} definition(s): " + ", ".join(x.get("term", "") for x in defs[:8]) + (" ..." if len(defs) > 8 else ""))
                if conv:
                    parts.append(f"{len(conv)} convention(s): " + "; ".join(str(x.get("rule", ""))[:70] for x in conv[:4]) + (" ..." if len(conv) > 4 else ""))
                reads = sum(1 for u in used if u["tool"] in ("read_section", "define_term", "search_similar") and name.lower() in str(u.get("ref", "")).lower())
                if not parts and not reads:
                    continue                     # nothing was taken from this file by name: not listed as a source
                docs.append({"kind": "knowledge (glossary)" if d.get("kind") == "glossary" else "knowledge", "name": name, "chars": d.get("chars"),
                             "used_by": ["knowledge"] + (["story", "data", "planner", "coder", "reviewer"] if reads else []),
                             "process": "context pack (knowledge agent) " + ("+ look-ups by other agents" if reads else ""),
                             "extracted": "; ".join(parts)})
        # ---- tables: columns described, columns used in the generated code, samples
        tables = []
        for t in self.inputs.tables:
            cols = [c["name"] for c in t.get("columns", [])]
            used_cols = [c for c in cols if re.search(r"\b" + re.escape(c) + r"\b", gen_text)]
            desc = sorted({a for u in used if u["tool"] == "describe_table" and u["ref"].lower() == t["table"].lower() for a in [u["agent"].replace("_agent", "")]})
            tables.append({"table": f"{t['schema']}.{t['table']}", "columns": len(cols), "sample_rows": len(t.get("sample") or []),
                           "used_by": ["data"] + [a for a in desc if a != "data"],
                           "process": "context pack (data agent)" + (" + describe_table look-ups" if desc else "") + ("; columns in generated code" if used_cols else ""),
                           "extracted": f"{len(cols)} columns with types" + (f", keys {', '.join(t.get('keys') or [])}" if t.get("keys") else "")
                                        + (f", distribution {t.get('distribution')}" if t.get("distribution") else "") + f", {len(t.get('sample') or [])} sample rows"
                                        + (f"; columns used in the generated code: {', '.join(used_cols)}" if used_cols else "; no column of it appears in the generated code")})
        queries = [{"name": q["name"], "row_count": q.get("row_count"), "extracted": f"result shape: {len(q.get('columns') or [])} columns ({', '.join((q.get('columns') or [])[:10])}), {q.get('row_count')} rows"}
                   for q in self.inputs.queries]
        # ---- repository files and their role
        roles: Dict[str, List[str]] = {}
        def add(path, role):
            if path:
                roles.setdefault(path, [])
                if role not in roles[path]:
                    roles[path].append(role)
        for rp in pack.get("repos", []):
            for f in rp.get("relevant_files", []):
                add(f["path"], "in the context pack (relevant to the story / plan)")
        for x in repo_r.get("patterns_to_imitate", []) or []:
            add(x.get("path"), "pattern imitated: " + str(x.get("why", ""))[:90])
        for x in repo_r.get("existing_files_to_modify", []) or []:
            add(x.get("path"), "existing file to modify: " + str(x.get("why", ""))[:90])
        for x in repo_r.get("registration_points", []) or []:
            add(x.get("path"), "registration point: " + str(x.get("what_to_add", ""))[:90])
        for x in repo_r.get("companion_files", []) or []:
            add(x.get("path"), f"companion ({x.get('action', '')}): " + str(x.get("what_to_change", ""))[:90])
        for r in refs("read_file"):
            add(r["ref"], "read in full by " + ", ".join(r["agents"]))
        for pth, f in self.files.items():
            if f.get("action") == "modify":
                add(pth, "MODIFIED by this run")
        agents_of = {}
        for u in used:
            if u["tool"] in ("read_file", "grep_repo", "search_repo", "companion_files", "registration_points", "references", "search_similar"):
                agents_of.setdefault(u["ref"], set()).add(u["agent"].replace("_agent", ""))
        def how(pth, rl):
            parts = []
            if any("pattern" in r or "context pack" in r for r in rl): parts.append("retrieved into the context pack (BM25 / repo agent)")
            if any("registration" in r or "companion" in r for r in rl): parts.append("registration / companion look-up")
            if pth in agents_of: parts.append("read_file by " + ", ".join(sorted(agents_of[pth])))
            if any("MODIFIED" in r for r in rl): parts.append("modified by the coder")
            if any("semantic" in r for r in rl): parts.append("found by meaning (embeddings)")
            return "; ".join(parts) or "in the repository index"
        repo_files = [{"path": pth, "roles": rl, "used_by": sorted({"repo"} | agents_of.get(pth, set()) | ({"coder"} if any("MODIFIED" in r for r in rl) else set())),
                       "process": how(pth, rl)} for pth, rl in sorted(roles.items())]
        if kn.get("rules"):
            docs.append({"kind": "derived", "name": "validator rules", "chars": None,
                         "extracted": f"{len(kn['rules'])} checkable rule(s) derived from the standards files: " + ", ".join(str(r.get("id", "")) for r in kn["rules"][:8])})
        # ---- knowledge packs: what each pack contributed (conventions / definitions baseline, context block, pack look-ups)
        packs_src = []
        pack_tools = ("pack_search", "pack_folder", "pack_card", "pack_impact", "pack_exemplar")
        for pk in (ov.get("packs") or []):
            kp = next((x for x in (pack.get("packs") or []) if x.get("system") == pk.get("system")), {})
            lookups = [u for u in used if u["tool"] in pack_tools]
            agents = sorted({u["agent"].replace("_agent", "") for u in lookups} | {"planner", "coder", "reviewer"})
            kn_src = [x for x in kn.get("sources", []) or [] if "pack" in str(x)] if isinstance(kn.get("sources"), list) else []
            c = pk.get("counts") or {}
            packs_src.append({"name": pk.get("name"), "system": pk.get("system"), "version": pk.get("version"), "built_at": pk.get("built_at"),
                              "used_by": agents, "process": "pre-built facts (no model call): conventions / definitions / rules baseline, folder + table cards and code chunks "
                                                             "retrieved into the context pack" + (f"; {len(lookups)} pack look-up(s) by agents" if lookups else ""),
                              "extracted": f"{c.get('conventions', 0)} conventions, {c.get('definitions', 0)} definitions, {c.get('rules', 0)} rules, "
                                           f"{c.get('folders', 0)} folders, {c.get('tables_described', 0)} tables, {c.get('companion_patterns', 0)} companion rules; "
                                           f"context block {len(kp.get('context', '')) if kp else 0} chars" + ("; model layer" if pk.get("model_layer") else "; facts only"),
                              "repo": pk.get("repo_name"), "dense_index": pk.get("dense_index")})
        return {"story": story, "documents": docs, "packs": packs_src, "pack_lookups": [x for t in pack_tools for x in refs(t)], "tables": tables, "queries": queries,
                "repositories": [{"name": r["name"], "branch": r.get("branch"), "url": r.get("url"), "files_indexed": r.get("files"),
                                  "extracted": f"{r.get('files')} files indexed for search; {sum(1 for x in roles)} file(s) used (listed below)"} for r in (ov.get("repos") or [])],
                "repository_files": repo_files,
                "glossary_terms_looked_up": refs("define_term"), "knowledge_sections_read": refs("read_section"),
                "repository_searches": refs("search_repo") + refs("grep_repo"), "registration_lookups": refs("registration_points") + refs("companion_files") + refs("references"),
                "tables_described_on_demand": refs("describe_table"), "semantic_searches": refs("search_similar"),
                "semantic_index": (dict(self._semantic.stats, enabled=True) if getattr(self, "_semantic", None) else {"enabled": False}),
                "user_instructions": ov.get("instructions") or []}

    AGENT_OUTPUTS = {"story_agent": "story_result.json", "knowledge_agent": "knowledge.json", "data_agent": "data.json", "repo_agent": "repo.json",
                     "planner_agent": "plan.json", "reviewer_agent": "review.json", "validator": "findings.json", "run_summary": "run_summary.json",
                     "sources": "sources.json", "context_pack": "pack.json", "tokens": "tokens.json"}

    # ------------------------------------------------------------------ timings + recommendations (Log tab)
    def _timings(self, t0: float) -> dict:
        """Stages (from the milestone events of this run) and agent tasks (from ctx.timings) with their seconds."""
        ev = [e for e in self.events if e.get("t") and e["t"] >= t0 - 1]
        marks = [(e["t"], e.get("stage") or ("end" if e.get("title") == "run complete" else None), e.get("title", "")) for e in ev]
        marks = [m for m in marks if m[1]]
        stages = []
        for i, (t, key, title) in enumerate(marks):
            if key == "end":
                continue
            nxt = marks[i + 1][0] if i + 1 < len(marks) else time.time()
            stages.append({"stage": title, "seconds": round(nxt - t, 1)})
        rows = list((self.ctx.timings if self.ctx else []) or [])
        by_agent: Dict[str, dict] = {}
        for r in rows:
            a = by_agent.setdefault(r["agent"], {"agent": r["agent"], "tasks": 0, "seconds": 0.0, "steps": 0, "fix_rounds": 0, "cached": 0, "issues": 0, "grounding_seconds": 0.0})
            a["tasks"] += 1; a["seconds"] = round(a["seconds"] + r["seconds"], 1); a["steps"] += r["steps"]
            a["fix_rounds"] += r["fix_rounds"]; a["cached"] += 1 if r["cached"] else 0; a["issues"] += r.get("issues", 0)
            a["grounding_seconds"] = round(a["grounding_seconds"] + float(r.get("grounding_seconds", 0) or 0), 1)
        slow = sorted([r for r in rows if not r["cached"]], key=lambda r: -r["seconds"])[:8]
        return {"total_seconds": round(time.time() - t0, 1), "stages": stages, "agents": sorted(by_agent.values(), key=lambda a: -a["seconds"]),
                "slowest_tasks": [{"agent": r["agent"], "task": r["task"], "seconds": r["seconds"], "steps": r["steps"], "fix_rounds": r["fix_rounds"]} for r in slow]}

    def _recommendations(self, stats: dict) -> List[str]:
        """Short, concrete hints to make the next run faster and cheaper, derived from this run."""
        out = []
        rows = list((self.ctx.timings if self.ctx else []) or [])
        by = stats.get("by_agent") or {}
        pl = [r for r in rows if r["agent"] == "planner_agent"]
        if pl and sum(r["fix_rounds"] for r in pl) >= 1:
            n = sum(r["fix_rounds"] for r in pl)
            out.append(f"planner re-planned {n}x after grounding - name the target folder, the registration file and the companion scripts in the story "
                       "(or a standards note) so the first plan passes")
        readers = [r for r in rows if r["agent"] in ("story_agent", "knowledge_agent", "data_agent", "repo_agent")]
        if readers and not all(r["cached"] for r in readers):
            out.append("keep the same documents, tables and repository for the next story: the knowledge / data / repo results are then reused from cache (0 tokens)")
        coder = [r for r in rows if r["agent"] == "coder_agent"]
        if coder and max(r["steps"] for r in coder) >= 5:
            out.append("the coder took many tool steps on some files - give the planner's outline the exact sibling file to imitate and the columns to add")
        rv = by.get("reviewer_agent") or {}
        if (self.review or {}).get("skipped"):
            out.append("the review was skipped by the time budget - raise product.max_run_minutes or shorten the story to one outcome")
        unfixed = [f for f in (self.review or {}).get("findings", []) or [] if f.get("status") == "open" and f.get("severity") in ("critical", "high")]
        if unfixed:
            out.append(f"{len(unfixed)} critical / high finding(s) left open - fix them in the chat now; each costs one coder call, not a full re-run")
        big = [f for f in self.files.values() if f.get("action") == "modify" and len(self._existing(f["path"], f.get("repo", "")) or "") > 40000]
        if big:
            out.append(f"{len(big)} large file(s) modified by edits - use the 'Sub-folder only' option when adding the repository to keep the index small")
        tot = stats.get("total") or {}
        if tot.get("input_tokens", 0) > 150000:
            out.append("uncached input above 150k tokens - lower llm.max_tool_result_chars / coder_context_chars, or add fewer tables and documents to the chat")
        nq = len((self.plan or {}).get("questions") or [])
        if nq:
            out.append(f"{nq} open question(s) in the plan - answer them in the story text and re-run: fewer questions = fewer planner rounds and a higher score")
        if not out:
            out.append("nothing to tune: readers cached, one planning round, review completed")
        return out[:6]

    # ------------------------------------------------------------------ outputs
    def _write_outputs(self, t0: float, failed: str = "") -> None:
        stats = self.llm.token_stats() if hasattr(self.llm, "token_stats") else {"total": {}, "by_agent": {}}
        self.summary = {"user": self.user, "chat_id": self.chat_id, "story": {k: self.inputs.story.get(k) for k in ("id", "title")} if self.inputs.story else None,
                        "files": [{"path": p, "language": f["language"], "action": f["action"], "chars": len(f["content"]), "confidence": f.get("confidence")} for p, f in self.files.items()],
                        "quality_score": quality_score(self.findings) if self.files else 0, "review": {k: self.review.get(k) for k in ("verdict", "score", "summary")},
                        "findings": len(self.findings), "duration_seconds": round(time.time() - t0, 1), "tokens": stats["total"],
                        "confidence": self.confidence(),
                        "tokens_by_agent": stats["by_agent"], "tokens_by_model": stats.get("by_model") or {}, "pricing": stats.get("pricing"), "failed": failed, "finished": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
        self.summary["cost_usd"] = (stats.get("total") or {}).get("cost_usd")
        self.summary["timings"] = self._timings(t0)
        self.summary["recommendations"] = self._recommendations(stats)
        self._save_json("run_summary.json", self.summary)
        self._save_json("tokens.json", stats)
        if self.ctx:
            self._save_json("story_result.json", self.ctx.story)
            self._save_json("knowledge.json", self.ctx.knowledge)
            self._save_json("data.json", self.ctx.data)
            self._save_json("repo.json", self.ctx.repo)
        try:
            self._save_json("sources.json", self.sources())      # after the agent outputs: it reads them
        except Exception as e:  # noqa: BLE001
            log.warning("sources not saved: %s", e)
        try:
            txt = self.llm.token_stats_text() if hasattr(self.llm, "token_stats_text") else json.dumps(stats, indent=1)
            (self.folder / "tokens.txt").write_text(txt, encoding="utf-8")
            self.log("\n" + txt)
        except Exception:  # noqa: BLE001
            pass
        if self.files and (bool(self.cfg.generation.get("docs", False)) or getattr(self, "docs_wanted", False)):
            try:
                from .docgen import write_docs
                self.docs = write_docs(self)
                for d in self.docs:
                    self.event("result", f"documentation: {Path(d).name}", kind="docs", path=d)
            except Exception as e:  # noqa: BLE001
                self.event("error", "documentation failed", str(e)[:200])
        self.make_zip()

    def make_zip(self) -> Path:
        sid = _safe((self.inputs.story or {}).get("id", "run"))
        zp = self.folder / f"agiledev_{sid}.zip"
        with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
            for p, f in self.files.items():
                z.writestr(p, f["content"])
            for name in ("plan.json", "review.json", "findings.json", "run_summary.json", "tokens.txt", "log.txt", "pack.json"):
                fp = self.folder / name
                if fp.exists():
                    z.write(fp, f"_agiledev/{name}")
            z.writestr("_agiledev/README.txt", self.readme_text())
            for d in getattr(self, "docs", []) or []:
                if Path(d).exists():
                    z.write(d, f"_agiledev/{Path(d).name}")
        return zp

    # ------------------------------------------------------------------ savepoints (named snapshots of the generated code)
    def savepoints(self) -> List[dict]:
        return self._load_json("savepoints.json") or []

    def save_point(self, name: str = "", note: str = "") -> dict:
        """Snapshot every generated file + plan / review / findings / summary into savepoints/<name>.zip (restorable, downloadable)."""
        if not self.files:
            raise ValueError("nothing to save yet - run first")
        sps = self.savepoints()
        name = (name or "").strip() or f"savepoint-{len(sps) + 1}"
        name = re.sub(r"[^A-Za-z0-9._-]+", "-", name).strip("-")[:60]
        d = self.folder / "savepoints"
        d.mkdir(parents=True, exist_ok=True)
        zp = d / f"{name}.zip"
        with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
            for pth, f in self.files.items():
                z.writestr("files/" + pth, f["content"])
            z.writestr("files_meta.json", json.dumps({k: {x: v for x, v in f.items() if x != "content"} for k, f in self.files.items()}, default=str))
            for nm in ("plan.json", "review.json", "findings.json", "run_summary.json"):
                fp = self.folder / nm
                if fp.exists():
                    z.write(fp, nm)
        conf = (self.summary or {}).get("confidence") or {}
        rec = {"name": name, "created": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "files": sorted(self.files), "note": note,
               "confidence": conf.get("score"), "zip": zp.name}
        sps = [x for x in sps if x["name"] != name] + [rec]
        self._save_json("savepoints.json", sps)
        self.event("result", f"savepoint {name} saved", f"{len(self.files)} file(s)" + (f", confidence {conf.get('score')}" if conf.get("score") is not None else ""), kind="savepoint")
        return rec

    def restore_point(self, name: str) -> dict:
        """Replace the generated files (and plan / review / findings / summary) with the savepoint's; the current state is saved
        first as 'before-restore-<n>' so a revert is itself reversible."""
        sps = self.savepoints()
        rec = next((x for x in sps if x["name"] == name), None) or next((x for x in sps if x["name"].lower() == name.lower()), None)
        if not rec:
            raise ValueError(f"no savepoint named {name!r}; available: " + (", ".join(x["name"] for x in sps) or "none"))
        if self.files:
            self.save_point(f"before-restore-{sum(1 for x in sps if x['name'].startswith('before-restore')) + 1}", note=f"state before reverting to {rec['name']}")
        zp = self.folder / "savepoints" / rec["zip"]
        import shutil
        if (self.folder / "files").exists():
            shutil.rmtree(self.folder / "files")
        self.files = {}
        with zipfile.ZipFile(zp) as z:
            meta = json.loads(z.read("files_meta.json").decode("utf-8"))
            for n in z.namelist():
                if n.startswith("files/") and not n.endswith("/"):
                    pth = n[len("files/"):]
                    self.files[pth] = dict(meta.get(pth, {"path": pth, "language": "", "action": "create", "purpose": ""}), content=z.read(n).decode("utf-8"))
            for nm in ("plan.json", "review.json", "findings.json", "run_summary.json"):
                if nm in z.namelist():
                    (self.folder / nm).write_bytes(z.read(nm))
        for f in self.files.values():
            self._save_file(f)
        self.plan = self._load_json("plan.json") or {}
        self.review = self._load_json("review.json") or {}
        self.findings = self._load_json("findings.json") or []
        self.summary = self._load_json("run_summary.json") or {}
        if self.ctx:
            self.ctx.files = dict(self.files)
            self.ctx.plan = self.plan
        self.make_zip()
        self.event("result", f"reverted to savepoint {rec['name']}", f"{len(self.files)} file(s) restored", kind="savepoint")
        return rec

    def readme_text(self) -> str:
        s = self.inputs.story or {}
        lines = [f"Agile Dev Assist output for story {s.get('id', '')}: {s.get('title', '')}", f"user: {self.user}  chat: {self.chat_id}",
                 "", "Approach:", self.plan.get("approach", ""), "", "Files:"]
        for p, f in self.files.items():
            lines.append(f"  {f['action']:7s} {p}  [{f['language']}]  {f['purpose']}")
        if self.review:
            lines += ["", f"Review: {self.review.get('verdict')} score {self.review.get('score')} - {self.review.get('summary', '')}"]
        return "\n".join(lines)

    # ------------------------------------------------------------------ publish
    def publish(self, url: str, token: str, branch: str, base_branch: str, message: str = "", author: Optional[dict] = None,
                paths: Optional[List[str]] = None, mr_target: str = "") -> dict:
        if not self.files:
            raise ValueError("nothing to push")
        gc = GitClient(url, token, self.cfg.git.get("ssl_verify", True), self.cfg.git.get("default_provider", "gitlab"))
        who = gc.whoami()
        s = self.inputs.story or {}
        msg = (message or "").strip() or self.cfg.git.get("commit_message_template", "{story_id}: {title}").format(
            story_id=s.get("id", ""), title=s.get("title", "")[:80], user=who.get("name") or self.user)
        prefix = str(self.cfg.git.get("commit_prefix", "agile_dev_assist")).strip()
        if prefix and not msg.lower().startswith(prefix.lower()):
            msg = f"{prefix}: {msg}"              # every commit and MR title starts with the tool's name - also when the user typed their own
        files = {p: f["content"] for p, f in self.files.items() if not paths or p in paths}
        self.event("input", f"pushing {len(files)} file(s) to {gc.project} branch {branch}", f"as {who.get('username')} from {base_branch}", kind="publish")
        conf = (self.summary or {}).get("confidence") or {}
        desc = (f"agile_dev_assist - generated for {who.get('name') or self.user}\n\nStory {s.get('id', '')}: {s.get('title', '')}\n\n"
                f"Files:\n" + "\n".join(f"- {p}" for p in sorted(files)) +
                (f"\n\nConfidence {conf.get('score')} ({conf.get('grade')}) - review score {(self.review or {}).get('score')}, "
                 f"validator quality {(self.summary or {}).get('quality_score')}" if conf else ""))
        r = gc.publish(branch, base_branch, msg, files, author or {"name": who.get("name"), "email": who.get("email")},
                       mr_target=mr_target, mr_title=msg.splitlines()[0][:120], mr_description=desc)
        r["pushed_as"] = who.get("username")
        r["paths"] = sorted(files)
        hist = self._load_json("publish.json") or []
        hist = hist if isinstance(hist, list) else [hist]
        hist.append(r)
        self._save_json("publish.json", hist)
        self.event("result", f"pushed: {r['branch']}", r.get("branch_url", ""), kind="publish", url=r.get("branch_url", ""))
        if r.get("mr_url"):
            self.event("result", f"merge request {'created' if r.get('mr_created') else 'already open'}: !{r.get('mr_iid')} -> {mr_target}",
                       r["mr_url"], kind="publish", url=r["mr_url"])
        return r

    # ------------------------------------------------------------------ feature branches (real git: worktree per chat)
    def _gitws(self):
        from .gitworkspace import GitWorkspace
        return GitWorkspace(self.cfg, self.cfg.path(self.cfg.storage.get("git_mirrors_dir", "data/cache/git")))

    def _author(self) -> dict:
        name = self.user.split("@")[0].replace(".", " ").title() if "@" in self.user else self.user
        return {"name": name, "email": self.user if "@" in self.user else f"{self.user}@invalid"}

    def create_branch(self, repo_url: str, base: str, feature: str, target: str, token: str, system: str = "", progress=None) -> dict:
        """Checkout: the feature branch is created locally from origin/<base> as a worktree of the shared mirror (created on the
        remote at the first push). Several branches per chat (one per repository) are normal: an ODM + NLG story has two."""
        from .gitworkspace import slug_of
        from .gitclient import parse_project_url
        if not (repo_url and base and feature):
            raise ValueError("repository URL, base branch and feature branch are required")
        feature = re.sub(r"[^A-Za-z0-9._/-]+", "-", feature.strip()).strip("-/")
        ws = self._gitws()
        slug = slug_of(repo_url)
        info = parse_project_url(repo_url)
        dest = self.folder / "repos" / slug
        say = progress or (lambda m: self.event("log", m))
        r = ws.checkout(repo_url, token, base, feature, dest, say, chat=self.chat_id)
        if not system:
            system = next((p["system"] for p in self.inputs.packs if p.get("repo_name") and p["repo_name"] in info.get("project", "")), "")
            if not system:
                for sysn in ("ikg", "odm", "nlg"):
                    if sysn in info.get("project", "").lower() or sysn in feature.lower():
                        system = sysn; break
        rec = {"slug": slug, "system": system, "repo_url": repo_url, "project": info.get("project", ""), "base": base, "feature": feature, "target": target or base,
               "path": str(dest), "mirror": r["mirror"], "base_sha": r["base_sha"], "head": r["head"], "resumed": r["resumed"], "local": r.get("local", feature),
               "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "created_by": self.user, "commits": [], "pushed": None}
        self.inputs.add_branch(rec)
        self.event("input", f"feature branch {feature} checked out from {base} ({info.get('project', '')})",
                   f"{'resumed from the remote' if r['resumed'] else 'new, local until the first push'}; merge target {rec['target']}", kind="branch", branch=feature)
        # a live clone of the same repo is not needed any more: the worktree IS the live repository
        return self.branch_status(slug)

    def branch_status(self, slug: str) -> dict:
        b = next((x for x in self.inputs.branches if x["slug"] == slug), None)
        if not b:
            raise KeyError(f"no branch {slug}")
        out = {k: v for k, v in b.items() if k not in ("path", "mirror")}
        try:
            lg = self._gitws().log(Path(b["path"]), b["base"])
            out.update({"commits": lg["commits"], "changed": lg["changed"], "head": lg["head"]})
        except Exception as e:  # noqa: BLE001
            out["error"] = str(e)[:200]
        return out

    def branch_diff(self, slug: str, path: str = "") -> str:
        b = next((x for x in self.inputs.branches if x["slug"] == slug), None)
        if not b:
            raise KeyError(f"no branch {slug}")
        return self._gitws().diff(Path(b["path"]), b["base"], path)

    def remove_branch(self, slug: str) -> dict:
        b = self.inputs.remove_branch(slug)
        if b:
            try:
                self._gitws().remove(Path(b["path"]), Path(b["mirror"]), b["feature"], b.get("local", ""))
            except Exception as e:  # noqa: BLE001
                log.warning("branch cleanup: %s", e)
            self.event("input", f"feature branch {b['feature']} removed from this chat", "the remote branch (if pushed) is untouched", kind="branch")
        return {"removed": bool(b)}

    def commit_to_branches(self, label: str) -> List[dict]:
        """Every generated file goes into the worktree of its repository's feature branch as a commit by the chat's user."""
        if not self.inputs.branches or not self.files:
            return []
        ws = self._gitws()
        groups: Dict[str, Dict[str, str]] = {}
        for p, f in self.files.items():
            b = self.inputs.branch_for_repo(f.get("repo", ""))
            if b:
                groups.setdefault(b["slug"], {})[p] = f["content"]
        s = self.inputs.story or {}
        out = []
        for slug, files in groups.items():
            b = next(x for x in self.inputs.branches if x["slug"] == slug)
            msg = f"{s.get('id', '')}: {s.get('title', '')[:80]} ({label})".strip(": ")
            try:
                c = ws.commit(Path(b["path"]), files, msg, self._author())
            except Exception as e:  # noqa: BLE001
                self.event("error", f"commit on {b['feature']} failed", str(e)[:300], kind="branch")
                continue
            if c:
                b.setdefault("commits", []).append(c)
                b["head"] = c["sha"]
                self.inputs._save()
                self.event("result", f"committed {len(files)} file(s) on {b['feature']} ({c['sha']})", msg, kind="branch", branch=b["feature"])
                out.append({"slug": slug, **c})
            else:
                self.event("log", f"{b['feature']}: nothing new to commit")
        return out

    def push_branch(self, slug: str, token: str, message: str = "", create_mr: bool = True, mr_target: str = "", progress=None,
                    files: Optional[List[str]] = None) -> dict:
        """Rebase on the base branch, re-author every commit to the token owner, push, open the merge request - all as that user.
        `files`: the paths the user ticked in the push form (None = all). Unticked files are left out of this push (they
        stay in the chat). create_mr=False pushes to the branch only."""
        b = next((x for x in self.inputs.branches if x["slug"] == slug), None)
        if not b:
            raise KeyError(f"no branch {slug}")
        if not token:
            raise ValueError("your personal git token is required: the branch, commits and merge request are created under your name")
        ws = self._gitws()
        say = progress or (lambda m: self.event("log", m))
        gc = GitClient(b["repo_url"], token, self.cfg.git.get("ssl_verify", True), self.cfg.git.get("default_provider", "gitlab"))
        who = gc.whoami()
        if not who.get("username"):
            raise ValueError("the token does not identify a user (whoami failed) - a personal token is required")
        author = {"name": who.get("name") or who["username"], "email": who.get("email") or f"{who['username']}@users.noreply"}
        wt = Path(b["path"])
        if self.files:                                            # whatever is in the chat but not yet committed goes in first
            self.commit_to_branches("before push")
        target = (mr_target or b.get("target") or b["base"]).strip()
        feature, base = b["feature"], b["base"]
        # ---- does the branch already exist on GitLab? (a colleague's, or yours from another chat / an earlier push)
        remote = ws.remote_sha(b["repo_url"], token, feature)
        others, integrated = [], 0
        if remote:
            ws.fetch(b["repo_url"], token, [base, feature], say)
            ig = ws.integrate(wt, b["repo_url"], token, feature, say)       # our new commits go ON TOP of what is there
            if not ig["ok"]:
                self.event("error", f"{feature} on GitLab changed the same lines", ", ".join(ig["conflicts"]), kind="branch")
                return {"pushed": False, "conflicts": ig["conflicts"], "base": base, "branch": feature, "shared": True,
                        "hint": "someone pushed to this branch and changed the same lines: open a new chat on the branch (it resumes from GitLab) "
                                "and re-apply your change there, or resolve by hand - nothing was pushed, nothing of theirs was touched"}
            integrated = ig.get("integrated", 0)
            others = [a for a in ws.authors(wt, f"refs/remotes/origin/{base}..refs/remotes/origin/{feature}") if a != str(author.get("email", "")).lower()]
        local_new = ws.count(wt, f"refs/remotes/origin/{feature}..HEAD") if remote else ws.count(wt, f"refs/remotes/origin/{base}..HEAD")
        if local_new == 0:
            return {"pushed": False, "reason": "no new commits on the branch - nothing to push", "branch": feature}
        excluded: List[str] = []
        if files is not None and not others:
            # own branch: bring it up to date FIRST so "what this push delivers" is measured against the current base
            rb = ws.rebase(wt, b["repo_url"], token, base, say)
            if not rb["ok"]:
                self.event("error", f"rebase of {feature} on {base} conflicts", ", ".join(rb["conflicts"]), kind="branch")
                return {"pushed": False, "conflicts": rb["conflicts"], "base": base, "branch": feature,
                        "hint": "the base branch changed in these files since the branch was created: ask in the chat to re-apply the change on the current version, or resolve by hand"}
        if files is not None:
            baseline = f"refs/remotes/origin/{feature}" if remote and others else f"refs/remotes/origin/{base}"
            chosen = {str(p).strip().lstrip("/") for p in files if str(p).strip()}
            excluded = [p for p in ws.changed_paths(wt, baseline) if p not in chosen]
            if excluded:
                s = self.inputs.story or {}
                msg = message.strip() or f"{s.get('id', '')}: {s.get('title', '')[:80]}".strip(": ") or "agile_dev_assist change"
                ex = ws.exclude(wt, baseline, excluded, msg, self._author())
                if not ex["ok"]:
                    return {"pushed": False, "reason": "none of the selected files has a change to push", "branch": feature, "excluded": excluded}
                message = ""                                       # already used for the squashed commit
                say(f"{feature}: left out of this push (kept in the chat): {', '.join(excluded)}")
        if message.strip():                                       # a user message becomes the last commit's message (our own commit only)
            ws._run("commit", "--amend", "-q", "-m", message.strip(), cwd=wt, author=self._author())
        if others:
            # SHARED branch: other people's commits are on it -> never rebase or rewrite them; only our new commits are
            # re-authored, and the push is a fast-forward of the remote commit we just fetched
            mode = "shared"
            n = ws.reauthor(wt, base, author, upstream=f"refs/remotes/origin/{feature}")
        else:
            # our own branch (new, or only our commits on it): bring it up to date with the base and re-author it all
            mode = "own"
            rb = ws.rebase(wt, b["repo_url"], token, base, say) if files is None else {"ok": True}
            if not rb["ok"]:
                self.event("error", f"rebase of {feature} on {base} conflicts", ", ".join(rb["conflicts"]), kind="branch")
                return {"pushed": False, "conflicts": rb["conflicts"], "base": base, "branch": feature,
                        "hint": "the base branch changed in these files since the branch was created: ask in the chat to re-apply the change on the current version, or resolve by hand"}
            n = ws.reauthor(wt, base, author)
        pr = ws.push(wt, b["repo_url"], token, feature, expect=remote)    # lease: refused if anyone pushed after our fetch
        say(f"pushed {n} commit(s) to {feature} ({mode} branch" + (f", on top of {integrated} commit(s) already on GitLab" if integrated else "")
            + (f"; other authors on it: {', '.join(others)}" if others else "") + ")")
        res = {"pushed": True, "branch": feature, "base": base, "commits": n, "head": pr["head"], "pushed_as": who["username"], "author": author,
               "mode": mode, "integrated": integrated, "other_authors": others, "excluded": excluded, "mr_requested": bool(create_mr),
               "project": gc.project, "branch_url": f"{gc.info['web']}/{gc.project}/-/tree/{b['feature']}" if gc.provider != "github" else f"{gc.info['web']}/{gc.project}/tree/{b['feature']}"}
        preview = ws.conflict_preview(wt, b["repo_url"], token, target, say)
        res["target_conflicts"] = preview
        if create_mr:
            s = self.inputs.story or {}
            prefix = str(self.cfg.git.get("commit_prefix", "agile_dev_assist")).strip()
            title = f"{prefix}: {s.get('id', '')}: {s.get('title', '')[:100]}".strip(": ")
            conf = (self.summary or {}).get("confidence") or {}
            desc = (f"Generated with Agile Dev Assist by {author['name']} ({who['username']}).\n\nStory {s.get('id', '')}: {s.get('title', '')}\n\n"
                    f"Branch {b['feature']} from {b['base']} -> {target}; {n} commit(s).\n\nFiles:\n" + "\n".join(f"- {p}" for p in sorted({p for p in self.files})) +
                    (f"\n\nConfidence {conf.get('score')} ({conf.get('grade')}), review score {(self.review or {}).get('score')}, validator quality {(self.summary or {}).get('quality_score')}" if conf else "") +
                    (f"\n\nNOTE: this branch conflicts with {target} in: {', '.join(preview.get('files', []))} - resolve before merging" if preview.get("conflicts") else ""))
            mr = gc.create_merge_request(b["feature"], target, title, desc)
            res.update({"mr_target": target, "mr_iid": mr.get("iid"), "mr_url": mr.get("web_url"), "mr_created": mr.get("created")})
        b["pushed"] = {k: res.get(k) for k in ("head", "pushed_as", "mr_iid", "mr_url", "mr_target", "branch_url")} | {"at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
        b["target"] = target
        self.inputs._save()
        hist = self._load_json("publish.json") or []
        hist = hist if isinstance(hist, list) else [hist]
        hist.append({**res, "paths": sorted(self.files), "base_branch": b["base"], "files": len(self.files)})
        self._save_json("publish.json", hist)
        self.event("result", f"pushed {b['feature']} ({n} commit(s)) as {who['username']}", res["branch_url"], kind="publish", url=res["branch_url"])
        if res.get("mr_url"):
            self.event("result", f"merge request {'created' if res.get('mr_created') else 'already open'}: !{res.get('mr_iid')} {b['feature']} -> {target}", res["mr_url"], kind="publish", url=res["mr_url"])
        return res

    def suggest_branch(self, repo_url: str = "") -> str:
        s = self.inputs.story or {}
        feature = (self.ctx.story.get("feature_name") if self.ctx and self.ctx.story else "") or \
            (self._load_json("story_result.json") or {}).get("feature_name") or s.get("title", "change")
        repo = ""
        if repo_url:
            from .gitclient import parse_project_url
            repo = parse_project_url(repo_url).get("project", "").rsplit("/", 1)[-1]
        elif self.inputs.repos:
            repo = self.inputs.repos[0]["name"]
        gd = self.inputs.git_defaults or {}
        system = gd.get("system") or (self.inputs.packs[0]["system"] if self.inputs.packs else "")
        template = gd.get("branch_template") or self.cfg.git.get("branch_template", "{story_id}-{system}-{feature}")
        return GitClient.branch_name(template, s.get("id", "story"), repo or "repo", feature, int(self.cfg.git.get("branch_name_max_length", 80)), system=system)

    def git_conventions(self, repo_url: str = "") -> dict:
        """Branch / base / merge-request target for the push form: template (per system) > config > the repository's branch."""
        gd = self.inputs.git_defaults or {}
        repos = self.inputs.repos
        live = [r for r in repos if not r.get("from_pack")]
        rec = (live or repos)[:1]
        base = gd.get("base_branch") or self.cfg.git.get("base_branch") or (rec[0]["branch"] if rec else "")
        return {"branch": self.suggest_branch(repo_url), "base_branch": base, "mr_target": gd.get("mr_target") or self.cfg.git.get("mr_target") or base,
                "repo_url": repo_url or (rec[0]["url"] if rec and not str(rec[0]["url"]).startswith("pack://") else ""),
                "system": gd.get("system") or (self.inputs.packs[0]["system"] if self.inputs.packs else ""), "source": "template" if gd else "config"}

    # ------------------------------------------------------------------ edits from the UI
    def update_file(self, path: str, content: str) -> dict:
        rec = self.files.get(path) or {"path": path, "language": "", "action": "create", "purpose": "edited in the UI",
                                       "explanation": "", "assumptions": [], "confidence": 0, "repo": ""}
        rec["content"] = content
        from .validators import language_of
        rec["language"] = rec["language"] or language_of(path)
        self.files[path] = rec
        if self.ctx:
            self.ctx.files[path] = rec
        self._save_file(rec)
        fnd = validate_file(path, content, rec["language"], self.ctx.rules if self.ctx else [])
        self.findings = [f for f in self.findings if f["path"] != path] + fnd
        self._save_json("findings.json", self.findings)
        self.event("file", f"edited in the UI: {path}", f"{len(fnd)} finding(s)", kind="file", path=path, language=rec["language"])
        self.make_zip()
        return {"path": path, "findings": fnd}

    # ------------------------------------------------------------------ persistence
    def _save_file(self, rec: dict) -> None:
        p = self.folder / "files" / rec["path"]
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(rec["content"], encoding="utf-8")
        self._save_json("files_meta.json", {k: {x: v for x, v in f.items() if x != "content"} for k, f in self.files.items()})

    def _save_json(self, name: str, data) -> None:
        try:
            (self.folder / name).write_text(json.dumps(data, ensure_ascii=False, indent=1, default=str), encoding="utf-8")
        except Exception as e:  # noqa: BLE001
            log.warning("%s not saved: %s", name, e)

    def _load_json(self, name: str):
        p = self.folder / name
        if p.exists():
            try:
                return json.loads(p.read_text(encoding="utf-8"))
            except Exception:  # noqa: BLE001
                return None
        return None

    def _load_state(self) -> None:
        self.plan = self._load_json("plan.json") or {}
        self.review = self._load_json("review.json") or {}
        self.findings = self._load_json("findings.json") or []
        self.summary = self._load_json("run_summary.json") or {}
        self.history = self._load_json("history.json") or []
        meta = self._load_json("files_meta.json") or {}
        for p, m in meta.items():
            fp = self.folder / "files" / p
            if fp.exists():
                self.files[p] = dict(m, content=fp.read_text(encoding="utf-8"))
        ev = self.folder / "events.jsonl"
        if ev.exists():
            try:
                self.events = [json.loads(l) for l in ev.read_text(encoding="utf-8").splitlines() if l.strip()]
            except Exception:  # noqa: BLE001
                self.events = []

    def add_history(self, role: str, text: str, **extra) -> dict:
        m = {"role": role, "text": text, "ts": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), **extra}
        self.history.append(m)
        self._save_json("history.json", self.history)
        return m

    def _pushed(self) -> dict:
        """path -> [{project, branch, url}] of every push made from this chat (several pushes to several repos are normal)."""
        hist = self._load_json("publish.json") or []
        hist = hist if isinstance(hist, list) else [hist]
        out: Dict[str, list] = {}
        for h in hist:
            for pth in h.get("paths") or []:
                out.setdefault(pth, []).append({"project": h.get("project", ""), "branch": h.get("branch", ""), "url": h.get("branch_url", "")})
        return out

    def state(self) -> dict:
        return {"chat_id": self.chat_id, "user": self.user, "inputs": self.inputs.overview(), "plan": self.plan,
                "files": [{k: v for k, v in f.items() if k != "content"} for f in self.files.values()],
                "review": self.review, "findings": self.findings, "summary": self.summary, "running": self.running,
                "docs": [d for d in (getattr(self, "docs", []) or []) if Path(d).exists()],
                "pipeline": list(self.inputs.pipeline or DEFAULT_PIPELINE), "default_pipeline": DEFAULT_PIPELINE,
                "pushed": self._pushed(), "savepoints": self.savepoints(), "sources": self._load_json("sources.json") or {},
                "branches": [{k: v for k, v in b.items() if k not in ("path", "mirror")} for b in self.inputs.branches],
                "agent_outputs": [k for k, v in self.AGENT_OUTPUTS.items() if (self.folder / v).exists()],
                "history": self.history, "events": self.events[-400:]}


def _safe(s: str) -> str:
    import re
    return re.sub(r"[^A-Za-z0-9._@-]+", "_", str(s))[:120] or "x"
