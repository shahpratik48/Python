"""The engine: one ChatSession = one chat of one user. Inputs -> context pack -> agents -> files -> validation ->
review -> regeneration -> outputs (files, zip, plan, log, token stats) -> optional git push.

Everything the session produces lives in its folder:
    inputs.json  pack.json  plan.json  files/<path>  review.json  findings.json  run_summary.json
    log.txt  tokens.txt  tokens.json  events.jsonl  history.json  agiledev_<story>.zip
"""
from __future__ import annotations

import concurrent.futures as cf
import io
import json
import re
import logging
import threading
import time
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Callable, Dict, List, Optional

from .agents.context import AgentContext
from .agents.specialists import (StoryAgent, KnowledgeAgent, DataAgent, RepoAgent, PlannerAgent, CoderAgent,
                                 ReviewerAgent, ChangeAgent)
from .contextpack import build_pack, save_pack
from .gitclient import GitClient
from .inputs import SessionInputs, normalise_story
from .readers import read_document
from .validators import validate_file, score as quality_score

log = logging.getLogger(__name__)

DEFAULT_PIPELINE = ["story_agent", "knowledge_agent", "data_agent", "repo_agent", "planner_agent", "coder_agent", "reviewer_agent"]
STAGES = [("story", "Understanding the story"), ("knowledge", "Reading skills, glossary and standards"),
          ("data", "Analysing the tables"), ("repo", "Studying the repository"), ("plan", "Planning the files"),
          ("generate", "Generating the code"), ("validate", "Validating"), ("review", "Reviewing"),
          ("fix", "Regenerating after review"), ("outputs", "Writing the outputs")]


class ChatSession:
    def __init__(self, cfg, llm, folder: Path, user: str, chat_id: str, on_event: Optional[Callable[[dict], None]] = None):
        self.cfg, self.llm = cfg, llm
        self.folder = Path(folder)
        self.folder.mkdir(parents=True, exist_ok=True)
        self.user, self.chat_id = user, chat_id
        self.inputs = SessionInputs.load(self.folder)
        self.on_event = on_event
        self.events: List[dict] = []
        self.history: List[dict] = []
        self.files: Dict[str, dict] = {}
        self.plan: dict = {}
        self.review: dict = {}
        self.findings: List[dict] = []
        self.summary: dict = {}
        self.ctx: Optional[AgentContext] = None
        self.running = False
        self._lock = threading.Lock()
        self._log_fh = None
        self._load_state()

    # ------------------------------------------------------------------ events + log
    def event(self, type_: str, title: str, detail: str = "", pct: Optional[int] = None, **extra) -> dict:
        e = {"ts": datetime.now().strftime("%H:%M:%S"), "t": time.time(), "type": type_, "title": title, "detail": detail, "pct": pct, **extra}
        self.events.append(e)
        try:
            with open(self.folder / "events.jsonl", "a", encoding="utf-8") as fh:
                fh.write(json.dumps(e, ensure_ascii=False, default=str) + "\n")
        except Exception:  # noqa: BLE001
            pass
        self.log(f"[{type_}] {title}" + (f" - {detail}" if detail else ""))
        if self.on_event:
            try:
                self.on_event(e)
            except Exception:  # noqa: BLE001
                pass
        return e

    def log(self, line: str) -> None:
        try:
            with open(self.folder / "log.txt", "a", encoding="utf-8") as fh:
                fh.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} {line}\n")
        except Exception:  # noqa: BLE001
            pass

    def _trace_sink(self, row: dict) -> None:
        self.log(f"[trace] {row['agent']} {row['task']} step {row['step']} {row['kind']} {row['name']} {row['detail']}" + ("" if row["ok"] else " (issue)"))
        if row["kind"] in ("done", "cache"):
            self.event("agent", f"{row['agent']}: {row['task']} {'(cache)' if row['kind'] == 'cache' else 'done'}", row["detail"], agent=row["agent"])

    # ------------------------------------------------------------------ inputs (called by the UI)
    def set_story_text(self, text: str, title: str = "", story_id: str = "", source: Optional[dict] = None) -> dict:
        s = self.inputs.set_story(normalise_story(text, title, story_id, source))
        self.event("input", f"story: {s['id']} {s['title']}", f"{s['chars']} chars", kind="story")
        return s

    def set_story_from_git(self, url: str, token: str, issue: str = "", path: str = "", ref: str = "") -> dict:
        gc = GitClient(url, token, self.cfg.git.get("ssl_verify", True), self.cfg.git.get("default_provider", "gitlab"))
        issue = issue or gc.info.get("issue")
        if issue:
            it = gc.issue(issue)
            text = f"# {it['title']}\n\n{it['description']}\n\n" + "\n\n".join(f"**comment by {n['author']}**\n{n['body']}" for n in it["notes"])
            src = {"type": "git_issue", "url": it.get("web_url") or url, "project": gc.project, "issue": it["id"]}
            return self.set_story_text(text, it["title"], it["id"], src)
        if path:
            ref = ref or gc.info.get("branch") or gc.project_info().get("default_branch") or "main"
            content = gc.file(path, ref)
            doc = read_document(Path(path).name, content.encode("utf-8"), "story")
            src = {"type": "git_file", "url": url, "project": gc.project, "path": path, "ref": ref}
            return self.set_story_text(doc["text"], "", "", src)
        raise ValueError("give an issue number or a file path in the repository")

    def set_story_from_file(self, name: str, data: bytes) -> dict:
        doc = read_document(name, data, "story", int(self.cfg.inputs.get("max_doc_chars", 120000)))
        return self.set_story_text(doc["text"], "", "", {"type": "upload", "name": name})

    def add_documents(self, kind: str, files: List[tuple]) -> List[dict]:
        out = []
        for name, data in files:
            out.append(self.inputs.add_document(kind, name, data, int(self.cfg.inputs.get("max_doc_chars", 120000))))
            self.event("input", f"{kind}: {name}", f"{out[-1]['chars']} chars", kind=kind)
        return out

    def add_local_repo(self, path: str, name: str = "", branch: str = "local") -> dict:
        """A repository already on this machine (a checkout or an unzipped copy) - for local testing and offline work."""
        p = Path(path).expanduser()
        if not p.is_dir():
            raise ValueError(f"folder not found: {p}")
        name = name or p.name
        rec = self.inputs.add_repo(name, f"file://{p}", branch, p, self.cfg.inputs.repo, {"provider": "local", "project": str(p)})
        self.event("input", f"local repository {name}: {rec['files']} files indexed", json.dumps(rec["languages"]), kind="repo")
        return rec

    def add_repo(self, url: str, token: str, branch: str = "", name: str = "", subpath: str = "", refresh: bool = False,
                 progress=None) -> dict:
        rc = self.cfg.inputs.repo
        say = progress or (lambda msg: None)
        if url.startswith("file://") or (url and not url.startswith("http") and Path(url).expanduser().is_dir()):
            say("indexing the local folder ...")
            return self.add_local_repo(url.replace("file://", ""), name, branch or "local")
        say("contacting the git server ...")
        gc = GitClient(url, token, self.cfg.git.get("ssl_verify", True), self.cfg.git.get("default_provider", "gitlab"))
        info = gc.project_info()
        branch = branch or gc.info.get("branch") or info.get("default_branch") or "main"
        name = name or gc.project.rsplit("/", 1)[-1]
        cache_root = self.cfg.path(self.cfg.storage.get("repo_cache_dir", "data/cache/repos")) / _safe(self.user) / _safe(f"{gc.project}@{branch}")
        self.event("input", f"repository {name}@{branch}: downloading", url, kind="repo")
        d = gc.download(cache_root, branch, rc.get("code_extensions", ["py", "sql"]), int(rc.get("max_file_kb", 400)),
                        int(rc.get("max_files", 6000)), float(rc.get("cache_hours", 24)), refresh, subpath, progress=say,
                        use_git_cli=bool(rc.get("use_git_cli", True)))
        say("indexing files (symbols, search index) ...")
        rec = self.inputs.add_repo(name, url, branch, cache_root, rc, {"provider": gc.provider, "project": gc.project, "web_url": info.get("web_url", "")})
        self.event("input", f"repository {name}@{branch}: {rec['files']} files indexed" + (" (cached)" if d.get("cached") else ""), json.dumps(rec["languages"]), kind="repo")
        return rec

    def apply_inputs(self, src_folder: Path, data: dict) -> dict:
        """Load the inputs of a saved template into this chat: story, documents (files copied), tables and queries (with
        their stored descriptions - no Greenplum round trip), repositories (the cached clone is reused - no download),
        pipeline. Instant when the caches are still there; a repository whose cache is gone is reported for re-adding."""
        import shutil
        src_folder = Path(src_folder)
        loaded = {"story": None, "docs": {}, "tables": 0, "queries": 0, "repos": [], "missing_repos": []}
        if data.get("story"):
            self.inputs.story = data["story"]
            loaded["story"] = data["story"].get("title")
        for kind, docs in (data.get("docs") or {}).items():
            if kind not in self.inputs.docs:
                continue
            for d in docs:
                srcf = src_folder / "inputs" / kind / d["name"]
                if srcf.exists():
                    (self.folder / "inputs" / kind).mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(srcf, self.folder / "inputs" / kind / d["name"])
                self.inputs.docs[kind] = [x for x in self.inputs.docs[kind] if x["name"] != d["name"]] + [d]
                loaded["docs"][kind] = loaded["docs"].get(kind, 0) + 1
        for t in data.get("tables") or []:
            self.inputs.tables = [x for x in self.inputs.tables if (x["schema"], x["table"]) != (t["schema"], t["table"])] + [t]
            loaded["tables"] += 1
        for q in data.get("queries") or []:
            self.inputs.queries = [x for x in self.inputs.queries if x.get("name") != q.get("name")] + [q]
            loaded["queries"] += 1
        for r in data.get("repos") or []:
            if Path(r.get("path", "")).exists():
                self.inputs.repos = [x for x in self.inputs.repos if x["name"] != r["name"]] + [r]
                loaded["repos"].append(f"{r['name']}@{r.get('branch', '')}")
            else:
                loaded["missing_repos"].append(r.get("url") or r["name"])
        if data.get("pipeline"):
            self.inputs.pipeline = list(data["pipeline"])
        self.inputs._save()
        self.event("input", "template loaded", json.dumps(loaded), kind="template")
        return loaded

    def add_tables(self, gp, schema: str, tables: List[str], progress=None, refresh: bool = False) -> List[dict]:
        out = []
        n = int(self.cfg.inputs.greenplum.get("sample_rows", 5))
        todo = tables[: int(self.cfg.inputs.greenplum.get("max_tables", 50))]
        pairs = []
        for t in todo:
            sch, name = (t.split(".", 1) if "." in t else (schema, t))
            pairs.append((sch.strip(), name.strip()))
        t0 = time.time()
        # per-user on-disk cache of table descriptions (catalog + sample): a table already described today is not read again
        gcfg = self.cfg.inputs.greenplum
        hours = float(gcfg.get("cache_hours", 24) or 0)
        cdir = self.cfg.path(self.cfg.storage.get("data_dir", "data")) / "cache" / "gp" / _safe(self.user) / _safe(f"{gp.conn_info.get('host', 'local')}_{gp.conn_info.get('database', '')}")
        cdir.mkdir(parents=True, exist_ok=True)
        described, fresh_pairs = [], []
        for sch, name in pairs:
            f = cdir / f"{_safe(sch)}.{_safe(name)}.json"
            if hours and not refresh and f.exists() and (time.time() - f.stat().st_mtime) / 3600 <= hours:
                try:
                    described.append(json.loads(f.read_text(encoding="utf-8")))
                    continue
                except Exception:  # noqa: BLE001
                    pass
            fresh_pairs.append((sch, name))
        if described and progress:
            progress(f"{len(described)} table(s) taken from today's cache ...")
        if fresh_pairs:
            for d in gp.describe_many(fresh_pairs, n, progress=progress, sample_timeout_s=int(gcfg.get("sample_timeout_seconds", 15))):
                described.append(d)
                try:
                    (cdir / f"{_safe(d['schema'])}.{_safe(d['table'])}.json").write_text(json.dumps(d, ensure_ascii=False, default=str), encoding="utf-8")
                except Exception:  # noqa: BLE001
                    pass
        for d in described:
            out.append(self.inputs.add_table(d))
            self.event("input", f"table {d['schema']}.{d['table']}: {out[-1]['columns']} columns", kind="table")
        self.log(f"{len(described)} table(s) described in {time.time() - t0:.1f}s")
        return out

    def add_query(self, gp, sql: str, name: str = "") -> dict:
        q = gp.query(sql, 200)
        q["name"] = name
        r = self.inputs.add_query(q)
        self.event("input", f"query {r['name']}: {r['row_count']} rows", kind="query")
        return r

    # ------------------------------------------------------------------ the run
    def run(self, instructions: str = "", pipeline: Optional[List[str]] = None) -> dict:
        """Runs the agent pipeline of this chat (inputs.pipeline, editable in the UI) in order.
        Stages per agent: story | knowledge, data, repo (parallel) | planner | coder (generate + validate) | reviewer (+ fix)."""
        if self.inputs.story is None:
            raise ValueError("add a story first (drag the Story icon into the chat)")
        with self._lock:
            if self.running:
                raise RuntimeError("a run is already in progress for this chat")
            self.running = True
        t0 = time.time()
        budget = float(self.cfg.product.get("max_run_minutes", 5)) * 60
        pipe = [a for a in (pipeline or self.inputs.pipeline or DEFAULT_PIPELINE) if a in DEFAULT_PIPELINE]
        if "coder_agent" in pipe and "planner_agent" not in pipe:
            pipe.insert(pipe.index("coder_agent"), "planner_agent")          # the coder needs a plan
        try:
            if instructions:
                self.inputs.add_instruction(instructions)
            self.event("milestone", "run started", f"budget {budget / 60:.0f} min - pipeline: " + " > ".join(a.replace("_agent", "") for a in pipe), pct=0, pipeline=pipe)
            pack = build_pack(self.inputs, self.cfg)
            save_pack(pack, self.folder)
            self.event("log", "context pack built", json.dumps(pack["chars"]))
            ctx = AgentContext(self.cfg, self.llm, self.inputs, pack, self._trace_sink, deadline=t0 + budget)
            self.ctx = ctx
            n_steps = max(1, len(pipe))
            pct = lambda i: int(5 + 85 * i / n_steps)  # noqa: E731
            step = 0
            # ---- story
            if "story_agent" in pipe:
                self._stage("story", pct(step)); step += 1
                StoryAgent(ctx).execute()
                self.event("result", "requirements", json.dumps({k: ctx.story.get(k) for k in ("summary", "feature_name", "target_languages")}), kind="story")
            else:
                st = self.inputs.story
                ctx.story = {"summary": st.get("text", "")[:2000], "goal": st.get("title", ""), "feature_name": st.get("title", "")[:60],
                             "functional_requirements": [], "business_rules": [], "acceptance_criteria": st.get("acceptance_criteria", []), "target_languages": []}
                self.event("log", "story agent skipped - the story text is used as is")
            # ---- knowledge, data, repo: independent -> parallel
            group = [(a, k) for a, k in (("knowledge_agent", "knowledge"), ("data_agent", "data"), ("repo_agent", "repo")) if a in pipe]
            if group:
                for _, k in group:
                    self._stage(k, pct(step), running=True)
                agents = {"knowledge_agent": KnowledgeAgent, "data_agent": DataAgent, "repo_agent": RepoAgent}
                with cf.ThreadPoolExecutor(len(group)) as ex:
                    futs = {ex.submit(agents[a](ctx).execute): k for a, k in group}
                    for f in cf.as_completed(futs):
                        try:
                            f.result()
                            self.event("milestone", f"{futs[f]} done", stage_done=futs[f])
                        except Exception as e:  # noqa: BLE001
                            self.event("error", f"{futs[f]} agent failed (continuing)", str(e)[:300], stage_done=futs[f])
                step += len(group)
                if ctx.knowledge.get("rules"):
                    self.event("log", f"{len(ctx.knowledge['rules'])} checkable rule(s) extracted from the standards")
            # ---- plan
            if "planner_agent" in pipe:
                self._stage("plan", pct(step)); step += 1
                PlannerAgent(ctx).execute()
                self._ensure_registrations(ctx)
                ctx.pack = build_pack(self.inputs, self.cfg, query_hint=ctx.story.get("summary", ""), plan=ctx.plan)
                save_pack(ctx.pack, self.folder)
                self.plan = ctx.plan
                self._save_json("plan.json", self.plan)
                self.event("result", f"plan: {len(self.plan.get('files', []))} file(s)", self.plan.get("approach", ""), kind="plan",
                           files=[{"path": f["path"], "action": f["action"], "language": f["language"]} for f in self.plan.get("files", [])], stage_done="plan")
            # ---- code (generation + validation may use the budget only up to the review reserve: the review always runs)
            reserve = min(0.3 * budget, float(self.cfg.product.get("review_reserve_minutes", 4)) * 60) if "reviewer_agent" in pipe else 0
            if "coder_agent" in pipe:
                ctx.deadline = t0 + budget - reserve
                self._stage("generate", pct(step)); step += 1
                self._generate(ctx)
                self.event("milestone", "generation done", stage_done="generate")
                self._stage("validate", pct(step))
                self._validate_and_fix(ctx)
                self.event("milestone", "validation done", stage_done="validate")
                ctx.deadline = t0 + budget
            # ---- review (+ fix)
            if "reviewer_agent" in pipe and self.files:
                if not ctx.out_of_time() or reserve:
                    self._stage("review", pct(step)); step += 1
                    rev = ReviewerAgent(ctx).execute(self.findings)
                    self.review = rev
                    self._save_json("review.json", rev)
                    self.event("result", f"review: {rev.get('verdict')} score {rev.get('score')}", rev.get("summary", ""), kind="review",
                               findings=len(rev.get("findings", [])), stage_done="review")
                    sev = set(self.cfg.generation.get("review_fix_severities", ["critical", "high"]))
                    to_fix = [f for f in rev.get("findings", []) if f.get("severity") in sev and f.get("path") in self.files]
                    for f in rev.get("findings", []) or []:          # status of every review finding, shown in the UI
                        f["status"] = "open" if f in to_fix else ("suggestion" if f.get("severity") in ("medium", "low", "info") else "open")
                    if to_fix and not ctx.out_of_time():
                        self._stage("fix", pct(step))
                        self._fix(ctx, to_fix, "review")
                        self._validate_and_fix(ctx, rounds=1)
                        for f in to_fix:
                            f["status"] = "fixed"
                            f["fixed_by"] = "coder fix pass after the review; validator re-run on the regenerated file"
                        self.event("milestone", "fixes applied", f"{len(to_fix)} review finding(s) sent to the coder and regenerated", stage_done="fix")
                    elif to_fix:
                        for f in to_fix:
                            f["status"] = "open"
                            f["fixed_by"] = "not fixed: time budget used up - fix by hand or ask in the chat"
                        self.event("log", f"{len(to_fix)} critical / high review finding(s) NOT fixed - time budget used up", stage_skipped="fix")
                    else:
                        self.event("log", "no critical / high review finding - nothing to regenerate", stage_skipped="fix")
                    self.review = rev
                    self._save_json("review.json", rev)
                else:
                    self.review = {"skipped": f"time budget ({budget / 60:.0f} min) used up before the review - raise product.max_run_minutes in the config",
                                   "findings": [], "verdict": "skipped", "score": None}
                    self._save_json("review.json", self.review)
                    self.event("log", "time budget used up - review skipped", stage_skipped="review")
            self._stage("outputs", 95)
            self._write_outputs(t0)
            if self.files:
                try:
                    self.save_point(f"run-{sum(1 for x in self.savepoints() if x['name'].startswith('run-')) + 1}", note="automatic savepoint after the run")
                except Exception as e:  # noqa: BLE001
                    log.warning("auto savepoint failed: %s", e)
            self.event("milestone", "run complete", f"{len(self.files)} file(s), confidence {self.summary.get('confidence', {}).get('score')} "
                       f"({self.summary.get('confidence', {}).get('grade')}), quality {self.summary.get('quality_score')}, "
                       f"{self.summary.get('duration_seconds')}s, {self.summary.get('tokens', {}).get('total_tokens', 0)} tokens, ${self.summary.get('cost_usd') or 0:.2f}", pct=100, kind="done", stage_done="outputs")
            return self.summary
        except Exception as e:
            log.exception("run failed")
            self.event("error", "run failed", f"{type(e).__name__}: {e}", kind="failed")
            self._write_outputs(t0, failed=str(e))
            raise
        finally:
            self.running = False

    def _stage(self, key: str, pct: int, running: bool = False) -> None:
        title = dict(STAGES).get(key, key)
        self.event("milestone", title, pct=pct, stage=key, parallel=running)

    def _ensure_registrations(self, ctx: AgentContext) -> None:
        """Safety net after the planner: a NEW script in a folder whose siblings are registered somewhere (DAG task list,
        config, task-name file) gets that file added to the plan as a modify - unless the planner declined it with a reason.
        A script that is never registered never runs; this is the defect the planner is most likely to argue away."""
        plan = ctx.plan or {}
        files = plan.get("files") or []
        planned = {f["path"] for f in files}
        # a decline only counts when it says WHICH planned file runs the new script; "the existing operator already
        # registers the folder" is the sentence that leaves a new script unregistered
        runs = re.compile(r"\b(called|invoked|included|executed|sourced|run by|runs it|runs the|\\i\b|imports?|wrapped)")
        declined = {x.get("path") for x in plan.get("registration_changes") or []
                    if "not needed" in str(x.get("what", "")).lower() and runs.search(str(x.get("what", "")).lower())}
        added = []
        for f in list(files):
            if f.get("action") != "create" or f.get("language", "").lower() not in ("sql", "python", "r", "shell", "ipynb"):
                continue
            folder = f["path"].rsplit("/", 1)[0] if "/" in f["path"] else ""
            for idx in self.inputs.indexes():
                if f.get("repo") and idx.name != f.get("repo"):
                    continue
                for c in idx.registration_candidates(folder)[:1]:
                    if c["path"] in planned or c["path"] in declined:
                        continue
                    spec = {"path": c["path"], "action": "modify", "language": idx.files[c["path"]]["language"],
                            "purpose": f"register {f['path'].rsplit('/', 1)[-1]} exactly like its siblings ({c['reason']}); example line: {c.get('example_line', '')}",
                            "outline": [f"add the entry for {f['path'].rsplit('/', 1)[-1]} next to the neighbouring entries, same style and order",
                                        "change nothing else"],
                            "depends_on": [f["path"]], "repo": f.get("repo", ""), "requirements_covered": f.get("requirements_covered", [])}
                    files.append(spec)
                    planned.add(c["path"])
                    plan.setdefault("registration_changes", []).append({"path": c["path"], "what": spec["purpose"]})
                    added.append(c["path"])
        if added:
            plan["files"] = files
            ctx.plan = plan
            self.event("log", "registration added to the plan by the safety net: " + ", ".join(added))

    def _existing(self, path: str, repo: str = "") -> Optional[str]:
        for idx in self.inputs.indexes():
            if (not repo or idx.name == repo) and path in idx.files:
                return idx.read(path, 10 ** 7)
        return None

    def _generate(self, ctx: AgentContext) -> None:
        files = ctx.plan.get("files", [])
        done = {}

        def one(spec):
            if ctx.out_of_time():
                return spec["path"], None
            existing = self._existing(spec["path"], spec.get("repo", "")) if spec["action"] == "modify" else None
            try:
                r = CoderAgent(ctx).write(spec, existing, "modify" if existing is not None else "create")
            except Exception as e:  # noqa: BLE001 - one file must not kill the whole run
                self.event("log", f"{spec['path']}: coder failed - {type(e).__name__}: {str(e)[:200]}", level="error")
                return spec["path"], {"error": f"{type(e).__name__}: {e}"}
            return spec["path"], r
        # files without dependencies first (parallel), then dependants
        order = sorted(files, key=lambda f: len(f.get("depends_on") or []))
        with cf.ThreadPoolExecutor(int(self.cfg.generation.get("parallel_files", 4))) as ex:
            for path, r in ex.map(one, order):
                if r is None:
                    self.event("log", f"{path}: skipped (time budget)")
                    continue
                if r.get("error"):
                    ctx.plan.setdefault("notes", []).append(f"{path}: not generated - {r['error'][:200]}")
                    continue
                spec = next(f for f in files if f["path"] == path)
                if spec["action"] == "modify":
                    before = self._existing(path, spec.get("repo", ""))
                    if before is not None and (r.get("content") or "").strip() == before.strip():
                        # the coder found nothing to change (a companion / config file planned "just in case"): a no-op
                        # file would only drag the confidence down - leave it out and say so
                        self.event("log", f"{path}: no change needed - left out of the result ({(r.get('explanation') or '')[:160]})")
                        plan_files = ctx.plan.get("files") or []
                        ctx.plan["files"] = [f for f in plan_files if f["path"] != path]
                        ctx.plan.setdefault("notes", []).append(f"{path}: planned as modify, the coder found nothing to change - dropped")
                        continue
                rec = {"path": path, "language": r.get("language") or spec["language"], "content": r.get("content", ""),
                       "action": spec["action"], "purpose": spec["purpose"], "explanation": r.get("explanation", ""),
                       "assumptions": r.get("assumptions", []), "confidence": r.get("confidence", 0), "repo": spec.get("repo", "")}
                self.files[path] = rec
                ctx.files[path] = rec
                self._save_file(rec)
                self.event("file", f"{spec['action']}: {path}", f"{len(rec['content'])} chars, confidence {rec['confidence']}", kind="file",
                           path=path, language=rec["language"])

    def _validate_and_fix(self, ctx: AgentContext, rounds: Optional[int] = None) -> None:
        rounds = int(self.cfg.generation.get("validate_fix_rounds", 2)) if rounds is None else rounds
        dialect = (ctx.data or {}).get("sql_dialect") or "postgres"
        for rnd in range(rounds + 1):
            findings = []
            for p, f in self.files.items():
                existing = self._existing(p, f.get("repo", "")) if f.get("action") == "modify" else None
                findings += validate_file(p, f["content"], f.get("language", ""), ctx.rules, "postgres" if "green" in dialect.lower() else dialect,
                                          existing=existing)
            self.findings = findings
            ctx.findings = findings
            self._save_json("findings.json", findings)
            blocking = [x for x in findings if x["severity"] in ("critical", "high")]
            self.event("result", f"validation: {len(findings)} finding(s), {len(blocking)} blocking, score {quality_score(findings)}",
                       "; ".join(f"{x['path']}: {x['message']}" for x in blocking[:5]), kind="validation", findings=len(findings))
            if not blocking or rnd == rounds or ctx.out_of_time():
                return
            self._fix(ctx, blocking, "validator")

    def _fix(self, ctx: AgentContext, findings: List[dict], who: str) -> None:
        by_path: Dict[str, List[dict]] = {}
        for f in findings:
            by_path.setdefault(f["path"], []).append(f)

        def one(path):
            rec = self.files[path]
            spec = {"path": path, "language": rec["language"], "purpose": rec["purpose"], "outline": [], "repo": rec.get("repo", "")}
            r = CoderAgent(ctx).write(spec, rec["content"], "fix", by_path[path])
            return path, r
        with cf.ThreadPoolExecutor(int(self.cfg.generation.get("parallel_files", 4))) as ex:
            for path, r in ex.map(one, list(by_path)):
                if r.get("content"):
                    self.files[path]["content"] = r["content"]
                    self.files[path]["explanation"] = r.get("explanation", self.files[path]["explanation"])
                    if r.get("confidence"):
                        self.files[path]["confidence"] = r["confidence"]
                    ctx.files[path] = self.files[path]
                    self._save_file(self.files[path])
                    self.event("file", f"fixed ({who}): {path}", "; ".join(f["message"][:80] for f in by_path[path][:3]), kind="file",
                               path=path, language=self.files[path]["language"])

    # ------------------------------------------------------------------ follow-up changes in the chat
    def change(self, request: str) -> dict:
        if not self.files:
            raise ValueError("nothing generated yet - run the story first")
        with self._lock:
            if self.running:
                raise RuntimeError("a run is already in progress")
            self.running = True
        t0 = time.time()
        try:
            ctx = self.ctx or self._rebuild_ctx()
            ctx.deadline = t0 + float(self.cfg.product.get("max_run_minutes", 5)) * 60
            self.event("milestone", "change requested", request[:200], pct=0)
            r = ChangeAgent(ctx).execute(request, self.history)
            if r.get("needs_clarification") and r.get("question"):
                self.event("milestone", "question", r["question"], pct=100, kind="done")
                return {"reply": r["question"], "changed": []}
            changed = []
            for ch in r.get("changes", []):
                p = ch["path"]
                if ch["action"] == "delete":
                    self.files.pop(p, None)
                    ctx.files.pop(p, None)
                    try:
                        (self.folder / "files" / p).unlink()
                    except Exception:  # noqa: BLE001
                        pass
                    changed.append(p)
                    continue
                rec = self.files.get(p)
                spec = {"path": p, "language": ch.get("language") or (rec or {}).get("language", ""), "purpose": ch.get("purpose") or (rec or {}).get("purpose", ""),
                        "outline": ch.get("instructions", []), "repo": (rec or {}).get("repo", "")}
                existing = rec["content"] if rec else self._existing(p)
                mode = "fix" if rec else ("modify" if existing is not None else "create")
                out = CoderAgent(ctx).write(spec, existing, mode, [{"path": p, "severity": "high", "message": i} for i in ch.get("instructions", [])], request)
                if out.get("content"):
                    self.files[p] = {"path": p, "language": out.get("language") or spec["language"], "content": out["content"],
                                     "action": (rec or {}).get("action", "create"), "purpose": spec["purpose"],
                                     "explanation": out.get("explanation", ""), "assumptions": out.get("assumptions", []),
                                     "confidence": out.get("confidence", 0), "repo": spec["repo"]}
                    ctx.files[p] = self.files[p]
                    self._save_file(self.files[p])
                    changed.append(p)
                    self.event("file", f"changed: {p}", out.get("explanation", "")[:200], kind="file", path=p, language=self.files[p]["language"])
            if changed:
                self._validate_and_fix(ctx, rounds=1)
            self._write_outputs(t0)
            self.event("milestone", "change complete", f"{len(changed)} file(s)", pct=100, kind="done")
            return {"reply": r.get("reply", ""), "changed": changed, "understanding": r.get("understanding", "")}
        finally:
            self.running = False

    def _rebuild_ctx(self) -> AgentContext:
        pack = build_pack(self.inputs, self.cfg)
        ctx = AgentContext(self.cfg, self.llm, self.inputs, pack, self._trace_sink)
        ctx.plan = self.plan
        ctx.files = self.files
        st = self._load_json("story_result.json") or {}
        ctx.story = st
        kn = self._load_json("knowledge.json") or {}
        ctx.knowledge, ctx.rules = kn, kn.get("rules", [])
        self.ctx = ctx
        return ctx

    # ------------------------------------------------------------------ confidence
    def confidence(self) -> dict:
        """One number a developer can act on, built from three independent signals and capped by what is still open:
             40 % validator quality  (deterministic checks: syntax, Airflow, SQL parse, team rules)
             35 % reviewer score     (independent reviewer agent: requirements, story code, registration, impact, standards)
             25 % coder confidence   (the coder's own, averaged over the files)
           caps: review skipped -> max 70; open critical finding -> max 50; open high finding -> max 75;
                 a file below 60 coder confidence -> max 80; open questions in the plan -> -2 each (max -10).
           grade: High >= 85, Medium >= 70, Low < 70. The parts and caps are returned so the UI can explain the number."""
        if not self.files:
            return {"score": None, "grade": "none", "parts": {}, "caps": [], "explain": "no files generated"}
        q = quality_score(self.findings)
        rev = self.review or {}
        r_score = rev.get("score")
        coder = [f.get("confidence") for f in self.files.values() if isinstance(f.get("confidence"), (int, float))]
        c_mean = round(sum(coder) / len(coder), 1) if coder else None
        parts = {"validator_quality": q, "reviewer_score": r_score, "coder_confidence": c_mean}
        if r_score is None:
            score = 0.6 * q + 0.4 * (c_mean if c_mean is not None else q)
        else:
            score = 0.40 * q + 0.35 * r_score + 0.25 * (c_mean if c_mean is not None else r_score)
        caps = []
        open_sev = {f.get("severity") for f in self.findings} | {f.get("severity") for f in rev.get("findings", []) or [] if f.get("status") != "fixed"}
        if rev.get("skipped") or r_score is None:
            caps.append(("review did not run", 70))
        if "critical" in open_sev:
            caps.append(("an open critical finding", 50))
        elif "high" in open_sev:
            caps.append(("an open high finding", 75))
        if coder and min(coder) < 60:
            caps.append((f"a file with coder confidence {min(coder)}", 80))
        for why, cap in caps:
            score = min(score, cap)
        nq = len((self.plan or {}).get("questions") or [])
        if nq:
            score -= min(10, 2 * nq)
            caps.append((f"{nq} open question(s) in the plan", -min(10, 2 * nq)))
        score = int(round(max(0, min(100, score))))
        grade = "High" if score >= 85 else "Medium" if score >= 70 else "Low"
        explain = (f"40% validator {q} + 35% reviewer {r_score if r_score is not None else '-'} + 25% coder {c_mean if c_mean is not None else '-'}"
                   + ("; capped by " + ", ".join(f"{w} (max {c})" if c > 0 else f"{w} ({c})" for w, c in caps) if caps else ""))
        blocking = [{"path": f.get("path"), "line": f.get("line"), "severity": f.get("severity"), "message": f.get("message"), "from": "validator"}
                    for f in self.findings if f.get("severity") in ("critical", "high")]
        blocking += [{"path": f.get("path"), "line": f.get("line"), "severity": f.get("severity"), "message": f.get("message"),
                      "suggestion": f.get("suggestion"), "from": "reviewer"}
                     for f in (rev.get("findings", []) or []) if f.get("severity") in ("critical", "high") and f.get("status") != "fixed"]
        to_raise = [f"fix the {len(blocking)} blocking finding(s) listed below" if blocking else "",
                    "run the review (raise product.max_run_minutes)" if r_score is None else "",
                    "answer the open questions of the plan and re-run" if nq else ""]
        return {"score": score, "grade": grade, "parts": parts, "caps": [{"reason": w, "cap": c} for w, c in caps],
                "explain": explain, "to_raise": [t for t in to_raise if t], "blocking": blocking,
                "open_questions": list((self.plan or {}).get("questions") or [])}

    # ------------------------------------------------------------------ sources (what contributed to the generated code)
    def sources(self) -> dict:
        """Everything that contributed to this run's code, per source, with WHAT was taken from it: the story (requirements,
        rules, code blocks), every document (definitions / conventions / rules extracted from that file), every table
        (columns described, columns actually used in the generated code, sample rows), queries, repositories and the
        repository files (pattern imitated / modified / registration / companion / read / in context), terms looked up."""
        ov = self.inputs.overview()
        used = (self.ctx.used if self.ctx else []) or []
        pack = self._load_json("pack.json") or {}
        story_r = self._load_json("story_result.json") or {}
        kn = self._load_json("knowledge.json") or {}
        repo_r = self._load_json("repo.json") or {}
        gen_text = "\n".join(f.get("content", "") for f in self.files.values())
        by_tool: Dict[str, Dict[str, set]] = {}
        for u in used:
            by_tool.setdefault(u["tool"], {}).setdefault(u["ref"], set()).add(u["agent"].replace("_agent", ""))

        def refs(tool):
            return [{"ref": r, "agents": sorted(a)} for r, a in sorted(by_tool.get(tool, {}).items())]

        # ---- story
        st = ov.get("story") or {}
        story = None
        if st:
            cb = story_r.get("code_in_story") or []
            story = {"id": st.get("id"), "title": st.get("title"), "source": st.get("source", {}),
                     "extracted": f"{len(story_r.get('functional_requirements') or [])} requirements, {len(story_r.get('business_rules') or [])} business rules, "
                                  f"{len(story_r.get('acceptance_criteria') or [])} acceptance criteria, {len(cb)} code block(s) used as specification, "
                                  f"tables mentioned: {', '.join(story_r.get('tables_mentioned') or []) or '-'}"}
        # ---- documents: what the knowledge agent took from each file
        docs = []
        for kind in ("skills", "standards", "glossary"):
            for d in (ov.get(kind) or []):
                name = d["name"]
                defs = [x for x in kn.get("definitions", []) if name.lower() in str(x.get("source", "")).lower()]
                conv = [x for x in kn.get("conventions", []) if name.lower() in str(x.get("source", "")).lower()]
                parts = []
                if defs:
                    parts.append(f"{len(defs)} definition(s): " + ", ".join(x.get("term", "") for x in defs[:8]) + (" ..." if len(defs) > 8 else ""))
                if conv:
                    parts.append(f"{len(conv)} convention(s): " + "; ".join(str(x.get("rule", ""))[:70] for x in conv[:4]) + (" ..." if len(conv) > 4 else ""))
                docs.append({"kind": "standards (glossary)" if kind == "glossary" else kind, "name": name, "chars": d.get("chars"),
                             "extracted": "; ".join(parts) if parts else "in the knowledge agent's context (no item attributed to this file by name)"})
        # ---- tables: columns described, columns used in the generated code, samples
        tables = []
        for t in self.inputs.tables:
            cols = [c["name"] for c in t.get("columns", [])]
            used_cols = [c for c in cols if re.search(r"\b" + re.escape(c) + r"\b", gen_text)]
            tables.append({"table": f"{t['schema']}.{t['table']}", "columns": len(cols), "sample_rows": len(t.get("sample") or []),
                           "extracted": f"{len(cols)} columns with types" + (f", keys {', '.join(t.get('keys') or [])}" if t.get("keys") else "")
                                        + (f", distribution {t.get('distribution')}" if t.get("distribution") else "") + f", {len(t.get('sample') or [])} sample rows"
                                        + (f"; columns used in the generated code: {', '.join(used_cols)}" if used_cols else "; no column of it appears in the generated code")})
        queries = [{"name": q["name"], "row_count": q.get("row_count"), "extracted": f"result shape: {len(q.get('columns') or [])} columns ({', '.join((q.get('columns') or [])[:10])}), {q.get('row_count')} rows"}
                   for q in self.inputs.queries]
        # ---- repository files and their role
        roles: Dict[str, List[str]] = {}
        def add(path, role):
            if path:
                roles.setdefault(path, [])
                if role not in roles[path]:
                    roles[path].append(role)
        for rp in pack.get("repos", []):
            for f in rp.get("relevant_files", []):
                add(f["path"], "in the context pack (relevant to the story / plan)")
        for x in repo_r.get("patterns_to_imitate", []) or []:
            add(x.get("path"), "pattern imitated: " + str(x.get("why", ""))[:90])
        for x in repo_r.get("existing_files_to_modify", []) or []:
            add(x.get("path"), "existing file to modify: " + str(x.get("why", ""))[:90])
        for x in repo_r.get("registration_points", []) or []:
            add(x.get("path"), "registration point: " + str(x.get("what_to_add", ""))[:90])
        for x in repo_r.get("companion_files", []) or []:
            add(x.get("path"), f"companion ({x.get('action', '')}): " + str(x.get("what_to_change", ""))[:90])
        for r in refs("read_file"):
            add(r["ref"], "read in full by " + ", ".join(r["agents"]))
        for pth, f in self.files.items():
            if f.get("action") == "modify":
                add(pth, "MODIFIED by this run")
        repo_files = [{"path": pth, "roles": rl} for pth, rl in sorted(roles.items())]
        if kn.get("rules"):
            docs.append({"kind": "derived", "name": "validator rules", "chars": None,
                         "extracted": f"{len(kn['rules'])} checkable rule(s) derived from the standards files: " + ", ".join(str(r.get("id", "")) for r in kn["rules"][:8])})
        return {"story": story, "documents": docs, "tables": tables, "queries": queries,
                "repositories": [{"name": r["name"], "branch": r.get("branch"), "url": r.get("url"), "files_indexed": r.get("files"),
                                  "extracted": f"{r.get('files')} files indexed for search; {sum(1 for x in roles)} file(s) used (listed below)"} for r in (ov.get("repos") or [])],
                "repository_files": repo_files,
                "glossary_terms_looked_up": refs("define_term"), "knowledge_sections_read": refs("read_section"),
                "repository_searches": refs("search_repo") + refs("grep_repo"), "registration_lookups": refs("registration_points") + refs("companion_files") + refs("references"),
                "tables_described_on_demand": refs("describe_table"), "user_instructions": ov.get("instructions") or []}

    AGENT_OUTPUTS = {"story_agent": "story_result.json", "knowledge_agent": "knowledge.json", "data_agent": "data.json", "repo_agent": "repo.json",
                     "planner_agent": "plan.json", "reviewer_agent": "review.json", "validator": "findings.json", "run_summary": "run_summary.json",
                     "sources": "sources.json", "context_pack": "pack.json", "tokens": "tokens.json"}

    # ------------------------------------------------------------------ outputs
    def _write_outputs(self, t0: float, failed: str = "") -> None:
        stats = self.llm.token_stats() if hasattr(self.llm, "token_stats") else {"total": {}, "by_agent": {}}
        self.summary = {"user": self.user, "chat_id": self.chat_id, "story": {k: self.inputs.story.get(k) for k in ("id", "title")} if self.inputs.story else None,
                        "files": [{"path": p, "language": f["language"], "action": f["action"], "chars": len(f["content"]), "confidence": f.get("confidence")} for p, f in self.files.items()],
                        "quality_score": quality_score(self.findings) if self.files else 0, "review": {k: self.review.get(k) for k in ("verdict", "score", "summary")},
                        "findings": len(self.findings), "duration_seconds": round(time.time() - t0, 1), "tokens": stats["total"],
                        "confidence": self.confidence(),
                        "tokens_by_agent": stats["by_agent"], "pricing": stats.get("pricing"), "failed": failed, "finished": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
        self.summary["cost_usd"] = (stats.get("total") or {}).get("cost_usd")
        self._save_json("run_summary.json", self.summary)
        self._save_json("tokens.json", stats)
        if self.ctx:
            self._save_json("story_result.json", self.ctx.story)
            self._save_json("knowledge.json", self.ctx.knowledge)
            self._save_json("data.json", self.ctx.data)
            self._save_json("repo.json", self.ctx.repo)
        try:
            self._save_json("sources.json", self.sources())      # after the agent outputs: it reads them
        except Exception as e:  # noqa: BLE001
            log.warning("sources not saved: %s", e)
        try:
            txt = self.llm.token_stats_text() if hasattr(self.llm, "token_stats_text") else json.dumps(stats, indent=1)
            (self.folder / "tokens.txt").write_text(txt, encoding="utf-8")
            self.log("\n" + txt)
        except Exception:  # noqa: BLE001
            pass
        if self.files and (bool(self.cfg.generation.get("docs", False)) or getattr(self, "docs_wanted", False)):
            try:
                from .docgen import write_docs
                self.docs = write_docs(self)
                for d in self.docs:
                    self.event("result", f"documentation: {Path(d).name}", kind="docs", path=d)
            except Exception as e:  # noqa: BLE001
                self.event("error", "documentation failed", str(e)[:200])
        self.make_zip()

    def make_zip(self) -> Path:
        sid = _safe((self.inputs.story or {}).get("id", "run"))
        zp = self.folder / f"agiledev_{sid}.zip"
        with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
            for p, f in self.files.items():
                z.writestr(p, f["content"])
            for name in ("plan.json", "review.json", "findings.json", "run_summary.json", "tokens.txt", "log.txt", "pack.json"):
                fp = self.folder / name
                if fp.exists():
                    z.write(fp, f"_agiledev/{name}")
            z.writestr("_agiledev/README.txt", self.readme_text())
            for d in getattr(self, "docs", []) or []:
                if Path(d).exists():
                    z.write(d, f"_agiledev/{Path(d).name}")
        return zp

    # ------------------------------------------------------------------ savepoints (named snapshots of the generated code)
    def savepoints(self) -> List[dict]:
        return self._load_json("savepoints.json") or []

    def save_point(self, name: str = "", note: str = "") -> dict:
        """Snapshot every generated file + plan / review / findings / summary into savepoints/<name>.zip (restorable, downloadable)."""
        if not self.files:
            raise ValueError("nothing to save yet - run first")
        sps = self.savepoints()
        name = (name or "").strip() or f"savepoint-{len(sps) + 1}"
        name = re.sub(r"[^A-Za-z0-9._-]+", "-", name).strip("-")[:60]
        d = self.folder / "savepoints"
        d.mkdir(parents=True, exist_ok=True)
        zp = d / f"{name}.zip"
        with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
            for pth, f in self.files.items():
                z.writestr("files/" + pth, f["content"])
            z.writestr("files_meta.json", json.dumps({k: {x: v for x, v in f.items() if x != "content"} for k, f in self.files.items()}, default=str))
            for nm in ("plan.json", "review.json", "findings.json", "run_summary.json"):
                fp = self.folder / nm
                if fp.exists():
                    z.write(fp, nm)
        conf = (self.summary or {}).get("confidence") or {}
        rec = {"name": name, "created": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "files": sorted(self.files), "note": note,
               "confidence": conf.get("score"), "zip": zp.name}
        sps = [x for x in sps if x["name"] != name] + [rec]
        self._save_json("savepoints.json", sps)
        self.event("result", f"savepoint {name} saved", f"{len(self.files)} file(s)" + (f", confidence {conf.get('score')}" if conf.get("score") is not None else ""), kind="savepoint")
        return rec

    def restore_point(self, name: str) -> dict:
        """Replace the generated files (and plan / review / findings / summary) with the savepoint's; the current state is saved
        first as 'before-restore-<n>' so a revert is itself reversible."""
        sps = self.savepoints()
        rec = next((x for x in sps if x["name"] == name), None) or next((x for x in sps if x["name"].lower() == name.lower()), None)
        if not rec:
            raise ValueError(f"no savepoint named {name!r}; available: " + (", ".join(x["name"] for x in sps) or "none"))
        if self.files:
            self.save_point(f"before-restore-{sum(1 for x in sps if x['name'].startswith('before-restore')) + 1}", note=f"state before reverting to {rec['name']}")
        zp = self.folder / "savepoints" / rec["zip"]
        import shutil
        if (self.folder / "files").exists():
            shutil.rmtree(self.folder / "files")
        self.files = {}
        with zipfile.ZipFile(zp) as z:
            meta = json.loads(z.read("files_meta.json").decode("utf-8"))
            for n in z.namelist():
                if n.startswith("files/") and not n.endswith("/"):
                    pth = n[len("files/"):]
                    self.files[pth] = dict(meta.get(pth, {"path": pth, "language": "", "action": "create", "purpose": ""}), content=z.read(n).decode("utf-8"))
            for nm in ("plan.json", "review.json", "findings.json", "run_summary.json"):
                if nm in z.namelist():
                    (self.folder / nm).write_bytes(z.read(nm))
        for f in self.files.values():
            self._save_file(f)
        self.plan = self._load_json("plan.json") or {}
        self.review = self._load_json("review.json") or {}
        self.findings = self._load_json("findings.json") or []
        self.summary = self._load_json("run_summary.json") or {}
        if self.ctx:
            self.ctx.files = dict(self.files)
            self.ctx.plan = self.plan
        self.make_zip()
        self.event("result", f"reverted to savepoint {rec['name']}", f"{len(self.files)} file(s) restored", kind="savepoint")
        return rec

    def readme_text(self) -> str:
        s = self.inputs.story or {}
        lines = [f"Agile Dev Assist output for story {s.get('id', '')}: {s.get('title', '')}", f"user: {self.user}  chat: {self.chat_id}",
                 "", "Approach:", self.plan.get("approach", ""), "", "Files:"]
        for p, f in self.files.items():
            lines.append(f"  {f['action']:7s} {p}  [{f['language']}]  {f['purpose']}")
        if self.review:
            lines += ["", f"Review: {self.review.get('verdict')} score {self.review.get('score')} - {self.review.get('summary', '')}"]
        return "\n".join(lines)

    # ------------------------------------------------------------------ publish
    def publish(self, url: str, token: str, branch: str, base_branch: str, message: str = "", author: Optional[dict] = None,
                paths: Optional[List[str]] = None) -> dict:
        if not self.files:
            raise ValueError("nothing to push")
        gc = GitClient(url, token, self.cfg.git.get("ssl_verify", True), self.cfg.git.get("default_provider", "gitlab"))
        who = gc.whoami()
        s = self.inputs.story or {}
        msg = message or self.cfg.git.get("commit_message_template", "{story_id}: {title}").format(
            story_id=s.get("id", ""), title=s.get("title", "")[:80], user=who.get("name") or self.user)
        files = {p: f["content"] for p, f in self.files.items() if not paths or p in paths}
        self.event("input", f"pushing {len(files)} file(s) to {gc.project} branch {branch}", f"as {who.get('username')} from {base_branch}", kind="publish")
        r = gc.publish(branch, base_branch, msg, files, author or {"name": who.get("name"), "email": who.get("email")})
        r["pushed_as"] = who.get("username")
        r["paths"] = sorted(files)
        hist = self._load_json("publish.json") or []
        hist = hist if isinstance(hist, list) else [hist]
        hist.append(r)
        self._save_json("publish.json", hist)
        self.event("result", f"pushed: {r['branch']}", r.get("branch_url", ""), kind="publish", url=r.get("branch_url", ""))
        return r

    def suggest_branch(self, repo_url: str = "") -> str:
        s = self.inputs.story or {}
        feature = (self.ctx.story.get("feature_name") if self.ctx and self.ctx.story else "") or \
            (self._load_json("story_result.json") or {}).get("feature_name") or s.get("title", "change")
        repo = ""
        if repo_url:
            from .gitclient import parse_project_url
            repo = parse_project_url(repo_url).get("project", "").rsplit("/", 1)[-1]
        elif self.inputs.repos:
            repo = self.inputs.repos[0]["name"]
        return GitClient.branch_name(self.cfg.git.get("branch_template", "{story_id}-{repo}-{feature}"), s.get("id", "story"),
                                     repo or "repo", feature, int(self.cfg.git.get("branch_name_max_length", 80)))

    # ------------------------------------------------------------------ edits from the UI
    def update_file(self, path: str, content: str) -> dict:
        rec = self.files.get(path) or {"path": path, "language": "", "action": "create", "purpose": "edited in the UI",
                                       "explanation": "", "assumptions": [], "confidence": 0, "repo": ""}
        rec["content"] = content
        from .validators import language_of
        rec["language"] = rec["language"] or language_of(path)
        self.files[path] = rec
        if self.ctx:
            self.ctx.files[path] = rec
        self._save_file(rec)
        fnd = validate_file(path, content, rec["language"], self.ctx.rules if self.ctx else [])
        self.findings = [f for f in self.findings if f["path"] != path] + fnd
        self._save_json("findings.json", self.findings)
        self.event("file", f"edited in the UI: {path}", f"{len(fnd)} finding(s)", kind="file", path=path, language=rec["language"])
        self.make_zip()
        return {"path": path, "findings": fnd}

    # ------------------------------------------------------------------ persistence
    def _save_file(self, rec: dict) -> None:
        p = self.folder / "files" / rec["path"]
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(rec["content"], encoding="utf-8")
        self._save_json("files_meta.json", {k: {x: v for x, v in f.items() if x != "content"} for k, f in self.files.items()})

    def _save_json(self, name: str, data) -> None:
        try:
            (self.folder / name).write_text(json.dumps(data, ensure_ascii=False, indent=1, default=str), encoding="utf-8")
        except Exception as e:  # noqa: BLE001
            log.warning("%s not saved: %s", name, e)

    def _load_json(self, name: str):
        p = self.folder / name
        if p.exists():
            try:
                return json.loads(p.read_text(encoding="utf-8"))
            except Exception:  # noqa: BLE001
                return None
        return None

    def _load_state(self) -> None:
        self.plan = self._load_json("plan.json") or {}
        self.review = self._load_json("review.json") or {}
        self.findings = self._load_json("findings.json") or []
        self.summary = self._load_json("run_summary.json") or {}
        self.history = self._load_json("history.json") or []
        meta = self._load_json("files_meta.json") or {}
        for p, m in meta.items():
            fp = self.folder / "files" / p
            if fp.exists():
                self.files[p] = dict(m, content=fp.read_text(encoding="utf-8"))
        ev = self.folder / "events.jsonl"
        if ev.exists():
            try:
                self.events = [json.loads(l) for l in ev.read_text(encoding="utf-8").splitlines() if l.strip()]
            except Exception:  # noqa: BLE001
                self.events = []

    def add_history(self, role: str, text: str, **extra) -> dict:
        m = {"role": role, "text": text, "ts": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), **extra}
        self.history.append(m)
        self._save_json("history.json", self.history)
        return m

    def _pushed(self) -> dict:
        """path -> [{project, branch, url}] of every push made from this chat (several pushes to several repos are normal)."""
        hist = self._load_json("publish.json") or []
        hist = hist if isinstance(hist, list) else [hist]
        out: Dict[str, list] = {}
        for h in hist:
            for pth in h.get("paths") or []:
                out.setdefault(pth, []).append({"project": h.get("project", ""), "branch": h.get("branch", ""), "url": h.get("branch_url", "")})
        return out

    def state(self) -> dict:
        return {"chat_id": self.chat_id, "user": self.user, "inputs": self.inputs.overview(), "plan": self.plan,
                "files": [{k: v for k, v in f.items() if k != "content"} for f in self.files.values()],
                "review": self.review, "findings": self.findings, "summary": self.summary, "running": self.running,
                "docs": [d for d in (getattr(self, "docs", []) or []) if Path(d).exists()],
                "pipeline": list(self.inputs.pipeline or DEFAULT_PIPELINE), "default_pipeline": DEFAULT_PIPELINE,
                "pushed": self._pushed(), "savepoints": self.savepoints(), "sources": self._load_json("sources.json") or {},
                "agent_outputs": [k for k, v in self.AGENT_OUTPUTS.items() if (self.folder / v).exists()],
                "history": self.history, "events": self.events[-400:]}


def _safe(s: str) -> str:
    import re
    return re.sub(r"[^A-Za-z0-9._@-]+", "_", str(s))[:120] or "x"
