"""Greenplum / PostgreSQL input: connection details entered in the UI (held in memory), tables introspected into a
standard JSON shape (columns, types, comments, keys, distribution, sample rows), optional read-only query."""
from __future__ import annotations

import logging
import re
from typing import List, Optional

log = logging.getLogger(__name__)

READ_ONLY = re.compile(r"(?is)^\s*(with\b.*?\bselect\b|select\b|explain\b|show\b)")
FORBIDDEN = re.compile(r"(?i)\b(insert|update|delete|drop|alter|create|truncate|grant|revoke|copy|vacuum|analyze)\b")


class GreenplumInput:
    def __init__(self, host: str, port: int, database: str, user: str, password: str, sslmode: str = "prefer",
                 statement_timeout_seconds: int = 60, sqlite_path: Optional[str] = None):
        self.conn_info = {"host": host, "port": int(port or 5432), "database": database, "user": user, "sslmode": sslmode}
        self._password = password
        self.timeout = int(statement_timeout_seconds)
        self.sqlite_path = sqlite_path            # self-test: a sqlite file plays the database
        self._conn = None

    # ------------------------------------------------------------------ connection
    def connect(self):
        if self._conn is not None:
            return self._conn
        if self.sqlite_path:
            import sqlite3
            self._conn = sqlite3.connect(self.sqlite_path, check_same_thread=False)
            return self._conn
        import psycopg2
        self._conn = psycopg2.connect(host=self.conn_info["host"], port=self.conn_info["port"], dbname=self.conn_info["database"],
                                      user=self.conn_info["user"], password=self._password, sslmode=self.conn_info["sslmode"],
                                      connect_timeout=20, options=f"-c statement_timeout={self.timeout * 1000}")
        self._conn.set_session(readonly=True, autocommit=True)
        return self._conn

    def close(self):
        try:
            if self._conn is not None:
                self._conn.close()
        finally:
            self._conn = None

    def test(self) -> str:
        rows = self.query("select version()" if not self.sqlite_path else "select sqlite_version()")
        return str(rows["rows"][0][0])[:80] if rows["rows"] else "connected"

    def query(self, sql: str, limit: int = 200) -> dict:
        """Read-only SELECT with a row cap."""
        if not READ_ONLY.match(sql) or FORBIDDEN.search(sql):
            raise ValueError("only read-only SELECT / WITH / EXPLAIN queries are allowed")
        s = sql.strip().rstrip(";")
        if not re.search(r"(?i)\blimit\s+\d+\s*$", s) and not s.lower().startswith("explain"):
            s = f"select * from ({s}) _q limit {int(limit)}"
        cur = self.connect().cursor()
        cur.execute(s)
        cols = [d[0] for d in cur.description] if cur.description else []
        rows = [[_cell(c) for c in r] for r in cur.fetchall()]
        return {"sql": sql, "columns": cols, "rows": rows, "row_count": len(rows)}

    # ------------------------------------------------------------------ introspection
    def describe(self, schema: str, table: str, sample_rows: int = 5) -> dict:
        if self.sqlite_path:
            return self._describe_sqlite(table, sample_rows)
        cur = self.connect().cursor()
        cur.execute("""select c.column_name, c.data_type, c.character_maximum_length, c.numeric_precision, c.numeric_scale,
                              c.is_nullable, c.column_default, c.ordinal_position,
                              pg_catalog.col_description((quote_ident(c.table_schema) || '.' || quote_ident(c.table_name))::regclass::oid,
                                                         c.ordinal_position::int)
                       from information_schema.columns c
                       where c.table_schema = %s and c.table_name = %s order by c.ordinal_position""", (schema, table))
        cols = [{"name": r[0], "type": _type(r[1], r[2], r[3], r[4]), "nullable": r[5] == "YES", "default": r[6],
                 "position": r[7], "comment": r[8] or ""} for r in cur.fetchall()]
        if not cols:
            raise ValueError(f"table {schema}.{table} not found or no columns visible")
        out = {"schema": schema, "table": table, "columns": cols, "comment": "", "kind": "table", "keys": [],
               "distribution": [], "row_estimate": None, "sample": {"columns": [], "rows": []}}
        try:
            cur.execute("""select case c.relkind when 'v' then 'view' when 'm' then 'materialized view' else 'table' end,
                                  obj_description(c.oid), c.reltuples
                           from pg_class c join pg_namespace n on n.oid = c.relnamespace
                           where n.nspname = %s and c.relname = %s""", (schema, table))
            r = cur.fetchone()
            if r:
                out["kind"], out["comment"], out["row_estimate"] = r[0], r[1] or "", int(r[2] or 0)
        except Exception as e:  # noqa: BLE001
            log.debug("pg_class lookup failed: %s", e)
        try:
            cur.execute("""select kcu.column_name from information_schema.table_constraints tc
                           join information_schema.key_column_usage kcu on kcu.constraint_name = tc.constraint_name
                           where tc.table_schema = %s and tc.table_name = %s and tc.constraint_type in ('PRIMARY KEY','UNIQUE')""", (schema, table))
            out["keys"] = [r[0] for r in cur.fetchall()]
        except Exception:  # noqa: BLE001
            pass
        try:
            cur.execute("""select a.attname from gp_distribution_policy p
                           join pg_class c on c.oid = p.localoid join pg_namespace n on n.oid = c.relnamespace
                           join pg_attribute a on a.attrelid = c.oid and a.attnum = any(p.distkey)
                           where n.nspname = %s and c.relname = %s""", (schema, table))
            out["distribution"] = [r[0] for r in cur.fetchall()]
        except Exception:  # noqa: BLE001  (not Greenplum)
            pass
        if sample_rows:
            try:
                q = self.query(f'select * from "{schema}"."{table}" limit {int(sample_rows)}', limit=sample_rows)
                out["sample"] = {"columns": q["columns"], "rows": q["rows"]}
            except Exception as e:  # noqa: BLE001
                out["sample_error"] = str(e)[:200]
        return out

    def _describe_sqlite(self, table: str, sample_rows: int) -> dict:
        cur = self.connect().cursor()
        cur.execute(f"pragma table_info('{table}')")
        cols = [{"name": r[1], "type": r[2] or "text", "nullable": not r[3], "default": r[4], "position": r[0] + 1,
                 "comment": ""} for r in cur.fetchall()]
        if not cols:
            raise ValueError(f"table {table} not found")
        out = {"schema": "main", "table": table, "columns": cols, "comment": "", "kind": "table",
               "keys": [c["name"] for c in cols if c["position"] == 1], "distribution": [], "row_estimate": None}
        q = self.query(f"select * from {table} limit {int(sample_rows)}", limit=sample_rows)
        out["sample"] = {"columns": q["columns"], "rows": q["rows"]}
        return out

    def list_tables(self, schema: str, like: str = "", limit: int = 200) -> List[str]:
        if self.sqlite_path:
            cur = self.connect().cursor()
            cur.execute("select name from sqlite_master where type in ('table','view') order by name")
            return [r[0] for r in cur.fetchall() if not like or like.replace("%", "") in r[0]][:limit]
        cur = self.connect().cursor()
        cur.execute("""select table_name from information_schema.tables where table_schema = %s and table_name like %s
                       order by table_name limit %s""", (schema, like or "%", int(limit)))
        return [r[0] for r in cur.fetchall()]


def _type(dt, ln, prec, scale) -> str:
    if dt in ("character varying", "character", "varchar") and ln:
        return f"{dt}({ln})"
    if dt == "numeric" and prec:
        return f"numeric({prec},{scale or 0})"
    return dt or ""


def _cell(c):
    if c is None or isinstance(c, (int, float, str, bool)):
        return c
    return str(c)


def table_text(t: dict) -> str:
    lines = [f"### {t['schema']}.{t['table']} ({t.get('kind', 'table')}" + (f", ~{t['row_estimate']} rows" if t.get("row_estimate") else "") + ")"]
    if t.get("comment"):
        lines.append(f"comment: {t['comment']}")
    if t.get("keys"):
        lines.append(f"keys: {', '.join(t['keys'])}")
    if t.get("distribution"):
        lines.append(f"distributed by: {', '.join(t['distribution'])}")
    for c in t["columns"]:
        lines.append(f"  - {c['name']} {c['type']}" + ("" if c.get("nullable", True) else " not null") + (f"  -- {c['comment']}" if c.get("comment") else ""))
    s = t.get("sample") or {}
    if s.get("rows"):
        lines.append("sample rows: " + " | ".join(s["columns"]))
        for r in s["rows"]:
            lines.append("  " + " | ".join(str(x)[:60] for x in r))
    return "\n".join(lines)
