"""Single sign-on + per-user sessions.

Modes (config auth.mode):
  header  corporate SSO in front (reverse proxy / IdP agent) authenticates and sets a trusted header with the user id
          (e.g. X-Remote-User); optional display-name header. The app never sees a password.
  oidc    OpenID Connect authorization-code flow against the corporate IdP (Azure AD / Entra, Okta, Keycloak ...):
          /auth/login -> IdP -> /auth/callback; the id_token claim (user_claim) is the user id.
  dev     a login form asking only for a user name - local runs and demos.

Whatever the mode, the app issues its own signed, HttpOnly session cookie (HMAC, server secret) carrying the user id.
Per-user secrets entered in the UI (git tokens, Greenplum passwords) live in `Vault` - server memory only.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import threading
import time
from typing import Optional
from urllib.parse import urlencode

COOKIE = "agiledev_session"


class Auth:
    def __init__(self, cfg, secret: str):
        self.cfg = cfg
        self.a = cfg.get("auth") or {}
        self.mode = str(self.a.get("mode", "dev")).lower()
        self.secret = (secret or os.environ.get("AGILEDEV_SERVER_SECRET") or hashlib.sha256(os.urandom(32)).hexdigest()).encode()
        self.ttl = float(self.a.get("session_hours", 12)) * 3600
        self._oidc_meta = None

    # ------------------------------------------------------------------ cookie
    def sign(self, user: dict) -> str:
        payload = base64.urlsafe_b64encode(json.dumps({"u": user["user_id"], "n": user.get("display_name", ""),
                                                       "e": user.get("email", ""), "x": time.time() + self.ttl}).encode()).decode()
        sig = hmac.new(self.secret, payload.encode(), hashlib.sha256).hexdigest()
        return f"{payload}.{sig}"

    def verify(self, token: str) -> Optional[dict]:
        try:
            payload, sig = token.rsplit(".", 1)
            if not hmac.compare_digest(sig, hmac.new(self.secret, payload.encode(), hashlib.sha256).hexdigest()):
                return None
            d = json.loads(base64.urlsafe_b64decode(payload.encode()))
            if d.get("x", 0) < time.time():
                return None
            return {"user_id": d["u"], "display_name": d.get("n", ""), "email": d.get("e", "")}
        except Exception:  # noqa: BLE001
            return None

    def allowed(self, user_id: str) -> bool:
        al = [str(x).lower() for x in (self.a.get("allowed_users") or [])]
        return not al or user_id.lower() in al

    def is_admin(self, user_id: str) -> bool:
        return user_id.lower() in [str(x).lower() for x in (self.a.get("admins") or [])]

    # ------------------------------------------------------------------ identify the request
    def user_from_request(self, headers: dict, cookies: dict) -> Optional[dict]:
        """headers / cookies are case-insensitive dict-likes (Starlette's)."""
        if self.mode == "header":
            hn = self.a.get("header_name", "X-Remote-User")
            uid = headers.get(hn) or headers.get(hn.lower())
            if uid:
                dn = headers.get(self.a.get("header_display_name", "X-Remote-Name"), "") or ""
                return {"user_id": uid.strip(), "display_name": dn.strip(), "email": uid.strip() if "@" in uid else ""}
        tok = cookies.get(COOKIE)
        if tok:
            return self.verify(tok)
        return None

    # ------------------------------------------------------------------ oidc
    def oidc_meta(self) -> dict:
        if self._oidc_meta is None:
            import requests
            o = self.a.get("oidc") or {}
            issuer = o.get("issuer", "").rstrip("/")
            self._oidc_meta = requests.get(f"{issuer}/.well-known/openid-configuration", timeout=30).json()
        return self._oidc_meta

    def oidc_login_url(self, redirect_uri: str, state: str) -> str:
        o = self.a.get("oidc") or {}
        return self.oidc_meta()["authorization_endpoint"] + "?" + urlencode({
            "client_id": o.get("client_id", ""), "response_type": "code", "scope": o.get("scopes", "openid profile email"),
            "redirect_uri": redirect_uri, "state": state})

    def oidc_exchange(self, code: str, redirect_uri: str, client_secret: str) -> dict:
        import requests
        o = self.a.get("oidc") or {}
        meta = self.oidc_meta()
        r = requests.post(meta["token_endpoint"], data={"grant_type": "authorization_code", "code": code, "redirect_uri": redirect_uri,
                                                        "client_id": o.get("client_id", ""), "client_secret": client_secret}, timeout=30)
        r.raise_for_status()
        tokens = r.json()
        claims = self._verify_id_token(tokens.get("id_token", ""), meta, o.get("client_id", ""))
        uid = claims.get(o.get("user_claim", "preferred_username")) or claims.get("email") or claims.get("sub")
        return {"user_id": uid, "display_name": claims.get("name", ""), "email": claims.get("email", "")}

    @staticmethod
    def _verify_id_token(id_token: str, meta: dict, client_id: str) -> dict:
        """Signature + audience + expiry check with the IdP's JWKS (PyJWT when installed; otherwise the token is
        trusted only because it was just received over TLS from the token endpoint, which is acceptable for the
        code flow but PyJWT is recommended)."""
        try:
            import jwt
            from jwt import PyJWKClient
            key = PyJWKClient(meta["jwks_uri"]).get_signing_key_from_jwt(id_token).key
            return jwt.decode(id_token, key, algorithms=["RS256", "ES256"], audience=client_id, options={"verify_exp": True})
        except ImportError:
            payload = id_token.split(".")[1]
            payload += "=" * (-len(payload) % 4)
            claims = json.loads(base64.urlsafe_b64decode(payload))
            if claims.get("aud") not in (client_id, [client_id]) or claims.get("exp", 0) < time.time():
                raise ValueError("id_token audience / expiry check failed")
            return claims


class Vault:
    """Per-user secrets entered in the UI (git tokens, Greenplum passwords): memory only, gone on restart."""

    def __init__(self):
        self._d = {}
        self._lock = threading.Lock()

    def set(self, user: str, key: str, value: str) -> None:
        with self._lock:
            self._d.setdefault(user, {})[key] = value

    def get(self, user: str, key: str) -> Optional[str]:
        with self._lock:
            return (self._d.get(user) or {}).get(key)

    def keys(self, user: str) -> list:
        with self._lock:
            return sorted(self._d.get(user, {}))

    def clear(self, user: str) -> None:
        with self._lock:
            self._d.pop(user, None)
