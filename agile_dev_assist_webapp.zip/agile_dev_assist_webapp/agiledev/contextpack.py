"""Context pack: the ONE standard JSON every agent reads. Built deterministically from the session inputs with
character budgets per section, so the model sees the story, the relevant knowledge and the relevant existing code
and nothing else. Saved as pack.json in the chat folder."""
from __future__ import annotations

import json
from pathlib import Path
from typing import List, Optional

from .greenplum import table_text
from .inputs import SessionInputs


def _fit(parts: List[str], budget: int) -> str:
    out, used = [], 0
    for p in parts:
        if used + len(p) > budget:
            room = budget - used
            if room > 400:
                out.append(p[:room] + "\n...[truncated]")
            break
        out.append(p)
        used += len(p) + 2
    return "\n\n".join(out)


def docs_text(docs: List[dict], budget: int) -> str:
    parts = []
    for d in docs:
        head = f"==== {d['name']} ({d['format']}) ===="
        if d.get("data") is not None and d["format"] in ("yml", "yaml", "json"):
            body = json.dumps(d["data"], ensure_ascii=False, indent=1, default=str)[:60000]
        else:
            body = d.get("text", "")
        parts.append(head + "\n" + body)
    return _fit(parts, budget)


def build_pack(inputs: SessionInputs, cfg, query_hint: str = "", plan: Optional[dict] = None) -> dict:
    c = cfg.get("context", {})
    story = inputs.story or {"id": "", "title": "", "text": "", "acceptance_criteria": [], "code_blocks": []}
    st = dict(story)
    st["text"] = st.get("text", "")[: int(c.get("story_chars", 20000))]
    # relevant files: story + plan + hint drive the retrieval over every repository
    query = " ".join([story.get("title", ""), story.get("text", "")[:6000], query_hint,
                      " ".join(f.get("path", "") + " " + f.get("purpose", "") for f in (plan or {}).get("files", []))])
    repos, rel_budget = [], int(c.get("repo_chars", 80000))
    per_file = int(c.get("file_excerpt_chars", 12000))
    k = int(c.get("relevant_files", 12))
    for idx in inputs.indexes():
        hits = idx.search(query, k=k)
        files, used = [], 0
        for h in hits:
            if used >= rel_budget // max(1, len(inputs.repos)):
                break
            txt = idx.read(h["path"], per_file)
            files.append({"path": h["path"], "language": h["language"], "score": h["score"], "content": txt})
            used += len(txt)
        repos.append({"name": idx.name, "summary": idx.summary(), "relevant_files": files,
                      "branch": next((r["branch"] for r in inputs.repos if r["name"] == idx.name), ""),
                      "url": next((r["url"] for r in inputs.repos if r["name"] == idx.name), "")})
    tables = _fit([table_text(t) for t in inputs.tables] +
                  [f"### query {q['name']}\n{q['sql']}\n" + " | ".join(q["columns"]) + "\n" +
                   "\n".join(" | ".join(str(x)[:60] for x in r) for r in q["rows"][:20]) for q in inputs.queries],
                  int(c.get("tables_chars", 40000)))
    pack = {
        "story": st,
        "instructions": inputs.instructions,
        "skills": docs_text(inputs.docs["skills"], int(c.get("skills_chars", 60000))),
        "glossary": docs_text(inputs.docs["glossary"], int(c.get("glossary_chars", 40000))),
        "standards": docs_text(inputs.docs["standards"], int(c.get("standards_chars", 40000))),
        "tables": tables,
        "table_catalog": [{"schema": t["schema"], "table": t["table"], "columns": [x["name"] for x in t["columns"]],
                           "keys": t.get("keys", [])} for t in inputs.tables],
        "repos": repos,
        "inventory": {"skills": [d["name"] for d in inputs.docs["skills"]], "glossary": [d["name"] for d in inputs.docs["glossary"]],
                      "standards": [d["name"] for d in inputs.docs["standards"]], "tables": len(inputs.tables),
                      "queries": len(inputs.queries), "repos": [r["name"] for r in inputs.repos]},
    }
    pack["chars"] = {k: (len(v) if isinstance(v, str) else len(json.dumps(v, default=str))) for k, v in pack.items() if k != "chars"}
    return pack


def save_pack(pack: dict, folder: Path) -> Path:
    p = Path(folder) / "pack.json"
    p.write_text(json.dumps(pack, ensure_ascii=False, indent=1, default=str), encoding="utf-8")
    return p
