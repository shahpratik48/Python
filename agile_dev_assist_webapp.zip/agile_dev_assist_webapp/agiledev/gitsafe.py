"""Git 'dubious ownership' fix for hosted runs (Azure App Service, containers).

Git refuses to work in a repository whose folder is owned by another OS user than the process
("fatal: detected dubious ownership in repository"). That happens when the persistent data mount was
created by a different uid than the one the web app runs as. `safe.directory` - the setting that allows
it - is only read from the SYSTEM or GLOBAL git config (git ignores it in `-c` options and repo config).

So every git command of the app gets GIT_CONFIG_GLOBAL = a small config file the app owns that trusts its
own folders and includes the machine's normal global config (proxy / SSL settings stay in effect).
Git older than 2.32 does not know GIT_CONFIG_GLOBAL: then the entry is added to the real global config once.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import threading
from pathlib import Path
from typing import Dict

_lock = threading.Lock()
_done: Dict[str, str] = {}


def _git_version(git: str) -> tuple:
    try:
        out = subprocess.run([git, "--version"], capture_output=True, text=True, timeout=20).stdout
        m = re.search(r"(\d+)\.(\d+)", out)
        return (int(m.group(1)), int(m.group(2))) if m else (0, 0)
    except Exception:  # noqa: BLE001
        return (0, 0)


def safe_env(env: dict, base_dir) -> dict:
    """Adds what git needs to trust the app's own folders to `env` (in place) and returns it."""
    git = shutil.which("git") or "git"
    base = str(Path(base_dir).resolve())
    with _lock:
        cfg = _done.get(base)
        if cfg is None:
            if _git_version(git) >= (2, 32):
                Path(base).mkdir(parents=True, exist_ok=True)
                p = Path(base) / ".gitconfig_app"
                home_cfg = Path(os.path.expanduser("~")) / ".gitconfig"
                body = "[safe]\n\tdirectory = *\n"
                if home_cfg.exists():
                    body = f"[include]\n\tpath = {home_cfg.as_posix()}\n" + body
                try:
                    if not p.exists() or p.read_text(encoding="utf-8") != body:
                        p.write_text(body, encoding="utf-8")
                    cfg = str(p)
                except OSError:
                    cfg = ""
            else:
                cfg = ""
            if not cfg:                     # old git or read-only folder: add it to the real global config once
                try:
                    have = subprocess.run([git, "config", "--global", "--get-all", "safe.directory"], capture_output=True, text=True, timeout=20).stdout.split()
                    if "*" not in have:
                        subprocess.run([git, "config", "--global", "--add", "safe.directory", "*"], capture_output=True, timeout=20)
                except Exception:  # noqa: BLE001
                    pass
            _done[base] = cfg
    if cfg:
        env["GIT_CONFIG_GLOBAL"] = cfg
    return env
