"""Azure OpenAI (GPT-5) client: tool-calling chat, JSON calls, disk cache, adaptive rate limiting and token
accounting per agent (process) and in total."""
from __future__ import annotations

import hashlib
import json
import logging
import random
import threading
import time
from pathlib import Path
from typing import Optional

from .config import Config, get_secret, ssl_verify

log = logging.getLogger(__name__)


class RateLimiter:
    """At most `max_inflight` concurrent requests; halves on 429 and honours Retry-After; optional
    tokens-per-minute pacing (requests wait until their estimated size fits the rolling minute)."""

    def __init__(self, max_inflight: int, tokens_per_minute: int = 0):
        self.max_inflight = max(1, max_inflight)
        self.limit = self.max_inflight
        self.inflight = 0
        self.pause_until = 0.0
        self.successes = 0
        self.tpm = int(tokens_per_minute or 0)
        self.window = []
        self.cv = threading.Condition()
        self.hits_429 = 0
        self.last_reduce = 0.0

    def acquire(self, est_tokens: int = 0):
        with self.cv:
            while True:
                now = time.time()
                wait = self.pause_until - now
                if wait > 0:
                    self.cv.wait(min(wait, 5))
                    continue
                if self.inflight >= self.limit:
                    self.cv.wait(2)
                    continue
                self.window = [(t, n) for t, n in self.window if now - t < 60]
                if self.tpm:
                    used = sum(n for _, n in self.window)
                    if used + est_tokens > self.tpm and self.window:
                        self.cv.wait(min(5, 60 - (now - self.window[0][0]) + 0.1))
                        continue
                self.window.append((now, est_tokens))
                self.inflight += 1
                return

    def release(self, ok: bool, retry_after: float = 0.0):
        with self.cv:
            self.inflight -= 1
            if ok:
                self.successes += 1
                if self.successes >= 10 and self.limit < self.max_inflight:
                    self.limit += 1
                    self.successes = 0
            else:
                self.hits_429 += 1
                self.successes = 0
                now = time.time()
                if now - self.last_reduce > 8:
                    self.limit = max(1, self.limit // 2)
                    self.last_reduce = now
                    used = sum(n for t, n in self.window if now - t < 60)
                    if used and not self.tpm:
                        self.tpm = max(20000, int(used * 0.8))
                self.pause_until = max(self.pause_until, now + max(1.0, retry_after))
            self.cv.notify_all()


def _retry_after(exc) -> float:
    for attr in ("response", "http_response"):
        r = getattr(exc, attr, None)
        h = getattr(r, "headers", None)
        if h and h.get("retry-after"):
            try:
                return float(h.get("retry-after"))
            except ValueError:
                pass
    return 0.0


def _is_rate_limit(msg: str) -> bool:
    m = msg.lower()
    return "429" in m or "rate limit" in m or "ratelimit" in m or "too many requests" in m


EMPTY = {"calls": 0, "cache_hits": 0, "prompt_tokens": 0, "completion_tokens": 0, "reasoning_tokens": 0,
         "cached_tokens": 0, "total_tokens": 0, "seconds_in_calls": 0.0, "rate_limit_hits": 0}


class LLM:
    def __init__(self, cfg: Config, cache_dir: Path, client=None):
        self.cfg = cfg
        self.c = cfg.llm
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self._client = client
        self.extra = {"reasoning_effort": self.c["reasoning_effort"]} if self.c.get("reasoning_effort") else {}
        self.json_mode = True
        self.usage = dict(EMPTY)
        self.usage_by = {}
        self._local = threading.local()
        self._lock = threading.Lock()
        self.limiter = RateLimiter(int(self.c.get("parallel_calls", 6)), int(self.c.get("tokens_per_minute", 0) or 0))
        self.rate_limit_max_wait = float(self.c.get("rate_limit_max_wait_seconds", 240))

    # ------------------------------------------------------------------ process accounting
    def set_process(self, name: str) -> None:
        self._local.process = name

    @property
    def process(self) -> str:
        return getattr(self._local, "process", "other")

    def _account(self, r, seconds: float) -> None:
        u = getattr(r, "usage", None)
        with self._lock:
            for bucket in (self.usage, self.usage_by.setdefault(self.process, dict(EMPTY))):
                bucket["calls"] += 1
                bucket["seconds_in_calls"] += seconds
                if u:
                    pt = getattr(u, "prompt_tokens", 0) or 0
                    ct = getattr(u, "completion_tokens", 0) or 0
                    d = getattr(u, "prompt_tokens_details", None)
                    cd = getattr(u, "completion_tokens_details", None)
                    bucket["prompt_tokens"] += pt
                    bucket["completion_tokens"] += ct
                    bucket["total_tokens"] += (getattr(u, "total_tokens", 0) or (pt + ct))
                    bucket["cached_tokens"] += (getattr(d, "cached_tokens", 0) or 0) if d else 0
                    bucket["reasoning_tokens"] += (getattr(cd, "reasoning_tokens", 0) or 0) if cd else 0

    def count_cache_hit(self) -> None:
        with self._lock:
            self.usage["cache_hits"] += 1
            self.usage_by.setdefault(self.process, dict(EMPTY))["cache_hits"] += 1

    def token_stats(self) -> dict:
        with self._lock:
            tot = dict(self.usage)
            tot["rate_limit_hits"] = self.limiter.hits_429
            by = {k: dict(v) for k, v in self.usage_by.items()}
        for b in [tot] + list(by.values()):
            b["avg_tokens_per_call"] = round(b["total_tokens"] / b["calls"]) if b["calls"] else 0
            b["seconds_in_calls"] = round(b["seconds_in_calls"], 1)
        return {"total": tot, "by_agent": by}

    def token_stats_text(self) -> str:
        s = self.token_stats()
        lines = ["TOKEN STATISTICS", "=" * 60]
        for k, v in s["total"].items():
            lines.append(f"  {k:24s} {v}")
        lines.append("")
        lines.append(f"{'agent':20s} {'calls':>6s} {'cache':>6s} {'prompt':>10s} {'completion':>11s} {'reasoning':>10s} {'total':>10s} {'secs':>7s}")
        for k, v in sorted(s["by_agent"].items(), key=lambda kv: -kv[1]["total_tokens"]):
            lines.append(f"{k:20s} {v['calls']:6d} {v['cache_hits']:6d} {v['prompt_tokens']:10d} {v['completion_tokens']:11d} "
                         f"{v['reasoning_tokens']:10d} {v['total_tokens']:10d} {v['seconds_in_calls']:7.1f}")
        return "\n".join(lines)

    # ------------------------------------------------------------------ client
    @property
    def client(self):
        if self._client is None:
            from openai import AzureOpenAI
            kw = {}
            verify = ssl_verify(self.c.get("ssl_verify", True))
            if verify is not True:
                try:
                    import httpx
                except ImportError:
                    import httpx2 as httpx
                kw["http_client"] = httpx.Client(verify=verify, timeout=self.c["request_timeout_seconds"])
            self._client = AzureOpenAI(azure_endpoint=self.c["endpoint"], api_version=self.c["api_version"],
                                       api_key=get_secret(self.cfg, "llm_api_key"),
                                       timeout=self.c["request_timeout_seconds"], max_retries=0, **kw)
        return self._client

    def check(self) -> str:
        r = self.client.chat.completions.create(model=self.c["deployment"], max_completion_tokens=2000,
                                                messages=[{"role": "user", "content": "Reply with the single word OK"}], **self.extra)
        return (r.choices[0].message.content or "").strip()

    def _request(self, kw: dict):
        est = sum(len(str(m.get("content", ""))) for m in kw.get("messages", [])) // 4 + 2000
        waited, attempt = 0.0, 0
        while True:
            attempt += 1
            self.limiter.acquire(est)
            t0 = time.time()
            try:
                r = self.client.chat.completions.create(**kw)
                self.limiter.release(True)
                self._account(r, time.time() - t0)
                return r
            except Exception as e:  # noqa: BLE001
                msg = str(e)
                if _is_rate_limit(msg):
                    ra = _retry_after(e) or min(60.0, 5.0 * attempt)
                    self.limiter.release(False, ra)
                    if waited > self.rate_limit_max_wait:
                        raise RuntimeError(f"rate limited for more than {self.rate_limit_max_wait:.0f}s: {msg[:200]}")
                    sleep = ra + random.uniform(0, 2)
                    waited += sleep
                    log.warning("429 rate limit (attempt %d) - waiting %.0fs", attempt, sleep)
                    time.sleep(sleep)
                    continue
                self.limiter.release(True)
                raise

    # ------------------------------------------------------------------ calls
    def chat(self, messages: list, tools: Optional[list] = None, tool_choice="auto", reasoning_effort=None):
        last = None
        for attempt in range(1, int(self.c["max_retries"]) + 1):
            try:
                extra = dict(self.extra)
                if reasoning_effort and extra:
                    extra["reasoning_effort"] = reasoning_effort
                kw = dict(model=self.c["deployment"], messages=messages,
                          max_completion_tokens=int(self.c["max_completion_tokens"]), **extra)
                if tools:
                    kw["tools"] = tools
                    kw["tool_choice"] = tool_choice
                r = self._request(kw)
                return r.choices[0].message
            except Exception as e:  # noqa: BLE001
                msg, last = str(e), e
                if "reasoning_effort" in msg and self.extra:
                    self.extra = {}
                    continue
                if "tool_choice" in msg and tool_choice not in ("auto", None):
                    tool_choice = "auto"
                    continue
                if any(x in msg for x in ("401", "403", "DeploymentNotFound", "invalid subscription key")):
                    raise
                log.warning("LLM chat attempt %d failed: %s", attempt, msg[:300])
                time.sleep(float(self.c["retry_delay_seconds"]) * attempt + random.uniform(0, 2))
        raise RuntimeError(f"LLM chat failed after retries: {last}")

    def json_call(self, system: str, user: str, reasoning_effort=None) -> dict:
        msgs = [{"role": "system", "content": system}, {"role": "user", "content": user}]
        for attempt in range(1, int(self.c["max_retries"]) + 1):
            try:
                extra = dict(self.extra)
                if reasoning_effort and extra:
                    extra["reasoning_effort"] = reasoning_effort
                kw = dict(model=self.c["deployment"], messages=msgs, max_completion_tokens=int(self.c["max_completion_tokens"]), **extra)
                if self.json_mode:
                    kw["response_format"] = {"type": "json_object"}
                r = self._request(kw)
                txt = (r.choices[0].message.content or "").strip()
                if txt.startswith("```"):
                    txt = txt.split("\n", 1)[1].rsplit("```", 1)[0]
                return json.loads(txt)
            except Exception as e:  # noqa: BLE001
                msg = str(e)
                if "response_format" in msg and self.json_mode:
                    self.json_mode = False
                    continue
                if "reasoning_effort" in msg and self.extra:
                    self.extra = {}
                    continue
                log.warning("LLM json attempt %d failed: %s", attempt, msg[:300])
                time.sleep(float(self.c["retry_delay_seconds"]) * attempt)
        raise RuntimeError("LLM json call failed after retries")

    # ------------------------------------------------------------------ agent result cache
    def cache_get(self, key: str):
        f = self.cache_dir / f"agent_{key}.json"
        return json.loads(f.read_text(encoding="utf-8")) if f.exists() else None

    def cache_put(self, key: str, value) -> None:
        try:
            (self.cache_dir / f"agent_{key}.json").write_text(json.dumps(value, ensure_ascii=False, indent=1, default=str), encoding="utf-8")
        except Exception as e:  # noqa: BLE001
            log.debug("cache write failed: %s", e)

    @staticmethod
    def hash(*parts) -> str:
        h = hashlib.sha256()
        for p in parts:
            h.update(json.dumps(p, sort_keys=True, ensure_ascii=False, default=str).encode())
        return h.hexdigest()[:40]
