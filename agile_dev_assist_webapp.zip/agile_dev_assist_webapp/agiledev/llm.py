"""Azure OpenAI (GPT-5) client: tool-calling chat, JSON calls, disk cache, adaptive rate limiting and token
accounting per agent (process) and in total."""
from __future__ import annotations

import hashlib
import json
import os
import logging
import random
import threading
import time
from pathlib import Path
from typing import Optional

from .config import fmt_secs, Config, get_secret, ssl_verify

log = logging.getLogger(__name__)


class RateLimiter:
    """At most `max_inflight` concurrent requests; halves on 429 and honours Retry-After; optional
    tokens-per-minute pacing (requests wait until their estimated size fits the rolling minute)."""

    def __init__(self, max_inflight: int, tokens_per_minute: int = 0):
        self.max_inflight = max(1, max_inflight)
        self.limit = self.max_inflight
        self.inflight = 0
        self.pause_until = 0.0
        self.successes = 0
        self.tpm = int(tokens_per_minute or 0)
        self.window = []
        self.cv = threading.Condition()
        self.hits_429 = 0
        self.last_reduce = 0.0

    def acquire(self, est_tokens: int = 0):
        with self.cv:
            while True:
                now = time.time()
                wait = self.pause_until - now
                if wait > 0:
                    self.cv.wait(min(wait, 5))
                    continue
                if self.inflight >= self.limit:
                    self.cv.wait(2)
                    continue
                self.window = [(t, n) for t, n in self.window if now - t < 60]
                if self.tpm:
                    used = sum(n for _, n in self.window)
                    if used + est_tokens > self.tpm and self.window:
                        self.cv.wait(min(5, 60 - (now - self.window[0][0]) + 0.1))
                        continue
                self.window.append((now, est_tokens))
                self.inflight += 1
                return

    def release(self, ok: bool, retry_after: float = 0.0):
        with self.cv:
            self.inflight -= 1
            if ok:
                self.successes += 1
                if self.successes >= 10 and self.limit < self.max_inflight:
                    self.limit += 1
                    self.successes = 0
            else:
                self.hits_429 += 1
                self.successes = 0
                now = time.time()
                if now - self.last_reduce > 8:
                    self.limit = max(1, self.limit // 2)
                    self.last_reduce = now
                    used = sum(n for t, n in self.window if now - t < 60)
                    if used and not self.tpm:
                        self.tpm = max(20000, int(used * 0.8))
                self.pause_until = max(self.pause_until, now + max(1.0, retry_after))
            self.cv.notify_all()


def _retry_after(exc) -> float:
    for attr in ("response", "http_response"):
        r = getattr(exc, attr, None)
        h = getattr(r, "headers", None)
        if h and h.get("retry-after"):
            try:
                return float(h.get("retry-after"))
            except ValueError:
                pass
    return 0.0


def _is_rate_limit(msg: str) -> bool:
    m = msg.lower()
    return "429" in m or "rate limit" in m or "ratelimit" in m or "too many requests" in m


EMPTY = {"calls": 0, "cache_hits": 0, "prompt_tokens": 0, "completion_tokens": 0, "reasoning_tokens": 0,
         "cached_tokens": 0, "total_tokens": 0, "seconds_in_calls": 0.0, "rate_limit_hits": 0}


class LLM:
    def __init__(self, cfg: Config, cache_dir: Path, client=None):
        self.cfg = cfg
        self.c = cfg.llm
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self._client = client
        self.extra = {"reasoning_effort": self.c["reasoning_effort"]} if self.c.get("reasoning_effort") else {}
        # deployments that are NOT reasoning models (gpt-4o-mini, gpt-4.1-*): the reasoning_effort parameter is never sent to them;
        # llm.non_reasoning_deployments in the config, plus any deployment that rejects the parameter at run time
        self._no_reasoning = {str(x) for x in (self.c.get("non_reasoning_deployments") or [])}
        self.json_mode = True
        self.usage = dict(EMPTY)
        self.usage_by = {}
        self.usage_pm = {}            # (process, deployment) -> bucket: costs are computed at each deployment's own price
        # repeatability: a fixed seed on every chat call (best effort on Azure) and temperature 0 for the non-reasoning
        # deployments (gpt-4o-mini); a deployment that rejects either parameter is remembered and not sent it again
        self._no_seed, self._no_temp = set(), set()
        self._local = threading.local()
        self._lock = threading.Lock()
        self.limiter = RateLimiter(int(self.c.get("parallel_calls", 6)), int(self.c.get("tokens_per_minute", 0) or 0))
        self.rate_limit_max_wait = float(self.c.get("rate_limit_max_wait_seconds", 240))

    def child(self) -> "LLM":
        """A per-run view of this client: SAME Azure client, rate limiters, result cache and learned deployment quirks, but its
        OWN token counters - so the Tokens tab of a run shows that run only, not the server's running total across every
        user and chat (the server holds one LLM for everybody)."""
        import copy
        root = getattr(self, "_root", None) or self
        c = copy.copy(root)
        c._root = root
        c.usage, c.usage_by, c.usage_pm = dict(EMPTY), {}, {}
        c._lock, c._local = threading.Lock(), threading.local()
        return c

    @property
    def _shared(self):
        return getattr(self, "_root", None) or self

    # ------------------------------------------------------------------ process accounting
    def set_process(self, name: str) -> None:
        self._local.process = name

    @property
    def process(self) -> str:
        return getattr(self._local, "process", "other")

    def _account(self, r, seconds: float, deployment: str = "") -> None:
        u = getattr(r, "usage", None)
        dep = deployment or getattr(r, "model", "") or self.c.get("deployment", "")
        with self._lock:
            for bucket in (self.usage, self.usage_by.setdefault(self.process, dict(EMPTY)), self.usage_pm.setdefault((self.process, dep), dict(EMPTY))):
                bucket["calls"] += 1
                bucket["seconds_in_calls"] += seconds
                if u:
                    pt = getattr(u, "prompt_tokens", 0) or 0
                    ct = getattr(u, "completion_tokens", 0) or 0
                    d = getattr(u, "prompt_tokens_details", None)
                    cd = getattr(u, "completion_tokens_details", None)
                    bucket["prompt_tokens"] += pt
                    bucket["completion_tokens"] += ct
                    bucket["total_tokens"] += (getattr(u, "total_tokens", 0) or (pt + ct))
                    bucket["cached_tokens"] += (getattr(d, "cached_tokens", 0) or 0) if d else 0
                    bucket["reasoning_tokens"] += (getattr(cd, "reasoning_tokens", 0) or 0) if cd else 0

    def count_cache_hit(self) -> None:
        with self._lock:
            self.usage["cache_hits"] += 1
            self.usage_by.setdefault(self.process, dict(EMPTY))["cache_hits"] += 1

    def pricing(self) -> dict:
        """USD per 1M tokens: llm.pricing_per_1m in the config (defaults = GPT-5 list prices: input 1.25, cached input 0.125, output 10)."""
        pr = dict(self.c.get("pricing_per_1m") or {}) if hasattr(self.c, "get") else {}
        return {"input": float(pr.get("input", 1.25)), "cached_input": float(pr.get("cached_input", 0.125)), "output": float(pr.get("output", 10.0)),
                "embedding": float(pr.get("embedding", 0.02)),
                "currency": str(pr.get("currency", "USD")), "note": str(pr.get("note", "GPT-5 list prices; edit llm.pricing_per_1m to match your Azure contract"))}

    def model_pricing(self, deployment: str) -> dict:
        """USD per 1M tokens for ONE deployment: llm.pricing_per_1m_by_deployment.<deployment> (gpt-4o-mini is ~8x cheaper than
        gpt-5 - pricing every call at the gpt-5 price overstated the readers' cost), else llm.pricing_per_1m."""
        base = self.pricing()
        by = (self.c.get("pricing_per_1m_by_deployment") or {}) if hasattr(self.c, "get") else {}
        own = by.get(deployment) or {}
        return {"input": float(own.get("input", base["input"])), "cached_input": float(own.get("cached_input", base["cached_input"])),
                "output": float(own.get("output", base["output"])), "embedding": float(own.get("input", base["embedding"])),
                "label": str(own.get("label") or deployment)}

    def _cost(self, b: dict, process: str = "", deployment: str = "") -> dict:
        pr = self.model_pricing(deployment) if deployment else self.pricing()
        if process == "embeddings":
            n = int(b.get("prompt_tokens", 0) or 0)
            c = n * pr["embedding"] / 1e6
            return {"input_tokens": n, "cached_input_tokens": 0, "output_tokens": 0, "cost_input": round(c, 4), "cost_cached_input": 0.0,
                    "cost_output": 0.0, "cost_usd": round(c, 4)}
        cached = int(b.get("cached_tokens", 0) or 0)
        inp = max(0, int(b.get("prompt_tokens", 0) or 0) - cached)      # prompt_tokens includes the cached part
        out = int(b.get("completion_tokens", 0) or 0)                  # completion includes reasoning tokens
        c_in, c_cached, c_out = inp * pr["input"] / 1e6, cached * pr["cached_input"] / 1e6, out * pr["output"] / 1e6
        return {"input_tokens": inp, "cached_input_tokens": cached, "output_tokens": out,
                "cost_input": round(c_in, 4), "cost_cached_input": round(c_cached, 4), "cost_output": round(c_out, 4),
                "cost_usd": round(c_in + c_cached + c_out, 4)}

    def token_stats(self) -> dict:
        """total / by_agent / by_model. Every cost is the sum over (agent, deployment) at THAT deployment's price, so an agent
        routed to gpt-4o-mini is priced as mini, the planner as gpt-5, embeddings at the embedding price."""
        with self._lock:
            tot = dict(self.usage)
            tot["rate_limit_hits"] = self.limiter.hits_429
            by = {k: dict(v) for k, v in self.usage_by.items()}
            pm = {k: dict(v) for k, v in self.usage_pm.items()}
        cost_keys = ("input_tokens", "cached_input_tokens", "output_tokens", "cost_input", "cost_cached_input", "cost_output", "cost_usd")
        agent_cost, model_rows = {}, {}
        for (proc, dep), b in pm.items():
            c = self._cost(b, "embeddings" if proc == "embeddings" else "", dep)
            a = agent_cost.setdefault(proc, {k: 0 for k in cost_keys})
            m = model_rows.setdefault(dep, dict(EMPTY, **{k: 0 for k in cost_keys}, agents=[], kind="embeddings" if proc == "embeddings" else "chat"))
            for k in cost_keys:
                a[k] += c[k]; m[k] += c[k]
            for k in EMPTY:
                if isinstance(b.get(k), (int, float)):
                    m[k] += b[k]
            if proc not in m["agents"]:
                m["agents"].append(proc)
        for name, b in list(by.items()):
            b["avg_tokens_per_call"] = round(b["total_tokens"] / b["calls"]) if b["calls"] else 0
            b["seconds_in_calls"] = round(b["seconds_in_calls"], 1)
            b.update({k: (round(v, 4) if isinstance(v, float) else v) for k, v in (agent_cost.get(name) or self._cost(b, name)).items()})
            b["deployments"] = sorted({d for (p, d) in pm if p == name})
        for dep, m in model_rows.items():
            for k in ("cost_input", "cost_cached_input", "cost_output", "cost_usd"):
                m[k] = round(m[k], 4)
            m["seconds_in_calls"] = round(m["seconds_in_calls"], 1)
            mp = self.model_pricing(dep)
            m["label"] = mp["label"]
            m["pricing"] = {"input": mp["input"], "cached_input": mp["cached_input"], "output": mp["output"]} if m["kind"] == "chat" else {"input": mp["embedding"]}
        tot["avg_tokens_per_call"] = round(tot["total_tokens"] / tot["calls"]) if tot["calls"] else 0
        tot["seconds_in_calls"] = round(tot["seconds_in_calls"], 1)
        if pm:
            for k in cost_keys:
                tot[k] = sum(m[k] for m in model_rows.values())
            for k in ("cost_input", "cost_cached_input", "cost_output", "cost_usd"):
                tot[k] = round(tot[k], 4)
            if "embeddings" in by:
                tot["embedding_tokens"] = by["embeddings"].get("input_tokens", 0)
        else:
            tot.update(self._cost(tot))
        return {"total": tot, "by_agent": by, "by_model": model_rows, "pricing": self.pricing()}

    def token_stats_text(self) -> str:
        s = self.token_stats()
        t, pr = s["total"], s["pricing"]
        if len(s.get("by_model") or {}) > 1:          # several models: each priced at its own rate - the per-model table below has the rates
            return "\n".join(["TOKEN STATISTICS", "=" * 72,
                               f"  input tokens (uncached)   {t['input_tokens']:>12,}   = ${t['cost_input']:.4f}",
                               f"  cached input tokens       {t['cached_input_tokens']:>12,}   = ${t['cost_cached_input']:.4f}",
                               f"  output tokens (+reasoning){t['output_tokens']:>12,}   = ${t['cost_output']:.4f}",
                               f"  TOTAL                     {t['total_tokens']:>12,}   cost ${t['cost_usd']:.4f} {pr['currency']}   (each model at its own price: llm.pricing_per_1m_by_deployment)",
                               f"  calls {t['calls']}, cache hits {t['cache_hits']}, reasoning tokens {t['reasoning_tokens']}, time in calls {fmt_secs(t['seconds_in_calls'])}, 429s {t.get('rate_limit_hits', 0)}", ""]
                              + self._tables_text(s))
        lines = ["TOKEN STATISTICS", "=" * 72,
                 f"  input tokens (uncached)   {t['input_tokens']:>12,}   x ${pr['input']}/1M   = ${t['cost_input']:.4f}",
                 f"  cached input tokens       {t['cached_input_tokens']:>12,}   x ${pr['cached_input']}/1M = ${t['cost_cached_input']:.4f}",
                 f"  output tokens (+reasoning){t['output_tokens']:>12,}   x ${pr['output']}/1M  = ${t['cost_output']:.4f}",
                 f"  TOTAL                     {t['total_tokens']:>12,}   cost ${t['cost_usd']:.4f} {pr['currency']}   ({pr['note']})",
                 f"  calls {t['calls']}, cache hits {t['cache_hits']}, reasoning tokens {t['reasoning_tokens']}, time in calls {fmt_secs(t['seconds_in_calls'])}, 429s {t.get('rate_limit_hits', 0)}", ""]
        return "\n".join(lines + self._tables_text(s))

    def _tables_text(self, s: dict) -> list:
        lines = [f"{'agent':18s} {'calls':>5s} {'input':>10s} {'cached':>10s} {'output':>9s} {'total':>10s} {'cost $':>9s} {'time':>16s}"]
        for k, v in sorted(s["by_agent"].items(), key=lambda kv: -kv[1]["total_tokens"]):
            lines.append(f"{k:18s} {v['calls']:5d} {v['input_tokens']:10,d} {v['cached_input_tokens']:10,d} {v['output_tokens']:9,d} {v['total_tokens']:10,d} {v['cost_usd']:9.4f} {fmt_secs(v['seconds_in_calls']):>16s}")
        if s.get("by_model"):
            lines += ["", f"{'model (deployment)':24s} {'calls':>5s} {'input':>10s} {'cached':>10s} {'output':>9s} {'cost $':>9s}  agents"]
            for dep, m in sorted(s["by_model"].items(), key=lambda kv: -kv[1]["cost_usd"]):
                lines.append(f"{dep[:24]:24s} {m['calls']:5d} {m['input_tokens']:10,d} {m['cached_input_tokens']:10,d} {m['output_tokens']:9,d} {m['cost_usd']:9.4f}  {', '.join(m['agents'])}")
        return lines

    # ------------------------------------------------------------------ client
    @property
    def client(self):
        root = getattr(self, "_root", None)
        if root is not None and root is not self:
            return root.client                      # one Azure client (connection pool) for the whole server
        if self._client is None:
            from openai import AzureOpenAI
            kw = {}
            verify = ssl_verify(self.c.get("ssl_verify", True))
            if verify is not True:
                try:
                    import httpx
                except ImportError:
                    import httpx2 as httpx
                kw["http_client"] = httpx.Client(verify=verify, timeout=self.c["request_timeout_seconds"])
            self._client = AzureOpenAI(azure_endpoint=self.c["endpoint"], api_version=self.c["api_version"],
                                       api_key=get_secret(self.cfg, "llm_api_key"),
                                       timeout=self.c["request_timeout_seconds"], max_retries=0, **kw)
        return self._client

    def check(self) -> str:
        r = self.client.chat.completions.create(model=self.c["deployment"], max_completion_tokens=2000,
                                                messages=[{"role": "user", "content": "Reply with the single word OK"}], **self.extra)
        return (r.choices[0].message.content or "").strip()

    def _request(self, kw: dict):
        est = sum(len(str(m.get("content", ""))) for m in kw.get("messages", [])) // 4 + 2000
        waited, attempt = 0.0, 0
        while True:
            attempt += 1
            self.limiter.acquire(est)
            t0 = time.time()
            try:
                r = self.client.chat.completions.create(**kw)
                self.limiter.release(True)
                self._account(r, time.time() - t0, kw.get("model", ""))
                return r
            except Exception as e:  # noqa: BLE001
                msg = str(e)
                if _is_rate_limit(msg):
                    ra = _retry_after(e) or min(60.0, 5.0 * attempt)
                    self.limiter.release(False, ra)
                    if waited > self.rate_limit_max_wait:
                        raise RuntimeError(f"rate limited for more than {self.rate_limit_max_wait:.0f}s: {msg[:200]}")
                    sleep = ra + random.uniform(0, 2)
                    waited += sleep
                    log.warning("429 rate limit (attempt %d) - waiting %.0fs", attempt, sleep)
                    time.sleep(sleep)
                    continue
                self.limiter.release(True)
                raise

    # ------------------------------------------------------------------ repeatability
    def _repeatable(self, kw: dict, dep: str) -> None:
        """llm.seed (same inputs -> as far as Azure allows the same answer) and, for non-reasoning deployments, temperature 0.
        Reasoning models (gpt-5) accept only the default temperature, so it is never sent to them."""
        seed = self.c.get("seed")
        if seed not in (None, "", False) and dep not in self._no_seed:
            kw["seed"] = int(seed)
        t = self.c.get("temperature_non_reasoning")
        if t not in (None, "") and dep in self._no_reasoning and dep not in self._no_temp:
            kw["temperature"] = float(t)

    def _drop_rejected(self, msg: str, dep: str) -> bool:
        low = msg.lower()
        if "seed" in low and ("unsupported" in low or "unrecognized" in low or "not supported" in low or "invalid" in low) and dep not in self._no_seed:
            self._no_seed.add(dep); log.info("deployment %s does not accept seed - not sent to it any more", dep); return True
        if "temperature" in low and dep not in self._no_temp:
            self._no_temp.add(dep); log.info("deployment %s does not accept temperature - not sent to it any more", dep); return True
        return False

    # ------------------------------------------------------------------ calls
    def deployment_for(self, process: str = "") -> str:
        """agents.deployment.<agent> (e.g. a cheaper model for the readers or the coder's fix mode) else llm.deployment."""
        by = (self.cfg.get("agents") or {}).get("deployment") or {}
        return str(by.get(process or self.process) or self.c["deployment"])

    def chat(self, messages: list, tools: Optional[list] = None, tool_choice="auto", reasoning_effort=None, model: str = ""):
        last = None
        for attempt in range(1, int(self.c["max_retries"]) + 1):
            try:
                dep = model or self.deployment_for()
                extra = dict(self.extra)
                if reasoning_effort and extra:
                    extra["reasoning_effort"] = reasoning_effort
                if (reasoning_effort == "none" or dep in self._no_reasoning) and "reasoning_effort" in extra:
                    extra.pop("reasoning_effort")                 # non-reasoning deployments reject the parameter
                clean = [{k: v for k, v in m.items() if not k.startswith("_")} for m in messages]   # drop bookkeeping keys
                kw = dict(model=dep, messages=clean,
                          max_completion_tokens=int(self.c["max_completion_tokens"]), **extra)
                self._repeatable(kw, dep)
                if tools:
                    kw["tools"] = tools
                    kw["tool_choice"] = tool_choice
                r = self._request(kw)
                return r.choices[0].message
            except Exception as e:  # noqa: BLE001
                msg, last = str(e), e
                if "reasoning_effort" in msg and self.extra and dep not in self._no_reasoning:
                    self._no_reasoning.add(dep)                   # remember PER DEPLOYMENT: the gpt-5 calls keep their reasoning
                    log.info("deployment %s does not accept reasoning_effort - not sent to it any more", dep)
                    continue
                if self._drop_rejected(msg, dep):
                    continue
                if "tool_choice" in msg and tool_choice not in ("auto", None):
                    tool_choice = "auto"
                    continue
                if any(x in msg for x in ("401", "403", "DeploymentNotFound", "invalid subscription key")):
                    raise
                log.warning("LLM chat attempt %d failed: %s", attempt, msg[:300])
                time.sleep(float(self.c["retry_delay_seconds"]) * attempt + random.uniform(0, 2))
        raise RuntimeError(f"LLM chat failed after retries: {last}")

    def json_call(self, system: str, user: str, reasoning_effort=None) -> dict:
        msgs = [{"role": "system", "content": system}, {"role": "user", "content": user}]
        for attempt in range(1, int(self.c["max_retries"]) + 1):
            try:
                dep = self.deployment_for()
                extra = dict(self.extra)
                if reasoning_effort and extra:
                    extra["reasoning_effort"] = reasoning_effort
                if dep in self._no_reasoning and "reasoning_effort" in extra:
                    extra.pop("reasoning_effort")
                kw = dict(model=dep, messages=msgs, max_completion_tokens=int(self.c["max_completion_tokens"]), **extra)
                self._repeatable(kw, dep)
                if self.json_mode:
                    kw["response_format"] = {"type": "json_object"}
                r = self._request(kw)
                txt = (r.choices[0].message.content or "").strip()
                if txt.startswith("```"):
                    txt = txt.split("\n", 1)[1].rsplit("```", 1)[0]
                return json.loads(txt)
            except Exception as e:  # noqa: BLE001
                msg = str(e)
                if self._drop_rejected(msg, dep):
                    continue
                if "response_format" in msg and self.json_mode:
                    self.json_mode = False
                    continue
                if "reasoning_effort" in msg and self.extra and dep not in self._no_reasoning:
                    self._no_reasoning.add(dep)
                    continue
                log.warning("LLM json attempt %d failed: %s", attempt, msg[:300])
                time.sleep(float(self.c["retry_delay_seconds"]) * attempt)
        raise RuntimeError("LLM json call failed after retries")

    # ------------------------------------------------------------------ agent result cache
    # ------------------------------------------------------------------ embeddings (optional second retriever, semantic.py)
    _emb_client = None
    _emb_limiter = None

    def embed(self, texts: list, s: dict) -> list:
        """Embed texts with the Azure OpenAI embeddings deployment (embeddings.* in the config). Same endpoint and key as the
        chat model unless embeddings.endpoint / the AGILEDEV_AZURE_EMBEDDINGS_API_KEY variable are set. Token usage is
        accounted under the process 'embeddings' (cost at pricing_per_1m.embedding, default $0.02 / 1M)."""
        if not texts:
            return []
        sh = self._shared
        if sh is not self and sh._emb_client is not None:
            self._emb_client, self._emb_limiter = sh._emb_client, sh._emb_limiter
        if self._emb_client is None:
            from openai import AzureOpenAI
            # the embeddings deployment may live on ANOTHER Azure resource with its own key: secret "embeddings_api_key"
            # (env var named in secrets:, Airflow Variable, or the notebook prompt); when not set, the chat key is used
            key = (get_secret(self.cfg, "embeddings_api_key", allow_prompt=False, required=False)
                   or os.environ.get("AGILEDEV_AZURE_EMBEDDINGS_API_KEY", "") or get_secret(self.cfg, "llm_api_key"))
            self._emb_client = AzureOpenAI(azure_endpoint=s.get("endpoint") or self.c["endpoint"], api_version=s.get("api_version") or self.c["api_version"],
                                           api_key=key, timeout=self.c["request_timeout_seconds"], max_retries=0)
        kw = {"model": s["deployment"], "input": [t[:8000] for t in texts]}
        if s.get("dimensions") and "3" in str(s["deployment"]):
            kw["dimensions"] = int(s["dimensions"])
        # the embeddings deployment has its OWN quota: a separate limiter (embeddings.parallel / tokens_per_minute), shared by
        # every pack built in this process; 429 -> honour Retry-After, halve the concurrency, retry up to rate_limit_max_wait
        if self._emb_limiter is None:
            self._emb_limiter = RateLimiter(int(s.get("parallel", 2) or 2), int(s.get("tokens_per_minute", 0) or 0))
        if sh is not self and sh._emb_client is None:
            sh._emb_client, sh._emb_limiter = self._emb_client, self._emb_limiter    # the next run's child reuses them (one quota)
        est = sum(len(t[:8000]) for t in texts) // 4 + 50
        prev = self.process
        self.set_process("embeddings")
        waited, attempt = 0.0, 0
        try:
            while True:
                attempt += 1
                self._emb_limiter.acquire(est)
                t0 = time.time()
                try:
                    r = self._emb_client.embeddings.create(**kw)
                    r_dep = kw.get("model", "")
                    self._emb_limiter.release(True)
                    self._account(r, time.time() - t0, r_dep)
                    return [d.embedding for d in sorted(r.data, key=lambda d: d.index)]
                except Exception as e:  # noqa: BLE001
                    msg = str(e)
                    if _is_rate_limit(msg):
                        ra = _retry_after(e) or min(30.0, 3.0 * attempt)
                        self._emb_limiter.release(False, ra)
                        if waited > float(s.get("rate_limit_max_wait_seconds", 180)):
                            raise RuntimeError(f"embeddings rate limited for more than {s.get('rate_limit_max_wait_seconds', 180)}s: {msg[:160]}")
                        sleep = ra + random.uniform(0, 1)
                        waited += sleep
                        log.warning("embeddings 429 (attempt %d) - waiting %.0fs", attempt, sleep)
                        time.sleep(sleep)
                        continue
                    self._emb_limiter.release(True)
                    raise
        finally:
            self.set_process(prev)

    def cache_get(self, key: str):
        f = self.cache_dir / f"agent_{key}.json"
        return json.loads(f.read_text(encoding="utf-8")) if f.exists() else None

    def cache_put(self, key: str, value) -> None:
        try:
            (self.cache_dir / f"agent_{key}.json").write_text(json.dumps(value, ensure_ascii=False, indent=1, default=str), encoding="utf-8")
        except Exception as e:  # noqa: BLE001
            log.debug("cache write failed: %s", e)

    @staticmethod
    def hash(*parts) -> str:
        h = hashlib.sha256()
        for p in parts:
            h.update(json.dumps(p, sort_keys=True, ensure_ascii=False, default=str).encode())
        return h.hexdigest()[:40]
