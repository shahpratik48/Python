"""One button in the notebook -> the full web UI in a NEW browser window (dev login, no SSO), on this machine.

    from agiledev.notebook_ui import launch
    launch(cfg, llm=llm, port=8780, selftest=SELFTEST)

The server (standard library, no extra packages) runs in a background thread of the kernel. The button is HTML in
the notebook output, so the window opens in YOUR browser - also when JupyterLab runs on a remote server:
  * notebook on your own machine                       -> http://localhost:<port>/
  * JupyterLab / JupyterHub with jupyter-server-proxy  -> <jupyter base>/proxy/<port>/
  * JupyterLab on a server without the proxy           -> http://<that server>:<port>/ (port must be reachable)
"""
from __future__ import annotations

import socket
from typing import Optional

_SERVERS = {}


def _local_cfg(cfg):
    from .config import Config
    c = Config(dict(cfg))
    c["auth"] = dict(cfg.get("auth") or {}, mode="dev", dev_allow_any_user=True)
    c["inputs"] = dict(cfg.get("inputs") or {})
    c["inputs"]["greenplum"] = dict(c["inputs"].get("greenplum") or {}, allow_sqlite=True)   # local test: a sqlite file may play Greenplum
    return c


def start_server(cfg, llm=None, port: int = 8780, selftest: bool = False, host: str = "0.0.0.0", git_read_token: str = ""):
    from .server import serve
    if port in _SERVERS:
        return _SERVERS[port]
    srv = serve(_local_cfg(cfg), host=host, port=port, selftest=selftest, llm=llm, background=True, git_read_token=git_read_token)
    _SERVERS[port] = srv
    return srv


def stop(port: int = 8780):
    s = _SERVERS.pop(port, None)
    if s is not None:
        s.stop()


def launch(cfg, llm=None, port: int = 8780, selftest: bool = False, open_window: bool = True, git_read_token: str = ""):
    """Start the UI (once) and show the button that opens it in a new window.
    git_read_token: read-only token used to read stories / download code for this UI; a push always asks for the user's own."""
    start_server(cfg, llm, port, selftest, git_read_token=git_read_token)
    local = f"http://localhost:{port}/"
    try:
        ip = socket.gethostbyname(socket.gethostname())
    except Exception:  # noqa: BLE001
        ip = socket.gethostname()
    direct = f"http://{ip}:{port}/"
    name = cfg.product.get("name", "Agile Dev Assist")
    html = f"""
<div style="font-family:sans-serif;font-size:14px;line-height:1.6">
  <button id="ada-open-{port}" style="padding:10px 18px;border-radius:10px;border:0;cursor:pointer;font-size:15px;font-weight:600;
          color:#fff;background:linear-gradient(135deg,#7c6cff,#22d3ee);box-shadow:0 4px 14px rgba(124,108,255,.4)">
    🚀 Open {name} in a new window</button>
  <span style="margin-left:12px;color:#666">direct links: <a href="{local}" target="_blank">{local}</a> &middot;
  <a href="{direct}" target="_blank">{direct}</a></span>
  <div style="color:#888;font-size:12px">Sign in with any user id (local dev login). Everything - inputs, agents, tools, chat, panels - works in that window.
  Remote JupyterLab: the button uses the jupyter-server-proxy link; otherwise open http://&lt;server&gt;:{port}/.</div>
</div>
<script>
(function(){{
  const btn = document.getElementById('ada-open-{port}');
  function url(){{
    const p = location.pathname;
    const m = p.match(/^(.*?)\\/(lab|notebooks|tree|voila|doc)(\\/|$)/);
    if (m && location.hostname !== 'localhost' && location.hostname !== '127.0.0.1') return location.origin + m[1] + '/proxy/{port}/';
    if (location.hostname === 'localhost' || location.hostname === '127.0.0.1') return '{local}';
    return 'http://' + location.hostname + ':{port}/';
  }}
  btn.onclick = () => window.open(url(), '_blank', 'noopener,width=1500,height=950');
  if ({'true' if open_window else 'false'}) setTimeout(() => window.open(url(), '_blank', 'noopener,width=1500,height=950'), 400);
}})();
</script>"""
    try:
        from IPython.display import HTML, display
        display(HTML(html))
    except ImportError:
        print(f"{name} UI running: {local} | {direct}")
    print(f"{name} UI is running on port {port}. If no window opened, click the button or use a direct link. stop({port}) stops it.")


# backwards compatible name
launch_button = launch
