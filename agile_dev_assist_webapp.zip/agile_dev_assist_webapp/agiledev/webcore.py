"""Shared HTTP plumbing for the Agile Dev Assist family of apps: a standard-library threaded HTTP server with a small
router, request / response helpers and multipart parsing. Each app creates its own Router and Server."""
from __future__ import annotations

import json
import logging
import mimetypes
import re
import threading
import traceback
from http import cookies as http_cookies
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from urllib.parse import parse_qs, unquote, urlparse

log = logging.getLogger(__name__)


class HTTPError(Exception):
    def __init__(self, code: int, detail: str):
        super().__init__(detail)
        self.code, self.detail = code, detail



def parse_multipart(body: bytes, content_type: str) -> Tuple[Dict[str, str], Dict[str, List[Tuple[str, bytes]]]]:
    """Minimal multipart/form-data parser: fields {name: value}, files {name: [(filename, bytes), ...]}."""
    m = re.search(r'boundary="?([^";]+)"?', content_type)
    if not m:
        raise HTTPError(400, "multipart boundary missing")
    boundary = m.group(1).encode()
    fields, files = {}, {}
    for part in body.split(b"--" + boundary):
        part = part.strip(b"\r\n")
        if not part or part == b"--":
            continue
        if b"\r\n\r\n" not in part:
            continue
        head, data = part.split(b"\r\n\r\n", 1)
        if data.endswith(b"\r\n"):
            data = data[:-2]
        headers = head.decode("utf-8", "replace")
        cd = re.search(r'name="([^"]*)"', headers)
        if not cd:
            continue
        name = cd.group(1)
        fn = re.search(r'filename="([^"]*)"', headers)
        if fn:
            files.setdefault(name, []).append((unquote(Path(fn.group(1).replace("\\", "/")).name), data))
        else:
            fields[name] = data.decode("utf-8", "replace")
    return fields, files


def _page(title: str, body: str) -> str:
    return (f"<!doctype html><html><head><meta charset='utf-8'><title>{title}</title><link rel='stylesheet' href='static/style.css'></head>"
            f"<body class='plain'><div class='card'><h1>{title}</h1><p>{body}</p></div></body></html>")


class Request:
    def __init__(self, handler: "BaseHTTPRequestHandler"):
        self.h = handler
        self.client = (getattr(handler, "client_address", None) or ("",))[0]   # the direct peer (the SSO gateway in header mode)
        u = urlparse(handler.path)
        self.path = u.path
        self.query = {k: v[0] for k, v in parse_qs(u.query).items()}
        self.headers = {k.lower(): v for k, v in handler.headers.items()}
        self.cookies = {}
        if handler.headers.get("Cookie"):
            c = http_cookies.SimpleCookie()
            try:
                c.load(handler.headers.get("Cookie"))
                self.cookies = {k: v.value for k, v in c.items()}
            except Exception:  # noqa: BLE001
                pass
        n = int(handler.headers.get("Content-Length", 0) or 0)
        self.body = handler.rfile.read(n) if n else b""
        self.ctype = handler.headers.get("Content-Type", "")
        self._json = None
        self.fields, self.files = {}, {}
        if self.ctype.startswith("multipart/form-data"):
            self.fields, self.files = parse_multipart(self.body, self.ctype)
        elif self.ctype.startswith("application/x-www-form-urlencoded"):
            self.fields = {k: v[0] for k, v in parse_qs(self.body.decode("utf-8", "replace")).items()}

    def json(self) -> dict:
        if self._json is None:
            try:
                self._json = json.loads(self.body or b"{}") if self.body else {}
            except json.JSONDecodeError:
                raise HTTPError(400, "invalid JSON body")
        return self._json

    def header(self, name: str, default: str = "") -> str:
        return self.headers.get(name.lower(), default)


class Response:
    def __init__(self, code: int = 200, body=b"", ctype: str = "application/json", headers: Optional[list] = None):
        self.code, self.body, self.ctype, self.headers = code, body, ctype, headers or []

    @classmethod
    def json(cls, obj, code: int = 200):
        return cls(code, json.dumps(obj, ensure_ascii=False, default=str).encode("utf-8"))

    @classmethod
    def html(cls, text: str, code: int = 200):
        return cls(code, text.encode("utf-8"), "text/html; charset=utf-8")

    @classmethod
    def text(cls, text: str, code: int = 200):
        return cls(code, text.encode("utf-8"), "text/plain; charset=utf-8")

    @classmethod
    def redirect(cls, url: str, code: int = 303):
        return cls(code, b"", "text/plain", [("Location", url)])

    @classmethod
    def file(cls, path: Path, download_name: str = ""):
        ctype = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        hdr = [("Content-Disposition", f'attachment; filename="{download_name or path.name}"')] if download_name else []
        return cls(200, path.read_bytes(), ctype, hdr)



class Router:
    def __init__(self):
        self.routes: List[Tuple[str, re.Pattern, callable]] = []

    def route(self, method: str, pattern: str):
        def deco(fn):
            self.routes.append((method, re.compile("^" + pattern + "$"), fn))
            return fn
        return deco


# ----------------------------------------------------------------------------- HTTP plumbing
class Handler(BaseHTTPRequestHandler):
    core = None
    router: Router = None
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):      # quiet access log (paths only, never bodies)
        log.debug("%s %s", self.address_string(), fmt % args)

    def _dispatch(self, method: str):
        try:
            r = Request(self)
            for m, rx, fn in self.router.routes:
                if m != method:
                    continue
                mm = rx.match(r.path)
                if mm:
                    resp = fn(self.core, r, **mm.groupdict())
                    break
            else:
                raise HTTPError(404, "not found")
        except HTTPError as e:
            resp = Response.json({"detail": e.detail}, e.code)
        except Exception as e:  # noqa: BLE001
            log.error("request failed: %s\n%s", e, traceback.format_exc())
            resp = Response.json({"detail": f"{type(e).__name__}: {e}"}, 500)
        self.send_response(resp.code)
        self.send_header("Content-Type", resp.ctype)
        self.send_header("Content-Length", str(len(resp.body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in resp.headers:
            self.send_header(k, v)
        self.end_headers()
        if method != "HEAD":
            self.wfile.write(resp.body)

    def do_GET(self):
        self._dispatch("GET")

    def do_POST(self):
        self._dispatch("POST")

    def do_PUT(self):
        self._dispatch("PUT")

    def do_PATCH(self):
        self._dispatch("PATCH")

    def do_DELETE(self):
        self._dispatch("DELETE")

    def do_HEAD(self):
        self._dispatch("HEAD")


class Server:
    def __init__(self, core, host: str, port: int, router: Router, name: str = "web"):
        handler = type("BoundHandler", (Handler,), {"core": core, "router": router})
        self._name = name
        self.httpd = ThreadingHTTPServer((host, port), handler)
        self.httpd.daemon_threads = True
        self.core, self.host, self.port = core, host, port
        self.thread: Optional[threading.Thread] = None

    def run(self):
        try:
            self.httpd.serve_forever()
        except KeyboardInterrupt:
            pass

    def start_background(self):
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True, name=self._name)
        self.thread.start()
        return self

    def stop(self):
        self.httpd.shutdown()
        self.httpd.server_close()


