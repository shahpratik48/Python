"""What every agent shares: config, model client, trace, the context pack, the session inputs, a run clock."""
from __future__ import annotations

import time
from typing import List, Optional

from .base import Trace


class AgentContext:
    def __init__(self, cfg, llm, inputs, pack: dict, trace_sink=None, deadline: Optional[float] = None):
        self.used: List[dict] = []          # every source an agent consulted through a tool: {agent, tool, ref}
        self.cfg = cfg
        self.llm = llm
        self.inputs = inputs
        self.pack = pack
        self.trace = Trace(trace_sink)
        self.deadline = deadline
        self.rules = []                     # regex rules extracted from the standards (knowledge agent)
        self.knowledge = {}                 # knowledge agent result
        self.story = {}                     # story agent result
        self.data = {}                      # data agent result
        self.repo = {}                      # repo agent result
        self.plan = {}
        self.files = {}                     # path -> {content, language, action, purpose}
        self.findings = []
        self.review = {}
        self.semantic = None                # SemanticIndex when embeddings.enabled (second retriever, by meaning)
        self.timings: List[dict] = []       # one row per agent task: agent, task, seconds, steps, fix_rounds, cached

    def reasoning_effort(self, agent: str):
        return ((self.cfg.get("agents") or {}).get("reasoning_effort") or {}).get(agent)

    def max_steps(self, agent: str, default: int, variant: str = "") -> int:
        """agents.max_steps_<agent>_<variant> -> agents.max_steps_<agent> -> agents.max_steps -> default."""
        a = self.cfg.get("agents") or {}
        for key in ([f"max_steps_{agent}_{variant}"] if variant else []) + [f"max_steps_{agent}", "max_steps"]:
            if key in a:
                return int(a[key])
        return int(default)

    def out_of_time(self) -> bool:
        return bool(self.deadline and time.time() > self.deadline)

    def seconds_left(self) -> float:
        return max(0.0, self.deadline - time.time()) if self.deadline else 1e9
