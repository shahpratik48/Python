"""Generic tool-calling agent: system prompt + tools + a JSON result schema that code validates before accepting.
Results are cached by a hash of (agent, prompt, task, tools) so a repeated run costs nothing."""
from __future__ import annotations

import hashlib
import json
import logging
import time
from typing import Any, Callable, Dict, List, Optional

log = logging.getLogger(__name__)
MAX_TOOL_RESULT_CHARS = 40000
S, I, B = {"type": "string"}, {"type": "integer"}, {"type": "boolean"}


class Trace:
    def __init__(self, sink: Optional[Callable[[dict], None]] = None):
        self.rows: List[dict] = []
        self.sink = sink

    def add(self, agent: str, task: str, step: int, kind: str, name: str = "", detail: str = "", ok: bool = True):
        row = {"ts": time.strftime("%H:%M:%S"), "agent": agent, "task": task, "step": step, "kind": kind, "name": name,
               "detail": detail[:500], "ok": ok}
        self.rows.append(row)
        if self.sink:
            try:
                self.sink(row)
            except Exception:  # noqa: BLE001
                pass


class Tool:
    def __init__(self, name: str, description: str, params: dict, fn: Callable):
        self.name, self.description, self.params, self.fn = name, description, params, fn

    def spec(self) -> dict:
        return {"type": "function", "function": {"name": self.name, "description": self.description, "parameters": self.params}}

    def __call__(self, **kw):
        return self.fn(**kw)


def obj(props: Dict[str, dict], required: Optional[List[str]] = None) -> dict:
    return {"type": "object", "properties": props, "required": list(props) if required is None else required,
            "additionalProperties": True}


def arr(items: dict) -> dict:
    return {"type": "array", "items": items}


def validate_schema(data: Any, schema: dict, path: str = "$") -> List[str]:
    errs = []
    t = schema.get("type")
    if t == "object":
        if not isinstance(data, dict):
            return [f"{path}: expected object"]
        for k in schema.get("required", []):
            if k not in data:
                errs.append(f"{path}.{k}: missing")
        for k, sub in schema.get("properties", {}).items():
            if k in data and data[k] is not None:
                errs += validate_schema(data[k], sub, f"{path}.{k}")
    elif t == "array":
        if not isinstance(data, list):
            return [f"{path}: expected array"]
        for i, it in enumerate(data[:500]):
            errs += validate_schema(it, schema.get("items", {}), f"{path}[{i}]")
    elif t == "string" and not isinstance(data, str):
        errs.append(f"{path}: expected string")
    elif t == "integer" and not isinstance(data, int):
        if isinstance(data, float) and data.is_integer():
            return errs
        errs.append(f"{path}: expected integer")
    elif t == "boolean" and not isinstance(data, bool):
        errs.append(f"{path}: expected boolean")
    if "enum" in schema and data not in schema["enum"]:
        errs.append(f"{path}: must be one of {schema['enum']}")
    return errs


class Agent:
    name = "agent"
    max_steps = 8
    max_fix_rounds = 1
    strict = True

    def __init__(self, ctx, tools: List[Tool], output_schema: dict, prompt: str):
        self.ctx = ctx
        self.tools = {t.name: t for t in tools}
        self.output_schema = output_schema
        self.prompt = prompt

    def ground(self, result: dict, task: dict):
        return result, []

    def system_prompt(self) -> str:
        return self.prompt

    def run(self, task: dict, prefix: Optional[str] = None, task_label: str = "", use_cache: bool = True) -> dict:
        label = task_label or self.name
        llm = self.ctx.llm
        if hasattr(llm, "set_process"):
            llm.set_process(self.name)
        key = self._key(task, prefix)
        if use_cache:
            hit = llm.cache_get(key)
            if hit is not None:
                self.ctx.trace.add(self.name, label, 0, "cache", "", "result reused from cache")
                self.ctx.timings.append({"agent": self.name, "task": label, "seconds": 0.0, "steps": 0, "fix_rounds": 0, "cached": True, "issues": 0})
                if hasattr(llm, "count_cache_hit"):
                    llm.count_cache_hit()
                return hit
        submit = Tool("submit_result", "Submit your final result (must match the schema). Call it once you have what you need.",
                      self.output_schema, lambda **k: k)
        specs = [t.spec() for t in self.tools.values()] + [submit.spec()]
        msgs = [{"role": "system", "content": self.system_prompt()}]
        if prefix:
            msgs.append({"role": "user", "content": prefix})
        msgs.append({"role": "user", "content": "TASK:\n" + json.dumps(task, ensure_ascii=False, default=str)})
        fixes, best, t_start = 0, None, time.time()
        effort = self.ctx.reasoning_effort(self.name)
        steps = int(self.ctx.max_steps(self.name, self.max_steps))
        for step in range(1, steps + 1):
            if self.ctx.out_of_time():
                force = True
            else:
                force = step == steps
            choice = {"type": "function", "function": {"name": "submit_result"}} if force else "auto"
            self._compact(msgs, step)
            t0 = time.time()
            m = llm.chat(msgs, tools=specs, tool_choice=choice, reasoning_effort=effort)
            calls = list(getattr(m, "tool_calls", None) or [])
            self.ctx.trace.add(self.name, label, step, "turn", f"{len(calls)} call(s)",
                               f"{time.time() - t0:.1f}s " + ", ".join(c.function.name for c in calls))
            amsg = {"role": "assistant", "content": m.content or ""}
            if calls:
                amsg["tool_calls"] = [{"id": c.id, "type": "function", "function": {"name": c.function.name, "arguments": c.function.arguments}} for c in calls]
            msgs.append(amsg)
            if not calls:
                parsed = _json_from_text(m.content or "")
                if parsed is not None:
                    res, errs = self._finish(parsed, task, label, step)
                    if not errs or force:
                        return self._accept(key, res, errs, label, t_start, step, fixes)
                    best = res
                msgs.append({"role": "user", "content": "Call submit_result with your final JSON result."})
                continue
            submits = [c for c in calls if c.function.name == "submit_result"]
            tool_calls = [c for c in calls if c.function.name != "submit_result"]
            if tool_calls:
                for c, out in zip(tool_calls, self._run_tools(tool_calls, label, step)):
                    cap = int(self.ctx.cfg.get("llm", {}).get("max_tool_result_chars", 24000))
                    if len(out) > cap:
                        out = out[:cap] + f"\n...[truncated {len(out) - cap} chars - ask for a narrower query / smaller max_chars]"
                    msgs.append({"role": "tool", "tool_call_id": c.id, "content": out, "_step": step, "_tool": c.function.name})
            for c in submits:
                try:
                    args = json.loads(c.function.arguments or "{}")
                except json.JSONDecodeError as e:
                    msgs.append({"role": "tool", "tool_call_id": c.id,
                                 "content": f"ERROR: invalid JSON arguments ({e}). Your output was probably TRUNCATED: shorten it, "
                                            "or for a large existing file return `edits` [{find, replace}] instead of full content."})
                    self.ctx.trace.add(self.name, label, step, "submit", "invalid-json", str(e)[:120], ok=False)
                    continue
                res, errs = self._finish(args, task, label, step)
                if not errs:
                    msgs.append({"role": "tool", "tool_call_id": c.id, "content": "accepted"})
                    return self._accept(key, res, [], label, t_start, step, fixes)
                fixes += 1
                best = res
                if fixes > self.max_fix_rounds or force or not self.strict:
                    msgs.append({"role": "tool", "tool_call_id": c.id, "content": "accepted with issues"})
                    return self._accept(key, res, errs, label, t_start, step, fixes)
                msgs.append({"role": "tool", "tool_call_id": c.id, "content": "REJECTED - fix and resubmit:\n- " + "\n- ".join(errs[:25])})
        if best is not None:
            return self._accept(key, best, ["accepted last submission after max steps"], label, t_start, steps, fixes)
        raise RuntimeError(f"{self.name}: no result after {steps} steps ({label})")

    def _compact(self, msgs: list, step: int) -> None:
        """Token saver: every model call re-sends the whole conversation, so a 40k-char file read 6 steps ago is paid for again
        on every later step. Tool results older than `compact_after_steps` are shortened to their first `compact_keep_chars`
        with a note; the model can call the tool again if it still needs the detail (results of the last steps stay intact)."""
        llm_cfg = self.ctx.cfg.get("llm", {})
        after = int(llm_cfg.get("compact_after_steps", 2))
        keep = int(llm_cfg.get("compact_keep_chars", 1500))
        for m in msgs:
            if m.get("role") == "tool" and "_step" in m and step - m["_step"] > after and len(m.get("content", "")) > keep + 200 and not m.get("_compacted"):
                full = len(m["content"])
                m["content"] = m["content"][:keep] + f"\n...[{full - keep} more chars from {m.get('_tool', 'tool')} at step {m['_step']} omitted to save tokens - call the tool again if needed]"
                m["_compacted"] = True

    def _accept(self, key, res, errs, label, t_start, steps: int = 0, fixes: int = 0):
        if errs:
            res["_issues"] = errs[:25]
            log.warning("%s [%s]: accepted with %d issue(s): %s", self.name, label, len(errs), errs[0][:120])
        self.ctx.trace.add(self.name, label, 0, "done", "", f"{time.time() - t_start:.0f}s" + (f", {len(errs)} issue(s)" if errs else ""), ok=not errs)
        self.ctx.timings.append({"agent": self.name, "task": label, "seconds": round(time.time() - t_start, 1), "steps": steps,
                                 "fix_rounds": fixes, "cached": False, "issues": len(errs)})
        self.ctx.llm.cache_put(key, res)
        return res

    def _run_tools(self, calls, label, step) -> List[str]:
        def one(c):
            try:
                args = json.loads(c.function.arguments or "{}")
            except json.JSONDecodeError as e:
                return f"ERROR: invalid JSON arguments: {e}"
            return self._call_tool(c.function.name, args, label, step)
        if len(calls) == 1:
            return [one(calls[0])]
        import concurrent.futures as cf
        with cf.ThreadPoolExecutor(min(6, len(calls))) as ex:
            return list(ex.map(one, calls))

    def _finish(self, data, task, label, step):
        errs = validate_schema(data, self.output_schema)
        if errs:
            self.ctx.trace.add(self.name, label, step, "submit", "schema", "; ".join(errs[:5]), ok=False)
            return data, errs
        res, gerrs = self.ground(data, task)
        self.ctx.trace.add(self.name, label, step, "submit", "accepted" if not gerrs else "grounding", "; ".join(gerrs[:5]) if gerrs else "ok", ok=not gerrs)
        return res, gerrs

    def _call_tool(self, name, args, label, step) -> str:
        t = self.tools.get(name)
        if t is None:
            return f"ERROR: unknown tool {name}. Available: {list(self.tools)}"
        try:
            out = t(**args)
            txt = out if isinstance(out, str) else json.dumps(out, ensure_ascii=False, default=str)
            ok = True
            ref = args.get("path") or args.get("table") or args.get("term") or args.get("folder") or args.get("name") or args.get("query") or args.get("pattern") or args.get("section")
            if ref:
                self.ctx.used.append({"agent": self.name, "tool": name, "ref": str(ref)[:200], "repo": args.get("repo", ""), "schema": args.get("schema", "")})
        except Exception as e:  # noqa: BLE001
            txt, ok = f"ERROR: {type(e).__name__}: {e}", False
        self.ctx.trace.add(self.name, label, step, "tool", name, json.dumps(args, default=str)[:300], ok=ok)
        if len(txt) > MAX_TOOL_RESULT_CHARS:
            txt = txt[:MAX_TOOL_RESULT_CHARS] + f"\n...[truncated {len(txt) - MAX_TOOL_RESULT_CHARS} chars - narrow the request]"
        return txt

    cache_ignore: tuple = ()            # task fields left out of the result-cache key (story-specific hints that do not change the answer)

    def _key(self, task, prefix) -> str:
        h = hashlib.sha256()
        keyed = {k: v for k, v in task.items() if k not in self.cache_ignore} if isinstance(task, dict) else task
        for p in (self.name, self.ctx.cfg.llm["deployment"], self.system_prompt(), prefix or "", keyed, sorted(self.tools)):
            h.update(json.dumps(p, sort_keys=True, ensure_ascii=False, default=str).encode())
        return h.hexdigest()[:40]


def _json_from_text(txt: str):
    txt = (txt or "").strip()
    if txt.startswith("```"):
        txt = txt.split("\n", 1)[-1].rsplit("```", 1)[0]
    if not txt.startswith("{"):
        return None
    try:
        return json.loads(txt)
    except json.JSONDecodeError:
        return None
