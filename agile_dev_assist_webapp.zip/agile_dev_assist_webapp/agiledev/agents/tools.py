"""Deterministic tools the agents may call: everything reads the standard context pack or the indexed repositories.
No tool writes anything; no tool sees a secret."""
from __future__ import annotations

import json
import re
from typing import List

from .base import Tool, obj, arr, S, I

from ..greenplum import table_text


def _pack_section(ctx, name: str, query: str = "", max_chars: int = 20000) -> str:
    txt = ctx.pack.get(name, "")
    if isinstance(txt, (dict, list)):
        txt = json.dumps(txt, ensure_ascii=False, indent=1, default=str)
    if query:
        hits = []
        for para in re.split(r"\n\s*\n", txt):
            if any(q.lower() in para.lower() for q in query.split()):
                hits.append(para)
        txt = "\n\n".join(hits) or f"(nothing in {name} mentions '{query}')"
    return txt[:max_chars] + ("" if len(txt) <= max_chars else f"\n...[truncated {len(txt) - max_chars} chars - pass a query]")


def knowledge_tools(ctx) -> List[Tool]:
    return [
        Tool("read_section", "Read a section of the context pack: story | knowledge (skills, standards, glossary documents) | pack_knowledge | tables | instructions. "
             "Optional query = words to filter paragraphs.", obj({"section": S, "query": S}, ["section"]),
             lambda section, query="": _pack_section(ctx, {"skills": "knowledge", "standards": "knowledge"}.get(section, section), query)),
        Tool("define_term", "Look a term / column / abbreviation up in the glossary, knowledge documents and knowledge packs.",
             obj({"term": S}, ["term"]), lambda term: _define(ctx, term)),
    ] + pack_tools(ctx) + [
        Tool("search_similar", "Search BY MEANING (embeddings) across repository files, input tables, columns, glossary rows and "
             "skills / standards paragraphs. Use it when the story is plain English and search_repo / define_term / columns_named "
             "find nothing for a business phrase ('advisor's book of business', 'beneficiary not reviewed'). Hits are CANDIDATES: "
             "confirm with read_file / describe_table before using them. kinds = comma list of file,table,column,glossary,skills,standards.",
             obj({"query": S, "kinds": S, "k": I}, ["query"]), lambda query, kinds="", k=8: _similar(ctx, query, kinds, k)),
    ]


def _similar(ctx, query: str, kinds: str = "", k: int = 8):
    if ctx.semantic is None:
        return ("semantic search is OFF (embeddings.enabled: false in the config, or no embeddings deployment). Use search_repo with "
                "several alternative words (synonyms, abbreviations, singular / plural), define_term and columns_named instead.")
    ks = [x.strip() for x in str(kinds or "").split(",") if x.strip()] or None
    hits = ctx.semantic.search(query, k=int(k or 8), kinds=ks)
    if ctx.semantic.stats.get("error"):
        return f"semantic search unavailable: {ctx.semantic.stats['error']} - fall back to search_repo / define_term"
    if not hits:
        return f"nothing similar to '{query}' above the similarity threshold - try other words or search_repo"
    out = []
    for h in hits:
        out.append({"kind": h["kind"], "ref": h["ref"], "score": h["score"], "repo": h.get("repo", ""), "schema": h.get("schema", ""),
                    "excerpt": h["text"][:240]})
    return {"query": query, "hits": out, "note": "ranked by meaning (cosine similarity); confirm each candidate with read_file / describe_table"}


def _define(ctx, term: str) -> str:
    out = []
    for sec in ("knowledge", "pack_knowledge", "tables"):
        txt = ctx.pack.get(sec, "")
        for line in txt.splitlines():
            if re.search(rf"(?i)\b{re.escape(term)}\b", line):
                out.append(f"[{sec}] {line.strip()[:300]}")
                if len(out) >= 40:
                    return "\n".join(out)
    for pk in ctx.inputs.pack_objects():
        for b in pk.bridge(term)[:5]:
            out.append(f"[pack {pk.system} bridge] {b.get('term')}: tables {', '.join(b.get('tables', []) or [])}; columns {', '.join(b.get('columns', []) or [])}; scripts {', '.join(b.get('scripts_or_folders', []) or [])}")
        for h in pk.search(term, k=4, kinds=["definition", "glossary", "term", "table", "column"]):
            out.append(f"[pack {pk.system} {h['kind']}] {h['title']}: {h['text'][:200]}")
    return "\n".join(out) or f"'{term}' is not defined in the glossary, knowledge documents, knowledge packs or tables"


def pack_tools(ctx) -> List[Tool]:
    """The system knowledge packs (project 6): pre-built, indexed facts - exact and instant."""
    if not ctx.inputs.packs:
        return []

    def _pk(system=""):
        pks = ctx.inputs.pack_objects()
        if system:
            for p in pks:
                if p.system == system:
                    return p
        return pks[0]

    def search(query, system="", kinds="", k=8):
        ks = [x.strip() for x in str(kinds or "").split(",") if x.strip()] or None
        return [{"kind": h["kind"], "ref": h["ref"], "title": h["title"], "score": h["score"], "excerpt": h["text"][:400]} for h in _pk(system).search(query, k=int(k), kinds=ks)]

    def card(kind, name, system=""):
        return _pk(system).card(kind, name) or f"no {kind} card for {name}"

    def impact(table, system=""):
        return _pk(system).impact(table)

    def exemplar(folder, system=""):
        ex = _pk(system).exemplar(folder)
        return ex or f"no exemplar for folder {folder}"

    def folder(folder, system=""):
        pk = _pk(system)
        return {"card": pk.card("folder", folder), "registration": pk.registration(folder), "companions": pk.folder(folder).get("companions", []), "exemplar": (pk.exemplar(folder) or {}).get("file")}
    def insights(query, system="", k=6):
        out = []
        for h in _pk(system).insights(query, k=int(k)):
            out.append({"id": h["id"], "title": h["title"], "target": h["target"], "domain": h["domain"], "status": h["status"], "description": h["description"][:700]})
        return out or "no business rule matches - try other words, or pack_search"

    def trace(insight_id, system=""):
        t = _pk(system).trace(insight_id)
        if not t:
            return f"no insight {insight_id} in the pack"
        feats = {c: {"meaning": f.get("meaning", ""), "home_table": f.get("home_table", ""),
                     "computed_in": [(x.get("table"), x.get("file"), x.get("line"), x.get("expr", "")[:160]) for x in (f.get("lineage") or [])][-2:] or
                                    [(p.get("file"), p.get("line"), p.get("expr", "")[:160]) for p in f.get("producers", [])[:1]],
                     "used_by_count": f.get("used_by_count", 0)} for c, f in t["features"].items()}
        return {"card": t["card"][:6000], "features": feats, "depends_on": t["depends_on"]}

    def feature(column, system=""):
        return _pk(system).feature(column) or f"no feature {column} used by any business rule"
    systems = ", ".join(p["system"] for p in ctx.inputs.packs)
    return [
        Tool("pack_insights", f"Business rules (insights si_*) of the pack(s) ({systems}) matching plain English - the story's words: id, title, target, "
             "and an English description (advisor narrative + when the rule fires). Start here when the story is about an insight / alert / rule.",
             obj({"query": S, "system": S, "k": I}, ["query"]), insights),
        Tool("pack_trace", "Full trace of one insight id: ODM rule file and every condition (SQL + English), source profile table, NLG narrative "
             "yml + placeholders + layout, and each feature with the IKG script / line that computes it (column lineage). Use it to decide "
             "which IKG / ODM / NLG files a change touches and to copy the closest sibling.", obj({"insight_id": S, "system": S}, ["insight_id"]), trace),
        Tool("pack_feature", "One feature (column) used by the business rules: meaning, the IKG script computing it, lineage, the insights using it.",
             obj({"column": S, "system": S}, ["column"]), feature),
        Tool("pack_search", f"Search the system knowledge pack(s) ({systems}): folders, DAGs, tables, code chunks, companion rules, conventions, "
             "definitions, how-tos - hybrid BM25 + vectors with glossary synonyms. kinds = comma list of folder,dag,table,chunk,file,companion,"
             "convention,rule,definition,howto,param,glossary,business_rule,feature,domain,entity.", obj({"query": S, "system": S, "kinds": S, "k": I}, ["query"]), search),
        Tool("pack_folder", "Everything the pack knows about a folder: purpose card, registration rule (AUTOMATIC / STATIC), companion rules, "
             "exemplar file - call it for every candidate folder of the change before reading files.", obj({"folder": S, "system": S}, ["folder"]), folder),
        Tool("pack_card", "A prompt-ready card of the pack: kind = folder | table | dag | howto | rule | domain (name = folder path, schema.table, DAG stem, task, insight id, domain).",
             obj({"kind": S, "name": S, "system": S}, ["kind", "name"]), card),
        Tool("pack_impact", "Readers, downstream tables and DAGs of a table from the pack's lineage graph (what breaks if it changes).",
             obj({"table": S, "system": S}, ["table"]), impact),
        Tool("pack_exemplar", "The most typical existing file of a folder, full text - the shape to copy for a new file there.",
             obj({"folder": S, "system": S}, ["folder"]), exemplar),
    ]


def data_tools(ctx) -> List[Tool]:
    def describe(schema, table):
        for t in ctx.inputs.tables:
            if t["table"].lower() == table.lower() and (not schema or t["schema"].lower() == schema.lower()):
                return table_text(t)
        return f"table {schema}.{table} is not among the session inputs: " + ", ".join(f"{t['schema']}.{t['table']}" for t in ctx.inputs.tables)

    def columns_named(name):
        hits = [f"{t['schema']}.{t['table']}.{c['name']} {c['type']}" for t in ctx.inputs.tables for c in t["columns"]
                if name.lower() in c["name"].lower()]
        return "\n".join(hits[:100]) or f"no column containing '{name}'"
    return [
        Tool("describe_table", "Columns, types, keys, comments and sample rows of an input table.", obj({"schema": S, "table": S}, ["table"]), describe),
        Tool("columns_named", "Find input-table columns whose name contains the text.", obj({"name": S}, ["name"]), columns_named),
    ]


def repo_tools(ctx) -> List[Tool]:
    def _idx(repo=""):
        idxs = ctx.inputs.indexes()
        if not idxs:
            raise ValueError("no repository was added to this session")
        if repo:
            for i in idxs:
                if i.name == repo:
                    return i
        return idxs[0]

    def search(query, repo="", k=10, language=""):
        return [{"path": h["path"], "language": h["language"], "symbols": h["symbols"][:15], "chars": h["chars"]}
                for h in _idx(repo).search(query, k=int(k), languages=[language] if language else None)]

    def read(path, repo="", max_chars=20000, around="", from_line=0, to_line=0, context=40):
        """Whole file (capped) - or, for a big file, the exact window around a regex / a line range, with line numbers,
        so the edit anchors are copied verbatim (indentation included) instead of guessed from the first 20k chars."""
        idx = _idx(repo)
        if not around and not from_line:
            return idx.read(path, int(max_chars))
        full = idx.read(path, 10 ** 8)
        lines = full.splitlines()
        if around:
            rx = re.compile(around, re.I)
            where = [i for i, l in enumerate(lines) if rx.search(l)]
            if not where:
                return f"no line of {path} matches /{around}/ ({len(lines)} lines) - try grep_repo or a different pattern"
            windows = []
            for i in where[:6]:
                a, b = max(0, i - int(context)), min(len(lines), i + int(context) + 1)
                if windows and a <= windows[-1][1]:
                    windows[-1] = (windows[-1][0], b)
                else:
                    windows.append((a, b))
        else:
            a = max(0, int(from_line) - 1)
            windows = [(a, min(len(lines), int(to_line) if to_line else a + 2 * int(context)))]
        out = [f"# {path}: {len(lines)} lines, {len(full)} chars - windows below are VERBATIM (copy anchors exactly, indentation included)"]
        for a, b in windows:
            out.append(f"--- lines {a + 1}-{b} ---")
            out.extend(lines[a:b])
        txt = "\n".join(out)
        return txt if len(txt) <= int(max_chars) * 2 else txt[: int(max_chars) * 2] + "\n...[truncated - narrow the window]"

    def grep(pattern, repo="", max_hits=40):
        return _idx(repo).grep(pattern, int(max_hits))

    def tree(repo="", depth=3):
        return "\n".join(_idx(repo).tree(int(depth)))

    def examples(language, folder="", repo="", k=2):
        return _idx(repo).examples(language, folder, int(k))

    def registration(folder, repo=""):
        return _idx(repo).registration_candidates(folder)

    def references(name, repo="", max_hits=40):
        return _idx(repo).references(name, int(max_hits))

    def companions(path, repo="", table_names=None):
        idx = _idx(repo)
        return idx.companions(path, table_names or []) if path.strip("/") in idx.files else idx.companions_for_new(path)
    return [
        Tool("companion_files", "Files that change TOGETHER with a file: the same table's history / archive / snapshot script in a "
             "sibling folder, configs and DAGs listing it, readers of it. For a path that does not exist yet, what its future "
             "siblings have (analogous file to create + config entries to add). Call it for EVERY file you will create or modify.",
             obj({"path": S, "repo": S, "table_names": arr(S)}, ["path"]), companions),
        Tool("registration_points", "Files that register the scripts of a folder (DAG task lists, config lists, task-name files). "
             "A NEW script in that folder must be added there too.", obj({"folder": S, "repo": S}, ["folder"]), registration),
        Tool("references", "Every place a table / column / function / file name is used - the impact of changing it.",
             obj({"name": S, "repo": S, "max_hits": I}, ["name"]), references),
        Tool("search_repo", "Find the existing files most related to a query (BM25 over paths, symbols, content).",
             obj({"query": S, "repo": S, "k": I, "language": S}, ["query"]), search),
        Tool("read_file", "Read an existing repository file (path from search_repo / tree). Default 20,000 chars (the head only for a big file). "
             "For a big file read the PLACE you will edit: around=<regex> (window of `context` lines round each match, max 6 matches) or "
             "from_line / to_line - the lines come back verbatim with indentation, ready to be copied as edit anchors.",
             obj({"path": S, "repo": S, "max_chars": I, "around": S, "from_line": I, "to_line": I, "context": I}, ["path"]), read),
        Tool("grep_repo", "Regex search across the repository: file, line number, the line verbatim (indentation kept).", obj({"pattern": S, "repo": S, "max_hits": I}, ["pattern"]), grep),
        Tool("repo_tree", "Folder tree of the repository with file counts.", obj({"repo": S, "depth": I}, []), tree),
        Tool("example_files", "Paths of typical existing files of a language (patterns to imitate).", obj({"language": S, "folder": S, "repo": S, "k": I}, ["language"]), examples),
    ]


def all_tools(ctx) -> List[Tool]:
    return knowledge_tools(ctx) + data_tools(ctx) + (repo_tools(ctx) if ctx.inputs.repos else [])
