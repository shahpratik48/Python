"""Deterministic tools the agents may call: everything reads the standard context pack or the indexed repositories.
No tool writes anything; no tool sees a secret."""
from __future__ import annotations

import json
import re
from typing import List

from .base import Tool, obj, arr, S, I

from ..greenplum import table_text


def _pack_section(ctx, name: str, query: str = "", max_chars: int = 20000) -> str:
    txt = ctx.pack.get(name, "")
    if isinstance(txt, (dict, list)):
        txt = json.dumps(txt, ensure_ascii=False, indent=1, default=str)
    if query:
        hits = []
        for para in re.split(r"\n\s*\n", txt):
            if any(q.lower() in para.lower() for q in query.split()):
                hits.append(para)
        txt = "\n\n".join(hits) or f"(nothing in {name} mentions '{query}')"
    return txt[:max_chars] + ("" if len(txt) <= max_chars else f"\n...[truncated {len(txt) - max_chars} chars - pass a query]")


def knowledge_tools(ctx) -> List[Tool]:
    return [
        Tool("read_section", "Read a section of the context pack: story | skills | glossary | standards | tables | instructions. "
             "Optional query = words to filter paragraphs.", obj({"section": S, "query": S}, ["section"]),
             lambda section, query="": _pack_section(ctx, section, query)),
        Tool("define_term", "Look a term / column / abbreviation up in the glossary, skills and standards.",
             obj({"term": S}, ["term"]), lambda term: _define(ctx, term)),
        Tool("search_similar", "Search BY MEANING (embeddings) across repository files, input tables, columns, glossary rows and "
             "skills / standards paragraphs. Use it when the story is plain English and search_repo / define_term / columns_named "
             "find nothing for a business phrase ('advisor's book of business', 'beneficiary not reviewed'). Hits are CANDIDATES: "
             "confirm with read_file / describe_table before using them. kinds = comma list of file,table,column,glossary,skills,standards.",
             obj({"query": S, "kinds": S, "k": I}, ["query"]), lambda query, kinds="", k=8: _similar(ctx, query, kinds, k)),
    ]


def _similar(ctx, query: str, kinds: str = "", k: int = 8):
    if ctx.semantic is None:
        return ("semantic search is OFF (embeddings.enabled: false in the config, or no embeddings deployment). Use search_repo with "
                "several alternative words (synonyms, abbreviations, singular / plural), define_term and columns_named instead.")
    ks = [x.strip() for x in str(kinds or "").split(",") if x.strip()] or None
    hits = ctx.semantic.search(query, k=int(k or 8), kinds=ks)
    if ctx.semantic.stats.get("error"):
        return f"semantic search unavailable: {ctx.semantic.stats['error']} - fall back to search_repo / define_term"
    if not hits:
        return f"nothing similar to '{query}' above the similarity threshold - try other words or search_repo"
    out = []
    for h in hits:
        out.append({"kind": h["kind"], "ref": h["ref"], "score": h["score"], "repo": h.get("repo", ""), "schema": h.get("schema", ""),
                    "excerpt": h["text"][:240]})
    return {"query": query, "hits": out, "note": "ranked by meaning (cosine similarity); confirm each candidate with read_file / describe_table"}


def _define(ctx, term: str) -> str:
    out = []
    for sec in ("glossary", "skills", "standards", "tables"):
        txt = ctx.pack.get(sec, "")
        for line in txt.splitlines():
            if re.search(rf"(?i)\b{re.escape(term)}\b", line):
                out.append(f"[{sec}] {line.strip()[:300]}")
                if len(out) >= 40:
                    return "\n".join(out)
    return "\n".join(out) or f"'{term}' is not defined in the glossary, skills, standards or tables"


def data_tools(ctx) -> List[Tool]:
    def describe(schema, table):
        for t in ctx.inputs.tables:
            if t["table"].lower() == table.lower() and (not schema or t["schema"].lower() == schema.lower()):
                return table_text(t)
        return f"table {schema}.{table} is not among the session inputs: " + ", ".join(f"{t['schema']}.{t['table']}" for t in ctx.inputs.tables)

    def columns_named(name):
        hits = [f"{t['schema']}.{t['table']}.{c['name']} {c['type']}" for t in ctx.inputs.tables for c in t["columns"]
                if name.lower() in c["name"].lower()]
        return "\n".join(hits[:100]) or f"no column containing '{name}'"
    return [
        Tool("describe_table", "Columns, types, keys, comments and sample rows of an input table.", obj({"schema": S, "table": S}, ["table"]), describe),
        Tool("columns_named", "Find input-table columns whose name contains the text.", obj({"name": S}, ["name"]), columns_named),
    ]


def repo_tools(ctx) -> List[Tool]:
    def _idx(repo=""):
        idxs = ctx.inputs.indexes()
        if not idxs:
            raise ValueError("no repository was added to this session")
        if repo:
            for i in idxs:
                if i.name == repo:
                    return i
        return idxs[0]

    def search(query, repo="", k=10, language=""):
        return [{"path": h["path"], "language": h["language"], "symbols": h["symbols"][:15], "chars": h["chars"]}
                for h in _idx(repo).search(query, k=int(k), languages=[language] if language else None)]

    def read(path, repo="", max_chars=20000):
        return _idx(repo).read(path, int(max_chars))

    def grep(pattern, repo="", max_hits=40):
        return _idx(repo).grep(pattern, int(max_hits))

    def tree(repo="", depth=3):
        return "\n".join(_idx(repo).tree(int(depth)))

    def examples(language, folder="", repo="", k=2):
        return _idx(repo).examples(language, folder, int(k))

    def registration(folder, repo=""):
        return _idx(repo).registration_candidates(folder)

    def references(name, repo="", max_hits=40):
        return _idx(repo).references(name, int(max_hits))

    def companions(path, repo="", table_names=None):
        idx = _idx(repo)
        return idx.companions(path, table_names or []) if path.strip("/") in idx.files else idx.companions_for_new(path)
    return [
        Tool("companion_files", "Files that change TOGETHER with a file: the same table's history / archive / snapshot script in a "
             "sibling folder, configs and DAGs listing it, readers of it. For a path that does not exist yet, what its future "
             "siblings have (analogous file to create + config entries to add). Call it for EVERY file you will create or modify.",
             obj({"path": S, "repo": S, "table_names": arr(S)}, ["path"]), companions),
        Tool("registration_points", "Files that register the scripts of a folder (DAG task lists, config lists, task-name files). "
             "A NEW script in that folder must be added there too.", obj({"folder": S, "repo": S}, ["folder"]), registration),
        Tool("references", "Every place a table / column / function / file name is used - the impact of changing it.",
             obj({"name": S, "repo": S, "max_hits": I}, ["name"]), references),
        Tool("search_repo", "Find the existing files most related to a query (BM25 over paths, symbols, content).",
             obj({"query": S, "repo": S, "k": I, "language": S}, ["query"]), search),
        Tool("read_file", "Read an existing repository file (path from search_repo / tree). Default 20,000 chars; pass max_chars for more, or grep_repo for one place.", obj({"path": S, "repo": S, "max_chars": I}, ["path"]), read),
        Tool("grep_repo", "Regex search across the repository: file, line, text.", obj({"pattern": S, "repo": S, "max_hits": I}, ["pattern"]), grep),
        Tool("repo_tree", "Folder tree of the repository with file counts.", obj({"repo": S, "depth": I}, []), tree),
        Tool("example_files", "Paths of typical existing files of a language (patterns to imitate).", obj({"language": S, "folder": S, "repo": S, "k": I}, ["language"]), examples),
    ]


def all_tools(ctx) -> List[Tool]:
    return knowledge_tools(ctx) + data_tools(ctx) + (repo_tools(ctx) if ctx.inputs.repos else [])
