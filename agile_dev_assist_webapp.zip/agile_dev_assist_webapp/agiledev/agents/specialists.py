"""The specialist agents. Every one gets the SAME standard context pack and returns a JSON result that code validates.

  story_agent      story -> structured requirement (what, inputs, outputs, rules, acceptance, open questions)
  knowledge_agent  skills + glossary + standards -> definitions that matter here + machine-checkable rules
  data_agent       tables -> how each is used (grain, keys, joins, columns needed)
  repo_agent       repository -> where the change belongs, patterns to imitate, conventions observed
  planner_agent    -> the plan: files to create / modify (language, purpose, outline), steps
  coder_agent      one file (full content or edits for a large existing file)
  reviewer_agent   all files vs story + standards -> findings (severity) + score
  change_agent     a follow-up request in the chat -> which files change and how (then coder in fix mode)
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Optional, List

from .base import Agent, obj, arr, S, I, B
from . import tools as T

PROMPTS = Path(__file__).resolve().parent.parent.parent / "prompts"


def _prompt(name: str) -> str:
    p = PROMPTS / f"{name}.md"
    return p.read_text(encoding="utf-8") if p.exists() else f"You are the {name}. Answer with JSON via submit_result."


SEVERITY = {"type": "string", "enum": ["critical", "high", "medium", "low", "info"]}


class StoryAgent(Agent):
    name = "story_agent"
    SCHEMA = obj({"summary": S, "goal": S, "functional_requirements": arr(S), "inputs": arr(S), "outputs": arr(S),
                  "business_rules": arr(S), "acceptance_criteria": arr(S), "non_functional": arr(S),
                  "open_questions": arr(S), "feature_name": S, "target_languages": arr(S),
                  "code_in_story": arr(obj({"index": I, "language": S, "what_it_does": S, "how_to_use": S, "tables": arr(S), "columns": arr(S)},
                                           ["index", "what_it_does", "how_to_use"])),
                  "tables_mentioned": arr(S), "columns_mentioned": arr(S)},
                 ["summary", "goal", "functional_requirements", "acceptance_criteria", "feature_name", "code_in_story"])

    def ground(self, r, task):
        n = len((task.get("story") or {}).get("code_blocks") or [])
        got = {c.get("index") for c in r.get("code_in_story", [])}
        missing = [i for i in range(1, n + 1) if i not in got]
        return r, ([f"code_in_story must describe every code block of the story - missing block(s) {missing} (index 1..{n})"] if missing else [])

    def __init__(self, ctx):
        super().__init__(ctx, T.knowledge_tools(ctx) + T.data_tools(ctx), self.SCHEMA, _prompt("story_agent"))

    def execute(self) -> dict:
        p = self.ctx.pack
        story = dict(p["story"])
        story["code_blocks"] = [{"index": i, "language": b.get("language", ""), "where": b.get("where", ""), "code": b.get("code", "")[:6000]}
                                for i, b in enumerate(story.get("code_blocks") or [], 1)]
        task = {"story": story, "user_instructions": p.get("instructions", []), "inventory": p.get("inventory", {}),
                "table_catalog": p.get("table_catalog", [])}
        res = self.run(task, task_label="story")
        self.ctx.story = res
        return res


class KnowledgeAgent(Agent):
    name = "knowledge_agent"
    strict = False
    # the extraction depends on the DOCUMENTS, not on the story: the story fields are only a focus hint, so the result is
    # reused for every story that uses the same skills / standards / glossary files (no model call, no cost)
    cache_ignore = ("story_summary", "feature", "requirements", "target_languages")
    SCHEMA = obj({"definitions": arr(obj({"term": S, "definition": S, "source": S})),
                  "conventions": arr(obj({"rule": S, "source": S, "applies_to": S})),
                  "rules": arr(obj({"id": S, "pattern": S, "must_match": B, "severity": SEVERITY, "message": S, "languages": arr(S),
                                    "applies_to": arr(S), "exempt": arr(S)}, ["id", "pattern", "must_match", "severity", "message", "languages"])),
                  "notes_for_coder": arr(S)}, ["definitions", "conventions", "rules"])

    def __init__(self, ctx):
        super().__init__(ctx, T.knowledge_tools(ctx), self.SCHEMA, _prompt("knowledge_agent"))

    def ground(self, r, task):
        ok = []
        for rule in r.get("rules", []):
            try:
                re.compile(rule.get("pattern", ""))
                ok.append(rule)
            except re.error:
                continue
        r["rules"] = ok
        return r, []

    def execute(self) -> dict:
        p = self.ctx.pack
        if not (p.get("skills") or p.get("glossary") or p.get("standards")):
            self.ctx.knowledge = {"definitions": [], "conventions": [], "rules": [], "notes_for_coder": [], "skipped": "no knowledge documents"}
            return self.ctx.knowledge
        task = {"story_summary": self.ctx.story.get("summary", ""), "feature": self.ctx.story.get("feature_name", ""),
                "requirements": self.ctx.story.get("functional_requirements", []),
                "target_languages": self.ctx.story.get("target_languages", []),
                "skills_excerpt": p.get("skills", "")[:30000], "glossary_excerpt": p.get("glossary", "")[:20000],
                "standards_excerpt": p.get("standards", "")[:30000]}
        res = self.run(task, task_label="knowledge")
        self.ctx.knowledge = res
        self.ctx.rules = res.get("rules", [])
        return res


class DataAgent(Agent):
    name = "data_agent"
    strict = False
    SCHEMA = obj({"tables": arr(obj({"table": S, "role": S, "grain": S, "keys": arr(S), "columns_needed": arr(S), "notes": S})),
                  "joins": arr(S), "data_rules": arr(S), "sql_dialect": S}, ["tables"])

    def __init__(self, ctx):
        super().__init__(ctx, T.data_tools(ctx) + T.knowledge_tools(ctx), self.SCHEMA, _prompt("data_agent"))

    def execute(self) -> dict:
        if not self.ctx.inputs.tables and not self.ctx.inputs.queries:
            self.ctx.data = {"tables": [], "joins": [], "data_rules": [], "skipped": "no tables"}
            return self.ctx.data
        task = {"story_summary": self.ctx.story.get("summary", ""), "requirements": self.ctx.story.get("functional_requirements", []),
                "tables": self.ctx.pack.get("tables", "")[:30000]}
        self.ctx.data = self.run(task, task_label="data")
        return self.ctx.data


class RepoAgent(Agent):
    name = "repo_agent"
    strict = True
    max_fix_rounds = 1
    SCHEMA = obj({"where_the_change_belongs": arr(obj({"repo": S, "folder": S, "reason": S})),
                  "patterns_to_imitate": arr(obj({"path": S, "why": S})),
                  "conventions_observed": arr(S), "existing_files_to_modify": arr(obj({"path": S, "why": S})),
                  "registration_points": arr(obj({"path": S, "what_to_add": S, "example_line": S}, ["path", "what_to_add"])),
                  "companion_files": arr(obj({"path": S, "for_file": S, "action": {"type": "string", "enum": ["create", "modify", "not needed"]},
                                              "what_to_change": S}, ["path", "for_file", "action", "what_to_change"])),
                  "impact": arr(obj({"name": S, "used_in": arr(S), "risk": S}, ["name", "used_in"])),
                  "reusable_functions": arr(S)},
                 ["where_the_change_belongs", "patterns_to_imitate", "conventions_observed", "registration_points", "companion_files", "impact"])

    def __init__(self, ctx):
        super().__init__(ctx, T.repo_tools(ctx) + T.knowledge_tools(ctx), self.SCHEMA, _prompt("repo_agent"))

    def ground(self, r, task):
        known = {f["path"] for rp in self.ctx.pack.get("repos", []) for f in rp.get("relevant_files", [])}
        for idx in self.ctx.inputs.indexes():
            known |= set(idx.files)
        for k in ("patterns_to_imitate", "existing_files_to_modify", "registration_points"):
            r[k] = [x for x in r.get(k, []) if x.get("path") in known]
        errs = []
        # deterministic companions of every file to modify (history / archive script, config entries): must be decided, not forgotten
        listed_c = {x["path"] for x in r.get("companion_files", [])}
        miss_c = []
        for fm in r.get("existing_files_to_modify", []):
            for idx in self.ctx.inputs.indexes():
                if fm["path"] in idx.files:
                    for c in idx.companions(fm["path"], self.ctx.story.get("tables_mentioned", []))[:4]:
                        if c["relation"] == "consumer":          # readers belong to impact, not to the change set
                            continue
                        if c["path"] not in listed_c and c["path"] not in {m["path"] for m in miss_c}:
                            miss_c.append({"path": c["path"], "for_file": fm["path"], "relation": c["relation"], "reason": c["reason"]})
        if miss_c and not r.get("_companions_checked"):
            errs.append("these files usually change together with the files you modify and are missing from companion_files - read each "
                        "(read_file) and add it with action modify + what_to_change, or action 'not needed' + why: "
                        + "; ".join(f"{m['path']} (for {m['for_file']}: {m['reason'][:120]})" for m in miss_c[:8]))
        r["_companions_checked"] = True
        # deterministic registration candidates for the chosen folders: the agent must not miss them
        for w in r.get("where_the_change_belongs", []):
            idx = next((i for i in self.ctx.inputs.indexes() if i.name == w.get("repo")), None) or (self.ctx.inputs.indexes() or [None])[0]
            if idx is None:
                continue
            cands = idx.registration_candidates(w.get("folder", ""))
            listed = {x["path"] for x in r.get("registration_points", [])}
            miss = [c for c in cands[:3] if c["path"] not in listed]
            if miss and not r.get("_registration_checked"):
                errs.append(f"folder {w.get('folder')}: these files register its scripts and are missing from registration_points: "
                            + "; ".join(f"{c['path']} ({c['reason']})" for c in miss) + " - read them (read_file) and list what to add, or state why not")
        r["_registration_checked"] = True
        return r, errs

    def execute(self) -> dict:
        if not self.ctx.inputs.repos:
            self.ctx.repo = {"where_the_change_belongs": [], "patterns_to_imitate": [], "conventions_observed": [],
                             "existing_files_to_modify": [], "skipped": "no repository"}
            return self.ctx.repo
        repos = [{"name": rp["name"], "summary": rp["summary"], "relevant_files": [{"path": f["path"], "language": f["language"],
                  "excerpt": f["content"][:2500]} for f in rp["relevant_files"]]} for rp in self.ctx.pack.get("repos", [])]
        task = {"story_summary": self.ctx.story.get("summary", ""), "feature": self.ctx.story.get("feature_name", ""),
                "requirements": self.ctx.story.get("functional_requirements", []),
                "tables_mentioned": self.ctx.story.get("tables_mentioned", []), "code_in_story": self.ctx.story.get("code_in_story", []),
                "repos": repos}
        self.ctx.repo = self.run(task, task_label="repo")
        return self.ctx.repo


class PlannerAgent(Agent):
    name = "planner_agent"
    max_fix_rounds = 2
    SCHEMA = obj({"approach": S,
                  "design": obj({"modules": arr(obj({"name": S, "purpose": S, "kind": S}, ["name", "purpose"])),
                                 "intermediate_tables": arr(obj({"name": S, "grain": S, "purpose": S, "distribution_key": S}, ["name", "purpose"])),
                                 "performance": arr(S), "story_code_usage": arr(obj({"index": I, "used_in": S, "how": S}, ["index", "used_in", "how"]))},
                                ["modules", "intermediate_tables", "performance", "story_code_usage"]),
                  "files": arr(obj({"path": S, "action": {"type": "string", "enum": ["create", "modify"]}, "language": S,
                                    "purpose": S, "outline": arr(S), "depends_on": arr(S), "repo": S,
                                    "requirements_covered": arr(S)}, ["path", "action", "language", "purpose", "outline"])),
                  "registration_changes": arr(obj({"path": S, "what": S}, ["path", "what"])),
                  "impact": arr(S), "steps": arr(S), "test_plan": arr(S), "risks": arr(S), "questions": arr(S)},
                 ["approach", "design", "files", "registration_changes", "impact", "steps", "test_plan"])

    def __init__(self, ctx):
        super().__init__(ctx, T.all_tools(ctx), self.SCHEMA, _prompt("planner_agent"))

    def ground(self, r, task):
        errs = []
        langs = {l.lower() for l in (self.ctx.cfg.get("generation", {}).get("languages") or [])}
        max_files = int(self.ctx.cfg.get("generation", {}).get("max_files", 30))
        seen = set()
        files = []
        for f in r.get("files", []):
            if f["path"] in seen:
                continue
            seen.add(f["path"])
            f["language"] = f.get("language", "").lower()
            if langs and f["language"] not in langs:
                f["language"] = _guess_lang(f["path"]) or f["language"]
            if f["action"] == "modify":
                exists = any(f["path"] in idx.files for idx in self.ctx.inputs.indexes())
                if not exists:
                    # the file is wanted (a history / companion script that does not exist yet): keep it as a CREATE rather
                    # than dropping it - dropping it is how a 6-file plan silently becomes a 3-file plan
                    f["action"] = "create"
                    f["purpose"] = (f.get("purpose") or "") + " (new file: it did not exist in the repository - copy the shape of its siblings)"
                    r.setdefault("notes", []).append(f"{f['path']}: planned as modify but absent from the repository - turned into create")
            files.append(f)
        if not files:
            errs.append("the plan has no files")
        if len(files) > max_files:
            errs.append(f"too many files ({len(files)} > {max_files}) - merge or drop the least important")
        r["files"] = files[:max_files]
        # every registration point found by the repo agent must be a modified file (or explicitly declined in registration_changes)
        planned = {f["path"] for f in files}
        declined = {x["path"] for x in r.get("registration_changes", [])}
        # a declined registration of a NEW script is only valid when another planned file runs it
        new_scripts = {f["path"] for f in files if f["action"] == "create" and f["language"] in ("sql", "python", "r", "shell")}
        reg_paths = {rp["path"] for rp in (self.ctx.repo or {}).get("registration_points", [])}
        for p in new_scripts:
            folder = p.rsplit("/", 1)[0] if "/" in p else ""
            for idx in self.ctx.inputs.indexes():
                reg_paths |= {c["path"] for c in idx.registration_candidates(folder)[:2]}
        for x in r.get("registration_changes", []):
            what = str(x.get("what", "")).lower()
            if "not needed" not in what or x.get("path") not in reg_paths or x.get("path") in planned:
                continue
            runs = re.search(r"\b(called|invoked|included|executed|sourced|run by|runs it|runs the|\\i\b|imports?|wrapped)", what)
            if new_scripts and not runs:
                errs.append(f"registration_changes {x.get('path')}: a new script that is not registered anywhere never runs. Either plan "
                            f"a modify of {x.get('path')} that adds the new script(s) {sorted(new_scripts)} exactly like their siblings, or say "
                            "'not needed because <new file> is called / included by <another file of the plan>'")
        for rp in (self.ctx.repo or {}).get("registration_points", []):
            if rp["path"] not in planned and rp["path"] not in declined:
                errs.append(f"{rp['path']} registers the scripts of the target folder ({rp.get('what_to_add', '')}) - add it as a modify file, "
                            "or list it in registration_changes with what = 'not needed because ...'")
        # every code block of the story must be used (or explicitly not)
        n = len(self.ctx.story.get("code_in_story", []) or [])
        design = r.get("design") or {}
        used = {u.get("index") for u in design.get("story_code_usage", [])}
        miss = [i for i in range(1, n + 1) if i not in used]
        if miss:
            errs.append(f"design.story_code_usage must say how story code block(s) {miss} are used (used_in = file path, or 'not used because ...')")
        # design -> files: every intermediate table of the design is built by a file of the plan
        stems = {f["path"].rsplit("/", 1)[-1].rsplit(".", 1)[0].lower(): f for f in files}
        for t in design.get("intermediate_tables", []) or []:
            name = (t.get("name") or "").split(".")[-1].lower()
            mentioned = any(name in (f["path"] + " " + f.get("purpose", "") + " " + " ".join(f.get("outline") or [])).lower() for f in files) \
                or any(name in str(m.get("name", "")).lower() and str(m.get("kind", "")).lower().startswith("temp") for m in design.get("modules", []) or []) \
                or "inside" in str(t.get("purpose", "")).lower() or "temp" in str(t.get("purpose", "")).lower()
            if name and name not in stems and not mentioned:
                errs.append(f"design.intermediate_tables declares {name} but no file of the plan builds it - add a create file named after the "
                            "table in the folder of its subject (copy the shape of its siblings), or remove it from the design")
        # logic belongs in a module of its own: story code with joins / aggregations / windows is ported into a NEW file
        # (an intermediate / temp table, a function) and only JOINED by an existing table script - unless explicitly justified
        blocks = (self.ctx.pack.get("story") or {}).get("code_blocks") or []
        by_path = {f["path"]: f for f in files}
        for u in design.get("story_code_usage", []):
            try:
                code = (blocks[int(u.get("index", 0)) - 1].get("code") or "")
            except (IndexError, ValueError, TypeError):
                continue
            heavy = re.search(r"(?is)\b(join|group\s+by|over\s*\(|case\s+when|distinct\s+on|with\s+\w+\s+as)\b", code) is not None
            target = by_path.get(str(u.get("used_in", "")).strip())
            how = str(u.get("how", "")).lower()
            if heavy and target and target["action"] == "modify" and "because" not in how:
                errs.append(f"story code block {u.get('index')} contains joins / aggregations / CASE logic but is placed into the EXISTING file "
                            f"{target['path']} - port it into a NEW module file (intermediate / temp table named after what it computes, in the "
                            "folder of its subject, DISTRIBUTED BY the join key) and let the existing script only LEFT JOIN that table; "
                            "or say in design.story_code_usage.how 'kept in the existing file because <convention / reason>'")
        # companion files (history / archive script of the same table, config entries): planned or declined, never forgotten
        for c in (self.ctx.repo or {}).get("companion_files", []):
            if c.get("action") in ("create", "modify") and c["path"] not in planned and c["path"] not in declined:
                errs.append(f"{c['path']} changes together with {c.get('for_file')} ({c.get('what_to_change', '')[:120]}) - add it to files "
                            "(action " + c["action"] + "), or list it in registration_changes with what = 'not needed because ...'")
        dependents = {x["path"] for x in (self.ctx.repo or {}).get("registration_points", [])} | \
                     {x["path"] for x in (self.ctx.repo or {}).get("companion_files", [])}
        for f in files:
            if f["path"] in dependents:          # registration / companion files are the dependents, not the source of more
                continue
            for idx in self.ctx.inputs.indexes():
                if (not f.get("repo") or idx.name == f.get("repo")) and (idx.files or []):
                    cands = idx.companions(f["path"], self.ctx.story.get("tables_mentioned", [])) if f["path"] in idx.files \
                        else idx.companions_for_new(f["path"])
                    for c in cands[:4]:
                        if c["relation"] == "consumer":
                            continue
                        if c["path"] not in planned and c["path"] not in declined:
                            errs.append(f"{f['path']}: {c['path']} - {c['reason'][:160]} - plan it (create / modify) or decline it in "
                                        "registration_changes with what = 'not needed because ...'")
        # one validation artifact per story (config generation.require_validation): a validation SQL / notebook that checks the result
        if (self.ctx.cfg.get("generation") or {}).get("require_validation", True):
            is_val = lambda f: re.search(r"valid|check|test|reconcil", (f["path"] + " " + f.get("purpose", "")).lower()) is not None  # noqa: E731
            if not any(is_val(f) for f in files):
                errs.append("the plan has no validation artifact - add ONE file that checks the result (row counts, null rates, min / max of the "
                            "new columns, reconciliation against the source): in the folder the repository uses for validations (search_repo "
                            "'validation') copying a sibling's shape, else a notebook under notebooks/. Every story gets exactly one.")
        # DAG / orchestration sanity: new sql / python scripts in a folder whose siblings are orchestrated
        for f in files:
            if f["action"] == "create" and f["language"] in ("sql", "python"):
                folder = f["path"].rsplit("/", 1)[0] if "/" in f["path"] else ""
                for idx in self.ctx.inputs.indexes():
                    for c in idx.registration_candidates(folder)[:2]:
                        if c["path"] not in planned and c["path"] not in declined:
                            errs.append(f"new file {f['path']}: {c['path']} {c['reason']} - plan a modify of it or decline it in registration_changes")
        return r, list(dict.fromkeys(errs))

    def execute(self) -> dict:
        blocks = [{"index": i, "language": b.get("language", ""), "code": b.get("code", "")[:4000]}
                  for i, b in enumerate((self.ctx.pack.get("story") or {}).get("code_blocks") or [], 1)]
        task = {"story": self.ctx.story, "story_code_blocks": blocks, "knowledge": _trim(self.ctx.knowledge), "data": _trim(self.ctx.data),
                "repo": _trim(self.ctx.repo, 16000), "user_instructions": self.ctx.pack.get("instructions", []),
                "repository_facts": _repository_facts(self.ctx),     # computed by code: what the grounding will demand - plan it from the start
                "allowed_languages": self.ctx.cfg.get("generation", {}).get("languages", [])}
        self.ctx.plan = self.run(task, task_label="plan")
        return self.ctx.plan


def _repository_facts(ctx, max_folders: int = 6) -> dict:
    """Deterministic facts the planner would otherwise discover with tool calls (and be rejected for missing): for every
    candidate folder of the change, the files that register its scripts (DAG task lists, configs, name registries) and
    the companion files its scripts have (history / archive scripts, config entries); the validation folder; the files
    the repo agent wants modified with THEIR companions. Everything here is verified against the repository index."""
    repo = ctx.repo or {}
    folders = []
    v = repo.get("where_the_change_belongs")
    for w in (v if isinstance(v, list) else [v]):
        if isinstance(w, dict) and w.get("folder"):
            folders.append(str(w["folder"]).strip("/"))
        elif isinstance(w, str) and "/" in w:
            folders.append(w.strip("/"))
    for x in (repo.get("patterns_to_imitate") or []) + (repo.get("existing_files_to_modify") or []):
        pth = str(x.get("path", "") if isinstance(x, dict) else x)
        if "/" in pth:
            folders.append(pth.rsplit("/", 1)[0])
    seen, out_folders = set(), []
    for f in folders:
        if f and f not in seen:
            seen.add(f); out_folders.append(f)
    facts = {"folders": [], "files_to_modify": [], "validation_folder": None,
             "rule": "every new script in a folder below must be registered in that folder's registration files (or the plan says which "
                     "planned file calls it); every companion listed must be planned (create / modify) or declined with 'not needed because ...'"}
    for idx in ctx.inputs.indexes():
        if not idx.files:
            continue
        for folder in out_folders[:max_folders]:
            regs = idx.registration_candidates(folder)[:3]
            sibs = [r for r in idx.files if (r.rsplit("/", 1)[0] if "/" in r else "") == folder][:3]
            comp = []
            for sb in sibs[:2]:
                for c in idx.companions(sb, ctx.story.get("tables_mentioned", []) if ctx.story else [])[:4]:
                    if c["relation"] != "consumer":
                        comp.append({"sibling": sb, "companion": c["path"], "relation": c["relation"], "example_line": c.get("example_line", "")[:120]})
            facts["folders"].append({"folder": folder, "repo": idx.name, "sibling_files": sibs,
                                     "registration_files": [{"path": r["path"], "reason": r["reason"][:140], "example_line": r.get("example_line", "")[:160]} for r in regs],
                                     "companions_of_siblings": comp[:6]})
        for x in (repo.get("existing_files_to_modify") or [])[:6]:
            pth = str(x.get("path", "") if isinstance(x, dict) else x)
            if pth in idx.files:
                facts["files_to_modify"].append({"path": pth, "companions": [{"path": c["path"], "relation": c["relation"], "reason": c["reason"][:140]}
                                                                               for c in idx.companions(pth, ctx.story.get("tables_mentioned", []) if ctx.story else [])[:4]
                                                                               if c["relation"] != "consumer"]})
        if facts["validation_folder"] is None:
            hits = idx.search("validation validate check", k=5)
            vf = [h["path"].rsplit("/", 1)[0] for h in hits if re.search(r"valid|check|test", h["path"].lower())]
            if vf:
                facts["validation_folder"] = {"folder": vf[0], "example_files": [h["path"] for h in hits if h["path"].startswith(vf[0])][:3]}
    return facts


class CoderAgent(Agent):
    name = "coder_agent"
    SCHEMA = obj({"path": S, "language": S, "content": S, "edits": arr(obj({"find": S, "replace": S}, ["find", "replace"])),
                  "explanation": S, "assumptions": arr(S), "confidence": I}, ["path", "language", "explanation"])

    def __init__(self, ctx):
        super().__init__(ctx, T.all_tools(ctx), self.SCHEMA, _prompt("coder_agent"))
        self._key_extra = None

    def _key(self, task, prefix) -> str:
        """Per-file cache: the same file spec + the same repository file + the same rules / design / sibling + the same findings
        gives the same code, whatever the other files of the plan were. The volatile parts (other generated files, the plan's
        file list) are left out, so a re-run after answering an open question regenerates only the files whose entry changed."""
        import hashlib
        stable = {k: v for k, v in task.items() if k not in ("other_generated_files", "existing_excerpts", "existing_stats")}
        h = hashlib.sha256()
        for part in (self.name, self.ctx.cfg.llm["deployment"], self.system_prompt(), stable, self._key_extra, sorted(self.tools)):
            h.update(json.dumps(part, sort_keys=True, ensure_ascii=False, default=str).encode())
        return h.hexdigest()[:40]

    def ground(self, r, task):
        errs = []
        mode = task.get("mode")
        # the file as it stands NOW (full text, also for large files whose text is not in the task)
        existing = getattr(self, "_existing_full", None)
        if existing is None:
            existing = task.get("existing_content")
        big = bool(task.get("existing_file_is_large"))
        if r.get("edits"):
            if existing is None:
                errs.append("edits given but there is no existing file - return full content")
            else:
                new = existing
                for e in r["edits"]:
                    n = new.count(e["find"])
                    if n == 0:
                        errs.append(f"edit anchor not found verbatim in the file (copy it from read_file / existing_excerpts): {e['find'][:80]!r}")
                        continue
                    if n > 1:
                        errs.append(f"edit anchor occurs {n} times - make it unique (add the surrounding line): {e['find'][:80]!r}")
                        continue
                    new = new.replace(e["find"], e["replace"], 1)
                if not errs:
                    r["content"] = new
        elif big and existing is not None:
            # a large file must be changed by edits: a rewritten 'content' is where whole DAGs get lost
            errs.append("the existing file is large: return `edits` = [{find, replace}] with unique anchors copied verbatim "
                        "(use read_file / grep_repo or existing_excerpts to see the exact lines) - do NOT return a rewritten content")
        if not r.get("content", "").strip():
            errs.append("content is empty")
        # a modify never throws the file away: lines of the repository file that disappear are a rewrite, not a change
        if existing is not None and r.get("content") and mode in ("modify", "fix") and not errs:
            old_lines = [l for l in existing.splitlines() if l.strip()]
            new_set = set(l.strip() for l in r["content"].splitlines())
            gone = [l for l in old_lines if l.strip() not in new_set]
            limit = max(40, int(len(old_lines) * float(self.ctx.cfg.get("generation", {}).get("max_removed_fraction", 0.2))))
            if len(gone) > limit:
                errs.append(f"{len(gone)} of {len(old_lines)} existing lines are missing from the result - a modify keeps the whole file and "
                            "adds / changes only what the story needs. Return edits [{find, replace}] against the file as it is "
                            f"(first missing lines: {' | '.join(l.strip()[:60] for l in gone[:3])})")
        if r.get("content") and task.get("path") and r.get("path") != task.get("path"):
            r["path"] = task["path"]
        from ..validators import validate_file
        if r.get("content") and not errs:
            base = getattr(self, "_repo_content", None)          # the file as it is in the repository (modify / fix of a modified file)
            fnd = [f for f in validate_file(r["path"], r["content"], r.get("language", ""), self.ctx.rules, existing=base)
                   if f["severity"] in ("critical", "high") and f["kind"] in ("syntax",)]
            errs += [f"{f['kind']}: {f['message']}" + (f" (line {f['line']})" if f.get("line") else "") for f in fnd[:8]]
        if mode == "fix" and r.get("content") == existing:
            errs.append("fix mode: the content is unchanged - apply the findings")
        return r, errs

    def write(self, spec: dict, existing_content=None, mode: str = "create", findings: List[dict] = None, request: str = "") -> dict:
        gen = self.ctx.cfg.get("generation", {})
        limit = int(gen.get("edits_above_chars_fix", 8000)) if mode == "fix" else int(gen.get("edits_above_chars", 40000))
        big = existing_content is not None and len(existing_content) > limit
        self._existing_full = existing_content                      # full text for grounding, even when the task carries only excerpts
        self._repo_content = next((idx.read(spec["path"], 10 ** 7) for idx in self.ctx.inputs.indexes()
                                   if (not spec.get("repo") or idx.name == spec.get("repo")) and spec["path"] in idx.files), None)
        blocks = [{"index": i, "language": b.get("language", ""), "code": b.get("code", "")[:6000]}
                  for i, b in enumerate((self.ctx.pack.get("story") or {}).get("code_blocks") or [], 1)]
        design = (self.ctx.plan or {}).get("design") or {}
        budget = int(self.ctx.cfg.get("llm", {}).get("coder_context_chars", 8000))
        # SHARED context, identical for every file of the run -> sent as a prefix so Azure's prompt cache serves it from the
        # second file on (the per-file task below stays small). Order matters: static first, file-specific last.
        rules = []
        for r_ in (self.ctx.rules or [])[:40]:
            rules.append({"id": r_.get("id"), "languages": r_.get("languages"), "kind": "REQUIRED in every file of these languages" if r_.get("must_match") else "FORBIDDEN",
                          "what": r_.get("message"), "pattern": str(r_.get("pattern", ""))[:120], "applies_to": r_.get("applies_to"), "exempt": r_.get("exempt")})
        shared = {"story": {k: self.ctx.story.get(k) for k in ("summary", "goal", "functional_requirements", "business_rules", "acceptance_criteria")},
                  "story_code_blocks": blocks, "design": design,
                  "validator_rules_checklist": rules,          # the validator checks exactly these: satisfy them in the FIRST write
                  "knowledge": _trim(self.ctx.knowledge, budget), "data": _trim(self.ctx.data, budget), "repo_guidance": _trim(self.ctx.repo, budget),
                  "registration_changes": (self.ctx.plan or {}).get("registration_changes", []),
                  "plan_files": [{"path": f["path"], "purpose": f["purpose"]} for f in self.ctx.plan.get("files", [])],
                  "user_instructions": self.ctx.pack.get("instructions", [])}
        prefix = "SHARED CONTEXT FOR EVERY FILE OF THIS RUN:\n" + json.dumps(shared, ensure_ascii=False, default=str)
        self._key_extra = {k: shared[k] for k in ("story", "story_code_blocks", "design", "validator_rules_checklist", "knowledge", "data", "repo_guidance", "user_instructions")}
        import hashlib as _hl
        self._key_extra["existing_sha"] = _hl.sha256((existing_content or "").encode("utf-8", "replace")).hexdigest()[:16]
        others = {}
        total = 0
        for pth, v in self.ctx.files.items():                       # other generated files: only what this file depends on, capped
            if pth == spec["path"]:
                continue
            if pth in (spec.get("depends_on") or []) or total < 6000:
                ex = v["content"][:1500]
                others[pth] = ex
                total += len(ex)
        sibling = None
        if mode == "create":
            sibling = _sibling_example(self.ctx, spec)
        task = {"mode": mode, "path": spec["path"], "language": spec.get("language", ""), "purpose": spec.get("purpose", ""),
                "sibling_example": sibling,                       # head + tail of the closest existing file: copy its header, parameters, ending (OWNER / GRANT / DISTRIBUTED BY)
                "outline": spec.get("outline", []), "repo": spec.get("repo", ""),
                "requirements_covered": spec.get("requirements_covered", []),
                "story_code_usage_for_this_file": [u for u in design.get("story_code_usage", []) if spec["path"] in str(u.get("used_in", ""))],
                "other_generated_files": others,
                "existing_content": existing_content if (existing_content is not None and not big) else None,
                "existing_file_is_large": big, "existing_head": existing_content[:4000] if big else None,
                "existing_excerpts": _excerpts(existing_content, spec, findings) if big else None,
                "existing_stats": {"lines": existing_content.count("\n") + 1, "chars": len(existing_content)} if existing_content is not None else None,
                "findings_to_fix": findings or [], "change_request": request,
                "output_rule": ("return `edits` [{find, replace}] with small UNIQUE anchors copied verbatim" if big else "return the complete file in `content`")}
        if mode == "fix" and big:
            task["existing_content"] = None
            task["output_rule"] = "the file is large: return `edits` [{find, replace}] against the CURRENT file (anchors verbatim from existing_excerpts / read_file)"
        r = self.run(task, prefix=prefix, task_label=f"{mode} {spec['path']}")
        if big and existing_content is not None and r.get("edits") and not r.get("content"):
            new = existing_content
            for e in r["edits"]:
                new = new.replace(e["find"], e["replace"], 1)
            r["content"] = new
        if existing_content is not None and mode in ("modify", "fix"):
            # last line of defence (the grounding may have been exhausted): never hand back an empty or gutted file
            old_lines = [l for l in existing_content.splitlines() if l.strip()]
            new_set = set(l.strip() for l in (r.get("content") or "").splitlines())
            gone = sum(1 for l in old_lines if l.strip() not in new_set)
            limit = max(40, int(len(old_lines) * float(self.ctx.cfg.get("generation", {}).get("max_removed_fraction", 0.2))))
            if not (r.get("content") or "").strip() or gone > limit:
                r["content"] = existing_content
                r["confidence"] = 0
                r["unsafe"] = f"the coder returned an empty or rewritten file ({gone} of {len(old_lines)} lines missing); the repository version was kept"
                r["explanation"] = "NOT CHANGED: " + r["unsafe"] + ". " + (r.get("explanation") or "")
        return r


class ReviewerAgent(Agent):
    name = "reviewer_agent"
    strict = False
    SCHEMA = obj({"findings": arr(obj({"path": S, "severity": SEVERITY, "kind": S, "message": S, "suggestion": S}, ["path", "severity", "message"])),
                  "requirements_coverage": arr(obj({"requirement": S, "covered": B, "where": S})),
                  "story_code_check": arr(obj({"index": I, "respected": B, "note": S}, ["index", "respected"])),
                  "registration_check": obj({"ok": B, "note": S}, ["ok"]),
                  "impact_assessment": arr(obj({"change": S, "affects": S, "risk": SEVERITY, "mitigation": S}, ["change", "affects", "risk"])),
                  "performance_notes": arr(S), "standards_check": arr(obj({"rule": S, "ok": B, "where": S}, ["rule", "ok"])),
                  "score": I, "verdict": {"type": "string", "enum": ["approve", "fix_required", "reject"]}, "summary": S},
                 ["findings", "requirements_coverage", "story_code_check", "registration_check", "impact_assessment", "score", "verdict", "summary"])

    def __init__(self, ctx):
        super().__init__(ctx, T.all_tools(ctx), self.SCHEMA, _prompt("reviewer_agent"))

    def execute(self, validator_findings: List[dict], previous: Optional[dict] = None) -> dict:
        """previous = the last review of this chat with its file hashes: files whose content is unchanged since then are not
        re-read (their earlier findings are carried over); only changed / new files are reviewed. Nothing changed -> no call."""
        import difflib
        import hashlib
        hashes = {p: hashlib.sha256(v["content"].encode("utf-8", "replace")).hexdigest()[:16] for p, v in self.ctx.files.items()}
        prev_hashes = (previous or {}).get("file_hashes") or {}
        unchanged = [p for p, h in hashes.items() if prev_hashes.get(p) == h]
        changed = [p for p in hashes if p not in unchanged]
        carried = [f for f in (previous or {}).get("findings", []) or [] if f.get("path") in unchanged]
        if previous and not changed:
            rev = dict(previous)
            rev["file_hashes"] = hashes
            rev["incremental"] = {"reviewed": [], "carried_over": unchanged, "note": "no file changed since the last review - result reused"}
            self.ctx.trace.add(self.name, "review", 0, "cache", "", "nothing changed since the last review - reused")
            self.ctx.timings.append({"agent": self.name, "task": "review", "seconds": 0.0, "steps": 0, "fix_rounds": 0, "cached": True, "issues": 0})
            self.ctx.review = rev
            return rev
        files = {}
        for p, v in self.ctx.files.items():
            if p in unchanged:
                files[p] = {"shown_as": "UNCHANGED since the last review (not re-read); its earlier findings are listed in previous_findings_for_unchanged_files"}
                continue
            base = next((idx.read(p, 10 ** 7) for idx in self.ctx.inputs.indexes() if p in idx.files), None)
            if v.get("action") == "modify" and base is not None and len(v["content"]) > 6000:
                diff = "".join(difflib.unified_diff(base.splitlines(True), v["content"].splitlines(True), "repository/" + p, "generated/" + p, n=4))
                files[p] = {"shown_as": "unified diff against the repository version (unchanged lines omitted; use read_file for context)",
                            "head": v["content"][:1500], "diff": diff[:20000]}
            else:
                files[p] = v["content"][:15000]
        blocks = [{"index": i, "language": b.get("language", ""), "code": b.get("code", "")[:4000]}
                  for i, b in enumerate((self.ctx.pack.get("story") or {}).get("code_blocks") or [], 1)]
        task = {"story": self.ctx.story, "story_code_blocks": blocks, "knowledge": _trim(self.ctx.knowledge), "data": _trim(self.ctx.data),
                "repo_guidance": {k: (self.ctx.repo or {}).get(k) for k in ("registration_points", "companion_files", "impact", "conventions_observed")},
                "plan": {"approach": self.ctx.plan.get("approach"), "design": self.ctx.plan.get("design"),
                         "registration_changes": self.ctx.plan.get("registration_changes"),
                         "files": [{"path": f["path"], "purpose": f["purpose"], "requirements_covered": f.get("requirements_covered", [])} for f in self.ctx.plan.get("files", [])]},
                "files": files, "validator_findings": [f for f in validator_findings if f.get("path") in changed][:60],
                "previous_findings_for_unchanged_files": [{k: f.get(k) for k in ("path", "severity", "kind", "message", "status")} for f in carried][:40],
                "review_scope": {"review_these": changed, "unchanged_since_last_review": unchanged},
                "user_instructions": self.ctx.pack.get("instructions", [])}
        rev = self.run(task, task_label="review", use_cache=False)
        # merge: the reviewer's findings for the changed files + the carried-over findings of the unchanged ones
        new_f = [f for f in rev.get("findings", []) or [] if f.get("path") in changed or f.get("path") not in hashes]
        rev["findings"] = new_f + [dict(f) for f in carried]
        rev["file_hashes"] = hashes
        rev["incremental"] = {"reviewed": changed, "carried_over": unchanged}
        self.ctx.review = rev
        return rev


class ChangeAgent(Agent):
    name = "change_agent"
    SCHEMA = obj({"understanding": S, "changes": arr(obj({"path": S, "action": {"type": "string", "enum": ["create", "modify", "delete"]},
                                                        "language": S, "purpose": S, "instructions": arr(S)}, ["path", "action", "instructions"])),
                  "reply": S, "needs_clarification": B, "question": S}, ["understanding", "changes", "reply"])

    def __init__(self, ctx):
        super().__init__(ctx, T.all_tools(ctx), self.SCHEMA, _prompt("change_agent"))

    def execute(self, request: str, history: List[dict]) -> dict:
        task = {"request": request, "recent_conversation": history[-8:],
                "story": {k: self.ctx.story.get(k) for k in ("summary", "goal")},
                "current_files": {p: {"language": v.get("language"), "purpose": v.get("purpose"), "head": v["content"][:1500]} for p, v in self.ctx.files.items()},
                "plan_files": [{"path": f["path"], "purpose": f["purpose"], "language": f.get("language")} for f in self.ctx.plan.get("files", [])]}
        return self.run(task, task_label="change", use_cache=False)


def _sibling_example(ctx, spec: dict, head_chars: int = 2500, tail_chars: int = 1500) -> Optional[dict]:
    """The existing file most like the one to create (same folder, closest name; else same language nearby): its head and
    tail verbatim. Validation / registry conventions (header comment, parameters, DISTRIBUTED BY, OWNER, GRANT) live there."""
    path = spec["path"]
    folder = path.rsplit("/", 1)[0] if "/" in path else ""
    stem = set(Path(path).stem.lower().split("_"))
    lang = (spec.get("language") or "").lower()
    for idx in ctx.inputs.indexes():
        if spec.get("repo") and idx.name != spec.get("repo"):
            continue
        cands = [r for r in idx.files if (r.rsplit("/", 1)[0] if "/" in r else "") == folder and r != path]
        if not cands:
            cands = [r for r in idx.files if idx.files[r]["language"] == lang and r.startswith(folder.rsplit("/", 1)[0] if "/" in folder else "")]
        if not cands:
            continue
        cands.sort(key=lambda r: (-len(stem & set(Path(r).stem.lower().split("_"))), abs(idx.files[r]["chars"] - 4000)))
        best = cands[0]
        text = idx.read(best, 10 ** 6)
        return {"path": best, "head": text[:head_chars], "tail": text[-tail_chars:] if len(text) > head_chars + tail_chars else "",
                "lines": text.count("\n") + 1, "why": "closest sibling - copy its shape: header, parameters, statement order, ending"}
    return None


def _excerpts(text: str, spec: dict, findings=None, window: int = 25, max_chars: int = 9000) -> List[dict]:
    """Windows of a large file around the lines a change is most likely to touch: words of the purpose / outline (sibling
    folder and file stems, task ids) and the lines named in findings. Gives the coder verbatim anchors for its edits."""
    lines = text.splitlines()
    words = set()
    for src in [spec.get("purpose", "")] + list(spec.get("outline") or []):
        for w in re.findall(r"[A-Za-z_][A-Za-z0-9_]{5,}", str(src)):
            words.add(w.lower())
    for f in findings or []:
        for w in re.findall(r"[A-Za-z_][A-Za-z0-9_]{5,}", str(f.get("message", "")) + " " + str(f.get("suggestion", ""))):
            words.add(w.lower())
    stop = {"register", "exactly", "siblings", "folder", "script", "scripts", "existing", "registration", "example", "change", "nothing"}
    words -= stop
    hits = []
    for i, l in enumerate(lines):
        low = l.lower()
        score = sum(1 for w in words if w in low)
        if score:
            hits.append((score, i))
    for f in findings or []:
        if f.get("line"):
            hits.append((99, int(f["line"]) - 1))
    hits.sort(key=lambda x: -x[0])
    out, used, total = [], set(), 0
    for _, i in hits:
        a, b = max(0, i - window), min(len(lines), i + window)
        if any(a < y and x < b for x, y in used):
            continue
        chunk = "\n".join(lines[a:b])
        if total + len(chunk) > max_chars:
            break
        out.append({"from_line": a + 1, "to_line": b, "text": chunk})
        used.add((a, b))
        total += len(chunk)
    out.sort(key=lambda x: x["from_line"])
    return out


def _trim(d: dict, n: int = 12000) -> dict:
    """Shrink a context dict to about n chars of JSON WITHOUT breaking it: long strings are cut, long lists shortened,
    largest fields first, until it fits. (Cutting the serialized text and re-parsing it produced invalid JSON when the
    cut fell inside a nested object - 'JSONDecodeError: Expecting , delimiter'.)"""
    def size(x):
        return len(json.dumps(x, ensure_ascii=False, default=str))
    if size(d) <= n:
        return d
    d = json.loads(json.dumps(d, ensure_ascii=False, default=str))      # plain data, deep copy

    def shrink(x, budget):
        if isinstance(x, str):
            return x if len(x) <= budget else x[:max(budget - 15, 40)] + " ...(cut)"
        if isinstance(x, list):
            out = []
            for item in x:
                if size(out) >= budget:
                    out.append("...(%d more cut)" % (len(x) - len(out)))
                    break
                out.append(shrink(item, max(budget // 2, 200)))
            return out
        if isinstance(x, dict):
            keys = sorted(x, key=lambda k: -size(x[k]))
            for k in keys:
                if size(x) <= budget:
                    break
                x[k] = shrink(x[k], max(budget // 3, 200))
            return x
        return x
    for cut in (n, int(n * 0.8), int(n * 0.6), int(n * 0.4)):
        d = shrink(d, cut)
        if size(d) <= n:
            break
    d["_trimmed"] = "context shortened to fit the token budget; use read_file / search_repo / describe_table for the full detail"
    return d


def _guess_lang(path: str) -> str:
    from ..validators import language_of
    return language_of(path)
