"""Regression bench (#5): run N real stories through the engine with a knowledge pack and compare the PLANNED files with the
files the team's merged MR really touched. Prints precision / recall per story, quality, review verdict, seconds and cost;
writes bench/results/<name>_<timestamp>.json so two runs (before / after a config or pack change) can be compared.

    python app_server.py --bench bench/ikg.yaml                 # real model (keys from the environment / hidden prompt)
    python app_server.py --bench bench/ikg.yaml --scripted      # offline smoke run with the scripted model

bench/ikg.yaml:
    system: ikg
    pack: packs/ikg_pack.zip                 # or "prebuilt:ikg" (the template of the config)
    stories:
      - id: "2400"
        story: bench/stories/2400.md         # file (md / docx / pdf / txt) OR inline text under `text:`
        expected_files:                      # from the merged MR:  git diff --name-only ikg-master...2400-ikg-beneficiary-enrichment
          - dags/ikg/scripts/sql/ikg_create_profiles/beneficiary_profile_curr_ikg.sql
          - dags/ikg/scripts/sql/ikg_create_profiles_history/beneficiary_profile_ikg.sql
          - dags/ikg/dags/ikg_data_refresh.py
        expected_branch: 2400-ikg-beneficiary-enrichment    # optional
        notes: "what made this story hard"                  # optional, printed in the report

Matching is by repository path; a planned file whose BASENAME matches an expected one in another folder counts as a
"near miss" (reported separately) so a wrong folder is visible without hiding that the file itself was right.
"""
from __future__ import annotations

import json
import shutil
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List

import yaml


def _norm(p: str) -> str:
    return str(p or "").strip().strip("/").replace("\\", "/")


def _score(planned: List[str], expected: List[str]) -> Dict:
    P, E = {_norm(p) for p in planned}, {_norm(e) for e in expected}
    hit = P & E
    base_e = {Path(e).name: e for e in E - hit}
    near = sorted(p for p in P - hit if Path(p).name in base_e)
    precision = round(len(hit) / len(P), 2) if P else 0.0
    recall = round(len(hit) / len(E), 2) if E else 0.0
    return {"planned": sorted(P), "expected": sorted(E), "hit": sorted(hit), "missed": sorted(E - hit), "extra": sorted(P - hit - set(near)),
            "near_miss": near, "precision": precision, "recall": recall,
            "f1": round(2 * precision * recall / (precision + recall), 2) if precision + recall else 0.0}


def run_bench(cfg, spec_path: Path, out_dir: Path, scripted: bool = False, progress=print) -> dict:
    from .engine import ChatSession
    spec = yaml.safe_load(Path(spec_path).read_text(encoding="utf-8")) or {}
    system = str(spec.get("system") or "")
    stories = spec.get("stories") or []
    if not stories:
        raise SystemExit(f"{spec_path}: no stories")
    name = Path(spec_path).stem
    out_dir.mkdir(parents=True, exist_ok=True)
    if scripted:
        from .selftest import ScriptedLLM
        llm = ScriptedLLM(cfg, out_dir / "cache")
    else:
        from .llm import LLM
        llm = LLM(cfg, cfg.path(cfg.storage.get("llm_cache_dir", "data/cache/llm")))
    # the pack: a zip path or "prebuilt:<template id>"
    pack_ref = str(spec.get("pack") or "")
    kp = cfg.get("knowledge_packs") or {}
    gd = {}
    if pack_ref.startswith("prebuilt:"):
        t = next((t for t in kp.get("templates") or [] if t.get("id") == pack_ref.split(":", 1)[1]), None)
        if not t:
            raise SystemExit(f"unknown prebuilt template {pack_ref}")
        pack_path = cfg.path(kp.get("dir", "packs")) / t["pack"]
        gd = {k: t.get(k) for k in ("system", "base_branch", "mr_target", "branch_template")}
    else:
        pack_path = Path(pack_ref) if Path(pack_ref).is_absolute() else cfg.path(pack_ref)
        gd = {"system": system}
    if not pack_path.exists():
        raise SystemExit(f"pack not found: {pack_path}")
    pack_bytes = pack_path.read_bytes()
    base = Path(spec_path).parent
    results, t_all = [], time.time()
    for i, st in enumerate(stories, 1):
        sid = str(st.get("id") or i)
        progress(f"[{i}/{len(stories)}] story {sid} ...")
        chat_dir = out_dir / f"{name}_{sid}"
        shutil.rmtree(chat_dir, ignore_errors=True)
        c = ChatSession(cfg, llm, chat_dir, "bench", f"{name}-{sid}")
        if st.get("text"):
            c.set_story_text(str(st["text"]), title=str(st.get("title") or f"story {sid}"), story_id=sid)
        else:
            sp = Path(st["story"]) if Path(st["story"]).is_absolute() else base / st["story"]
            c.set_story_from_file(sp.name, sp.read_bytes())
            if sid and c.inputs.story and not c.inputs.story.get("id"):
                c.inputs.story["id"] = sid
        c.attach_pack(pack_path.name, pack_bytes)
        if gd:
            c.inputs.set_git_defaults(**gd)
        t0 = time.time()
        before = (llm.token_stats().get("total") or {}).get("cost_usd", 0) if hasattr(llm, "token_stats") else 0
        err = ""
        try:
            c.run("")
        except Exception as e:  # noqa: BLE001
            err = f"{type(e).__name__}: {str(e)[:200]}"
        after = (llm.token_stats().get("total") or {}).get("cost_usd", 0) if hasattr(llm, "token_stats") else 0
        # planned = the planner's list as saved right after planning (plan.json); delivered = what really ended in the output
        # (a modify the coder found unnecessary is dropped from the output - that is visible as the gap between the two)
        try:
            plan_files = [f["path"] for f in (json.loads((chat_dir / "plan.json").read_text(encoding="utf-8")) or {}).get("files", [])]
        except Exception:  # noqa: BLE001
            plan_files = [f["path"] for f in (c.plan or {}).get("files", [])]
        produced = list((c.files or {}).keys())
        sc = _score(plan_files or produced, st.get("expected_files") or [])
        delivered = _score(produced, st.get("expected_files") or [])
        sc["delivered_recall"], sc["delivered_precision"] = delivered["recall"], delivered["precision"]
        summ = c.summary or {}
        branch = ""
        try:
            branch = c.git_conventions().get("branch", "")
        except Exception:  # noqa: BLE001
            pass
        r = {"id": sid, "title": (c.inputs.story or {}).get("title", ""), "error": err, "seconds": round(time.time() - t0, 1),
             "cost_usd": round((after or 0) - (before or 0), 4), "quality_score": summ.get("quality_score"), "confidence": (summ.get("confidence") or {}).get("grade"),
             "review": (summ.get("review") or {}).get("verdict"), "files_produced": len(produced), "branch": branch,
             "branch_ok": (branch == st["expected_branch"]) if st.get("expected_branch") else None, "notes": st.get("notes", ""),
             "timings": [{k: t.get(k) for k in ("agent", "task", "seconds", "steps", "fix_rounds")} for t in (c.ctx.timings if c.ctx else [])], **sc}
        results.append(r)
        progress(f"    planned: precision {r['precision']}  recall {r['recall']}  f1 {r['f1']}  |  delivered: precision {r['delivered_precision']}  recall {r['delivered_recall']}  |  quality {r['quality_score']}  review {r['review']}  "
                 f"{r['seconds']}s  {r['cost_usd']} USD" + (f"  ERROR {err}" if err else ""))
        if sc["missed"]:
            progress("    missed : " + ", ".join(sc["missed"]))
        if sc["extra"]:
            progress("    extra  : " + ", ".join(sc["extra"]))
        if sc["near_miss"]:
            progress("    near   : " + ", ".join(sc["near_miss"]) + "   (right file, wrong folder)")
    n = len(results)
    agg = {"stories": n, "precision": round(sum(r["precision"] for r in results) / n, 2), "recall": round(sum(r["recall"] for r in results) / n, 2),
           "f1": round(sum(r["f1"] for r in results) / n, 2), "seconds": round(sum(r["seconds"] for r in results), 1),
           "cost_usd": round(sum(r["cost_usd"] for r in results), 4), "errors": sum(1 for r in results if r["error"]),
           "review_pass": sum(1 for r in results if str(r.get("review") or "").lower() in ("approve", "approved", "pass", "ok", "mergeable"))}
    report = {"bench": name, "system": system, "pack": str(pack_path), "pack_version": _pack_version(pack_path), "scripted": scripted,
              "model": {"deployment": cfg.llm.get("deployment"), "agents": (cfg.get("agents") or {}).get("deployment")},
              "started": datetime.fromtimestamp(t_all).strftime("%Y-%m-%d %H:%M:%S"), "total_seconds": round(time.time() - t_all, 1), "aggregate": agg, "results": results}
    rp = out_dir / f"{name}_{datetime.now():%Y%m%d_%H%M%S}.json"
    rp.write_text(json.dumps(report, indent=1, ensure_ascii=False), encoding="utf-8")
    progress(f"\n{name}: {n} stories  precision {agg['precision']}  recall {agg['recall']}  f1 {agg['f1']}  {agg['seconds']}s  {agg['cost_usd']} USD  "
             f"errors {agg['errors']}  ->  {rp}")
    return report


def _pack_version(zp: Path) -> str:
    try:
        import zipfile
        with zipfile.ZipFile(zp) as zf:
            v = next((n for n in zf.namelist() if n.endswith("/VERSION.txt")), None)
            return zf.read(v).decode("utf-8", "replace").splitlines()[0].strip() if v else ""
    except Exception:  # noqa: BLE001
        return ""


def compare(a: Path, b: Path) -> str:
    """Side-by-side of two result files: `python app_server.py --bench-compare before.json after.json`."""
    A, B = json.loads(Path(a).read_text(encoding="utf-8")), json.loads(Path(b).read_text(encoding="utf-8"))
    ra, rb = {r["id"]: r for r in A["results"]}, {r["id"]: r for r in B["results"]}
    lines = [f"{'story':<10}{'prec A':>8}{'prec B':>8}{'rec A':>8}{'rec B':>8}{'sec A':>8}{'sec B':>8}{'usd A':>9}{'usd B':>9}"]
    for k in sorted(set(ra) | set(rb)):
        x, y = ra.get(k, {}), rb.get(k, {})
        lines.append(f"{k:<10}{x.get('precision', '-'):>8}{y.get('precision', '-'):>8}{x.get('recall', '-'):>8}{y.get('recall', '-'):>8}"
                     f"{x.get('seconds', '-'):>8}{y.get('seconds', '-'):>8}{x.get('cost_usd', '-'):>9}{y.get('cost_usd', '-'):>9}")
    ga, gb = A["aggregate"], B["aggregate"]
    lines.append(f"{'ALL':<10}{ga['precision']:>8}{gb['precision']:>8}{ga['recall']:>8}{gb['recall']:>8}{ga['seconds']:>8}{gb['seconds']:>8}{ga['cost_usd']:>9}{gb['cost_usd']:>9}")
    return "\n".join(lines)
