"""Git hosting client (GitLab and GitHub REST APIs) with the USER's token - nothing is stored.

  * parse any project URL  -> provider, api base, project path
  * issues                 -> a story by number (title, description, comments, code blocks, attachments)
  * repository             -> archive download at a branch (code files only), single file read, branch list
  * publish                -> create a branch from a base branch and commit all files under the user's identity
"""
from __future__ import annotations

import io
import logging
import os
import subprocess
import re
import shutil
import time
import zipfile
from pathlib import Path
from typing import Dict, List, Optional
from urllib.parse import quote, urlparse

log = logging.getLogger(__name__)


def extract_code_blocks(text: str, where: str) -> List[dict]:
    out = []
    for m in re.finditer(r"```([a-zA-Z0-9_+-]*)\n(.*?)```", text or "", flags=re.S):
        code = m.group(2).strip()
        if len(code) > 20:
            lang = (m.group(1) or "").lower() or ("sql" if re.search(r"(?i)\b(select|insert|create|with)\b", code) else "text")
            out.append({"where": where, "language": lang, "code": code})
    return out


def parse_project_url(url: str, default_provider: str = "gitlab") -> dict:
    """https://devcloud.ubs.net/group/sub/project(.git)?(/-/tree/branch)? -> {provider, host, base, project, branch}"""
    u = urlparse(url.strip())
    if not u.scheme:
        u = urlparse("https://" + url.strip())
    host = u.netloc
    path = u.path.strip("/")
    branch = ""
    issue = ""
    m = re.search(r"/-/(tree|blob|issues|merge_requests)/(.*)$", "/" + path)
    if m:
        kind, rest = m.group(1), m.group(2)
        path = path[: path.index("/-/")]
        if kind in ("tree", "blob"):
            branch = rest.split("/")[0]
        elif kind == "issues":
            issue = rest.split("/")[0]
    mg = re.search(r"^([^/]+/[^/]+)/(tree|blob|issues)/(.*)$", path)
    if "github" in host and mg:
        path = mg.group(1)
        if mg.group(2) in ("tree", "blob"):
            branch = mg.group(3).split("/")[0]
        else:
            issue = mg.group(3).split("/")[0]
    if path.endswith(".git"):
        path = path[:-4]
    provider = "github" if "github" in host else ("gitlab" if "gitlab" in host else default_provider)
    base = f"https://api.github.com" if provider == "github" else f"{u.scheme}://{host}/api/v4"
    return {"provider": provider, "host": host, "web": f"{u.scheme}://{host}", "base": base, "project": path,
            "branch": branch, "issue": issue, "url": url.strip()}


class GitClient:
    def __init__(self, project_url: str, token: str, ssl_verify=True, default_provider: str = "gitlab"):
        self.info = parse_project_url(project_url, default_provider)
        self.provider = self.info["provider"]
        self.base = self.info["base"]
        self.project = self.info["project"]
        self.token = token or ""
        self.verify = ssl_verify
        self._s = None

    # ------------------------------------------------------------------ http
    @property
    def s(self):
        if self._s is None:
            import requests
            self._s = requests.Session()
            if self.provider == "github":
                self._s.headers.update({"Authorization": f"Bearer {self.token}", "Accept": "application/vnd.github+json"})
            else:
                self._s.headers["PRIVATE-TOKEN"] = self.token
            self._s.verify = self.verify
        return self._s

    def _proj(self) -> str:
        if self.provider == "github":
            return f"{self.base}/repos/{self.project}"
        return f"{self.base}/projects/{quote(self.project, safe='')}"

    def _get(self, url: str, **params):
        r = self.s.get(url, params=params, timeout=120)
        r.raise_for_status()
        return r.json()

    def whoami(self) -> dict:
        u = self._get(f"{self.base}/user")
        return {"username": u.get("username") or u.get("login"), "name": u.get("name", ""), "email": u.get("email", "")}

    def project_info(self) -> dict:
        p = self._get(self._proj())
        return {"name": p.get("name", ""), "default_branch": p.get("default_branch", ""),
                "web_url": p.get("web_url") or p.get("html_url", ""), "id": p.get("id")}

    # ------------------------------------------------------------------ issues (stories)
    def issue(self, number) -> dict:
        n = int(str(number).lstrip("#"))
        if self.provider == "github":
            it = self._get(f"{self._proj()}/issues/{n}")
            notes = [{"author": (c.get("user") or {}).get("login", ""), "created": c.get("created_at", ""), "body": c.get("body", "")}
                     for c in self._get(f"{self._proj()}/issues/{n}/comments", per_page=100)]
            desc = it.get("body") or ""
            labels = [l.get("name") for l in it.get("labels", [])]
            url = it.get("html_url", "")
        else:
            it = self._get(f"{self._proj()}/issues/{n}")
            notes = []
            try:
                notes = [{"author": (x.get("author") or {}).get("name", ""), "created": x.get("created_at", ""), "body": x.get("body", "")}
                         for x in self._get(f"{self._proj()}/issues/{n}/notes", per_page=100, sort="asc") if not x.get("system")]
            except Exception as e:  # noqa: BLE001
                log.warning("issue notes not readable: %s", e)
            desc = it.get("description") or ""
            labels = it.get("labels", [])
            url = it.get("web_url", "")
        attachments = re.findall(r"\[([^\]]*)\]\((/uploads/[^)]+)\)", desc)
        blocks = extract_code_blocks(desc, "description") + [b for x in notes for b in extract_code_blocks(x["body"], f"comment by {x['author']}")]
        return {"id": str(it.get("iid") or it.get("number") or n), "title": it.get("title", ""), "description": desc,
                "labels": labels, "state": it.get("state"), "web_url": url,
                "assignees": [a.get("name") or a.get("login") for a in it.get("assignees", [])],
                "notes": notes, "code_blocks": blocks,
                "attachments": [{"name": a, "url": self.info["web"] + "/" + self.project + u} for a, u in attachments]}

    # ------------------------------------------------------------------ repository
    def branches(self, limit: int = 100) -> List[str]:
        rows = self._get(f"{self._proj()}/branches", per_page=limit) if self.provider == "github" else \
            self._get(f"{self._proj()}/repository/branches", per_page=limit)
        return [b["name"] for b in rows]

    def file(self, path: str, ref: str) -> str:
        if self.provider == "github":
            r = self.s.get(f"{self._proj()}/contents/{quote(path)}", params={"ref": ref},
                           headers={"Accept": "application/vnd.github.raw"}, timeout=120)
        else:
            r = self.s.get(f"{self._proj()}/repository/files/{quote(path, safe='')}/raw", params={"ref": ref}, timeout=120)
        r.raise_for_status()
        return r.text

    # ------------------------------------------------------------------ fast path: git CLI (shallow, sparse, incremental)
    def _git_env_and_args(self):
        import base64
        env = dict(os.environ, GIT_TERMINAL_PROMPT="0", GIT_ASKPASS="")
        args = ["-c", "credential.helper=", "-c", f"http.extraHeader=Authorization: Basic " +
                base64.b64encode(f"oauth2:{self.token}".encode()).decode()]   # per-command only: never written to .git/config
        if self.provider == "github":
            args[-1] = "http.extraHeader=Authorization: Basic " + base64.b64encode(f"x-access-token:{self.token}".encode()).decode()
        if self.verify is False:
            args += ["-c", "http.sslVerify=false"]
        elif isinstance(self.verify, str):
            args += ["-c", f"http.sslCAInfo={self.verify}"]
        return env, args

    def git_sync(self, dest: Path, ref: str, subpath: str = "", refresh: bool = False, progress=None) -> Optional[dict]:
        """Shallow (depth 1), blob-filtered, sparse checkout of `subpath` at `ref` with the git CLI; a later call on the same
        folder is an incremental fetch (seconds). Returns None when git is unavailable or fails (the archive path is used)."""
        git = shutil.which("git")
        if not git:
            return None
        say = progress or (lambda m: None)
        dest = Path(dest)
        env, args = self._git_env_and_args()
        url = getattr(self, "clone_url", "") or f"{self.info['web']}/{self.project}.git"
        workdir = dest / ".git_checkout"

        def run(*cmd, cwd=None, timeout=900):
            r = subprocess.run([git, *args, *cmd], cwd=str(cwd) if cwd else None, env=env, capture_output=True, text=True, timeout=timeout)
            if r.returncode != 0:
                raise RuntimeError((r.stderr or r.stdout).strip()[-400:])
            return r.stdout
        try:
            t0 = time.time()
            if (workdir / ".git").exists():
                say(f"git fetch {ref} (incremental) ...")
                run("fetch", "--depth", "1", "origin", ref, cwd=workdir, timeout=600)
                run("reset", "--hard", "FETCH_HEAD", cwd=workdir)
            else:
                if workdir.exists():
                    shutil.rmtree(workdir)
                workdir.parent.mkdir(parents=True, exist_ok=True)
                say(f"git clone --depth 1 {self.project}@{ref}" + (f" (sparse: {subpath})" if subpath else "") + " ...")
                clone = ["clone", "--depth", "1", "--single-branch", "--branch", ref, "--no-tags", "--filter=blob:none", "--quiet"]
                if subpath:
                    clone.append("--sparse")
                run(*clone, url, str(workdir), timeout=900)
                if subpath:
                    run("sparse-checkout", "set", "--no-cone", subpath, cwd=workdir, timeout=600)
            say(f"git checkout ready in {time.time() - t0:.0f}s - collecting code files ...")
            return {"workdir": workdir}
        except Exception as e:  # noqa: BLE001
            log.warning("git CLI path failed (%s) - falling back to the archive download", str(e)[:200])
            return None

    def download(self, dest: Path, ref: str, extensions: List[str], max_file_kb: int = 400, max_files: int = 6000,
                 cache_hours: float = 24, refresh: bool = False, subpath: str = "", progress=None, use_git_cli: bool = True) -> dict:
        """Code of the repository at `ref` -> dest/ (code files only). Reused for cache_hours; `refresh` = re-sync.
        Fast path: git CLI shallow + sparse checkout (incremental on refresh); fallback: the archive download."""
        dest = Path(dest)
        marker = dest / ".agiledev_ref"
        if dest.exists() and marker.exists() and not refresh:
            ref_c, ts = (marker.read_text().split("\n") + ["0"])[:2]
            if ref_c == ref and (time.time() - float(ts or 0)) / 3600 <= cache_hours:
                n = sum(1 for _ in dest.rglob("*") if _.is_file() and ".git_checkout" not in _.parts) - 1
                return {"path": str(dest), "files": n, "cached": True, "ref": ref}
        say = progress or (lambda msg: None)
        exts = tuple("." + e.lower().lstrip(".") for e in extensions)
        g = self.git_sync(dest, ref, subpath, refresh, progress) if use_git_cli else None
        if g:
            # copy the code files out of the checkout (the index and the agents only ever see dest/, never .git)
            for child in list(dest.iterdir()):
                if child.name not in (".git_checkout", ".agiledev_ref", ".agiledev_index.pkl"):
                    shutil.rmtree(child) if child.is_dir() else child.unlink()
            n, skipped = 0, 0
            for p in g["workdir"].rglob("*"):
                if not p.is_file() or ".git" in p.relative_to(g["workdir"]).parts:
                    continue
                rel = p.relative_to(g["workdir"])
                if not str(rel).lower().endswith(exts):
                    continue
                if p.stat().st_size > max_file_kb * 1024 or n >= max_files:
                    skipped += 1
                    continue
                target = dest / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(p, target)
                n += 1
            marker.write_text(f"{ref}\n{time.time()}")
            say(f"{n} code files ready ({skipped} skipped) - indexing ...")
            log.info("%s@%s: %d files via git (%d skipped)", self.project, ref, n, skipped)
            return {"path": str(dest), "files": n, "skipped": skipped, "cached": False, "ref": ref, "via": "git"}
        if dest.exists():
            shutil.rmtree(dest)
        dest.mkdir(parents=True)
        say(f"requesting the archive of {self.project}@{ref}" + (f" ({subpath})" if subpath else "") + " ...")
        if self.provider == "github":
            r = self.s.get(f"{self._proj()}/zipball/{quote(ref, safe='')}", timeout=900, stream=True)
        else:
            params = {"sha": ref}
            if subpath:
                params["path"] = subpath
            r = self.s.get(f"{self._proj()}/repository/archive.zip", params=params, timeout=900, stream=True)
        r.raise_for_status()
        buf, got, t0 = io.BytesIO(), 0, time.time()
        for chunk in r.iter_content(chunk_size=1 << 18):
            if chunk:
                buf.write(chunk)
                got += len(chunk)
                if time.time() - t0 > 1.5:
                    say(f"downloading ... {got / 1048576:.1f} MB")
                    t0 = time.time()
        say(f"downloaded {got / 1048576:.1f} MB - extracting code files ...")
        exts = tuple("." + e.lower().lstrip(".") for e in extensions)
        n, skipped = 0, 0
        with zipfile.ZipFile(buf) as z:
            for m in z.infolist():
                if m.is_dir():
                    continue
                rel = m.filename.split("/", 1)[-1]
                if not rel or not rel.lower().endswith(exts) or "/." in "/" + rel:
                    continue
                if m.file_size > max_file_kb * 1024:
                    skipped += 1
                    continue
                if n >= max_files:
                    skipped += 1
                    continue
                p = dest / rel
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_bytes(z.read(m))
                n += 1
        marker.write_text(f"{ref}\n{time.time()}")
        say(f"{n} code files extracted ({skipped} skipped) - indexing ...")
        log.info("%s@%s: %d files downloaded (%d skipped)", self.project, ref, n, skipped)
        return {"path": str(dest), "files": n, "skipped": skipped, "cached": False, "ref": ref}

    # ------------------------------------------------------------------ publish (user's token)
    @staticmethod
    def branch_name(template: str, story_id: str, repo: str, feature: str, max_len: int = 80) -> str:
        def slug(x):
            x = re.sub(r"[^a-z0-9]+", "-", str(x).lower()).strip("-")
            return re.sub(r"-+", "-", x)
        name = template.format(story_id=slug(story_id) or "story", repo=slug(repo), feature=slug(feature)[:40] or "change")
        return name[:max_len].rstrip("-")

    def branch_exists(self, branch: str) -> bool:
        if self.provider == "github":
            r = self.s.get(f"{self._proj()}/branches/{quote(branch, safe='')}", timeout=60)
        else:
            r = self.s.get(f"{self._proj()}/repository/branches/{quote(branch, safe='')}", timeout=60)
        return r.status_code == 200

    def create_branch(self, branch: str, base: str) -> dict:
        if self.provider == "github":
            ref = self._get(f"{self._proj()}/git/ref/heads/{quote(base, safe='')}")
            r = self.s.post(f"{self._proj()}/git/refs", json={"ref": f"refs/heads/{branch}", "sha": ref["object"]["sha"]}, timeout=120)
        else:
            r = self.s.post(f"{self._proj()}/repository/branches", data={"branch": branch, "ref": base}, timeout=120)
        r.raise_for_status()
        return r.json()

    def _exists(self, path: str, ref: str) -> bool:
        if self.provider == "github":
            r = self.s.get(f"{self._proj()}/contents/{quote(path)}", params={"ref": ref}, timeout=60)
        else:
            r = self.s.head(f"{self._proj()}/repository/files/{quote(path, safe='')}", params={"ref": ref}, timeout=60)
        return r.status_code == 200

    def commit(self, branch: str, message: str, files: Dict[str, str], author: Optional[dict] = None) -> dict:
        if self.provider == "github":
            import base64
            last = {}
            for p, c in files.items():
                body = {"message": message, "content": base64.b64encode(c.encode("utf-8")).decode(), "branch": branch}
                r = self.s.get(f"{self._proj()}/contents/{quote(p)}", params={"ref": branch}, timeout=60)
                if r.status_code == 200:
                    body["sha"] = r.json().get("sha")
                r2 = self.s.put(f"{self._proj()}/contents/{quote(p)}", json=body, timeout=120)
                r2.raise_for_status()
                last = r2.json().get("commit", {})
            return {"id": last.get("sha", ""), "web_url": last.get("html_url", ""),
                    "branch_url": f"{self.info['web']}/{self.project}/tree/{branch}"}
        actions = [{"action": "update" if self._exists(p, branch) else "create", "file_path": p, "content": c}
                   for p, c in files.items()]
        body = {"branch": branch, "commit_message": message, "actions": actions}
        if author and author.get("email"):
            body["author_email"], body["author_name"] = author["email"], author.get("name", author["email"])
        r = self.s.post(f"{self._proj()}/repository/commits", json=body, timeout=300)
        r.raise_for_status()
        j = r.json()
        j["branch_url"] = f"{self.info['web']}/{self.project}/-/tree/{branch}"
        return j

    def publish(self, branch: str, base_branch: str, message: str, files: Dict[str, str], author: Optional[dict] = None) -> dict:
        created = False
        if not self.branch_exists(branch):
            self.create_branch(branch, base_branch)
            created = True
        c = self.commit(branch, message, files, author)
        return {"provider": self.provider, "project": self.project, "branch": branch, "base_branch": base_branch,
                "branch_created": created, "files": len(files), "commit": str(c.get("id", ""))[:12],
                "branch_url": c.get("branch_url", ""), "commit_url": c.get("web_url", "")}
