"""
column_lineage_tab.py
─────────────────────
Dash tab that lets the user select a target_column from
ikg_column_lineage_master_auto_refresh, then a target_table that contains
that column, and renders a full upstream + downstream column lineage graph in
the same interactive canvas style as the Table Lineage (ER) tab.

Follow the exact same architecture as table_lineage_er_tab.py:
  layout()               → returns dcc.Tab
  register_callbacks()   → Dash callbacks (cascading dropdowns + iframe src)
  register_server_routes() → Flask route that serves rendered HTML
"""
import json
import re
import urllib.parse
from pathlib import Path

import pandas as pd
from dash import Input, Output, State, dcc, html, no_update
from flask import request
from styles import metadata_dashboard_styles as mds
from utils.data import (
    get_all_target_columns,
    get_column_lineage_downstream,
    get_column_lineage_upstream,
    get_tables_for_column,
)

# ─────────────────────────────────────────────────────────────────────────────
# Constants
# ─────────────────────────────────────────────────────────────────────────────
_NODE_W   = 230
_NODE_H   = 54   # header (30) + column label body (20) + padding (4)
_COL_GAP  = 340  # horizontal gap between depth levels
_ROW_GAP  = 130  # vertical gap between nodes in same column
_LEFT_PAD = 80


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _safe_str(v) -> str:
    return str(v) if v is not None and pd.notna(v) else ""


def _node_ntype(table: str, schema: str) -> str:
    """Map a table+schema to a display node type."""
    t = table.lower() if table else ""
    s = (schema or "").lower()
    if t.endswith("_ikg"):
        return "ikg"
    if t.startswith("temp_") or t.endswith("_tmp") or t.endswith("_temp"):
        return "tmp"
    if "ikg" in s or "model" in s or "nlg" in s:
        return "ikg"
    return "ext"


def _col_label_from_row(row, col_field: str) -> str:
    """Return a clean column label from a dataframe row."""
    val = getattr(row, col_field, None)
    s = _safe_str(val).strip()
    if s.lower() in ("", "none", "nan"):
        return ""
    return s


# ─────────────────────────────────────────────────────────────────────────────
# Graph builder
# ─────────────────────────────────────────────────────────────────────────────

def _build_column_lineage_payload(
    target_column: str,
    target_table: str,
):
    """
    Returns (nodes, edges, counts) for the column lineage canvas.

    Layout:
      depth < 0  → upstream tables (left side)
      depth = 0  → focal table  (centre)
      depth > 0  → downstream tables (right side)
    """
    target_column = _safe_str(target_column).strip()
    target_table  = _safe_str(target_table).strip()

    df_up   = get_column_lineage_upstream(target_column, target_table)
    df_down = get_column_lineage_downstream(target_column, target_table)

    # ── Build the edge set from both directions ───────────────────────────
    edge_tuples: list[tuple] = []   # (src_table, src_col, tgt_table, tgt_col, logic, process)

    if not df_up.empty:
        for r in df_up.itertuples(index=False):
            src_t   = _safe_str(getattr(r, "source_table",  None))
            src_c   = _safe_str(getattr(r, "source_column", None))
            tgt_t   = _safe_str(getattr(r, "target_table",  None))
            tgt_c   = _safe_str(getattr(r, "target_column", None))
            logic   = _safe_str(getattr(r, "logic",         None))
            process = _safe_str(getattr(r, "process",       None))
            if src_t and tgt_t:
                edge_tuples.append((src_t, src_c, tgt_t, tgt_c, logic, process))

    if not df_down.empty:
        for r in df_down.itertuples(index=False):
            src_t   = _safe_str(getattr(r, "source_table",  None))
            src_c   = _safe_str(getattr(r, "source_column", None))
            tgt_t   = _safe_str(getattr(r, "target_table",  None))
            tgt_c   = _safe_str(getattr(r, "target_column", None))
            logic   = _safe_str(getattr(r, "logic",         None))
            process = _safe_str(getattr(r, "process",       None))
            if src_t and tgt_t:
                edge_tuples.append((src_t, src_c, tgt_t, tgt_c, logic, process))

    if not edge_tuples and df_up.empty and df_down.empty:
        # Nothing at all – still show the focal node alone
        focal_node = {
            "id": target_table, "x": _LEFT_PAD, "y": 70,
            "w": _NODE_W, "h": _NODE_H,
            "role": "focal", "ntype": "ikg",
            "col_label": target_column, "level": 0,
        }
        return [focal_node], [], {
            "upstream": 0, "downstream": 0, "focal": 1, "relations": 0
        }

    # ── Assign depths (BFS from focal outward in both directions) ─────────
    # upstream depth  = negative  (tables to the left)
    # focal depth     = 0
    # downstream depth= positive  (tables to the right)

    # We store the COLUMN that passes through each (table, depth) slot so
    # the node body can show it.

    # BFS upstream
    upstream_tables: dict[str, int] = {}   # table → depth (negative)
    upstream_col:    dict[str, str]  = {}   # table → the column in that table
    if not df_up.empty:
        adj_up: dict[str, list] = {}       # target → [(source, src_col, tgt_col)]
        for st, sc2, tt, tc, *_ in edge_tuples:
            if not df_up.empty:
                adj_up.setdefault(tt, []).append((st, sc2, tc))

        visited: set = {target_table}
        queue = [(target_table, 0, target_column)]
        while queue:
            tbl, depth, col_in = queue.pop(0)
            for src, sc2, tc in adj_up.get(tbl, []):
                if src not in visited:
                    visited.add(src)
                    new_depth = depth - 1
                    upstream_tables[src] = new_depth
                    upstream_col[src]    = sc2 or col_in
                    queue.append((src, new_depth, sc2 or col_in))

    # BFS downstream
    downstream_tables: dict[str, int] = {}
    downstream_col:    dict[str, str]  = {}
    if not df_down.empty:
        adj_down: dict[str, list] = {}
        for st, sc2, tt, tc, *_ in edge_tuples:
            adj_down.setdefault(st, []).append((tt, sc2, tc))

        visited2: set = {target_table}
        queue2 = [(target_table, 0, target_column)]
        while queue2:
            tbl, depth, col_out = queue2.pop(0)
            for dst, sc2, tc in adj_down.get(tbl, []):
                if dst not in visited2:
                    visited2.add(dst)
                    new_depth = depth + 1
                    downstream_tables[dst] = new_depth
                    downstream_col[dst]    = tc or col_out
                    queue2.append((dst, new_depth, tc or col_out))

    # ── Schema lookup for ntype ────────────────────────────────────────────
    schema_map: dict[str, str] = {}
    for df_s in [df_up, df_down]:
        if df_s.empty:
            continue
        for col_pair in [("source_table", "source_schema"), ("target_table", "target_schema")]:
            t_col, s_col = col_pair
            if t_col in df_s.columns and s_col in df_s.columns:
                for r in df_s[[t_col, s_col]].drop_duplicates().itertuples(index=False):
                    tbl = _safe_str(r[0])
                    sch = _safe_str(r[1])
                    if tbl and tbl not in schema_map:
                        schema_map[tbl] = sch

    # ── Group tables by depth bucket for layout ───────────────────────────
    depth_buckets: dict[int, list[str]] = {0: [target_table]}
    for tbl, d in upstream_tables.items():
        depth_buckets.setdefault(d, []).append(tbl)
    for tbl, d in downstream_tables.items():
        depth_buckets.setdefault(d, []).append(tbl)

    # Normalise so minimum depth starts at 0 for x positioning
    min_depth = min(depth_buckets.keys())

    nodes: list[dict] = []
    node_pos: dict[str, tuple[float, float]] = {}

    for depth in sorted(depth_buckets.keys()):
        col_index = depth - min_depth          # 0-based column index
        tables_in_col = sorted(depth_buckets[depth])
        for row_idx, tbl in enumerate(tables_in_col):
            x = _LEFT_PAD + col_index * _COL_GAP
            y = 60 + row_idx * _ROW_GAP

            if depth == 0:
                role      = "focal"
                col_label = target_column
            elif depth < 0:
                role      = "upstream"
                col_label = upstream_col.get(tbl, "")
            else:
                role      = "downstream"
                col_label = downstream_col.get(tbl, "")

            sch   = schema_map.get(tbl, "")
            ntype = role if role == "focal" else _node_ntype(tbl, sch)

            nodes.append({
                "id":        tbl,
                "x":         x,
                "y":         y,
                "w":         _NODE_W,
                "h":         _NODE_H,
                "role":      role,
                "ntype":     ntype,
                "col_label": col_label,
                "level":     col_index,
            })
            node_pos[tbl] = (x, y)

    # ── Build edges (deduplicated) ─────────────────────────────────────────
    all_node_ids = {n["id"] for n in nodes}
    seen_edges: set = set()
    edges: list[dict] = []

    for src_t, src_c, tgt_t, tgt_c, logic, process in edge_tuples:
        if src_t not in all_node_ids or tgt_t not in all_node_ids:
            continue
        key = (src_t, src_c, tgt_t, tgt_c)
        if key in seen_edges:
            continue
        seen_edges.add(key)
        edges.append({
            "from":    src_t,
            "to":      tgt_t,
            "src_col": src_c,
            "tgt_col": tgt_c,
            "logic":   logic if logic.lower() not in ("", "none", "nan") else "",
            "process": process,
        })

    counts = {
        "focal":      1,
        "upstream":   len(upstream_tables),
        "downstream": len(downstream_tables),
        "relations":  len(edges),
    }
    return nodes, edges, counts


# ─────────────────────────────────────────────────────────────────────────────
# Template rendering
# ─────────────────────────────────────────────────────────────────────────────

def _template_path() -> Path:
    return Path(__file__).resolve().parents[1] / "utils" / "column_lineage_template.html"


def _render_column_lineage(target_column: str, target_table: str) -> str:
    template = _template_path().read_text(encoding="utf-8")

    nodes, edges, counts = _build_column_lineage_payload(target_column, target_table)

    payload = (
        f"const NODES  = {json.dumps(nodes)};\n"
        f"const EDGES  = {json.dumps(edges)};\n"
        f"const FOCAL_TABLE = {json.dumps(target_table)};\n"
        f"const FOCAL_COL   = {json.dumps(target_column)};\n"
        f"const CL_COUNTS   = {json.dumps(counts)};"
    )

    # Replace the placeholder data block
    template = re.sub(
        r"const NODES\s*=\s*\[\s*\];\s*"
        r"const EDGES\s*=\s*\[\s*\];\s*"
        r"const FOCAL_TABLE\s*=\s*\".*?\";\s*"
        r"const FOCAL_COL\s*=\s*\".*?\";\s*"
        r"const CL_COUNTS\s*=\s*\{.*?\};",
        payload,
        template,
        flags=re.DOTALL,
    )

    # Patch <title>
    safe = f"{target_column} in {target_table}"
    template = re.sub(r"<title>.*?</title>", f"<title>{safe}</title>",
                      template, count=1, flags=re.DOTALL)

    return template


# ─────────────────────────────────────────────────────────────────────────────
# Dash layout
# ─────────────────────────────────────────────────────────────────────────────

def layout():
    """Return the dcc.Tab for Column Lineage."""
    # Load all available target columns for the first dropdown
    try:
        df_cols = get_all_target_columns()
        col_options = [
            {"label": c, "value": c}
            for c in df_cols["target_column"].dropna().astype(str).tolist()
        ]
    except Exception:
        col_options = []

    return dcc.Tab(
        label="Column Lineage",
        value="tab-column-lineage",
        children=html.Div(
            [
                html.H3("Column Lineage", style=mds["section_header_style"]),
                # ── Toolbar ────────────────────────────────────────────────
                html.Div(
                    [
                        # Dropdown 1 — column
                        html.Div(
                            [
                                html.Span("Target Column", style=mds["dropdown_label_style"]),
                                dcc.Dropdown(
                                    id="cl-column-dd",
                                    options=col_options,
                                    placeholder="Select a column …",
                                    clearable=True,
                                    searchable=True,
                                    style={**mds["dropdown_style"], "width": "380px"},
                                ),
                            ],
                            style={"minWidth": "400px"},
                        ),
                        # Arrow divider
                        html.Div(
                            "→",
                            style={
                                "fontSize": "1.4rem", "color": "#94a3b8",
                                "padding": "0 8px", "alignSelf": "center",
                                "marginTop": "18px",
                            },
                        ),
                        # Dropdown 2 — table (populated by callback)
                        html.Div(
                            [
                                html.Span("Target Table", style=mds["dropdown_label_style"]),
                                dcc.Dropdown(
                                    id="cl-table-dd",
                                    options=[],
                                    placeholder="Select a table …",
                                    clearable=True,
                                    disabled=True,
                                    style={**mds["dropdown_style"], "width": "380px"},
                                ),
                            ],
                            style={"minWidth": "400px"},
                        ),
                        # Info badge
                        html.Div(
                            id="cl-info-badge",
                            style={
                                "marginLeft": "auto", "alignSelf": "center",
                                "marginTop": "18px", "fontSize": "11px",
                                "color": "#7c3aed", "fontWeight": "600",
                                "padding": "4px 12px",
                                "background": "#f5f3ff",
                                "border": "1px solid #ede9fe",
                                "borderRadius": "20px",
                            },
                        ),
                    ],
                    style={
                        **mds["toolbar_style"],
                        "marginBottom": "10px",
                        "display": "flex",
                        "alignItems": "flex-start",
                        "gap": "0px",
                        "flexWrap": "wrap",
                    },
                ),
                # ── Iframe ─────────────────────────────────────────────────
                html.Iframe(
                    id="cl-iframe",
                    src="",
                    style={
                        "width": "100%",
                        "height": "88vh",
                        "border": "1px solid #e2e8f0",
                        "borderRadius": "8px",
                        "background": "#ffffff",
                    },
                ),
            ],
            style=mds["table_container_style"],
        ),
    )


# ─────────────────────────────────────────────────────────────────────────────
# Callbacks
# ─────────────────────────────────────────────────────────────────────────────

def register_callbacks(app):

    @app.callback(
        Output("cl-table-dd", "options"),
        Output("cl-table-dd", "disabled"),
        Output("cl-table-dd", "value"),
        Output("cl-info-badge", "children"),
        Input("cl-column-dd", "value"),
    )
    def _populate_table_dropdown(selected_col):
        """When a column is chosen, load the tables that contain it."""
        if not selected_col:
            return [], True, None, ""
        try:
            df = get_tables_for_column(str(selected_col))
            tables = df["target_table"].dropna().astype(str).tolist()
        except Exception:
            tables = []

        options  = [{"label": t, "value": t} for t in sorted(tables)]
        disabled = len(options) == 0
        badge    = f"{len(options)} table{'s' if len(options) != 1 else ''}"
        return options, disabled, None, badge

    @app.callback(
        Output("cl-iframe", "src"),
        Input("cl-column-dd", "value"),
        Input("cl-table-dd",  "value"),
    )
    def _update_iframe(selected_col, selected_table):
        if not selected_col or not selected_table:
            return ""
        enc_col   = urllib.parse.quote(str(selected_col),   safe="")
        enc_table = urllib.parse.quote(str(selected_table), safe="")
        return app.get_relative_path(
            f"/column-lineage-view?col={enc_col}&table={enc_table}"
        )


# ─────────────────────────────────────────────────────────────────────────────
# Server route
# ─────────────────────────────────────────────────────────────────────────────

def register_server_routes(server, routes_prefix="/"):
    """Register the Flask route that serves the column lineage HTML page."""

    def _handler():
        col   = request.args.get("col",   "").strip()
        table = request.args.get("table", "").strip()
        if not col or not table:
            return (
                "<html><body style='font-family:Arial;padding:16px'>"
                "Select a column and table to view lineage.</body></html>"
            )
        try:
            return _render_column_lineage(col, table)
        except Exception as exc:
            safe = str(exc).replace("<", "&lt;").replace(">", "&gt;")
            return (
                f"<html><body style='font-family:Arial;padding:16px'>"
                f"Failed to render column lineage: {safe}</body></html>"
            )

    if not routes_prefix.startswith("/"):
        routes_prefix = "/" + routes_prefix
    if not routes_prefix.endswith("/"):
        routes_prefix = routes_prefix + "/"

    base_path     = "/column-lineage-view"
    prefixed_path = f"{routes_prefix.rstrip('/')}{base_path}"

    existing = {rule.rule for rule in server.url_map.iter_rules()}
    if base_path not in existing:
        server.add_url_rule(
            base_path, endpoint="column_lineage_view", view_func=_handler
        )
    if prefixed_path not in existing and prefixed_path != base_path:
        server.add_url_rule(
            prefixed_path,
            endpoint="column_lineage_view_prefixed",
            view_func=_handler,
        )
