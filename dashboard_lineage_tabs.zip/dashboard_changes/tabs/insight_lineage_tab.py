"""
insight_lineage_tab.py
──────────────────────
Dash tab that lets the user select an insight_type from
odm_rule_metadata_auto_refresh and renders the full upstream column
lineage for every ODM rule_column belonging to that insight in the same
interactive canvas style as the Table Lineage (ER) tab.

Architecture mirrors table_lineage_er_tab.py exactly:
  layout()               → returns dcc.Tab
  register_callbacks()   → Dash callbacks
  register_server_routes() → Flask route serving the rendered HTML
"""
import json
import re
import urllib.parse
from pathlib import Path

import pandas as pd
from dash import Input, Output, dcc, html
from flask import request
from styles import metadata_dashboard_styles as mds
from utils.data import (
    get_all_insight_types,
    get_insight_column_lineage,
    get_insight_rule_meta,
)

# ─────────────────────────────────────────────────────────────────────────────
# Layout constants (match column_lineage_tab for visual consistency)
# ─────────────────────────────────────────────────────────────────────────────
_NODE_W   = 230
_NODE_H   = 54
_COL_GAP  = 340
_ROW_GAP  = 130
_LEFT_PAD = 80


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _safe_str(v) -> str:
    return str(v) if v is not None and pd.notna(v) else ""


def _node_ntype(table: str, schema: str, rule_cols_in_table: set) -> str:
    """
    Map a table+schema to a canvas node type.

    Tables that contain an ODM rule_column get type "rule" so they receive
    the purple highlight.  Otherwise the existing ikg/src/ext logic applies.
    """
    t = (table  or "").lower()
    s = (schema or "").lower()
    if rule_cols_in_table:
        return "rule"
    if t.endswith("_ikg"):
        return "ikg"
    if "ikg" in s or "model" in s or "nlg" in s:
        return "ikg"
    if t.startswith("temp_") or t.endswith("_tmp"):
        return "src"
    return "ext"


# ─────────────────────────────────────────────────────────────────────────────
# Graph builder
# ─────────────────────────────────────────────────────────────────────────────

def _build_insight_lineage_payload(insight_type: str):
    """
    Build (nodes, edges, rule_cols, counts) for the insight lineage canvas.

    The graph shows all source→target column flows that feed into any ODM
    rule_column for the selected insight_type.

    Layout depth is assigned by BFS from the "rule column" tables outward to
    their upstream sources (left side only – insight lineage is upstream-only).
    """
    insight_type = _safe_str(insight_type).strip()

    # ── Fetch data ────────────────────────────────────────────────────────
    df = get_insight_column_lineage(insight_type)
    df_meta = get_insight_rule_meta(insight_type)

    # Determine the set of ODM rule columns for this insight
    rule_cols: list[str] = []
    if not df_meta.empty and "rule_column" in df_meta.columns:
        rule_cols = (
            df_meta["rule_column"]
            .dropna()
            .astype(str)
            .str.strip()
            .unique()
            .tolist()
        )
    rule_col_set = {c.lower() for c in rule_cols if c}

    if df.empty:
        return [], [], rule_cols, {"rule": len(rule_cols), "ikg": 0, "src": 0, "relations": 0}

    # ── Build edge list ───────────────────────────────────────────────────
    edge_tuples: list[tuple] = []   # (src_table, src_col, tgt_table, tgt_col, logic, process)
    for r in df.itertuples(index=False):
        src_t   = _safe_str(getattr(r, "source_table",  None))
        src_c   = _safe_str(getattr(r, "source_column", None))
        tgt_t   = _safe_str(getattr(r, "target_table",  None))
        tgt_c   = _safe_str(getattr(r, "target_column", None))
        logic   = _safe_str(getattr(r, "logic",         None))
        process = _safe_str(getattr(r, "process",       None))
        if src_t and tgt_t:
            edge_tuples.append((src_t, src_c, tgt_t, tgt_c, logic, process))

    if not edge_tuples:
        return [], [], rule_cols, {"rule": len(rule_cols), "ikg": 0, "src": 0, "relations": 0}

    # ── Schema lookup ─────────────────────────────────────────────────────
    schema_map: dict[str, str] = {}
    for col_pair in [("source_table", "source_schema"), ("target_table", "target_schema")]:
        t_col, s_col = col_pair
        if t_col in df.columns and s_col in df.columns:
            for r in df[[t_col, s_col]].drop_duplicates().itertuples(index=False):
                tbl = _safe_str(r[0])
                sch = _safe_str(r[1])
                if tbl and tbl not in schema_map:
                    schema_map[tbl] = sch

    # ── Which rule_columns live in which table ────────────────────────────
    # target_column = rule_column  → that table holds the rule column
    table_rule_cols: dict[str, set] = {}
    for st, sc2, tt, tc, *_ in edge_tuples:
        if tc.lower() in rule_col_set:
            table_rule_cols.setdefault(tt, set()).add(tc)
        if sc2.lower() in rule_col_set:
            table_rule_cols.setdefault(st, set()).add(sc2)

    # ── BFS to assign depth (rule-col tables = depth 0; sources go left) ─
    all_tables: set[str] = set()
    for st, sc2, tt, tc, *_ in edge_tuples:
        all_tables.add(st)
        all_tables.add(tt)

    # seed: tables that contain a rule column
    seed_tables = {t for t in all_tables if table_rule_cols.get(t)}
    if not seed_tables:
        # fallback: use the targets of the first batch of edges
        seed_tables = {tt for _, _, tt, *_ in edge_tuples}

    # Build adjacency: "who feeds into me"
    adj_up: dict[str, list[str]] = {}
    for st, sc2, tt, tc, *_ in edge_tuples:
        adj_up.setdefault(tt, []).append(st)

    depths: dict[str, int] = {}
    for t in seed_tables:
        depths[t] = 0

    queue = list(seed_tables)
    visited = set(seed_tables)
    while queue:
        tbl = queue.pop(0)
        for src in adj_up.get(tbl, []):
            if src not in visited:
                visited.add(src)
                depths[src] = depths[tbl] - 1
                queue.append(src)

    # Any table not reached by BFS gets depth 0
    for t in all_tables:
        if t not in depths:
            depths[t] = 0

    # ── Group by depth for layout ─────────────────────────────────────────
    depth_buckets: dict[int, list[str]] = {}
    for tbl, d in depths.items():
        depth_buckets.setdefault(d, []).append(tbl)

    min_depth = min(depth_buckets.keys())

    nodes: list[dict] = []
    for depth in sorted(depth_buckets.keys()):
        col_index  = depth - min_depth
        tbl_in_col = sorted(depth_buckets[depth])
        for row_idx, tbl in enumerate(tbl_in_col):
            x = _LEFT_PAD + col_index * _COL_GAP
            y = 60 + row_idx * _ROW_GAP

            rc_in_tbl = sorted(table_rule_cols.get(tbl, set()))
            sch       = schema_map.get(tbl, "")
            ntype     = _node_ntype(tbl, sch, set(rc_in_tbl))

            nodes.append({
                "id":        tbl,
                "x":         x,
                "y":         y,
                "w":         _NODE_W,
                "h":         _NODE_H,
                "ntype":     ntype,
                "rule_cols": rc_in_tbl,
                "level":     col_index,
            })

    # ── Build edges (deduplicated) ─────────────────────────────────────────
    all_node_ids = {n["id"] for n in nodes}
    seen_edges: set = set()
    edges: list[dict] = []

    for src_t, src_c, tgt_t, tgt_c, logic, process in edge_tuples:
        if src_t not in all_node_ids or tgt_t not in all_node_ids:
            continue
        key = (src_t, src_c, tgt_t, tgt_c)
        if key in seen_edges:
            continue
        seen_edges.add(key)
        edges.append({
            "from":    src_t,
            "to":      tgt_t,
            "src_col": src_c,
            "tgt_col": tgt_c,
            "logic":   logic if logic.lower() not in ("", "none", "nan") else "",
            "process": process,
        })

    rule_node_count  = sum(1 for n in nodes if n["ntype"] == "rule")
    ikg_node_count   = sum(1 for n in nodes if n["ntype"] == "ikg")
    src_node_count   = sum(1 for n in nodes if n["ntype"] in ("src", "ext"))

    counts = {
        "rule":      rule_node_count,
        "ikg":       ikg_node_count,
        "src":       src_node_count,
        "relations": len(edges),
    }
    return nodes, edges, rule_cols, counts


# ─────────────────────────────────────────────────────────────────────────────
# Template rendering
# ─────────────────────────────────────────────────────────────────────────────

def _template_path() -> Path:
    return Path(__file__).resolve().parents[1] / "utils" / "insight_lineage_template.html"


def _render_insight_lineage(insight_type: str) -> str:
    template = _template_path().read_text(encoding="utf-8")

    nodes, edges, rule_cols, counts = _build_insight_lineage_payload(insight_type)

    payload = (
        f"const NODES      = {json.dumps(nodes)};\n"
        f"const EDGES      = {json.dumps(edges)};\n"
        f"const INSIGHT    = {json.dumps(insight_type)};\n"
        f"const RULE_COLS  = {json.dumps(rule_cols)};\n"
        f"const IL_COUNTS  = {json.dumps(counts)};"
    )

    # Replace placeholder data block
    template = re.sub(
        r"const NODES\s*=\s*\[\s*\];\s*"
        r"const EDGES\s*=\s*\[\s*\];\s*"
        r"const INSIGHT\s*=\s*\".*?\";\s*"
        r"const RULE_COLS\s*=\s*\[\s*\];\s*"
        r"const IL_COUNTS\s*=\s*\{.*?\};",
        payload,
        template,
        flags=re.DOTALL,
    )

    # Patch <title>
    template = re.sub(
        r"<title>.*?</title>",
        f"<title>{insight_type} — Insight Lineage</title>",
        template,
        count=1,
        flags=re.DOTALL,
    )
    return template


# ─────────────────────────────────────────────────────────────────────────────
# Dash layout
# ─────────────────────────────────────────────────────────────────────────────

def layout():
    """Return the dcc.Tab for Insight Lineage."""
    try:
        df_insights = get_all_insight_types()
        insight_options = [
            {"label": v, "value": v}
            for v in df_insights["insight_type"].dropna().astype(str).tolist()
        ]
    except Exception:
        insight_options = []

    return dcc.Tab(
        label="Insight Lineage",
        value="tab-insight-lineage",
        children=html.Div(
            [
                html.H3("Insight Lineage", style=mds["section_header_style"]),
                # ── Toolbar ────────────────────────────────────────────────
                html.Div(
                    [
                        # Insight type dropdown
                        html.Div(
                            [
                                html.Span("Insight Type", style=mds["dropdown_label_style"]),
                                dcc.Dropdown(
                                    id="il-insight-dd",
                                    options=insight_options,
                                    placeholder="Select an insight type …",
                                    clearable=True,
                                    searchable=True,
                                    style={**mds["dropdown_style"], "width": "520px"},
                                ),
                            ],
                            style={"minWidth": "560px"},
                        ),
                        # Rule-column badge populated by callback
                        html.Div(
                            id="il-rule-badge",
                            style={
                                "marginLeft": "auto",
                                "alignSelf": "center",
                                "marginTop": "18px",
                                "fontSize": "11px",
                                "color": "#7c3aed",
                                "fontWeight": "600",
                                "padding": "4px 12px",
                                "background": "#f5f3ff",
                                "border": "1px solid #ede9fe",
                                "borderRadius": "20px",
                            },
                        ),
                    ],
                    style={
                        **mds["toolbar_style"],
                        "marginBottom": "10px",
                        "display": "flex",
                        "alignItems": "flex-start",
                        "gap": "16px",
                        "flexWrap": "wrap",
                    },
                ),
                # ── Rule column summary card (hidden until selection) ──────
                html.Div(
                    id="il-meta-card",
                    style={"display": "none"},
                    children=[
                        html.Div(
                            id="il-meta-content",
                            style={
                                **mds["content_card_style"],
                                "marginBottom": "10px",
                                "display": "flex",
                                "flexWrap": "wrap",
                                "gap": "8px",
                                "alignItems": "center",
                                "padding": "10px 16px",
                            },
                        )
                    ],
                ),
                # ── Iframe ─────────────────────────────────────────────────
                html.Iframe(
                    id="il-iframe",
                    src="",
                    style={
                        "width": "100%",
                        "height": "85vh",
                        "border": "1px solid #e2e8f0",
                        "borderRadius": "8px",
                        "background": "#ffffff",
                    },
                ),
            ],
            style=mds["table_container_style"],
        ),
    )


# ─────────────────────────────────────────────────────────────────────────────
# Callbacks
# ─────────────────────────────────────────────────────────────────────────────

def register_callbacks(app):

    @app.callback(
        Output("il-rule-badge",    "children"),
        Output("il-meta-card",     "style"),
        Output("il-meta-content",  "children"),
        Input("il-insight-dd", "value"),
    )
    def _update_meta(selected_insight):
        """Show the rule-column chips below the dropdown when an insight is selected."""
        hidden_style = {"display": "none"}
        visible_style = {"display": "block"}

        if not selected_insight:
            return "", hidden_style, []

        try:
            df_meta = get_insight_rule_meta(str(selected_insight))
        except Exception:
            return "⚠ could not load metadata", hidden_style, []

        rule_cols = []
        if not df_meta.empty and "rule_column" in df_meta.columns:
            rule_cols = (
                df_meta["rule_column"]
                .dropna()
                .astype(str)
                .str.strip()
                .unique()
                .tolist()
            )

        badge = f"{len(rule_cols)} rule column{'s' if len(rule_cols) != 1 else ''}"

        # Build chip list for the meta card
        chips = [
            html.Span(
                "◈ ODM Rule Columns:",
                style={
                    "fontSize": "11px", "fontWeight": "700",
                    "color": "#5b21b6", "marginRight": "8px",
                    "textTransform": "uppercase", "letterSpacing": "0.06em",
                },
            )
        ]
        for rc in sorted(rule_cols):
            chips.append(
                html.Span(
                    rc,
                    style={
                        "display": "inline-block",
                        "background": "#f5f3ff",
                        "border": "1px solid #ede9fe",
                        "borderRadius": "4px",
                        "padding": "2px 8px",
                        "fontSize": "12px",
                        "fontFamily": '"JetBrains Mono", monospace',
                        "color": "#5b21b6",
                    },
                )
            )

        meta_style = {**visible_style}
        return badge, meta_style, chips

    @app.callback(
        Output("il-iframe", "src"),
        Input("il-insight-dd", "value"),
    )
    def _update_iframe(selected_insight):
        if not selected_insight:
            return ""
        enc = urllib.parse.quote(str(selected_insight), safe="")
        return app.get_relative_path(f"/insight-lineage-view?insight={enc}")


# ─────────────────────────────────────────────────────────────────────────────
# Server route
# ─────────────────────────────────────────────────────────────────────────────

def register_server_routes(server, routes_prefix="/"):
    """Register the Flask route that serves the insight lineage HTML page."""

    def _handler():
        insight = request.args.get("insight", "").strip()
        if not insight:
            return (
                "<html><body style='font-family:Arial;padding:16px'>"
                "Select an insight type to view lineage.</body></html>"
            )
        try:
            return _render_insight_lineage(insight)
        except Exception as exc:
            safe = str(exc).replace("<", "&lt;").replace(">", "&gt;")
            return (
                f"<html><body style='font-family:Arial;padding:16px'>"
                f"Failed to render insight lineage: {safe}</body></html>"
            )

    if not routes_prefix.startswith("/"):
        routes_prefix = "/" + routes_prefix
    if not routes_prefix.endswith("/"):
        routes_prefix = routes_prefix + "/"

    base_path     = "/insight-lineage-view"
    prefixed_path = f"{routes_prefix.rstrip('/')}{base_path}"

    existing = {rule.rule for rule in server.url_map.iter_rules()}
    if base_path not in existing:
        server.add_url_rule(
            base_path, endpoint="insight_lineage_view", view_func=_handler
        )
    if prefixed_path not in existing and prefixed_path != base_path:
        server.add_url_rule(
            prefixed_path,
            endpoint="insight_lineage_view_prefixed",
            view_func=_handler,
        )
