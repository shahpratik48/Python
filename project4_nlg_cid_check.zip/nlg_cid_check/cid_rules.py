"""
The CID rules.

Every rule applies ONLY to attributes this branch actually introduced or
changed -- this is a branch gate, not a repository-wide audit.

  Rule 1  CID_IN_SQL_COLUMN_MAPPING
          A CID attribute added/changed in input_data_config/<tt>.yml must
          NOT also appear in any sql_column_mapping/<tt>/**/*.yml file.
          input_data_config and sql_column_mapping are the non-CID
          environment; a CID attribute reaching them unmasked is a leak.

  Rule 2  NEW_CID_IN_SQL_COLUMN_MAPPING
          A CID attribute added/changed directly in a
          sql_column_mapping/<tt>/... file is flagged on sight, for the
          same reason.

  Rule 3  CID_NOT_MASKED_IN_DUMMY
          A CID attribute added/changed in input_data_config/<tt>.yml must
          have an MD5-masked counterpart in
          input_data_config_dummy/<tt>.yml. Masked -> good. Missing, or
          present but unmasked -> flagged.

  Rule 4  CID_UNDETERMINED
          The attribute could not be classified (no LLM, LLM error, or low
          confidence). Flagged deliberately: an unreviewed attribute that
          might be CID is exactly what a human should look at.

Every flag fails the run. A clean report passes.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set

from cid_attributes import (NewAttribute, extract_attributes, is_attribute_md5_masked,
                            parse_config_mapping, parse_sql_column_mapping)
from cid_llm import CidVerdict

CAT_RULE1 = "CID attribute from input_data_config also present in sql_column_mapping"
CAT_RULE2 = "New CID attribute added directly in sql_column_mapping"
CAT_RULE3 = "CID attribute not MD5-masked in input_data_config_dummy"
CAT_RULE4 = "CID status could not be determined -- needs manual review"

SEVERITY = {CAT_RULE1: "high", CAT_RULE2: "high", CAT_RULE3: "high", CAT_RULE4: "medium"}


@dataclass
class Finding:
    category: str
    attribute: str
    target_type: str
    source_file: str          # where the branch introduced/changed it
    key: str
    sql_expr: str
    detail: str
    severity: str = "high"
    cid_basis: str = ""       # how the attribute was judged CID
    cid_reasoning: str = ""
    related_files: List[str] = field(default_factory=list)
    insight_type: Optional[str] = None


def evaluate(new_attributes: List[NewAttribute],
             verdicts: Dict[str, CidVerdict],
             sql_mapping_files_by_tt: Dict[str, Dict[str, str]],
             dummy_files_by_tt: Dict[str, Optional[str]]) -> List[Finding]:
    """Apply all four rules.

    `sql_mapping_files_by_tt`  target_type -> {file_path: content} for every
                               sql_column_mapping file of that target_type
                               on the branch.
    `dummy_files_by_tt`        target_type -> input_data_config_dummy file
                               content on the branch (None if absent).
    """
    findings: List[Finding] = []
    seen: Set[tuple] = set()

    def add(f: Finding):
        # one finding per (category, attribute, target_type, source file)
        k = (f.category, f.attribute, f.target_type, f.source_file)
        if k not in seen:
            seen.add(k)
            findings.append(f)

    for na in new_attributes:
        verdict = verdicts.get(na.attribute)
        if verdict is None:
            continue

        # ---- Rule 4: undetermined -------------------------------------
        if verdict.needs_review:
            add(Finding(
                category=CAT_RULE4, attribute=na.attribute, target_type=na.target_type,
                source_file=na.file_path, key=na.key, sql_expr=na.sql_expr,
                severity=SEVERITY[CAT_RULE4], cid_basis=verdict.basis,
                cid_reasoning=verdict.reasoning, insight_type=na.insight_type,
                detail=(f"Attribute '{na.attribute}' was {na.reason} in {na.file_path} "
                        f"({na.folder}), but its CID status could not be determined. "
                        f"Review it manually before merging."),
            ))
            continue

        if not verdict.is_cid:
            continue                       # classified as non-CID: nothing to check

        # ---- Rule 2: CID added straight into sql_column_mapping -------
        if na.folder == "sql_column_mapping":
            add(Finding(
                category=CAT_RULE2, attribute=na.attribute, target_type=na.target_type,
                source_file=na.file_path, key=na.key, sql_expr=na.sql_expr,
                severity=SEVERITY[CAT_RULE2], cid_basis=verdict.basis,
                cid_reasoning=verdict.reasoning, insight_type=na.insight_type,
                detail=(f"CID attribute '{na.attribute}' was {na.reason} in "
                        f"{na.file_path} (insight_type '{na.insight_type}', target_type "
                        f"'{na.target_type}'). sql_column_mapping is the non-CID environment, "
                        f"so a CID attribute must not be introduced there."),
            ))
            continue

        # ---- Rules 1 and 3 apply to input_data_config only ------------
        if na.folder != "input_data_config":
            continue

        # Rule 1: same attribute present in any sql_column_mapping file of this target_type
        hits = []
        for path, content in (sql_mapping_files_by_tt.get(na.target_type) or {}).items():
            for key, expr in parse_sql_column_mapping(content).items():
                if na.attribute in extract_attributes(expr):
                    hits.append(f"{path} (key '{key}')")
                    break
        if hits:
            add(Finding(
                category=CAT_RULE1, attribute=na.attribute, target_type=na.target_type,
                source_file=na.file_path, key=na.key, sql_expr=na.sql_expr,
                severity=SEVERITY[CAT_RULE1], cid_basis=verdict.basis,
                cid_reasoning=verdict.reasoning, related_files=hits,
                detail=(f"CID attribute '{na.attribute}' was {na.reason} in {na.file_path}, and the "
                        f"same attribute also appears in {len(hits)} sql_column_mapping file(s) for "
                        f"target_type '{na.target_type}'. A CID attribute must not be present in the "
                        f"non-CID sql_column_mapping environment."),
            ))

        # Rule 3: must be MD5-masked in the matching dummy file
        dummy_content = dummy_files_by_tt.get(na.target_type)
        dummy_path = f"config/input_data_config_dummy/{na.target_type}.yml"
        if dummy_content is None:
            add(Finding(
                category=CAT_RULE3, attribute=na.attribute, target_type=na.target_type,
                source_file=na.file_path, key=na.key, sql_expr=na.sql_expr,
                severity=SEVERITY[CAT_RULE3], cid_basis=verdict.basis,
                cid_reasoning=verdict.reasoning, related_files=[dummy_path],
                detail=(f"CID attribute '{na.attribute}' was {na.reason} in {na.file_path}, but "
                        f"{dummy_path} does not exist on this branch, so the attribute cannot be "
                        f"masked there."),
            ))
        else:
            dummy_map = parse_config_mapping(dummy_content, na.target_type)
            masked = any(is_attribute_md5_masked(expr, na.attribute) for expr in dummy_map.values())
            if not masked:
                present = any(na.attribute in extract_attributes(expr) for expr in dummy_map.values())
                why = ("present but NOT wrapped in MD5" if present else "not present at all")
                add(Finding(
                    category=CAT_RULE3, attribute=na.attribute, target_type=na.target_type,
                    source_file=na.file_path, key=na.key, sql_expr=na.sql_expr,
                    severity=SEVERITY[CAT_RULE3], cid_basis=verdict.basis,
                    cid_reasoning=verdict.reasoning, related_files=[dummy_path],
                    detail=(f"CID attribute '{na.attribute}' was {na.reason} in {na.file_path}, but in "
                            f"{dummy_path} it is {why}. A CID attribute must be MD5-masked in the dummy "
                            f"environment."),
                ))

    return findings
