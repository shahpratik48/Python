"""
Orchestration for the NLG CID attribute check.

Single entry point, `run_cid_check(settings)`, used identically by the
Airflow DAG and the notebook. Steps:

  1. Connect to GitLab and list what the branch changed under
     input_data_config / input_data_config_dummy / sql_column_mapping.
     Uses the branch-vs-base comparison by default rather than only the
     latest commit, since an attribute introduced two commits earlier on
     the same branch still needs checking. The latest commit is reported
     separately for context.
  2. For every changed file, fetch its content on both refs and work out
     which attributes the branch actually introduced or changed.
  3. Build the MD5 registry from every input_data_config_dummy file --
     the codebase's own record of what counts as CID.
  4. Classify each new attribute: registry first, LLM for the rest,
     undetermined if that fails.
  5. Apply the four rules.
  6. Write the HTML report next to this script and email it as an
     attachment -- always, pass or fail.

Returns a CidCheckResult. `.failed` is True if anything was flagged;
callers (the DAG) raise on that so the task goes red.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from cid_attributes import (build_md5_registry, diff_file_attributes, NewAttribute,
                            target_type_of_path)
from cid_email import send_report
from cid_git import ChangedFile, CommitInfo, GitLabClient
from cid_llm import classify_attributes
from cid_report import build_html, write_report
from cid_rules import Finding, evaluate

MONITORED = ("config/input_data_config/", "config/input_data_config_dummy/", "sql_column_mapping/")


@dataclass
class CidCheckResult:
    branch: str
    base_branch: str
    commit: Optional[CommitInfo]
    changed_files: List[ChangedFile] = field(default_factory=list)
    new_attributes: List[NewAttribute] = field(default_factory=list)
    verdicts: Dict = field(default_factory=dict)
    findings: List[Finding] = field(default_factory=list)
    report_path: str = ""
    email_status: str = ""
    notes: List[str] = field(default_factory=list)
    md5_registry_size: int = 0

    @property
    def failed(self) -> bool:
        return len(self.findings) > 0


def run_cid_check(settings, progress=None, use_compare: bool = True) -> CidCheckResult:
    def log(m):
        if progress:
            progress(m)

    notes: List[str] = []
    gl = GitLabClient(settings)

    # ---- 1. what changed -------------------------------------------------
    log(f"Reading branch '{settings.branch}' from GitLab...")
    try:
        commit = gl.latest_commit()
        log(f"Latest commit: {commit.short_id} - {commit.title} ({commit.author_name})")
    except Exception as e:
        commit = None
        notes.append(f"Could not read latest commit metadata ({type(e).__name__}: {e}).")

    if use_compare:
        log(f"Comparing '{settings.branch}' against '{settings.base_branch}'...")
        changed = gl.compare_files()
        notes.append(f"Change set taken from the full comparison of '{settings.branch}' against "
                     f"'{settings.base_branch}' (merge-base diff), so attributes introduced anywhere "
                     f"on the branch are covered, not only those in the most recent commit.")
    else:
        log("Reading files from the latest commit only...")
        changed = gl.latest_commit_files()
        notes.append("Change set taken from the latest commit only.")

    changed = [c for c in changed if c.path.startswith(MONITORED)]
    log(f"{len(changed)} changed file(s) in the monitored folders.")

    # ---- 2. attributes introduced/changed --------------------------------
    new_attributes: List[NewAttribute] = []
    for cf in changed:
        if cf.change_type == "deleted":
            continue                      # nothing can be introduced by a deletion
        after = gl.read_file(cf.new_path, settings.branch)
        before = None if cf.change_type == "added" else gl.read_file(
            cf.old_path or cf.new_path, settings.base_branch)
        new_attributes.extend(diff_file_attributes(cf.new_path, before, after, cf.change_type))
    distinct = sorted({na.attribute for na in new_attributes})
    log(f"{len(distinct)} distinct attribute(s) introduced or changed by this branch.")

    # ---- 3. MD5 registry -------------------------------------------------
    log("Building the MD5 registry from input_data_config_dummy...")
    dummy_paths = [p for p in gl.read_tree("config/input_data_config_dummy", settings.branch)
                   if p.endswith((".yml", ".yaml"))]
    dummy_files = {p: (gl.read_file(p, settings.branch) or "") for p in dummy_paths}
    md5_registry = build_md5_registry(dummy_files)
    log(f"{len(md5_registry)} attribute(s) are already MD5-masked somewhere in the dummy config.")
    if not md5_registry:
        notes.append("The MD5 registry is empty -- no masked attributes were found in "
                     "input_data_config_dummy. LLM classification will have no calibration examples.")

    # ---- 4. classify -----------------------------------------------------
    sql_context = {}
    for na in new_attributes:
        sql_context.setdefault(na.attribute, na.sql_expr)
    if not settings.llm_enabled:
        notes.append("No LLM key configured. Attributes not already in the MD5 registry are reported "
                     "as UNDETERMINED and flagged for manual review rather than assumed safe.")
    verdicts = classify_attributes(distinct, md5_registry, sql_context, settings, progress=progress)
    n_cid = sum(1 for v in verdicts.values() if v.is_cid)
    n_unk = sum(1 for v in verdicts.values() if v.needs_review)
    log(f"Classification: {n_cid} CID, {n_unk} undetermined, "
        f"{len(verdicts) - n_cid - n_unk} not CID.")

    # ---- 5. supporting content, then rules -------------------------------
    tts = sorted({na.target_type for na in new_attributes if na.target_type})
    sql_by_tt: Dict[str, Dict[str, str]] = {}
    dummy_by_tt: Dict[str, Optional[str]] = {}
    for tt in tts:
        paths = [p for p in gl.read_tree(f"sql_column_mapping/{tt}", settings.branch)
                 if p.endswith((".yml", ".yaml"))]
        sql_by_tt[tt] = {p: (gl.read_file(p, settings.branch) or "") for p in paths}
        dummy_path = f"config/input_data_config_dummy/{tt}.yml"
        dummy_by_tt[tt] = dummy_files.get(dummy_path) or gl.read_file(dummy_path, settings.branch)
    if tts:
        log(f"Loaded supporting files for target_type(s): {', '.join(tts)}")

    findings = evaluate(new_attributes, verdicts, sql_by_tt, dummy_by_tt)
    log(f"{len(findings)} finding(s) flagged.")

    # ---- 6. report + email (always) --------------------------------------
    html_text = build_html(settings.branch, settings.base_branch, commit, changed,
                           new_attributes, verdicts, findings, len(md5_registry), notes)
    report_path = write_report(html_text, settings.output_dir, settings.branch)
    log(f"Report written: {report_path}")

    email_status = send_report(settings, report_path, html_text,
                               failed=bool(findings), finding_count=len(findings), progress=progress)

    return CidCheckResult(branch=settings.branch, base_branch=settings.base_branch, commit=commit,
                          changed_files=changed, new_attributes=new_attributes, verdicts=verdicts,
                          findings=findings, report_path=report_path, email_status=email_status,
                          notes=notes, md5_registry_size=len(md5_registry))
