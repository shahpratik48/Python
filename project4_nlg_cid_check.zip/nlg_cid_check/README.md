# NLG CID Attribute Check

Flags **Client-Identifying Data (CID)** attributes that a branch introduces without the protection
they require, and fails the pipeline when it finds any.

Everything lives in **one flat folder** — scripts, DAG, notebook, and the generated reports. No
subfolders. Connects to **GitLab only**; there is no local-file mode anywhere, by design.

## What an "attribute" means here

The attribute is the **database column inside the SQL expression**, not the YAML key:

```yaml
# input_data_config/account.yml
account_name: b.acc_i                        # attribute = acc_i

# input_data_config_dummy/account.yml
account_name: substring(MD5(b.acc_i),1,8)    # same attribute acc_i, masked -> therefore CID
```

That distinction matters: the same attribute can appear under different keys, and it's the
*attribute* that is or isn't CID.

## The three environments

| Folder | Meaning |
|---|---|
| `config/input_data_config/` | non-CID environment, one file per **target_type** |
| `config/input_data_config_dummy/` | dummy environment, one file per **target_type**; CID attributes are `MD5(...)`-masked here |
| `sql_column_mapping/` | non-CID environment, `<target_type>/[<subdir>/]<insight_type>.yml` |

## The rules

Applied only to attributes **this branch introduced or changed** — a branch gate, not a
repository-wide audit.

| # | Category | Flagged when |
|---|---|---|
| 1 | CID attribute from `input_data_config` also present in `sql_column_mapping` | a CID attribute added/changed in `input_data_config/<tt>.yml` also appears in any `sql_column_mapping/<tt>/**` file |
| 2 | New CID attribute added directly in `sql_column_mapping` | a CID attribute is added/changed straight into a `sql_column_mapping` file |
| 3 | CID attribute not MD5-masked in `input_data_config_dummy` | it's missing from, or present-but-unmasked in, `input_data_config_dummy/<tt>.yml` |
| 4 | CID status could not be determined | no LLM available, the call failed, or the model was not confident |

Rule 4 exists on purpose: an unreviewed attribute that *might* be CID is exactly what a human should
look at, so it is flagged rather than assumed safe.

## How CID is identified

1. **MD5 registry** — every attribute already `MD5(...)`-masked anywhere in `input_data_config_dummy`.
   That set *is* the organisation's own working definition of CID. An attribute in it is CID with no
   LLM call. On the attached source tree this registry contains **106 attributes** across 46 dummy files.
2. **LLM** — anything not in the registry goes to the LLM **with the registry supplied as calibration
   examples**, plus the attribute's name and SQL expression, so the model infers *this* codebase's
   standard rather than a generic notion of PII.
3. **Undetermined** — never silently "not CID". Falls to rule 4.

## Files

| File | Purpose |
|---|---|
| `cid_settings.py` | GitLab / LLM / email config. Same conventions and Variables as the other NLG projects. |
| `cid_git.py` | GitLab REST client: latest-commit files, branch-vs-base comparison, file content at a ref. |
| `cid_attributes.py` | YAML parsing, attribute extraction from SQL, balanced-paren `MD5(...)` detection, MD5 registry, new/changed attribute diffing. |
| `cid_llm.py` | LLM CID classification calibrated on the MD5 registry. |
| `cid_rules.py` | The four rules. |
| `cid_report.py` | Self-contained HTML report, categorised. |
| `cid_email.py` | Emails the report as an attachment. |
| `cid_main.py` | `run_cid_check()` — the single entry point used by both the DAG and the notebook. |
| `airflow_dag_nlg_cid_check.py` | Airflow DAG. Fails the task on any flag. |
| `run_cid_check.ipynb` | Notebook for testing; prompts for the GitLab token and LLM key. |

## Running it — notebook

```python
from cid_settings import CidSettings
from cid_main import run_cid_check

settings = CidSettings()
settings.branch = "nlg-master"
settings.base_branch = "develop"
settings.email_to = ["you@ubs.net"]        # empty = skip sending, report still written
settings.resolve_secrets(interactive=True) # prompts for GitLab token + LLM key

result = run_cid_check(settings, progress=print)
print("FAIL" if result.failed else "PASS", "-", result.report_path)
```

## Running it — Airflow

Deploy `airflow_dag_nlg_cid_check.py` alongside the `cid_*.py` files in the same folder. Secrets come
from the same Airflow Variable the other NLG projects use (`GENESIS_DDLC_IKG_GIT_SECRET`).

Optional Variables: `CID_BRANCH`, `CID_BASE_BRANCH`, `CID_EMAIL_TO`, `CID_EMAIL_FROM`,
`CID_SMTP_HOST`, `CID_SMTP_PORT`, `CID_SMTP_USER`, `CID_SMTP_PASSWORD`, `CID_SMTP_USE_TLS`,
`CID_CHECK_SCHEDULE`.

Override per-run with `dag_run.conf`:

```json
{"branch": "nlg-master"}
{"branch": "feature/my-change", "base_branch": "develop"}
```

**Pass/fail:** the report is **always** written and **always** emailed, whatever the outcome. The task
then fails if the report contains any flag and passes if it's clean — a red task means "CID issues
found", never "the check didn't run".

## Which commits are checked

By default the change set is the **full comparison of `branch` against `base_branch`**, computed from
the merge base. A single latest commit would miss an attribute introduced two commits earlier on the
same branch, so the comparison is the safer default; the merge base (rather than a straight tip-to-tip
diff) keeps the base branch's own independent progress out of the results. The latest commit is still
reported for context, and `run_cid_check(settings, use_compare=False)` restricts the check to it alone.

## Validation performed

Tested against the attached `nlg-src` tree with simulated branch changes:

- **Attribute extraction** — `b.acc_i` → `acc_i`; nested `substring(md5(lower(trim(b.x))),1,8)` → `x`;
  multi-argument `MD5(COALESCE(b.a, b.b))` → both; `MD5('literal')` → nothing. In a `STRING_AGG`
  expression containing three columns where only one is inside `MD5(...)`, only that one is treated as
  masked — the discrimination that rule 3 depends on.
- **MD5 registry** — 106 CID attributes built from the 46 real dummy files.
- **All four rules fired** on a simulated branch, and a **negative control** (an attribute already
  correctly masked and absent from `sql_column_mapping`) produced zero findings.
- **Email** — correct MIME structure, attachment intact, PASS/FAIL subjects, graceful skip with no
  recipients, and an SMTP failure that reports itself without masking the check result.

## Known limitations

- **Attribute extraction recognises alias-qualified columns** (`b.acc_i`, `a.metric_val`) — the
  convention throughout these config files. A bare unqualified identifier is not treated as an
  attribute, because SQL keywords, function names and literals would otherwise be indistinguishable
  from column names and the false-positive rate would make the report unusable.
- **LLM CID judgements are a signal, not a certainty.** Registry-based verdicts are reliable (the
  codebase already made that call); LLM verdicts are worth spot-checking, and the report shows the
  basis for every determination so you can tell them apart.
- Rule 3 checks `input_data_config_dummy/<target_type>.yml` specifically. An attribute masked under a
  *different* target_type is still recognised as CID via the registry, but does not satisfy rule 3 for
  the target_type being changed — which is intended.
