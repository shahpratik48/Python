"""
Configuration for the NLG CID (Client-Identifying Data) attribute check.

Uses the SAME GitLab and LLM settings/conventions as the other NLG agent
projects, so a single set of credentials works everywhere. Everything is
overridable by environment variable, so the identical module runs from a
notebook, from Airflow, or from a plain shell.

Secrets are NEVER hard-coded. Call `resolve_secrets()`:
  - interactive=True  (notebook): env var -> Airflow Variable -> getpass prompt
  - interactive=False (Airflow):  env var -> Airflow Variable -> raise
"""
from __future__ import annotations

import getpass
import os
from dataclasses import dataclass, field
from typing import List, Optional


def _env(name: str, default: Optional[str] = None) -> Optional[str]:
    return os.getenv(name, default)


@dataclass
class CidSettings:
    # ------------------------------------------------------------------
    # Git / GitLab  (same values as the other NLG projects)
    # ------------------------------------------------------------------
    gitlab_url: str = field(default_factory=lambda: _env("GITLAB_URL", "https://devcloud.ubs.net"))
    nlg_project_path: str = field(default_factory=lambda: _env(
        "NLG_PROJECT_PATH",
        "ubs/gwma/smart-technology-and-analytics/staat-data-science/staat-ds-genesis/genesis-platform/nlg-dags"))
    gitlab_token: Optional[str] = field(default_factory=lambda: _env("GITLAB_TOKEN", ""))
    gitlab_token_var: str = field(default_factory=lambda: _env("GITLAB_TOKEN_VAR", "GENESIS_DDLC_IKG_GIT_SECRET"))

    # The branch being checked, and what to compare it against.
    branch: str = field(default_factory=lambda: _env("CID_BRANCH", "nlg-master"))
    base_branch: str = field(default_factory=lambda: _env("CID_BASE_BRANCH", "develop"))

    # Where the nlg source tree lives inside the GitLab project.
    nlg_src_subpath: str = field(default_factory=lambda: _env("NLG_SRC_SUBPATH", "dags/nlg/src"))

    # ------------------------------------------------------------------
    # LLM  (same values as the other NLG projects)
    # ------------------------------------------------------------------
    llm_provider: str = field(default_factory=lambda: _env("LLM_PROVIDER", "azure_openai"))
    azure_openai_endpoint: str = field(default_factory=lambda: _env(
        "AZURE_OPENAI_ENDPOINT", "https://cirruspl-staat-ste-dev-ai.openai.azure.com/openai/v1/"))
    azure_openai_deployment: str = field(default_factory=lambda: _env("AZURE_OPENAI_DEPLOYMENT", "gpt-4.1"))
    azure_openai_api_version: str = field(default_factory=lambda: _env("AZURE_OPENAI_API_VERSION", "2024-02-01"))
    azure_openai_api_key: Optional[str] = field(default_factory=lambda: _env("AZURE_OPENAI_API_KEY", ""))

    llm_gateway_url: str = field(default_factory=lambda: _env(
        "LLM_GATEWAY_URL", "https://llm.genesis-dev.azpriv-cloud.ubs.net"))
    llm_model: str = field(default_factory=lambda: _env("LLM_MODEL", "gpt-4.1"))
    llm_api_key: Optional[str] = field(default_factory=lambda: _env("LLM_API_KEY", ""))

    llm_temperature: float = field(default_factory=lambda: float(_env("LLM_TEMPERATURE", "0.1")))
    llm_max_tokens: int = field(default_factory=lambda: int(_env("LLM_MAX_TOKENS", "4000")))
    llm_airflow_secret_var: str = field(default_factory=lambda: _env(
        "LLM_AIRFLOW_SECRET_VAR", "GENESIS_DDLC_IKG_GIT_SECRET"))

    # ------------------------------------------------------------------
    # Email  (report is always sent as an attachment, pass or fail)
    # ------------------------------------------------------------------
    smtp_host: str = field(default_factory=lambda: _env("CID_SMTP_HOST", "localhost"))
    smtp_port: int = field(default_factory=lambda: int(_env("CID_SMTP_PORT", "25")))
    smtp_user: Optional[str] = field(default_factory=lambda: _env("CID_SMTP_USER", ""))
    smtp_password: Optional[str] = field(default_factory=lambda: _env("CID_SMTP_PASSWORD", ""))
    smtp_use_tls: bool = field(default_factory=lambda: _env("CID_SMTP_USE_TLS", "false").lower() == "true")
    email_from: str = field(default_factory=lambda: _env("CID_EMAIL_FROM", "nlg-cid-check@ubs.net"))
    email_to: List[str] = field(default_factory=lambda: [
        e.strip() for e in _env("CID_EMAIL_TO", "").split(",") if e.strip()])
    email_subject_prefix: str = field(default_factory=lambda: _env("CID_EMAIL_SUBJECT_PREFIX", "[NLG CID Check]"))
    # If no recipients are configured the run still completes and still writes
    # the report -- it just skips the send and says so, rather than failing.
    skip_email_if_no_recipients: bool = True

    # ------------------------------------------------------------------
    # Output -- written next to this script, no subfolders.
    # ------------------------------------------------------------------
    output_dir: str = field(default_factory=lambda: _env(
        "CID_OUTPUT_DIR", os.path.dirname(os.path.abspath(__file__))))

    # ------------------------------------------------------------------
    def _airflow_variable(self, key: str) -> Optional[str]:
        try:
            from airflow.models import Variable  # type: ignore
            return Variable.get(key, default_var=None)
        except Exception:
            return None

    def resolve_secrets(self, interactive: bool = True) -> "CidSettings":
        """Populates gitlab_token and the active LLM key in place."""
        if not self.gitlab_token:
            self.gitlab_token = self._airflow_variable(self.gitlab_token_var)
        if not self.gitlab_token and interactive:
            self.gitlab_token = getpass.getpass("GitLab personal access token: ").strip() or None

        if self.llm_provider == "azure_openai":
            if not self.azure_openai_api_key:
                self.azure_openai_api_key = self._airflow_variable(self.llm_airflow_secret_var)
            if not self.azure_openai_api_key and interactive:
                self.azure_openai_api_key = getpass.getpass("Azure OpenAI API key: ").strip() or None
        elif self.llm_provider == "azure_gateway":
            if not self.llm_api_key:
                self.llm_api_key = self._airflow_variable(self.llm_airflow_secret_var)
            if not self.llm_api_key and interactive:
                self.llm_api_key = getpass.getpass("LLM Gateway API key: ").strip() or None
        return self

    @property
    def llm_enabled(self) -> bool:
        if self.llm_provider == "azure_openai":
            return bool(self.azure_openai_api_key)
        if self.llm_provider == "azure_gateway":
            return bool(self.llm_api_key)
        return False

    # Paths inside the src tree (relative to nlg_src_subpath).
    INPUT_DATA_CONFIG = "config/input_data_config/"
    INPUT_DATA_CONFIG_DUMMY = "config/input_data_config_dummy/"
    SQL_COLUMN_MAPPING = "sql_column_mapping/"
