"""
Parsing and attribute extraction for the CID check.

The central idea, grounded in the real repo layout:

    input_data_config/account.yml
        account:
          sql_column_mapping:
            account_name: b.acc_i          <- key is `account_name`,
                                              ATTRIBUTE is `acc_i`

    input_data_config_dummy/account.yml
        account:
          sql_column_mapping:
            account_name: substring(MD5(b.acc_i),1,8)
                                           <- same attribute `acc_i`,
                                              masked, therefore CID

    sql_column_mapping/<target_type>/[<subdir>/]<insight_type>.yml
        <flat key: sql_expression>         <- attributes extracted the
                                              same way

So an "attribute" here is the underlying database column referenced in
the SQL expression, not the YAML key. That distinction matters: the same
attribute (`acc_i`) can appear under different keys, and it is the
attribute that is or isn't CID.

Attribute extraction deliberately only recognises alias-qualified
references (`b.acc_i`, `a.insight_type`), which is the convention used
throughout these config files. A bare, unqualified identifier is not
treated as an attribute, because at that point SQL keywords, function
names and literals become indistinguishable from column names and the
false-positive rate would make the report useless.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None

# alias.column  ->  captures `column`
_COLUMN_REF = re.compile(r"\b[A-Za-z_]\w*\.([A-Za-z_]\w*)\b")
_MD5_START = re.compile(r"\bmd5\s*\(", re.IGNORECASE)


# ---------------------------------------------------------------- parsing
def parse_config_mapping(content: Optional[str], target_type: str) -> Dict[str, str]:
    """`key -> sql_expression` from an input_data_config (or _dummy) file.

    These files nest the mapping under `<target_type>: sql_column_mapping:`.
    Falls back gracefully if the top-level key doesn't match the filename,
    which happens occasionally.
    """
    if not content or yaml is None:
        return {}
    try:
        data = yaml.safe_load(content)
    except Exception:
        return {}
    if not isinstance(data, dict):
        return {}
    inner = data.get(target_type)
    if not isinstance(inner, dict):
        # fall back to the single top-level block, whatever it's called
        candidates = [v for v in data.values() if isinstance(v, dict) and "sql_column_mapping" in v]
        inner = candidates[0] if candidates else data
    mapping = inner.get("sql_column_mapping") if isinstance(inner, dict) else None
    return {str(k): str(v) for k, v in mapping.items()} if isinstance(mapping, dict) else {}


def parse_sql_column_mapping(content: Optional[str]) -> Dict[str, str]:
    """`key -> sql_expression` from a sql_column_mapping file (flat dict)."""
    if not content or yaml is None:
        return {}
    try:
        data = yaml.safe_load(content)
    except Exception:
        return {}
    if not isinstance(data, dict):
        return {}
    return {str(k): str(v) for k, v in data.items() if not isinstance(v, (dict, list))}


def target_type_of_path(path: str) -> Optional[str]:
    """target_type for any of the three folder layouts."""
    if path.startswith("config/input_data_config/"):
        name = path[len("config/input_data_config/"):]
        return name.rsplit(".", 1)[0] if "/" not in name else None
    if path.startswith("config/input_data_config_dummy/"):
        name = path[len("config/input_data_config_dummy/"):]
        return name.rsplit(".", 1)[0] if "/" not in name else None
    if path.startswith("sql_column_mapping/"):
        rest = path[len("sql_column_mapping/"):]
        return rest.split("/")[0] if "/" in rest else None
    return None


def insight_type_of_path(path: str) -> Optional[str]:
    """insight_type = the file name, for sql_column_mapping files."""
    if not path.startswith("sql_column_mapping/"):
        return None
    return path.rsplit("/", 1)[-1].rsplit(".", 1)[0]


# ---------------------------------------------------------------- extraction
def extract_attributes(sql_expr: str) -> Set[str]:
    """Every alias-qualified column referenced in a SQL expression."""
    if not sql_expr:
        return set()
    return set(_COLUMN_REF.findall(sql_expr))


def _md5_arguments(sql_expr: str) -> List[str]:
    """The full argument text of every md5(...) call, matched with balanced
    parentheses so nested calls survive intact -- e.g.
    `substring(md5(lower(trim(b.x))),1,8)` yields `lower(trim(b.x))`."""
    out = []
    for m in _MD5_START.finditer(sql_expr or ""):
        i = m.end()          # just past the opening paren
        depth, start = 1, i
        while i < len(sql_expr) and depth:
            if sql_expr[i] == "(":
                depth += 1
            elif sql_expr[i] == ")":
                depth -= 1
            i += 1
        out.append(sql_expr[start:i - 1] if depth == 0 else sql_expr[start:])
    return out


def extract_md5_attributes(sql_expr: str) -> Set[str]:
    """Attributes that appear *inside* an md5(...) call -- i.e. attributes
    this expression actually masks. `MD5('literal')` yields nothing, which
    is correct: no column is being protected there."""
    found: Set[str] = set()
    for arg in _md5_arguments(sql_expr):
        found |= extract_attributes(arg)
    return found


def is_attribute_md5_masked(sql_expr: str, attribute: str) -> bool:
    return attribute in extract_md5_attributes(sql_expr)


# ---------------------------------------------------------------- registry
def build_md5_registry(dummy_files: Dict[str, str]) -> Dict[str, Set[str]]:
    """`attribute -> {target_types where it is MD5-masked}`, across every
    input_data_config_dummy file. This is the evidence base the LLM is
    calibrated against: every attribute the codebase already treats as CID.
    """
    registry: Dict[str, Set[str]] = {}
    for path, content in dummy_files.items():
        tt = target_type_of_path(path)
        if not tt:
            continue
        for _key, expr in parse_config_mapping(content, tt).items():
            for attr in extract_md5_attributes(expr):
                registry.setdefault(attr, set()).add(tt)
    return registry


# ---------------------------------------------------------------- diffing
@dataclass
class NewAttribute:
    """An attribute introduced or changed by this branch."""
    attribute: str
    file_path: str
    target_type: str
    key: str                       # the YAML key it appeared under
    sql_expr: str
    change_type: str               # file-level: added / modified / renamed
    reason: str                    # "new key" | "changed expression"
    insight_type: Optional[str] = None   # only for sql_column_mapping files

    @property
    def folder(self) -> str:
        if self.file_path.startswith("config/input_data_config_dummy/"):
            return "input_data_config_dummy"
        if self.file_path.startswith("config/input_data_config/"):
            return "input_data_config"
        if self.file_path.startswith("sql_column_mapping/"):
            return "sql_column_mapping"
        return "other"


def diff_file_attributes(path: str, before: Optional[str], after: Optional[str],
                          change_type: str) -> List[NewAttribute]:
    """Attributes introduced or changed in one file between two refs.

    An attribute counts as new/changed when its key is new, or when the key
    existed but its SQL expression changed and the attribute wasn't there
    before. Attributes untouched by this branch are ignored -- this is a
    branch check, not a whole-repository audit.
    """
    tt = target_type_of_path(path)
    if not tt or after is None:
        return []

    if path.startswith("sql_column_mapping/"):
        map_after = parse_sql_column_mapping(after)
        map_before = parse_sql_column_mapping(before)
        insight = insight_type_of_path(path)
    else:
        map_after = parse_config_mapping(after, tt)
        map_before = parse_config_mapping(before, tt)
        insight = None

    out: List[NewAttribute] = []
    for key, expr in map_after.items():
        prev = map_before.get(key)
        if prev == expr:
            continue                                   # untouched
        reason = "new key" if key not in map_before else "changed expression"
        prev_attrs = extract_attributes(prev) if prev else set()
        for attr in sorted(extract_attributes(expr) - prev_attrs):
            out.append(NewAttribute(attribute=attr, file_path=path, target_type=tt,
                                     key=key, sql_expr=expr, change_type=change_type,
                                     reason=reason, insight_type=insight))
    return out
