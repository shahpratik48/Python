"""
Emails the CID report as an attachment.

Sending is intentionally decoupled from the pass/fail outcome: the report
goes out either way, so a clean run is positively confirmed rather than
silent. Send failures are reported but never mask the check's own result --
losing the email should not turn a real CID finding into a different error.
"""
from __future__ import annotations

import os
import smtplib
from email.message import EmailMessage
from typing import List, Optional


def send_report(settings, report_path: str, html_body: str, failed: bool,
                finding_count: int, progress=None) -> str:
    """Returns a human-readable status string (also shown in logs)."""
    def log(m):
        if progress:
            progress(m)

    if not settings.email_to:
        msg = ("No recipients configured (set CID_EMAIL_TO) -- email skipped. "
               f"Report is still available at {report_path}")
        log(msg)
        if settings.skip_email_if_no_recipients:
            return msg
        raise RuntimeError(msg)

    status = "FAIL" if failed else "PASS"
    subject = (f"{settings.email_subject_prefix} {status} - {settings.branch} - "
               f"{finding_count} finding(s)")

    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = settings.email_from
    msg["To"] = ", ".join(settings.email_to)
    msg.set_content(
        f"NLG CID attribute check\n\n"
        f"Result   : {status}\n"
        f"Branch   : {settings.branch}\n"
        f"Compared : {settings.base_branch}\n"
        f"Findings : {finding_count}\n\n"
        f"The full categorised report is attached as HTML.\n"
        + ("Every finding must be resolved or explicitly accepted before this branch merges.\n"
           if failed else "No CID issues were found in this branch's changes.\n"))
    # inline HTML as well, so it is readable without opening the attachment
    msg.add_alternative(html_body, subtype="html")

    with open(report_path, "rb") as fh:
        msg.add_attachment(fh.read(), maintype="text", subtype="html",
                           filename=os.path.basename(report_path))

    try:
        if settings.smtp_use_tls:
            with smtplib.SMTP(settings.smtp_host, settings.smtp_port, timeout=60) as s:
                s.starttls()
                if settings.smtp_user:
                    s.login(settings.smtp_user, settings.smtp_password or "")
                s.send_message(msg)
        else:
            with smtplib.SMTP(settings.smtp_host, settings.smtp_port, timeout=60) as s:
                if settings.smtp_user:
                    s.login(settings.smtp_user, settings.smtp_password or "")
                s.send_message(msg)
        out = f"Report emailed to {', '.join(settings.email_to)} (subject: {subject})"
        log(out)
        return out
    except Exception as e:
        out = (f"EMAIL SEND FAILED ({type(e).__name__}: {e}). The report is still written to "
               f"{report_path} and the check result below is unaffected.")
        log(out)
        return out
