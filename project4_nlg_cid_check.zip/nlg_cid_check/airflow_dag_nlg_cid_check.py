"""
airflow_dag_nlg_cid_check.py
-----------------------------
Runs the NLG CID attribute check against a GitLab branch.

Connects to GitLab only -- there is no local-file mode. Secrets come from
the same Airflow Variables the other NLG projects use:

    GENESIS_DDLC_IKG_GIT_SECRET   GitLab token, and the LLM key

Optional Airflow Variables:
    CID_BRANCH                branch to check          (default: nlg-master)
    CID_BASE_BRANCH           branch to compare with   (default: develop)
    CID_EMAIL_TO              comma-separated recipients
    CID_SMTP_HOST / _PORT / _USER / _PASSWORD / _USE_TLS
    CID_EMAIL_FROM

Behaviour: the HTML report is ALWAYS written and ALWAYS emailed as an
attachment, whatever the outcome. The task then fails if the report
contains any flag, and passes if it is clean -- so a red task means "CID
issues found", never "the check didn't run".

Deploy this file together with cid_*.py in the SAME folder (no subfolders);
the report is written beside them.
"""
from __future__ import annotations

import os
import sys
from datetime import datetime, timedelta

from airflow import DAG
from airflow.models import Variable
from airflow.operators.python import PythonOperator

# the cid_*.py modules live next to this DAG file
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from cid_main import run_cid_check
from cid_settings import CidSettings


def _var(key, default=None):
    try:
        return Variable.get(key, default_var=default)
    except Exception:
        return default


def task_run_cid_check(**kwargs):
    conf = (kwargs.get("dag_run").conf if kwargs.get("dag_run") else {}) or {}

    settings = CidSettings()
    # dag_run.conf wins, then Airflow Variable, then the built-in default
    settings.branch = conf.get("branch") or _var("CID_BRANCH", settings.branch)
    settings.base_branch = conf.get("base_branch") or _var("CID_BASE_BRANCH", settings.base_branch)

    recipients = conf.get("email_to") or _var("CID_EMAIL_TO", "")
    if recipients:
        settings.email_to = [e.strip() for e in str(recipients).split(",") if e.strip()]
    settings.email_from = _var("CID_EMAIL_FROM", settings.email_from)
    settings.smtp_host = _var("CID_SMTP_HOST", settings.smtp_host)
    settings.smtp_port = int(_var("CID_SMTP_PORT", str(settings.smtp_port)))
    settings.smtp_user = _var("CID_SMTP_USER", settings.smtp_user)
    settings.smtp_password = _var("CID_SMTP_PASSWORD", settings.smtp_password)
    settings.smtp_use_tls = str(_var("CID_SMTP_USE_TLS", "false")).lower() == "true"

    # report lands next to this DAG file
    settings.output_dir = os.path.dirname(os.path.abspath(__file__))

    settings.resolve_secrets(interactive=False)   # Airflow Variables, never prompts
    if not settings.gitlab_token:
        raise RuntimeError(
            "No GitLab token resolved. Set the Airflow Variable "
            f"'{settings.gitlab_token_var}' (or the GITLAB_TOKEN env var).")
    if not settings.llm_enabled:
        # not fatal: unclassifiable attributes become UNDETERMINED findings,
        # which fail the task anyway -- so nothing slips through silently.
        print("WARNING: no LLM key resolved. Attributes not already in the MD5 registry "
              "will be reported as UNDETERMINED and will fail this task.")

    result = run_cid_check(settings, progress=print)

    ti = kwargs["ti"]
    ti.xcom_push(key="report_path", value=result.report_path)
    ti.xcom_push(key="finding_count", value=len(result.findings))
    ti.xcom_push(key="email_status", value=result.email_status)
    ti.xcom_push(key="failed", value=result.failed)

    print("\n" + "=" * 70)
    print(f"Branch        : {result.branch}  (vs {result.base_branch})")
    print(f"Files changed : {len(result.changed_files)}")
    print(f"New attributes: {len({n.attribute for n in result.new_attributes})}")
    print(f"Findings      : {len(result.findings)}")
    print(f"Report        : {result.report_path}")
    print(f"Email         : {result.email_status}")
    print("=" * 70)

    if result.failed:
        by_cat = {}
        for f in result.findings:
            by_cat.setdefault(f.category, []).append(f)
        lines = [f"  - {cat}: {len(items)}" for cat, items in by_cat.items()]
        raise RuntimeError(
            f"CID check FAILED: {len(result.findings)} finding(s) on branch '{result.branch}'.\n"
            + "\n".join(lines)
            + f"\nThe full categorised report was emailed and written to {result.report_path}.")

    print("CID check PASSED -- no findings.")


default_args = {
    "owner": "NLG",
    "retries": 0,               # a failure here is a real finding, not a flake -- do not retry
    "retry_delay": timedelta(minutes=2),
    "email_on_failure": True,
}

with DAG(
    dag_id="nlg_cid_check",
    default_args=default_args,
    description="Flags CID attributes introduced on a branch without proper MD5 masking. "
                'Trigger with {"branch": "<name>"} to override the default.',
    start_date=datetime(2024, 1, 1),
    schedule_interval=_var("CID_CHECK_SCHEDULE", None),   # None = on-demand only
    catchup=False,
    tags=["NLG", "CID", "compliance"],
) as dag:

    run_check = PythonOperator(
        task_id="run_cid_check",
        python_callable=task_run_cid_check,
    )
