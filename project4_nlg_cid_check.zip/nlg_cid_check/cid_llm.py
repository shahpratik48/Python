"""
LLM classification of whether a newly introduced attribute is CID.

The evidence base is the MD5 registry: every attribute the codebase
already masks in input_data_config_dummy. Those attributes ARE the
organisation's own working definition of CID, so they are handed to the
model as calibration rather than relying on a generic notion of PII.

Two ways an attribute is judged CID:
  1. It is already in the MD5 registry -- decided without an LLM call,
     since the codebase has already made that determination explicitly.
  2. Otherwise the LLM is asked, given the registry as examples plus the
     attribute's name and SQL expression.

A deliberate design point: when the LLM is unavailable, errors, returns
malformed output, or answers with low confidence, the result is
UNDETERMINED -- never a silent "not CID". Undetermined attributes are
flagged in the report as their own category, because an unreviewed
attribute that might be CID is exactly the thing worth a human look.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Dict, List, Optional, Set

CID_YES = "cid"
CID_NO = "not_cid"
CID_UNKNOWN = "undetermined"


@dataclass
class CidVerdict:
    attribute: str
    verdict: str          # CID_YES | CID_NO | CID_UNKNOWN
    basis: str            # "md5_registry" | "llm" | "llm_unavailable" | "llm_error" | "llm_low_confidence"
    confidence: str = ""
    reasoning: str = ""

    @property
    def is_cid(self) -> bool:
        return self.verdict == CID_YES

    @property
    def needs_review(self) -> bool:
        return self.verdict == CID_UNKNOWN


SYSTEM_PROMPT = """You are a data-privacy reviewer for a financial-services data pipeline. You decide \
whether a database attribute (column) holds CID -- Client Identifying Data -- meaning data that \
identifies, or helps identify, a specific client, individual or account holder.

You will be given a list of attributes that this codebase ALREADY treats as CID (they are MD5-masked \
in its dummy/non-production configuration). That list is the organisation's own working definition of \
CID -- infer the pattern from it and apply the same standard. Consider both the attribute name and the \
SQL expression it comes from.

Guidance:
- Names, contact details, government identifiers, dates of birth, addresses, and account/household \
identifiers tied to a person are CID.
- Aggregates, counts, monetary amounts, dates of events, product or category labels, and internal \
non-identifying codes are NOT CID.
- A boolean flag that merely indicates whether some data exists (has_email, is_verified, dob_on_file) \
is NOT itself CID -- it is an indicator, not the identifying value.
- If you are genuinely unsure, say so with low confidence rather than guessing. An honest \
"unsure" is more useful here than a confident wrong answer, because unsure results get human review.

Reply with STRICT JSON only, no markdown fences, no commentary:
{"results": [{"attribute": "<name>", "is_cid": true|false, "confidence": "low|medium|high", \
"reasoning": "<one short sentence>"}]}
Return exactly one entry per attribute you were given."""


def _call_llm(settings, system_prompt: str, user_prompt: str) -> Optional[str]:
    import requests
    body = {
        "messages": [{"role": "system", "content": system_prompt},
                     {"role": "user", "content": user_prompt}],
        "temperature": settings.llm_temperature,
        "max_tokens": settings.llm_max_tokens,
        "response_format": {"type": "json_object"},
    }
    if settings.llm_provider == "azure_openai":
        url = (settings.azure_openai_endpoint.rstrip("/") +
               f"/openai/deployments/{settings.azure_openai_deployment}/chat/completions"
               f"?api-version={settings.azure_openai_api_version}")
        headers = {"api-key": settings.azure_openai_api_key, "Content-Type": "application/json"}
        r = requests.post(url, headers=headers, json=body, timeout=120)
        if r.status_code == 404:
            # some deployments expose the v1-style path instead
            body["model"] = settings.azure_openai_deployment
            r = requests.post(settings.azure_openai_endpoint.rstrip("/") + "/chat/completions",
                              headers=headers, json=body, timeout=120)
    elif settings.llm_provider == "azure_gateway":
        body["model"] = settings.llm_model
        r = requests.post(settings.llm_gateway_url.rstrip("/") + "/v1/chat/completions",
                          headers={"Authorization": f"Bearer {settings.llm_api_key}",
                                   "Content-Type": "application/json"},
                          json=body, timeout=120)
    else:
        return None
    r.raise_for_status()
    return r.json()["choices"][0]["message"]["content"]


def _parse(raw: str) -> Dict[str, dict]:
    txt = (raw or "").strip()
    if txt.startswith("```"):
        txt = txt.strip("`")
        if txt.lower().startswith("json"):
            txt = txt[4:]
    data = json.loads(txt)
    results = data.get("results", data if isinstance(data, list) else [])
    out = {}
    for item in results or []:
        if isinstance(item, dict) and item.get("attribute"):
            out[str(item["attribute"])] = item
    return out


def classify_attributes(attributes: List[str],
                        md5_registry: Dict[str, Set[str]],
                        sql_context: Dict[str, str],
                        settings,
                        batch_size: int = 25,
                        progress=None) -> Dict[str, CidVerdict]:
    """Classify each attribute as CID / not CID / undetermined.

    `md5_registry` is attribute -> target_types where already masked.
    `sql_context` is attribute -> a representative SQL expression, giving
    the model something concrete beyond the bare name.
    """
    def log(m):
        if progress:
            progress(m)

    verdicts: Dict[str, CidVerdict] = {}
    to_ask: List[str] = []

    for attr in attributes:
        if attr in md5_registry:
            tts = ", ".join(sorted(md5_registry[attr])[:4])
            verdicts[attr] = CidVerdict(
                attr, CID_YES, "md5_registry", "high",
                f"Already MD5-masked in input_data_config_dummy (target_type: {tts}), so the codebase "
                f"already treats this attribute as CID.")
        else:
            to_ask.append(attr)

    if not to_ask:
        log(f"All {len(attributes)} attribute(s) resolved from the MD5 registry -- no LLM call needed.")
        return verdicts

    if not settings.llm_enabled:
        log(f"LLM not configured -- {len(to_ask)} attribute(s) left UNDETERMINED (flagged for review).")
        for attr in to_ask:
            verdicts[attr] = CidVerdict(
                attr, CID_UNKNOWN, "llm_unavailable", "",
                "No LLM key configured, so this attribute could not be classified. Flagged for manual "
                "review rather than assumed safe.")
        return verdicts

    known = sorted(md5_registry.keys())
    for i in range(0, len(to_ask), batch_size):
        batch = to_ask[i:i + batch_size]
        log(f"Asking LLM about {len(batch)} attribute(s) [{i + 1}-{i + len(batch)} of {len(to_ask)}]...")
        listing = "\n".join(
            f"- {a}   (SQL: {str(sql_context.get(a, ''))[:160]})" for a in batch)
        user_prompt = (
            f"Attributes ALREADY treated as CID in this codebase (MD5-masked), as calibration:\n"
            f"{', '.join(known)}\n\n"
            f"Classify each of the following attributes:\n{listing}")
        try:
            parsed = _parse(_call_llm(settings, SYSTEM_PROMPT, user_prompt) or "")
        except Exception as e:
            log(f"  LLM call failed ({type(e).__name__}) -- batch left UNDETERMINED.")
            for attr in batch:
                verdicts[attr] = CidVerdict(
                    attr, CID_UNKNOWN, "llm_error", "",
                    f"LLM classification failed ({type(e).__name__}: {e}). Flagged for manual review.")
            continue

        for attr in batch:
            item = parsed.get(attr)
            if not item:
                verdicts[attr] = CidVerdict(
                    attr, CID_UNKNOWN, "llm_error", "",
                    "LLM response did not include a verdict for this attribute. Flagged for review.")
                continue
            conf = str(item.get("confidence", "")).lower()
            reasoning = str(item.get("reasoning", ""))
            if conf == "low":
                verdicts[attr] = CidVerdict(
                    attr, CID_UNKNOWN, "llm_low_confidence", conf,
                    f"LLM was unsure ({reasoning}). Flagged for manual review rather than assumed safe.")
            elif bool(item.get("is_cid")):
                verdicts[attr] = CidVerdict(attr, CID_YES, "llm", conf, reasoning)
            else:
                verdicts[attr] = CidVerdict(attr, CID_NO, "llm", conf, reasoning)

    return verdicts
