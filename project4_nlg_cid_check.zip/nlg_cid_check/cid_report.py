"""
HTML report for the CID check.

Self-contained (inline CSS, no external assets) so it renders correctly as
an email attachment opened straight from a mail client.

Structure: verdict banner, run context, counts by category, then the
findings themselves grouped by category, then the supporting evidence --
every attribute the branch introduced with how it was classified, and
every file the branch changed. The evidence sections matter as much as the
findings: they let a reviewer confirm the check looked at the right things,
rather than taking a clean result on faith.
"""
from __future__ import annotations

import datetime as _dt
import html
import os
from typing import Dict, List, Optional

from cid_rules import CAT_RULE1, CAT_RULE2, CAT_RULE3, CAT_RULE4, Finding

CATEGORY_ORDER = [CAT_RULE1, CAT_RULE2, CAT_RULE3, CAT_RULE4]

CATEGORY_HELP = {
    CAT_RULE1: ("A CID attribute was added or changed in an input_data_config file, and the same "
                "attribute also appears in one or more sql_column_mapping files for that target_type. "
                "sql_column_mapping is the non-CID environment, so the attribute must not be there."),
    CAT_RULE2: ("A CID attribute was added or changed directly inside a sql_column_mapping file. "
                "That folder is the non-CID environment and must not contain CID attributes."),
    CAT_RULE3: ("A CID attribute was added or changed in an input_data_config file, but it is not "
                "MD5-masked in the matching input_data_config_dummy file. Every CID attribute must be "
                "masked in the dummy environment."),
    CAT_RULE4: ("The CID status of this attribute could not be determined -- either no LLM was "
                "available, the call failed, or the model was not confident. Flagged deliberately: an "
                "unreviewed attribute that might be CID needs a human decision."),
}

_CSS = """
body{font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;margin:0;padding:24px;
color:#1a1a1a;background:#f6f7f9;}
.wrap{max-width:1100px;margin:0 auto;background:#fff;padding:28px 32px;border-radius:10px;
box-shadow:0 1px 3px rgba(0,0,0,.08);}
h1{margin:0 0 4px;font-size:24px;}
h2{margin:32px 0 10px;font-size:18px;border-bottom:2px solid #e6e8eb;padding-bottom:6px;}
h3{margin:22px 0 8px;font-size:15px;}
.sub{color:#666;font-size:13px;margin-bottom:20px;}
.banner{padding:14px 18px;border-radius:8px;font-weight:700;font-size:17px;margin:18px 0 8px;}
.pass{background:#e6f5ec;color:#0b6b36;border:1px solid #9fd6b6;}
.fail{background:#fdecec;color:#9b1c1c;border:1px solid #f0b4b4;}
table{border-collapse:collapse;width:100%;margin:10px 0 4px;font-size:13px;}
th{background:#305496;color:#fff;text-align:left;padding:8px 10px;font-weight:600;}
td{border-bottom:1px solid #e6e8eb;padding:8px 10px;vertical-align:top;}
tr:nth-child(even) td{background:#fafbfc;}
code{font-family:Consolas,Monaco,monospace;background:#f2f3f5;padding:1px 5px;border-radius:3px;
font-size:12px;word-break:break-all;}
.sev-high{color:#9b1c1c;font-weight:700;}
.sev-medium{color:#9a6700;font-weight:700;}
.pill{display:inline-block;padding:2px 9px;border-radius:11px;font-size:11px;font-weight:600;}
.pill-cid{background:#fdecec;color:#9b1c1c;}
.pill-not{background:#e6f5ec;color:#0b6b36;}
.pill-unk{background:#fff6e0;color:#9a6700;}
.help{background:#f2f6ff;border-left:3px solid #305496;padding:9px 13px;margin:8px 0 12px;
font-size:13px;color:#33415c;}
.meta{font-size:13px;color:#444;}
.meta td{border:none;padding:3px 12px 3px 0;}
.none{color:#0b6b36;font-size:14px;padding:8px 0;}
.foot{margin-top:34px;padding-top:14px;border-top:1px solid #e6e8eb;color:#777;font-size:12px;}
"""


def _e(x) -> str:
    return html.escape(str(x if x is not None else ""))


def _findings_table(items: List[Finding]) -> str:
    rows = []
    for f in items:
        related = "<br>".join(f"<code>{_e(r)}</code>" for r in f.related_files) or "&mdash;"
        rows.append(f"""<tr>
<td><span class="sev-{_e(f.severity)}">{_e(f.severity.upper())}</span></td>
<td><code>{_e(f.attribute)}</code></td>
<td>{_e(f.target_type)}{f"<br><small>insight: {_e(f.insight_type)}</small>" if f.insight_type else ""}</td>
<td><code>{_e(f.source_file)}</code><br><small>key: <code>{_e(f.key)}</code></small></td>
<td>{_e(f.detail)}</td>
<td>{related}</td>
<td><small>{_e(f.cid_basis)}<br>{_e(f.cid_reasoning)}</small></td>
</tr>""")
    return f"""<table>
<tr><th>Severity</th><th>Attribute</th><th>Target type</th><th>Introduced in</th>
<th>Why flagged</th><th>Related files</th><th>CID basis</th></tr>
{''.join(rows)}</table>"""


def build_html(branch: str, base_branch: str, commit, changed_files, new_attributes,
               verdicts: Dict, findings: List[Finding], md5_registry_size: int,
               notes: Optional[List[str]] = None) -> str:
    generated = _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    failed = len(findings) > 0

    banner = (f'<div class="banner fail">FAIL &mdash; {len(findings)} CID issue(s) flagged. '
              f'This branch should not merge until they are resolved or explicitly accepted.</div>'
              if failed else
              '<div class="banner pass">PASS &mdash; no CID issues found in this branch\'s changes.</div>')

    counts = {c: [f for f in findings if f.category == c] for c in CATEGORY_ORDER}
    summary_rows = "".join(
        f"<tr><td>{_e(c)}</td><td><b>{len(counts[c])}</b></td></tr>" for c in CATEGORY_ORDER)

    # findings by category
    sections = []
    for cat in CATEGORY_ORDER:
        items = counts[cat]
        sections.append(f"<h3>{_e(cat)} &mdash; {len(items)} finding(s)</h3>"
                        f'<div class="help">{_e(CATEGORY_HELP[cat])}</div>')
        sections.append(_findings_table(items) if items
                        else '<div class="none">No findings in this category.</div>')

    # changed files
    if changed_files:
        cf_rows = "".join(
            f"<tr><td>{_e(c.change_type)}</td><td><code>{_e(c.path)}</code></td>"
            f"<td>{'<code>' + _e(c.old_path) + '</code>' if c.change_type == 'renamed' else '&mdash;'}</td></tr>"
            for c in changed_files)
        cf_html = (f"<table><tr><th>Change</th><th>File</th><th>Previous path</th></tr>{cf_rows}</table>")
    else:
        cf_html = ('<div class="none">No files changed under input_data_config, '
                   'input_data_config_dummy or sql_column_mapping.</div>')

    # attributes introduced + classification
    if new_attributes:
        seen = {}
        for na in new_attributes:
            seen.setdefault(na.attribute, na)
        at_rows = []
        for attr, na in sorted(seen.items()):
            v = verdicts.get(attr)
            if v is None:
                pill, basis, reason = '<span class="pill pill-unk">n/a</span>', "", ""
            elif v.is_cid:
                pill = '<span class="pill pill-cid">CID</span>'
                basis, reason = v.basis, v.reasoning
            elif v.needs_review:
                pill = '<span class="pill pill-unk">UNDETERMINED</span>'
                basis, reason = v.basis, v.reasoning
            else:
                pill = '<span class="pill pill-not">not CID</span>'
                basis, reason = v.basis, v.reasoning
            at_rows.append(
                f"<tr><td><code>{_e(attr)}</code></td><td>{pill}</td><td>{_e(na.target_type)}</td>"
                f"<td><code>{_e(na.file_path)}</code></td><td><code>{_e(na.key)}</code></td>"
                f"<td><small>{_e(basis)}<br>{_e(reason)}</small></td></tr>")
        at_html = (f"<table><tr><th>Attribute</th><th>Classification</th><th>Target type</th>"
                   f"<th>First seen in</th><th>Key</th><th>Basis</th></tr>{''.join(at_rows)}</table>")
    else:
        at_html = ('<div class="none">This branch introduced no new or changed attributes in the '
                   'monitored folders.</div>')

    notes_html = ""
    if notes:
        notes_html = ("<h2>Run notes</h2><ul>" +
                      "".join(f"<li>{_e(n)}</li>" for n in notes) + "</ul>")

    commit_line = (f"{_e(getattr(commit, 'short_id', ''))} &mdash; {_e(getattr(commit, 'title', ''))} "
                   f"({_e(getattr(commit, 'author_name', ''))})") if commit else "&mdash;"

    return f"""<!DOCTYPE html><html><head><meta charset="utf-8">
<title>NLG CID Check &mdash; {_e(branch)}</title><style>{_CSS}</style></head><body><div class="wrap">
<h1>NLG CID Attribute Check</h1>
<div class="sub">Client-Identifying Data compliance for branch changes</div>
{banner}
<table class="meta">
<tr><td><b>Branch</b></td><td>{_e(branch)}</td></tr>
<tr><td><b>Compared against</b></td><td>{_e(base_branch)}</td></tr>
<tr><td><b>Latest commit</b></td><td>{commit_line}</td></tr>
<tr><td><b>Generated</b></td><td>{_e(generated)}</td></tr>
<tr><td><b>Files changed (in scope)</b></td><td>{len(changed_files)}</td></tr>
<tr><td><b>Attributes introduced / changed</b></td><td>{len({n.attribute for n in new_attributes})}</td></tr>
<tr><td><b>Known CID attributes (MD5 registry)</b></td><td>{md5_registry_size}</td></tr>
</table>
{notes_html}
<h2>Findings by category</h2>
<table><tr><th>Category</th><th>Count</th></tr>{summary_rows}
<tr><td><b>Total</b></td><td><b>{len(findings)}</b></td></tr></table>
{''.join(sections)}
<h2>Evidence &mdash; attributes introduced or changed by this branch</h2>
{at_html}
<h2>Evidence &mdash; files changed in scope</h2>
{cf_html}
<div class="foot">
An attribute is the database column referenced in a SQL expression &mdash; in
<code>account_name: b.acc_i</code> the attribute is <code>acc_i</code>. An attribute is treated as CID
when it is already MD5-masked somewhere in <code>input_data_config_dummy</code>, or when an LLM
classifies it as CID using those masked attributes as calibration. Anything that could not be
classified is flagged rather than assumed safe.
</div></div></body></html>"""


def write_report(html_text: str, output_dir: str, branch: str) -> str:
    """Writes the report beside the scripts -- no subfolders."""
    safe = "".join(ch if (ch.isalnum() or ch in "._-") else "_" for ch in branch).strip("_")
    stamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    path = os.path.join(output_dir, f"cid_report_{safe}_{stamp}.html")
    os.makedirs(output_dir, exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(html_text)
    return path
