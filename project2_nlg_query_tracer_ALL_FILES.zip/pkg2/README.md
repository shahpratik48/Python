# nlg_query_tracer (Project 2)

A **separate project** from `nlg_dag_agent` (the DAG hierarchy / impact-analysis
agent). Recovers the **final SQL query** nlg uses to fetch narrative-generation
input data for each `insight_type` -- a query the real system never stores
anywhere (it builds it, runs it, generates a narrative from the result, and
persists only the narrative text, per insight_type per record, in Greenplum).

## How: run the same logic nlg itself uses -- not an LLM guess

This tool imports and **actually runs** the real query-building function from
`nlg-src`:

```
fetch_data_with_insights_for_cl / _for_fl / _for_pr
```

(chosen the same way the real code chooses it: from `insights_target_user_type`
in `config/input_data_config/<target_type>.yml`), against a stub database
connector that intercepts every `execute_query_with_records_return` /
`execute_sql` / `get_table_columns` call instead of hitting a real database --
recording the SQL text and returning an empty/falsy result so the real code
gracefully takes its "no data" branch and keeps running its real logic to
completion.

**This is the real function running with real resolved config** -- table/
schema names from `config/nlg_db_tables.ini`, column mappings from
`config/input_data_config/<target_type>.yml`, ref-table join config, not-null
filters, all pulled from the actual files in the repo. It is not a
reconstruction or approximation.

Validated against your real codebase: **40/40 insight_types across
`account_holding_mmf`, `account_sbl`, and `fl_ubs_fa`** (spanning both the
`_for_cl` and `_for_fl` variants, including one with a `ref_table_columns`
join) captured successfully via real code execution -- zero LLM fallback
needed. See `sample_output/narrative_queries.xlsx`.

An LLM-based reconstruction is kept only as a **fallback** for the case where
real execution can't run at all in your environment (e.g. a required
third-party package auto-stubbing couldn't safely paper over). Every row's
`resolution_method` says exactly how it was produced -- `code_execution` (the
real thing) or `llm_fallback` (verify before trusting).

## The two config sources -- getting this right mattered

Real execution failed once during development with `KeyError:
'input_tbl_account_holding_mmf'` -- that's what led to finding the actual
shape of the real inputs. There are two genuinely separate config sources,
and conflating them silently produces subtly wrong queries:

| Source | Feeds | Notes |
|---|---|---|
| `config/nlg_db_tables.ini` | `nlg_db_tables` (schema/table names, `input_tbl_<target_type>`, `odm_insights_tbl`, ...) | **Environment-sectioned** (`[dev_active]`, `[prod_active]`, ...) -- this tool defaults to `prod_active`, override with `odm_env=`/`--odm-env`. |
| `config/input_data_config/<target_type>.yml` | `insights_target_user_type` (picks the variant), `input_db_join_col`, `target_key_conversion`, base `sql_column_mapping` | Per-target_type, not per-environment. |

Plus, per insight_type: `sql_column_mapping/<tt>/<it>.(yml\|json)` (optional
column-mapping overrides), `ref_table_columns/<tt>/<it>.yml` (optional
ref-table join config), `group_logic/<tt>/<it>.yml` (`fields_not_null` only).

## Files

| File | Purpose |
|---|---|
| `nlg_query_tracer/context_gatherer.py` | Gathers config from both sources above for one (target_type, insight_type) pair. Pure file lookup, no execution -- testable/inspectable on its own. |
| `nlg_query_tracer/query_capture.py` | The real-execution harness: writes `nlg-src` to a temp dir under the `nlg.src.*` namespace it expects, imports the real function, runs it against a stub DB, captures every SQL statement. |
| `nlg_query_tracer/tracer.py` | `trace_insight_type()` / `trace_target_type()` / `trace_many_target_types()` -- wraps `query_capture` into the `QueryResult` shape, with LLM fallback only if execution fails. |
| `nlg_query_tracer/xlsx_report.py` | Exports results to a formatted `.xlsx`. |
| `nlg_query_tracer/__main__.py` | CLI. |
| `run_query_tracer.ipynb` | Notebook walkthrough. |
| `sample_output/narrative_queries.xlsx` | Real output: 40 insight_types across 3 target_types, all via real code execution. |

## Quick start -- notebook

```python
from nlg_dag_agent import Settings, build_hierarchy
from nlg_query_tracer import trace_target_type, export_xlsx

settings = Settings()
settings.local_dags_dir = "./nlg-dag/dags"
settings.local_src_dir  = "./nlg-src/src"
settings.resolve_secrets(interactive=True)   # LLM key only needed if execution ever falls back

hierarchy = build_hierarchy(settings)
results = trace_target_type(hierarchy, "account_holding_mmf", settings=settings)
export_xlsx(results, "narrative_queries.xlsx")
```

See `run_query_tracer.ipynb` for the full walkthrough, including inspecting
every SQL statement the real code issued (not just the primary query) before
trusting a row.

## Quick start -- CLI

```bash
python -m nlg_query_tracer trace \
  --target-type account_holding_mmf,account_sbl,fl_ubs_fa \
  --local-dags ./nlg-dag/dags --local-src ./nlg-src/src \
  --odm-env prod_active \
  --xlsx narrative_queries.xlsx

# single insight_type
python -m nlg_query_tracer trace \
  --target-type account_holding_mmf --insight-type si_mmf_to_core_savings_promo_rate \
  --xlsx one_query.xlsx
```

## Output columns

| Column | Meaning |
|---|---|
| `target_type` / `insight_type` | which insight_type this row is for |
| `narrative_query` | the captured/reconstructed final SQL |
| `resolution_method` | `code_execution` (real code actually ran -- trust it) / `llm_fallback` (execution failed, LLM guessed instead -- verify) / `none` (both failed) |
| `variant_function_used` | which `fetch_data_with_insights_*` function was actually run |
| `confidence` | `high` for `code_execution`; the LLM's own self-assessment for `llm_fallback` |
| `supporting_queries` | other SQL the real code issued along the way (dummy-household checks, ref-table lookups) -- not the main query, kept for transparency |
| `source_files_used` | config/source files gathered for this row |
| `warnings` | non-fatal issues (missing config file, auto-stubbed import, etc.) |

## Environment requirements

Real execution imports the actual `nlg-src` code, so it needs whatever
third-party packages that code needs *at import time* -- the same set
already installed wherever the real DAG runs (`psycopg2`, and whatever your
`utils_narratives.py` import chain pulls in). Third-party modules that are
imported by the file but never actually touched by the function we call
(e.g. `airflow`, pulled in for an unrelated helper in the same file) are
auto-stubbed automatically with a permissive fake -- reported per-row in
`warnings` for transparency, never silently hidden. If a captured query ever
looks wrong, check `warnings` first and install the real package to rule
out a bad stub.

## Known limitations / extension points

- Extend `context_gatherer.VARIANT_BY_USER_TYPE` / `HELPER_FUNCTIONS` if your
  codebase adds new `fetch_data_with_insights_*` variants.
- Extend `query_capture._candidate_kwargs` if a variant needs a parameter
  this harness doesn't already know how to supply -- `execution_error` will
  say exactly which one.
- `is_prospect_run=True` (`--prospect-run`) switches to the
  `fetch_data_with_insights_for_pr` code path.
- No caching/parallelism yet -- each insight_type is one real function call
  (fast; no network I/O), but tracing many target_types sequentially will
  still take a moment for very large repos.
- If real execution consistently fails for a given insight_type, `notes`
  and `execution_error` explain exactly where it broke (often: a config
  field the harness didn't anticipate) -- that's usually a quick fix to
  `_candidate_kwargs` rather than a fundamental limitation.
