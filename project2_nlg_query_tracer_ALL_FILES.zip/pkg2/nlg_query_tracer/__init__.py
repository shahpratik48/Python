"""
nlg_query_tracer
=================
Separate project from nlg_dag_agent (Project 1), though it reuses
nlg_dag_agent's source-loading/indexing so the two never fall out of sync
with each other's view of the codebase.

The real system never stores the SQL query it uses to fetch data for each
insight_type's narrative -- it builds the query, runs it, generates the
narrative text from the result, and stores only the narrative (per
insight_type, per record, in Greenplum). This project recovers the query
by using the SAME logic nlg itself uses: it actually imports and RUNS the
real query-building code from nlg-src --

    fetch_data_with_insights_for_cl / _for_fl / _for_pr

-- (chosen the same way the real code chooses it, from
`insights_target_user_type` in `config/input_data_config/<target_type>.yml`)
against a stub database connector that intercepts every SQL statement
instead of hitting a real database, and captures exactly what the real
code built. This is not an LLM approximation -- it's the real function,
running with real resolved config (table/schema names from
`config/nlg_db_tables.ini`, column mappings, join columns, etc.), for real.

An LLM-based reconstruction is kept as a fallback ONLY for the case where
real execution can't run at all in your environment (e.g. a missing
third-party dependency auto-stubbing couldn't paper over). Every result
says which method actually produced it (`resolution_method`).
"""
from .tracer import trace_insight_type, trace_target_type, trace_many_target_types, QueryResult
from .query_capture import capture_queries_for_insight_type, CaptureResult
from .xlsx_report import export_xlsx

__all__ = ["trace_insight_type", "trace_target_type", "trace_many_target_types", "QueryResult",
           "capture_queries_for_insight_type", "CaptureResult", "export_xlsx"]
