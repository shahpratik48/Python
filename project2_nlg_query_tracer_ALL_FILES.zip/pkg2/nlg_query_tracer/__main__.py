"""
Command-line entry point for the query tracer.

    python -m nlg_query_tracer trace --target-type account_holding_mmf \\
        --local-dags ./nlg-dag/dags --local-src ./nlg-src/src --xlsx out.xlsx

    python -m nlg_query_tracer trace --target-type account_holding_mmf \\
        --insight-type si_mmf_to_core_savings_promo_rate --xlsx out.xlsx

    python -m nlg_query_tracer trace --target-type account_holding_mmf,account_sbl --xlsx out.xlsx
"""
from __future__ import annotations

import argparse

from nlg_dag_agent.config import Settings
from nlg_dag_agent.pipeline import build_hierarchy

from .tracer import trace_target_type, trace_insight_type
from .xlsx_report import export_xlsx


def main(argv=None):
    parser = argparse.ArgumentParser(prog="nlg_query_tracer")
    parser.add_argument("--provider", choices=["azure_openai", "azure_gateway", "none"], default=None)
    parser.add_argument("--non-interactive", action="store_true")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("trace", help="Reconstruct narrative-generation SQL queries for one or more target_types.")
    p.add_argument("--target-type", required=True, help="Comma-separated target_type(s), e.g. account_holding_mmf,account_sbl")
    p.add_argument("--insight-type", help="Restrict to a single insight_type (only valid with one target_type).")
    p.add_argument("--local-dags", help="Local path to the nlg dags folder (offline mode).")
    p.add_argument("--local-src", help="Local path to the nlg src folder (offline mode).")
    p.add_argument("--prospect-run", action="store_true", help="Trace the prospect-run code path instead of the standard one.")
    p.add_argument("--odm-env", default="prod_active",
                    help="Section of config/nlg_db_tables.ini to use for schema/table names (default: prod_active).")
    p.add_argument("--no-llm-fallback", action="store_true",
                    help="Disable the LLM fallback -- only report rows where real code execution succeeded.")
    p.add_argument("--xlsx", required=True, help="Output xlsx path.")

    args = parser.parse_args(argv)

    settings = Settings()
    if args.provider:
        settings.llm_provider = args.provider
    if args.local_dags:
        settings.local_dags_dir = args.local_dags
    if args.local_src:
        settings.local_src_dir = args.local_src
    settings.resolve_secrets(interactive=not args.non_interactive)

    print("Building hierarchy/source index (reused from nlg_dag_agent)...")
    hierarchy = build_hierarchy(settings)

    target_types = [t.strip() for t in args.target_type.split(",") if t.strip()]
    results = []
    if args.insight_type:
        if len(target_types) != 1:
            parser.error("--insight-type requires exactly one --target-type")
        results.append(trace_insight_type(hierarchy, target_types[0], args.insight_type,
                                            settings=settings, is_prospect_run=args.prospect_run,
                                            odm_env=args.odm_env, allow_llm_fallback=not args.no_llm_fallback))
    else:
        for tt in target_types:
            print(f"Tracing target_type={tt} ...")
            results.extend(trace_target_type(hierarchy, tt, settings=settings, is_prospect_run=args.prospect_run,
                                               odm_env=args.odm_env, allow_llm_fallback=not args.no_llm_fallback))

    out_path = export_xlsx(results, args.xlsx)
    n_exec = sum(1 for r in results if r.resolution_method == "code_execution")
    n_llm = sum(1 for r in results if r.resolution_method == "llm_fallback")
    n_none = sum(1 for r in results if r.resolution_method == "none")
    print(f"Wrote {len(results)} insight_type row(s) to {out_path} "
          f"(code_execution={n_exec}, llm_fallback={n_llm}, none={n_none})")


if __name__ == "__main__":
    main()
