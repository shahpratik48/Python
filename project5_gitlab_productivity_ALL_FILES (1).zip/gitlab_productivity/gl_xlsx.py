"""
XLSX export.

Deliberately mirrors the HTML report -- same sections in the same order,
same colours, same wording -- so the two are interchangeable rather than
two different views of the data that have to be reconciled. The palette
below is lifted directly from the CSS in gl_report.py; if one changes the
other should change with it.

Layout per pod: the headline summary and baseline shift first, then the
supporting summary tables, then the detailed issue and merge request
listings last -- reading top-down from "how are we doing" to "which
specific items".
"""
from __future__ import annotations

import datetime as _dt
import os
from typing import Dict, List, Optional

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from gl_settings import get_logger
from gl_summary import METRICS, shift_is_good

log = get_logger("gitlab.xlsx")

# ---- palette shared with the HTML stylesheet ----
C_HEADER = "305496"
C_HEADER_TXT = "FFFFFF"
C_ROW_ALT = "FAFBFC"
C_FLAG_BG = "FDECEC"
C_FLAG_TXT = "9B1C1C"
C_OK_BG = "E6F5EC"
C_OK_TXT = "0B6B36"
C_UNK_BG = "FFF6E0"
C_UNK_TXT = "9A6700"
C_BORDER = "E6E8EB"
C_TITLE = "1A1A1A"
C_SUB = "666666"
C_NOTE_BG = "F2F6FF"
C_NOTE_TXT = "33415C"

F_TITLE = Font(name="Calibri", size=16, bold=True, color=C_TITLE)
F_H2 = Font(name="Calibri", size=13, bold=True, color=C_HEADER)
F_H3 = Font(name="Calibri", size=11, bold=True, color=C_TITLE)
F_SUB = Font(name="Calibri", size=9, italic=True, color=C_SUB)
F_HEAD = Font(name="Calibri", size=10, bold=True, color=C_HEADER_TXT)
F_BODY = Font(name="Calibri", size=10)
F_BOLD = Font(name="Calibri", size=10, bold=True)
F_NOTE = Font(name="Calibri", size=9, color=C_NOTE_TXT)

FILL_HEAD = PatternFill("solid", start_color=C_HEADER, end_color=C_HEADER)
FILL_ALT = PatternFill("solid", start_color=C_ROW_ALT, end_color=C_ROW_ALT)
FILL_FLAG = PatternFill("solid", start_color=C_FLAG_BG, end_color=C_FLAG_BG)
FILL_OK = PatternFill("solid", start_color=C_OK_BG, end_color=C_OK_BG)
FILL_UNK = PatternFill("solid", start_color=C_UNK_BG, end_color=C_UNK_BG)
FILL_NOTE = PatternFill("solid", start_color=C_NOTE_BG, end_color=C_NOTE_BG)

_thin = Side(style="thin", color=C_BORDER)
BORDER = Border(left=_thin, right=_thin, top=_thin, bottom=_thin)
WRAP = Alignment(vertical="top", wrap_text=True)
CENTER = Alignment(vertical="center", horizontal="center", wrap_text=True)


class _Sheet:
    """Thin cursor over a worksheet: write a block, move down, repeat."""

    def __init__(self, ws, widths: Optional[List[int]] = None):
        self.ws = ws
        self.row = 1
        if widths:
            for i, w in enumerate(widths, start=1):
                ws.column_dimensions[get_column_letter(i)].width = w

    def blank(self, n: int = 1):
        self.row += n

    def title(self, text, font=F_TITLE):
        c = self.ws.cell(row=self.row, column=1, value=text)
        c.font = font
        self.row += 1

    def note(self, text, span: int = 8):
        c = self.ws.cell(row=self.row, column=1, value=text)
        c.font = F_NOTE
        c.fill = FILL_NOTE
        c.alignment = WRAP
        self.ws.merge_cells(start_row=self.row, start_column=1,
                            end_row=self.row, end_column=max(1, span))
        self.ws.row_dimensions[self.row].height = 28
        self.row += 1

    def table(self, headers: List[str], rows: List[list],
              row_fills: Optional[List[Optional[PatternFill]]] = None, autofilter: bool = True):
        first = self.row
        for i, h in enumerate(headers, start=1):
            c = self.ws.cell(row=self.row, column=i, value=h)
            c.font = F_HEAD
            c.fill = FILL_HEAD
            c.alignment = CENTER
            c.border = BORDER
        self.row += 1
        for r_i, r in enumerate(rows):
            fill = (row_fills[r_i] if row_fills and r_i < len(row_fills) else None)
            if fill is None and r_i % 2 == 1:
                fill = FILL_ALT
            for i, v in enumerate(r, start=1):
                c = self.ws.cell(row=self.row, column=i, value=v)
                c.font = F_BODY
                c.alignment = WRAP
                c.border = BORDER
                if fill:
                    c.fill = fill
            self.row += 1
        if autofilter and rows:
            self.ws.auto_filter.ref = "A%d:%s%d" % (
                first, get_column_letter(len(headers)), self.row - 1)
        self.ws.freeze_panes = self.ws.cell(row=first + 1, column=1)
        self.row += 1


def report_basename(pod, kind: str) -> str:
    """`<Pod Name>_<kind>` with the pod name made filename-safe.

    Every artefact for a pod therefore sorts together in a directory
    listing, and the kind ("last_3_months" or "daily") is obvious without
    opening the file.
    """
    import re as _re
    safe = _re.sub(r"[^A-Za-z0-9]+", "_", str(pod.name)).strip("_") or pod.key
    return "%s_%s" % (safe, kind)


def _num(v, nd=2):
    return round(float(v), nd) if v is not None else None


def _pct(v):
    return None if v is None else round(float(v), 1)


def _summary_sheet(wb, settings, report_months, rows, shifts, baseline):
    sh = _Sheet(wb.create_sheet("Summary"), [22, 18, 22, 22, 18, 16, 16])
    sh.title("Pod: %s" % settings.pod_name)
    sh.title("GitLab productivity summary", F_SUB)
    sh.blank()

    sh.title("Headline metrics per month", F_H2)
    headers = ["Month"] + [label for _a, label, _l in METRICS]
    body, fills = [], []
    for r in sorted(rows, key=lambda x: x.month, reverse=True):
        body.append([r.month + ("  (baseline)" if r.is_baseline else ""),
                     r.throughput, _num(r.cycle_time_days), _num(r.merged_per_author, 1),
                     _num(r.lead_time_hours)])
        fills.append(FILL_UNK if r.is_baseline else None)
    sh.table(headers, body, fills)

    sh.title("Shift against baseline %s" % (baseline.month if baseline else "(unavailable)"), F_H2)
    sh.note("Each month compared with the fixed baseline month rather than with the month before "
            "it -- a rolling comparison moves its own goalposts, so a weak month can look like an "
            "improvement simply because the previous one was worse. Cycle Time and Lead Time are "
            "lower-is-better, so a negative shift there is an improvement; green means better than "
            "baseline, red means worse.", span=len(headers))
    if shifts:
        body, fills = [], []
        for s in sorted(shifts, key=lambda x: x.month, reverse=True):
            body.append([s.month] + [_pct(s.shifts.get(a)) for a, _l, _x in METRICS])
            fills.append(None)
        sh.table(headers, body, fills)
        # colour each shift cell by whether it is an improvement
        start = sh.row - len(body) - 1
        for r_i, s in enumerate(sorted(shifts, key=lambda x: x.month, reverse=True)):
            for c_i, (attr, _l, _x) in enumerate(METRICS, start=2):
                good = shift_is_good(attr, s.shifts.get(attr))
                if good is None:
                    continue
                cell = sh.ws.cell(row=start + r_i, column=c_i)
                cell.fill = FILL_OK if good else FILL_FLAG
                cell.font = Font(name="Calibri", size=10, bold=True,
                                 color=C_OK_TXT if good else C_FLAG_TXT)
                cell.number_format = "+0.0%;-0.0%"
                if cell.value is not None:
                    cell.value = cell.value / 100.0
    else:
        sh.note("No baseline data available for %s, so no shift could be computed."
                % settings.baseline_month, span=len(headers))
    return sh


def _issue_sheet(wb, settings, months_desc, issue_summaries, issue_metrics):
    sh = _Sheet(wb.create_sheet("Issues"), [12, 12, 18, 18, 20, 14, 14, 40])
    sh.title("Pod: %s -- issues" % settings.pod_name)
    sh.blank()

    sh.title("Per month", F_H2)
    body = []
    for m in months_desc:
        s = issue_summaries.get(m)
        if not s:
            continue
        body.append([m, s.closed_count, s.from_in_progress, s.from_opened,
                     _num(s.avg_business_days), s.flagged_count, s.unmeasurable])
    sh.table(["Month", "Closed", "From in progress", "From opened", "Avg business days",
              "Flagged", "Not measurable"], body)

    sh.title("Issues over SLA", F_H3)
    sh.note("Only issues that breached the %g-business-day SLA are listed; those that met it are "
            "counted above but not itemised, so this stays a problem list rather than a full "
            "changelog. Newest closed first."
            % settings.issue_sla_business_days, span=8)
    body, fills = [], []
    for m in months_desc:
        for i in sorted([x for x in issue_metrics if x.month == m and x.flagged],
                        key=lambda x: (x.closed_at or _dt.datetime.min.replace(
                            tzinfo=_dt.timezone.utc)), reverse=True):
            body.append([i.iid, m, i.title, i.author_name, i.basis,
                         i.in_progress_at.strftime("%Y-%m-%d %H:%M") if i.in_progress_at else None,
                         i.closed_at.strftime("%Y-%m-%d %H:%M") if i.closed_at else None,
                         _num(i.elapsed_business_days)])
            fills.append(FILL_FLAG)
    if body:
        sh.table(["Issue", "Month", "Title", "Author", "Measured from", "Start", "Closed",
                  "Business days"], body, fills)
    else:
        sh.note("No issue breached the SLA in this window.", span=8)
    return sh


def _mr_sheet(wb, settings, months_desc, mr_summaries, mr_metrics, repos):
    from gl_metrics import MR_STATES
    sh = _Sheet(wb.create_sheet("Merge Requests"),
                [14, 10, 12, 40, 20, 12, 18, 18, 12])
    sh.title("Pod: %s -- merge requests" % settings.pod_name)
    sh.blank()

    sh.title("By state", F_H2)
    sh.note("closed means closed WITHOUT merging. Counts elsewhere consider merged only -- an "
            "abandoned MR is not delivered work.", span=len(MR_STATES) + 2)
    body = [[m] + [mr_summaries[m].state_counts.get(st, 0) for st in MR_STATES]
            + [sum(mr_summaries[m].state_counts.values())]
            for m in months_desc if m in mr_summaries]
    sh.table(["Month"] + list(MR_STATES) + ["Total"], body)

    sh.title("Merged per repository", F_H2)
    body = [[m] + [mr_summaries[m].per_repo.get(r, 0) for r in repos]
            + [mr_summaries[m].merged_count] for m in months_desc if m in mr_summaries]
    sh.table(["Month"] + list(repos) + ["Total merged"], body)

    sh.title("Merged -- elapsed time", F_H2)
    body = [[m, mr_summaries[m].merged_count, len(mr_summaries[m].per_author),
             mr_summaries[m].measured_count, _num(mr_summaries[m].avg_hours),
             mr_summaries[m].flagged_count, mr_summaries[m].unknown_count]
            for m in months_desc if m in mr_summaries]
    sh.table(["Month", "Merged", "Authors", "Measured", "Avg hours", "Flagged", "Unknown"], body)

    sh.title("Merged per author", F_H2)
    authors = sorted({a for s in mr_summaries.values() for a in s.per_author})
    body = [[a] + [mr_summaries[m].per_author.get(a, 0) for m in months_desc]
            + [sum(mr_summaries[m].per_author.get(a, 0) for m in months_desc)] for a in authors]
    if body:
        sh.table(["Author"] + list(months_desc) + ["Total"], body)
    else:
        sh.note("No merged merge requests in this window.", span=4)

    sh.title("Merge requests over SLA", F_H3)
    sh.note("Only merged MRs that breached the %g-hour SLA are listed. Newest merged first."
            % settings.mr_sla_hours, span=9)
    body, fills = [], []
    for m in months_desc:
        for x in sorted([v for v in mr_metrics if v.month == m and v.flagged],
                        key=lambda v: (v.merged_at or v.closed_at
                                       or _dt.datetime.min.replace(tzinfo=_dt.timezone.utc)),
                        reverse=True):
            body.append([x.repo, x.iid, m, x.title, x.author_name, x.state,
                         x.first_touch_at.strftime("%Y-%m-%d %H:%M") if x.first_touch_at else None,
                         (x.merged_at or x.closed_at).strftime("%Y-%m-%d %H:%M")
                         if (x.merged_at or x.closed_at) else None,
                         _num(x.elapsed_hours)])
            fills.append(FILL_FLAG)
    if body:
        sh.table(["Repo", "MR", "Month", "Title", "Author", "State", "First file touched",
                  "Merged", "Hours"], body, fills)
    else:
        sh.note("No merge request breached the SLA in this window.", span=9)
    return sh


def export_metrics_xlsx(settings, report_months, summary_rows, shift_rows, baseline,
                        issue_summaries, issue_metrics, mr_summaries, mr_metrics,
                        output_dir: str, prefix: str = "gitlab_metrics_report") -> str:
    """Writes the same content as the HTML report, in the same order and
    colours, to a workbook."""
    wb = Workbook()
    wb.remove(wb.active)
    months_desc = list(reversed(list(report_months)))

    _summary_sheet(wb, settings, report_months, summary_rows, shift_rows, baseline)
    _issue_sheet(wb, settings, months_desc, issue_summaries, issue_metrics)
    _mr_sheet(wb, settings, months_desc, mr_summaries, mr_metrics, list(settings.code_repos))

    os.makedirs(output_dir, exist_ok=True)
    path = os.path.join(output_dir, "%s_%s.xlsx" % (
        report_basename(settings.pod, "last_3_months"),
        _dt.datetime.now().strftime("%Y%m%d_%H%M%S")))
    wb.save(path)
    log.info("XLSX written: %s", path)
    return path


def export_daily_xlsx(settings, day, month, issues_closed_today, mrs_merged_today,
                      at_risk_issues, at_risk_mrs, issue_summary, mr_summary,
                      repos, output_dir: str) -> str:
    """The daily report as a workbook -- same sections, order and colours as
    its HTML counterpart."""
    from gl_daily import STATUS_BREACHED
    from gl_metrics import MR_STATES

    wb = Workbook()
    wb.remove(wb.active)

    # ---- sheet 1: needs action ----
    sh = _Sheet(wb.create_sheet("Needs Action"), [10, 40, 20, 20, 18, 18, 14, 14, 18])
    sh.title("Pod: %s -- daily report %s" % (settings.pod_name, day.strftime("%Y-%m-%d")))
    sh.title("What breached today, and what will breach today unless it is finished", F_SUB)
    sh.blank()

    i_over = sum(1 for x in at_risk_issues if x.status == STATUS_BREACHED)
    m_over = sum(1 for x in at_risk_mrs if x.status == STATUS_BREACHED)
    sh.title("Issues still open -- %d already overdue, %d at risk today"
             % (i_over, len(at_risk_issues) - i_over), F_H2)
    sh.note("Covers both groups. Restricted to issues with an iteration assigned that are in "
            "progress -- committed work that has actually started. Overdue first.", span=9)
    body, fills = [], []
    for i in sorted(at_risk_issues, key=lambda v: (v.status != STATUS_BREACHED,
                                                   -v.elapsed_end_of_day)):
        body.append([i.iid, i.title, i.author_name, i.assignee_name, i.iteration_title,
                     i.in_progress_at.strftime("%Y-%m-%d %H:%M") if i.in_progress_at else None,
                     _num(i.elapsed_now), _num(i.elapsed_end_of_day), i.status])
        fills.append(FILL_FLAG if i.status == STATUS_BREACHED else FILL_UNK)
    if body:
        sh.table(["Issue", "Title", "Author", "Assignee", "Iteration", "In progress since",
                  "Business days now", "By end of today", "Status"], body, fills)
    else:
        sh.note("No in-progress issue with an iteration assigned is over the SLA or will cross it "
                "today.", span=9)

    sh.title("Merge requests still unmerged -- %d already overdue, %d at risk today"
             % (m_over, len(at_risk_mrs) - m_over), F_H2)
    body, fills = [], []
    for m in sorted(at_risk_mrs, key=lambda v: (v.status != STATUS_BREACHED,
                                                -v.elapsed_end_of_day)):
        body.append([m.repo, m.iid, m.title, m.author_name,
                     m.first_touch_at.strftime("%Y-%m-%d %H:%M") if m.first_touch_at else None,
                     _num(m.elapsed_now), _num(m.elapsed_end_of_day), m.status])
        fills.append(FILL_FLAG if m.status == STATUS_BREACHED else FILL_UNK)
    if body:
        sh.table(["Repo", "MR", "Title", "Author", "First file touched", "Hours now",
                  "By end of today", "Status"], body, fills)
    else:
        sh.note("No unmerged merge request is over the SLA or will cross it today.", span=8)

    # ---- sheet 2: breached today ----
    sh2 = _Sheet(wb.create_sheet("Breached Today"), [10, 40, 20, 18, 18, 18, 14])
    sh2.title("Breached today -- %s" % day.strftime("%Y-%m-%d"), F_H2)
    sh2.note("Only items that finished today AND exceeded their SLA. Work completed today within "
             "SLA is counted in the month-to-date sheet but not listed here.", span=7)
    body = [[i.iid, i.title, i.author_name, i.basis,
             i.in_progress_at.strftime("%Y-%m-%d %H:%M") if i.in_progress_at else None,
             i.closed_at.strftime("%Y-%m-%d %H:%M") if i.closed_at else None,
             _num(i.elapsed_business_days)] for i in issues_closed_today]
    sh2.title("Issues closed today over SLA", F_H3)
    if body:
        sh2.table(["Issue", "Title", "Author", "Measured from", "Start", "Closed",
                   "Business days"], body, [FILL_FLAG] * len(body))
    else:
        sh2.note("No issue closed today breached the SLA.", span=7)

    body = [[m.repo, m.iid, m.title, m.author_name,
             m.first_touch_at.strftime("%Y-%m-%d %H:%M") if m.first_touch_at else None,
             m.merged_at.strftime("%Y-%m-%d %H:%M") if m.merged_at else None,
             _num(m.elapsed_hours)] for m in mrs_merged_today]
    sh2.title("Merge requests merged today over SLA", F_H3)
    if body:
        sh2.table(["Repo", "MR", "Title", "Author", "First file touched", "Merged", "Hours"],
                  body, [FILL_FLAG] * len(body))
    else:
        sh2.note("No merge request merged today breached the SLA.", span=7)

    # ---- sheet 3: month to date ----
    sh3 = _Sheet(wb.create_sheet("Month To Date"), [14, 14, 18, 16, 18, 12, 14])
    sh3.title("Month to date -- %s" % month, F_H2)
    sh3.note("Current month only, not the rolling window used in the monthly report.", span=7)
    sh3.title("Issues", F_H3)
    sh3.table(["Month", "Closed", "From in progress", "From opened", "Avg business days",
               "Flagged", "Not measurable"],
              [[month, issue_summary.closed_count, issue_summary.from_in_progress,
                issue_summary.from_opened, _num(issue_summary.avg_business_days),
                issue_summary.flagged_count, issue_summary.unmeasurable]])
    sh3.title("Merge requests by state", F_H3)
    sh3.table(["Month"] + list(MR_STATES) + ["Total"],
              [[month] + [mr_summary.state_counts.get(st, 0) for st in MR_STATES]
               + [sum(mr_summary.state_counts.values())]])
    sh3.title("Merged per repository", F_H3)
    sh3.table(["Month"] + list(repos) + ["Total merged"],
              [[month] + [mr_summary.per_repo.get(r, 0) for r in repos]
               + [mr_summary.merged_count]])
    sh3.title("Merged per author", F_H3)
    rows = [[a, n] for a, n in sorted(mr_summary.per_author.items(), key=lambda kv: -kv[1])]
    if rows:
        sh3.table(["Author", "Merged this month"], rows)
    else:
        sh3.note("No merge requests merged this month yet.", span=2)

    os.makedirs(output_dir, exist_ok=True)
    path = os.path.join(output_dir, "%s_%s.xlsx" % (
        report_basename(settings.pod, "daily"), _dt.datetime.now().strftime("%Y%m%d_%H%M%S")))
    wb.save(path)
    log.info("Daily XLSX written: %s", path)
    return path
