"""
The per-pod summary table that heads the report, and the shift against a
fixed baseline month.

Four headline metrics per pod per month, matching the agreed layout:

    Issue Throughput          closed issues
    Issue Cycle Time (Days)   average elapsed days, in progress -> closed
    Merged MRs per Author     merged MRs divided by distinct authors
    Lead Time (Hrs.)          average elapsed hours, first file touched -> merged

"Merged MRs per Author" is a RATIO, not a count -- 33 merged MRs across 2
authors reads as 16.5. That is the point of it: raw MR counts rise simply
because more people are working, whereas the ratio shows how much each
author is actually landing.

Every month is compared against one fixed baseline month (November 2025 by
default) rather than against the month before it. A rolling comparison
moves its own goalposts -- if last month was poor, a weak month looks like
an improvement. A fixed baseline answers the question that actually
matters: are we better or worse than the reference point.

Cycle Time and Lead Time are "lower is better", so an increase is a
regression. That inversion is carried on each metric rather than left to
the reader.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Tuple

from gl_metrics import month_key
from gl_settings import get_logger

log = get_logger("gitlab.summary")

# (attribute, display label, lower_is_better)
METRICS = [
    ("throughput", "Issue Throughput", False),
    ("cycle_time_days", "Issue Cycle Time (Days)", True),
    ("merged_per_author", "Merged MRs per Author", False),
    ("lead_time_hours", "Lead Time (Hrs.)", True),
]


@dataclass
class PodSummaryRow:
    month: str
    throughput: int = 0
    cycle_time_days: Optional[float] = None
    merged_per_author: Optional[float] = None
    lead_time_hours: Optional[float] = None
    is_baseline: bool = False

    def value(self, attr: str):
        return getattr(self, attr)


@dataclass
class ShiftRow:
    """Percentage shift of one month against the baseline, per metric."""
    month: str
    shifts: Dict[str, Optional[float]] = field(default_factory=dict)


def months_with_baseline(months_back: int, baseline_month: str,
                         now: Optional[datetime] = None) -> Tuple[List[str], List[str], datetime]:
    """(report months newest-last, every month to fetch including the
    baseline, earliest fetch timestamp).

    The baseline usually sits well before the rolling window, so the fetch
    has to reach back far enough to cover it -- otherwise the baseline row
    would silently come back empty.
    """
    now = now or datetime.now(timezone.utc)
    report, cursor = [], now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    for _ in range(months_back + 1):
        report.append(month_key(cursor))
        cursor = (cursor - timedelta(days=1)).replace(day=1)
    report.reverse()

    all_months = sorted(set(report) | {baseline_month})
    earliest_key = min(all_months)
    earliest = datetime.strptime(earliest_key + "-01", "%Y-%m-%d").replace(tzinfo=timezone.utc)
    log.info("Report months: %s | baseline: %s | fetching from %s",
             ", ".join(report), baseline_month, earliest.date())
    return report, all_months, earliest


def build_pod_summary(months: List[str], issue_summaries: Dict, mr_summaries: Dict,
                      baseline_month: Optional[str] = None) -> List[PodSummaryRow]:
    rows = []
    for m in months:
        isum = issue_summaries.get(m)
        msum = mr_summaries.get(m)
        merged = msum.merged_count if msum else 0
        authors = len(msum.per_author) if msum else 0
        rows.append(PodSummaryRow(
            month=m,
            throughput=isum.closed_count if isum else 0,
            cycle_time_days=isum.avg_business_days if isum else None,
            merged_per_author=(round(merged / authors, 1) if authors else None),
            lead_time_hours=msum.avg_hours if msum else None,
            is_baseline=(m == baseline_month)))
    return rows


def pct_shift(value: Optional[float], baseline: Optional[float]) -> Optional[float]:
    """Percentage change from baseline. None when either side is missing or
    the baseline is zero -- a shift from nothing is not a percentage, and
    reporting one would be misleading."""
    if value is None or baseline is None:
        return None
    try:
        if float(baseline) == 0:
            return None
        return round((float(value) - float(baseline)) / abs(float(baseline)) * 100.0, 1)
    except (TypeError, ValueError):
        return None


def build_shift_rows(rows: List[PodSummaryRow], baseline_month: str) -> Tuple[List[ShiftRow],
                                                                              Optional[PodSummaryRow]]:
    """Shift of every non-baseline month against the baseline row."""
    baseline = next((r for r in rows if r.month == baseline_month), None)
    if baseline is None:
        log.warning("Baseline month %s produced no data -- shift columns will be blank. "
                    "Check that the fetch window reaches back that far and that the pod had "
                    "activity then.", baseline_month)
        return [], None

    out = []
    for r in rows:
        if r.month == baseline_month:
            continue
        out.append(ShiftRow(month=r.month,
                            shifts={attr: pct_shift(r.value(attr), baseline.value(attr))
                                    for attr, _label, _lower in METRICS}))
    log.info("Computed shift against baseline %s for %d month(s).", baseline_month, len(out))
    return out, baseline


def shift_is_good(attr: str, shift: Optional[float]) -> Optional[bool]:
    """True when a shift is an improvement, False when a regression, None
    when flat or unknown. Cycle Time and Lead Time invert: lower is better."""
    if shift is None or shift == 0:
        return None
    lower_is_better = dict((a, low) for a, _l, low in METRICS).get(attr, False)
    improved = (shift < 0) if lower_is_better else (shift > 0)
    return improved
