# GitLab Productivity Reporting & BAU Ticket Automation

Three independent DAGs, each with a matching notebook for local testing. Everything lives in one flat
folder — modules, DAGs, notebooks, and the generated HTML reports and log files.

The same code runs in both places; only where the token comes from differs:

| | Token source |
|---|---|
| **Notebook** | prompts you (hidden input), or picks up `GITLAB_TOKEN` from the environment |
| **Airflow** | the `GENESIS_DDLC_IKG_GIT_SECRET` Variable, same as the other projects |

## The three DAGs

| DAG | File | Notebook | Schedule |
|---|---|---|---|
| 1 — Metrics + daily | `airflow_dag_gitlab_metrics.py` | `run_metrics.ipynb` | 18:00 America/New_York, Mon–Fri |
| 2 — Create BAU tickets | `airflow_dag_gitlab_create_tickets.py` | `run_create_tickets.ipynb` | manual (typically Wednesday) |
| 3 — Close BAU tickets | `airflow_dag_gitlab_close_tickets.py` | `run_close_tickets.ipynb` | manual (typically Thursday) |

### DAG 1 — Metrics

Four tasks, run in order:
`collect_issue_metrics → collect_mr_metrics → build_html_report → build_daily_report`.
Tasks 1 and 2 hand their results to the reporting tasks through XCom, so a failure in Task 2 still
leaves Task 1's results visible rather than losing the run.

It produces **two** HTML reports: the four-month rolling report, and a single-day report described
below.

Window: **current month plus the previous three**.

**Task 1 — issues** (`PROJECT_PATH`): issues closed per month, elapsed time to closure for each, and
the monthly average, in **business days** (weekends excluded). Over **5 business days** is flagged.

Elapsed time runs from the *In progress* transition where one exists. Where it doesn't, it falls back
to **opened → closed** rather than reporting nothing, so every closed issue contributes a figure. The
report shows which basis each issue used and counts both per month — an opened-based figure usually
reads higher, so it's worth seeing how much of the average rests on the fallback.

**Task 2 — merge requests** (IKG + NLG + ODM):

* **All four states are reported** — `opened`, `merged`, `closed` (meaning closed *without* merging),
  and `locked` — per month, so abandonment is visible rather than hidden.
* **Counts consider `merged` only**, per author and per repository, with **IKG / NLG / ODM broken out
  separately plus a total**. An abandoned MR isn't delivered work.
* **Elapsed hours** run from the earliest commit on the MR (when a file in it was first touched) until
  it was **merged**, flagged over **72 hours**. Only merged MRs have an elapsed time; opened,
  closed-unmerged and locked ones have none by definition.
* The full MR listing is **split into a separate table per month**.

**Report presentation.** Months run **newest first** everywhere. Both the issue listing and the merge
request listing are **split into one table per month**. The issue table shows the **author**. Every
table in every report is **sortable** (click a column header) and **filterable** (type in the box above
it), implemented in inline vanilla JavaScript with no library or CDN, so it keeps working from a local
file or an email attachment on a machine with no internet access. Sorting reads the visible cell text,
so a value shown next to a status badge still sorts on its number, while months, dates and timestamps
sort chronologically rather than being mis-read as plain numbers.

Month bucketing follows the state: merged MRs bucket by `merged_at`, closed-unmerged by `closed_at`,
and open or locked ones by `created_at`, so an open MR appears in the month it was raised.

**Names, not usernames.** Every person in the report is shown by GitLab display name
(`author.name`), falling back to username only if no name is set.

### Configuring pods

Pods are defined in **`pods.json`**, beside the scripts. Nothing in the Python needs editing to add,
remove or change a pod — the code reads the file and builds one full set of reports per pod entry.

**Each pod produces exactly four files:**

```
<Pod Name>_last_3_months_<timestamp>.html     current month + previous 3, vs baseline
<Pod Name>_last_3_months_<timestamp>.xlsx
<Pod Name>_daily_<timestamp>.html             single-day + at-risk
<Pod Name>_daily_<timestamp>.xlsx
```

#### Steps to add a pod

1. Open `pods.json` (or copy it somewhere and point `GL_PODS_FILE` at it).
2. Add an entry to the `pods` list:

```json
{
  "name": "Data Platform",
  "issue_projects": [
    "ubs/gwma/.../data-platform-board",
    "ubs/gwma/.../data-platform-intake"
  ],
  "mr_repos": {
    "ingest": "ubs/gwma/.../dp-ingest",
    "api":    "ubs/gwma/.../dp-api"
  }
}
```

3. Save. The next DAG run (or notebook run) picks it up — no code change, no redeploy of the modules.

#### Field reference

| Field | Required | Notes |
|---|---|---|
| `name` | yes | Display name. Also the **start of every report file name** — `Data Platform` → `Data_Platform_daily_*.html`. |
| `issue_projects` | yes | **One or more** GitLab projects whose issues belong to the pod. Issues are pooled across all of them. Accepts a single string or a list. |
| `mr_repos` | yes | **One or more** repositories whose merge requests belong to the pod. Summed across all of them, and also broken out per repository in the report. |
| `key` | no | Filename-safe id. Auto-derived from `name` if omitted (`Data Platform` → `data_platform`). Must be unique. |
| `group_path` | no | Group holding iterations/epics. Defaults to the first issue project's parent group. |

#### Accepted shapes

`mr_repos` can be a labelled map, or a bare list where the label is taken from the last path segment:

```json
"mr_repos": {"ingest": "ubs/.../dp-ingest"}      →  column header "ingest"
"mr_repos": ["ubs/.../dp-ingest"]                →  column header "dp-ingest"
```

Full URLs are accepted anywhere a path is, and are normalised automatically — so you can paste
straight from the browser address bar:

```json
"issue_projects": ["https://devcloud.ubs.net/ubs/dp/board-alpha"]   →  ubs/dp/board-alpha
```

#### Validation

A malformed file **raises rather than silently falling back** to the defaults — quietly reporting on
the wrong pods would be worse than stopping. Errors name the offending pod:

```
Pod 'NoRepos' needs at least one merge request repository ('mr_repos').
Duplicate pod key(s) ['insights'] in pods.json -- keys become file names, so they must be unique.
```

If `pods.json` is absent entirely, the two built-in pods below are used.

### Two pods

Every metric is reported **per pod per month**, and each pod gets its **own separate report**.

| Pod | Issue board | Code repositories (merge requests) |
|---|---|---|
| **Insights** | `staat-ds-insights-home` | IKG, NLG, ODM (3) |
| **Conv. Insights** | `genesis-platform/data-elements` | conv-insights, data-elements, data-elements-common, de-api, transcript-accumulator, nlg-chat, portfolioq (7) |

**Every configured pod is processed on every run.** The DAG loops over all of them, and each pod is
handled independently — if one fails (permissions, a renamed project), the others still produce their
reports and the task reports which pods failed at the end rather than aborting partway through and
silently leaving later pods unprocessed.

In the **notebook**, the walkthrough cells inspect a single pod (`POD = ALL_PODS[0]`) and **write
nothing** — they render the report inline in a sandboxed iframe for preview only. The final section,
*Generate all reports for all pods*, is the **only** thing that writes files, and it loops over every
pod exactly as the DAG does. That split is deliberate: it guarantees each pod ends up with exactly one
set of four files, with no duplicate set for whichever pod the walkthrough happened to use.

These two ship as the built-in defaults and are also spelled out in `pods.json`. The Airflow DAG
produces a full set of reports for **every** configured pod on each run. In the notebook, set `POD` in
the config cell to whichever pod you want to inspect — `ALL_PODS` holds them all in file order.

### Report layout

Top-down from "how are we doing" to "which specific items":

1. **Summary** — the headline table, per month:

   | Metric | Meaning |
   |---|---|
   | Issue Throughput | closed issues |
   | Issue Cycle Time (Days) | average elapsed days, in progress → closed |
   | Merged MRs per Author | merged MRs ÷ distinct authors |
   | Lead Time (Hrs.) | average elapsed hours, first file touched → merged |

   *Merged MRs per Author* is a **ratio, not a count** — 33 merged MRs across 2 authors reads as
   **16.5**. Raw MR counts rise simply because more people are working; the ratio shows how much each
   author is actually landing.

2. **Shift against baseline** — every month compared with a **fixed baseline month** (November 2025 by
   default, `GL_BASELINE_MONTH`), not with the month before it. A rolling comparison moves its own
   goalposts: if last month was poor, a weak month looks like an improvement. *Cycle Time* and *Lead
   Time* are lower-is-better, so a negative shift there is an **improvement** — the colouring carries
   that inversion rather than leaving it to the reader.

3. Supporting summary tables for issues and merge requests.
4. **Detailed issue and MR listings at the bottom**, SLA breaches only.

The fetch window automatically reaches back to cover the baseline month, so the baseline row is
populated even though it sits well outside the rolling window.

### HTML and XLSX

Both formats carry the same content in the same order with the same palette — the XLSX colours are
lifted directly from the HTML stylesheet, so the two are interchangeable rather than two views that
have to be reconciled. The workbook has three sheets (**Summary**, **Issues**, **Merge Requests**),
each with frozen headers and autofilter.

### The daily report

Written by Task 4 alongside the monthly one, as `gitlab_daily_report_*.html`.

| Section | Scope |
|---|---|
| Issues closed today | **only** those closed on the report day that **breached** the SLA |
| MRs merged today | **only** those merged on the report day that **breached** the SLA |
| Month-to-date tables | the **current month only** — running on 28 Jul 2026 shows `2026-07` |
| **Open issues at risk** | still open, **iteration assigned**, **in progress** — both **already overdue** and **crossing the SLA today** |
| **Open MRs at risk** | still **unmerged** — both **already overdue** and **crossing the SLA today** |

The at-risk **issue** list applies two extra filters, because an action list should only contain work
someone can actually act on: the issue must have an **iteration assigned** (committed work, not
backlog) and must be **in progress** (started, so its clock is running). Elapsed time there runs
strictly from the in-progress transition — unlike the closed-issue metrics, there is deliberately no
fallback to the opened date, since an issue nobody has started is not running late.

The two at-risk sections are the point of it. A breach already recorded is history; an item about to
breach can still be saved — which is why the DAG runs at 6pm, while there is still a working day left
to act. Both at-risk sections cover **two groups**, with the split shown in the section heading and in
separate headline cards: **already overdue** (past the SLA and still unfinished) and **at risk today**
(inside the SLA now, crossing it before 23:59 on the report day). Overdue items are listed first. The
distinction matters — an item already past its SLA is a different conversation from one that can still
be finished cleanly today, and a single combined count would hide that.

The at-risk view is the only reporting step that calls GitLab directly: currently-open work is never
fetched by the monthly collectors, since those look only at what has already closed.

### Detail listings show SLA breaches only

In both reports, the per-month issue and MR listings contain **only items that breached the SLA**.
Items that met it are still counted in every summary table above them, and a line under each table
says how many were omitted — so nothing disappears silently, but the detail stays a problem list
rather than a full changelog.

Default ordering: issues by **closed date descending**, merge requests by **merged/closed date
descending** — newest first, matching the newest-month-first section order.

### DAG 2 — Create BAU tickets

Creates 11 standing tickets in the **current iteration**, each with `weight=1`,
`label=@productivity`, `parent="BAU Technical 2026"`, and a description identical to its title:

```
QA Testing for new insights          Dashboard enhencements for release
UAT Testing for new insights         Dashboard enhencements for metadata
Pipeline monitoring for Dev          Code review for IKG
Pipeline monitoring for preprod      Code review for ODM
Pipeline monitoring for production   Code review for NLG
Pipeline monitoring for Dummy
```

**Idempotent** — a ticket whose title is already open in the current iteration is skipped rather than
duplicated, so an accidental re-trigger doesn't produce eleven more.

### DAG 3 — Close BAU tickets

Closes every open ticket in the current iteration with label `@productivity` under parent
`"BAU Technical 2026"`.

Scope is deliberately narrow: the API can filter on label and iteration but not on parent epic, so the
matches are filtered down in code to those whose parent really is that epic — and the run **refuses to
proceed at all** if the epic can't be resolved, rather than closing on label and iteration alone and
risking another team's work.

## Dry run

Both write DAGs support a dry run that resolves everything and logs exactly what *would* happen
without writing:

```json
{"dry_run": "true"}
```
via `dag_run.conf`, or the `GL_DRY_RUN=true` Airflow Variable, or `settings.dry_run = True` in the
notebook. **Worth doing on the first run of DAG 2 and DAG 3.**

## Files

| File | Purpose |
|---|---|
| `pods.json` | **Pod configuration** — add or edit pods here; no code change needed. |
| `gl_settings.py` | Configuration, pod loading/validation, token resolution, logging setup. |
| `gl_summary.py` | Headline summary metrics and the baseline shift. |
| `gl_xlsx.py` | XLSX export for both the monthly and daily reports, styled to match the HTML. |
| `gl_client.py` | GitLab REST client — issues, label events, MRs, MR commits, iterations, epics, create/close. |
| `gl_metrics.py` | Business-day and elapsed-hour maths, month bucketing, and both metric collectors. |
| `gl_tickets.py` | Ticket creation and closing, with the guards described above. |
| `gl_daily.py` | Single-day scoping and the at-risk detection for open issues and merge requests. |
| `gl_report.py` | Self-contained HTML reports (inline CSS + JS — they render and stay interactive straight from disk or as an attachment). |

## Logging

Logging is heavy by design, since these run unattended. Every run writes to **both** stdout (so it
appears in Airflow task logs and notebook output) and a timestamped `gitlab_report_*.log` file beside
the scripts. Every GitLab call, resolution step, per-issue decision, and write action is logged, and
the log file name is recorded in the HTML report so a report can always be traced back to its run.

Adjust with `GL_LOG_LEVEL` (default `INFO`; use `DEBUG` to see every HTTP request).

## Configuration

Paths default to the values below and can be overridden by environment variable or Airflow Variable:

```
GITLAB_URL        https://devcloud.ubs.net
GROUP_PATH        .../staat-ds-insights-cl/commons
PROJECT_PATH      .../staat-ds-insights-cl/commons/staat-ds-insights-home
IKG_PROJECT_PATH  .../genesis-platform/ikg-dags
NLG_PROJECT_PATH  .../genesis-platform/nlg-dags
ODM_PROJECT_PATH  .../genesis-platform/odm-dags
```

Tunable: `GL_MONTHS_BACK` (3), `GL_ISSUE_SLA_DAYS` (5), `GL_MR_SLA_HOURS` (72),
`GL_IN_PROGRESS_LABELS`, `GL_TICKET_LABEL`, `GL_TICKET_PARENT`, `GL_TICKET_WEIGHT`,
`GL_LOG_LEVEL`, `GL_DRY_RUN`, `GL_OUTPUT_DIR`.

## Things worth knowing

**"In progress" detection.** GitLab has no built-in concept of an in-progress *state*, so this reads
resource **label** events and matches any of `in progress`, `in-progress`, `doing`, `wip`
(case-insensitive, and scoped forms like `workflow::In progress` work too). Adjust with
`GL_IN_PROGRESS_LABELS` to match your board. An issue with no such transition **cannot** have a cycle
time computed — it is reported as *unknown* and counted separately, never treated as zero, which would
quietly drag the average down.

**"Any file touched in MR"** is taken as the earliest commit on the MR. An MR with no readable commit
history is likewise reported as *unknown* rather than skipped.

**Business days** exclude Saturday and Sunday. They do **not** account for public holidays or
working-hour boundaries, so a ticket opened at 4pm Friday and closed 10am Monday counts as ~0.75
business days.

**Iterations and epics are GitLab Premium features.** If the token lacks access, DAG 1 is unaffected,
but DAGs 2 and 3 will stop with a clear message rather than doing something half-correct.

## Python version

Targets **Python 3.8**, matching the Airflow environment (`live-3.8-env`).

One consequence worth knowing if you edit `gl_report.py`: before Python 3.12, an f-string
*expression* cannot contain a backslash, so `f"...{'<span class=\"x\">' }..."` is a `SyntaxError`
on 3.8 even though it is fine on 3.12. Any HTML needing quotes inside it is therefore built with
`%`-formatting in the small helpers `_count_badge()`, `_link()` and `_action_badge()` rather than
inline in an f-string. Keep new markup out of f-string expressions for the same reason.

Every `.py` file and every notebook code cell is verified against the Python 3.8 grammar
(`ast.parse(..., feature_version=(3, 8))`), not just whatever version happens to be local.

## Validation performed

Tested with a mocked GitLab API:

- **Business-day maths** — Mon 9am→Tue 9am = 1.00; Fri 3pm→Mon 9am = 0.75 (not 2.75); Mon→Mon = 5.00;
  Sat→Sun = 0.00.
- **Month bucketing** — current month plus the previous three; issues closed outside the window are
  excluded.
- **In-progress detection** — picks the earliest matching *add* event, ignores *remove* events and
  non-matching labels, and handles scoped labels.
- **Flagging** — a 10.12-business-day issue and a 126-hour merged MR were both correctly flagged.
- **Issue fallback** — an issue with an in-progress transition measured from it; one without measured
  from opened; both counted separately in the monthly summary.
- **MR states** — a month containing one opened, two merged, one closed-unmerged and one locked MR
  produced `{opened:1, merged:2, closed:1, locked:1}`, with counts of **2** (merged only), per-repo
  `{IKG:1, NLG:1, ODM:0}`, and elapsed hours present *only* on the merged ones.
- **Names** — display names appear throughout the report and usernames do not.
- **Report ordering** — issue and MR detail sections both render newest month first.
- **Flagged-only detail** — a within-SLA issue and a fast MR closed the same month were both excluded
  from the detail listings while still counted in the summaries.
- **Default ordering** — issues rendered newest-closed first, MRs newest-merged first.
- **Daily report** — with data seeded for 28 Jul 2026: only the late issue closed that day and the
  late MR merged that day appeared; the on-time ones closed/merged the same day were excluded; a stale
  open MR was surfaced as *already breached*; and the month-to-date tables contained `2026-07` only, with no trace
  of the earlier months.
- **At-risk issue filters** — of five open issues: one with an iteration and in progress was
  included; one with **no iteration** excluded; one with an iteration but **never in progress**
  excluded; one in progress but **inside the SLA** excluded; and one whose iteration had no title was
  included with a synthesised label. Exclusion counts are logged, so nothing drops silently.
- **Open/unmerged at-risk detection** — of three unmerged MRs: one 200 hours old surfaced as *already
  overdue*, one at 70 hours now / 76 by end of day surfaced as *at risk today*, and one opened that
  morning was excluded. Both statuses reached the report, the headings showed `1 already overdue,
  1 at risk today`, and the table listed the overdue one first.
- **Summary + baseline** — reproduced against the agreed spreadsheet figures: July Insights showed
  throughput 76, cycle time 13.72, **16.5** merged MRs per author (33 MRs ÷ 2 authors) and lead time
  149.50, matching exactly. Shift colouring was checked both ways: a **fall** in cycle time scores as
  *better*, a **fall** in throughput scores as *worse*.
- **Both pods end to end** — Insights (3 repos) and Conv. Insights (7 repos) each produced an HTML and
  an XLSX report with sections in the order Summary → Shift → issue/MR summaries → detail listings.
- **Fully configurable pods** — a pod defined only in JSON (`Data Platform`, **2 issue projects** and
  **2 MR repos**, given partly as full `https://` URLs) produced exactly four correctly-named files:
  `Data_Platform_last_3_months_*.html/.xlsx` and `Data_Platform_daily_*.html/.xlsx`. Issues were
  pooled across both boards and MRs across both repos, in the monthly and the at-risk views alike.
  Config validation was checked for missing name, missing issues, missing repos and duplicate keys.
- **All pods processed, failures isolated** — with a three-pod config whose middle pod was
  deliberately unreachable (simulated 404), the two healthy pods each still produced all four files
  and the broken one was reported separately, rather than aborting the run and leaving the third pod
  unprocessed.
- **Exactly four files per pod, once** — the notebook was executed end to end against a three-pod
  config (including one with 2 issue projects and one with 3 MR repos given as a bare list). It wrote
  12 files: 4 per pod, 2 × `last_3_months` and 2 × `daily` each, with no pod duplicated.
- **Table interactivity** — the inline JavaScript was syntax-checked with `node --check` both
  standalone and as embedded in the generated HTML, and its sort comparator was exercised against the
  real cell formats: `2026-07 > 2026-06 > 2026-05 > 2026-04` chronologically, `#9 < #23 < #101 < #1002`
  numerically rather than lexically, hours sorting on their number despite a trailing status badge, and
  blank/em-dash cells sorting last in both directions.
- **DAG 2 idempotency** — with one of the eleven titles already open: 10 created, 1 skipped.
- **DAG 3 scoping** — of two label+iteration matches, only the one under the right parent epic was
  closed; the one under a different epic was left alone.
- **XCom round-trip** — metrics serialise to JSON-safe payloads and reconstruct with datetimes intact.
- All three HTML reports generated and rendered.

The GitLab client itself could not be exercised against a live instance from the build environment, so
that is the piece worth a first supervised run — ideally DAG 1 first (read-only), then DAG 2 and 3 in
dry-run mode.
