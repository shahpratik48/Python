"""
Configuration and logging for the GitLab productivity reporting project.

Token resolution follows the same pattern as the other projects:
  - interactive=True  (notebook): env var -> Airflow Variable -> getpass prompt
  - interactive=False (Airflow):  env var -> Airflow Variable -> raise

Nothing is ever hard-coded and nothing is written back to disk.
"""
from __future__ import annotations

import getpass
import json
import logging
import os
import re
import sys
from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional

# --------------------------------------------------------------------------
# Logging
# --------------------------------------------------------------------------
_LOG_FORMAT = "%(asctime)s | %(levelname)-7s | %(name)-22s | %(message)s"
_configured = False


def setup_logging(level: str = "INFO", log_dir: Optional[str] = None,
                  log_to_file: bool = True) -> str:
    """Configures root logging once. Returns the log file path (or "").

    Logs go to stdout so they appear in Airflow task logs and in notebook
    output, and additionally to a timestamped file next to the scripts so a
    run can be reviewed after the fact.
    """
    global _configured
    root = logging.getLogger()
    log_path = ""

    if _configured:
        return getattr(root, "_gl_log_path", "")

    root.setLevel(getattr(logging, str(level).upper(), logging.INFO))
    for h in list(root.handlers):
        root.removeHandler(h)

    stream = logging.StreamHandler(sys.stdout)
    stream.setFormatter(logging.Formatter(_LOG_FORMAT))
    root.addHandler(stream)

    if log_to_file:
        log_dir = log_dir or os.path.dirname(os.path.abspath(__file__))
        os.makedirs(log_dir, exist_ok=True)
        log_path = os.path.join(
            log_dir, f"gitlab_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
        fh = logging.FileHandler(log_path, encoding="utf-8")
        fh.setFormatter(logging.Formatter(_LOG_FORMAT))
        root.addHandler(fh)

    # third-party HTTP chatter would drown out our own logs
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("requests").setLevel(logging.WARNING)

    root._gl_log_path = log_path        # type: ignore[attr-defined]
    _configured = True
    logging.getLogger("gitlab.setup").info(
        "Logging initialised (level=%s, file=%s)", level, log_path or "<stdout only>")
    return log_path


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)


def _env(name: str, default: Optional[str] = None) -> Optional[str]:
    return os.getenv(name, default)


@dataclass
class Pod:
    """A delivery pod.

    A pod owns one or more ISSUE projects and one or more MERGE REQUEST
    repositories -- both are lists, because a pod's work rarely lives in a
    single place. Issues are pooled across every issue project; merge
    requests are summed across every repository and also broken out per
    repository in the report.
    """
    name: str                                   # display name, e.g. "Conv. Insights"
    key: str                                    # filename-safe key, e.g. "conv_insights"
    group_path: str = ""                        # group holding iterations/epics (optional)
    issue_projects: List[str] = field(default_factory=list)
    mr_repos: Dict[str, str] = field(default_factory=dict)   # label -> project path

    @property
    def primary_issue_project(self) -> str:
        """Used where a single project is unavoidable (ticket automation)."""
        return self.issue_projects[0] if self.issue_projects else ""

    @staticmethod
    def from_dict(d: dict) -> "Pod":
        """Builds a Pod from configuration, accepting the shapes people
        actually write rather than one rigid form."""
        name = str(d.get("name") or d.get("pod") or "").strip()
        if not name:
            raise ValueError("Each pod needs a 'name'. Offending entry: %r" % (d,))
        key = str(d.get("key") or "").strip() or re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")

        # issues: accept a single string or a list, under either key
        raw_issues = d.get("issue_projects", d.get("issue_urls", d.get("issue_project")))
        if isinstance(raw_issues, str):
            raw_issues = [raw_issues]
        issues = [_norm_path(p) for p in (raw_issues or []) if str(p).strip()]
        if not issues:
            raise ValueError("Pod %r needs at least one issue project "
                             "('issue_projects')." % name)

        # merge requests: accept {label: path} or a bare list of paths
        raw_mrs = d.get("mr_repos", d.get("mr_urls", d.get("repos")))
        repos: Dict[str, str] = {}
        if isinstance(raw_mrs, dict):
            for label, path in raw_mrs.items():
                if str(path).strip():
                    repos[str(label)] = _norm_path(path)
        elif isinstance(raw_mrs, (list, tuple)):
            for path in raw_mrs:
                if str(path).strip():
                    p = _norm_path(path)
                    repos[p.rstrip("/").split("/")[-1]] = p     # label from the last segment
        if not repos:
            raise ValueError("Pod %r needs at least one merge request repository "
                             "('mr_repos')." % name)

        group = _norm_path(d.get("group_path", "")) or issues[0].rsplit("/", 1)[0]
        return Pod(name=name, key=key, group_path=group, issue_projects=issues, mr_repos=repos)


def _norm_path(value) -> str:
    """Accepts either a bare project path or a full GitLab URL and returns
    the path GitLab's API expects, so configuration can be pasted straight
    from a browser address bar."""
    p = str(value or "").strip().rstrip("/")
    if not p:
        return ""
    if "://" in p:
        p = p.split("://", 1)[1]
        p = p.split("/", 1)[1] if "/" in p else ""
    for prefix in ("gitlab.com/", "-/"):
        if p.startswith(prefix):
            p = p[len(prefix):]
    return p.strip("/")


_GEN = ("ubs/gwma/smart-technology-and-analytics/staat-data-science/staat-ds-genesis/"
        "genesis-platform")
_INS = ("ubs/gwma/smart-technology-and-analytics/staat-data-science/staat-ds-insights-cl/"
        "commons")

# Built-in defaults, used when no pods file is present. Anything here can be
# replaced or extended by pods.json without touching this module.
DEFAULT_PODS = [
    {"name": "Insights", "key": "insights", "group_path": _INS,
     "issue_projects": [_INS + "/staat-ds-insights-home"],
     "mr_repos": {"IKG": _GEN + "/ikg-dags",
                  "NLG": _GEN + "/nlg-dags",
                  "ODM": _GEN + "/odm-dags"}},
    {"name": "Conv. Insights", "key": "conv_insights", "group_path": _GEN,
     "issue_projects": [_GEN + "/data-elements"],
     "mr_repos": {"conv-insights": _GEN + "/conv-insights",
                  "data-elements": _GEN + "/data-elements",
                  "data-elements-common": _GEN + "/data-elements-common",
                  "de-api": _GEN + "/de-api",
                  "transcript-accumulator": _GEN + "/transcript-accumulator",
                  "nlg-chat": _GEN + "/nlg-chat",
                  "portfolioq": _GEN + "/portfolioq"}},
]

PODS_FILE = _env("GL_PODS_FILE", os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                              "pods.json"))


def load_pods(path: Optional[str] = None) -> List[Pod]:
    """Pods from JSON configuration, falling back to the built-in defaults.

    Looked up in order: the `path` argument, then the GL_PODS_FILE
    environment variable, then `pods.json` beside these scripts. A malformed
    file raises rather than silently falling back -- quietly reporting on the
    wrong pods would be worse than stopping.
    """
    log = get_logger("gitlab.settings")
    target = path or PODS_FILE
    if target and os.path.exists(target):
        with open(target, encoding="utf-8") as fh:
            raw = json.load(fh)
        entries = raw.get("pods") if isinstance(raw, dict) else raw
        if not isinstance(entries, list) or not entries:
            raise ValueError("%s must contain a non-empty 'pods' list." % target)
        pods = [Pod.from_dict(e) for e in entries]
        keys = [p.key for p in pods]
        dupes = {k for k in keys if keys.count(k) > 1}
        if dupes:
            raise ValueError("Duplicate pod key(s) %s in %s -- keys become file names, so they "
                             "must be unique." % (sorted(dupes), target))
        log.info("Loaded %d pod(s) from %s: %s", len(pods), target,
                 ", ".join("%s (%d issue project(s), %d repo(s))"
                           % (p.name, len(p.issue_projects), len(p.mr_repos)) for p in pods))
        return pods

    log.info("No pods file at %s -- using the %d built-in default pod(s).",
             target, len(DEFAULT_PODS))
    return [Pod.from_dict(e) for e in DEFAULT_PODS]


ALL_PODS = load_pods()
PODS_BY_KEY = {p.key: p for p in ALL_PODS}
POD_INSIGHTS = PODS_BY_KEY.get("insights", ALL_PODS[0])
POD_CONV_INSIGHTS = PODS_BY_KEY.get("conv_insights", ALL_PODS[-1])


@dataclass
class GitLabSettings:
    # ---------------- connection ----------------
    gitlab_url: str = field(default_factory=lambda: _env("GITLAB_URL", "https://devcloud.ubs.net"))
    gitlab_token: Optional[str] = field(default_factory=lambda: _env("GITLAB_TOKEN", ""))
    gitlab_token_var: str = field(default_factory=lambda: _env(
        "GITLAB_TOKEN_VAR", "GENESIS_DDLC_IKG_GIT_SECRET"))

    # ---------------- pod (issue board + its code repositories) ----------------
    pod: Pod = field(default_factory=lambda: POD_INSIGHTS)

    # Kept as properties so every existing call site keeps working unchanged
    # while the underlying values now come from the selected pod.
    @property
    def code_repos(self) -> dict:
        return dict(self.pod.mr_repos)

    @property
    def group_path(self) -> str:
        return self.pod.group_path

    @property
    def issue_projects(self) -> List[str]:
        return list(self.pod.issue_projects)

    @property
    def project_path(self) -> str:
        # single-project shorthand, used by the ticket automation DAGs
        return self.pod.primary_issue_project

    @property
    def pod_name(self) -> str:
        return self.pod.name

    # ---------------- reporting window / thresholds ----------------
    months_back: int = field(default_factory=lambda: int(_env("GL_MONTHS_BACK", "3")))
    # Fixed reference month every other month is compared against, so shifts
    # are measured from one stable point rather than a moving window.
    baseline_month: str = field(default_factory=lambda: _env("GL_BASELINE_MONTH", "2025-11"))
    issue_sla_business_days: float = field(default_factory=lambda: float(_env("GL_ISSUE_SLA_DAYS", "5")))
    mr_sla_hours: float = field(default_factory=lambda: float(_env("GL_MR_SLA_HOURS", "72")))

    # Which label marks "In progress". Matching is case-insensitive and also
    # matches scoped labels such as `workflow::In progress`, since teams vary
    # in how they name this.
    in_progress_labels: List[str] = field(default_factory=lambda: [
        s.strip() for s in _env("GL_IN_PROGRESS_LABELS", "in progress,in-progress,doing,wip").split(",")
        if s.strip()])

    # ---------------- ticket automation (DAG 2 / DAG 3) ----------------
    ticket_label: str = field(default_factory=lambda: _env("GL_TICKET_LABEL", "@productivity"))
    ticket_parent: str = field(default_factory=lambda: _env("GL_TICKET_PARENT", "BAU Technical 2026"))
    ticket_weight: int = field(default_factory=lambda: int(_env("GL_TICKET_WEIGHT", "1")))
    ticket_titles: List[str] = field(default_factory=lambda: [
        "QA Testing for new insights",
        "UAT Testing for new insights",
        "Pipeline monitoring for Dev",
        "Pipeline monitoring for preprod",
        "Pipeline monitoring for production",
        "Pipeline monitoring for Dummy",
        "Dashboard enhencements for release",
        "Dashboard enhencements for metadata",
        "Code review for IKG",
        "Code review for ODM",
        "Code review for NLG",
    ])

    # ---------------- output ----------------
    output_dir: str = field(default_factory=lambda: _env(
        "GL_OUTPUT_DIR", os.path.dirname(os.path.abspath(__file__))))
    log_level: str = field(default_factory=lambda: _env("GL_LOG_LEVEL", "INFO"))

    # Safety switch for the write DAGs: when True nothing is created or
    # closed, but every action that WOULD be taken is logged and reported.
    dry_run: bool = field(default_factory=lambda: _env("GL_DRY_RUN", "false").lower() == "true")

    # ---------------- secrets ----------------
    def _airflow_variable(self, key: str) -> Optional[str]:
        try:
            from airflow.models import Variable  # type: ignore
            return Variable.get(key, default_var=None)
        except Exception:
            return None

    def resolve_token(self, interactive: bool = True) -> "GitLabSettings":
        log = get_logger("gitlab.settings")
        if self.gitlab_token:
            log.info("GitLab token supplied via environment/constructor.")
            return self

        self.gitlab_token = self._airflow_variable(self.gitlab_token_var)
        if self.gitlab_token:
            log.info("GitLab token resolved from Airflow Variable '%s'.", self.gitlab_token_var)
            return self

        if interactive:
            log.info("No token in environment or Airflow Variable -- prompting.")
            self.gitlab_token = getpass.getpass("GitLab personal access token: ").strip() or None
            if self.gitlab_token:
                log.info("GitLab token captured from prompt (hidden input).")
            return self

        raise RuntimeError(
            f"No GitLab token available. Set the GITLAB_TOKEN environment variable or the "
            f"Airflow Variable '{self.gitlab_token_var}'.")
