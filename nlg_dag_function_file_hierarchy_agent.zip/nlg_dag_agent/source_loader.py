"""
Loads source files either from a local directory (offline / notebook-with-
checkout mode) or directly from a GitLab project via the REST API (no git
clone needed -- works well from inside an Airflow worker).
"""
from __future__ import annotations

import os
import posixpath
import urllib.parse
from dataclasses import dataclass
from typing import Dict, List, Optional


@dataclass
class SourceFile:
    path: str        # logical path, e.g. "dags/nlg_master.py" or "src/rules/account/foo.py"
    content: str


class SourceRepo:
    """Base interface. `namespace` is a short tag like 'dags' or 'src'."""

    def list_files(self, extensions: Optional[List[str]] = None) -> List[str]:
        raise NotImplementedError

    def read_file(self, path: str) -> str:
        raise NotImplementedError

    def read_all(self, extensions: Optional[List[str]] = None) -> Dict[str, str]:
        return {p: self.read_file(p) for p in self.list_files(extensions)}


class LocalSourceRepo(SourceRepo):
    """Reads from a directory already present on disk (e.g. an extracted
    GitLab archive or a `git clone`)."""

    def __init__(self, root_dir: str):
        self.root_dir = root_dir
        self._files: Optional[List[str]] = None

    def _walk(self) -> List[str]:
        if self._files is not None:
            return self._files
        out = []
        for dirpath, dirnames, filenames in os.walk(self.root_dir):
            dirnames[:] = [d for d in dirnames if d not in (".git", "__pycache__", ".ipynb_checkpoints")]
            for fn in filenames:
                full = os.path.join(dirpath, fn)
                rel = os.path.relpath(full, self.root_dir).replace(os.sep, "/")
                out.append(rel)
        self._files = sorted(out)
        return self._files

    def list_files(self, extensions: Optional[List[str]] = None) -> List[str]:
        files = self._walk()
        if extensions:
            exts = tuple(extensions)
            files = [f for f in files if f.endswith(exts)]
        return files

    def read_file(self, path: str) -> str:
        full = os.path.join(self.root_dir, path)
        with open(full, "r", encoding="utf-8", errors="replace") as fh:
            return fh.read()


class GitLabSourceRepo(SourceRepo):
    """Reads a subtree of a GitLab project via the REST API using a
    personal / project access token. No local clone required."""

    def __init__(self, base_url: str, project_path: str, token: str,
                 ref: str = "develop", subpath: str = ""):
        import requests  # local import so the package works w/o `requests` in pure-local mode
        self._requests = requests
        self.base_url = base_url.rstrip("/")
        self.project_path = project_path
        self.token = token
        self.ref = ref
        self.subpath = subpath.strip("/")
        self._project_id: Optional[int] = None
        self._files: Optional[List[str]] = None

    def _headers(self):
        return {"PRIVATE-TOKEN": self.token}

    def _project_id_lookup(self) -> int:
        if self._project_id is not None:
            return self._project_id
        encoded = urllib.parse.quote(self.project_path, safe="")
        url = f"{self.base_url}/api/v4/projects/{encoded}"
        r = self._requests.get(url, headers=self._headers(), timeout=30)
        r.raise_for_status()
        self._project_id = r.json()["id"]
        return self._project_id

    def _walk(self) -> List[str]:
        if self._files is not None:
            return self._files
        pid = self._project_id_lookup()
        files: List[str] = []
        page = 1
        while True:
            url = f"{self.base_url}/api/v4/projects/{pid}/repository/tree"
            params = {"path": self.subpath, "ref": self.ref, "recursive": "true",
                      "per_page": 100, "page": page}
            r = self._requests.get(url, headers=self._headers(), params=params, timeout=60)
            r.raise_for_status()
            batch = r.json()
            if not batch:
                break
            for item in batch:
                if item.get("type") == "blob":
                    files.append(item["path"])
            if len(batch) < 100:
                break
            page += 1
        # store paths relative to subpath for consistency with LocalSourceRepo
        rel = []
        for f in files:
            rel.append(posixpath.relpath(f, self.subpath) if self.subpath else f)
        self._files = sorted(rel)
        self._path_map = dict(zip(self._files, files))
        return self._files

    def list_files(self, extensions: Optional[List[str]] = None) -> List[str]:
        files = self._walk()
        if extensions:
            exts = tuple(extensions)
            files = [f for f in files if f.endswith(exts)]
        return files

    def read_file(self, path: str) -> str:
        self._walk()
        full_path = self._path_map.get(path, posixpath.join(self.subpath, path) if self.subpath else path)
        pid = self._project_id_lookup()
        encoded = urllib.parse.quote(full_path, safe="")
        url = f"{self.base_url}/api/v4/projects/{pid}/repository/files/{encoded}/raw"
        r = self._requests.get(url, headers=self._headers(), params={"ref": self.ref}, timeout=30)
        r.raise_for_status()
        return r.text


def build_repos(settings) -> Dict[str, SourceRepo]:
    """Returns {'dags': SourceRepo, 'src': SourceRepo} using local dirs if
    configured, otherwise GitLab."""
    if settings.local_dags_dir and settings.local_src_dir:
        return {
            "dags": LocalSourceRepo(settings.local_dags_dir),
            "src": LocalSourceRepo(settings.local_src_dir),
        }
    if not settings.gitlab_token:
        raise RuntimeError(
            "No local_dags_dir/local_src_dir configured and no GitLab token available. "
            "Call settings.resolve_secrets() first, or set NLG_LOCAL_DAGS_DIR / NLG_LOCAL_SRC_DIR."
        )
    return {
        "dags": GitLabSourceRepo(settings.gitlab_url, settings.nlg_project_path, settings.gitlab_token,
                                  ref=settings.default_base_branch, subpath=settings.nlg_dags_subpath),
        "src": GitLabSourceRepo(settings.gitlab_url, settings.nlg_project_path, settings.gitlab_token,
                                 ref=settings.default_base_branch, subpath=settings.nlg_src_subpath),
    }
