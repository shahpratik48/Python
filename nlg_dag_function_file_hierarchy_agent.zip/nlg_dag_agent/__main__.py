"""
Command-line entry point.

    python -m nlg_dag_agent build   --local-dags ./nlg-dag/dags --local-src ./nlg-src/src
    python -m nlg_dag_agent build   --gitlab                       # uses env vars / prompts
    python -m nlg_dag_agent impact  --file nlg_main_class.py --hierarchy out/nlg_hierarchy.json
    python -m nlg_dag_agent impact  --target-type client_windfall  --hierarchy out/nlg_hierarchy.json
    python -m nlg_dag_agent ask     "What tasks would break if I change generate_rule_narratives?"
"""
from __future__ import annotations

import argparse
import json
import sys

from .config import Settings
from .pipeline import build_hierarchy, run_impact_analysis, ask as ask_llm


def _settings_from_args(args) -> Settings:
    s = Settings()
    if args.provider:
        s.llm_provider = args.provider
    if getattr(args, "local_dags", None):
        s.local_dags_dir = args.local_dags
    if getattr(args, "local_src", None):
        s.local_src_dir = args.local_src
    interactive = not args.non_interactive
    s.resolve_secrets(interactive=interactive)
    return s


def cmd_build(args):
    s = _settings_from_args(args)
    h = build_hierarchy(s)
    out_path = args.out or "./nlg_dag_agent_output/nlg_hierarchy.json"
    h.save_json(out_path)
    print(f"Extracted {len(h.dags)} DAG(s). Hierarchy saved to {out_path}")
    if args.print_tree:
        h.print_tree()


def cmd_impact(args):
    with open(args.hierarchy, "r", encoding="utf-8") as fh:
        data = json.load(fh)
    # lightweight re-scan for impact query convenience via CLI: rebuild in-memory
    # (for CLI use we just grep the saved JSON rather than rehydrating objects)
    def grep_tasks(node, path_frag=None, target_type=None, func=None, dag_id=None, out=None):
        out = out if out is not None else []
        for t in node.get("tasks", []):
            hit = False
            if path_frag and any(path_frag in m.get("file", "") for m in t.get("methods", [])):
                hit = True
            if path_frag and any(path_frag in r.get("path", "") for r in t.get("resources", [])):
                hit = True
            if target_type and t.get("target_type") and target_type in t.get("target_type"):
                hit = True
            if func and any(func in m.get("name", "") for m in t.get("methods", [])):
                hit = True
            if hit:
                out.append({"dag": dag_id, "task": t["full_task_id"], "methods": t["methods"],
                            "target_type": t.get("target_type")})
        for g in node.get("groups", []) or node.get("subgroups", []):
            grep_tasks(g, path_frag, target_type, func, dag_id, out)
        return out

    results = []
    for dag in data["dags"]:
        results.extend(grep_tasks(dag, args.file, args.target_type, args.function, dag["dag_id"]))
    print(json.dumps(results, indent=2, default=str))


def main(argv=None):
    parser = argparse.ArgumentParser(prog="nlg_dag_agent")
    parser.add_argument("--provider", choices=["azure_openai", "azure_gateway", "none"], default=None)
    parser.add_argument("--non-interactive", action="store_true",
                         help="Do not prompt for secrets (Airflow/CI mode).")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_build = sub.add_parser("build", help="Extract the full hierarchy and save it as JSON.")
    p_build.add_argument("--local-dags", help="Local path to the nlg dags folder (offline mode).")
    p_build.add_argument("--local-src", help="Local path to the nlg src folder (offline mode).")
    p_build.add_argument("--out", help="Output JSON path.")
    p_build.add_argument("--print-tree", action="store_true")
    p_build.set_defaults(func=cmd_build)

    p_impact = sub.add_parser("impact", help="Query a previously-saved hierarchy JSON.")
    p_impact.add_argument("--hierarchy", required=True)
    p_impact.add_argument("--file", help="Substring of a file path (e.g. nlg_main_class.py).")
    p_impact.add_argument("--target-type", help="target_type value (e.g. client_windfall).")
    p_impact.add_argument("--function", help="Function/method name substring.")
    p_impact.set_defaults(func=cmd_impact)

    args = parser.parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main()
