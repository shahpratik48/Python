"""
nlg_dag_agent
=============
An LLM-assisted static-analysis agent that builds a full
DAG -> sub-DAG(TaskGroup) -> task/sub-task -> method -> file
hierarchy for the NLG Airflow codebase (nlg-dags / nlg-src), and answers
impact-analysis questions ("what breaks if I change file/method X?").

Runs unmodified in two contexts:
  1. A Jupyter notebook (interactive, prompts for LLM key / GitLab token).
  2. An Airflow DAG (non-interactive, reads secrets from Airflow Variables).

Core hierarchy extraction is 100% static (AST-based) and needs no LLM key
at all. The LLM is used only to (a) resolve ambiguous dynamic-dispatch
calls the static pass could not resolve, and (b) answer free-text
questions about the extracted hierarchy.
"""

from .config import Settings
from .pipeline import build_hierarchy, run_impact_analysis, ask

__all__ = ["Settings", "build_hierarchy", "run_impact_analysis", "ask"]
