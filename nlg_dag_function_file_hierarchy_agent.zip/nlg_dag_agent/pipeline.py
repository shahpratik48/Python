from __future__ import annotations

import json
import os
from typing import Dict, List, Optional, Any

from .config import Settings
from .source_loader import build_repos
from .dag_ast_parser import HierarchyExtractor
from .src_scanner import SrcIndex
from .dispatch_resolver import build_dispatch_map, DispatchInfo
from .model import DagNode, TaskGroupNode, TaskNode, MethodRef
from . import llm_client

PY_EXT = [".py"]
ALL_SRC_EXT = [".py", ".yml", ".yaml", ".sql", ".ini"]


class Hierarchy:
    """Container for the fully-resolved hierarchy plus the indices needed
    for impact analysis, kept together so a notebook/DAG can build it once
    and query it many times."""

    def __init__(self, dags: List[DagNode], src_index: SrcIndex, settings: Settings):
        self.dags = dags
        self.src_index = src_index
        self.settings = settings
        self._task_by_method_file: Dict[str, List[str]] = {}   # file -> [full_task_id, ...]
        self._task_index: Dict[str, TaskNode] = {}              # full_task_id -> TaskNode
        self._build_reverse_indices()

    # ------------------------------------------------------------------
    def _walk_groups(self, dag: DagNode, group: Optional[TaskGroupNode] = None):
        tasks = dag.tasks if group is None else group.tasks
        subgroups = dag.groups if group is None else group.subgroups
        for t in tasks:
            yield dag, group, t
        for g in subgroups:
            yield from self._walk_groups(dag, g)

    def all_tasks(self):
        for dag in self.dags:
            yield from self._walk_groups(dag)

    def _build_reverse_indices(self):
        for dag, group, task in self.all_tasks():
            self._task_index[task.full_task_id] = task
            for m in task.methods:
                self._task_by_method_file.setdefault(m.file, []).append(task.full_task_id)
            for r in task.resources:
                self._task_by_method_file.setdefault(r.path, []).append(task.full_task_id)

    # ------------------------------------------------------------------ output
    def to_dict(self) -> dict:
        return {"dags": [d.to_dict() for d in self.dags]}

    def save_json(self, path: str):
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(self.to_dict(), fh, indent=2, default=str)

    def print_tree(self, max_depth: int = 6):
        for dag in self.dags:
            print(f"DAG: {dag.dag_id}  [{dag.source_file}]")
            self._print_group_tree(dag.groups, dag.tasks, indent=1, depth=max_depth)
            print()

    def _print_group_tree(self, groups, tasks, indent, depth):
        pad = "  " * indent
        if depth <= 0:
            return
        for t in tasks:
            methods = ", ".join(f"{m.name}[{m.file}]" for m in t.methods) or "(unresolved)"
            tag = f" target_type={t.target_type}" if t.target_type else ""
            print(f"{pad}- task {t.task_id} ({t.operator}) -> {methods}{tag}")
        for g in groups:
            print(f"{pad}+ sub-DAG/TaskGroup: {g.group_id}  [{g.source_file}::{g.defined_in_function}]")
            self._print_group_tree(g.subgroups, g.tasks, indent + 1, depth - 1)

    # ------------------------------------------------------------------ impact analysis
    def impact_of_file(self, file_path_substring: str) -> List[dict]:
        """Given a (partial) file path, return every task that is wired to
        it, either directly (python_callable/dispatch method lives there)
        or via an associated resource (yaml/sql/ini)."""
        hits = []
        for file, task_ids in self._task_by_method_file.items():
            if file_path_substring in file:
                for tid in set(task_ids):
                    t = self._task_index[tid]
                    hits.append({
                        "matched_file": file,
                        "task": tid,
                        "operator": t.operator,
                        "target_type": t.target_type,
                        "product": t.product,
                        "source_file": t.source_file,
                    })
        return hits

    def impact_of_target_type(self, target_type: str) -> List[dict]:
        hits = []
        for dag, group, task in self.all_tasks():
            if task.target_type and target_type in task.target_type:
                hits.append({
                    "task": task.full_task_id,
                    "dag": dag.dag_id,
                    "operator": task.operator,
                    "product": task.product,
                    "insight_types": task.insight_types,
                })
        return hits

    def impact_of_function(self, func_or_method_name: str) -> List[dict]:
        hits = []
        for dag, group, task in self.all_tasks():
            for m in task.methods:
                if func_or_method_name in m.name:
                    hits.append({
                        "task": task.full_task_id, "dag": dag.dag_id,
                        "method": m.name, "file": m.file, "resolution": m.resolution,
                    })
        return hits


# ---------------------------------------------------------------------- build
def build_hierarchy(settings: Settings, use_llm_fallback: Optional[bool] = None) -> Hierarchy:
    """Main entry point. Reads dags+src (local or GitLab per `settings`),
    statically extracts the full DAG/TaskGroup/Task tree, resolves each
    task's method+file (direct call -> dynamic dispatch -> LLM fallback),
    and attaches target_type/product/resource metadata.
    """
    if use_llm_fallback is None:
        use_llm_fallback = settings.llm_enabled

    repos = build_repos(settings)
    dag_files = repos["dags"].read_all(PY_EXT)
    src_files_all = repos["src"].read_all(ALL_SRC_EXT)

    extractor = HierarchyExtractor(dag_files)
    dags = extractor.extract_dags()

    src_index = SrcIndex(src_files_all)
    dispatch_map = build_dispatch_map(extractor.func_registry)

    # Note: functions that build a TaskGroup (e.g. `get_nlg_rules`) are
    # memoized in the extractor, so if more than one DAG file calls the
    # same helper function, the *same* TaskGroupNode/TaskNode objects are
    # shared across those DagNodes. Resolve each physical TaskNode once.
    seen = set()
    for dag, group, task in _walk_all(dags):
        if id(task) in seen:
            continue
        seen.add(id(task))
        _resolve_task(task, extractor, src_index, dispatch_map, settings, use_llm_fallback)

    return Hierarchy(dags, src_index, settings)


def _walk_all(dags: List[DagNode]):
    def walk_group(dag, group):
        for t in group.tasks:
            yield dag, group, t
        for g in group.subgroups:
            yield from walk_group(dag, g)
    for dag in dags:
        for t in dag.tasks:
            yield dag, None, t
        for g in dag.groups:
            yield from walk_group(dag, g)


def _resolve_task(task: TaskNode, extractor: HierarchyExtractor, src_index: SrcIndex,
                   dispatch_map: Dict[str, DispatchInfo], settings: Settings, use_llm_fallback: bool):
    # 1) Postgres / SQL-only tasks
    if task.operator == "PostgresOperator" or task.sql_snippet is not None:
        task.methods.append(MethodRef(name="N/A", file=task.source_file, kind="N/A",
                                       resolution="static", note="Postgres operator with sql code"))
    elif task.python_callable:
        pc = task.python_callable
        resolved = False
        # 2) dynamic-dispatch idiom: eval(f"{obj}.{kwargs['key']}()")
        if pc in dispatch_map:
            info = dispatch_map[pc]
            action = task.op_kwargs.get(info.dispatch_kwarg)
            if isinstance(action, str):
                file = src_index.find_class_method_file(info.class_name, action)
                if file:
                    task.methods.append(MethodRef(name=f"{info.class_name}.{action}", file=file,
                                                    kind="method", resolution="dispatch"))
                    resolved = True
                else:
                    task.methods.append(MethodRef(name=f"{info.class_name}.{action}",
                                                    file=src_index.classes.get(info.class_name).file
                                                    if info.class_name in src_index.classes else "UNKNOWN",
                                                    kind="method", resolution="dispatch",
                                                    note="method not found on class - verify manually"))
                    resolved = True
        # 3) direct function resolution: python_callable defined in dag files themselves
        if not resolved:
            if pc in extractor.func_registry:
                _, file, _ = extractor.func_registry[pc]
                task.methods.append(MethodRef(name=pc, file=file, kind="function", resolution="static"))
                resolved = True
            else:
                # 3b) or defined in nlg-src
                file = src_index.find_function_file(pc)
                if file:
                    task.methods.append(MethodRef(name=pc, file=file, kind="function", resolution="static"))
                    resolved = True
        # 4) LLM fallback
        if not resolved and use_llm_fallback:
            result = _llm_resolve(task, settings)
            if result:
                task.methods.append(result)
                resolved = True
        if not resolved:
            task.methods.append(MethodRef(name=pc, file="UNKNOWN", kind="function",
                                            resolution="unresolved",
                                            note="static+LLM resolution both failed; needs manual check"))
    # else: e.g. EmptyOperator/BranchPythonOperator with inline branching function already covered above
    elif task.operator in ("BranchPythonOperator",) and task.python_callable is None:
        pass

    # resource attachment
    if task.target_type:
        task.resources = src_index.resources_for_target_type(task.target_type)
        task.insight_types = src_index.insight_types_for_target_type(task.target_type)


def _llm_resolve(task: TaskNode, settings: Settings) -> Optional[MethodRef]:
    system = ("You are a senior Python/Airflow code analyst. Given a task's python_callable name "
              "and its op_kwargs, infer which underlying function/class-method is actually executed "
              "when this idiom is not a plain 1:1 call. Reply with strict JSON only: "
              '{"method": "<Class.method or function name>", "confidence": "low|medium|high", "reasoning": "..."}')
    user = (f"python_callable: {task.python_callable}\n"
            f"op_kwargs: {json.dumps(task.op_kwargs, default=str)}\n"
            f"operator: {task.operator}\ntask_id: {task.task_id}")
    result = llm_client.call_llm_json(settings, system, user)
    if not result or "method" not in result:
        return None
    return MethodRef(name=result["method"], file="LLM_INFERRED", kind="method", resolution="llm",
                      note=f"confidence={result.get('confidence','?')}: {result.get('reasoning','')}")


# ---------------------------------------------------------------------- impact / Q&A entry points
def run_impact_analysis(hierarchy: Hierarchy, changed_file: Optional[str] = None,
                          target_type: Optional[str] = None, function_name: Optional[str] = None) -> dict:
    out = {}
    if changed_file:
        out["by_file"] = hierarchy.impact_of_file(changed_file)
    if target_type:
        out["by_target_type"] = hierarchy.impact_of_target_type(target_type)
    if function_name:
        out["by_function"] = hierarchy.impact_of_function(function_name)
    return out


def ask(hierarchy: Hierarchy, question: str, max_chars: int = 60000) -> str:
    """Free-text Q&A over the extracted hierarchy, via LLM. Falls back to a
    canned message if no LLM is configured."""
    if not hierarchy.settings.llm_enabled:
        return ("LLM not configured -- set LLM_PROVIDER/keys, or call "
                "hierarchy.impact_of_file()/impact_of_target_type()/impact_of_function() directly.")
    payload = json.dumps(hierarchy.to_dict(), default=str)
    if len(payload) > max_chars:
        payload = payload[:max_chars] + "\n...[truncated]..."
    system = ("You are an expert on the NLG Airflow pipeline. Answer questions using ONLY the "
              "JSON hierarchy provided (DAG -> TaskGroup -> Task -> method/file, with target_type, "
              "product, and resource metadata). Be precise and cite task_ids/files.")
    user = f"HIERARCHY_JSON:\n{payload}\n\nQUESTION: {question}"
    try:
        return llm_client.call_llm(hierarchy.settings, system, user)
    except Exception as e:
        return f"LLM call failed: {e}"
