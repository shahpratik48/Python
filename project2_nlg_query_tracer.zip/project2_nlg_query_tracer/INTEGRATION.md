# Query alias qualification + attribute inventory

Four drop-in modules for **Project 2 (`nlg_query_tracer`)**. Copy them into the
`nlg_query_tracer/` package folder alongside the existing modules.

| File | Purpose |
|---|---|
| `qt_sqlscan.py` | SQL scanning that respects literals, comments and nesting |
| `qt_alias.py` | Adds the right table alias to bare columns, using Greenplum metadata |
| `qt_attributes.py` | Extracts main-SELECT attributes with table, alias and logic |
| `qt_attributes_sheet.py` | Writes the **Query Attributes** worksheet |

---

## 1. Alias qualification

Some generated queries reference a column bare — `metric_val` rather than `a.metric_val`. That is
valid only while the name happens to be unique across the joined tables, and it breaks the moment a
second table gains the same column.

`qualify()` asks Greenplum which tables actually contain each column and prefixes accordingly.

**Precedence when a column exists in several of the query's tables:**

1. a table matching `%profile%`
2. otherwise a table matching `%odm%`
3. otherwise the first remaining table, in FROM order

```python
from qt_attributes import from_alias_map
from qt_alias import qualify

alias_map = from_alias_map(sql)          # {'a': 'core_ikg.si_odm_insights_active', 'b': ...}
sql = qualify(sql, alias_map, conn)      # conn = an open Greenplum connection
```

**Where to call it:** immediately after the tracer has recovered the SQL for an insight_type and
before it is stored or written out, so everything downstream sees the qualified form.

Only the **main select list** is rewritten. Sub-queries have their own scope — a bare column there
refers to their own FROM, and prefixing it with an outer alias would change the query's meaning
rather than clarify it.

Column metadata is read **once per table** and cached for the process, so a run over hundreds of
insight types makes a handful of metadata queries rather than one per column. If the metadata cannot
be read, the query is left exactly as it was: a wrong alias is worse than no alias.

---

## 2. The Query Attributes worksheet

One row per attribute the **main select list** reads. Not sub-queries, WHERE, JOIN or HAVING — those
columns are how the result is *found*, whereas the select list is what the narrative actually *uses*.

```python
from qt_attributes_sheet import collect_attributes, write_attributes_sheet

rows = collect_attributes(traced)        # any iterable with target_type / insight_type / sql
write_attributes_sheet(rows, xlsx_path)  # adds the sheet to the workbook already produced
```

`collect_attributes` accepts dicts or objects and looks for `sql`, `query` or `final_sql`, so it fits
whatever shape the tracer returns.

### Columns

| Column | Meaning |
|---|---|
| `target_type` | as traced |
| `insight_type` | as traced |
| `attribute` | the column, or the literal where there is no column |
| `table` | the source table, or `NULL` for a literal |
| `alias` | the output name |
| `logic` | the select-list item, verbatim |

### Rules

- **One row per (attribute, table, alias, logic).** The same attribute appears again under a
  different alias or expression — those are genuinely different usages.
- **An expression reading two columns produces two rows**, sharing one alias and one logic string.
  The `CASE WHEN ... svg_elg_mhh_acc_lst ... THEN acc_n` example gives exactly two.
- **A derived table resolves to the table inside it.** `a.insight_type` reports
  `si_odm_insights_active`, not `a` — reporting the alias would tell a reader nothing.
- **Literals have no table**, so `table` is written as `NULL` rather than left blank, which would
  read as "not yet worked out".

> **One note on the header order.** Your example's header line reads `table | attribute`, but every
> sample row is written `attribute` then `table` — for instance
> `... | insight_type | si_odm_insights_active | ...`, where `insight_type` is the column and
> `si_odm_insights_active` the table. I followed the **data**, since it is consistent across all the
> sample rows, and labelled the headers to match. Say the word if you would rather have the columns
> the other way round.

---

## Verified against your example

The reference query produced **23 rows**, including every row you listed:

```
attribute            table                                       alias               logic
insight_type         si_odm_insights_active                      insight_type        a.insight_type
'acc_i_asset_key'    NULL                                        key_name            'acc_i_asset_key' as key_name
acc_mhh_n            account_mmf_to_core_svngs_profile_curr_ikg  acc_mhh_n           b.acc_mhh_n::text
profile_date         account_mmf_to_core_svngs_profile_curr_ikg  profile_date        (b.profile_date::date - interval '3' day) as profile_date
saving_promo_rate    account_mmf_to_core_svngs_profile_curr_ikg  saving_promo_rate   b.saving_promo_rate
lead_account_title   account_mmf_to_core_svngs_profile_curr_ikg  lead_acc_title      initcap(b.lead_account_title) as lead_acc_title
svg_elg_mhh_acc_lst  account_mmf_to_core_svngs_profile_curr_ikg  has_multi_accounts  CASE WHEN ... THEN b.acc_n ELSE 0 END AS has_multi_accounts
acc_n                account_mmf_to_core_svngs_profile_curr_ikg  has_multi_accounts  CASE WHEN ... THEN b.acc_n ELSE 0 END AS has_multi_accounts
```

Alias qualification was tested on a variant of the same query with bare columns and two columns
present in **both** tables (`acc_i`, `metric_val`) — both resolved to the `%profile%` table:

```
select insight_type, target_key, metric_val, acc_i, saving_promo_rate, upper(lead_account_title) as lead_title
  ->  select a.insight_type, a.target_key, b.metric_val, b.acc_i, b.saving_promo_rate, upper(b.lead_account_title) as lead_title
```

Parsing edge cases covered: `DISTINCT ON (...)` not mistaken for a column; commas inside
`string_to_array(x, ';')` not treated as select-list separators; the `ON` of a join distinguished
from the `ON` of `DISTINCT ON`; `::text` cast targets excluded; function names not mistaken for
columns; and an `AS` alias not counted as a column it reads.

---

## To finish the integration

Project 2's own files are not in this workspace — send `project2_nlg_query_tracer.zip` (or the
all-projects zip) and I will wire these in: the `qualify()` call into the tracer's SQL-building step,
and the sheet into its XLSX export, then re-run the tracer end to end.
