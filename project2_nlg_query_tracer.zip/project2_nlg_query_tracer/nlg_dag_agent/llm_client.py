"""
Thin LLM client. Supports:
  - Azure OpenAI (standard Chat Completions REST API)
  - The internal "Azure LLM Gateway" fallback (OpenAI-compatible payload
    assumed -- adjust `_call_gateway` if your gateway's actual contract
    differs; this is the one piece we could not verify from the provided
    config screenshot, so it is isolated in a single small function).

All calls are best-effort: if the LLM is unavailable/unconfigured, callers
in this package always have a static fallback and simply mark the result
as "unresolved" rather than failing the whole pipeline.
"""
from __future__ import annotations

import json
from typing import Optional

from .config import Settings


class LLMUnavailable(RuntimeError):
    pass


def call_llm(settings: Settings, system_prompt: str, user_prompt: str,
              json_mode: bool = False) -> str:
    if not settings.llm_enabled:
        raise LLMUnavailable("LLM not configured (no API key / provider=none).")
    if settings.llm_provider == "azure_openai":
        return _call_azure_openai(settings, system_prompt, user_prompt, json_mode)
    if settings.llm_provider == "azure_gateway":
        return _call_gateway(settings, system_prompt, user_prompt, json_mode)
    raise LLMUnavailable(f"Unknown LLM provider: {settings.llm_provider}")


def _call_azure_openai(settings: Settings, system_prompt: str, user_prompt: str, json_mode: bool) -> str:
    import requests
    url = (settings.azure_openai_endpoint.rstrip("/") +
           f"/openai/deployments/{settings.azure_openai_deployment}/chat/completions"
           f"?api-version={settings.azure_openai_api_version}")
    # Some endpoints (as in the provided config, ending in /openai/v1/) already
    # point at the v1-style base; fall back to that form if the deployments
    # form 404s. We try the deployments form first since it's the most common.
    headers = {"api-key": settings.azure_openai_api_key, "Content-Type": "application/json"}
    body = {
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "temperature": settings.llm_temperature,
        "max_tokens": settings.llm_max_tokens,
    }
    if json_mode:
        body["response_format"] = {"type": "json_object"}
    r = requests.post(url, headers=headers, json=body, timeout=120)
    if r.status_code == 404:
        # fall back to the v1 chat/completions form
        url2 = settings.azure_openai_endpoint.rstrip("/") + "/chat/completions"
        body["model"] = settings.azure_openai_deployment
        r = requests.post(url2, headers=headers, json=body, timeout=120)
    r.raise_for_status()
    data = r.json()
    return data["choices"][0]["message"]["content"]


def _call_gateway(settings: Settings, system_prompt: str, user_prompt: str, json_mode: bool) -> str:
    import requests
    headers = {"Authorization": f"Bearer {settings.llm_api_key}", "Content-Type": "application/json"}
    body = {
        "model": settings.llm_model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "temperature": settings.llm_temperature,
        "max_tokens": settings.llm_max_tokens,
    }
    url = settings.llm_gateway_url.rstrip("/") + "/v1/chat/completions"
    r = requests.post(url, headers=headers, json=body, timeout=120)
    r.raise_for_status()
    data = r.json()
    return data["choices"][0]["message"]["content"]


def call_llm_json(settings: Settings, system_prompt: str, user_prompt: str) -> Optional[dict]:
    try:
        raw = call_llm(settings, system_prompt, user_prompt, json_mode=True)
    except Exception:
        return None
    raw = raw.strip()
    if raw.startswith("```"):
        raw = raw.strip("`")
        if raw.startswith("json"):
            raw = raw[4:]
    try:
        return json.loads(raw)
    except Exception:
        return None
