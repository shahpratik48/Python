"""
Exports the combined `nlg_hierarchy` row-set (see report_rows.combined_rows)
to a Greenplum table -- dropping and recreating it every run, then applying
the standing GRANT/ALTER statements for this schema.

Connection resolution, in order:
  1. Inside Airflow: `PostgresHook(postgres_conn_id=settings.postgres_conn_id_var)`,
     schema name from the Airflow Variable named `settings.greenplum_schema_var`
     (falls back to `settings.greenplum_schema` if that Variable isn't set).
  2. Local/notebook: a direct psycopg2 connection using
     settings.greenplum_host/port/db/user/schema, with the password read
     from GREENPLUM_PASSWORD or prompted interactively (never hard-coded).

Usage:
    from nlg_dag_agent import build_hierarchy, Settings
    from nlg_dag_agent.greenplum_export import export_to_greenplum

    settings = Settings()
    settings.resolve_secrets(interactive=True)
    settings.resolve_greenplum_password(interactive=True)
    hierarchy = build_hierarchy(settings)
    export_to_greenplum(hierarchy, settings)
"""
from __future__ import annotations

import csv
import io
from typing import List, Optional, Tuple

from .config import Settings
from .pipeline import Hierarchy
from .report_rows import combined_rows, COMBINED_COLUMNS

# All COMBINED_COLUMNS are free-form text in practice (paths, names, notes,
# semi-colon-joined lists) -- a single TEXT type per column keeps the DDL
# simple and avoids truncation surprises on long call-chain/notes values.
_DDL_COLUMNS = ", ".join(f'"{c}" TEXT' for c in COMBINED_COLUMNS)

_GRANT_TEMPLATE = """
GRANT SELECT ON {schema}.{table} TO {select_grantee};
GRANT TRUNCATE ON {schema}.{table} TO {truncate_grantee};
ALTER TABLE {schema}.{table} OWNER TO {new_owner};
"""


def _get_connection(settings: Settings) -> Tuple[object, str, str]:
    """Returns (dbapi_connection, schema, mode) where mode is 'airflow' or 'local'."""
    try:
        from airflow.hooks.postgres_hook import PostgresHook
        from airflow.models import Variable
        hook = PostgresHook(postgres_conn_id=settings.postgres_conn_id_var)
        conn = hook.get_conn()
        schema = Variable.get(settings.greenplum_schema_var, default_var=settings.greenplum_schema)
        return conn, schema, "airflow"
    except Exception:
        pass

    import psycopg2
    if not settings.greenplum_password:
        settings.resolve_greenplum_password(interactive=True)
    conn = psycopg2.connect(
        host=settings.greenplum_host, port=settings.greenplum_port,
        dbname=settings.greenplum_db, user=settings.greenplum_user,
        password=settings.greenplum_password,
    )
    return conn, settings.greenplum_schema, "local"


def _quoted_ident(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def build_ddl(schema: str, table: str) -> List[str]:
    """Returns the list of DDL/DML statements this export runs, in order --
    exposed separately so it can be unit-tested/inspected without a live
    database connection."""
    fq = f"{_quoted_ident(schema)}.{_quoted_ident(table)}"
    return [
        f"DROP TABLE IF EXISTS {fq};",
        f"CREATE TABLE {fq} ({_DDL_COLUMNS});",
    ]


def build_grant_statements(schema: str, table: str, settings: Settings) -> str:
    fq_schema, fq_table = _quoted_ident(schema), _quoted_ident(table)
    return _GRANT_TEMPLATE.format(
        schema=fq_schema, table=fq_table,
        select_grantee=settings.greenplum_grant_select_to,
        truncate_grantee=settings.greenplum_grant_truncate_to,
        new_owner=settings.greenplum_new_owner,
    )


def _rows_to_csv_buffer(rows: List[dict], columns: List[str]) -> io.StringIO:
    buf = io.StringIO()
    writer = csv.writer(buf, quoting=csv.QUOTE_ALL, lineterminator="\n")
    for r in rows:
        writer.writerow([r.get(c, "") or "" for c in columns])
    buf.seek(0)
    return buf


def _bulk_insert(cur, fq_table: str, columns: List[str], rows: List[dict]) -> str:
    """Loads `rows` into `fq_table` as fast as the available driver allows.
    Tried in order (each is a strict speed downgrade from the last):

      1. COPY ... FROM STDIN -- ONE network round-trip for the entire
         table, regardless of row count. This is what made the export slow
         before: plain psycopg2 `executemany()` issues one round-trip
         PER ROW, so 10,000+ rows meant 10,000+ round-trips.
      2. psycopg2.extras.execute_values -- true multi-row INSERT batched
         into pages (still far fewer round-trips than executemany), used
         only if COPY isn't available on this cursor/connection.
      3. Plain executemany/execute loop -- last resort, only if neither of
         the above is available (e.g. a non-psycopg2 DB-API driver).

    Returns which method was actually used, for the summary dict.
    """
    col_list = ", ".join(_quoted_ident(c) for c in columns)

    if hasattr(cur, "copy_expert"):
        try:
            buf = _rows_to_csv_buffer(rows, columns)
            copy_sql = f"COPY {fq_table} ({col_list}) FROM STDIN WITH (FORMAT csv)"
            cur.copy_expert(copy_sql, buf)
            return "copy"
        except Exception:
            pass  # fall through to the next method below

    try:
        from psycopg2.extras import execute_values
        insert_sql = f"INSERT INTO {fq_table} ({col_list}) VALUES %s"
        values = [[r.get(c, "") for c in columns] for r in rows]
        execute_values(cur, insert_sql, values, page_size=2000)
        return "execute_values"
    except Exception:
        pass  # fall through to the last-resort method below

    placeholders = ", ".join(["%s"] * len(columns))
    insert_sql = f"INSERT INTO {fq_table} ({col_list}) VALUES ({placeholders})"
    values = [[r.get(c, "") for c in columns] for r in rows]
    try:
        cur.executemany(insert_sql, values)
    except AttributeError:
        for row in values:
            cur.execute(insert_sql, row)
    return "executemany"


def export_to_greenplum(hierarchy: Hierarchy, settings: Optional[Settings] = None) -> dict:
    """Drops/recreates {schema}.{table} (defaults to core_nlg.nlg_hierarchy
    style config, see Settings), bulk-loads the combined hierarchy+product+
    yaml row-set via COPY (falling back to slower methods only if COPY
    isn't available), and applies the standing GRANT/ALTER statements.
    Returns a small summary dict."""
    settings = settings or hierarchy.settings
    rows = combined_rows(hierarchy)

    conn, schema, mode = _get_connection(settings)
    table = settings.nlg_hierarchy_table
    try:
        cur = conn.cursor()
        for stmt in build_ddl(schema, table):
            cur.execute(stmt)

        fq = f"{_quoted_ident(schema)}.{_quoted_ident(table)}"
        load_method = _bulk_insert(cur, fq, COMBINED_COLUMNS, rows)

        for stmt in build_grant_statements(schema, table, settings).strip().split(";"):
            stmt = stmt.strip()
            if stmt:
                cur.execute(stmt + ";")

        conn.commit()
    finally:
        try:
            conn.close()
        except Exception:
            pass

    return {"schema": schema, "table": table, "rows_written": len(rows),
            "connection_mode": mode, "load_method": load_method}
