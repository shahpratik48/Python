"""
nlg_dag_agent (minimal subset, bundled for nlg_query_tracer / Project 2)
=========================================================================
This is a TRIMMED copy of nlg_dag_agent containing only the modules
Project 2 (nlg_query_tracer) actually needs: source loading + AST-based
hierarchy extraction (build_hierarchy / Hierarchy / Settings / llm_client).

It deliberately does NOT include xlsx_export.py, greenplum_export.py,
report_rows.py, or __main__.py -- those are Project 1-only output/CLI
features nlg_query_tracer never imports. If you also want Project 1's full
functionality (the xlsx workbook, Greenplum export, CLI), use the
complete nlg_dag_agent package from Project 1 instead of this subset --
the two are compatible (this is a strict subset, not a fork).
"""

from .config import Settings
from .pipeline import build_hierarchy, run_impact_analysis, ask

__all__ = ["Settings", "build_hierarchy", "run_impact_analysis", "ask"]
