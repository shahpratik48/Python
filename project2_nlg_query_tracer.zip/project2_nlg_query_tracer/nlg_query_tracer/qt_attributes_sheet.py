"""
The "Query Attributes" worksheet.

One row per attribute the main select list of each insight_type's narrative
query reads, with the table it comes from, the output alias and the exact
expression it appears in.
"""
from __future__ import annotations

import os
from typing import List, Optional, Sequence

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from qt_attributes import AttributeRow

SHEET_NAME = "Query Attributes"

# The header order follows the DATA in the agreed example -- attribute then
# table -- since every sample row is written that way.
HEADERS = ["target_type", "insight_type", "attribute", "table", "alias", "logic"]
WIDTHS = [30, 46, 34, 48, 32, 110]

C_HEAD, C_HEAD_TX, C_ALT, C_BORDER = "305496", "FFFFFF", "FAFBFC", "E6E8EB"
_thin = Side(style="thin", color=C_BORDER)
BORDER = Border(left=_thin, right=_thin, top=_thin, bottom=_thin)


def write_attributes_sheet(rows: Sequence[AttributeRow], path: str,
                           sheet_name: str = SHEET_NAME) -> str:
    """Adds (or replaces) the attribute sheet in an existing workbook.

    Appends to the workbook the tracer already produced rather than writing a
    separate file, so everything about a run stays in one place.
    """
    if os.path.exists(path):
        wb = load_workbook(path)
        if sheet_name in wb.sheetnames:
            del wb[sheet_name]
    else:
        wb = Workbook()
        wb.remove(wb.active)
    ws = wb.create_sheet(sheet_name)

    for i, (h, w) in enumerate(zip(HEADERS, WIDTHS), start=1):
        c = ws.cell(row=1, column=i, value=h)
        c.font = Font(name="Calibri", size=10, bold=True, color=C_HEAD_TX)
        c.fill = PatternFill("solid", start_color=C_HEAD, end_color=C_HEAD)
        c.alignment = Alignment(vertical="center", horizontal="center", wrap_text=True)
        c.border = BORDER
        ws.column_dimensions[get_column_letter(i)].width = w

    alt = PatternFill("solid", start_color=C_ALT, end_color=C_ALT)
    for r_i, r in enumerate(rows):
        # a literal has no table; leaving the cell empty would read as "not
        # yet worked out" rather than "there is none"
        values = [r.target_type, r.insight_type, r.attribute,
                  r.table if r.table else "NULL", r.alias, r.logic]
        for c_i, v in enumerate(values, start=1):
            c = ws.cell(row=r_i + 2, column=c_i, value=v)
            c.font = Font(name="Calibri", size=10)
            c.alignment = Alignment(vertical="top", wrap_text=True)
            c.border = BORDER
            if r_i % 2:
                c.fill = alt

    if rows:
        ws.auto_filter.ref = "A1:%s%d" % (get_column_letter(len(HEADERS)), len(rows) + 1)
    # No frozen panes: the sheet is one long table and freezing here has
    # caused scrolling complaints before.
    wb.save(path)
    return path


def collect_attributes(traced, strip_schema: bool = True) -> List[AttributeRow]:
    """Builds the rows for every traced insight_type.

    `traced` is any iterable of objects or dicts carrying `target_type`,
    `insight_type` and `sql`, so it fits whatever shape the tracer returns.
    """
    from qt_attributes import extract_attributes
    out: List[AttributeRow] = []
    for t in traced:
        get = (lambda k: t.get(k)) if isinstance(t, dict) else (lambda k: getattr(t, k, None))
        sql = get("sql") or get("query") or get("final_sql")
        if not sql:
            continue
        out.extend(extract_attributes(sql, str(get("target_type") or ""),
                                      str(get("insight_type") or ""),
                                      strip_schema=strip_schema))
    return out
