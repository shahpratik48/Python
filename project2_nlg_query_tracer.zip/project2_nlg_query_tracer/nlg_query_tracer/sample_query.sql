select a.insight_type, a.target_type, a.target_key, a.metric_name, a.metric_type, a.metric_val, 'acc_i_asset_key' as key_name, b.acc_mhh_n::text, '' as id_name, '' as target_entity_id, b.acc_mhh_n::text, (b.profile_date::date - interval '3' day) as profile_date, b.acc_i, b.pw_scty_i, b.svg_elg_mhh_acc_lst, b.svg_elg_mhh_scty_assets_curr, b.pro_long_desc1_t, b.pro_long_desc2_t, b.mmf_seven_day_yield, b.saving_standard_rate, b.saving_promo_rate, initcap(b.lead_account_title) as lead_acc_title, CASE WHEN array_length(string_to_array(b.svg_elg_mhh_acc_lst, ';'), 1) > 1  THEN b.acc_n ELSE 0 END AS has_multi_accounts
                        from ( (select distinct on (target_key) insight_type, target_type, target_key, metric_name, metric_type, metric_val 
                                   from core_ikg.si_odm_insights_active 
                                   where target_type = 'account_holding_mmf' and insight_type = 'si_mmf_to_core_savings_promo_rate')
                              ) a 
                        inner join core_ikg.account_mmf_to_core_svngs_profile_curr_ikg  b on a.target_key = b.acc_i_asset_key
                        WHERE b.acc_mhh_n is not null
