"""
Traces the final SQL query for each insight_type using the SAME logic nlg
itself uses -- not an LLM guess. The real system builds this exact query,
executes it, generates a narrative from the result, and stores only the
narrative (per Greenplum) -- the query itself is never persisted anywhere.
This module recovers it by actually running the real query-building code
(see query_capture.py) with a stub DB connector that intercepts and
records every SQL statement instead of hitting a real database.

An LLM-based reconstruction (reads the source + config, asks an LLM to
infer the query) is kept as a FALLBACK only, used solely when real
execution can't run at all (e.g. this environment is missing a required
third-party package that auto-stubbing couldn't paper over, or the
function needs a parameter this harness doesn't know how to supply). Any
row produced this way is clearly marked so it's never confused with a
row produced by actually running the real code.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

import logging

from nlg_dag_agent import llm_client
from nlg_dag_agent.config import Settings
from nlg_dag_agent.pipeline import Hierarchy

from .context_gatherer import (gather_context, list_insight_types_for_target_type, list_all_target_types,
                                 QueryContext, DEFAULT_ODM_ENV)
from .query_capture import capture_queries_for_insight_type, CaptureResult

LLM_FALLBACK_SYSTEM_PROMPT = """You are a senior Python/SQL engineer. Real code execution to recover this \
query failed in this environment (see the error provided). As a FALLBACK ONLY, read the provided \
config values and Python source of the query-building function(s) and infer what the final SQL query \
text would be, following the function's branching logic as literally as possible.

Reply with STRICT JSON only, no markdown fences:
{
  "query": "<your best-effort reconstruction>",
  "confidence": "low|medium|high",
  "notes": "<key assumptions/substitutions, and what you're unsure about>"
}"""


@dataclass
class QueryResult:
    target_type: str
    insight_type: str
    query: str = ""
    resolution_method: str = "none"     # "code_execution" | "llm_fallback" | "none"
    variant_function_used: Optional[str] = None
    supporting_queries: List[str] = field(default_factory=list)
    confidence: str = "n/a"
    notes: str = ""
    source_files_used: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    def to_dict(self):
        return self.__dict__


def _llm_fallback(hierarchy: Hierarchy, ctx: QueryContext, capture: CaptureResult,
                    settings: Settings) -> Optional[QueryResult]:
    if not settings.llm_enabled:
        return None
    config_payload = {
        "target_type": ctx.target_type, "insight_type": ctx.insight_type,
        "insights_target_user_type": ctx.insights_target_user_type,
        "nlg_db_tables": ctx.nlg_db_tables, "col_name_mapping": ctx.col_name_mapping,
        "ref_table_columns_to_retrieve": ctx.ref_table_columns_to_retrieve,
        "fields_not_null": ctx.fields_not_null, "variant_function": ctx.variant_function,
        "real_execution_error": capture.execution_error,
    }
    parts = [f"CONFIG:\n{json.dumps(config_payload, indent=2, default=str)}\n"]
    for path, content in ctx.source_files.items():
        if path.endswith(".py"):
            parts.append(f"\n--- SOURCE FILE: {path} ---\n{content}")
    user_prompt = "\n".join(parts)
    parsed = llm_client.call_llm_json(settings, LLM_FALLBACK_SYSTEM_PROMPT, user_prompt)
    if not parsed:
        return None
    return QueryResult(
        target_type=ctx.target_type, insight_type=ctx.insight_type,
        query=parsed.get("query", ""), resolution_method="llm_fallback",
        variant_function_used=ctx.variant_function, confidence=parsed.get("confidence", "n/a"),
        notes=f"[LLM FALLBACK -- real execution failed: {capture.execution_error}] {parsed.get('notes', '')}",
        source_files_used=sorted(ctx.source_files.keys()), warnings=list(ctx.warnings),
    )


LOG = logging.getLogger("tracer")


def _qualify(sql: str, settings) -> str:
    """Gives bare columns their table alias, using Greenplum column metadata.

    Applied here so every consumer -- the query sheet, the attribute sheet,
    anyone copying the SQL out -- sees the same qualified form. Failure is
    never fatal: the original query is returned unchanged, because a wrong
    alias would be worse than no alias.
    """
    if not sql or not getattr(settings, "qualify_aliases", True):
        return sql
    try:
        try:
            from .qt_alias import qualify
            from .qt_attributes import from_alias_map
        except ImportError:                                    # loose modules
            from qt_alias import qualify                       # type: ignore
            from qt_attributes import from_alias_map           # type: ignore
        amap = from_alias_map(sql)
        if not amap:
            return sql
        conn = None
        getter = getattr(settings, "greenplum_connection", None)
        if callable(getter):
            conn = getter()
        return qualify(sql, amap, conn)
    except Exception as e:
        LOG.warning("Alias qualification skipped (%s); query left as captured.", e)
        return sql


def trace_insight_type(hierarchy: Hierarchy, target_type: str, insight_type: str,
                        settings: Optional[Settings] = None, is_prospect_run: bool = False,
                        odm_env: str = DEFAULT_ODM_ENV, allow_llm_fallback: bool = True) -> QueryResult:
    settings = settings or hierarchy.settings
    capture = capture_queries_for_insight_type(hierarchy, target_type, insight_type,
                                                 is_prospect_run=is_prospect_run)

    if capture.primary_query:
        return QueryResult(
            target_type=target_type, insight_type=insight_type,
            query=_qualify(capture.primary_query, settings),
            resolution_method="code_execution", variant_function_used=capture.variant_function,
            supporting_queries=capture.supporting_queries, confidence="high",
            notes="Captured by actually running the real fetch_data_with_insights_* code with a stub DB.",
            warnings=capture.warnings,
        )

    # Real execution didn't produce a usable query -- try the LLM fallback,
    # if configured (gather_context is re-run once more, cheaply, just to
    # get the source/config payload for the prompt; no execution involved).
    ctx = gather_context(hierarchy, target_type, insight_type, is_prospect_run=is_prospect_run, odm_env=odm_env)
    if allow_llm_fallback:
        fallback = _llm_fallback(hierarchy, ctx, capture, settings)
        if fallback:
            return fallback

    return QueryResult(
        target_type=target_type, insight_type=insight_type, resolution_method="none",
        variant_function_used=capture.variant_function,
        notes=(f"Real execution failed ({capture.execution_error}) and no LLM fallback was available/"
               f"configured. Fix the underlying issue (see notes) and retry, or set an LLM provider "
               f"for a best-effort fallback."),
        source_files_used=sorted(ctx.source_files.keys()), warnings=capture.warnings + ctx.warnings,
    )


def trace_target_type(hierarchy: Hierarchy, target_type: str, settings: Optional[Settings] = None,
                       is_prospect_run: bool = False, odm_env: str = DEFAULT_ODM_ENV,
                       insight_types: Optional[List[str]] = None,
                       allow_llm_fallback: bool = True) -> List[QueryResult]:
    """Traces every insight_type under rules/<target_type>/*.yml (or a
    caller-supplied subset)."""
    its = insight_types or list_insight_types_for_target_type(hierarchy, target_type)
    return [trace_insight_type(hierarchy, target_type, it, settings=settings, is_prospect_run=is_prospect_run,
                                 odm_env=odm_env, allow_llm_fallback=allow_llm_fallback)
            for it in its]


def trace_many_target_types(hierarchy: Hierarchy, target_types: List[str],
                             settings: Optional[Settings] = None, **kwargs) -> List[QueryResult]:
    out: List[QueryResult] = []
    for tt in target_types:
        out.extend(trace_target_type(hierarchy, tt, settings=settings, **kwargs))
    return out


def trace_all_target_types(hierarchy: Hierarchy, settings: Optional[Settings] = None,
                            is_prospect_run: bool = False, odm_env: str = DEFAULT_ODM_ENV,
                            allow_llm_fallback: bool = True,
                            progress_callback: Optional[callable] = None) -> List[QueryResult]:
    """Traces EVERY insight_type under EVERY target_type found in rules/ --
    i.e. every .yml file anywhere under rules/<target_type>/ (at any
    nesting depth), covering the full repo, not a hand-picked subset.

    `progress_callback(target_type, insight_type, index, total)` is called
    after each insight_type is traced, if provided -- useful for a progress
    bar/log line when tracing hundreds of insight_types."""
    target_types = list_all_target_types(hierarchy)
    plan: List[Tuple[str, str]] = []
    for tt in target_types:
        for it in list_insight_types_for_target_type(hierarchy, tt):
            plan.append((tt, it))

    out: List[QueryResult] = []
    for i, (tt, it) in enumerate(plan, start=1):
        result = trace_insight_type(hierarchy, tt, it, settings=settings, is_prospect_run=is_prospect_run,
                                     odm_env=odm_env, allow_llm_fallback=allow_llm_fallback)
        out.append(result)
        if progress_callback:
            progress_callback(tt, it, i, len(plan))
    return out
