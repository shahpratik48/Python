"""
The attribute inventory: one row per column that the MAIN select list reads.

Deliberately only the main select list -- not sub-queries, WHERE, JOIN or
HAVING. Those columns are how the result is *found*; the select list is what
the narrative actually *uses*, which is the question this sheet answers.

One row per (attribute, table, alias, logic). The same attribute appears
again when it is used under a different alias or a different expression,
because those are genuinely different usages -- and a CASE expression that
reads two columns produces two rows sharing one alias and one logic string.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Dict, List, Optional

try:
    from .qt_sqlscan import column_refs, find_kw, main_from_clause, main_select_list, output_alias, split_top_level, strip_comments
except ImportError:              # running as loose modules
    from qt_sqlscan import column_refs, find_kw, main_from_clause, main_select_list, output_alias, split_top_level, strip_comments  # type: ignore


@dataclass
class AttributeRow:
    target_type: str
    insight_type: str
    attribute: str            # the column, or the literal where there is none
    table: Optional[str]      # None for a literal or an unresolved alias
    alias: str                # the output name
    logic: str                # the select-list item, verbatim


_ALIAS_TAIL = re.compile(r"^\s*(?:as\s+)?([A-Za-z_][\w$]*)\s*$", re.I)


def from_alias_map(sql: str) -> Dict[str, str]:
    """`alias -> table` for the main FROM clause.

    A derived table resolves to the table INSIDE it: the select list refers
    to `a.insight_type`, and reporting the table as `a` or as `(subquery)`
    would tell a reader nothing. The first real table in the sub-query is
    used, which is what these generated queries always have.
    """
    clause = main_from_clause(sql)
    if not clause:
        return {}

    out: Dict[str, str] = {}
    for part in _split_from_parts(clause):
        part = part.strip()
        if not part:
            continue
        # Drop the join condition -- but only an ON at depth 0. A derived
        # table containing `distinct on (...)` would otherwise be truncated
        # at that inner ON, losing the alias entirely.
        on = find_kw(part, "on", 0, 0)
        if on >= 0:
            part = part[:on].strip()
        if part.startswith("("):
            depth, end = 0, len(part)
            for i, c in enumerate(part):
                if c == "(":
                    depth += 1
                elif c == ")":
                    depth -= 1
                    if depth == 0:
                        end = i + 1
                        break
            inner, tail = part[:end], part[end:]
            m = _ALIAS_TAIL.match(tail)
            alias = m.group(1) if m else None
            table = _first_table(inner)
            if alias and table:
                out[alias] = table
        else:
            toks = [t for t in re.split(r"\s+", part) if t]
            if not toks:
                continue
            table = toks[0]
            alias = None
            if len(toks) >= 2 and toks[1].lower() == "as" and len(toks) >= 3:
                alias = toks[2]
            elif len(toks) >= 2 and toks[1].lower() not in ("on",):
                alias = toks[1]
            key = alias or table.split(".")[-1]
            out[key] = table
    return out


def _split_from_parts(clause: str) -> List[str]:
    """Splits a FROM clause on commas and JOIN keywords at depth 0."""
    marked = clause
    for kw in ("inner join", "left outer join", "right outer join", "full outer join",
               "left join", "right join", "full join", "cross join", "join"):
        while True:
            i = find_kw(marked, kw.split()[0], 0, 0) if " " not in kw else -1
            break
    parts, buf, depth, i, n = [], [], 0, 0, len(clause)
    lo = clause.lower()
    while i < n:
        c = clause[i]
        if c == "'":
            j = clause.find("'", i + 1)
            j = n if j < 0 else j
            buf.append(clause[i:j + 1])
            i = j + 1
            continue
        if c == "(":
            depth += 1
        elif c == ")":
            depth -= 1
        if depth == 0:
            if c == ",":
                parts.append("".join(buf))
                buf = []
                i += 1
                continue
            m = re.match(r"(?:inner\s+|left\s+|right\s+|full\s+|cross\s+|outer\s+)*join\b",
                         lo[i:])
            if m and (i == 0 or not (clause[i - 1].isalnum() or clause[i - 1] == "_")):
                parts.append("".join(buf))
                buf = []
                i += m.end()
                continue
        buf.append(c)
        i += 1
    parts.append("".join(buf))
    return [p for p in parts if p.strip()]


def _first_table(text: str) -> Optional[str]:
    """The first table named in a FROM inside `text`, at any depth."""
    clean = strip_comments(text)
    lo = clean.lower()
    for m in re.finditer(r"\bfrom\b", lo):
        tail = clean[m.end():].strip()
        m2 = re.match(r"([A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)?)", tail)
        if m2:
            return m2.group(1)
    return None


def extract_attributes(sql: str, target_type: str, insight_type: str,
                       strip_schema: bool = True) -> List[AttributeRow]:
    """One AttributeRow per column read by the main select list."""
    sel = main_select_list(sql)
    if not sel:
        return []
    amap = from_alias_map(sql)

    def table_for(alias: Optional[str]) -> Optional[str]:
        if alias is None:
            # unqualified: only safe when the query has exactly one source
            if len(amap) == 1:
                t = list(amap.values())[0]
                return t.split(".")[-1] if strip_schema else t
            return None
        t = amap.get(alias)
        if t is None:
            return None
        return t.split(".")[-1] if strip_schema else t

    rows: List[AttributeRow] = []
    seen = set()
    for item in split_top_level(sel):
        logic = " ".join(item.split())
        alias = output_alias(item) or ""
        cols = column_refs(item)

        if not cols:
            # a literal or constant -- there is no column, so the expression
            # itself is the attribute and there is no table
            lit = item
            a = find_kw(item, "as", 0, 0)
            if a >= 0:
                lit = item[:a]
            lit = " ".join(lit.split()).strip()
            key = (lit, None, alias, logic)
            if key not in seen:
                seen.add(key)
                rows.append(AttributeRow(target_type, insight_type, lit, None, alias, logic))
            continue

        for tbl_alias, col, _pos in cols:
            table = table_for(tbl_alias)
            key = (col, table, alias, logic)
            if key in seen:
                continue
            seen.add(key)
            rows.append(AttributeRow(target_type, insight_type, col, table, alias, logic))
    return rows
