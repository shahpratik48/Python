"""
Exports a list of QueryResult (see tracer.py) to an .xlsx workbook: one row
per insight_type, columns target_type / insight_type / narrative_query /
plus supporting detail (how it was resolved, supporting queries, source
files, warnings).
"""
from __future__ import annotations

import os
from typing import List

import logging

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

from .tracer import QueryResult

HEADER_FONT = Font(name="Arial", bold=True, color="FFFFFF")
HEADER_FILL = PatternFill(start_color="305496", end_color="305496", fill_type="solid")
BODY_FONT = Font(name="Arial", size=10)
CODE_FONT = Font(name="Consolas", size=9)
WRAP = Alignment(vertical="top", wrap_text=True)


ATTR_SHEET = "query_attributes"
# Header order follows the DATA in the agreed example -- attribute then table.
ATTR_HEADERS = ["target_type", "insight_type", "attribute", "table", "alias", "logic"]


LOG = logging.getLogger("tracer.xlsx")


def _style_sheet(ws, col_widths):
    ws.freeze_panes = "A2"
    for cell in ws[1]:
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(vertical="center", horizontal="center", wrap_text=True)
    ws.auto_filter.ref = ws.dimensions
    for i, w in enumerate(col_widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = WRAP
            cell.font = BODY_FONT


def export_xlsx(results: List[QueryResult], output_path: str) -> str:
    wb = Workbook()
    ws = wb.active
    ws.title = "narrative_queries"
    headers = ["target_type", "insight_type", "narrative_query", "resolution_method",
               "variant_function_used", "confidence", "supporting_queries", "notes",
               "source_files_used", "warnings"]
    ws.append(headers)
    for r in results:
        ws.append([
            r.target_type, r.insight_type, r.query, r.resolution_method,
            r.variant_function_used or "", r.confidence,
            "\n---\n".join(r.supporting_queries), r.notes,
            "; ".join(r.source_files_used), "; ".join(r.warnings),
        ])
    widths = [22, 40, 90, 18, 34, 12, 50, 50, 60, 40]
    _style_sheet(ws, widths)
    for row in ws.iter_rows(min_row=2, min_col=3, max_col=3):
        for cell in row:
            cell.font = CODE_FONT
            cell.alignment = WRAP
    for row in ws.iter_rows(min_row=2, min_col=7, max_col=7):
        for cell in row:
            cell.font = CODE_FONT
            cell.alignment = WRAP

    # ---- query_attributes: what each narrative query actually reads ----
    # Built here rather than in a separate pass so the sheet can never fall
    # out of step with the queries in the sheet above it.
    try:
        from .qt_attributes import extract_attributes
    except ImportError:                                   # running as loose modules
        from qt_attributes import extract_attributes      # type: ignore

    attr_ws = wb.create_sheet(ATTR_SHEET)
    attr_ws.append(ATTR_HEADERS)
    n_attr, n_failed = 0, 0
    for r in results:
        if not (r.query or "").strip():
            continue
        try:
            rows = extract_attributes(r.query, r.target_type, r.insight_type)
        except Exception as e:
            # One unparseable query must not cost the whole sheet; it is
            # recorded as a row so the gap is visible rather than silent.
            n_failed += 1
            attr_ws.append([r.target_type, r.insight_type, "(could not parse)", "NULL", "",
                            "%s: %s" % (type(e).__name__, e)])
            continue
        for a in rows:
            attr_ws.append([a.target_type, a.insight_type, a.attribute,
                            a.table if a.table else "NULL", a.alias, a.logic])
            n_attr += 1
    _style_sheet(attr_ws, [22, 40, 34, 48, 32, 110])
    for row in attr_ws.iter_rows(min_row=2, min_col=6, max_col=6):
        for cell in row:
            cell.font = CODE_FONT
            cell.alignment = WRAP
    if attr_ws.max_row > 1:
        attr_ws.auto_filter.ref = "A1:F%d" % attr_ws.max_row
    LOG.info("query_attributes: %d row(s) across %d insight_type(s)%s",
             n_attr, sum(1 for r in results if (r.query or "").strip()),
             "; %d query/queries could not be parsed" % n_failed if n_failed else "")

    legend = wb.create_sheet("README", 0)
    legend.column_dimensions["A"].width = 26
    legend.column_dimensions["B"].width = 110
    rows = [
        ("Workbook", "One row per insight_type: the final SQL query used to fetch narrative-generation "
                      "input data for that insight_type. This query is NOT stored anywhere by the real "
                      "system (it's built, executed, and discarded -- only the resulting narrative is "
                      "saved to Greenplum) -- this workbook recovers it by actually running the real "
                      "query-building code (fetch_data_with_insights_for_cl/_for_fl/_for_pr) with a stub "
                      "database connector that intercepts and records every SQL statement instead of "
                      "hitting a real database. See resolution_method to confirm how each row was produced."),
        ("narrative_query", "The captured SQL, built by the real code with real resolved config values "
                             "(table/schema names from config/nlg_db_tables.ini, column mapping from "
                             "config/input_data_config/<target_type>.yml, etc.) -- not an approximation."),
        ("resolution_method", "'code_execution' = the real query-building function was actually run and "
                               "this is its real output (high confidence). 'llm_fallback' = real execution "
                               "failed in this environment (see notes) and an LLM produced a best-effort "
                               "reconstruction instead -- verify before trusting. 'none' = both failed."),
        ("variant_function_used", "Which fetch_data_with_insights_* function was actually run, chosen the "
                                   "same way the real code chooses it (from insights_target_user_type in "
                                   "input_data_config)."),
        ("supporting_queries", "Other SQL the real code issued along the way (e.g. dummy-household "
                                "existence checks, ref-table lookups) -- not the main narrative-data "
                                "query, but captured for transparency/debugging."),
        ("confidence", "'high' for code_execution rows (it's the real code). For llm_fallback rows, the "
                        "LLM's own low/medium/high self-assessment -- always verify those manually."),
        ("warnings", "Non-fatal issues from context-gathering or execution -- e.g. a missing config file, "
                      "or third-party modules that had to be auto-stubbed just to allow the import (see "
                      "README in query_capture.py for why that's safe for this specific use)."),
    ]
    for r in rows:
        legend.append(r)
    for row in legend.iter_rows():
        for cell in row:
            cell.font = BODY_FONT
            cell.alignment = WRAP
    legend["A1"].font = Font(name="Arial", bold=True, size=13)
    for i in range(2, len(rows) + 1):
        legend.cell(row=i, column=1).font = Font(name="Arial", bold=True)

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    wb.save(output_path)
    return output_path
