"""
Runs the SAME query-building code nlg actually uses (not an LLM
approximation) to produce the final SQL query for a given
(target_type, insight_type) -- and captures it, since the real system never
stores it: it builds the query, executes it, generates + stores the
narrative text, and discards the query.

How: write nlg-src to a real temp directory under the `nlg.src.*` package
namespace the code itself expects (matches its own internal
`from nlg.src.utils.X import Y` imports), import the actual
`fetch_data_with_insights_for_cl` / `_for_fl` / `_for_pr` function for this
insight_type's `insights_target_user_type`, and call it with a
`CapturingDatabase` stub standing in for the real `Database` class --
same class (real subclass of the real `nlg.src.utils.db_utils.Database`),
except every `execute_query_with_records_return` / `execute_sql` /
`get_table_columns` call is intercepted: the SQL text is recorded, and an
empty/falsy result is returned instead of touching a real database. That's
enough for the function to run its real branching logic to completion (or
to the point it can't proceed further without real data) while we capture
every SQL statement it actually built along the way.

Requires the same third-party dependencies nlg-src itself needs at import
time (whatever `utils_narratives.py` and its own imports pull in -- e.g.
`tracery`, `pluralizer`, and, transitively, `apache-airflow` in some
versions of this codebase). That's not a new requirement: it's the same
dependency set already installed wherever this DAG runs today. Run this
from that same environment (or a venv mirroring it), not a bare sandbox.
"""
from __future__ import annotations

import importlib
import inspect
import logging
import os
import shutil
import sys
import tempfile
from dataclasses import dataclass, field
from typing import Dict, List, Optional
from unittest.mock import MagicMock

from nlg_dag_agent.pipeline import Hierarchy

from .context_gatherer import gather_context, QueryContext

_KNOWN_SHIM_PATHS: List[str] = []   # every shim root we've ever added to sys.path, oldest first


def _purge_stale_nlg_modules_and_paths(new_shim_root: str):
    """Every Hierarchy uses the SAME `nlg.src.*` dotted import namespace,
    regardless of which branch/commit its source actually came from. If an
    earlier `hierarchy` (e.g. built before a new commit landed on
    `develop`) already triggered a real import of `nlg.src.utils.X` in
    this process, Python's `sys.modules` cache would otherwise silently
    keep returning THAT old module forever -- even after rebuilding
    `hierarchy` against fresh GitLab content -- because `import` always
    checks `sys.modules` before ever consulting `sys.path` again. That
    would defeat the entire point of "always reflects whatever's on
    develop right now". So: every time a genuinely NEW shim is written
    (i.e. this hierarchy didn't already have one), purge any previously
    imported `nlg`/`nlg.*` modules AND remove every older shim path from
    sys.path, leaving only the newest one -- guaranteeing the next import
    reads fresh content, not a stale cached module or a stale path."""
    for mod_name in list(sys.modules):
        if mod_name == "nlg" or mod_name.startswith("nlg."):
            del sys.modules[mod_name]
    for old_path in _KNOWN_SHIM_PATHS:
        while old_path in sys.path:
            sys.path.remove(old_path)
    _KNOWN_SHIM_PATHS.append(new_shim_root)


def _prepare_import_shim(hierarchy: Hierarchy) -> str:
    """Writes hierarchy.src_index.raw_files to disk under <tmp>/nlg/src/...
    (matching the `nlg.src.*` namespace nlg-src's own internal imports
    expect), and returns the temp root to add to sys.path.

    Cached as an attribute ON the hierarchy object itself (not a global
    dict keyed by id(hierarchy)) so the cache's lifetime is tied exactly
    to that object -- repeated calls against the SAME hierarchy (e.g.
    tracing hundreds of insight_types in one run) reuse it and don't
    re-write the tree every time, while a genuinely NEW hierarchy (rebuilt
    to pick up new commits on `develop`) always gets a fresh shim and a
    clean module cache (see _purge_stale_nlg_modules_and_paths above)."""
    cached = getattr(hierarchy, "_nlg_query_tracer_shim_root", None)
    if cached and os.path.isdir(cached):
        return cached

    tmp_root = tempfile.mkdtemp(prefix="nlg_query_tracer_shim_")
    dest_src = os.path.join(tmp_root, "nlg", "src")
    for rel_path, content in hierarchy.src_index.raw_files.items():
        if not rel_path.endswith(".py"):
            continue
        full = os.path.join(dest_src, rel_path)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with open(full, "w", encoding="utf-8") as fh:
            fh.write(content)

    _purge_stale_nlg_modules_and_paths(tmp_root)
    try:
        setattr(hierarchy, "_nlg_query_tracer_shim_root", tmp_root)
    except Exception:
        pass  # if Hierarchy ever becomes a slotted/frozen type, caching just degrades to "always fresh"
    return tmp_root


def _import_with_auto_stub(module_name: str, stubbed: List[str], max_attempts: int = 25):
    """Imports `module_name`, auto-stubbing (with a permissive MagicMock)
    any third-party module it can't find, and retrying. This is only safe
    because the functions we actually CALL (fetch_data_with_insights_*)
    never touch those modules at runtime -- they're pulled in at import
    time by OTHER functions living in the same file. Every stubbed name is
    recorded in `stubbed` for transparency; a module already importable in
    this environment is always used for real, never stubbed."""
    for _ in range(max_attempts):
        try:
            return importlib.import_module(module_name)
        except ModuleNotFoundError as e:
            missing = e.name
            if not missing or missing in sys.modules:
                raise
            sys.modules[missing] = MagicMock(__name__=missing)
            stubbed.append(missing)
    raise ImportError(f"Could not import {module_name} after {max_attempts} auto-stub attempts")


class _NullLogger:
    """Stand-in for the real logger the Database class expects -- every
    call is a no-op, nothing is printed/logged."""
    def __getattr__(self, _name):
        return lambda *a, **k: None


@dataclass
class CaptureResult:
    target_type: str
    insight_type: str
    variant_function: Optional[str] = None
    primary_query: str = ""
    supporting_queries: List[str] = field(default_factory=list)
    all_captured: List[dict] = field(default_factory=list)   # [{"seq", "kind", "sql"}]
    success: bool = False
    execution_error: Optional[str] = None
    warnings: List[str] = field(default_factory=list)


def _make_capturing_database_class(Database):
    """Builds a subclass of the REAL Database class (imported from the
    target codebase) that intercepts every DB call instead of connecting
    to anything real."""

    class CapturingDatabase(Database):
        def __init__(self):
            self.logger = _NullLogger()
            self.conn = None
            self.captured: List[dict] = []
            self._seq = 0

        def _capture(self, sql: str, kind: str):
            self._seq += 1
            self.captured.append({"seq": self._seq, "kind": kind, "sql": sql})

        def get_conn(self):
            raise RuntimeError("CapturingDatabase.get_conn() should never be called -- "
                                "all query methods are overridden to intercept before a real connection is made.")

        def execute_query_with_records_return(self, sql, params=None):
            self._capture(sql, "select")
            return []   # empty result -> real code takes its "no data found" branch, gracefully

        def execute_sql(self, sql, params=None):
            self._capture(sql, "exec")
            return None

        def get_table_columns(self, schema, tbl):
            self._capture(f"-- get_table_columns({schema}.{tbl})", "metadata")
            return []

        def get_table_columns_with_type(self, schema, tbl):
            self._capture(f"-- get_table_columns_with_type({schema}.{tbl})", "metadata")
            return {}

    return CapturingDatabase


def _module_for_file(file_path: str) -> str:
    """nlg-src relative path -> dotted module name under the nlg.src namespace."""
    return "nlg.src." + file_path[:-3].replace("/", ".")


def _candidate_kwargs(ctx: QueryContext, db_obj) -> dict:
    return {
        "db_obj": db_obj,
        "nlg_db_tables": ctx.nlg_db_tables,
        "target_type": ctx.target_type,
        "insight_type": ctx.insight_type,
        "curr_insight_type": ctx.insight_type,
        "col_name_mapping": ctx.col_name_mapping,
        "ref_table_columns_to_retrieve": ctx.ref_table_columns_to_retrieve,
        "input_db_join_col": ctx.input_data_config.get("input_db_join_col", ""),
        "target_key_conversion": ctx.input_data_config.get("target_key_conversion", ""),
        "acc_mhh_n": None,
        "pilot_only": False,
        "fields_not_null": ctx.fields_not_null,
        "odm_run_timestamp": "1970-01-01 00:00:00",
        "household_id_range": None,
        "hh_id_range": None,
        "insight_type_from_odm": 1,
        "rule_logic": None,
        "odm_env": None,
        "target_type_is_acc_level": False,
        "prospect_id": None,
        "eva_client_id": None,
        "eva_client_secret": None,
        "odm_run": "latest",
        "insights_target_user_type": ctx.insights_target_user_type,
        "is_prospect_run": ctx.is_prospect_run or None,
    }


def capture_queries_for_insight_type(hierarchy: Hierarchy, target_type: str, insight_type: str,
                                       is_prospect_run: bool = False) -> CaptureResult:
    ctx = gather_context(hierarchy, target_type, insight_type, is_prospect_run=is_prospect_run)
    result = CaptureResult(target_type=target_type, insight_type=insight_type,
                            variant_function=ctx.variant_function, warnings=list(ctx.warnings))

    if ctx.variant_function is None:
        result.execution_error = "Could not determine which fetch_data_with_insights_* variant applies."
        return result

    fi = hierarchy.src_index.functions.get(ctx.variant_function)
    if fi is None:
        result.execution_error = f"Function `{ctx.variant_function}` not found in the indexed source."
        return result

    shim_root = _prepare_import_shim(hierarchy)
    if shim_root not in sys.path:
        sys.path.insert(0, shim_root)

    stubbed: List[str] = []
    try:
        target_module = _import_with_auto_stub(_module_for_file(fi.file), stubbed)
        func = getattr(target_module, ctx.variant_function)
    except Exception as e:
        result.execution_error = (f"Could not import `{ctx.variant_function}` from the real nlg-src code "
                                   f"({type(e).__name__}: {e}). This usually means a third-party dependency "
                                   f"nlg-src needs isn't installed in THIS environment -- install it here (it's "
                                   f"already required wherever the real DAG runs), then retry.")
        return result

    try:
        db_module = _import_with_auto_stub("nlg.src.utils.db_utils", stubbed)
        Database = getattr(db_module, "Database")
        CapturingDatabase = _make_capturing_database_class(Database)
        db_obj = CapturingDatabase()
    except Exception as e:
        result.execution_error = f"Could not build the capturing DB stub ({type(e).__name__}: {e})."
        return result

    if stubbed:
        result.warnings.append(
            "Auto-stubbed missing third-party module(s) for import purposes only (they're pulled in by "
            f"other, unrelated functions in the same file): {sorted(set(stubbed))}. The functions actually "
            "called here never touch these at runtime, but if capture looks wrong, install the real "
            "package(s) in this environment and re-run to rule this out.")

    candidate_kwargs = _candidate_kwargs(ctx, db_obj)
    sig = inspect.signature(func)
    call_kwargs = {}
    missing_required = []
    for name, param in sig.parameters.items():
        if name in candidate_kwargs:
            call_kwargs[name] = candidate_kwargs[name]
        elif param.default is inspect.Parameter.empty and param.kind in (
                inspect.Parameter.POSITIONAL_OR_KEYWORD, inspect.Parameter.KEYWORD_ONLY):
            missing_required.append(name)
    if missing_required:
        result.execution_error = (f"`{ctx.variant_function}` requires parameter(s) "
                                   f"{missing_required} that this harness doesn't know how to supply -- "
                                   f"extend query_capture._candidate_kwargs().")
        result.all_captured = db_obj.captured
        return result

    try:
        func(**call_kwargs)
        result.success = True
    except Exception as e:
        # Expected in some cases (e.g. post-processing a ref table with no rows) --
        # anything captured BEFORE the exception is still real and still useful.
        result.execution_error = f"{type(e).__name__}: {e}"
        result.warnings.append("Execution raised partway through -- likely post-processing code that "
                                "needed real row data. Queries captured before the error are still valid.")

    result.all_captured = db_obj.captured
    matches = [c["sql"] for c in db_obj.captured if _looks_like_primary(c["sql"], target_type, insight_type)]
    # The dummy-household existence-check query can ALSO contain the
    # target_type/insight_type literals (it filters against the same ODM
    # insights table) and is always issued BEFORE the real main query in
    # the source's execution order -- so the correct pick is the LAST
    # match, not the first.
    primary = matches[-1] if matches else None
    if primary:
        result.primary_query = primary
        result.supporting_queries = [c["sql"] for c in db_obj.captured if c["sql"] != primary]
        result.success = True
    else:
        result.supporting_queries = [c["sql"] for c in db_obj.captured]
        if db_obj.captured:
            result.warnings.append("Code ran and issued SQL, but none of it matched the expected "
                                    "target_type/insight_type literal pattern -- inspect all_captured manually.")

    return result


def _looks_like_primary(sql: str, target_type: str, insight_type: str) -> bool:
    """The main narrative-data-fetch query is the one built from the
    literal f-string `where target_type = '{target_type}' and
    insight_type = '{insight_type}'` -- distinguishes it from supporting
    queries (dummy-household checks, ref-table lookups, table introspection)."""
    return (f"target_type = '{target_type}'" in sql and f"insight_type = '{insight_type}'" in sql)
