"""
Adds the right table alias to unqualified columns.

Some generated queries reference a column bare -- `metric_val` rather than
`a.metric_val`. That is valid SQL only while the name happens to be unique
across the joined tables, and it makes the query unreadable and fragile the
moment a second table gains the same column. The fix is to ask Greenplum
which tables actually contain each column and qualify accordingly.

Resolution order when a column exists in several of the query's tables:

    1. a table whose name matches %profile%
    2. otherwise a table whose name matches %odm%
    3. otherwise the first remaining table, in FROM order

That order is the crew's, not a guess: profile tables are the wide
per-entity tables these narratives are built from, and the ODM insight
tables are the fallback source.

Column metadata is read ONCE for all tables in the query and cached for the
process, so a run over hundreds of insight types makes a handful of
metadata queries rather than one per column.
"""
from __future__ import annotations

import re
import threading
from typing import Dict, List, Optional, Sequence, Set

from qt_sqlscan import SQL_KEYWORDS, column_refs, main_select_list, scan, split_top_level

try:
    from nlg_query_tracer.qt_settings import get_logger      # type: ignore
except Exception:                                            # pragma: no cover
    import logging

    def get_logger(name):
        return logging.getLogger(name)

log = get_logger("tracer.alias")

_CACHE: Dict[str, Set[str]] = {}          # "schema.table" -> {column, ...}
_CACHE_LOCK = threading.Lock()


def _split_name(qualified: str):
    parts = qualified.split(".")
    if len(parts) == 2:
        return parts[0], parts[1]
    return None, parts[-1]


def load_columns(conn, tables: Sequence[str]) -> Dict[str, Set[str]]:
    """`table -> {columns}` from information_schema, cached per process.

    Queried in ONE round trip for all uncached tables. Doing it per column
    would turn a few hundred insight types into thousands of metadata
    queries for information that never changes during a run.
    """
    want = [t for t in dict.fromkeys(tables) if t]
    with _CACHE_LOCK:
        missing = [t for t in want if t not in _CACHE]

    if missing and conn is not None:
        pairs = [_split_name(t) for t in missing]
        schemas = sorted({s for s, _t in pairs if s})
        names = sorted({n for _s, n in pairs})
        sql = ("SELECT table_schema, table_name, column_name "
               "FROM information_schema.columns WHERE table_name = ANY(%s)")
        params = [names]
        if schemas:
            sql += " AND table_schema = ANY(%s)"
            params.append(schemas)
        try:
            cur = conn.cursor()
            cur.execute(sql, params)
            found: Dict[str, Set[str]] = {}
            for sch, tbl, col in cur.fetchall():
                found.setdefault("%s.%s" % (sch, tbl), set()).add(str(col).lower())
                found.setdefault(tbl, set()).add(str(col).lower())
            with _CACHE_LOCK:
                for t in missing:
                    _CACHE[t] = found.get(t, found.get(t.split(".")[-1], set()))
            log.info("Loaded column metadata for %d table(s); %d resolved.",
                     len(missing), sum(1 for t in missing if _CACHE.get(t)))
        except Exception as e:
            # Without metadata the query is left exactly as it was, which is
            # the safe outcome -- a wrong alias is worse than no alias.
            log.warning("Could not read column metadata (%s); columns will be left "
                        "unqualified.", e)
            with _CACHE_LOCK:
                for t in missing:
                    _CACHE.setdefault(t, set())

    with _CACHE_LOCK:
        return {t: set(_CACHE.get(t, set())) for t in want}


def pick_table(candidates: Sequence[str]) -> Optional[str]:
    """The table to attribute a column to, by the crew's precedence."""
    if not candidates:
        return None
    for pat in ("profile", "odm"):
        for t in candidates:
            if pat in t.lower():
                return t
    return candidates[0]


def qualify(sql: str, alias_map: Dict[str, str], conn=None) -> str:
    """Returns `sql` with unqualified select-list columns given an alias.

    Only the MAIN select list is rewritten. Sub-queries have their own scope
    -- a bare column there refers to their own FROM, and prefixing it with an
    outer alias would change the query's meaning rather than clarify it.
    """
    sel = main_select_list(sql)
    if not sel or not alias_map:
        return sql

    tables = list(alias_map.values())
    cols_by_table = load_columns(conn, tables)
    if not any(cols_by_table.values()):
        return sql

    # column -> the aliases whose table contains it, in FROM order
    owners: Dict[str, List[str]] = {}
    for alias, table in alias_map.items():
        for col in cols_by_table.get(table, set()):
            owners.setdefault(col, []).append(alias)

    start = sql.find(sel)
    if start < 0:
        return sql
    end = start + len(sel)
    rewritten, changed = [], 0

    for item in split_top_level(sel):
        new_item, n = _qualify_item(item, owners, alias_map)
        changed += n
        rewritten.append(new_item)

    if not changed:
        return sql
    log.info("Qualified %d bare column reference(s) in the select list.", changed)
    return sql[:start] + ", ".join(rewritten) + sql[end:]


def _qualify_item(item: str, owners: Dict[str, List[str]], alias_map: Dict[str, str]):
    """Rewrites one select-list item, right to left so offsets stay valid."""
    refs = [(a, c, p) for a, c, p in column_refs(item) if a is None]
    if not refs:
        return item, 0

    text, changed = item, 0
    for _a, col, pos in sorted(refs, key=lambda t: t[2], reverse=True):
        aliases = owners.get(col.lower())
        if not aliases:
            continue                     # not a column of any joined table
        if len(aliases) == 1:
            chosen = aliases[0]
        else:
            table = pick_table([alias_map[a] for a in aliases])
            chosen = next(a for a in aliases if alias_map[a] == table)
        # the position came from the alias-stripped, literal-masked copy, so
        # verify the token really is there before touching it
        if text[pos:pos + len(col)] != col:
            found = re.search(r"(?<![\w.$])%s(?![\w$])" % re.escape(col), text)
            if not found:
                continue
            pos = found.start()
        text = text[:pos] + chosen + "." + text[pos:]
        changed += 1
    return text, changed
