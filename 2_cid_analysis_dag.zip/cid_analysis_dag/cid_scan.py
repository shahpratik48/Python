"""
Finding where a column is used, and whether it is masked.

Both config folders are YAML whose leaf values are SQL fragments, so the
question is always the same: does this expression mention the column, and is
that mention wrapped in MD5?

Masking is judged by PARSING the expression, not by asking whether the word
"md5" appears somewhere in it. That distinction matters:

    ip_frst_x:      substring(MD5(b.ip_frst_x),1,8)      masked
    ip_frst_x_real: b.ip_frst_x                          NOT masked
    mixed:          MD5(b.a) || b.ip_frst_x              NOT masked -- the
                                                         second use is bare

A substring check would call the third one masked and let a real leak
through.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Tuple

import yaml

from cid_settings import get_logger

log = get_logger("cid.scan")

_MASK_FN = re.compile(r"\b(md5|sha1|sha224|sha256|sha384|sha512|hashtext|encode|digest)\s*\(",
                      re.I)


@dataclass
class Usage:
    """One place a column is used."""
    file_path: str
    yaml_key: str            # the mapping key, e.g. ip_frst_x_real
    column: str
    logic: str               # the expression, verbatim
    masked: bool
    target_type: str = ""


def _column_pattern(column: str) -> "re.Pattern":
    """Whole-word, so `acc_i` does not match inside `acc_i_asset_key`."""
    return re.compile(r"(?<![\w$])%s(?![\w$])" % re.escape(column), re.I)


def _mask_spans(expr: str) -> List[Tuple[int, int]]:
    """Character ranges covered by a masking function's arguments."""
    spans = []
    for m in _MASK_FN.finditer(expr):
        i = m.end() - 1                     # at the '('
        depth = 0
        for j in range(i, len(expr)):
            if expr[j] == "(":
                depth += 1
            elif expr[j] == ")":
                depth -= 1
                if depth == 0:
                    spans.append((m.end(), j))
                    break
        else:
            spans.append((m.end(), len(expr)))   # unbalanced; treat to end
    return spans


def occurrences_masked(expr: str, column: str) -> Tuple[int, int]:
    """(total occurrences, how many sit inside a masking call)."""
    pat = _column_pattern(column)
    spans = _mask_spans(expr)
    total = inside = 0
    for m in pat.finditer(expr):
        total += 1
        if any(a <= m.start() < b for a, b in spans):
            inside += 1
    return total, inside


def is_masked(expr: str, column: str) -> Optional[bool]:
    """True only when EVERY occurrence is wrapped.

    One bare use is enough to leak the value, so partial masking counts as
    unmasked.
    """
    total, inside = occurrences_masked(expr, column)
    if total == 0:
        return None
    return inside == total


def _walk(node, path: str = ""):
    """Yields (key path, scalar value) for every leaf in a YAML document."""
    if isinstance(node, dict):
        for k, v in node.items():
            yield from _walk(v, "%s.%s" % (path, k) if path else str(k))
    elif isinstance(node, list):
        for i, v in enumerate(node):
            yield from _walk(v, "%s[%d]" % (path, i))
    else:
        if node is not None:
            yield path, str(node)


def parse_yaml(text: str, path: str):
    try:
        return yaml.safe_load(text)
    except Exception as e:
        log.warning("Could not parse YAML %s (%s); falling back to a line scan.", path, e)
        return None


def scan_files(files: Dict[str, str], columns: Iterable[str],
               target_type_of=None) -> List[Usage]:
    """Every use of any of `columns` across `files`.

    The column list is scanned per expression rather than the other way
    round, so each file's text is walked once no matter how many CID columns
    there are -- with ~470 mapping files and a long CID list, the opposite
    order is what makes this slow.
    """
    cols = [c for c in dict.fromkeys(c.strip().lower() for c in columns) if c]
    if not cols:
        return []
    pats = {c: _column_pattern(c) for c in cols}
    out: List[Usage] = []

    for path, text in files.items():
        if not text or not text.strip():
            continue
        low = text.lower()
        # cheap pre-filter: skip a file that cannot contain any of them
        present = [c for c in cols if c in low]
        if not present:
            continue

        doc = parse_yaml(text, path)
        tt = target_type_of(path, doc) if target_type_of else ""
        leaves = list(_walk(doc)) if doc is not None else \
            [("(line %d)" % (i + 1), ln) for i, ln in enumerate(text.splitlines()) if ln.strip()]

        for key, expr in leaves:
            el = expr.lower()
            for c in present:
                if c not in el or not pats[c].search(expr):
                    continue
                m = is_masked(expr, c)
                out.append(Usage(file_path=path, yaml_key=key, column=c,
                                 logic=" ".join(expr.split()), masked=bool(m),
                                 target_type=tt))
    log.info("Scanned %d file(s) for %d column(s): %d usage(s) found.",
             len(files), len(cols), len(out))
    return out


def target_type_from_config(path: str, doc) -> str:
    """The top-level key of an input_data_config file is its target_type."""
    if isinstance(doc, dict) and len(doc) == 1:
        return str(list(doc.keys())[0])
    import posixpath
    return posixpath.basename(path).rsplit(".", 1)[0]


def target_type_from_mapping(path: str, _doc=None) -> str:
    """sql_column_mapping is laid out as <target_type>/<insight_type>.yml."""
    parts = path.strip("/").split("/")
    return parts[-2] if len(parts) >= 2 else ""


def load_profile_map(text: str) -> Dict[str, str]:
    """`target_type -> profile table` from profile_tbl.yaml."""
    try:
        doc = yaml.safe_load(text) or {}
    except Exception as e:
        log.error("Could not parse the profile map: %s", e)
        return {}
    out = {}
    for row in (doc.get("profile_tables") or []):
        if isinstance(row, dict):
            tt = str(row.get("target_type") or "").strip()
            tbl = str(row.get("profile_table_name") or "").strip()
            if tt and tbl:
                out[tt] = tbl
    log.info("Profile map: %d target_type -> table entries.", len(out))
    return out
