# Wiring the task into `nlg_dummy2` (and `nlg_dummy`)

The CID files are deployed to **`/opt/airflow/dags/nlg/src/cid/`** — beside the DAG's existing
`template_searchpath` of `/opt/airflow/dags/nlg/src`.

## The change — two lines

```diff
  from airflow.operators.python_operator import PythonOperator

+ from nlg.src.cid import build_task

  ...
      start_nlg = PythonOperator(task_id='start_nlg', python_callable=get_nlg_start_time)
+     cid_analysis = build_task()
      nlg_latest_odm_insights = nlg_taskgroups.get_latest_odm_insights('nlg_dummy2')

-     chain(start_nlg, nlg_latest_odm_insights, nlg_asset_allocation, nlg_preprocess, nlg_rules, nlg_json_insights, end_nlg)
+     chain(start_nlg, cid_analysis, nlg_latest_odm_insights, nlg_asset_allocation, nlg_preprocess, nlg_rules, nlg_json_insights, end_nlg)
```

For `nlg_dummy` the change is identical — the task reads the DAG id from the context and pins that
one to `develop`.

### What the package import needs

`nlg/src` and `nlg/src/cid` must both be importable packages, so each needs an `__init__.py`:

- `nlg/src/cid/__init__.py` — **included** in this bundle
- `nlg/src/__init__.py` — deploy `src_init_for_nlg.py` under that name; keep your existing file if
  there already is one

An empty `__init__.py` on `src` changes nothing else. It does **not** affect `template_searchpath`,
which reads the directory from disk rather than importing it.

Every module imports its siblings **relatively first**, falling back to a flat import, so the very
same files also run as loose modules from the notebook where there is no package at all. Both forms
were tested against a replica of this layout.

Set `CID_HOME` if the reports should be written somewhere other than the `cid` folder.

## A DAG run does not use GitLab

The code a DAG analyses **is the deployment on that worker**, so the task reads
`/opt/airflow/dags/nlg/src` straight from disk. There is no clone, no token and no network call.

That is not just faster — cloning a branch back from GitLab could analyse a *different* revision from
the one about to run, which is the one thing this check must not do.

| | DAG run | Notebook run |
|---|---|---|
| Source | the deployed folder on the worker | the GitLab branch |
| GitLab token | **not needed** | required |
| Branch | not applicable — reports the path scanned | `develop`, or your feature branch |

`GENESIS_DDLC_IKG_GIT_SECRET` is therefore no longer required for the DAG. The notebook is unchanged.

The root is derived from where `cid_task.py` sits — the parent of the `cid` folder — so moving the
whole tree needs no edit. `CID_LOCAL_ROOT` overrides it.

## Where each file goes

```
/opt/airflow/dags/nlg/src/
    __init__.py          <- from src_init_for_nlg.py, if not already present
    cid/
        __init__.py
        cid_task.py      <- build_task() lives here
        cid_settings.py
        cid_gitlab.py
        cid_greenplum.py
        cid_context.py
        cid_scan.py
        cid_analysis.py
        cid_report.py
        cid_main.py
```

Reports and the run log are written into this same folder.

## Why one task rather than two

It analyses, writes both reports, **emails them, and only then raises**. Sending before raising is
what lets a single task do the whole job: the attachment exists whether the run passed, found
something, or errored.

Your `default_args` already carries `'email_on_failure': True` with `dl-staat-ds-ikg@ubs.com`, so on
a failure Airflow sends its own alert **in addition** to the report email. Nothing to add.

## Telling nlg_dummy2 which branch

`nlg_dummy` always uses `develop` and ignores everything below. `nlg_dummy2` takes the branch from,
in order:

**1. DAG-run configuration** — no DAG change needed:

```json
{"branch": "feature/my-change"}
```

**2. A DAG Param**, if you prefer it in the trigger form — one line in the existing `params` block:

```python
   params={
       "odm_env": Param("dummy2", enum=["dummy", "dummy2"]),
       "branch": Param("develop", type="string"),
   },
```

**3. Neither** — the task fails immediately saying the branch is missing. It does **not** fall back
to develop: scanning the wrong branch would report a clean result for code nobody has checked.

## When the task fails

| Situation | Outcome |
|---|---|
| Nothing flagged, no new columns | passes — report emailed anyway |
| Anything flagged | **fails**, report emailed |
| No flags but **any** new column | **fails**, report emailed |
| Analysis could not run | **fails**, error emailed |

A new column fails on its own because nobody has yet decided whether it is client-identifying — CID
or not, used or not.

## Airflow objects used

| Kind | Name |
|---|---|
| Variable | `IKG_SCHEMA` (Dev, used by `nlg_dummy2`) |
| Variable | `IKG_PRE_PROD_SCHEMA` (UAT, used by `nlg_dummy`) |
| Variable *(optional)* | `CID_LOCAL_ROOT` — defaults to the parent of the `cid` folder |
| Connection | `IKG_GP_GPRDSP` (Greenplum) |
| Variable *(optional)* | `CID_EXCLUDE_KEYS` — defaults to `input_db_join_col` |
| Variable *(optional)* | `CID_EMAIL_RECIPIENTS` — comma-separated |

`core_ikg` is hardcoded for the CID metadata table and deliberately not configurable.
