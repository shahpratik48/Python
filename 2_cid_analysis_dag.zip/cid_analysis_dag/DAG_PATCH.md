# Wiring the task into `nlg_dummy2` (and `nlg_dummy`)

Two lines added to the existing DAG file. Nothing else changes.

## The change

```diff
   # User defined modules
   from nlg.dags import nlg_taskgroups
+  from nlg.cid import cid_task          # wherever you deploy the cid_*.py files

   start_nlg = PythonOperator(task_id='start_nlg', python_callable=get_nlg_start_time)
+  cid_analysis = cid_task.build_task()
   nlg_latest_odm_insights = nlg_taskgroups.get_latest_odm_insights('nlg_dummy2')
   ...

-  chain(start_nlg, nlg_latest_odm_insights, nlg_asset_allocation, nlg_preprocess, nlg_rules, nlg_json_insights, end_nlg)
+  chain(start_nlg, cid_analysis, nlg_latest_odm_insights, nlg_asset_allocation, nlg_preprocess, nlg_rules, nlg_json_insights, end_nlg)
```

`build_task()` returns a ready `PythonOperator` with `task_id='cid_analysis'`. Pass
`build_task(task_id='...')` to rename it, or `build_task(dag=dag)` if your file does not use the
`with DAG(...)` context.

## Why one task rather than two

It analyses, writes both reports, **emails them, and only then raises**. Sending before raising is
what lets a single task do the whole job: the attachment exists whether the run passed, found
something, or errored.

Your `default_args` already carries `'email_on_failure': True` with `dl-staat-ds-ikg@ubs.com`, so on
a failure Airflow sends its own alert **in addition** to the report email. Nothing to add for that.

## Telling nlg_dummy2 which branch

`nlg_dummy` always uses `develop` and ignores everything below. `nlg_dummy2` needs a branch, taken in
this order:

**1. DAG-run configuration** — nothing to change in the DAG file:

```json
{"branch": "feature/my-change"}
```

**2. A DAG Param**, if you would rather have it in the trigger form. Your file already has a `params`
block, so this is one more line:

```python
   params={
       "odm_env": Param("dummy2", enum=["dummy", "dummy2"]),
       "branch": Param("develop", type="string"),
   },
```

**3. Neither** — the task fails immediately with a message saying the branch is missing. It does
**not** quietly fall back to develop: scanning the wrong branch would report a clean result for code
nobody has checked.

## Where the files go

All `cid_*.py` files must sit together, importable from the DAG. Either:

- alongside the DAG file, and `import cid_task`; or
- in a package such as `nlg/cid/`, and `from nlg.cid import cid_task`.

`cid_task.py` adds its own directory to `sys.path`, so the sibling modules resolve either way.

## When the task fails

| Situation | Outcome |
|---|---|
| Nothing flagged, no new columns | task passes, report emailed anyway |
| Anything flagged | task **fails**, report emailed |
| No flags but **any new column** | task **fails**, report emailed |
| Analysis could not run | task **fails**, error emailed |

A new column fails on its own because nobody has yet decided whether it is client-identifying — CID
or not, used or not.

## Airflow objects used

| Kind | Name |
|---|---|
| Variable | `IKG_SCHEMA` (Dev, used by `nlg_dummy2`) |
| Variable | `IKG_PRE_PROD_SCHEMA` (UAT, used by `nlg_dummy`) |
| Variable | `GENESIS_DDLC_IKG_GIT_SECRET` (GitLab token) |
| Connection | `IKG_GP_GPRDSP` (Greenplum) |
| Variable *(optional)* | `CID_EXCLUDE_KEYS` — defaults to `input_db_join_col` |
| Variable *(optional)* | `CID_EMAIL_RECIPIENTS` — comma-separated |

`core_ikg` is hardcoded for the CID metadata table and deliberately not configurable.
