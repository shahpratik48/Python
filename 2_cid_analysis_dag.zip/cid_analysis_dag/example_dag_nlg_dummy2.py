"""
REFERENCE ONLY -- the existing nlg_dummy2 DAG with the CID task wired in.

Shown so the two added lines are unambiguous; do not deploy this file. The
change to make in your real DAG is marked with  # <-- ADDED.
"""
import importlib

importlib.invalidate_caches()

from datetime import datetime, timedelta

from airflow import DAG
from airflow.models.baseoperator import chain
from airflow.models.param import Param
from airflow.operators.empty import EmptyOperator
from airflow.operators.python_operator import PythonOperator


def get_nlg_start_time(ti):
    nlg_time_start = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
    ti.xcom_push(key="nlg_time_start", value=nlg_time_start)


default_args = {
    "owner": "NLG",
    "retry_delay": timedelta(minutes=1),
    "retries": 0,
    "email": ["dl-staat-ds-ikg@ubs.com"],
    # already present: Airflow sends its own alert when the CID task fails
    "email_on_failure": True,
}

with DAG(
    dag_id="nlg_dummy2",
    default_args=default_args,
    description="NLG Dummy2",
    template_searchpath="/opt/airflow/dags/nlg/src",
    start_date=datetime(2023, 6, 6),
    schedule_interval=None,
    render_template_as_native_obj=True,
    params={
        "odm_env": Param("dummy2", enum=["dummy", "dummy2"]),
        "branch": Param("develop", type="string"),        # <-- ADDED (optional)
    },
    tags=["NLG"],
):

    # User defined modules
    from nlg.dags import nlg_taskgroups

    from nlg.cid import cid_task                          # <-- ADDED

    start_nlg = PythonOperator(task_id="start_nlg", python_callable=get_nlg_start_time)
    cid_analysis = cid_task.build_task()                  # <-- ADDED
    nlg_latest_odm_insights = nlg_taskgroups.get_latest_odm_insights("nlg_dummy2")
    nlg_asset_allocation = nlg_taskgroups.get_nlg_asset_allocation()
    nlg_preprocess = nlg_taskgroups.get_nlg_preprocess()
    nlg_rules = nlg_taskgroups.get_nlg_rules()
    nlg_json_insights = nlg_taskgroups.get_nlg_json_insights()
    end_nlg = EmptyOperator(task_id="end_nlg", trigger_rule="none_failed")

    chain(start_nlg, cid_analysis,                        # <-- ADDED to the chain
          nlg_latest_odm_insights, nlg_asset_allocation, nlg_preprocess,
          nlg_rules, nlg_json_insights, end_nlg)
