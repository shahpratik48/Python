"""
Configuration, secrets and logging for the CID analysis.

Two DAGs share this code and differ only in what they point at:

    nlg_dummy    branch is ALWAYS develop        schema = IKG_PRE_PROD_SCHEMA (UAT)
    nlg_dummy2   branch comes from the user      schema = IKG_SCHEMA (Dev)

The CID metadata table is the one exception: it is always read from the
hardcoded production schema, because a dev copy of "which columns are
client-identifying" would make the whole check meaningless.

Secrets resolve as: explicit value -> environment -> Airflow Variable ->
prompt (notebook only). Nothing is ever hardcoded.
"""
from __future__ import annotations

import getpass
import logging
import os
import sys
from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional

DAG_DUMMY = "nlg_dummy"
DAG_DUMMY2 = "nlg_dummy2"

# Always production -- see the module docstring.
CID_METADATA_SCHEMA = "core_ikg"
CID_METADATA_TABLE = "cid_columns_metadata_manual_refresh"

_LOG_FMT = "%(asctime)s | %(levelname)-7s | %(name)-20s | %(message)s"
_configured = False


def stdout_is_a_logger() -> bool:
    """Whether sys.stdout has been redirected INTO the logging system.

    Airflow replaces sys.stdout with a writer that logs whatever is written
    to it. Attaching a StreamHandler to that object closes a loop --
    emit -> write -> log -> emit -- which recurses until the stack blows and
    the process dies with SIGABRT, taking the task with it before anything
    can be reported.
    """
    out = getattr(sys, "stdout", None)
    if out is None:
        return True
    mod = (getattr(type(out), "__module__", "") or "").lower()
    name = getattr(type(out), "__name__", "") or ""
    if "logging_mixin" in mod or "logging" in mod:
        return True
    if name in ("StreamLogWriter", "RedirectStdHandler", "LoggingMixin"):
        return True
    return hasattr(out, "log") and not hasattr(out, "fileno")


def in_airflow() -> bool:
    """Whether this is running inside an Airflow task."""
    if os.getenv("AIRFLOW_CTX_DAG_ID") or os.getenv("AIRFLOW_CTX_TASK_ID"):
        return True
    if "airflow" in sys.modules:
        return True
    return stdout_is_a_logger()


def _writable(path: str) -> bool:
    try:
        os.makedirs(path, exist_ok=True)
        probe = os.path.join(path, ".cid_write_test")
        with open(probe, "w") as fh:
            fh.write("x")
        os.remove(probe)
        return True
    except Exception:
        return False


def writable_dir(preferred: Optional[str] = None) -> str:
    """The first writable directory among the candidates.

    The deployment folder is usually read-only on a worker, so reports and
    logs cannot be written beside the code. Falling back is better than
    failing the task for a reason unrelated to the check.
    """
    import tempfile
    for cand in (preferred,
                 os.getenv("CID_OUTPUT_DIR"),
                 os.path.join(os.getenv("AIRFLOW_HOME", "/opt/airflow"), "logs", "cid"),
                 os.path.join(tempfile.gettempdir(), "cid_analysis")):
        if cand and _writable(cand):
            return cand
    return tempfile.gettempdir()


def setup_logging(level: str = "INFO", log_dir: Optional[str] = None,
                  log_to_file: bool = True) -> str:
    """Configure logging WITHOUT disturbing anything already configured.

    Under Airflow this attaches nothing at all. Airflow installs its own
    handler on the root logger to capture a task's output for the UI, and an
    earlier version of this function removed every root handler before
    adding its own -- which silently threw away the task log and left the
    run with no diagnostics whatsoever. Records from these modules propagate
    to whatever Airflow has set up, which is exactly what is wanted.
    """
    global _configured
    root = logging.getLogger()
    if _configured:
        return getattr(root, "_cid_log", "")

    lvl = getattr(logging, str(level).upper(), logging.INFO)
    for name in ("cid", "cid.settings", "cid.gitlab", "cid.local", "cid.greenplum",
                 "cid.scan", "cid.context", "cid.analysis", "cid.report", "cid.main",
                 "cid.task"):
        logging.getLogger(name).setLevel(lvl)

    path = ""
    if in_airflow():
        # Airflow owns the handlers; adding our own would duplicate every
        # line in the task log -- and any handler bound to the redirected
        # stdout would recurse until the process aborts.
        if root.level > lvl or root.level == logging.NOTSET:
            root.setLevel(lvl)
        logging.getLogger("cid").info(
            "Logging through Airflow's task handler (no handlers added or removed).")
    else:
        if not root.handlers:
            # sys.__stdout__, never sys.stdout: the latter may have been
            # redirected into the logging system, and a handler writing to
            # that would recurse forever. The original stream cannot.
            stream = sys.__stdout__ or sys.stdout
            if not stdout_is_a_logger() or stream is not sys.stdout:
                sh = logging.StreamHandler(stream)
                sh.setFormatter(logging.Formatter(_LOG_FMT))
                root.addHandler(sh)
        root.setLevel(lvl)
        if log_to_file:
            target = writable_dir(log_dir)
            path = os.path.join(target, "cid_analysis_%s.log"
                                % datetime.now().strftime("%Y%m%d_%H%M%S"))
            try:
                fh = logging.FileHandler(path, encoding="utf-8")
                fh.setFormatter(logging.Formatter(_LOG_FMT))
                root.addHandler(fh)
            except Exception as e:
                path = ""
                logging.getLogger("cid").warning("No log file (%s); console only.", e)

    logging.getLogger("urllib3").setLevel(logging.WARNING)
    root._cid_log = path
    _configured = True
    return path


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)


log = get_logger("cid.settings")


def _env(k, d=None):
    return os.getenv(k, d)


def _airflow_var(key):
    try:
        from airflow.models import Variable      # type: ignore
        return Variable.get(key, default_var=None)
    except Exception:
        return None


@dataclass
class CidSettings:
    # ---------------- where the code is read from ----------------
    # "git"   -- clone the branch from GitLab (the notebook)
    # "local" -- read the deployment already on the worker (the DAG)
    # Inside a DAG the code being analysed IS the deployment, so fetching it
    # from GitLab would add a network dependency, a token to manage, and the
    # risk of analysing a different revision from the one about to run.
    source: str = field(default_factory=lambda: _env("CID_SOURCE", "git"))
    local_root: str = field(default_factory=lambda: _env(
        "CID_LOCAL_ROOT", "/opt/airflow/dags/nlg/src"))

    # ---------------- GitLab (source = "git" only) ----------------
    gitlab_url: str = field(default_factory=lambda: _env("GITLAB_URL",
                                                         "https://devcloud.ubs.net"))
    nlg_project_path: str = field(default_factory=lambda: _env(
        "NLG_PROJECT_PATH",
        "ubs/gwma/smart-technology-and-analytics/staat-data-science/"
        "staat-ds-genesis/genesis-platform/nlg-dags"))
    git_token: Optional[str] = field(default_factory=lambda: _env("GITLAB_TOKEN", ""))
    git_token_var: str = "GENESIS_DDLC_IKG_GIT_SECRET"

    # ---------------- which DAG, which branch ----------------
    dag_id: str = DAG_DUMMY
    input_branch: Optional[str] = None          # only used by nlg_dummy2
    branch: str = ""                            # resolved

    # ---------------- Greenplum ----------------
    gp_conn_id: str = "IKG_GP_GPRDSP"
    gp_host: str = field(default_factory=lambda: _env("GREENPLUM_HOST",
                                                      "greenplum-rdsp.zur.swissbank.com"))
    gp_port: int = field(default_factory=lambda: int(_env("GREENPLUM_PORT", "5432")))
    gp_db: str = field(default_factory=lambda: _env("GREENPLUM_DB", "gprdsp"))
    gp_user: str = field(default_factory=lambda: _env("GREENPLUM_USER", "ds_rdsp_dev"))
    gp_password: Optional[str] = field(default_factory=lambda: _env("GREENPLUM_PASSWORD", ""))
    gp_conn_loaded: bool = False        # the Airflow connection was found

    ikg_schema: str = field(default_factory=lambda: _env("IKG_SCHEMA", ""))
    ikg_pre_prod_schema: str = field(default_factory=lambda: _env("IKG_PRE_PROD_SCHEMA", ""))
    compare_schema: str = ""                    # resolved

    # ---------------- what to look for in the repo ----------------
    # Folder and file NAMES, not paths: they are located at whatever depth
    # they happen to sit, so a layout change cannot make the scan silently
    # find nothing.
    config_dir_name: str = "input_data_config_dummy"
    mapping_dir_name: str = "sql_column_mapping"
    profile_map_name: str = "profile_tbl.yaml"

    # ---------------- keys excluded from the masking check ----------------
    # Some YAML keys carry a column name for plumbing rather than for
    # display -- `input_db_join_col` names the join key, which is never
    # rendered. Comma-separated; an entry may be a bare key or a
    # `target_type.key` path.
    exclude_keys: str = field(default_factory=lambda: _env(
        "CID_EXCLUDE_KEYS", "") or (_airflow_var("CID_EXCLUDE_KEYS") or "input_db_join_col"))

    # ---------------- behaviour ----------------
    max_workers: int = field(default_factory=lambda: int(_env("CID_MAX_WORKERS", "24")))
    output_dir: str = field(default_factory=lambda: _env(
        "CID_OUTPUT_DIR", os.path.dirname(os.path.abspath(__file__))))
    fail_on_findings: bool = True

    # ---------------- resolution ----------------
    @property
    def is_local(self) -> bool:
        return str(self.source or "").lower() == "local"

    def resolve_branch(self) -> "CidSettings":
        """nlg_dummy is pinned to develop; nlg_dummy2 must be told.

        A blank branch for nlg_dummy2 is a hard error rather than a silent
        fall back to develop -- scanning the wrong branch would report a
        clean result for code nobody has checked.

        None of that applies when reading from disk: there is no branch to
        choose, because the deployment is whatever was released. The label
        records the path instead, so the report still says what was scanned.
        """
        dag = (self.dag_id or "").strip()
        if self.is_local:
            if dag not in (DAG_DUMMY, DAG_DUMMY2):
                raise ValueError("Unknown dag_id %r. Expected '%s' or '%s'."
                                 % (dag, DAG_DUMMY, DAG_DUMMY2))
            self.branch = "local: %s" % self.local_root
            log.info("DAG '%s' -> reading the deployed code at %s (no branch involved).",
                     dag, self.local_root)
            return self
        if dag == DAG_DUMMY:
            self.branch = "develop"
            log.info("DAG '%s' -> branch pinned to 'develop'.", dag)
        elif dag == DAG_DUMMY2:
            b = (self.input_branch or "").strip()
            if not b:
                raise ValueError(
                    "DAG '%s' needs a feature branch. Pass it as the 'branch' DAG-run "
                    "config value, or set it in the notebook. It was blank or missing, and "
                    "defaulting to develop would report on code you did not ask about."
                    % DAG_DUMMY2)
            self.branch = b
            log.info("DAG '%s' -> branch '%s' (from input).", dag, b)
        else:
            raise ValueError("Unknown dag_id %r. Expected '%s' or '%s'."
                             % (dag, DAG_DUMMY, DAG_DUMMY2))
        return self

    def resolve_schema(self) -> "CidSettings":
        """nlg_dummy2 compares against Dev, nlg_dummy against UAT."""
        if self.dag_id == DAG_DUMMY2:
            name, val = "IKG_SCHEMA", self.ikg_schema or _airflow_var("IKG_SCHEMA")
        else:
            name, val = ("IKG_PRE_PROD_SCHEMA",
                         self.ikg_pre_prod_schema or _airflow_var("IKG_PRE_PROD_SCHEMA"))
        if not val:
            raise RuntimeError(
                "%s is not set. It names the schema whose profile tables are compared against "
                "%s. Set the Airflow Variable, the environment variable, or pass it in the "
                "notebook." % (name, CID_METADATA_SCHEMA))
        self.compare_schema = val
        log.info("DAG '%s' -> comparing schema '%s' (%s) against production '%s'.",
                 self.dag_id, val, name, CID_METADATA_SCHEMA)
        return self

    def load_gp_connection(self) -> bool:
        """Fill the Greenplum credentials from the Airflow connection.

        Inside a DAG the credentials belong to `IKG_GP_GPRDSP` -- host, port,
        database, login and password all come from it. Resolving them HERE
        means the rest of the code has one source of truth and never has to
        ask which kind of run it is.
        """
        try:
            from airflow.hooks.base import BaseHook          # type: ignore
        except Exception:
            try:
                from airflow.hooks.base_hook import BaseHook  # type: ignore
            except Exception:
                return False
        try:
            c = BaseHook.get_connection(self.gp_conn_id)
        except Exception as e:
            log.info("Airflow connection '%s' not available (%s).", self.gp_conn_id, e)
            return False
        if c.host:
            self.gp_host = c.host
        if c.port:
            self.gp_port = int(c.port)
        if c.schema:
            self.gp_db = c.schema
        if c.login:
            self.gp_user = c.login
        if c.password:
            self.gp_password = c.password
        self.gp_conn_loaded = True
        log.info("Greenplum credentials taken from the Airflow connection '%s' (%s:%s/%s as %s).",
                 self.gp_conn_id, self.gp_host, self.gp_port, self.gp_db, self.gp_user)
        if not self.gp_password:
            log.info("The connection carries no password; the driver will authenticate by "
                     "whatever means it is configured for.")
        return True

    def resolve_secrets(self, interactive: bool = True) -> "CidSettings":
        """Only the credentials this run will actually use.

        A DAG run reads the deployment from disk, so it never calls GitLab
        and is never asked for a token. Demanding one anyway would make the
        DAG depend on a credential it does not use, and fail for a reason
        that has nothing to do with the check.
        """
        if self.is_local:
            log.info("Source is the local filesystem -- no GitLab token required.")
        else:
            if not self.git_token:
                self.git_token = _airflow_var(self.git_token_var)
            if not self.git_token and interactive:
                self.git_token = getpass.getpass(
                    "GitLab personal access token: ").strip() or None
            if not self.git_token:
                raise RuntimeError("No GitLab token. Set GITLAB_TOKEN or the Airflow Variable "
                                   "'%s'." % self.git_token_var)
            log.info("GitLab token resolved.")

        # The Airflow connection comes FIRST: inside a DAG it is the intended
        # source, and demanding an environment variable as well would fail a
        # run whose credentials were configured perfectly correctly.
        if not self.gp_password:
            self.load_gp_connection()
        if not self.gp_password:
            self.gp_password = _airflow_var("GREENPLUM_PASSWORD")
        if not self.gp_password and interactive:
            self.gp_password = getpass.getpass(
                "Greenplum password for %s@%s: " % (self.gp_user, self.gp_host)).strip() or None
        if not self.gp_password and not self.gp_conn_loaded:
            # Only an error when there is no connection either. A connection
            # WITHOUT a password is legitimate -- the driver may authenticate
            # by .pgpass, a trust rule or an IAM token, and refusing to try
            # would fail a setup that works.
            raise RuntimeError(
                "No Greenplum credentials. Inside Airflow the connection '%s' should supply "
                "them -- check that it exists. Outside Airflow, set GREENPLUM_PASSWORD or the "
                "Airflow Variable of the same name." % self.gp_conn_id)
        log.info("Greenplum credentials resolved for %s@%s:%s/%s.",
                 self.gp_user, self.gp_host, self.gp_port, self.gp_db)
        return self

    def excluded_key_set(self):
        """The configured keys, normalised and de-duplicated."""
        out = []
        for part in str(self.exclude_keys or "").split(","):
            k = part.strip().strip('"').strip("'").lower()
            if k and k not in out:
                out.append(k)
        return out

    def prepare(self, interactive: bool = True) -> "CidSettings":
        self.resolve_branch().resolve_schema().resolve_secrets(interactive)
        ex = self.excluded_key_set()
        log.info("Keys excluded from the masking check: %s",
                 ", ".join(ex) if ex else "(none)")
        return self
