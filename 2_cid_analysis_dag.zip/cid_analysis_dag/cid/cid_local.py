"""
Reading the two config folders from the LOCAL filesystem.

Inside a DAG the code being analysed is already on the worker -- it is the
deployment under `/opt/airflow/dags/nlg/src`. Cloning it back from GitLab
would add a network dependency, a token to manage, and the risk of
analysing a *different* revision from the one that is about to run.

So the DAG reads from disk and the notebook reads from GitLab. Both present
the same `load_tree()` interface, so everything downstream -- discovery,
scanning, the rules -- is identical and neither path is a special case.
"""
from __future__ import annotations

import os
from typing import Dict, Optional

# Imports work BOTH ways: as a package member (from nlg.src.cid import ...)
# and as loose modules on sys.path (the notebook). Relative is tried first
# so the package form does not depend on the folder being on sys.path.
try:
    from .cid_settings import get_logger
except ImportError:                     # loaded as loose modules
    from cid_settings import get_logger  # type: ignore

log = get_logger("cid.local")

try:
    from .cid_scan import is_wanted_file
except ImportError:                     # loaded as loose modules
    from cid_scan import is_wanted_file  # type: ignore

DATA_SUFFIXES = (".yml", ".yaml", ".json")
MAX_BYTES = 4 * 1024 * 1024              # no config file is bigger than this
SKIP_DIRS = {".git", "__pycache__", ".idea", ".vscode", "node_modules", ".pytest_cache"}


class LocalRepo:
    """Same shape as GitLabRepo, backed by a directory."""

    def __init__(self, settings):
        self.root = os.path.abspath(settings.local_root or "")
        self.workers = int(getattr(settings, "max_workers", 12))
        self._files: Optional[Dict[str, str]] = None

    # ------------------------------------------------------------ checks
    def branch_exists(self) -> bool:
        """There is no branch on disk; what matters is that the root exists.

        Kept under the same name so the caller does not have to know which
        source it is talking to.
        """
        if not self.root:
            log.error("No local root configured. Set local_root (or CID_LOCAL_ROOT) to the "
                      "folder holding sql_column_mapping and input_data_config_dummy.")
            return False
        if not os.path.isdir(self.root):
            log.error("Local root does not exist: %s", self.root)
            return False
        log.info("Reading the deployed code from %s (no GitLab connection needed).", self.root)
        return True

    # ------------------------------------------------------------ files
    def load_tree(self, keep=None) -> Dict[str, str]:
        """`relative path -> text` for every .yml/.yaml/.json under the root.

        Paths are relative to the root and use forward slashes, so the
        folder-name discovery downstream behaves exactly as it does for the
        GitLab archive.
        """
        if self._files is None:
            files: Dict[str, str] = {}
            n_seen = n_skipped = 0
            for dirpath, dirnames, filenames in os.walk(self.root):
                dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
                for name in filenames:
                    if not is_wanted_file(name):
                        continue
                    n_seen += 1
                    full = os.path.join(dirpath, name)
                    try:
                        if os.path.getsize(full) > MAX_BYTES:
                            n_skipped += 1
                            continue
                        with open(full, "r", encoding="utf-8", errors="replace") as fh:
                            text = fh.read()
                    except Exception as e:
                        n_skipped += 1
                        log.warning("Could not read %s: %s", full, e)
                        continue
                    rel = os.path.relpath(full, self.root).replace(os.sep, "/")
                    files[rel] = text
            self._files = files
            log.info("Loaded %d file(s) from disk (%d seen, %d skipped).",
                     len(files), n_seen, n_skipped)
            self._log_layout(files)
        return {k: v for k, v in self._files.items() if keep is None or keep(k)}

    @staticmethod
    def _log_layout(files: Dict[str, str]) -> None:
        """Says what was actually found, so a layout mismatch is obvious
        rather than showing up as an empty, apparently clean, report."""
        from collections import Counter
        found = Counter()
        for p in files:
            parts = p.split("/")
            for name in ("input_data_config_dummy", "sql_column_mapping"):
                if name in parts[:-1]:
                    found[name] += 1
        for name in ("input_data_config_dummy", "sql_column_mapping"):
            n = found.get(name, 0)
            if n:
                sample = next(p for p in files if name in p.split("/")[:-1])
                log.info("  '%s': %d file(s), e.g. %s", name, n, sample)
            else:
                log.error("  '%s': NO files found under the local root. Check the deployment "
                          "path.", name)
