"""
The CID analysis as ONE Airflow task.

These files are deployed to  /opt/airflow/dags/nlg/src/cid.  The DAG file
stays almost untouched -- two lines:

    from nlg.src.cid import build_task

    cid_analysis = build_task()
    chain(start_nlg, cid_analysis, nlg_latest_odm_insights, ...)

That needs `__init__.py` in `nlg/src/` and `nlg/src/cid/`; both are in this
bundle. Every module here imports its siblings relatively first and falls
back to a flat import, so the same files also run as loose modules from the
notebook, with no package at all.

Everything else lives here, so the DAG keeps its existing shape and nothing
about it has to be understood to maintain the check.

**One task, not two.** It runs the analysis, writes both reports, emails
them, and only then raises. Sending the report before raising is what makes
a single task work: the attachment exists whether the outcome is a pass, a
finding, or an error, and Airflow's own `email_on_failure` (already set in
this DAG's `default_args`) then sends the failure alert on top.

The branch for nlg_dummy2 comes from, in order:
    1. the DAG-run configuration     {"branch": "feature/my-change"}
    2. a `branch` Param on the DAG, if one is defined
    3. nothing -> the task fails with a clear message
nlg_dummy ignores all of it and always uses develop.
"""
from __future__ import annotations

import os
from typing import List, Optional

# Where the reports and the run log are written. The module's own directory
# by default; CID_HOME overrides it if they should go elsewhere.
CID_HOME = os.getenv("CID_HOME", os.path.dirname(os.path.abspath(__file__)))
HERE = CID_HOME

# The deployed source tree: the parent of this `cid` folder, i.e.
# /opt/airflow/dags/nlg/src. Derived rather than hardcoded so a move of the
# whole tree needs no edit; CID_LOCAL_ROOT overrides it.
DEFAULT_LOCAL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Imports work BOTH ways: as a package member (from nlg.src.cid import ...)
# and as loose modules on sys.path (the notebook). Relative is tried first
# so the package form does not depend on the folder being on sys.path.
try:
    from .cid_main import run_cid_analysis
except ImportError:                     # loaded as loose modules
    from cid_main import run_cid_analysis  # type: ignore
try:
    from .cid_settings import CidSettings, get_logger, setup_logging, writable_dir
except ImportError:                     # loaded as loose modules
    from cid_settings import (CidSettings, get_logger, setup_logging,   # type: ignore
                              writable_dir)

DEFAULT_RECIPIENTS = ["pratik.shah.2@ubs.com"]

XCOM_XLSX = "cid_xlsx_path"
XCOM_HTML = "cid_html_path"
XCOM_SUMMARY = "cid_summary"
XCOM_NEEDS_REVIEW = "cid_needs_review"


def _recipients() -> List[str]:
    raw = os.getenv("CID_EMAIL_RECIPIENTS", "")
    if not raw:
        try:
            from airflow.models import Variable        # type: ignore
            raw = Variable.get("CID_EMAIL_RECIPIENTS", default_var="") or ""
        except Exception:
            raw = ""
    out = [r.strip() for r in raw.split(",") if r.strip()]
    return out or DEFAULT_RECIPIENTS


def _env_label() -> str:
    """Dev / Prod, for the subject line."""
    try:
        from airflow.configuration import conf         # type: ignore
        from airflow.models import Variable            # type: ignore
        base = conf.get("webserver", "base_url")
        if base == Variable.get("AIRFLOW_UAT_URL", default_var=""):
            return "Dev"
        if base == Variable.get("AIRFLOW_PROD_URL", default_var=""):
            return "Prod"
    except Exception:
        pass
    return "Unknown"


def _resolve_branch(context) -> Optional[str]:
    conf = {}
    dag_run = context.get("dag_run")
    if dag_run is not None and getattr(dag_run, "conf", None):
        conf = dag_run.conf or {}
    for key in ("branch", "input_branch", "feature_branch"):
        if conf.get(key):
            return str(conf[key]).strip()
    params = context.get("params") or {}
    for key in ("branch", "input_branch", "feature_branch"):
        if params.get(key):
            return str(params[key]).strip()
    return None


def _send_report(subject: str, body_html: str, files: List[str], log) -> None:
    """Emails the report. Never raises -- a mail problem must not hide the
    analysis result, which the task is about to report anyway."""
    try:
        from airflow.utils.email import send_email     # type: ignore
        send_email(to=_recipients(), subject=subject, html_content=body_html, files=files)
        log.info("CID report emailed to %s (%d attachment(s)).", _recipients(), len(files))
    except Exception as e:
        log.error("Could not send the CID report email: %s", e)


def run_cid_task(**context):
    """Analyse, report, email, then fail if a person needs to look.

    Wrapped so that NOTHING can make this task die without a notification.
    An unexpected error still sends an email saying so -- a silent failure
    is the worst outcome, because the pipeline stops and no one is told why.
    """
    log_path = setup_logging("INFO")
    log = get_logger("cid.task")
    try:
        return _run(context, log, log_path)
    except Exception as exc:
        if isinstance(exc, _Reported):
            raise exc.original
        log.exception("CID analysis failed unexpectedly.")
        try:
            _send_report("CID report [%s] - ERROR - %s"
                         % (_env_label(), _dag_id(context) or "cid_analysis"),
                         "<br>Hi Team,<br><br><b>The CID analysis task failed before it could "
                         "produce a report.</b><br><br>%s<br>" % _e(exc), [], log)
        except Exception:
            log.error("Could not send the failure email either.")
        raise


class _Reported(Exception):
    """Carries an exception that has already been emailed."""

    def __init__(self, original):
        Exception.__init__(self, str(original))
        self.original = original


def _e(x):
    import html
    return html.escape(str(x))


def _dag_id(context):
    dag = context.get("dag")
    return getattr(dag, "dag_id", "") or os.getenv("AIRFLOW_CTX_DAG_ID", "")


def _run(context, log, log_path):

    dag_id = _dag_id(context) or (context.get("params") or {}).get("dag_id", "")
    branch = _resolve_branch(context)
    log.info("CID analysis starting for DAG '%s' (reading the deployed code on this worker).",
             dag_id)

    s = CidSettings()
    s.dag_id = dag_id
    s.input_branch = branch
    # The deployment folder is normally read-only on a worker, so reports go
    # to the first writable location instead of failing the task for a
    # reason that has nothing to do with the check.
    s.output_dir = writable_dir(HERE)
    log.info("Reports will be written to %s", s.output_dir)
    # A DAG run analyses the code that is deployed on this worker, so it
    # reads from disk. No GitLab connection and no token are involved.
    s.source = "local"
    s.local_root = os.getenv("CID_LOCAL_ROOT", DEFAULT_LOCAL_ROOT)

    outcome = run_cid_analysis(s, interactive=False)
    res = outcome.result

    ti = context["ti"]
    ti.xcom_push(key=XCOM_XLSX, value=outcome.xlsx_path)
    ti.xcom_push(key=XCOM_HTML, value=outcome.html_path)
    ti.xcom_push(key=XCOM_SUMMARY, value=outcome.summary())
    ti.xcom_push(key=XCOM_NEEDS_REVIEW, value=bool(outcome.failed))
    ti.xcom_push(key="cid_log_path", value=log_path)

    # ---- email, always, before any raise ----
    files = [p for p in (outcome.xlsx_path, outcome.html_path) if p and os.path.exists(p)]
    if outcome.error:
        status = "ERROR"
        detail = "<b>The analysis could not complete.</b><br><br>%s" % outcome.error
    elif outcome.failed:
        status = "ACTION REQUIRED"
        detail = ("<b>%s</b><br><br>The task has been failed so this is reviewed before the "
                  "change goes further." % res.fail_reason)
    else:
        status = "passed"
        detail = "Nothing flagged and no new columns."

    subject = "CID report [%s] - %s - %s (%s)" % (
        _env_label(), status, dag_id, (res.branch if res else branch) or "?")
    body = ("<br>Hi Team,<br><br>%s<br><br>%s<br><br>"
            "<b>Reports attached.</b><br>" % (detail, outcome.summary()))
    _send_report(subject, body, files, log)

    # ---- then decide the task's fate ----
    if outcome.error:
        raise _Reported(RuntimeError("CID analysis could not complete: %s" % outcome.error))

    if outcome.failed:
        parts = ["CID analysis needs human review on branch '%s': %s. Reports are attached to "
                 "the notification email." % (res.branch, res.fail_reason)]
        if res.flagged:
            parts += ["", "Flagged:"]
            parts += ["  %s | %s | %s" % (f.rule, f.column, f.file_path)
                      for f in res.flagged[:20]]
            if len(res.flagged) > 20:
                parts.append("  ... and %d more" % (len(res.flagged) - 20))
        if res.new_column_count:
            parts += ["", "New column(s) awaiting a CID decision:"]
            for tbl in sorted(res.new_columns):
                parts.append("  %s: %s" % (tbl, ", ".join(sorted(res.new_columns[tbl]))))
        raise _Reported(RuntimeError("\n".join(parts)))

    log.info("CID analysis passed: nothing flagged and no new columns.")


def build_task(task_id: str = "cid_analysis", dag=None, **operator_kwargs):
    """The operator to wire in after `start_nlg`.

    The PythonOperator import is tried both ways so this works whether the
    DAG file uses the modern path or the older `python_operator` one, which
    is what the existing nlg_dummy2 file imports.
    """
    try:
        from airflow.operators.python import PythonOperator        # type: ignore
    except ImportError:                                            # pragma: no cover
        from airflow.operators.python_operator import PythonOperator   # type: ignore

    kwargs = dict(task_id=task_id, python_callable=run_cid_task, provide_context=True)
    kwargs.update(operator_kwargs)
    if dag is not None:
        kwargs["dag"] = dag
    try:
        return PythonOperator(**kwargs)
    except TypeError:
        # Airflow 2 removed provide_context; context is passed automatically
        kwargs.pop("provide_context", None)
        return PythonOperator(**kwargs)
