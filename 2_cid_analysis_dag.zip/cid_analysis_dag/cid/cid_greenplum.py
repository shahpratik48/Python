"""
Greenplum access: the CID column list, and the schema comparison.

Two very different reads:

  * the CID metadata table, ALWAYS from production `core_ikg` -- a dev copy
    of "which columns are client-identifying" would make the check
    meaningless;
  * profile-table columns from the schema under test and from production, to
    find columns that exist in one and not the other.

Both are single round trips over `information_schema`, filtered to BASE
TABLEs. Views are excluded deliberately: a view's columns are a projection
of a table's, so counting them would report the same new column several
times over.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Sequence, Set, Tuple

# Imports work BOTH ways: as a package member (from nlg.src.cid import ...)
# and as loose modules on sys.path (the notebook). Relative is tried first
# so the package form does not depend on the folder being on sys.path.
try:
    from .cid_settings import CID_METADATA_SCHEMA, CID_METADATA_TABLE, get_logger
except ImportError:                     # loaded as loose modules
    from cid_settings import CID_METADATA_SCHEMA, CID_METADATA_TABLE, get_logger  # type: ignore

log = get_logger("cid.greenplum")


def connect(settings):
    """A connection from the resolved settings.

    The credentials were already resolved once, in CidSettings -- from the
    Airflow connection inside a DAG, or from the environment outside one.
    Deciding again here would mean two places could disagree about which
    database is being read.
    """
    import psycopg2
    log.info("Connecting to Greenplum %s:%s/%s as %s.",
             settings.gp_host, settings.gp_port, settings.gp_db, settings.gp_user)
    return psycopg2.connect(host=settings.gp_host, port=settings.gp_port,
                            dbname=settings.gp_db, user=settings.gp_user,
                            password=settings.gp_password, connect_timeout=30)


def load_cid_columns(conn) -> Dict[str, dict]:
    """`column_name -> row` for every column flagged is_cid = 'Y'.

    Read from production regardless of which schema is being analysed.
    """
    sql = ("SELECT * FROM {s}.{t} WHERE upper(trim(is_cid)) = 'Y'"
           .format(s=CID_METADATA_SCHEMA, t=CID_METADATA_TABLE))
    cur = conn.cursor()
    log.info("Reading CID metadata: %s", sql)
    cur.execute(sql)
    cols = [d[0].lower() for d in cur.description]
    out: Dict[str, dict] = {}
    # `cid_profile_column` is the name this table actually uses; the others
    # are kept so an older or differently-named deployment still works.
    name_col = next((c for c in ("cid_profile_column", "column_name", "col_name",
                                 "column_nm", "attribute_name") if c in cols), cols[0])
    for row in cur.fetchall():
        rec = dict(zip(cols, row))
        name = str(rec.get(name_col) or "").strip().lower()
        if name:
            out[name] = rec
    log.info("CID metadata: %d column(s) marked is_cid = 'Y' (name column: '%s').",
             len(out), name_col)
    if not out:
        log.warning("No CID columns found. Steps 3 and 4 will report nothing -- check that "
                    "%s.%s is populated.", CID_METADATA_SCHEMA, CID_METADATA_TABLE)
    return out


def load_table_columns(conn, schema: str, tables: Sequence[str]) -> Dict[str, Dict[str, str]]:
    """`table -> {column: data type}` for BASE TABLEs only, in one query.

    The data type comes along for free and is worth having: a reviewer
    deciding whether a new column is client-identifying wants to know
    whether it is a 20-character text field or a numeric flag.
    """
    names = sorted({t.split(".")[-1].strip().lower() for t in tables if t})
    if not names:
        return {}
    sql = ("SELECT c.table_name, c.column_name, c.data_type, "
           "       coalesce(c.character_maximum_length, c.numeric_precision) "
           "FROM information_schema.columns c "
           "JOIN information_schema.tables t "
           "  ON t.table_schema = c.table_schema AND t.table_name = c.table_name "
           "WHERE c.table_schema = %s AND c.table_name = ANY(%s) "
           "  AND t.table_type = 'BASE TABLE'")
    cur = conn.cursor()
    cur.execute(sql, (schema, names))
    out: Dict[str, Dict[str, str]] = {}
    for tbl, col, dtype, length in cur.fetchall():
        label = str(dtype or "")
        if length:
            label = "%s(%s)" % (label, length)
        out.setdefault(str(tbl).lower(), {})[str(col).lower()] = label
    log.info("Schema '%s': %d of %d requested table(s) found (base tables only).",
             schema, len(out), len(names))
    missing = [n for n in names if n not in out]
    if missing:
        log.info("  not present in '%s': %s%s", schema, ", ".join(missing[:8]),
                 " ..." if len(missing) > 8 else "")
    return out


def compare_schemas(conn, compare_schema: str, tables: Sequence[str]):
    """(new_columns, cmp_cols, prod_cols) per profile table.

    "New" means present in the schema under test and absent from production
    -- a column somebody has added but that production has not yet seen,
    which is exactly the population that needs a CID decision.
    """
    cmp_cols = load_table_columns(conn, compare_schema, tables)
    prod_cols = load_table_columns(conn, CID_METADATA_SCHEMA, tables)
    new: Dict[str, Set[str]] = {}
    for tbl, cols in cmp_cols.items():
        base = prod_cols.get(tbl)
        if base is None:
            # the table itself is new; every column is new, but that is worth
            # saying plainly rather than burying in a long column list
            log.info("Table '%s' exists in '%s' but not in '%s' -- treating all %d column(s) "
                     "as new.", tbl, compare_schema, CID_METADATA_SCHEMA, len(cols))
            new[tbl] = set(cols)
            continue
        diff = set(cols) - set(base)
        if diff:
            new[tbl] = diff
    total = sum(len(v) for v in new.values())
    log.info("Schema comparison: %d new column(s) across %d table(s) in '%s' vs '%s'.",
             total, len(new), compare_schema, CID_METADATA_SCHEMA)
    for tbl in sorted(new):
        log.info("  %-52s %s", tbl, ", ".join(sorted(new[tbl])))
    return new, cmp_cols, prod_cols
