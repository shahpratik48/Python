"""
Reading the anonymisation function, and resolving its table names.

`nlg_main_class.py` holds a function that copies real tables into the dummy
schema and then hashes the sensitive columns:

    update {schema_nlg}.{self.si_nlg_settings['ref_tbl_pilot_fa_mhh_map']}
       set client_name = ... md5(...) ...,
           ip_frst_x   = ... md5(...) ...

Two things are taken from it:

  * the TABLES being anonymised -- named indirectly, through a settings key
    that `nlg_db_tables.ini` maps to a real table name, per environment;
  * the COLUMNS in each `SET` clause -- by definition the ones the team has
    already decided are client-identifying, since they are being hashed.

Together they say "these tables hold CID, and these are the CID columns",
which is exactly what the two metadata tables are meant to record. Reading
it from the code rather than maintaining the list by hand means the metadata
cannot drift away from what the pipeline actually does.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple

try:
    from .cid_settings import get_logger
except ImportError:                     # loaded as loose modules
    from cid_settings import get_logger  # type: ignore

log = get_logger("cid.anonymize")

ANON_FUNC = "pre_nlg_sync_fa_ta_mhh_map_tabl_anonymize_for_dummy"
MAIN_CLASS_FILE = "nlg_main_class.py"
DB_TABLES_FILE = "nlg_db_tables.ini"

# nlg_dummy runs the dev_dummy environment, nlg_dummy2 the dev_dummy2 one
SECTION_FOR_DAG = {"nlg_dummy": "dev_dummy", "nlg_dummy2": "dev_dummy2"}


@dataclass
class AnonymiseFindings:
    section: str = ""
    tables: Dict[str, str] = field(default_factory=dict)    # settings key -> table
    columns: Set[str] = field(default_factory=set)          # masked in a SET clause
    unresolved: List[str] = field(default_factory=list)     # keys absent from the ini
    per_table_columns: Dict[str, Set[str]] = field(default_factory=dict)


# ---------------------------------------------------------------- the ini
def parse_ini(text: str, section: str) -> Dict[str, str]:
    """`variable -> table name` for one section.

    Hand-rolled rather than configparser: these files are written with
    Windows line endings and occasional duplicate keys, both of which
    configparser objects to, and the format is simple enough that being
    lenient costs nothing.
    """
    out: Dict[str, str] = {}
    wanted = False
    for raw in (text or "").splitlines():
        line = raw.strip()
        if not line or line.startswith((";", "#")):
            continue
        if line.startswith("[") and line.endswith("]"):
            wanted = line[1:-1].strip().lower() == section.lower()
            continue
        if not wanted or "=" not in line:
            continue
        k, v = line.split("=", 1)
        k, v = k.strip().lower(), v.strip()
        if k and v:
            out[k] = v
    log.info("Section [%s]: %d variable(s) mapped to table names.", section, len(out))
    return out


# ---------------------------------------------------------------- the function
def extract_function(source: str, name: str = ANON_FUNC) -> str:
    """The body of one method, by indentation.

    Located textually rather than with `ast`: the file imports the whole NLG
    stack at module level, so importing it here is neither possible nor
    desirable, and the body is only ever read as text.
    """
    m = re.search(r"^([ \t]*)def\s+%s\s*\(" % re.escape(name), source or "", re.M)
    if not m:
        return ""
    indent = len(m.group(1))
    lines = (source or "").splitlines()
    start = source[:m.start()].count("\n")
    body = [lines[start]]
    for line in lines[start + 1:]:
        if line.strip() and (len(line) - len(line.lstrip())) <= indent:
            break
        body.append(line)
    return "\n".join(body)


_UPDATE = re.compile(
    r"update\s+(?:\{[^}]*\}\s*\.\s*)?\{\s*self\.si_nlg_settings\[\s*['\"]([a-zA-Z_0-9]+)['\"]\s*\]\s*\}",
    re.I)
_SET_COL = re.compile(r"(?:^|,)\s*([a-zA-Z_][\w$]*)\s*=", re.M)


def _set_clause(block: str) -> str:
    """The text between SET and the end of the statement."""
    m = re.search(r"\bset\b", block, re.I)
    if not m:
        return ""
    tail = block[m.end():]
    stop = re.search(r"\bwhere\b|;", tail, re.I)
    return tail[:stop.start()] if stop else tail


def _columns_in_set(clause: str) -> Set[str]:
    """Assignment targets only.

    A CASE expression repeats the column on its right-hand side, and a
    comma inside `substring(md5(x),1,8)` looks like an assignment separator,
    so the text is masked before scanning: parenthesised groups are blanked,
    leaving only the top-level `column =` positions.
    """
    flat, depth = [], 0
    for ch in clause:
        if ch == "(":
            depth += 1
            flat.append(" ")
        elif ch == ")":
            depth -= 1
            flat.append(" ")
        else:
            flat.append(" " if depth > 0 else ch)
    masked = "".join(flat)
    cols = set()
    for m in _SET_COL.finditer(masked):
        w = m.group(1).lower()
        if w not in ("case", "when", "then", "else", "end", "set", "and", "or", "not"):
            cols.add(w)
    return cols


def analyse_anonymise_function(main_class_src: str, ini_text: str,
                               dag_id: str) -> AnonymiseFindings:
    """Tables and masked columns from the anonymise function."""
    section = SECTION_FOR_DAG.get(dag_id, "")
    res = AnonymiseFindings(section=section)
    if not section:
        log.error("No nlg_db_tables.ini section is defined for DAG %r; expected one of %s.",
                  dag_id, ", ".join(sorted(SECTION_FOR_DAG)))
        return res

    body = extract_function(main_class_src)
    if not body:
        log.error("Could not find def %s() in %s.", ANON_FUNC, MAIN_CLASS_FILE)
        return res
    log.info("Read def %s() -- %d line(s).", ANON_FUNC, body.count("\n") + 1)

    mapping = parse_ini(ini_text, section)

    for m in _UPDATE.finditer(body):
        key = m.group(1).lower()
        # the statement runs to the closing triple quote, or the next update
        rest = body[m.end():]
        end = re.search(r'"""|\bupdate\s+\{', rest, re.I)
        block = rest[:end.start()] if end else rest

        table = mapping.get(key)
        if not table:
            if key not in res.unresolved:
                res.unresolved.append(key)
            log.warning("  update target '%s' has no entry in section [%s]; the table cannot "
                        "be named.", key, section)
        else:
            res.tables[key] = table

        cols = _columns_in_set(_set_clause(block))
        res.columns |= cols
        if table:
            res.per_table_columns.setdefault(table, set()).update(cols)

    log.info("Anonymise function: %d table(s), %d masked column(s)%s.",
             len(res.tables), len(res.columns),
             "; %d unresolved key(s)" % len(res.unresolved) if res.unresolved else "")
    for key in sorted(res.tables):
        log.info("  %-42s -> %s", key, res.tables[key])
    if res.columns:
        log.info("  masked columns: %s", ", ".join(sorted(res.columns)))
    return res


def find_file(files: Dict[str, str], name: str) -> Tuple[str, str]:
    """(path, text) for a file located by NAME anywhere in the tree."""
    for path, text in files.items():
        if path.rsplit("/", 1)[-1].lower() == name.lower():
            return path, text
    return "", ""
