"""
nlg.src.cid -- CID analysis for the nlg_dummy / nlg_dummy2 pipelines.

    from nlg.src.cid import build_task
    cid_analysis = build_task()

Every module here imports its siblings relatively first and falls back to a
flat import, so the same files also run as loose modules from the notebook,
where there is no package at all.
"""
try:
    from .cid_task import build_task, run_cid_task      # noqa: F401
except ImportError:                                     # loaded as loose modules
    from cid_task import build_task, run_cid_task       # type: ignore  # noqa: F401

__all__ = ["build_task", "run_cid_task"]
