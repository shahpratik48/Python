# CID analysis — how it works

Checks a branch of **nlg-dags** for client-identifying data (CID) that is exposed without masking,
and fails the pipeline when it finds any, so a person reviews the change.

---

## Flow

```
                    ┌──────────────────────────────┐
                    │  start_nlg  (existing task)  │
                    └──────────────┬───────────────┘
                                   │
                    ┌──────────────▼───────────────┐
                    │        cid_analysis          │
                    └──────────────┬───────────────┘
                                   │
   STEP 1  which DAG am I?  ───────┤
           nlg_dummy   → branch = develop        → schema = IKG_PRE_PROD_SCHEMA (UAT)
           nlg_dummy2  → branch = user input     → schema = IKG_SCHEMA          (Dev)
           blank branch on nlg_dummy2 → FAIL with a clear message
                                   │
   STEP 2  CID columns      ───────┤   core_ikg.cid_columns_metadata_manual_refresh
           (always production)     │   WHERE is_cid = 'Y'
                                   │
                    ┌──────────────▼───────────────┐
                    │  pull the branch ONCE as a   │
                    │  tar.gz archive (≈500 files) │
                    └──────────────┬───────────────┘
                                   │
        ┌──────────────────────────┼──────────────────────────┐
        │                          │                          │
   STEP 3                     STEP 4                     STEP 5
   sql_column_mapping         input_data_config_dummy    schema comparison
        │                          │                          │
   any CID column use         CID column used            columns in the schema
   is a FINDING               WITHOUT MD5 is a           under test but not in
                              FINDING                    core_ikg  →  "new"
   (narrative text a          (hashed use is                    │
    person reads)              recorded, not flagged)           │
                                                    ┌───────────┴───────────┐
                                                    │                       │
                                              new column IS CID       new column not CID
                                                    │                       │
                                              re-run steps 3 & 4       still reported,
                                              on it → FINDING          with how it is used
        └──────────────────────────┼──────────────────────────┘
                                   │
   STEP 7  anonymise function ─────┤   def pre_nlg_sync_..._anonymize_for_dummy()
           tables  -> resolved via nlg_db_tables.ini  [dev_dummy] / [dev_dummy2]
           columns -> the SET clause of each UPDATE
           reconcile core_ikg.cid_tables_metadata_manual_refresh
                 and core_ikg.cid_columns_metadata_manual_refresh
           then compare every CID table: dummy vs production
                                   │
   STEP 6  anything to review? ────┤
           any FLAG                       → task FAILS
           OR any NEW COLUMN at all       → task FAILS
           OR any METADATA change         → task FAILS
           OR any new column in a CID tbl → task FAILS
           none of these                  → task passes
                                   │
                    ┌──────────────▼───────────────┐
                    │  cid_email                   │  trigger_rule = all_done
                    │  sends XLSX + HTML always    │  (pass, fail or error)
                    └──────────────────────────────┘
```

---

## How the files are found and read

### Two sources, one interface

| Run | Source |
|---|---|
| **DAG** | the deployment on the worker, `/opt/airflow/dags/nlg/src`, read from disk |
| **Notebook** | the GitLab branch, downloaded once as an archive |

A DAG analyses the code that is about to run, so reading it from disk is both faster and *more
correct* — cloning a branch back could analyse a different revision. `LocalRepo` and `GitLabRepo`
present the same `load_tree()` call, so discovery, scanning and the rules are identical either way
and neither path is a special case.

A DAG run needs **no GitLab token**.

### Found by name, at any depth

The whole branch archive is read and the two folders located by **directory name**, wherever they
sit:

```
src/config/input_data_config_dummy/account.yml            found
repo/x/y/src/config/input_data_config_dummy/account.yml   found
src/sql_column_mapping/account/rmd/si_rmd_owned.yml       found  (nested)
```

Fixed path prefixes were the earlier mistake: they assume a layout, and one extra directory level
makes the scan match nothing — which is indistinguishable from a clean result. The run now logs what
it found, and says so loudly when a folder yields nothing:

```
'input_data_config_dummy': 46 file(s), e.g. src/config/input_data_config_dummy/account.yml
'sql_column_mapping': 470 file(s), e.g. src/sql_column_mapping/account/rmd/si_rmd_owned.yml
```

### Which files are read

`.yml`, `.yaml` and `.json` throughout the tree, **plus two files needed by name**:

| File | Where | Why |
|---|---|---|
| `nlg_main_class.py` | `nlg/src` | holds the anonymise function read in step 7 |
| `nlg_db_tables.ini` | `nlg/src/config` | maps settings keys to real table names |

Neither is YAML, so an earlier version filtered them out by extension and step 7 silently had nothing
to work with. A missing one is now a **flagged finding**, not a footnote — a report that merely looks
empty is indistinguishable from a clean one.

The YAML rule proper: `.yml`, `.yaml` **and `.json`**. The reference tree has 139 JSON mapping files carrying exactly the
same shape, so reading only YAML left a large blind spot.

```json
{ "primary_position_type_old": "b.wx_value_prev as primary_position_type_old" }
```

### The two file patterns

**`input_data_config_dummy/<target_type>.yml`** — flat folder, one file per target type, with the
expressions nested under `sql_column_mapping`:

```yaml
account:
  input_db_join_col: acc_i
  sql_column_mapping:
    target_id:  b.acc_mhh_n::text
    ip_frst_x:  substring(MD5(b.ip_frst_x),1,8)
```

**`sql_column_mapping/<target_type>/[<sub>/]<insight_type>.yml|.json`** — nested one or two levels, a
flat map:

```yaml
data_asof_d: b.data_asof_d
comp_set_with_event_name: >-
  case when b.comp_set = 'Target' then b.company_sec_name_short else b.comp_set end
    as comp_set_with_event_name
```

In both, the **key is an output name** and the **value is a SQL expression**. Every leaf is walked, so
both shapes are handled without the code needing to know which it is reading.

### Columns come from parsing the expression, not the key

| Expression | Columns |
|---|---|
| `b.acc_mhh_n::text` | `acc_mhh_n` |
| `substring(MD5(b.ip_frst_x),1,8)` | `ip_frst_x` |
| `(b.profile_date::date - interval '3' day) as profile_date` | `profile_date` |
| `case when b.comp_set = 'Target' then b.company_sec_name_short else b.comp_set end as comp_set_with_event_name` | `comp_set`, `company_sec_name_short` |
| `'acc_i' as key_name` | *(none — a literal)* |

Matching the **keys** would miss the underlying column whenever it is renamed — `ip_frst_x_real`,
`hh_lead_account_title`, `target_id` — which is common in these files.

A trailing `AS <name>` is excluded: that name is being defined, not read. Left in, `'acc_i' as
key_name` would report `key_name` as a column, and any alias sharing a CID column's name would raise
a false finding.

Keywords, function names and cast targets are filtered out, so `case`, `substring` and `text` do not
appear as columns.

**A sanity check runs every time**: after discovery the parser reports how many distinct column names
it read. Files found but zero columns parsed is treated as an error, because it means the format has
changed rather than that the branch is clean.

## Step 7 — the anonymise function and the CID metadata

`nlg_main_class.py` holds `pre_nlg_sync_fa_ta_mhh_map_tabl_anonymize_for_dummy()`, which copies real
tables into the dummy schema and hashes the sensitive columns:

```sql
update {schema_nlg}.{self.si_nlg_settings['ref_tbl_pilot_fa_mhh_map']}
   set client_name = ... md5(...) ...,
       ip_frst_x   = ... md5(...) ...
```

Two things come out of it:

| From | How |
|---|---|
| **Tables** | the settings key in each `UPDATE` is resolved through `nlg_db_tables.ini` — section `[dev_dummy]` for `nlg_dummy`, `[dev_dummy2]` for `nlg_dummy2` |
| **Columns** | every assignment target in the `SET` clause |

A table or column here is client-identifying **by definition** — the team is already hashing it. So
each run reconciles the code against the metadata:

| State | Action |
|---|---|
| in the code, absent from the table | `INSERT` with `is_cid = 'Y'` |
| in both, but recorded as `N` | `UPDATE` to `'Y'` |
| in both and already `Y` | left alone |

Every name appears exactly once; nothing is inserted twice. Reading the list from the code rather
than maintaining it by hand is what stops the metadata drifting away from what the pipeline does.

### If the metadata cannot be written

Reading `core_ikg` and writing to it are separate grants, and the connection often has only the
first. When an `INSERT` or `UPDATE` is refused the run does **not** fall silent: the analysis is
already complete, so every intended change is reported as **NOT WRITTEN — permission denied**, and
the log prints the grant required:

```
GRANT INSERT, UPDATE ON core_ikg.cid_tables_metadata_manual_refresh  TO <the connection's user>;
GRANT INSERT, UPDATE ON core_ikg.cid_columns_metadata_manual_refresh TO <the connection's user>;
```

The task still fails, and the report still names every table and column that needs adding — so the
work is usable even before the grant exists.

### Then two comparisons

1. **Every table recorded as CID** — new or long-standing — has its columns compared between the
   schema under test and production. Anything present in one and not the other is flagged: somebody
   must decide whether it is client-identifying and whether the anonymise function masks it.
2. **A table newly recorded as CID** has *all* of its columns listed, because none of them has ever
   been reviewed.

Both land on the **CID tables** sheet, with a column saying whether the anonymise function already
hashes each one. The metadata changes themselves appear there and on the **New columns** sheet.

## The rules, and why they differ

| Folder | Rule | Reason |
|---|---|---|
| `sql_column_mapping` | flagged where the value **reaches narrative text** unmasked | these expressions build the text a person reads |
| `input_data_config_dummy` | flagged where the value is **selected** unmasked | this layer may carry CID columns provided they are hashed |

Both now turn on the same question — *does the value reach the output?* — rather than on mere
presence. A CID column used only to partition or compare is reported as informational in both
folders, never flagged.

### Masking is only required where the value is EXPOSED

A CID column leaks only when its **value reaches the output**. Using it to filter, count, group,
compare or order reveals nothing, so those uses are not findings:

```sql
case when b.x > 0 then b.x else b.y end
```

`b.x` appears twice and the two are treated differently:

| Occurrence | Context | Verdict |
|---|---|---|
| `when b.x > 0` | a test — the reader sees only whether it passed | **no masking needed** |
| `then b.x` | the returned value | **must be hashed** |

So the fix is `case when b.x > 0 then MD5(b.x) else b.y end` — *not* masking the comparison, which
would change what the test does.

**Contexts that need no masking**

| Context | Example |
|---|---|
| `COUNT()`, `LENGTH()`, `ARRAY_LENGTH()`, `POSITION()` and similar | `count(b.acc_i)` |
| `PARTITION BY` | `OVER (PARTITION BY b.acc_mhh_n)` |
| `ORDER BY` / `GROUP BY` | `order by b.ip_frst_x` |
| `WHERE` / `HAVING` / `FILTER (WHERE …)` / join `ON` | `filter (where b.ip_cli_i = '1')` |
| A `CASE WHEN` condition | `when b.x is not null` |
| Either operand of a comparison | `b.x > 0`, `b.x = 'a'`, `b.x in (…)`, `b.x is null` |

**The output alias is not a use of the column.** An alias very often repeats the column it came
from, and counting it as a second occurrence makes a correctly hashed expression look like an
unmasked exposure:

```sql
substring(MD5(b.lead_acc_title),1,8) as lead_acc_title          -- clean
'https://' || MD5(REPLACE(b.znfo_scoop_url,'https://','')) as znfo_scoop_url   -- clean
replace(substring(MD5(b.t12_brk_acc_lst),1,8), ',', ';') t12_brk_acc_lst       -- clean
```

The trailing alias is stripped before any occurrence is examined, with or without the `AS` keyword.
A bare alias is only recognised where the expression before it is clearly complete — it ends in a
closing paren, a string literal or `END` — so a plain `b.ip_last_x` never has its own name stripped.

This does **not** weaken the check. The value still has to be hashed wherever it is genuinely
returned:

```sql
CASE WHEN b.linkedin_url is not null
     THEN substring(MD5(b.linkedin_url),1,8)
     ELSE b.linkedin_url END as linkedin_url        -- still FLAGGED: the ELSE returns it raw
```

**Contexts that do expose the value**: a bare selection, a `THEN`/`ELSE` result,
`STRING_AGG`, `MAX`/`MIN`, `COALESCE`, `SUBSTRING`, `UPPER`/`TRIM`/`INITCAP`, string concatenation —
anything whose output carries the value itself.

Each occurrence is classified innermost-outwards, because the closest context wins: a column inside
`count()` is safe no matter what surrounds the call. The report's **Why** column carries the reason
for every row, and **Exposure** says how many occurrences reach the output and how many of those are
unmasked.

On the reference tree this is the difference between a report nobody can act on and one that is
usable: the same CID list produced **202 real findings** rather than 658, with the remainder recorded
as informational and explained — 196 `PARTITION BY`, 141 already hashed, 112 `CASE WHEN` conditions,
27 inside `COUNT()`.

### Masking is parsed, not pattern-matched

```
ip_frst_x:      substring(MD5(b.ip_frst_x),1,8)     masked
ip_frst_x_real: b.ip_frst_x                         NOT masked
mixed:          MD5(b.a) || b.ip_frst_x             NOT masked
```

The third case is why a substring search for `"md5"` is not good enough — the expression contains
`MD5`, but one of the two uses is bare, and one bare use is enough to leak the value. The scanner
finds each occurrence of the column and checks whether **that occurrence** sits inside a hashing
call; masking counts only when **every** occurrence does.

Recognised as masking: `md5`, `sha1`/`224`/`256`/`384`/`512`, `hashtext`, `encode`, `digest`.

Column matching is whole-word, so `acc_i` does not match inside `acc_i_asset_key`.

---

## Step 5 in detail

1. The profile table behind each `input_data_config_dummy` file is looked up in
   `src/config/odm_profile_map/profile_tbl.yaml` (`target_type → profile_table_name`).
2. Columns for those tables are read from the schema under test and from `core_ikg`, in **one query
   each**, restricted to `BASE TABLE` — views are excluded because a view's columns are a projection
   of a table's, and counting them would report the same new column several times.
3. Columns present in the schema under test but absent from production are **new**.
4. A new column that is also `is_cid = 'Y'` gets steps 3 and 4 applied to it.
5. **Every** new column is reported with the profile table and whether the branch already uses it —
   CID or not — because that is the change a reviewer needs to see.

If a table exists in the schema under test but not in production, every one of its columns is treated
as new, and the log says so plainly rather than burying it.

---

## Keys excluded from the masking check

Some YAML keys carry a column name for plumbing rather than for display. `input_db_join_col` names
the join key, which is never rendered, so masking it would break the join without protecting
anything.

Configure with `CID_EXCLUDE_KEYS` (environment variable or Airflow Variable), comma-separated:

```
CID_EXCLUDE_KEYS = input_db_join_col
CID_EXCLUDE_KEYS = input_db_join_col, target_key_conversion, account.some_key
```

An entry matches either the **bare key** or a **`target_type.key`** path:

| Config entry | `account.input_db_join_col` | `other.input_db_join_col` |
|---|---|---|
| `input_db_join_col` | matched | matched |
| `account.input_db_join_col` | matched | not matched |

The bare form matches everywhere because the same key means the same thing whichever target_type it
sits under; requiring the full path would mean listing it once per file. A longer name is never a
partial match — `input_db_join_col_extra` is untouched.

The default is `input_db_join_col`. Excluded expressions are skipped entirely and the count is
logged, so the exemption is visible rather than silent.

## Why a new column fails the task

A new column is not a violation. But **nobody has yet decided whether it is client-identifying**, and
a silent pass would let that decision be skipped — the column would reach production unreviewed.

So the task fails when there is **any** new column, whether or not it is marked CID and whether or
not the branch uses it yet. The failure message lists them by table, and the report's *New columns*
sheet carries the same list with usage.

## Schemas and secrets

| What | Where it comes from |
|---|---|
| CID metadata | **always** `core_ikg` (hardcoded production) |
| Schema compared, `nlg_dummy` | Airflow Variable `IKG_PRE_PROD_SCHEMA` (UAT) |
| Schema compared, `nlg_dummy2` | Airflow Variable `IKG_SCHEMA` (Dev) |
| GitLab token | Airflow Variable `GENESIS_DDLC_IKG_GIT_SECRET` |
| Greenplum | Airflow connection `IKG_GP_GPRDSP` |

In the notebook the token and password are prompted for with hidden input and never stored.
Resolution order everywhere: explicit value → environment variable → Airflow Variable → prompt.

---

## Performance

The job is dominated by file access, so:

- **One archive download** for the whole branch instead of ~500 API calls. If the archive endpoint is
  unavailable the code falls back to per-file fetching in parallel, which is slower but still
  correct.
- **Files are walked once**, matching every CID column per expression, rather than once per column.
  With ~470 mapping files and a long CID list the opposite order is what makes this slow.
- **A cheap pre-filter** skips any file whose text contains none of the column names before the YAML
  is parsed at all.
- **Two metadata queries** for the schema comparison, not one per table.

A full run over the reference tree — 46 config files, 331 mapping files, 43 profile tables — completes
in a couple of seconds once the archive is down.

---

## What the reports contain

Both formats, every run:

| Sheet / section | Contents |
|---|---|
| **Summary** | outcome, DAG, branch, schemas, counts, and the flagged tally by rule |
| **Flagged** | only the findings that fail the task |
| **All findings** | including acceptable masked uses, so the report shows everything examined |
| **New columns** | every new profile column, one row per place it is used, plus the CID metadata changes |
| **CID tables** | columns of CID tables needing a decision, and what changed in the metadata tables |

Each finding row carries: step, severity, rule, column, is-CID, masked, exposure, why, target type,
profile table, **file path**, **YAML key**, the **logic** verbatim, and a note explaining the rule.

### The New columns sheet

Self-contained, so the CID decision can be made without opening another sheet. **One row per new
column per place it is used**, or a single row where it is not used yet:

| Column | Contents |
|---|---|
| Profile Table · Target Type | where the column appeared |
| New Column · **Data Type** | e.g. `character varying(50)` — a 50-char text field and a numeric flag call for very different judgements |
| Is CID | as currently recorded in the metadata table |
| **Status** | `NEEDS FIX` · `CID - ok here` · `review` |
| Used In | `input_data_config_dummy`, `sql_column_mapping`, or `not used in the branch` |
| File Path · YAML Key | exactly where |
| Masked · Exposure · Why | whether the value reaches the output, and the reason |
| Logic | the expression, verbatim |
| **Action** | what to do about this row |

The rows are assembled from the step-5 findings rather than recomputed, so this sheet and the
findings sheets cannot disagree.

---

## Failure behaviour

- **Findings** → `cid_analysis` raises, the task goes red, the pipeline stops. The message names the
  first 20 findings so the cause is visible in the Airflow UI without opening the attachment.
- **An error** (bad branch, no schema variable, database unreachable) → also raises, with a message
  saying which.
- **Either way** `cid_email` still runs (`trigger_rule="all_done"`) and attaches whatever reports
  exist. The reports are written *before* the failure is raised, precisely so this works.
