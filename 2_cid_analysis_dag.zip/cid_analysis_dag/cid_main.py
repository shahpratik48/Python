"""
Orchestration. One entry point shared by the notebook and the DAG.

    run_cid_analysis(settings) -> RunOutcome

The reports are written BEFORE the pass/fail decision is raised, so a
failing run still produces the attachments the email needs. Failing without
evidence would leave whoever is paged with nothing to look at.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import List, Optional

from cid_analysis import AnalysisResult, analyse
from cid_gitlab import GitLabRepo
from cid_report import write_html, write_xlsx
from cid_settings import CidSettings, get_logger

log = get_logger("cid.main")


@dataclass
class RunOutcome:
    result: Optional[AnalysisResult] = None
    xlsx_path: str = ""
    html_path: str = ""
    seconds: float = 0.0
    error: str = ""

    @property
    def failed(self) -> bool:
        return bool(self.error) or (self.result.failed if self.result else True)

    def summary(self) -> str:
        if self.error:
            return "CID analysis could not complete: %s" % self.error
        r = self.result
        return ("CID analysis %s -- %d flagged of %d finding(s); branch '%s', schema '%s'; "
                "%.1fs" % ("FAILED" if r.failed else "passed", len(r.flagged),
                           len(r.findings), r.branch, r.compare_schema, self.seconds))


def run_cid_analysis(settings: CidSettings, interactive: bool = False,
                     write_reports: bool = True) -> RunOutcome:
    """The whole check. Never raises for a *finding* -- that decision belongs
    to the caller, so the DAG can attach the reports before failing."""
    t0 = time.time()
    out = RunOutcome()
    try:
        settings.prepare(interactive=interactive)

        repo = GitLabRepo(settings)
        if not repo.branch_exists():
            raise ValueError(
                "Branch '%s' does not exist in %s. Check the branch name passed to the DAG "
                "run or the notebook." % (settings.branch, settings.nlg_project_path))

        from cid_greenplum import connect
        conn = connect(settings)
        try:
            res = analyse(settings, repo, conn)
        finally:
            try:
                conn.close()
            except Exception:
                pass

        out.result = res
        if write_reports:
            out.xlsx_path = write_xlsx(res, settings, settings.output_dir)
            out.html_path = write_html(res, settings, settings.output_dir)
    except Exception as e:
        log.exception("CID analysis failed before it could complete.")
        out.error = "%s: %s" % (type(e).__name__, e)
    out.seconds = time.time() - t0
    log.info(out.summary())
    return out
