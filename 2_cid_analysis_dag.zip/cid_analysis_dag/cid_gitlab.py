"""
Reading the nlg-dags repository at a given branch.

Speed matters here: `sql_column_mapping` alone is ~470 files, and fetching
them one at a time over the API would dominate the run. So the whole branch
is pulled as a SINGLE archive and read from memory -- one request instead of
several hundred, and it makes the notebook and the DAG equally quick.

If the archive endpoint is unavailable the code falls back to the per-file
API, which is slower but still correct.
"""
from __future__ import annotations

import io
import posixpath
import tarfile
import urllib.parse
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, List, Optional

import requests
from requests.adapters import HTTPAdapter

try:
    from urllib3.util.retry import Retry
except ImportError:                                   # pragma: no cover
    from requests.packages.urllib3.util.retry import Retry   # type: ignore

from cid_settings import get_logger

log = get_logger("cid.gitlab")


class GitLabRepo:
    def __init__(self, settings):
        self.base = settings.gitlab_url.rstrip("/")
        self.project = settings.nlg_project_path
        self.branch = settings.branch
        self.token = settings.git_token
        self.workers = max(1, int(getattr(settings, "max_workers", 12)))
        self._enc = urllib.parse.quote(self.project, safe="")
        self._files: Optional[Dict[str, str]] = None
        self._sess = self._session()

    def _session(self):
        s = requests.Session()
        s.headers.update({"PRIVATE-TOKEN": self.token or "",
                          "Accept": "application/json"})
        retry = Retry(total=4, backoff_factor=0.6,
                      status_forcelist=[429, 500, 502, 503, 504],
                      allowed_methods=frozenset(["GET"]))
        ad = HTTPAdapter(max_retries=retry, pool_connections=self.workers * 2,
                         pool_maxsize=self.workers * 2)
        s.mount("https://", ad)
        s.mount("http://", ad)
        return s

    # ------------------------------------------------------------ branch
    def branch_exists(self) -> bool:
        """Checked explicitly so a typo'd branch fails with a clear message
        rather than as an empty scan that looks like a clean result."""
        url = "%s/api/v4/projects/%s/repository/branches/%s" % (
            self.base, self._enc, urllib.parse.quote(self.branch, safe=""))
        r = self._sess.get(url, timeout=60)
        if r.status_code == 200:
            log.info("Branch '%s' found in %s.", self.branch, self.project)
            return True
        if r.status_code == 404:
            log.error("Branch '%s' does not exist in %s.", self.branch, self.project)
            return False
        r.raise_for_status()
        return False

    # ------------------------------------------------------------ files
    def load_tree(self, prefixes: List[str]) -> Dict[str, str]:
        """`path -> text` for every file under any of `prefixes`.

        One archive download, decompressed in memory. Nothing is written to
        disk, so the task leaves no artefacts behind on a worker.
        """
        if self._files is not None:
            return self._filter(prefixes)

        url = "%s/api/v4/projects/%s/repository/archive.tar.gz" % (self.base, self._enc)
        try:
            r = self._sess.get(url, params={"sha": self.branch}, timeout=300, stream=True)
            r.raise_for_status()
            blob = r.content
            log.info("Downloaded branch archive: %.1f MB.", len(blob) / 1048576.0)
            files: Dict[str, str] = {}
            with tarfile.open(fileobj=io.BytesIO(blob), mode="r:gz") as tf:
                for m in tf.getmembers():
                    if not m.isfile():
                        continue
                    # the archive root is <project>-<sha>/; strip it so paths
                    # match what the repository shows
                    parts = m.name.split("/", 1)
                    rel = parts[1] if len(parts) == 2 else m.name
                    if not any(rel.startswith(p) for p in prefixes):
                        continue
                    fh = tf.extractfile(m)
                    if fh is None:
                        continue
                    try:
                        files[rel] = fh.read().decode("utf-8", errors="replace")
                    except Exception as e:
                        log.warning("Could not read %s from the archive: %s", rel, e)
            self._files = files
            log.info("Loaded %d file(s) from the archive under %s.", len(files), prefixes)
            return files
        except Exception as e:
            log.warning("Archive download failed (%s); falling back to the per-file API.", e)
            self._files = self._load_via_api(prefixes)
            return self._files

    def _filter(self, prefixes: List[str]) -> Dict[str, str]:
        return {k: v for k, v in (self._files or {}).items()
                if any(k.startswith(p) for p in prefixes)}

    def _load_via_api(self, prefixes: List[str]) -> Dict[str, str]:
        paths: List[str] = []
        for p in prefixes:
            paths.extend(self._list_tree(p))
        log.info("Fetching %d file(s) individually with %d worker(s)...",
                 len(paths), self.workers)

        def _one(path):
            url = "%s/api/v4/projects/%s/repository/files/%s/raw" % (
                self.base, self._enc, urllib.parse.quote(path, safe=""))
            try:
                r = self._sess.get(url, params={"ref": self.branch}, timeout=90)
                if r.status_code == 200:
                    return path, r.text
                log.warning("  %s -> HTTP %s", path, r.status_code)
            except Exception as e:
                log.warning("  %s -> %s", path, e)
            return path, None

        out: Dict[str, str] = {}
        with ThreadPoolExecutor(max_workers=self.workers) as ex:
            for fut in as_completed([ex.submit(_one, p) for p in paths]):
                path, text = fut.result()
                if text is not None:
                    out[path] = text
        return out

    def _list_tree(self, prefix: str) -> List[str]:
        url = "%s/api/v4/projects/%s/repository/tree" % (self.base, self._enc)
        out, page = [], 1
        while True:
            r = self._sess.get(url, params={"ref": self.branch, "path": prefix,
                                            "recursive": "true", "per_page": 100,
                                            "page": page}, timeout=90)
            if r.status_code != 200:
                log.warning("Tree listing for %s -> HTTP %s", prefix, r.status_code)
                break
            batch = r.json() or []
            if not batch:
                break
            out.extend(x["path"] for x in batch if x.get("type") == "blob")
            if len(batch) < 100:
                break
            page += 1
        return out


def basename(path: str) -> str:
    return posixpath.basename(path)
