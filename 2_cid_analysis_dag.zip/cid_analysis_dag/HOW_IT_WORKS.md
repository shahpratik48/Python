# CID analysis — how it works

Checks a branch of **nlg-dags** for client-identifying data (CID) that is exposed without masking,
and fails the pipeline when it finds any, so a person reviews the change.

---

## Flow

```
                    ┌──────────────────────────────┐
                    │  start_nlg  (existing task)  │
                    └──────────────┬───────────────┘
                                   │
                    ┌──────────────▼───────────────┐
                    │        cid_analysis          │
                    └──────────────┬───────────────┘
                                   │
   STEP 1  which DAG am I?  ───────┤
           nlg_dummy   → branch = develop        → schema = IKG_PRE_PROD_SCHEMA (UAT)
           nlg_dummy2  → branch = user input     → schema = IKG_SCHEMA          (Dev)
           blank branch on nlg_dummy2 → FAIL with a clear message
                                   │
   STEP 2  CID columns      ───────┤   core_ikg.cid_columns_metadata_manual_refresh
           (always production)     │   WHERE is_cid = 'Y'
                                   │
                    ┌──────────────▼───────────────┐
                    │  pull the branch ONCE as a   │
                    │  tar.gz archive (≈500 files) │
                    └──────────────┬───────────────┘
                                   │
        ┌──────────────────────────┼──────────────────────────┐
        │                          │                          │
   STEP 3                     STEP 4                     STEP 5
   sql_column_mapping         input_data_config_dummy    schema comparison
        │                          │                          │
   any CID column use         CID column used            columns in the schema
   is a FINDING               WITHOUT MD5 is a           under test but not in
                              FINDING                    core_ikg  →  "new"
   (narrative text a          (hashed use is                    │
    person reads)              recorded, not flagged)           │
                                                    ┌───────────┴───────────┐
                                                    │                       │
                                              new column IS CID       new column not CID
                                                    │                       │
                                              re-run steps 3 & 4       still reported,
                                              on it → FINDING          with how it is used
        └──────────────────────────┼──────────────────────────┘
                                   │
   STEP 6  anything flagged?  ─────┤
           yes → raise → task FAILS → pipeline stops for human intervention
           no  → task passes
                                   │
                    ┌──────────────▼───────────────┐
                    │  cid_email                   │  trigger_rule = all_done
                    │  sends XLSX + HTML always    │  (pass, fail or error)
                    └──────────────────────────────┘
```

---

## The rules, and why they differ

| Folder | Rule | Reason |
|---|---|---|
| `sql_column_mapping` | **any** use of a CID column is flagged | these expressions build the narrative text a person reads, so a CID value there is exposed by definition |
| `input_data_config_dummy` | only **unmasked** uses are flagged | this layer is allowed to carry CID columns provided they are hashed |

### Masking is parsed, not pattern-matched

```
ip_frst_x:      substring(MD5(b.ip_frst_x),1,8)     masked
ip_frst_x_real: b.ip_frst_x                         NOT masked
mixed:          MD5(b.a) || b.ip_frst_x             NOT masked
```

The third case is why a substring search for `"md5"` is not good enough — the expression contains
`MD5`, but one of the two uses is bare, and one bare use is enough to leak the value. The scanner
finds each occurrence of the column and checks whether **that occurrence** sits inside a hashing
call; masking counts only when **every** occurrence does.

Recognised as masking: `md5`, `sha1`/`224`/`256`/`384`/`512`, `hashtext`, `encode`, `digest`.

Column matching is whole-word, so `acc_i` does not match inside `acc_i_asset_key`.

---

## Step 5 in detail

1. The profile table behind each `input_data_config_dummy` file is looked up in
   `src/config/odm_profile_map/profile_tbl.yaml` (`target_type → profile_table_name`).
2. Columns for those tables are read from the schema under test and from `core_ikg`, in **one query
   each**, restricted to `BASE TABLE` — views are excluded because a view's columns are a projection
   of a table's, and counting them would report the same new column several times.
3. Columns present in the schema under test but absent from production are **new**.
4. A new column that is also `is_cid = 'Y'` gets steps 3 and 4 applied to it.
5. **Every** new column is reported with the profile table and whether the branch already uses it —
   CID or not — because that is the change a reviewer needs to see.

If a table exists in the schema under test but not in production, every one of its columns is treated
as new, and the log says so plainly rather than burying it.

---

## Schemas and secrets

| What | Where it comes from |
|---|---|
| CID metadata | **always** `core_ikg` (hardcoded production) |
| Schema compared, `nlg_dummy` | Airflow Variable `IKG_PRE_PROD_SCHEMA` (UAT) |
| Schema compared, `nlg_dummy2` | Airflow Variable `IKG_SCHEMA` (Dev) |
| GitLab token | Airflow Variable `GENESIS_DDLC_IKG_GIT_SECRET` |
| Greenplum | Airflow connection `IKG_GP_GPRDSP` |

In the notebook the token and password are prompted for with hidden input and never stored.
Resolution order everywhere: explicit value → environment variable → Airflow Variable → prompt.

---

## Performance

The job is dominated by file access, so:

- **One archive download** for the whole branch instead of ~500 API calls. If the archive endpoint is
  unavailable the code falls back to per-file fetching in parallel, which is slower but still
  correct.
- **Files are walked once**, matching every CID column per expression, rather than once per column.
  With ~470 mapping files and a long CID list the opposite order is what makes this slow.
- **A cheap pre-filter** skips any file whose text contains none of the column names before the YAML
  is parsed at all.
- **Two metadata queries** for the schema comparison, not one per table.

A full run over the reference tree — 46 config files, 331 mapping files, 43 profile tables — completes
in a couple of seconds once the archive is down.

---

## What the reports contain

Both formats, every run:

| Sheet / section | Contents |
|---|---|
| **Summary** | outcome, DAG, branch, schemas, counts, and the flagged tally by rule |
| **Flagged** | only the findings that fail the task |
| **All findings** | including acceptable masked uses, so the report shows everything examined |
| **New columns** | every new column with its profile table, CID status and whether the branch uses it |

Each finding row carries: step, severity, rule, column, is-CID, masked, target type, profile table,
**file path**, **YAML key**, the **logic** verbatim, and a note explaining the rule.

---

## Failure behaviour

- **Findings** → `cid_analysis` raises, the task goes red, the pipeline stops. The message names the
  first 20 findings so the cause is visible in the Airflow UI without opening the attachment.
- **An error** (bad branch, no schema variable, database unreachable) → also raises, with a message
  saying which.
- **Either way** `cid_email` still runs (`trigger_rule="all_done"`) and attaches whatever reports
  exist. The reports are written *before* the failure is raised, precisely so this works.
