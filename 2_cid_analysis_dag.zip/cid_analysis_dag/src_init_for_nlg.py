"""
Deploy this file as  /opt/airflow/dags/nlg/src/__init__.py  (rename it).

`nlg/src` has to be an importable package for `from nlg.src.cid import ...`
to resolve. An empty __init__.py does that and changes nothing else -- it
does not affect `template_searchpath`, which reads the directory from disk
rather than importing it.

If your deployment already has this file, keep the existing one.
"""
