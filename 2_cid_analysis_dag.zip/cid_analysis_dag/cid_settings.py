"""
Configuration, secrets and logging for the CID analysis.

Two DAGs share this code and differ only in what they point at:

    nlg_dummy    branch is ALWAYS develop        schema = IKG_PRE_PROD_SCHEMA (UAT)
    nlg_dummy2   branch comes from the user      schema = IKG_SCHEMA (Dev)

The CID metadata table is the one exception: it is always read from the
hardcoded production schema, because a dev copy of "which columns are
client-identifying" would make the whole check meaningless.

Secrets resolve as: explicit value -> environment -> Airflow Variable ->
prompt (notebook only). Nothing is ever hardcoded.
"""
from __future__ import annotations

import getpass
import logging
import os
import sys
from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional

DAG_DUMMY = "nlg_dummy"
DAG_DUMMY2 = "nlg_dummy2"

# Always production -- see the module docstring.
CID_METADATA_SCHEMA = "core_ikg"
CID_METADATA_TABLE = "cid_columns_metadata_manual_refresh"

_LOG_FMT = "%(asctime)s | %(levelname)-7s | %(name)-20s | %(message)s"
_configured = False


def setup_logging(level: str = "INFO", log_dir: Optional[str] = None,
                  log_to_file: bool = True) -> str:
    """Console always; a timestamped file too when asked.

    Detailed logging is a requirement here, not a nicety: this task can fail
    a pipeline, and whoever is paged needs to see exactly which file, column
    and rule produced the finding.
    """
    global _configured
    root = logging.getLogger()
    if _configured:
        return getattr(root, "_cid_log", "")
    root.setLevel(getattr(logging, str(level).upper(), logging.INFO))
    for h in list(root.handlers):
        root.removeHandler(h)
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(logging.Formatter(_LOG_FMT))
    root.addHandler(sh)
    path = ""
    if log_to_file:
        log_dir = log_dir or os.path.dirname(os.path.abspath(__file__))
        os.makedirs(log_dir, exist_ok=True)
        path = os.path.join(log_dir, "cid_analysis_%s.log"
                            % datetime.now().strftime("%Y%m%d_%H%M%S"))
        fh = logging.FileHandler(path, encoding="utf-8")
        fh.setFormatter(logging.Formatter(_LOG_FMT))
        root.addHandler(fh)
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    root._cid_log = path
    _configured = True
    return path


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)


log = get_logger("cid.settings")


def _env(k, d=None):
    return os.getenv(k, d)


def _airflow_var(key):
    try:
        from airflow.models import Variable      # type: ignore
        return Variable.get(key, default_var=None)
    except Exception:
        return None


@dataclass
class CidSettings:
    # ---------------- GitLab ----------------
    gitlab_url: str = field(default_factory=lambda: _env("GITLAB_URL",
                                                         "https://devcloud.ubs.net"))
    nlg_project_path: str = field(default_factory=lambda: _env(
        "NLG_PROJECT_PATH",
        "ubs/gwma/smart-technology-and-analytics/staat-data-science/"
        "staat-ds-genesis/genesis-platform/nlg-dags"))
    git_token: Optional[str] = field(default_factory=lambda: _env("GITLAB_TOKEN", ""))
    git_token_var: str = "GENESIS_DDLC_IKG_GIT_SECRET"

    # ---------------- which DAG, which branch ----------------
    dag_id: str = DAG_DUMMY
    input_branch: Optional[str] = None          # only used by nlg_dummy2
    branch: str = ""                            # resolved

    # ---------------- Greenplum ----------------
    gp_conn_id: str = "IKG_GP_GPRDSP"
    gp_host: str = field(default_factory=lambda: _env("GREENPLUM_HOST",
                                                      "greenplum-rdsp.zur.swissbank.com"))
    gp_port: int = field(default_factory=lambda: int(_env("GREENPLUM_PORT", "5432")))
    gp_db: str = field(default_factory=lambda: _env("GREENPLUM_DB", "gprdsp"))
    gp_user: str = field(default_factory=lambda: _env("GREENPLUM_USER", "ds_rdsp_dev"))
    gp_password: Optional[str] = field(default_factory=lambda: _env("GREENPLUM_PASSWORD", ""))

    ikg_schema: str = field(default_factory=lambda: _env("IKG_SCHEMA", ""))
    ikg_pre_prod_schema: str = field(default_factory=lambda: _env("IKG_PRE_PROD_SCHEMA", ""))
    compare_schema: str = ""                    # resolved

    # ---------------- paths inside the repo ----------------
    dummy_config_dir: str = "src/config/input_data_config_dummy"
    sql_mapping_dir: str = "src/sql_column_mapping"
    profile_map_file: str = "src/config/odm_profile_map/profile_tbl.yaml"

    # ---------------- behaviour ----------------
    max_workers: int = field(default_factory=lambda: int(_env("CID_MAX_WORKERS", "24")))
    output_dir: str = field(default_factory=lambda: _env(
        "CID_OUTPUT_DIR", os.path.dirname(os.path.abspath(__file__))))
    fail_on_findings: bool = True

    # ---------------- resolution ----------------
    def resolve_branch(self) -> "CidSettings":
        """nlg_dummy is pinned to develop; nlg_dummy2 must be told.

        A blank branch for nlg_dummy2 is a hard error rather than a silent
        fall back to develop -- scanning the wrong branch would report a
        clean result for code nobody has checked.
        """
        dag = (self.dag_id or "").strip()
        if dag == DAG_DUMMY:
            self.branch = "develop"
            log.info("DAG '%s' -> branch pinned to 'develop'.", dag)
        elif dag == DAG_DUMMY2:
            b = (self.input_branch or "").strip()
            if not b:
                raise ValueError(
                    "DAG '%s' needs a feature branch. Pass it as the 'branch' DAG-run "
                    "config value, or set it in the notebook. It was blank or missing, and "
                    "defaulting to develop would report on code you did not ask about."
                    % DAG_DUMMY2)
            self.branch = b
            log.info("DAG '%s' -> branch '%s' (from input).", dag, b)
        else:
            raise ValueError("Unknown dag_id %r. Expected '%s' or '%s'."
                             % (dag, DAG_DUMMY, DAG_DUMMY2))
        return self

    def resolve_schema(self) -> "CidSettings":
        """nlg_dummy2 compares against Dev, nlg_dummy against UAT."""
        if self.dag_id == DAG_DUMMY2:
            name, val = "IKG_SCHEMA", self.ikg_schema or _airflow_var("IKG_SCHEMA")
        else:
            name, val = ("IKG_PRE_PROD_SCHEMA",
                         self.ikg_pre_prod_schema or _airflow_var("IKG_PRE_PROD_SCHEMA"))
        if not val:
            raise RuntimeError(
                "%s is not set. It names the schema whose profile tables are compared against "
                "%s. Set the Airflow Variable, the environment variable, or pass it in the "
                "notebook." % (name, CID_METADATA_SCHEMA))
        self.compare_schema = val
        log.info("DAG '%s' -> comparing schema '%s' (%s) against production '%s'.",
                 self.dag_id, val, name, CID_METADATA_SCHEMA)
        return self

    def resolve_secrets(self, interactive: bool = True) -> "CidSettings":
        if not self.git_token:
            self.git_token = _airflow_var(self.git_token_var)
        if not self.git_token and interactive:
            self.git_token = getpass.getpass("GitLab personal access token: ").strip() or None
        if not self.git_token:
            raise RuntimeError("No GitLab token. Set GITLAB_TOKEN or the Airflow Variable "
                               "'%s'." % self.git_token_var)
        log.info("GitLab token resolved.")

        if not self.gp_password:
            self.gp_password = _airflow_var("GREENPLUM_PASSWORD")
        if not self.gp_password and interactive:
            self.gp_password = getpass.getpass(
                "Greenplum password for %s@%s: " % (self.gp_user, self.gp_host)).strip() or None
        if not self.gp_password:
            raise RuntimeError("No Greenplum password. Set GREENPLUM_PASSWORD, the Airflow "
                               "Variable of the same name, or use the '%s' connection from "
                               "inside Airflow." % self.gp_conn_id)
        log.info("Greenplum credentials resolved for %s@%s/%s.",
                 self.gp_user, self.gp_host, self.gp_db)
        return self

    def prepare(self, interactive: bool = True) -> "CidSettings":
        return self.resolve_branch().resolve_schema().resolve_secrets(interactive)
