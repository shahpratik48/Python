"""
Deciding WHERE a column actually needs masking.

A CID column only leaks when its **value reaches the output**. Using it to
filter, count, group or compare reveals nothing:

    case when b.x > 0 then b.x else b.y end

`b.x` appears twice. The first is a predicate -- the reader sees only
whether the test passed. The second is the returned value, and that is the
one that must be hashed:

    case when b.x > 0 then MD5(b.x) else b.y end

So each OCCURRENCE is classified separately, by where it sits in the
expression. Flagging every occurrence would demand masking inside `count()`
and `PARTITION BY`, which changes results and produces findings nobody can
act on.

This is not a full SQL parser, and does not need to be: these expressions
are single select-list fragments, not statements. What it does is track
paren depth, the enclosing function, the governing clause keyword and the
CASE arm, which is what the question actually turns on.
"""
from __future__ import annotations

import re
from typing import List, Optional, Tuple

from cid_settings import get_logger

log = get_logger("cid.context")

# Functions that consume a value and return something derived from it -- a
# count, a length, a position. The value itself never reaches the output.
NON_EXPOSING_FUNCS = {
    "count", "length", "char_length", "character_length", "octet_length", "bit_length",
    "array_length", "cardinality", "position", "strpos", "ascii", "md5", "sha1", "sha224",
    "sha256", "sha384", "sha512", "hashtext", "digest", "encode",
}

# Clause keywords after which a column is being used to organise or filter,
# not to display.
NON_EXPOSING_CLAUSES = ("partition by", "order by", "group by", "having", "where", "on")

COMPARATORS = ("<=", ">=", "<>", "!=", "=", "<", ">")
WORD_PREDICATES = (" is null", " is not null", " in ", " not in ", " like ", " ilike ",
                   " between ", " similar to ")

EXPOSED = "exposed"
SAFE = "safe"


def _depths(expr: str) -> Tuple[List[int], List[bool]]:
    """Paren depth and in-literal flag per character.

    Everything downstream keys off these, so string contents can never be
    mistaken for SQL structure.
    """
    depth = 0
    depths, lits = [], []
    i, n = 0, len(expr)
    while i < n:
        c = expr[i]
        if c == "'":
            j = i + 1
            while j < n:
                if expr[j] == "'":
                    if j + 1 < n and expr[j + 1] == "'":
                        j += 2
                        continue
                    break
                j += 1
            for k in range(i, min(j + 1, n)):
                depths.append(depth)
                lits.append(True)
            i = j + 1
            continue
        if c == "(":
            depths.append(depth)
            lits.append(False)
            depth += 1
        elif c == ")":
            depth -= 1
            depths.append(depth)
            lits.append(False)
        else:
            depths.append(depth)
            lits.append(False)
        i += 1
    while len(depths) < n:
        depths.append(depth)
        lits.append(False)
    return depths, lits


_FUNC = re.compile(r"([A-Za-z_][\w$]*)\s*\($")


def enclosing_functions(expr: str, pos: int, depths: List[int]) -> List[str]:
    """Function names wrapping `pos`, innermost first."""
    out = []
    d = depths[pos] if pos < len(depths) else 0
    i = pos
    level = d
    while level > 0 and i > 0:
        # walk back to the '(' that opened this level
        j = i - 1
        while j >= 0:
            if depths[j] == level - 1 and expr[j] == "(":
                break
            j -= 1
        if j < 0:
            break
        m = _FUNC.search(expr[:j + 1])
        out.append(m.group(1).lower() if m else "")
        i = j
        level -= 1
    return out


# Words that end one expression and begin another. Without these, the
# segment for a THEN value would run back into the WHEN condition and pick
# up its comparison operator -- which is exactly how
# `case when b.x > 0 then b.x end` came to look like a predicate.
_BOUNDARY_WORDS = ("when", "then", "else", "end", "and", "or", "case")


def _boundary_positions(low: str, depths: List[int], d: int) -> List[int]:
    out = []
    for kw in _BOUNDARY_WORDS:
        start = 0
        while True:
            i = low.find(kw, start)
            if i < 0:
                break
            before_ok = i == 0 or not (low[i - 1].isalnum() or low[i - 1] == "_")
            after = i + len(kw)
            after_ok = after >= len(low) or not (low[after].isalnum() or low[after] == "_")
            if before_ok and after_ok and depths[i] <= d:
                out.append((i, len(kw)))
            start = i + 1
    return sorted(out)


def _segment_bounds(expr: str, pos: int, depths: List[int], lits: List[bool],
                    low: Optional[str] = None) -> Tuple[int, int]:
    """The slice at `pos`'s own paren depth, bounded by commas AND by the
    keywords that separate one expression from the next.

    Comparisons are judged inside one segment, so neither a comma elsewhere
    in the call nor a neighbouring CASE arm can drag an unrelated operator
    into scope.
    """
    d = depths[pos]
    low = low if low is not None else _lower_masked(expr, lits)

    start = 0
    for i in range(pos, -1, -1):
        if depths[i] < d:
            start = i + 1
            break
        if depths[i] == d and expr[i] == "," and not lits[i]:
            start = i + 1
            break
    end = len(expr)
    for i in range(pos, len(expr)):
        if depths[i] < d:
            end = i
            break
        if depths[i] == d and expr[i] == "," and not lits[i]:
            end = i
            break

    for i, klen in _boundary_positions(low, depths, d):
        if i + klen <= pos:
            start = max(start, i + klen)
        elif i >= pos:
            end = min(end, i)
            break
    return start, end


def _lower_masked(expr: str, lits: List[bool]) -> str:
    """Lower-cased text with literals blanked, for keyword searching."""
    return "".join(" " if lits[i] else c.lower() for i, c in enumerate(expr))


def _clause_before(low: str, pos: int, depths: List[int], d: int) -> Optional[str]:
    """The nearest governing clause keyword before `pos` at depth <= d."""
    best, best_i = None, -1
    for kw in NON_EXPOSING_CLAUSES:
        start = 0
        while True:
            i = low.find(kw, start, pos)
            if i < 0:
                break
            # standalone, and not nested deeper than the occurrence
            before_ok = i == 0 or not (low[i - 1].isalnum() or low[i - 1] == "_")
            after = i + len(kw)
            after_ok = after >= len(low) or not (low[after].isalnum() or low[after] == "_")
            if before_ok and after_ok and depths[i] <= d and i > best_i:
                best, best_i = kw, i
            start = i + 1
    if best is None:
        return None
    # a CASE arm opened after the clause keyword puts us back in value land
    for arm in ("then", "else"):
        j = low.rfind(arm, best_i, pos)
        if j > best_i and depths[j] <= d:
            return None
    return best


def _case_arm(low: str, pos: int, depths: List[int], d: int) -> Optional[str]:
    """'when', 'then' or 'else' -- whichever governs `pos`."""
    best, best_i = None, -1
    for kw in ("when", "then", "else"):
        start = 0
        while True:
            i = low.find(kw, start, pos)
            if i < 0:
                break
            before_ok = i == 0 or not (low[i - 1].isalnum() or low[i - 1] == "_")
            after = i + len(kw)
            after_ok = after >= len(low) or not (low[after].isalnum() or low[after] == "_")
            if before_ok and after_ok and depths[i] <= d and i > best_i:
                best, best_i = kw, i
            start = i + 1
    return best


def _has_comparison(segment: str) -> bool:
    seg = segment.lower()
    if any(op in segment for op in COMPARATORS):
        return True
    padded = " " + " ".join(seg.split()) + " "
    return any(w in padded for w in WORD_PREDICATES)


def classify(expr: str, pos: int) -> Tuple[str, str]:
    """(EXPOSED | SAFE, reason) for the occurrence starting at `pos`.

    Checked innermost-outwards, because the closest context wins: a column
    inside `count()` is safe no matter what surrounds the call.
    """
    depths, lits = _depths(expr)
    if pos >= len(depths):
        return EXPOSED, "value is selected"
    if lits[pos]:
        return SAFE, "inside a string literal"

    d = depths[pos]
    low = _lower_masked(expr, lits)

    # 1. an enclosing function that cannot leak the value
    for fn in enclosing_functions(expr, pos, depths):
        if fn in NON_EXPOSING_FUNCS:
            return SAFE, "argument of %s() -- the value is not returned" % fn.upper()

    # 2. the CASE arm it sits in
    arm = _case_arm(low, pos, depths, d)
    if arm == "when":
        return SAFE, "CASE WHEN condition -- used as a test, not returned"

    # 3. a clause that organises or filters rather than displays
    clause = _clause_before(low, pos, depths, d)
    if clause:
        return SAFE, "%s -- used to %s, not returned" % (
            clause.upper(), "filter" if clause in ("where", "having", "on") else "group")

    # 4. an operand of a comparison within its own segment
    a, b = _segment_bounds(expr, pos, depths, lits, low)
    if _has_comparison(expr[a:b]):
        return SAFE, "compared, not returned"

    return EXPOSED, "value is selected"


def occurrence_report(expr: str, column: str) -> List[dict]:
    """Every occurrence of `column`, with its classification and masking."""
    from cid_scan import _col_pattern, _mask_spans

    spans = _mask_spans(expr)
    out = []
    for m in _col_pattern(column).finditer(expr):
        masked = any(a <= m.start() < b for a, b in spans)
        kind, reason = classify(expr, m.start())
        out.append({"pos": m.start(), "masked": masked, "context": kind, "reason": reason})
    return out


def needs_masking(expr: str, column: str) -> Tuple[bool, str, int, int]:
    """(is a finding, reason, exposed occurrences, unmasked exposed ones).

    A finding only where the value is EXPOSED and NOT hashed. One such
    occurrence is enough, since one is all it takes to leak the value.
    """
    occ = occurrence_report(expr, column)
    if not occ:
        return False, "not referenced", 0, 0
    exposed = [o for o in occ if o["context"] == EXPOSED]
    bad = [o for o in exposed if not o["masked"]]
    if not exposed:
        reasons = sorted({o["reason"] for o in occ})
        return False, "; ".join(reasons[:2]), 0, 0
    if not bad:
        return False, "exposed but hashed", len(exposed), 0
    return True, bad[0]["reason"], len(exposed), len(bad)
