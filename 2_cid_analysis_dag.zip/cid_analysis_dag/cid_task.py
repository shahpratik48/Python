"""
The CID analysis as ONE Airflow task.

The DAG file stays almost untouched -- two lines:

    from nlg.cid import cid_task                     # or wherever these live
    cid_analysis = cid_task.build_task()

    chain(start_nlg, cid_analysis, nlg_latest_odm_insights, ...)

Everything else lives here, so the DAG keeps its existing shape and nothing
about it has to be understood to maintain the check.

**One task, not two.** It runs the analysis, writes both reports, emails
them, and only then raises. Sending the report before raising is what makes
a single task work: the attachment exists whether the outcome is a pass, a
finding, or an error, and Airflow's own `email_on_failure` (already set in
this DAG's `default_args`) then sends the failure alert on top.

The branch for nlg_dummy2 comes from, in order:
    1. the DAG-run configuration     {"branch": "feature/my-change"}
    2. a `branch` Param on the DAG, if one is defined
    3. nothing -> the task fails with a clear message
nlg_dummy ignores all of it and always uses develop.
"""
from __future__ import annotations

import os
import sys
from typing import List, Optional

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

from cid_main import run_cid_analysis
from cid_settings import CidSettings, get_logger, setup_logging

DEFAULT_RECIPIENTS = ["pratik.shah.2@ubs.com"]

XCOM_XLSX = "cid_xlsx_path"
XCOM_HTML = "cid_html_path"
XCOM_SUMMARY = "cid_summary"
XCOM_NEEDS_REVIEW = "cid_needs_review"


def _recipients() -> List[str]:
    raw = os.getenv("CID_EMAIL_RECIPIENTS", "")
    if not raw:
        try:
            from airflow.models import Variable        # type: ignore
            raw = Variable.get("CID_EMAIL_RECIPIENTS", default_var="") or ""
        except Exception:
            raw = ""
    out = [r.strip() for r in raw.split(",") if r.strip()]
    return out or DEFAULT_RECIPIENTS


def _env_label() -> str:
    """Dev / Prod, for the subject line."""
    try:
        from airflow.configuration import conf         # type: ignore
        from airflow.models import Variable            # type: ignore
        base = conf.get("webserver", "base_url")
        if base == Variable.get("AIRFLOW_UAT_URL", default_var=""):
            return "Dev"
        if base == Variable.get("AIRFLOW_PROD_URL", default_var=""):
            return "Prod"
    except Exception:
        pass
    return "Unknown"


def _resolve_branch(context) -> Optional[str]:
    conf = {}
    dag_run = context.get("dag_run")
    if dag_run is not None and getattr(dag_run, "conf", None):
        conf = dag_run.conf or {}
    for key in ("branch", "input_branch", "feature_branch"):
        if conf.get(key):
            return str(conf[key]).strip()
    params = context.get("params") or {}
    for key in ("branch", "input_branch", "feature_branch"):
        if params.get(key):
            return str(params[key]).strip()
    return None


def _send_report(subject: str, body_html: str, files: List[str], log) -> None:
    """Emails the report. Never raises -- a mail problem must not hide the
    analysis result, which the task is about to report anyway."""
    try:
        from airflow.utils.email import send_email     # type: ignore
        send_email(to=_recipients(), subject=subject, html_content=body_html, files=files)
        log.info("CID report emailed to %s (%d attachment(s)).", _recipients(), len(files))
    except Exception as e:
        log.error("Could not send the CID report email: %s", e)


def run_cid_task(**context):
    """Analyse, report, email, then fail if a person needs to look."""
    log_path = setup_logging("INFO", log_dir=HERE)
    log = get_logger("cid.task")

    dag = context.get("dag")
    dag_id = getattr(dag, "dag_id", "") or (context.get("params") or {}).get("dag_id", "")
    branch = _resolve_branch(context)
    log.info("CID analysis starting for DAG '%s' (branch input: %r).", dag_id, branch)

    s = CidSettings()
    s.dag_id = dag_id
    s.input_branch = branch
    s.output_dir = HERE

    outcome = run_cid_analysis(s, interactive=False)
    res = outcome.result

    ti = context["ti"]
    ti.xcom_push(key=XCOM_XLSX, value=outcome.xlsx_path)
    ti.xcom_push(key=XCOM_HTML, value=outcome.html_path)
    ti.xcom_push(key=XCOM_SUMMARY, value=outcome.summary())
    ti.xcom_push(key=XCOM_NEEDS_REVIEW, value=bool(outcome.failed))
    ti.xcom_push(key="cid_log_path", value=log_path)

    # ---- email, always, before any raise ----
    files = [p for p in (outcome.xlsx_path, outcome.html_path) if p and os.path.exists(p)]
    if outcome.error:
        status = "ERROR"
        detail = "<b>The analysis could not complete.</b><br><br>%s" % outcome.error
    elif outcome.failed:
        status = "ACTION REQUIRED"
        detail = ("<b>%s</b><br><br>The task has been failed so this is reviewed before the "
                  "change goes further." % res.fail_reason)
    else:
        status = "passed"
        detail = "Nothing flagged and no new columns."

    subject = "CID report [%s] - %s - %s (%s)" % (
        _env_label(), status, dag_id, (res.branch if res else branch) or "?")
    body = ("<br>Hi Team,<br><br>%s<br><br>%s<br><br>"
            "<b>Reports attached.</b><br>" % (detail, outcome.summary()))
    _send_report(subject, body, files, log)

    # ---- then decide the task's fate ----
    if outcome.error:
        raise RuntimeError("CID analysis could not complete: %s" % outcome.error)

    if outcome.failed:
        parts = ["CID analysis needs human review on branch '%s': %s. Reports are attached to "
                 "the notification email." % (res.branch, res.fail_reason)]
        if res.flagged:
            parts += ["", "Flagged:"]
            parts += ["  %s | %s | %s" % (f.rule, f.column, f.file_path)
                      for f in res.flagged[:20]]
            if len(res.flagged) > 20:
                parts.append("  ... and %d more" % (len(res.flagged) - 20))
        if res.new_column_count:
            parts += ["", "New column(s) awaiting a CID decision:"]
            for tbl in sorted(res.new_columns):
                parts.append("  %s: %s" % (tbl, ", ".join(sorted(res.new_columns[tbl]))))
        raise RuntimeError("\n".join(parts))

    log.info("CID analysis passed: nothing flagged and no new columns.")


def build_task(task_id: str = "cid_analysis", dag=None, **operator_kwargs):
    """The operator to wire in after `start_nlg`.

    The PythonOperator import is tried both ways so this works whether the
    DAG file uses the modern path or the older `python_operator` one, which
    is what the existing nlg_dummy2 file imports.
    """
    try:
        from airflow.operators.python import PythonOperator        # type: ignore
    except ImportError:                                            # pragma: no cover
        from airflow.operators.python_operator import PythonOperator   # type: ignore

    kwargs = dict(task_id=task_id, python_callable=run_cid_task, provide_context=True)
    kwargs.update(operator_kwargs)
    if dag is not None:
        kwargs["dag"] = dag
    try:
        return PythonOperator(**kwargs)
    except TypeError:
        # Airflow 2 removed provide_context; context is passed automatically
        kwargs.pop("provide_context", None)
        return PythonOperator(**kwargs)
