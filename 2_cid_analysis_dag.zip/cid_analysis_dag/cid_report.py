"""
The XLSX and HTML reports.

Both are produced on EVERY run, pass or fail, because the email attaches
them either way -- a clean report is the evidence that the check ran, and is
as much a part of the audit trail as a failing one.
"""
from __future__ import annotations

import base64
import datetime as _dt
import html as _html
import os
from typing import List

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from cid_settings import CID_METADATA_SCHEMA, get_logger

log = get_logger("cid.report")

C_HEAD, C_HEAD_TX = "305496", "FFFFFF"
C_FLAG_BG, C_FLAG_TX = "FDECEA", "9B1C1C"
C_OK_BG, C_OK_TX = "E7F6EC", "0B6B36"
C_ALT, C_BORDER = "FAFBFC", "E6E8EB"
_thin = Side(style="thin", color=C_BORDER)
BORDER = Border(left=_thin, right=_thin, top=_thin, bottom=_thin)

FINDING_HEADERS = ["Step", "Severity", "Rule", "Column", "Is CID", "Masked", "Exposure",
                   "Why", "Target Type", "Profile Table", "File Path", "YAML Key",
                   "Logic (how the column is used)", "Note"]
FINDING_WIDTHS = [7, 11, 54, 28, 8, 9, 22, 46, 24, 44, 60, 30, 88, 60]


def _sheet(ws, headers, widths):
    for i, (h, w) in enumerate(zip(headers, widths), start=1):
        c = ws.cell(row=1, column=i, value=h)
        c.font = Font(name="Calibri", size=10, bold=True, color=C_HEAD_TX)
        c.fill = PatternFill("solid", start_color=C_HEAD, end_color=C_HEAD)
        c.alignment = Alignment(vertical="center", horizontal="center", wrap_text=True)
        c.border = BORDER
        ws.column_dimensions[get_column_letter(i)].width = w


def write_xlsx(res, settings, output_dir: str) -> str:
    wb = Workbook()
    wb.remove(wb.active)

    # ---- Summary ----
    ws = wb.create_sheet("Summary")
    ws.column_dimensions["A"].width = 42
    ws.column_dimensions["B"].width = 96
    rows = [
        ("CID analysis", ""),
        ("Outcome", "FAILED -- %d item(s) flagged" % len(res.flagged)
         if res.failed else "PASSED -- nothing flagged"),
        ("DAG", res.dag_id),
        ("Branch analysed", res.branch),
        ("Schema compared", "%s  vs  %s (production)" % (res.compare_schema,
                                                         CID_METADATA_SCHEMA)),
        ("CID metadata source", "%s.cid_columns_metadata_manual_refresh (is_cid = 'Y')"
         % CID_METADATA_SCHEMA),
        ("CID columns in scope", res.cid_column_count),
        ("input_data_config_dummy files", res.files_config),
        ("sql_column_mapping files", res.files_mapping),
        ("New columns found", sum(len(v) for v in res.new_columns.values())),
        ("Generated", _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
    ]
    for i, (k, v) in enumerate(rows, start=1):
        a = ws.cell(row=i, column=1, value=k)
        b = ws.cell(row=i, column=2, value=v)
        a.font = Font(name="Calibri", size=11, bold=True,
                      color=C_HEAD if i == 1 else "333333")
        b.font = Font(name="Calibri", size=11)
        if k == "Outcome":
            b.font = Font(name="Calibri", size=11, bold=True,
                          color=C_FLAG_TX if res.failed else C_OK_TX)
            b.fill = PatternFill("solid",
                                 start_color=C_FLAG_BG if res.failed else C_OK_BG,
                                 end_color=C_FLAG_BG if res.failed else C_OK_BG)

    r = len(rows) + 2
    ws.cell(row=r, column=1, value="Flagged by rule").font = Font(bold=True, size=11)
    r += 1
    for rule, n in sorted(res.counts().items(), key=lambda kv: -kv[1]):
        ws.cell(row=r, column=1, value=rule).font = Font(size=10)
        ws.cell(row=r, column=2, value=n).font = Font(size=10, bold=True)
        r += 1
    if res.errors:
        r += 1
        ws.cell(row=r, column=1, value="Problems encountered").font = Font(bold=True, size=11)
        for e in res.errors:
            r += 1
            ws.cell(row=r, column=1, value=e).font = Font(size=10, color=C_FLAG_TX)

    # ---- Flagged / All findings ----
    for name, items in (("Flagged", res.flagged), ("All findings", res.findings)):
        w = wb.create_sheet(name)
        _sheet(w, FINDING_HEADERS, FINDING_WIDTHS)
        alt = PatternFill("solid", start_color=C_ALT, end_color=C_ALT)
        flag = PatternFill("solid", start_color=C_FLAG_BG, end_color=C_FLAG_BG)
        for i, f in enumerate(items):
            vals = [f.step, f.severity, f.rule, f.column, f.is_cid, f.masked,
                    f.exposure, f.context, f.target_type, f.profile_table,
                    f.file_path, f.yaml_key, f.logic, f.note]
            for j, v in enumerate(vals, start=1):
                c = w.cell(row=i + 2, column=j, value=v)
                c.font = Font(name="Consolas" if j == 13 else "Calibri", size=9.5)
                c.alignment = Alignment(vertical="top", wrap_text=True)
                c.border = BORDER
                if f.severity == "FLAG":
                    c.fill = flag
                elif i % 2:
                    c.fill = alt
        if items:
            w.auto_filter.ref = "A1:%s%d" % (get_column_letter(len(FINDING_HEADERS)),
                                             len(items) + 1)

    # ---- New columns ----
    w = wb.create_sheet("New columns")
    _sheet(w, ["Profile Table", "Target Type", "New Column", "Is CID",
               "Used in branch?"], [50, 26, 34, 9, 60])
    t2t = {v: k for k, v in res.profile_tables.items()}
    used = {}
    for f in res.findings:
        if f.step == "5" and f.file_path:
            used.setdefault(f.column, set()).add(f.file_path)
    i = 2
    for tbl in sorted(res.new_columns):
        for col in sorted(res.new_columns[tbl]):
            cid = any(f.column == col and f.is_cid == "Y" for f in res.findings)
            u = used.get(col)
            vals = [tbl, t2t.get(tbl, ""), col, "Y" if cid else "N",
                    ("%d file(s)" % len(u)) if u else "not used"]
            for j, v in enumerate(vals, start=1):
                c = w.cell(row=i, column=j, value=v)
                c.font = Font(name="Calibri", size=9.5)
                c.border = BORDER
                c.alignment = Alignment(vertical="top", wrap_text=True)
            i += 1
    if i > 2:
        w.auto_filter.ref = "A1:E%d" % (i - 1)

    os.makedirs(output_dir, exist_ok=True)
    path = os.path.join(output_dir, "cid_report_%s_%s_%s.xlsx" % (
        res.dag_id, _safe(res.branch), _dt.datetime.now().strftime("%Y%m%d_%H%M%S")))
    wb.save(path)
    log.info("XLSX written: %s", path)
    return path


def _safe(s: str) -> str:
    return "".join(c if (c.isalnum() or c in "._-") else "_" for c in str(s)).strip("_")


def _e(s) -> str:
    return _html.escape("" if s is None else str(s))


_CSS = """
body{font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;margin:0;
padding:28px;background:#f6f7f9;color:#1a1a1a}
.wrap{max-width:1600px;margin:0 auto}
h1{font-size:22px;margin:0 0 4px}h2{font-size:15px;margin:26px 0 8px;color:#305496}
.sub{color:#666;font-size:12px;margin-bottom:16px}
.banner{padding:12px 16px;border-radius:8px;font-weight:600;margin:14px 0}
.fail{background:#fdecea;color:#9b1c1c;border:1px solid #f5c2bd}
.pass{background:#e7f6ec;color:#0b6b36;border:1px solid #b7e3c6}
.cards{display:flex;flex-wrap:wrap;gap:10px;margin:12px 0 4px}
.card{background:#fff;border:1px solid #e6e8eb;border-radius:8px;padding:10px 14px;min-width:150px}
.card .k{font-size:11px;color:#666}.card .v{font-size:19px;font-weight:600;margin-top:2px}
table{border-collapse:collapse;width:100%;background:#fff;font-size:12px}
th{background:#305496;color:#fff;text-align:left;padding:7px 9px;position:sticky;top:0}
td{padding:6px 9px;border-top:1px solid #eef0f2;vertical-align:top}
tr.flag td{background:#fdecea}
code,td.logic{font-family:Consolas,Monaco,monospace;font-size:11px;white-space:pre-wrap}
.scroll{max-height:620px;overflow:auto;border:1px solid #e6e8eb;border-radius:8px}
input.f{width:320px;padding:6px 9px;margin:6px 0;border:1px solid #d6d9dd;border-radius:6px}
.note{color:#666;font-size:12px;margin:4px 0 8px}
"""

_JS = """
document.querySelectorAll('input.f').forEach(function(inp){
  inp.addEventListener('keyup', function(){
    var q=this.value.toLowerCase(), t=document.getElementById(this.dataset.t);
    t.querySelectorAll('tbody tr').forEach(function(r){
      r.style.display = r.innerText.toLowerCase().indexOf(q)>-1 ? '' : 'none';});
  });});
"""


def _table(tid, headers, rows, row_class=None, logic_col=None):
    if not rows:
        return "<div class='note'>Nothing to show.</div>"
    h = "".join("<th>%s</th>" % _e(x) for x in headers)
    body = []
    for r in rows:
        cls = row_class(r) if row_class else ""
        tds = []
        for i, v in enumerate(r):
            c = " class='logic'" if (logic_col is not None and i == logic_col) else ""
            tds.append("<td%s>%s</td>" % (c, _e(v)))
        body.append("<tr class='%s'>%s</tr>" % (cls, "".join(tds)))
    return ("<input class='f' data-t='%s' placeholder='Filter...'>"
            "<div class='scroll'><table id='%s'><thead><tr>%s</tr></thead>"
            "<tbody>%s</tbody></table></div>" % (tid, tid, h, "".join(body)))


def write_html(res, settings, output_dir: str) -> str:
    banner = ("<div class='banner fail'>FAILED &mdash; %d item(s) flagged. This task fails so "
              "a person reviews the change before it goes further.</div>" % len(res.flagged)
              if res.failed else
              "<div class='banner pass'>PASSED &mdash; nothing flagged.</div>")

    cards = "".join(
        "<div class='card'><div class='k'>%s</div><div class='v'>%s</div></div>" % (k, v)
        for k, v in [("Flagged", len(res.flagged)),
                     ("All findings", len(res.findings)),
                     ("CID columns", res.cid_column_count),
                     ("New columns", sum(len(v) for v in res.new_columns.values())),
                     ("config files", res.files_config),
                     ("mapping files", res.files_mapping)])

    def frow(f):
        return [f.step, f.severity, f.rule, f.column, f.is_cid, f.masked, f.exposure,
                f.context, f.target_type, f.profile_table, f.file_path, f.yaml_key,
                f.logic, f.note]

    t2t = {v: k for k, v in res.profile_tables.items()}
    used = {}
    for f in res.findings:
        if f.step == "5" and f.file_path:
            used.setdefault(f.column, set()).add(f.file_path)
    new_rows = []
    for tbl in sorted(res.new_columns):
        for col in sorted(res.new_columns[tbl]):
            cid = any(f.column == col and f.is_cid == "Y" for f in res.findings)
            u = used.get(col)
            new_rows.append([tbl, t2t.get(tbl, ""), col, "Y" if cid else "N",
                             ("%d file(s)" % len(u)) if u else "not used"])

    errs = ("<h2>Problems encountered</h2><div class='note'>%s</div>"
            % "<br>".join(_e(e) for e in res.errors)) if res.errors else ""

    body = """
<h1>CID analysis &mdash; %s</h1>
<div class='sub'>branch <b>%s</b> &nbsp;|&nbsp; schema <b>%s</b> vs production <b>%s</b>
 &nbsp;|&nbsp; generated %s</div>
%s
<div class='cards'>%s</div>
%s
<h2>Flagged (%d)</h2>
<div class='note'>Every one of these fails the task. A column is flagged only where its
<b>value reaches the output unmasked</b>. Using it to count, compare, filter, group, order or
partition is not a finding &mdash; the value is never revealed. The <b>Why</b> column says which
applies.</div>
%s
<h2>New columns in %s not present in %s</h2>
<div class='note'>Every new column is listed whether or not it is CID, with whether the branch
already uses it.</div>
%s
<h2>All findings (%d)</h2>
<div class='note'>Includes the acceptable, masked uses, so the report shows everything that was
examined rather than only the problems.</div>
%s
""" % (_e(res.dag_id), _e(res.branch), _e(res.compare_schema), _e(CID_METADATA_SCHEMA),
       _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), banner, cards, errs,
       len(res.flagged),
       _table("t1", FINDING_HEADERS, [frow(f) for f in res.flagged],
              lambda r: "flag", 12),
       _e(res.compare_schema), _e(CID_METADATA_SCHEMA),
       _table("t2", ["Profile Table", "Target Type", "New Column", "Is CID",
                     "Used in branch?"], new_rows),
       len(res.findings),
       _table("t3", FINDING_HEADERS, [frow(f) for f in res.findings],
              lambda r: "flag" if r[1] == "FLAG" else "", 12))

    doc = ("<!DOCTYPE html><html><head><meta charset='utf-8'><title>CID analysis - %s</title>"
           "<style>%s</style></head><body><div class='wrap'>%s</div>"
           "<script>%s</script></body></html>" % (_e(res.branch), _CSS, body, _JS))

    os.makedirs(output_dir, exist_ok=True)
    path = os.path.join(output_dir, "cid_report_%s_%s_%s.html" % (
        res.dag_id, _safe(res.branch), _dt.datetime.now().strftime("%Y%m%d_%H%M%S")))
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(doc)
    log.info("HTML written: %s", path)
    return path
