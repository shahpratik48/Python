# CID analysis — DAG integration bundle

For wiring the check into the **existing** `nlg_dummy` and `nlg_dummy2` DAGs.

## Files

| File | Purpose |
|---|---|
| `airflow_task_cid_analysis.py` | **the integration point** — `build_cid_tasks(dag)` |
| `cid_settings.py` · `cid_gitlab.py` · `cid_greenplum.py` · `cid_scan.py` · `cid_analysis.py` · `cid_report.py` · `cid_main.py` | the engine, identical to the notebook bundle |
| `HOW_IT_WORKS.md` | flow diagram and the full rule set |

Deploy all of them into the same folder as your DAG file.

## Wiring it in

```python
from airflow_task_cid_analysis import build_cid_tasks

cid_analysis, cid_email = build_cid_tasks(dag)

start_nlg >> cid_analysis >> cid_email >> <your next task>
```

`build_cid_tasks` returns two operators and links them for you.

### Why two tasks

| Task | Behaviour |
|---|---|
| `cid_analysis` | does the work and **fails** when anything is flagged — this is what stops the pipeline |
| `cid_email` | `trigger_rule="all_done"`, so the report is sent on pass, fail **and** error |

Attaching the evidence only on success would be exactly backwards; the failing run is the one
somebody needs to read. The reports are written *before* the failure is raised so the attachment
always exists.

## Triggering nlg_dummy2 with a branch

```json
{"branch": "feature/my-change"}
```

`nlg_dummy` ignores this and always uses `develop`. A blank branch on `nlg_dummy2` fails immediately
with a clear message rather than quietly falling back.

## Airflow objects used

| Kind | Name |
|---|---|
| Variable | `IKG_SCHEMA` — Dev schema, used by `nlg_dummy2` |
| Variable | `IKG_PRE_PROD_SCHEMA` — UAT schema, used by `nlg_dummy` |
| Variable | `GENESIS_DDLC_IKG_GIT_SECRET` — GitLab token |
| Connection | `IKG_GP_GPRDSP` — Greenplum |
| Variable *(optional)* | `AIRFLOW_UAT_URL` / `AIRFLOW_PROD_URL` — only to label the email subject Dev/Prod |

`core_ikg` is hardcoded for the CID metadata table and is deliberately not configurable.

Recipients default to `pratik.shah.2@ubs.com`; override with the `CID_EMAIL_RECIPIENTS` environment
variable (comma-separated).

## XComs published

| Key | Value |
|---|---|
| `cid_xlsx_path` / `cid_html_path` | report paths, for the email task |
| `cid_summary` | one-line outcome |
| `cid_failed` | boolean |
| `cid_log_path` | the run log |

## Files shared with the notebook bundle

All seven `cid_*.py` modules and `HOW_IT_WORKS.md` are byte-identical in both zips, so there is one
engine and no risk of the two drifting apart.
