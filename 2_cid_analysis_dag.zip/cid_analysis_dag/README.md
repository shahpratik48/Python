# CID analysis — DAG integration bundle

For wiring the check into the **existing** `nlg_dummy` and `nlg_dummy2` DAGs.

## Files

| File | Purpose |
|---|---|
| `cid_task.py` | **the integration point** — `build_task()` |
| `DAG_PATCH.md` | the exact two lines to add to your DAG file |
| `example_dag_nlg_dummy2.py` | reference only — your DAG with the task wired in |
| `cid_settings.py` · `cid_gitlab.py` · `cid_greenplum.py` · `cid_scan.py` · `cid_analysis.py` · `cid_report.py` · `cid_main.py` | the engine, identical to the notebook bundle |
| `HOW_IT_WORKS.md` | flow diagram and the full rule set |

Deploy all of them into the same folder as your DAG file.

## Where these files go

```
/opt/airflow/dags/nlg/src/
    __init__.py                  <- from src_init_for_nlg.py, if not already present
    cid/
        __init__.py   cid_task.py   cid_settings.py   cid_gitlab.py   cid_greenplum.py
        cid_context.py   cid_scan.py   cid_analysis.py   cid_report.py   cid_main.py
```

Beside the DAG's existing `template_searchpath` (`/opt/airflow/dags/nlg/src`). Reports and the run
log are written into this same folder.

## Wiring it in — two lines

```python
from nlg.src.cid import build_task

cid_analysis = build_task()
chain(start_nlg, cid_analysis, nlg_latest_odm_insights, ...)
```

`build_task()` returns a ready `PythonOperator` (`task_id='cid_analysis'`). See `DAG_PATCH.md` for
the diff against your existing file, and `example_dag_nlg_dummy2.py` for it in context.

**What it needs**: `nlg/src` and `nlg/src/cid` must both be importable packages.
`cid/__init__.py` is included; deploy `src_init_for_nlg.py` as `nlg/src/__init__.py` if you do not
already have one. An empty `__init__.py` there changes nothing else — `template_searchpath` reads the
directory from disk rather than importing it.

Every module imports its siblings relatively first and falls back to a flat import, so the same files
also run as loose modules from the notebook. Both forms were tested against a replica of this
layout.

### One task, not two

It analyses, writes both reports, **emails them, and only then raises**. Sending before raising is
what lets a single task do the whole job — the attachment exists whether the run passed, found
something, or errored.

Your `default_args` already carries `'email_on_failure': True`, so Airflow sends its own alert on top
when the task fails. Nothing to add.

### When it fails

| Situation | Outcome |
|---|---|
| Nothing flagged, no new columns | passes — report still emailed |
| Anything flagged | **fails**, report emailed |
| No flags but **any** new column | **fails**, report emailed |
| Analysis could not run | **fails**, error emailed |

## Telling nlg_dummy2 which branch

Taken in order: the DAG-run configuration, then a `branch` Param if you define one.

```json
{"branch": "feature/my-change"}
```

`nlg_dummy` ignores both and always uses `develop`. A missing branch on `nlg_dummy2` fails
immediately with a clear message rather than quietly falling back — scanning the wrong branch would
report a clean result for code nobody has checked.

## Airflow objects used

| Kind | Name |
|---|---|
| Variable | `IKG_SCHEMA` — Dev schema, used by `nlg_dummy2` |
| Variable | `IKG_PRE_PROD_SCHEMA` — UAT schema, used by `nlg_dummy` |
| Variable | `GENESIS_DDLC_IKG_GIT_SECRET` — GitLab token |
| Connection | `IKG_GP_GPRDSP` — Greenplum |
| Variable *(optional)* | `CID_EXCLUDE_KEYS` — YAML keys exempt from the masking check; defaults to `input_db_join_col` |
| Variable *(optional)* | `AIRFLOW_UAT_URL` / `AIRFLOW_PROD_URL` — only to label the email subject Dev/Prod |

`core_ikg` is hardcoded for the CID metadata table and is deliberately not configurable.

Recipients default to `pratik.shah.2@ubs.com`; override with the `CID_EMAIL_RECIPIENTS` environment
variable (comma-separated).

## XComs published

| Key | Value |
|---|---|
| `cid_xlsx_path` / `cid_html_path` | report paths |
| `cid_summary` | one-line outcome |
| `cid_needs_review` | boolean |
| `cid_log_path` | the run log |

## Files shared with the notebook bundle

All seven `cid_*.py` modules and `HOW_IT_WORKS.md` are byte-identical in both zips, so there is one
engine and no risk of the two drifting apart.
