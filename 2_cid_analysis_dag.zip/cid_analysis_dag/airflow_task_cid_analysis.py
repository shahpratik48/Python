"""
CID analysis as a task inside the EXISTING nlg_dummy / nlg_dummy2 DAGs.

Drop this file and the cid_*.py modules beside your DAG file, then wire the
task in after `start_nlg`:

    from airflow_task_cid_analysis import build_cid_tasks

    cid_analysis, cid_email = build_cid_tasks(dag)
    start_nlg >> cid_analysis >> cid_email

Two tasks, on purpose:

  * `cid_analysis` does the work and FAILS when anything is flagged, which
    is what stops the pipeline for human intervention;
  * `cid_email` runs with `trigger_rule="all_done"` so the report is sent
    whether the analysis passed, failed, or errored. Attaching the evidence
    only on success would be exactly backwards.

The branch for nlg_dummy2 comes from the DAG-run configuration:

    {"branch": "feature/my-change"}

nlg_dummy ignores it and always uses develop.
"""
from __future__ import annotations

import os
import sys
from typing import Optional, Tuple

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from cid_main import run_cid_analysis
from cid_settings import CidSettings, get_logger, setup_logging

HERE = os.path.dirname(os.path.abspath(__file__))
EMAIL_RECIPIENTS = [r.strip() for r in os.getenv(
    "CID_EMAIL_RECIPIENTS", "pratik.shah.2@ubs.com").split(",") if r.strip()]

XCOM_XLSX = "cid_xlsx_path"
XCOM_HTML = "cid_html_path"
XCOM_SUMMARY = "cid_summary"
XCOM_FAILED = "cid_failed"


def _env_label() -> str:
    """Dev / Prod, taken from the webserver URL, for the email subject."""
    try:
        from airflow.configuration import conf         # type: ignore
        from airflow.models import Variable            # type: ignore
        base = conf.get("webserver", "base_url")
        if base == Variable.get("AIRFLOW_UAT_URL", default_var=""):
            return "Dev"
        if base == Variable.get("AIRFLOW_PROD_URL", default_var=""):
            return "Prod"
    except Exception:
        pass
    return "Unknown"


def task_cid_analysis(**kwargs):
    """The check itself. Writes both reports, then fails if anything flagged."""
    log_path = setup_logging("INFO", log_dir=HERE)
    log = get_logger("cid.task")

    ti = kwargs["ti"]
    dag_run = kwargs.get("dag_run")
    conf = (dag_run.conf if dag_run else {}) or {}
    # The DAG this task belongs to decides the branch and the schema, so it
    # is read from the context rather than configured twice.
    dag_id = kwargs.get("dag").dag_id if kwargs.get("dag") else conf.get("dag_id", "")
    log.info("CID analysis starting for DAG '%s' (run conf: %s).", dag_id, conf)

    s = CidSettings()
    s.dag_id = dag_id
    s.input_branch = conf.get("branch") or conf.get("input_branch")
    s.output_dir = HERE

    outcome = run_cid_analysis(s, interactive=False)

    # Push BEFORE raising, so the email task can attach the reports even
    # though this task is about to go red.
    ti.xcom_push(key=XCOM_XLSX, value=outcome.xlsx_path)
    ti.xcom_push(key=XCOM_HTML, value=outcome.html_path)
    ti.xcom_push(key=XCOM_SUMMARY, value=outcome.summary())
    ti.xcom_push(key=XCOM_FAILED, value=bool(outcome.failed))
    ti.xcom_push(key="cid_log_path", value=log_path)

    if outcome.error:
        raise RuntimeError("CID analysis could not complete: %s" % outcome.error)

    r = outcome.result
    if r.flagged:
        lines = ["%s | %s | %s" % (f.rule, f.column, f.file_path) for f in r.flagged[:20]]
        raise RuntimeError(
            "CID analysis flagged %d item(s) on branch '%s'. The reports are attached to the "
            "notification email.\n%s%s"
            % (len(r.flagged), r.branch, "\n".join(lines),
               "\n... and %d more" % (len(r.flagged) - 20) if len(r.flagged) > 20 else ""))
    log.info("CID analysis passed: nothing flagged.")


def task_cid_email(**kwargs):
    """Sends the report. Runs on success, failure or error."""
    from airflow.utils.email import send_email          # type: ignore
    log = get_logger("cid.email")
    ti = kwargs["ti"]
    xlsx = ti.xcom_pull(task_ids="cid_analysis", key=XCOM_XLSX)
    html = ti.xcom_pull(task_ids="cid_analysis", key=XCOM_HTML)
    summary = ti.xcom_pull(task_ids="cid_analysis", key=XCOM_SUMMARY) or "no summary available"
    failed = ti.xcom_pull(task_ids="cid_analysis", key=XCOM_FAILED)

    status = "ACTION REQUIRED" if failed else "passed"
    subject = "CID report [%s] - %s - %s" % (_env_label(), status,
                                             kwargs.get("dag").dag_id
                                             if kwargs.get("dag") else "")
    body = ("<br>Hi Team,<br><br><b>%s</b><br><br>%s<br><br>"
            "<b>Report attached.</b><br>" % (status.upper(), summary))
    files = [p for p in (xlsx, html) if p and os.path.exists(p)]
    if not files:
        log.warning("No report files to attach; sending the summary alone.")
    try:
        send_email(to=EMAIL_RECIPIENTS, subject=subject, html_content=body, files=files)
        log.info("Report emailed to %s (%d attachment(s)).", EMAIL_RECIPIENTS, len(files))
    except Exception as e:
        # The email failing must not hide the analysis result, which is
        # already recorded on the upstream task.
        log.error("Could not send the CID report email: %s", e)
        raise


def build_cid_tasks(dag, task_id: str = "cid_analysis",
                    email_task_id: str = "cid_email") -> Tuple[object, object]:
    """The two operators, ready to wire in after `start_nlg`."""
    from airflow.operators.python import PythonOperator     # type: ignore

    t1 = PythonOperator(task_id=task_id, python_callable=task_cid_analysis, dag=dag)
    t2 = PythonOperator(task_id=email_task_id, python_callable=task_cid_email,
                        trigger_rule="all_done", dag=dag)
    t1 >> t2
    return t1, t2
