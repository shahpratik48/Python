# GitLab Productivity Reporting & BAU Ticket Automation

Three independent DAGs, each with a matching notebook for local testing. Everything lives in one flat
folder — modules, DAGs, notebooks, and the generated HTML reports and log files.

The same code runs in both places; only where the token comes from differs:

| | Token source |
|---|---|
| **Notebook** | prompts you (hidden input), or picks up `GITLAB_TOKEN` from the environment |
| **Airflow** | the `GENESIS_DDLC_IKG_GIT_SECRET` Variable, same as the other projects |

## The three DAGs

| DAG | File | Notebook | Schedule |
|---|---|---|---|
| 1 — Metrics | `airflow_dag_gitlab_metrics.py` | `run_metrics.ipynb` | 18:00 America/New_York, Mon–Fri |
| 2 — Create BAU tickets | `airflow_dag_gitlab_create_tickets.py` | `run_create_tickets.ipynb` | manual (typically Wednesday) |
| 3 — Close BAU tickets | `airflow_dag_gitlab_close_tickets.py` | `run_close_tickets.ipynb` | manual (typically Thursday) |

### DAG 1 — Metrics

Three tasks, run in order: `collect_issue_metrics → collect_mr_metrics → build_html_report`.
Tasks 1 and 2 hand their results to the reporting task through XCom, so a failure in Task 2 still
leaves Task 1's results visible rather than losing the run.

Window: **current month plus the previous three**.

**Task 1 — issues** (`PROJECT_PATH`): issues closed per month, elapsed time to closure for each, and
the monthly average, in **business days** (weekends excluded). Over **5 business days** is flagged.

Elapsed time runs from the *In progress* transition where one exists. Where it doesn't, it falls back
to **opened → closed** rather than reporting nothing, so every closed issue contributes a figure. The
report shows which basis each issue used and counts both per month — an opened-based figure usually
reads higher, so it's worth seeing how much of the average rests on the fallback.

**Task 2 — merge requests** (IKG + NLG + ODM):

* **All four states are reported** — `opened`, `merged`, `closed` (meaning closed *without* merging),
  and `locked` — per month, so abandonment is visible rather than hidden.
* **Counts consider `merged` only**, per author and per repository, with **IKG / NLG / ODM broken out
  separately plus a total**. An abandoned MR isn't delivered work.
* **Elapsed hours** run from the earliest commit on the MR (when a file in it was first touched) until
  it was **merged**, flagged over **72 hours**. Only merged MRs have an elapsed time; opened,
  closed-unmerged and locked ones have none by definition.
* The full MR listing is **split into a separate table per month**.

**Report presentation.** Months run **newest first** everywhere. Both the issue listing and the merge
request listing are **split into one table per month**. The issue table shows the **author**. Every
table in every report is **sortable** (click a column header) and **filterable** (type in the box above
it), implemented in inline vanilla JavaScript with no library or CDN, so it keeps working from a local
file or an email attachment on a machine with no internet access. Sorting reads the visible cell text,
so a value shown next to a status badge still sorts on its number, while months, dates and timestamps
sort chronologically rather than being mis-read as plain numbers.

Month bucketing follows the state: merged MRs bucket by `merged_at`, closed-unmerged by `closed_at`,
and open or locked ones by `created_at`, so an open MR appears in the month it was raised.

**Names, not usernames.** Every person in the report is shown by GitLab display name
(`author.name`), falling back to username only if no name is set.

### DAG 2 — Create BAU tickets

Creates 11 standing tickets in the **current iteration**, each with `weight=1`,
`label=@productivity`, `parent="BAU Technical 2026"`, and a description identical to its title:

```
QA Testing for new insights          Dashboard enhencements for release
UAT Testing for new insights         Dashboard enhencements for metadata
Pipeline monitoring for Dev          Code review for IKG
Pipeline monitoring for preprod      Code review for ODM
Pipeline monitoring for production   Code review for NLG
Pipeline monitoring for Dummy
```

**Idempotent** — a ticket whose title is already open in the current iteration is skipped rather than
duplicated, so an accidental re-trigger doesn't produce eleven more.

### DAG 3 — Close BAU tickets

Closes every open ticket in the current iteration with label `@productivity` under parent
`"BAU Technical 2026"`.

Scope is deliberately narrow: the API can filter on label and iteration but not on parent epic, so the
matches are filtered down in code to those whose parent really is that epic — and the run **refuses to
proceed at all** if the epic can't be resolved, rather than closing on label and iteration alone and
risking another team's work.

## Dry run

Both write DAGs support a dry run that resolves everything and logs exactly what *would* happen
without writing:

```json
{"dry_run": "true"}
```
via `dag_run.conf`, or the `GL_DRY_RUN=true` Airflow Variable, or `settings.dry_run = True` in the
notebook. **Worth doing on the first run of DAG 2 and DAG 3.**

## Files

| File | Purpose |
|---|---|
| `gl_settings.py` | Configuration, token resolution, and logging setup. |
| `gl_client.py` | GitLab REST client — issues, label events, MRs, MR commits, iterations, epics, create/close. |
| `gl_metrics.py` | Business-day and elapsed-hour maths, month bucketing, and both metric collectors. |
| `gl_tickets.py` | Ticket creation and closing, with the guards described above. |
| `gl_report.py` | Self-contained HTML reports (inline CSS — they render straight from disk or as an attachment). |

## Logging

Logging is heavy by design, since these run unattended. Every run writes to **both** stdout (so it
appears in Airflow task logs and notebook output) and a timestamped `gitlab_report_*.log` file beside
the scripts. Every GitLab call, resolution step, per-issue decision, and write action is logged, and
the log file name is recorded in the HTML report so a report can always be traced back to its run.

Adjust with `GL_LOG_LEVEL` (default `INFO`; use `DEBUG` to see every HTTP request).

## Configuration

Paths default to the values below and can be overridden by environment variable or Airflow Variable:

```
GITLAB_URL        https://devcloud.ubs.net
GROUP_PATH        .../staat-ds-insights-cl/commons
PROJECT_PATH      .../staat-ds-insights-cl/commons/staat-ds-insights-home
IKG_PROJECT_PATH  .../genesis-platform/ikg-dags
NLG_PROJECT_PATH  .../genesis-platform/nlg-dags
ODM_PROJECT_PATH  .../genesis-platform/odm-dags
```

Tunable: `GL_MONTHS_BACK` (3), `GL_ISSUE_SLA_DAYS` (5), `GL_MR_SLA_HOURS` (72),
`GL_IN_PROGRESS_LABELS`, `GL_TICKET_LABEL`, `GL_TICKET_PARENT`, `GL_TICKET_WEIGHT`,
`GL_LOG_LEVEL`, `GL_DRY_RUN`, `GL_OUTPUT_DIR`.

## Things worth knowing

**"In progress" detection.** GitLab has no built-in concept of an in-progress *state*, so this reads
resource **label** events and matches any of `in progress`, `in-progress`, `doing`, `wip`
(case-insensitive, and scoped forms like `workflow::In progress` work too). Adjust with
`GL_IN_PROGRESS_LABELS` to match your board. An issue with no such transition **cannot** have a cycle
time computed — it is reported as *unknown* and counted separately, never treated as zero, which would
quietly drag the average down.

**"Any file touched in MR"** is taken as the earliest commit on the MR. An MR with no readable commit
history is likewise reported as *unknown* rather than skipped.

**Business days** exclude Saturday and Sunday. They do **not** account for public holidays or
working-hour boundaries, so a ticket opened at 4pm Friday and closed 10am Monday counts as ~0.75
business days.

**Iterations and epics are GitLab Premium features.** If the token lacks access, DAG 1 is unaffected,
but DAGs 2 and 3 will stop with a clear message rather than doing something half-correct.

## Python version

Targets **Python 3.8**, matching the Airflow environment (`live-3.8-env`).

One consequence worth knowing if you edit `gl_report.py`: before Python 3.12, an f-string
*expression* cannot contain a backslash, so `f"...{'<span class=\"x\">' }..."` is a `SyntaxError`
on 3.8 even though it is fine on 3.12. Any HTML needing quotes inside it is therefore built with
`%`-formatting in the small helpers `_count_badge()`, `_link()` and `_action_badge()` rather than
inline in an f-string. Keep new markup out of f-string expressions for the same reason.

Every `.py` file and every notebook code cell is verified against the Python 3.8 grammar
(`ast.parse(..., feature_version=(3, 8))`), not just whatever version happens to be local.

## Validation performed

Tested with a mocked GitLab API:

- **Business-day maths** — Mon 9am→Tue 9am = 1.00; Fri 3pm→Mon 9am = 0.75 (not 2.75); Mon→Mon = 5.00;
  Sat→Sun = 0.00.
- **Month bucketing** — current month plus the previous three; issues closed outside the window are
  excluded.
- **In-progress detection** — picks the earliest matching *add* event, ignores *remove* events and
  non-matching labels, and handles scoped labels.
- **Flagging** — a 10.12-business-day issue and a 126-hour merged MR were both correctly flagged.
- **Issue fallback** — an issue with an in-progress transition measured from it; one without measured
  from opened; both counted separately in the monthly summary.
- **MR states** — a month containing one opened, two merged, one closed-unmerged and one locked MR
  produced `{opened:1, merged:2, closed:1, locked:1}`, with counts of **2** (merged only), per-repo
  `{IKG:1, NLG:1, ODM:0}`, and elapsed hours present *only* on the merged ones.
- **Names** — display names appear throughout the report and usernames do not.
- **Report ordering** — issue and MR detail sections both render newest month first.
- **Table interactivity** — the inline JavaScript was syntax-checked with `node --check` both
  standalone and as embedded in the generated HTML, and its sort comparator was exercised against the
  real cell formats: `2026-07 > 2026-06 > 2026-05 > 2026-04` chronologically, `#9 < #23 < #101 < #1002`
  numerically rather than lexically, hours sorting on their number despite a trailing status badge, and
  blank/em-dash cells sorting last in both directions.
- **DAG 2 idempotency** — with one of the eleven titles already open: 10 created, 1 skipped.
- **DAG 3 scoping** — of two label+iteration matches, only the one under the right parent epic was
  closed; the one under a different epic was left alone.
- **XCom round-trip** — metrics serialise to JSON-safe payloads and reconstruct with datetimes intact.
- All three HTML reports generated and rendered.

The GitLab client itself could not be exercised against a live instance from the build environment, so
that is the piece worth a first supervised run — ideally DAG 1 first (read-only), then DAG 2 and 3 in
dry-run mode.
