# NLG change-impact check in the merge-request pipeline

## Which script the stage calls

**One command, no arguments:**

```yaml
script:
  - python nlg/src/change_impact/run_impact_ci.py
```

`run_impact_ci.py` is the only entry point. Everything it needs comes from the CI environment, so
there are no branch names or MR numbers in the pipeline file to fall out of step with reality.

| It reads | For |
|---|---|
| `CI_MERGE_REQUEST_SOURCE_BRANCH_NAME` | **the feature branch — the one input the program needs** |
| `CI_MERGE_REQUEST_TARGET_BRANCH_NAME` | the base to compare against (`nlg-dev`) |
| `CI_MERGE_REQUEST_IID` / `CI_PROJECT_URL` | the subject line and the MR link |
| `CI_JOB_TOKEN` | issued by GitLab to every job — reads the repository, **no token to provision** |
| `ANTHROPIC_API_KEY` *or* the ini | the model key |

All of the `CI_*` values are set automatically in a merge-request pipeline.

## No GitLab token

The job authenticates with its own `CI_JOB_TOKEN`, sent as a `JOB-TOKEN` header. Nothing to create,
store or rotate. A personal token in `GITLAB_TOKEN` or the ini still takes precedence if someone
sets one — that path exists for the notebook, not the pipeline.

## The config file

`change_impact_config.ini` sits beside the scripts, so a branch carries its own settings:

```ini
[email]
to = pratik.shah.2@ubs.com        # comma-separated; swap for the team list later
smtp_host = smtp.ubs.com

[llm]
api_key =                          # prefer the masked CI/CD variable ANTHROPIC_API_KEY
```

Precedence for every value: **environment variable → ini → built-in default**. That is what lets
the pipeline supply the key as a masked variable while the ini holds the recipients. The run logs
where each value came from, without printing secrets.

## Where the files go

All of it in one folder in the feature branch:

```
nlg/src/change_impact/
    run_impact_ci.py          <- the pipeline calls this
    ci_email.py
    nlg_impact_agent/         <- the analyser package
    nlg_dag_agent/            <- bundled dependency (hierarchy builder) -- INCLUDED
```

`run_impact_ci.py` puts its own folder on `sys.path`, so no packaging or install step is needed —
the branch carries its own copy of the checker, and a branch that changes the checker tests the new
version on itself.

## What the developer gets

An email to **pratik.shah.2@ubs.com** (override with `CHANGE_IMPACT_EMAIL_TO`):

- **Subject:** `<branch> NLG change impact - MR !123`
- **Body:** the MR link, a summary table, and any possible missed changes inline
- **Attachment:** the full XLSX

## Every run fails, every run emails

The job ends **non-zero on every outcome** — clean, findings, or the check itself breaking — and
the report is emailed every time. A green job is not read; making every run a moment of attention
costs the developer a glance.

| Code | Meaning |
|---|---|
| `1` | there is something to read |
| `2` | the check itself could not run |
| `3` | clean — no impact and no gaps; still fails so the report is seen |

**All three are overridable.** With `allow_failure: true` the job shows as failed-with-warning and
the pipeline carries on; the developer reads the report and, if nothing needs action, proceeds.
The codes stay distinct so the log says *why* it stopped — a broken key and a real finding should
not read the same.

## The report

| Sheet | Contents |
|---|---|
| Summary | what the branch does, counts, per-change verdicts |
| Change Impact Detail | each change → DAGs, task groups, tasks, methods affected |
| **Possible Missed Changes** | where the branch looks incomplete — see below |
| Changes (no task match) | changes with no reachable task |
| CID Masking Compliance | deterministic CID check |
| Tool Call Transcript | every tool call and result — the audit trail |

## Completeness review

The agent also judges whether the branch is **finished**. A change made in one place often implies
the same change elsewhere: a key added to one config but not its sibling, three of four call sites
updated, a new `insight_type` wired into the SQL mapping but never into the dummy config.

None of that appears as a "change" — the evidence is in the files nobody touched. So the agent has
five repo-wide tools that see the whole branch rather than the diff:

| Tool | Answers |
|---|---|
| `search_code` | every line matching a pattern, **and which matching files the branch did not change** |
| `find_usages` | every call site of a symbol repo-wide, and which of those files went untouched |
| `find_definition` | where a function or class is defined |
| `read_file` | any file, changed or not, to confirm a suspicion before reporting it |
| `list_repo_files` | the siblings of a changed file |

Each gap is reported with evidence (file paths and line numbers), files to check, a confidence level
and a recommendation. The agent is told to report a low-confidence gap rather than stay silent — a
developer dismisses a wrong suggestion in seconds but will never find an omission nobody mentioned.

When it finds nothing the sheet says so explicitly. "No gaps found" and "the agent never looked"
must not look the same to a reader.
