"""
One place to read change_impact_config.ini.

Precedence for every value: environment variable -> ini -> built-in default.
That is what lets the pipeline supply the LLM key as a masked CI/CD variable
while the ini carries the recipient list and everything else.
"""
from __future__ import annotations

import configparser
import os

HERE = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.getenv("CHANGE_IMPACT_CONFIG", os.path.join(HERE, "change_impact_config.ini"))

_cfg = None


def _load():
    global _cfg
    if _cfg is None:
        _cfg = configparser.ConfigParser(interpolation=None)
        if os.path.exists(CONFIG_PATH):
            _cfg.read(CONFIG_PATH, encoding="utf-8")
    return _cfg


def get(section, key, env=None, default=""):
    """A single value, honouring the precedence above."""
    if env:
        v = os.getenv(env)
        if v is not None and v.strip():
            return v.strip()
    c = _load()
    if c.has_option(section, key):
        v = c.get(section, key)
        if v is not None and v.strip():
            return v.strip()
    return default


def get_bool(section, key, env=None, default=False):
    v = get(section, key, env, "")
    if not v:
        return default
    return v.lower() in ("1", "true", "yes", "on")


def get_int(section, key, env=None, default=0):
    v = get(section, key, env, "")
    try:
        return int(v) if v else default
    except ValueError:
        return default


def get_list(section, key, env=None, default=()):
    v = get(section, key, env, "")
    out = [x.strip() for x in v.split(",") if x.strip()]
    return out or list(default)


def describe():
    """For the log: where each value came from, without printing secrets."""
    return {
        "config_file": CONFIG_PATH if os.path.exists(CONFIG_PATH) else "(not found)",
        "email.to": get_list("email", "to", "CHANGE_IMPACT_EMAIL_TO"),
        "llm.api_key": "set" if get("llm", "api_key", "ANTHROPIC_API_KEY") else "MISSING",
        "gitlab.url": get("gitlab", "url", "CI_SERVER_URL"),
        "analysis.base_branch": get("analysis", "base_branch", None, "nlg-dev"),
    }
