"""
Sending the report from the merge-request pipeline.

Plain SMTP rather than an Airflow helper: this runs in a CI runner, where
Airflow is not installed and no connection store exists.

The subject carries the branch and the MR number, and the body leads with
the MR link, so the developer can go straight from the mail to the change
without hunting for it.
"""
from __future__ import annotations

import mimetypes
import os
import smtplib
from email.message import EmailMessage
from email.utils import formatdate

import ci_config as _cfg

# Everything below comes from change_impact_config.ini beside this file,
# with an environment variable of the same purpose taking precedence.
DEFAULT_TO = ["pratik.shah.2@ubs.com"]


def recipients():
    return _cfg.get_list("email", "to", "CHANGE_IMPACT_EMAIL_TO", DEFAULT_TO)


def _smtp():
    return dict(
        host=_cfg.get("email", "smtp_host", "SMTP_HOST", "smtp.ubs.com"),
        port=_cfg.get_int("email", "smtp_port", "SMTP_PORT", 25),
        user=_cfg.get("email", "smtp_user", "SMTP_USER", ""),
        password=_cfg.get("email", "smtp_password", "SMTP_PASSWORD", ""),
        starttls=_cfg.get_bool("email", "smtp_starttls", "SMTP_STARTTLS", False),
        sender=_cfg.get("email", "from", "CHANGE_IMPACT_EMAIL_FROM",
                        "nlg-change-impact@ubs.com"),
    )


def _subject(ctx):
    """<branch> NLG change impact - MR !123, as agreed."""
    return "%s NLG change impact - MR %s" % (ctx.branch, ctx.mr_label)


def _esc(x):
    import html
    return html.escape("" if x is None else str(x))


def _gap_rows(gaps):
    if not gaps:
        return ("<p style='color:#0b6b36'><b>No incomplete changes found.</b> The agent searched "
                "the whole branch for edits that appear to be missing elsewhere and found none. "
                "Nothing to do here.</p>")
    rows = []
    for g in gaps:
        rows.append(
            "<tr><td style='padding:6px 9px;border-top:1px solid #eee'><b>%s</b><br>"
            "<span style='color:#555'>%s</span></td>"
            "<td style='padding:6px 9px;border-top:1px solid #eee'>%s</td>"
            "<td style='padding:6px 9px;border-top:1px solid #eee;text-transform:uppercase'>"
            "%s</td></tr>"
            % (_esc(g.get("title", "")), _esc(g.get("what_looks_missing", "")),
               _esc(", ".join(g.get("files_to_check", []) or [])[:200]),
               _esc(g.get("confidence", "?"))))
    return (
        "<p style='color:#9b1c1c'><b>%d change(s) may be incomplete.</b> These are places where "
        "something was changed in one spot and appears to be needed elsewhere too. Full evidence "
        "is in the <i>Possible Missed Changes</i> sheet.</p>"
        "<table style='border-collapse:collapse;font-size:13px;width:100%%'>"
        "<tr style='background:#305496;color:#fff'>"
        "<th style='padding:6px 9px;text-align:left'>What looks missing</th>"
        "<th style='padding:6px 9px;text-align:left'>Files to check</th>"
        "<th style='padding:6px 9px;text-align:left'>Confidence</th></tr>%s</table>"
        % (len(gaps), "".join(rows)))


def _body(ctx, report):
    impacted = [c for c in (report.changes or []) if c.get("has_impact")]
    gaps = list(getattr(report, "completeness_gaps", []) or [])
    link = ctx.mr_url or "(no merge-request URL in the CI environment)"

    return """<html><body style="font-family:-apple-system,Segoe UI,Roboto,Arial,sans-serif;
color:#1a1a1a;font-size:14px">
<p>Hi,</p>

<p>The change-impact check ran on <b>%s</b> for merge request <b>%s</b>.</p>

<p style="font-size:15px"><b>Merge request:</b><br>
<a href="%s">%s</a></p>

<table style="border-collapse:collapse;margin:14px 0;font-size:13px">
<tr><td style="padding:4px 12px 4px 0"><b>Branch</b></td><td>%s</td></tr>
<tr><td style="padding:4px 12px 4px 0"><b>Target</b></td><td>%s</td></tr>
<tr><td style="padding:4px 12px 4px 0"><b>Author</b></td><td>%s</td></tr>
<tr><td style="padding:4px 12px 4px 0"><b>Files changed</b></td><td>%d</td></tr>
<tr><td style="padding:4px 12px 4px 0"><b>Changes with impact</b></td><td>%d</td></tr>
<tr><td style="padding:4px 12px 4px 0"><b>Possibly incomplete</b></td><td>%d</td></tr>
</table>

<p><b>What the branch does</b><br>%s</p>

%s

<p style="margin-top:18px"><b>The full report is attached.</b></p>

<p style="color:#555;font-size:13px">The pipeline job fails on <b>every</b> run, so this report
always gets read before the merge. Once you have looked and nothing needs action, override / allow
the job and carry on &mdash; it is a prompt to look, not a gate.</p>

<p style="color:#888;font-size:12px">Sent automatically by the NLG change-impact check.</p>
</body></html>""" % (
        _esc(ctx.branch), _esc(ctx.mr_label), _esc(link), _esc(link),
        _esc(ctx.branch), _esc(ctx.target), _esc(ctx.author or "-"),
        len(report.file_changes or []), len(impacted), len(gaps),
        _esc(getattr(report, "functional_summary", "") or
             getattr(report, "overall_summary", "") or "-"),
        _gap_rows(gaps))


def _send(subject, html, attachments, log):
    smtp_cfg = _smtp()
    msg = EmailMessage()
    msg["From"] = smtp_cfg["sender"]
    msg["To"] = ", ".join(recipients())
    msg["Subject"] = subject
    msg["Date"] = formatdate(localtime=True)
    msg.set_content("This report is formatted as HTML; the attachment holds the detail.")
    msg.add_alternative(html, subtype="html")

    for path in attachments or []:
        if not path or not os.path.exists(path):
            continue
        ctype, _ = mimetypes.guess_type(path)
        maintype, subtype = (ctype or "application/octet-stream").split("/", 1)
        with open(path, "rb") as fh:
            msg.add_attachment(fh.read(), maintype=maintype, subtype=subtype,
                               filename=os.path.basename(path))

    with smtplib.SMTP(smtp_cfg["host"], smtp_cfg["port"], timeout=60) as smtp:
        if smtp_cfg["starttls"]:
            smtp.starttls()
        if smtp_cfg["user"]:
            smtp.login(smtp_cfg["user"], smtp_cfg["password"])
        smtp.send_message(msg)
    log("emailed to %s (%d attachment(s))" % (", ".join(recipients()),
                                              len(attachments or [])))


def send_impact_email(ctx, report, xlsx_path, log=print):
    """Never raises: a mail problem must not hide the analysis result, which
    the job is about to report through its exit code anyway."""
    try:
        _send(_subject(ctx), _body(ctx, report), [xlsx_path], log)
    except Exception as e:
        log("WARNING: could not send the report email: %s" % e)
        log("         the report is still attached to the job as an artifact.")


def send_failure_email(ctx, detail, log=print):
    html = ("<html><body style=\"font-family:Segoe UI,Arial,sans-serif\">"
            "<p>Hi,</p><p>The change-impact check on <b>%s</b> (MR %s) "
            "<b>could not run</b>.</p><p><a href=\"%s\">%s</a></p>"
            "<pre style='background:#f6f7f9;padding:10px;border-left:4px solid #b3261e'>%s</pre>"
            "<p style='color:#555;font-size:13px'>No report was produced. This is a problem with "
            "the check itself rather than with the branch, so it should be fixed rather than "
            "overridden.</p></body></html>"
            % (_esc(ctx.branch), _esc(ctx.mr_label), _esc(ctx.mr_url), _esc(ctx.mr_url),
               _esc(detail)))
    try:
        _send("%s NLG change impact - MR %s - CHECK FAILED TO RUN"
              % (ctx.branch, ctx.mr_label), html, [], log)
    except Exception as e:
        log("WARNING: could not send the failure email: %s" % e)
