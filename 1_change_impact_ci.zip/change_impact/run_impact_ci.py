#!/usr/bin/env python3
"""
The script the merge-request pipeline runs.

    python nlg/src/change_impact/run_impact_ci.py

Everything it needs comes from the CI environment and from
change_impact_config.ini beside this file. The pipeline stage carries no
arguments, and no token has to be provisioned:

    CI_MERGE_REQUEST_SOURCE_BRANCH_NAME   the feature branch  (the one input that matters)
    CI_MERGE_REQUEST_TARGET_BRANCH_NAME   what it merges into (nlg-dev)
    CI_MERGE_REQUEST_IID / CI_PROJECT_URL for the email subject and link
    CI_JOB_TOKEN                          issued to every job by GitLab -- reads the repo
    ANTHROPIC_API_KEY  or  [llm] api_key  the model key (masked variable preferred)
    [email] to                            the recipients, in the ini

The job ALWAYS fails and ALWAYS emails the report. Every outcome -- clean,
findings, or the check itself breaking -- ends the same way: a red job, a
mail in the developer's inbox, and the developer deciding whether to carry
on. With allow_failure set in the pipeline, "carry on" is a click.

That is deliberate. A green job is not read. Making every run a moment of
attention costs the developer a glance; missing a real finding costs a
release.

Exit codes (all non-zero, all overridable)
------------------------------------------
    1   the report has something to read (impact or a possible omission)
    2   the analysis could not run (no MR context, bad key, ...)
    3   clean -- no impact and no gaps; still fails so the report is seen
"""
from __future__ import annotations

import os
import sys
import traceback
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
for p in (HERE, os.path.dirname(HERE)):
    if p not in sys.path:
        sys.path.insert(0, p)

EXIT_REVIEW = 1
EXIT_BROKEN = 2
EXIT_CLEAN = 3        # non-zero on purpose: every run stops for a look


def _env(*names, default=""):
    for n in names:
        v = os.getenv(n)
        if v:
            return v.strip()
    return default


def _log(msg):
    print("[change-impact] %s" % msg, flush=True)


class CiContext(object):
    """What the pipeline tells us about this merge request."""

    def __init__(self):
        self.mr_iid = _env("CI_MERGE_REQUEST_IID")
        self.branch = _env("CI_MERGE_REQUEST_SOURCE_BRANCH_NAME", "CI_COMMIT_REF_NAME")
        self.target = _env("CI_MERGE_REQUEST_TARGET_BRANCH_NAME", default="nlg-dev")
        self.project_url = _env("CI_PROJECT_URL")
        self.project_path = _env("CI_PROJECT_PATH")
        self.server_url = _env("CI_SERVER_URL", default="https://devcloud.ubs.net")
        self.author = _env("GITLAB_USER_NAME", "CI_COMMIT_AUTHOR")
        self.commit = _env("CI_COMMIT_SHORT_SHA")

    @property
    def mr_url(self):
        if self.project_url and self.mr_iid:
            return "%s/-/merge_requests/%s" % (self.project_url, self.mr_iid)
        return self.project_url or ""

    @property
    def mr_label(self):
        return "!%s" % self.mr_iid if self.mr_iid else "(no MR)"

    def check(self):
        problems = []
        if not self.branch:
            problems.append("No source branch: neither CI_MERGE_REQUEST_SOURCE_BRANCH_NAME nor "
                            "CI_COMMIT_REF_NAME is set. Run this job in a merge-request "
                            "pipeline.")
        if not self.mr_iid:
            # not fatal -- a branch pipeline can still produce a useful report
            _log("CI_MERGE_REQUEST_IID is not set; continuing without an MR number.")
        return problems


# The three CI/CD variables the pipeline defines for the model. Read ONLY
# here, in the pipeline entry point: the notebook keeps its own inputs and
# the ini, and must not start picking these up from a developer's shell.
CI_VAR_API_KEY = "nlg_apikey"
CI_VAR_ENDPOINT = "nlg_openai_endpoint"
CI_VAR_MODEL = "nlg_openai_modelname"


def _llm_from_pipeline():
    """(api_key, endpoint, model, sources) from the pipeline's variables.

    Each falls back to the ini when the variable is absent, so a missing
    one is reported by name rather than as a mysterious auth failure.
    """
    import ci_config
    out, src = {}, {}
    for field, var, sect, key, alt in (
            ("api_key", CI_VAR_API_KEY, "llm", "api_key", "ANTHROPIC_API_KEY"),
            ("endpoint", CI_VAR_ENDPOINT, "llm", "endpoint", "AZURE_OPENAI_ENDPOINT"),
            ("model", CI_VAR_MODEL, "llm", "model", "AZURE_OPENAI_DEPLOYMENT")):
        v = (os.getenv(var) or "").strip()
        if v:
            out[field], src[field] = v, "CI/CD variable %s" % var
        else:
            out[field] = ci_config.get(sect, key, alt, "")
            src[field] = "ini [%s] %s" % (sect, key) if out[field] else "MISSING"
    return out, src


def _gitlab_token():
    """The job's own token, needing nothing provisioned.

    GitLab issues CI_JOB_TOKEN to every job, and it can read the project's
    repository through the API. It is prefixed "job:" so the request layer
    sends it as JOB-TOKEN rather than PRIVATE-TOKEN. A personal token in
    GITLAB_TOKEN or the ini still wins if someone sets one.
    """
    import ci_config
    personal = ci_config.get("gitlab", "token", "GITLAB_TOKEN", "")
    if personal:
        return personal, "personal token"
    job = os.getenv("CI_JOB_TOKEN", "").strip()
    if job:
        return "job:" + job, "CI_JOB_TOKEN"
    return "", "none"


def build_settings(ctx, token, api_key, llm=None):
    """ImpactSettings for this merge request.

    Built in one call rather than assigned field by field: the dataclass
    validates `branch` in __post_init__, so it cannot be created empty and
    filled in afterwards -- and the field names are `gitlab_token` and
    `llm_api_key`, which an attribute assignment would have silently
    misspelled into unused attributes.
    """
    import ci_config
    from nlg_impact_agent.config import ImpactSettings

    kwargs = dict(
        branch=ctx.branch,
        base_branch=ctx.target or ci_config.get("analysis", "base_branch", None, "nlg-dev"),
        gitlab_token=token,
        llm_api_key=api_key,
        gitlab_url=ctx.server_url or ci_config.get("gitlab", "url", "CI_SERVER_URL",
                                                   "https://devcloud.ubs.net"),
    )
    llm = llm or {}
    if llm.get("endpoint"):
        kwargs["azure_openai_endpoint"] = llm["endpoint"].rstrip("/")
    if llm.get("model"):
        kwargs["azure_openai_deployment"] = llm["model"]
        kwargs["llm_model"] = llm["model"]
        kwargs["llm_provider"] = "azure_openai"
    if ctx.project_path:
        kwargs["nlg_project_path"] = ctx.project_path
    return ImpactSettings(**kwargs)


def main():
    started = datetime.now()
    ctx = CiContext()
    _log("branch '%s' -> '%s', MR %s, commit %s"
         % (ctx.branch, ctx.target, ctx.mr_label, ctx.commit or "?"))

    import ci_config
    for k, v in ci_config.describe().items():
        _log("config  %-22s %s" % (k, v))

    problems = ctx.check()
    token, token_kind = _gitlab_token()
    _log("GitLab auth: %s" % token_kind)

    llm, llm_src = _llm_from_pipeline()
    api_key = llm["api_key"]
    _log("LLM endpoint : %s   (%s)" % (llm["endpoint"] or "-", llm_src["endpoint"]))
    _log("LLM model    : %s   (%s)" % (llm["model"] or "-", llm_src["model"]))
    _log("LLM key      : %s   (%s)" % ("set" if api_key else "-", llm_src["api_key"]))
    if not token:
        problems.append("No way to read the repository: CI_JOB_TOKEN is absent (is this a "
                        "GitLab CI job?) and no token is set in the ini or GITLAB_TOKEN.")
    for field, var in (("api_key", CI_VAR_API_KEY), ("endpoint", CI_VAR_ENDPOINT),
                       ("model", CI_VAR_MODEL)):
        if not llm[field]:
            problems.append("No LLM %s. Define the CI/CD variable '%s' (Settings -> CI/CD -> "
                            "Variables), or set it in [llm] of change_impact_config.ini."
                            % (field, var))
    if problems:
        for p in problems:
            _log("ERROR: %s" % p)
        _notify_broken(ctx, "\n".join(problems))
        return EXIT_BROKEN

    try:
        from nlg_impact_agent.agent import analyze_branch_impact
        from nlg_impact_agent.xlsx_report import export_xlsx
    except Exception as e:
        _log("ERROR: could not import the analyser: %s" % e)
        traceback.print_exc()
        _notify_broken(ctx, "Could not import nlg_impact_agent: %s" % e)
        return EXIT_BROKEN

    try:
        settings = build_settings(ctx, token, api_key, llm)
        report = analyze_branch_impact(settings, progress=_log)
    except Exception as e:
        _log("ERROR: the analysis failed: %s" % e)
        traceback.print_exc()
        _notify_broken(ctx, "The change-impact analysis failed:\n\n%s" % e)
        return EXIT_BROKEN

    out_dir = _env("CHANGE_IMPACT_OUTPUT_DIR", default=os.getcwd())
    safe = "".join(c if c.isalnum() or c in "._-" else "_" for c in ctx.branch)[:60]
    xlsx = os.path.join(out_dir, "nlg_change_impact_%s_%s_%s.xlsx"
                        % (safe, ctx.mr_iid or "nomr",
                           started.strftime("%Y%m%d_%H%M%S")))
    try:
        export_xlsx(report, xlsx)
        _log("report written: %s" % xlsx)
    except Exception as e:
        _log("ERROR: could not write the report: %s" % e)
        traceback.print_exc()
        _notify_broken(ctx, "The analysis ran but the report could not be written: %s" % e)
        return EXIT_BROKEN

    impacted = [c for c in (report.changes or []) if c.get("has_impact")]
    gaps = list(getattr(report, "completeness_gaps", []) or [])
    _log("%d change(s) with impact, %d possible incomplete change(s)."
         % (len(impacted), len(gaps)))

    from ci_email import send_impact_email
    send_impact_email(ctx, report, xlsx, log=_log)

    _log("")
    _log("=" * 72)
    _log("This job fails ON PURPOSE -- every run does -- so the report gets read before the "
         "merge. Override / allow the job to continue once you have looked.")
    if impacted or gaps:
        if gaps:
            _log("%d change(s) may be INCOMPLETE:" % len(gaps))
            for g in gaps[:10]:
                _log("   [%s] %s" % (g.get("confidence", "?"), g.get("title", "")))
        if impacted:
            _log("%d change(s) have downstream impact:" % len(impacted))
            for c in impacted[:10]:
                _log("   %s: %s" % (c.get("file", ""), c.get("change_description", ""))[:110])
        _log("=" * 72)
        return EXIT_REVIEW

    _log("No downstream impact and no completeness gaps found. The report confirms it.")
    _log("=" * 72)
    return EXIT_CLEAN


def _notify_broken(ctx, detail):
    """Email even when the analysis could not run.

    A silent failure is the worst outcome: the pipeline goes red and nobody
    knows whether it found something or simply broke.
    """
    try:
        from ci_email import send_failure_email
        send_failure_email(ctx, detail, log=_log)
    except Exception as e:
        _log("Could not send the failure email either: %s" % e)


if __name__ == "__main__":
    sys.exit(main())
