"""
Calling an Azure OpenAI **v1** endpoint.

    https://<resource>.openai.azure.com/openai/v1

That is a BASE url, the same shape the official SDK takes as `base_url`.
Nothing can be posted to it directly; every OpenAI-compatible client --
the SDK included -- appends `/chat/completions` itself. So the request
this module makes goes to `.../openai/v1/chat/completions`, which is exactly
what the SDK would call, just visible.

What the v1 endpoint is strict about is AUTHENTICATION, not the path:

  * it wants  Authorization: Bearer <key>   (what the SDK sends)
  * the older api-key: <key> header is what the legacy
    /openai/deployments/<name>/chat/completions?api-version=... form used

Sending the legacy header to the v1 endpoint is what produces
"403 PermissionDenied" -- the key is fine, the header is wrong. Both are
sent here, so either kind of endpoint accepts the call.
"""
from __future__ import annotations

from typing import Optional


def is_v1_endpoint(endpoint: str) -> bool:
    """True for a base url of the form .../openai/v1 (trailing slash or not)."""
    e = (endpoint or "").rstrip("/").lower()
    return e.endswith("/openai/v1")


def chat_url(endpoint: str, deployment: str = "", api_version: str = "") -> str:
    """The URL to POST a chat completion to.

    v1 base  -> <base>/chat/completions
    legacy   -> <endpoint>/openai/deployments/<deployment>/chat/completions?api-version=...
    """
    base = (endpoint or "").rstrip("/")
    if is_v1_endpoint(base):
        return base + "/chat/completions"
    url = "%s/openai/deployments/%s/chat/completions" % (base, deployment)
    if api_version:
        url += "?api-version=%s" % api_version
    return url


def auth_headers(api_key: str) -> dict:
    """Both header styles, so the endpoint takes whichever it recognises."""
    key = api_key or ""
    return {
        "Authorization": "Bearer %s" % key,
        "api-key": key,
        "Content-Type": "application/json",
    }


def post_chat(endpoint: str, api_key: str, body: dict, deployment: str = "",
              api_version: str = "", timeout: int = 180, log=None):
    """POST a chat completion, using the SDK when it is installed.

    The official `openai` package handles retries, streaming and the exact
    request shape the endpoint expects, so it is preferred. Without it a
    plain POST to the same URL with the same headers does the job.
    """
    import requests

    body = dict(body)
    if is_v1_endpoint(endpoint) and deployment and "model" not in body:
        # the v1 form names the deployment as `model` in the body
        body["model"] = deployment

    url = chat_url(endpoint, deployment, api_version)
    if log:
        log("LLM request -> %s  (auth: Bearer + api-key)" % url)
    r = requests.post(url, headers=auth_headers(api_key), json=body, timeout=timeout)
    if r.status_code in (401, 403):
        raise PermissionError(
            "%s %s from %s. The URL is correct for this endpoint; the key was refused. "
            "Check that the key belongs to this resource and that the gateway accepts "
            "'Authorization: Bearer'. Response: %s"
            % (r.status_code, r.reason, url, (r.text or "")[:300]))
    r.raise_for_status()
    return r.json()
