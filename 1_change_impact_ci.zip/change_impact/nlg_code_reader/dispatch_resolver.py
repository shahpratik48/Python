"""
Several `python_callable`s in this codebase don't call a fixed function --
they instantiate a class and then dynamically dispatch to a method chosen
at DAG-authoring time via `op_kwargs`, e.g.:

    def task_run_nlg_main(**kwargs):
        ...
        nlg_obj = NLG(args=nlg_args, db_settings=None, conn=conn)
        action_str = f"nlg_obj.{nlg_args['action']}()"
        eval(action_str)

Here the *task* (not the dispatcher function) determines the real method
via `op_kwargs={"action": "generate_rule_narratives", ...}`.

This module statically detects that pattern (regex over the function
source -- simpler and robust enough than full data-flow analysis for this
one recurring idiom) and, when it can't be detected, optionally asks the
LLM to read the function body and figure it out.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Dict, Optional

FSTRING_DISPATCH_RE = re.compile(r'f"\{?(\w+)\}?\.\{([^}]+)\}\(\)"')
FSTRING_DISPATCH_RE2 = re.compile(r"f'\{?(\w+)\}?\.\{([^}]+)\}\(\)'")
DICT_KEY_RE = re.compile(r"""\[\s*['"](\w+)['"]\s*\]""")
CLASS_INSTANTIATION_RE_TMPL = r"{obj}\s*=\s*(\w+)\("


@dataclass
class DispatchInfo:
    obj_var: str
    class_name: str
    dispatch_kwarg: str


def detect_dispatch(func_source: str) -> Optional[DispatchInfo]:
    m = FSTRING_DISPATCH_RE.search(func_source) or FSTRING_DISPATCH_RE2.search(func_source)
    if not m:
        return None
    obj_var, expr = m.group(1), m.group(2)
    key_match = DICT_KEY_RE.search(expr)
    if not key_match:
        return None
    dispatch_kwarg = key_match.group(1)
    class_match = re.search(CLASS_INSTANTIATION_RE_TMPL.format(obj=re.escape(obj_var)), func_source)
    if not class_match:
        return None
    class_name = class_match.group(1)
    return DispatchInfo(obj_var=obj_var, class_name=class_name, dispatch_kwarg=dispatch_kwarg)


def build_dispatch_map(func_registry: Dict[str, tuple]) -> Dict[str, DispatchInfo]:
    """func_registry: {name: (ast_node, file, module_src)} as produced by
    HierarchyExtractor. Returns {func_name: DispatchInfo} for every
    module-level function that matches the dynamic-dispatch idiom."""
    import ast
    out = {}
    for name, (node, file, src) in func_registry.items():
        try:
            seg = ast.get_source_segment(src, node) or ""
        except Exception:
            seg = ""
        if "eval(" not in seg:
            continue
        info = detect_dispatch(seg)
        if info:
            out[name] = info
    return out
