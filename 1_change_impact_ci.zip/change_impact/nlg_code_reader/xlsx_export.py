"""
Exports a built `Hierarchy` (see pipeline.build_hierarchy) to a single
.xlsx workbook with:

  0. nlg_hierarchy  -- all three views below, UNIONed into one flat sheet
                        with a row_type discriminator. Same row-set that
                        greenplum_export.py writes to Greenplum.
  1. DAG Hierarchy   -- DAG -> sub-DAG/TaskGroup -> nested TaskGroup(s) ->
                         task -> method/function -> file where it's
                         defined -> file(s) where it's called, plus the
                         further call chain (e.g. run_nlg, run_nlg_of_
                         target_type, ...), with paths.
  2. YAML Insight Types -- every yaml/yml file found in nlg-src, its
                         target_type, its insight_type, and which
                         DAG/TaskGroup/task use that target_type.
                         Folder-driven files (rules/, group_logic/, ...)
                         infer target_type from path; insight_group_layout/
                         files parse target_type from file *content*
                         (one file can define several insight_types across
                         different target_types).
  3. Product Hierarchy -- same shape as sheet 1, scoped to tasks that
                         carry an explicit `product` tag.

No formulas are used (this is a flat data export, not a model), so no
recalculation step is required -- just professional formatting.
"""
from __future__ import annotations

from typing import List

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

from .pipeline import Hierarchy
from .report_rows import hierarchy_rows, yaml_rows, combined_rows, COMBINED_COLUMNS

HEADER_FONT = Font(name="Arial", bold=True, color="FFFFFF")
HEADER_FILL = PatternFill(start_color="305496", end_color="305496", fill_type="solid")
BODY_FONT = Font(name="Arial", size=10)
WRAP = Alignment(vertical="top", wrap_text=True)


def _style_sheet(ws, col_widths: List[int]):
    ws.freeze_panes = "A2"
    for cell in ws[1]:
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(vertical="center", horizontal="center", wrap_text=True)
    ws.auto_filter.ref = ws.dimensions
    for i, w in enumerate(col_widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.font = BODY_FONT
            cell.alignment = WRAP


def _write_combined_sheet(wb: Workbook, hierarchy: Hierarchy):
    ws = wb.create_sheet("nlg_hierarchy")
    headers = COMBINED_COLUMNS
    ws.append(headers)
    rows = combined_rows(hierarchy)
    for r in rows:
        ws.append([r.get(h, "") for h in headers])
    widths = [18, 22, 30, 22, 22, 34, 28, 34, 16, 34, 26, 34, 40, 20, 26, 16, 12, 34,
              30, 46, 14, 30]
    _style_sheet(ws, widths)
    return ws, len(rows)


def _write_hierarchy_sheet(wb: Workbook, title: str, rows: List[dict]):
    ws = wb.create_sheet(title)
    headers = ["DAG", "DAG File Path", "Sub-DAG / TaskGroup", "Nested TaskGroup Path",
               "TaskGroup Defined-In File(s)", "Task", "Full Task Path", "Operator",
               "Task Defined-In File (DAG py)", "Method / Function", "Method Defined-In File",
               "Method/Function Called From File(s)",
               "Target Type", "Insight Types", "Product", "Resolution", "Notes"]
    ws.append(headers)
    for r in rows:
        ws.append([r.get(h, "") for h in headers])
    widths = [26, 34, 26, 26, 40, 32, 40, 20, 40, 32, 40, 46, 22, 30, 20, 12, 40]
    _style_sheet(ws, widths)
    return ws


def _write_product_sheet(wb: Workbook, rows: List[dict]):
    ws = wb.create_sheet("Product Hierarchy")
    headers = ["Product", "DAG", "DAG File Path", "Sub-DAG / TaskGroup", "Nested TaskGroup Path",
               "Task", "Full Task Path", "Operator", "Task Defined-In File (DAG py)",
               "Method / Function", "Method Defined-In File", "Method/Function Called From File(s)",
               "Target Type", "Insight Types", "Resolution", "Notes"]
    ws.append(headers)
    product_rows = [r for r in rows if r.get("Product")]
    product_rows.sort(key=lambda r: (r["Product"], r["DAG"], r["Full Task Path"]))
    for r in product_rows:
        ws.append([
            r["Product"], r["DAG"], r["DAG File Path"], r["Sub-DAG / TaskGroup"], r["Nested TaskGroup Path"],
            r["Task"], r["Full Task Path"], r["Operator"], r["Task Defined-In File (DAG py)"],
            r["Method / Function"], r["Method Defined-In File"], r["Method/Function Called From File(s)"],
            r["Target Type"], r["Insight Types"], r["Resolution"], r["Notes"],
        ])
    widths = [20, 26, 34, 26, 26, 32, 40, 20, 40, 32, 40, 46, 22, 30, 12, 40]
    _style_sheet(ws, widths)
    return ws, len(product_rows)


def _write_yaml_sheet(wb: Workbook, hierarchy: Hierarchy):
    ws = wb.create_sheet("YAML Insight Types")
    headers = ["Target Type (inferred)", "YAML/YML File Name", "File Path", "Is si_ Insight File",
               "Insight Type", "DAG", "Sub-DAG / TaskGroup", "Task", "Full Task Path"]
    ws.append(headers)
    rows = yaml_rows(hierarchy)
    for r in rows:
        ws.append([r.get(h, "") for h in headers])
    widths = [24, 40, 60, 16, 40, 26, 26, 32, 40]
    _style_sheet(ws, widths)
    return ws, len(rows)


def _write_legend_sheet(wb: Workbook, stats: dict):
    ws = wb.create_sheet("README", 0)
    ws.column_dimensions["A"].width = 34
    ws.column_dimensions["B"].width = 110
    rows = [
        ("Workbook", "NLG DAG hierarchy, YAML/insight-type mapping, and product hierarchy -- "
                      "auto-generated by nlg_code_reader from static analysis of nlg-dags + nlg-src."),
        ("", ""),
        ("Sheet: nlg_hierarchy", "All three views below UNIONed into one flat sheet, distinguished by "
                                  "the row_type column (DAG_HIERARCHY / PRODUCT_HIERARCHY / "
                                  "YAML_INSIGHT_TYPE). This is the exact row-set also written to the "
                                  "Greenplum nlg_hierarchy table by greenplum_export.py -- use this sheet "
                                  "if you want one flat table to filter/pivot; use the other three if you "
                                  "prefer each view laid out with its own column set."),
        ("Sheet: DAG Hierarchy", "One row per individual method/function record. Each task's directly "
                                  "resolved method AND every function/method found by walking what that "
                                  "method itself calls (e.g. generate_rule_narratives calls run_nlg, which "
                                  "calls run_nlg_of_target_type, which calls run_nlg_of_insight_type, which "
                                  "calls fetch_data_with_insights, expanded up to 4 levels deep) each get "
                                  "their OWN row -- if a task's method chain involves 10 functions, that's "
                                  "10 rows, not 1 row with a joined list. Every row still carries the full "
                                  "DAG -> Sub-DAG/TaskGroup -> Nested TaskGroup Path -> Task context, plus "
                                  "the file where that specific method/function is DEFINED and the file(s) "
                                  "it's CALLED FROM. 'Sub-task' in this codebase = a task nested under a "
                                  "nested TaskGroup; see 'Nested TaskGroup Path'. The Resolution column "
                                  "distinguishes a task's primary target (static/dispatch/llm) from further "
                                  "call-chain entries (resolution = 'call-chain')."),
        ("Sheet: YAML Insight Types", "Every .yml/.yaml file under nlg-src. For rules/, sql_column_mapping/, "
                                       "group_logic/, and ref_table_columns/, 'Target Type (inferred)' is "
                                       "the path segment right after that root folder, however deeply the "
                                       "file is nested underneath. For insight_group_layout/, target_type "
                                       "comes from the file's *content* instead -- each file can define "
                                       "several insight_types (as keys under insight_types:), each with "
                                       "its own target_type field, so one file can produce several rows "
                                       "with different target types. Insight Type = the insight_type key "
                                       "or file name itself (keeps the 'si_' prefix), per spec. Rows with "
                                       "no DAG/Task shown are files/insight_types whose target_type isn't "
                                       "currently referenced by any task (still listed for completeness)."),
        ("Sheet: Product Hierarchy", "Same shape as 'DAG Hierarchy', restricted to tasks that carry an "
                                      "explicit `product` value (from op_kwargs), grouped by product."),
        ("", ""),
        ("Resolution column", "static = direct python_callable match; dispatch = resolved via the "
                               "eval(f\"{obj}.{action}()\") dynamic-dispatch idiom; llm = resolved by LLM "
                               "fallback (verify manually); unresolved = needs manual check; call-chain = "
                               "a function/method found by walking what the resolved method itself calls "
                               "(not the task's direct target). Postgres-only tasks show "
                               "Method/Function = N/A, Notes = 'Postgres operator with sql code'."),
        ("Generated stats", f"DAGs: {stats['dags']}  |  Tasks: {stats['tasks']}  |  "
                             f"Methods resolved: {stats['resolved']}/{stats['total_methods']}  |  "
                             f"YAML/insight_type rows: {stats['yaml_rows']}  |  "
                             f"Combined nlg_hierarchy rows: {stats['combined_rows']}"),
    ]
    for r in rows:
        ws.append(r)
    for row in ws.iter_rows():
        for cell in row:
            cell.font = BODY_FONT
            cell.alignment = WRAP
    ws["A1"].font = Font(name="Arial", bold=True, size=13)
    for r in (3, 4, 5, 6, 8):
        ws.cell(row=r, column=1).font = Font(name="Arial", bold=True)
    return ws


def export_xlsx(hierarchy: Hierarchy, output_path: str) -> str:
    wb = Workbook()
    wb.remove(wb.active)  # drop the default empty sheet

    rows = hierarchy_rows(hierarchy)
    combined = combined_rows(hierarchy)
    yrows = yaml_rows(hierarchy)

    _write_combined_sheet(wb, hierarchy)
    _write_hierarchy_sheet(wb, "DAG Hierarchy", rows)
    _write_product_sheet(wb, rows)
    _write_yaml_sheet(wb, hierarchy)

    total_methods = sum(1 for r in rows)
    resolved = sum(1 for r in rows if r["Resolution"] not in ("unresolved",))
    stats = {
        "dags": len(hierarchy.dags),
        "tasks": len({r["Full Task Path"] for r in rows}),
        "total_methods": total_methods,
        "resolved": resolved,
        "yaml_rows": len(yrows),
        "combined_rows": len(combined),
    }
    _write_legend_sheet(wb, stats)

    import os
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    wb.save(output_path)
    return output_path
