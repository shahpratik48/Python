"""
Builds the row-sets shared by both the XLSX exporter and the Greenplum
exporter, so the two outputs never drift out of sync: `hierarchy_rows()`
and `yaml_rows()` produce the same data as the three original workbook
tabs, and `combined_rows()` unions all of it into the single flat
`nlg_hierarchy` table/sheet schema.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Tuple

from .model import DagNode
from .pipeline import Hierarchy

# Folders whose immediate child directory names *are* target_type values,
# regardless of how deeply the actual file is nested underneath (e.g.
# "sql_column_mapping/household/housekeeping_checklist_explorer/si_hk_529_no.yml"
# -> target_type = "household", not "housekeeping_checklist_explorer").
#
# NOTE: "insight_group_layout" is deliberately excluded from this rule --
# its target_type comes from file *content* (see SrcIndex._build_layout_index),
# not folder structure, because one file there defines many insight_types
# across potentially different target_types.
TARGET_TYPE_ROOT_FOLDERS = ("rules", "sql_column_mapping", "group_logic", "ref_table_columns")

COMBINED_COLUMNS = [
    "row_type", "dag", "dag_file_path", "sub_dag_taskgroup", "nested_taskgroup_path",
    "taskgroup_defined_in_file", "task", "full_task_path", "operator", "task_defined_in_file",
    "method_function", "method_defined_in_file", "method_called_from_files",
    "target_type", "insight_types", "product", "resolution", "notes",
    "yaml_file_name", "yaml_file_path", "is_insight_file", "insight_type",
]


def _iter_tasks_with_path(dag: DagNode):
    """Yields (group_path, task) where group_path is a list of
    (group_id, defined_in_function, source_file) from the DAG root down to
    (but not including) the task's own TaskGroup."""
    def walk(tasks, subgroups, path):
        for t in tasks:
            yield path, t
        for g in subgroups:
            yield from walk(g.tasks, g.subgroups,
                             path + [(g.group_id, g.defined_in_function, g.source_file)])
    yield from walk(dag.tasks, dag.groups, [])


def hierarchy_rows(hierarchy: Hierarchy) -> List[dict]:
    """One row per individual method/function record -- the task's directly
    resolved method AND every function/method found by walking what that
    method itself calls (previously bundled into a single "Call Chain"
    column; now each one is its own full record). If a file/task chain
    involves 10 methods, all 10 appear as 10 separate rows, each carrying
    the same DAG/TaskGroup/Task/Sub-DAG context columns."""
    rows = []
    for dag in hierarchy.dags:
        for path, task in _iter_tasks_with_path(dag):
            top_group = path[0][0] if path else ""
            nested_path = ".".join(p[0] for p in path[1:]) if len(path) > 1 else ""
            group_files = "; ".join(sorted(set(p[2] for p in path))) if path else ""
            methods = list(task.methods) + list(task.call_chain)
            if not methods:
                methods = [None]
            for m in methods:
                rows.append({
                    "DAG": dag.dag_id,
                    "DAG File Path": dag.source_file,
                    "Sub-DAG / TaskGroup": top_group,
                    "Nested TaskGroup Path": nested_path,
                    "TaskGroup Defined-In File(s)": group_files,
                    "Task": task.task_id,
                    "Full Task Path": task.full_task_id,
                    "Operator": task.operator,
                    "Task Defined-In File (DAG py)": task.source_file,
                    "Method / Function": m.name if m else "",
                    "Method Defined-In File": m.file if m else "",
                    "Method/Function Called From File(s)": "; ".join(m.called_from) if m and m.called_from else "",
                    "Target Type": task.target_type or "",
                    "Insight Types": ", ".join(task.insight_types) if task.insight_types else "",
                    "Product": task.product or "",
                    "Resolution": m.resolution if m else "unresolved",
                    "Notes": m.note if m else "",
                })
    return rows


def _target_type_task_map(hierarchy: Hierarchy) -> Dict[str, List[Tuple[str, str, str, str]]]:
    """target_type -> [(dag_id, top_taskgroup, task_id, full_task_id), ...]"""
    m: Dict[str, List[Tuple[str, str, str, str]]] = {}
    for dag in hierarchy.dags:
        for path, task in _iter_tasks_with_path(dag):
            if not task.target_type:
                continue
            top_group = path[0][0] if path else ""
            for tt in (x.strip() for x in task.target_type.split(",") if x.strip()):
                m.setdefault(tt, []).append((dag.dag_id, top_group, task.task_id, task.full_task_id))
    return m


def _infer_target_type(path: str, parent_dir: str, stem: str, tt_map: Dict[str, list]) -> Optional[str]:
    if path == "insight_group_layout" or path.startswith("insight_group_layout/"):
        return None  # handled by yaml_rows() via the content-driven layout index instead
    parts = path.split("/")
    for i, part in enumerate(parts[:-1]):
        if part in TARGET_TYPE_ROOT_FOLDERS and i + 1 < len(parts) - 0:
            return parts[i + 1]
    if parent_dir in tt_map:
        return parent_dir
    if stem in tt_map:
        return stem
    return None


def yaml_rows(hierarchy: Hierarchy) -> List[dict]:
    """Every .yml/.yaml file under nlg-src: folder-driven target_type files
    (rules/, sql_column_mapping/, group_logic/, ref_table_columns/, and the
    config/input_data_config/<target_type>.yml fallback) PLUS the
    content-driven insight_group_layout/ entries (one row per insight_type
    key found inside each file, with its own target_type from content)."""
    rows: List[dict] = []
    tt_map = _target_type_task_map(hierarchy)
    src_index = hierarchy.src_index

    # -- folder-driven files (everything except insight_group_layout) --
    yaml_paths = sorted(p for p in src_index.raw_files
                         if p.endswith((".yml", ".yaml"))
                         and not (p == "insight_group_layout" or p.startswith("insight_group_layout/")))
    for path in yaml_paths:
        base = path.rsplit("/", 1)[-1]
        parent_dir = path.rsplit("/", 2)[-2] if "/" in path else ""
        stem = base.rsplit(".", 1)[0]
        is_insight = base.startswith("si_")
        insight_type = base if is_insight else ""   # keeps "si_" prefix and extension, per spec
        candidate = _infer_target_type(path, parent_dir, stem, tt_map)
        mappings = tt_map.get(candidate, []) if candidate else []
        if not mappings:
            rows.append({"Target Type (inferred)": candidate or "(unmapped)", "YAML/YML File Name": base,
                         "File Path": path, "Is si_ Insight File": "Y" if is_insight else "N",
                         "Insight Type": insight_type, "DAG": "", "Sub-DAG / TaskGroup": "",
                         "Task": "", "Full Task Path": ""})
        else:
            for dag_id, top_group, task_id, full_task_id in sorted(set(mappings)):
                rows.append({"Target Type (inferred)": candidate, "YAML/YML File Name": base,
                             "File Path": path, "Is si_ Insight File": "Y" if is_insight else "N",
                             "Insight Type": insight_type, "DAG": dag_id, "Sub-DAG / TaskGroup": top_group,
                             "Task": task_id, "Full Task Path": full_task_id})

    # -- content-driven insight_group_layout entries --
    for tt, insight_key, path in src_index.all_layout_rows():
        base = path.rsplit("/", 1)[-1]
        mappings = tt_map.get(tt, [])
        if not mappings:
            rows.append({"Target Type (inferred)": tt, "YAML/YML File Name": base, "File Path": path,
                         "Is si_ Insight File": "Y", "Insight Type": insight_key, "DAG": "",
                         "Sub-DAG / TaskGroup": "", "Task": "", "Full Task Path": ""})
        else:
            for dag_id, top_group, task_id, full_task_id in sorted(set(mappings)):
                rows.append({"Target Type (inferred)": tt, "YAML/YML File Name": base, "File Path": path,
                             "Is si_ Insight File": "Y", "Insight Type": insight_key, "DAG": dag_id,
                             "Sub-DAG / TaskGroup": top_group, "Task": task_id, "Full Task Path": full_task_id})
    return rows


def combined_rows(hierarchy: Hierarchy) -> List[dict]:
    """Unions hierarchy_rows() + product-tagged subset + yaml_rows() into a
    single flat schema (COMBINED_COLUMNS) with a `row_type` discriminator:
    'DAG_HIERARCHY' | 'PRODUCT_HIERARCHY' | 'YAML_INSIGHT_TYPE'. This is the
    exact row-set written to the `nlg_hierarchy` XLSX sheet and the
    `nlg_hierarchy` Greenplum table."""
    out: List[dict] = []
    h_rows = hierarchy_rows(hierarchy)
    for r in h_rows:
        out.append({
            "row_type": "DAG_HIERARCHY",
            "dag": r["DAG"], "dag_file_path": r["DAG File Path"],
            "sub_dag_taskgroup": r["Sub-DAG / TaskGroup"], "nested_taskgroup_path": r["Nested TaskGroup Path"],
            "taskgroup_defined_in_file": r["TaskGroup Defined-In File(s)"], "task": r["Task"],
            "full_task_path": r["Full Task Path"], "operator": r["Operator"],
            "task_defined_in_file": r["Task Defined-In File (DAG py)"],
            "method_function": r["Method / Function"], "method_defined_in_file": r["Method Defined-In File"],
            "method_called_from_files": r["Method/Function Called From File(s)"],
            "call_chain": r["Call Chain (further functions called)"],
            "target_type": r["Target Type"], "insight_types": r["Insight Types"], "product": r["Product"],
            "resolution": r["Resolution"], "notes": r["Notes"],
            "yaml_file_name": "", "yaml_file_path": "", "is_insight_file": "", "insight_type": "",
        })
    # product rows: same shape, restricted to tasks carrying a product tag
    out_product = []
    for r in h_rows:
        if not r["Product"]:
            continue
        out_product.append({
            "row_type": "PRODUCT_HIERARCHY",
            "dag": r["DAG"], "dag_file_path": r["DAG File Path"],
            "sub_dag_taskgroup": r["Sub-DAG / TaskGroup"], "nested_taskgroup_path": r["Nested TaskGroup Path"],
            "taskgroup_defined_in_file": r["TaskGroup Defined-In File(s)"], "task": r["Task"],
            "full_task_path": r["Full Task Path"], "operator": r["Operator"],
            "task_defined_in_file": r["Task Defined-In File (DAG py)"],
            "method_function": r["Method / Function"], "method_defined_in_file": r["Method Defined-In File"],
            "method_called_from_files": r["Method/Function Called From File(s)"],
            "call_chain": r["Call Chain (further functions called)"],
            "target_type": r["Target Type"], "insight_types": r["Insight Types"], "product": r["Product"],
            "resolution": r["Resolution"], "notes": r["Notes"],
            "yaml_file_name": "", "yaml_file_path": "", "is_insight_file": "", "insight_type": "",
        })
    out.extend(out_product)

    for r in yaml_rows(hierarchy):
        out.append({
            "row_type": "YAML_INSIGHT_TYPE",
            "dag": r["DAG"], "dag_file_path": "", "sub_dag_taskgroup": r["Sub-DAG / TaskGroup"],
            "nested_taskgroup_path": "", "taskgroup_defined_in_file": "", "task": r["Task"],
            "full_task_path": r["Full Task Path"], "operator": "", "task_defined_in_file": "",
            "method_function": "", "method_defined_in_file": "", "method_called_from_files": "", "call_chain": "",
            "target_type": r["Target Type (inferred)"], "insight_types": "", "product": "",
            "resolution": "", "notes": "",
            "yaml_file_name": r["YAML/YML File Name"], "yaml_file_path": r["File Path"],
            "is_insight_file": r["Is si_ Insight File"], "insight_type": r["Insight Type"],
        })
    return out
