"""
Static (AST-based) extraction of the Airflow hierarchy:

    DAG -> TaskGroup (sub-DAG) -> nested TaskGroup(s) -> Task/sub-task

No LLM is required for this pass -- it is pure `ast` analysis of the
`nlg-dags` python files, generalised (not hard-coded to any single DAG),
so it works for `nlg_master.py`, `nlg_taskgroups.py`, and every other DAG
file in the repo (`nlg_prospect_master.py`, `staat_ds_nlg.py`, ...).

Two things are resolved lazily by later modules and only *stubbed* here:
  - the actual method/file a `python_callable` resolves to (see
    `dispatch_resolver.py` / `src_scanner.py`)
  - resource files (yaml/sql) associated with a task's `target_type`.
"""
from __future__ import annotations

import ast
from typing import Dict, List, Optional, Tuple, Set

from .model import TaskNode, TaskGroupNode, DagNode

OPERATOR_SUFFIXES = ("Operator", "Sensor")


def _get_callee_name(call: ast.Call) -> Optional[str]:
    f = call.func
    if isinstance(f, ast.Name):
        return f.id
    if isinstance(f, ast.Attribute):
        return f.attr
    return None


def _literal_or_src(node: ast.AST, src: str) -> object:
    try:
        return ast.literal_eval(node)
    except Exception:
        try:
            return ast.get_source_segment(src, node)
        except Exception:
            return None


def _kwargs_dict(call: ast.Call, src: str) -> Dict[str, object]:
    out = {}
    for kw in call.keywords:
        if kw.arg is None:
            continue
        out[kw.arg] = _literal_or_src(kw.value, src)
    return out


def _extract_op_kwargs(call: ast.Call, src: str) -> Dict[str, object]:
    for kw in call.keywords:
        if kw.arg == "op_kwargs" and isinstance(kw.value, ast.Dict):
            d = {}
            for k, v in zip(kw.value.keys, kw.value.values):
                key = _literal_or_src(k, src) if k is not None else None
                val = _literal_or_src(v, src)
                if key is not None:
                    d[key] = val
            return d
    return {}


def _extract_taskgroup_id(call: ast.Call, src: str) -> Optional[str]:
    if call.args:
        v = _literal_or_src(call.args[0], src)
        if isinstance(v, str):
            return v
    for kw in call.keywords:
        if kw.arg == "group_id":
            v = _literal_or_src(kw.value, src)
            if isinstance(v, str):
                return v
    return None


class ParsedModule:
    def __init__(self, file: str, src: str):
        self.file = file
        self.src = src
        self.tree = ast.parse(src, filename=file)
        self.func_defs: Dict[str, ast.FunctionDef] = {}
        for node in self.tree.body:
            if isinstance(node, ast.FunctionDef):
                self.func_defs[node.name] = node


class HierarchyExtractor:
    """Parses every DAG python file, builds a global function registry
    (for cross-file `import; module.func()` resolution), and produces one
    `DagNode` per `with DAG(...) as x:` block found."""

    def __init__(self, dag_files: Dict[str, str]):
        """dag_files: {relative_path: source_text}"""
        self.modules: Dict[str, ParsedModule] = {}
        self.func_registry: Dict[str, Tuple[ast.FunctionDef, str, str]] = {}  # name -> (node, file, src)
        for path, src in dag_files.items():
            try:
                pm = ParsedModule(path, src)
            except SyntaxError:
                continue
            self.modules[path] = pm
            for name, node in pm.func_defs.items():
                # first definition wins; note collisions for transparency
                if name not in self.func_registry:
                    self.func_registry[name] = (node, path, src)
            for top in pm.tree.body:
                for sub in ast.walk(top):
                    if isinstance(sub, ast.FunctionDef) and sub is not top:
                        if sub.name not in self.func_registry:
                            self.func_registry[sub.name] = (sub, path, src)
            # Also index nested (closure) function defs, e.g. a branching
            # helper defined *inside* a `get_xxx_taskgroup()` function --
            # these are still valid python_callable targets.
            for top in pm.tree.body:
                for sub in ast.walk(top):
                    if isinstance(sub, ast.FunctionDef) and sub is not top:
                        if sub.name not in self.func_registry:
                            self.func_registry[sub.name] = (sub, path, src)
        self._group_memo: Dict[str, Optional[TaskGroupNode]] = {}

    # ---------------------------------------------------------- helpers
    def _find_taskgroup_with(self, stmts: List[ast.stmt]):
        for stmt in stmts:
            if isinstance(stmt, ast.With):
                for item in stmt.items:
                    call = item.context_expr
                    if isinstance(call, ast.Call) and _get_callee_name(call) == "TaskGroup":
                        return stmt, call
        return None, None

    def _extract_task(self, call: ast.Call, callee: str, file: str, src: str, lineno: int) -> Optional[TaskNode]:
        kwargs = _kwargs_dict(call, src)
        task_id = kwargs.get("task_id")
        if not isinstance(task_id, str):
            return None
        python_callable = None
        pc_node = None
        for kw in call.keywords:
            if kw.arg == "python_callable":
                pc_node = kw.value
        if isinstance(pc_node, ast.Name):
            python_callable = pc_node.id
        elif isinstance(pc_node, ast.Attribute):
            python_callable = pc_node.attr

        op_kwargs = _extract_op_kwargs(call, src)
        sql_snippet = None
        sql_val = kwargs.get("sql")
        if isinstance(sql_val, str):
            sql_snippet = sql_val

        task = TaskNode(
            task_id=task_id,
            full_task_id=task_id,
            operator=callee,
            python_callable=python_callable,
            target_type=op_kwargs.get("target_type") if isinstance(op_kwargs.get("target_type"), str) else None,
            product=op_kwargs.get("product") if isinstance(op_kwargs.get("product"), str) else None,
            op_kwargs=op_kwargs,
            source_file=file,
            source_line=lineno,
            sql_snippet=sql_snippet,
        )
        return task

    def _walk_stmts(self, stmts: List[ast.stmt], group: TaskGroupNode, file: str, src: str,
                     stack: Set[str]):
        for stmt in stmts:
            if isinstance(stmt, ast.With):
                sub_stmt, tg_call = None, None
                for item in stmt.items:
                    call = item.context_expr
                    if isinstance(call, ast.Call) and _get_callee_name(call) == "TaskGroup":
                        tg_call = call
                        break
                if tg_call is not None:
                    gid = _extract_taskgroup_id(tg_call, src) or f"anon_group_L{stmt.lineno}"
                    sub = TaskGroupNode(group_id=gid, full_group_id=f"{group.full_group_id}.{gid}",
                                         defined_in_function="<inline>", source_file=file)
                    self._walk_stmts(stmt.body, sub, file, src, stack)
                    group.subgroups.append(sub)
                else:
                    self._walk_stmts(stmt.body, group, file, src, stack)
            elif isinstance(stmt, (ast.If,)):
                self._walk_stmts(stmt.body, group, file, src, stack)
                self._walk_stmts(stmt.orelse, group, file, src, stack)
            elif isinstance(stmt, (ast.For, ast.While)):
                self._walk_stmts(stmt.body, group, file, src, stack)
            elif isinstance(stmt, (ast.Assign, ast.Expr, ast.AnnAssign)):
                value = getattr(stmt, "value", None)
                if isinstance(value, ast.Call):
                    callee = _get_callee_name(value)
                    if callee and any(callee.endswith(suf) for suf in OPERATOR_SUFFIXES):
                        task = self._extract_task(value, callee, file, src, stmt.lineno)
                        if task:
                            task.full_task_id = f"{group.full_group_id}.{task.task_id}"
                            group.tasks.append(task)
                    elif callee and callee in self.func_registry and callee not in stack:
                        sub = self.resolve_group_function(callee, stack)
                        if sub is not None:
                            group.subgroups.append(sub)

    def resolve_group_function(self, func_name: str, stack: Optional[Set[str]] = None) -> Optional[TaskGroupNode]:
        if func_name in self._group_memo:
            return self._group_memo[func_name]
        if func_name not in self.func_registry:
            return None
        stack = set(stack or set())
        if func_name in stack:
            return None
        stack.add(func_name)
        node, file, src = self.func_registry[func_name]
        with_stmt, tg_call = self._find_taskgroup_with(node.body)
        if with_stmt is None:
            self._group_memo[func_name] = None
            return None
        gid = _extract_taskgroup_id(tg_call, src) or func_name
        group = TaskGroupNode(group_id=gid, full_group_id=gid, defined_in_function=func_name, source_file=file)
        self._walk_stmts(with_stmt.body, group, file, src, stack)
        self._group_memo[func_name] = group
        return group

    # ---------------------------------------------------------- DAGs
    def extract_dags(self) -> List[DagNode]:
        dags: List[DagNode] = []
        for path, pm in self.modules.items():
            handled_with_style = False
            # Style 1: `with DAG(...) as dag:` (context-manager, tasks nested inside)
            for stmt in ast.walk(pm.tree):
                if not isinstance(stmt, ast.With):
                    continue
                for item in stmt.items:
                    call = item.context_expr
                    if isinstance(call, ast.Call) and _get_callee_name(call) == "DAG":
                        dag = self._build_dag_node(call, path, pm.src, stmt.body)
                        if dag:
                            dags.append(dag)
                            handled_with_style = True
            # Style 2: `dag = DAG(...)` (plain assignment, tasks are separate
            # module-level statements referencing `dag=dag`) -- used by
            # nlg_prospect_master.py, staat_ds_nlg.py, etc.
            if not handled_with_style:
                for stmt in pm.tree.body:
                    if isinstance(stmt, ast.Assign) and isinstance(stmt.value, ast.Call) \
                            and _get_callee_name(stmt.value) == "DAG":
                        dag = self._build_dag_node(stmt.value, path, pm.src, pm.tree.body)
                        if dag:
                            dags.append(dag)
        return dags

    def _build_dag_node(self, dag_call: ast.Call, path: str, src: str, body_stmts: List[ast.stmt]) -> Optional[DagNode]:
        kwargs = _kwargs_dict(dag_call, src)
        dag_id = kwargs.get("dag_id")
        if not isinstance(dag_id, str) and dag_call.args:
            # dag_id passed positionally, e.g. DAG('nlg_prospect_alert_generation', ...)
            v = _literal_or_src(dag_call.args[0], src)
            if isinstance(v, str):
                dag_id = v
        if not isinstance(dag_id, str):
            return None
        dag = DagNode(
            dag_id=dag_id,
            source_file=path,
            description=kwargs.get("description") if isinstance(kwargs.get("description"), str) else "",
            schedule=str(kwargs.get("schedule_interval")) if kwargs.get("schedule_interval") is not None else None,
        )
        root_group = TaskGroupNode(group_id=dag_id, full_group_id=dag_id,
                                    defined_in_function="<dag_root>", source_file=path)
        self._walk_stmts(body_stmts, root_group, path, src, set())
        dag.tasks = root_group.tasks
        dag.groups = root_group.subgroups
        dag.triggers = self._find_triggers(body_stmts, src)
        return dag

    def _find_triggers(self, stmts: List[ast.stmt], src: str) -> List[str]:
        triggers = []
        for node in stmts:
            for sub in ast.walk(node):
                if isinstance(sub, ast.Call) and _get_callee_name(sub) == "TriggerDagRunOperator":
                    kwargs = _kwargs_dict(sub, src)
                    tid = kwargs.get("trigger_dag_id")
                    if isinstance(tid, str):
                        triggers.append(tid)
        return triggers
