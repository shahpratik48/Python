"""
Indexes the `nlg-src` (a.k.a. `nlg/src`) library so tasks discovered in the
DAG files can be resolved down to an actual method + file, so `target_type`
values can be mapped to their config/rule/layout resource files
(yaml/sql/ini), and so a resolved method's own call graph can be walked a
few levels deeper (e.g. NLG.generate_rule_narratives -> run_nlg ->
run_nlg_of_target_type -> run_nlg_of_insight_type -> ...).
"""
from __future__ import annotations

import ast
import posixpath
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple

from .model import ResourceRef

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None


@dataclass
class ClassInfo:
    name: str
    file: str
    methods: Set[str] = field(default_factory=set)


@dataclass
class FuncInfo:
    name: str
    file: str
    lineno: int
    owner_class: Optional[str] = None       # set if this is a class method, else None
    calls: Set[str] = field(default_factory=set)   # bare names of functions/methods this def calls (best-effort)


class SrcIndex:
    def __init__(self, src_files: Dict[str, str]):
        """src_files: {relative_path: content} for everything under nlg-src (py/yml/yaml/sql/ini)."""
        self.raw_files = src_files
        self.classes: Dict[str, ClassInfo] = {}
        self.functions: Dict[str, FuncInfo] = {}          # bare name -> FuncInfo (first definition wins)
        self.functions_all: Dict[str, List[FuncInfo]] = {}  # bare name -> every definition (handles same method name on multiple classes)
        self.module_by_dotted: Dict[str, str] = {}   # "nlg.src.foo.bar" -> file path
        self._resource_index: Dict[str, List[ResourceRef]] = {}
        # target_type -> [(insight_type_key, file_path), ...] parsed from
        # insight_group_layout/**/*.yml *content* (these files are not
        # organized by target_type folder -- the target_type lives inside
        # each insight_type block).
        self._layout_index: Dict[str, List[Tuple[str, str]]] = {}
        self._build_python_index()
        self._build_module_path_index()
        self._build_resource_index()
        self._build_layout_index()

    # ------------------------------------------------------------ python
    def _record_def(self, name: str, file: str, lineno: int, calls: Set[str], owner_class: Optional[str]):
        fi = FuncInfo(name=name, file=file, lineno=lineno, owner_class=owner_class, calls=calls)
        self.functions_all.setdefault(name, []).append(fi)
        if name not in self.functions:
            self.functions[name] = fi

    def _calls_in(self, node) -> Set[str]:
        calls = set()
        for sub in ast.walk(node):
            if isinstance(sub, ast.Call):
                f = sub.func
                if isinstance(f, ast.Name):
                    calls.add(f.id)
                elif isinstance(f, ast.Attribute):
                    calls.add(f.attr)
        return calls

    def _build_python_index(self):
        for path, content in self.raw_files.items():
            if not path.endswith(".py"):
                continue
            try:
                tree = ast.parse(content, filename=path)
            except SyntaxError:
                continue
            for node in tree.body:
                if isinstance(node, ast.ClassDef):
                    ci = self.classes.setdefault(node.name, ClassInfo(name=node.name, file=path))
                    for item in node.body:
                        if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                            ci.methods.add(item.name)
                            # class methods are call-graph nodes too -- this is what
                            # lets the tracer follow e.g. NLG.generate_rule_narratives
                            # into module-level helper functions it calls internally.
                            self._record_def(item.name, path, item.lineno, self._calls_in(item), node.name)
                elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    self._record_def(node.name, path, node.lineno, self._calls_in(node), None)

    def _build_module_path_index(self):
        # nlg-src root corresponds to "nlg.src" package; "foo/bar.py" -> "nlg.src.foo.bar"
        for path in self.raw_files:
            if not path.endswith(".py"):
                continue
            dotted = "nlg.src." + path[:-3].replace("/", ".")
            self.module_by_dotted[dotted] = path
        self.module_by_dotted_norm = {k.replace("nlg.src.src.", "nlg.src."): v
                                       for k, v in self.module_by_dotted.items()}

    def _build_resource_index(self):
        """One pass over every file, building {key -> [ResourceRef]} so that
        resources_for_target_type() becomes O(1) dict lookups per
        comma-separated target_type instead of an O(files) scan *per task*."""
        for path in self.raw_files:
            if not path.endswith((".yml", ".yaml", ".sql", ".ini")):
                continue
            if path.startswith("insight_group_layout/") or path == "insight_group_layout":
                continue  # handled separately by _build_layout_index (content-driven, not folder-driven)
            base = posixpath.basename(path)
            parent_dir = posixpath.basename(posixpath.dirname(path))
            stem = base.rsplit(".", 1)[0]

            if path.endswith((".yml", ".yaml")):
                tag = "insight_type" if base.startswith("si_") else "input_data_config"
                ref = ResourceRef(kind="yaml", path=path, tag=tag)
            elif path.endswith(".sql"):
                ref = ResourceRef(kind="sql", path=path, tag="sql")
            else:
                ref = ResourceRef(kind="ini", path=path, tag="ini")

            keys = {parent_dir, stem}
            if stem.startswith("si_"):
                keys.add(stem[len("si_"):])
            for key in keys:
                self._resource_index.setdefault(key, []).append(ref)

    def _build_layout_index(self):
        """insight_group_layout/**/*.yml files define MULTIPLE insight_types
        per file, each as a key under a top-level `insight_types:` mapping,
        with its own `target_type` field in the content, e.g.:

            insight_types:
              si_bknight_heloc_maturity_over1y_new_sbl:
                target_type: client_bknight
                ...

        Folder location is not meaningful here (unlike rules/, group_logic/,
        etc.) -- target_type must come from the file content itself."""
        if yaml is None:
            return
        for path, content in self.raw_files.items():
            if not (path.startswith("insight_group_layout/") or path == "insight_group_layout"):
                continue
            if not path.endswith((".yml", ".yaml")):
                continue
            try:
                data = yaml.safe_load(content)
            except Exception:
                continue
            if not isinstance(data, dict):
                continue
            insight_block = data.get("insight_types")
            if not isinstance(insight_block, dict):
                # fallback: some files might have si_* keys at the top level directly
                insight_block = {k: v for k, v in data.items() if isinstance(k, str) and k.startswith("si_")}
            for insight_key, entry in insight_block.items():
                if not isinstance(entry, dict):
                    continue
                tt = entry.get("target_type")
                if not isinstance(tt, str):
                    continue
                for single_tt in (t.strip() for t in tt.split(",") if t.strip()):
                    self._layout_index.setdefault(single_tt, []).append((insight_key, path))

    def layout_insight_types_for_target_type(self, target_type: str) -> List[Tuple[str, str]]:
        """Returns [(insight_type_key, file_path), ...] sourced from
        insight_group_layout content for the given (comma-separated)
        target_type."""
        out = []
        seen = set()
        for tt in (t.strip() for t in target_type.split(",") if t.strip()):
            for insight_key, path in self._layout_index.get(tt, []):
                if (insight_key, path) not in seen:
                    seen.add((insight_key, path))
                    out.append((insight_key, path))
        return out

    def all_layout_rows(self) -> List[Tuple[str, str, str]]:
        """Flat [(target_type, insight_type_key, file_path), ...] for every
        insight_group_layout entry found, regardless of whether any current
        DAG task references that target_type -- used by the YAML sheet so
        the workbook is a complete inventory."""
        out = []
        for tt, entries in self._layout_index.items():
            for insight_key, path in entries:
                out.append((tt, insight_key, path))
        return out

    # ------------------------------------------------------------ lookups
    def find_class_method_file(self, class_name: str, method_name: str) -> Optional[str]:
        ci = self.classes.get(class_name)
        if ci and method_name in ci.methods:
            return ci.file
        return None

    def find_function_file(self, func_name: str) -> Optional[str]:
        fi = self.functions.get(func_name)
        return fi.file if fi else None

    def resolve_name_to_file(self, name: str) -> Optional[Tuple[str, str]]:
        """Best-effort: resolve a bare function/method name to (file, kind).
        Tries module-level functions first, then any class method with that
        name. Name-based (no receiver-type resolution), consistent with the
        rest of this tool's static-analysis approach."""
        fi = self.functions.get(name)
        if fi:
            return fi.file, ("method" if fi.owner_class else "function")
        return None

    def calls_of(self, name: str) -> Set[str]:
        fi = self.functions.get(name)
        return fi.calls if fi else set()

    # ------------------------------------------------------------ resources
    def resources_for_target_type(self, target_type: str) -> List[ResourceRef]:
        """target_type may be comma-separated, e.g. 'market_event,market_event_bank_im'."""
        seen_paths = set()
        out: List[ResourceRef] = []
        for tt in (t.strip() for t in target_type.split(",") if t.strip()):
            for ref in self._resource_index.get(tt, []):
                if ref.path not in seen_paths:
                    seen_paths.add(ref.path)
                    out.append(ref)
        # also fold in insight_group_layout entries (content-driven)
        for insight_key, path in self.layout_insight_types_for_target_type(target_type):
            if path not in seen_paths:
                seen_paths.add(path)
                out.append(ResourceRef(kind="yaml", path=path, tag="insight_type_layout"))
        return out

    def insight_types_for_target_type(self, target_type: str) -> List[str]:
        names = []
        for r in self.resources_for_target_type(target_type):
            if r.tag == "insight_type":
                names.append(posixpath.basename(r.path))
        for insight_key, _path in self.layout_insight_types_for_target_type(target_type):
            names.append(insight_key)
        return sorted(set(names))
