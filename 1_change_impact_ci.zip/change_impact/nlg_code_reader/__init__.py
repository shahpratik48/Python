"""
nlg_code_reader -- reads the NLG source tree and works out its structure.

Given the repository's DAG and source files AS TEXT, this package builds
the hierarchy the impact agent reasons over: which DAG contains which task
group, which task calls which method, in which file. It answers "what does
this code reach?" by parsing, not by running anything.

It never imports Airflow and never executes a DAG. The name says what it
does -- it reads code -- so nobody mistakes it for something that runs in
Airflow.

Public surface used by nlg_impact_agent:
    config.Settings          where and how to fetch the source
    pipeline.build_hierarchy the parse -> Hierarchy
    pipeline.Hierarchy       the structure, with reachability helpers
    llm_client               the shared model client
"""

from .config import Settings
from .pipeline import build_hierarchy, run_impact_analysis, ask

__all__ = ["Settings", "build_hierarchy", "run_impact_analysis", "ask"]
