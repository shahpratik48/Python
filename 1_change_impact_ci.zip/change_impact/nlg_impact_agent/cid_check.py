"""
CID (client-identifying) attribute masking compliance check.

Deterministic-first, rule-based -- structurally distinct from the impact
agent's tool-calling loop, since most of this is clear-cut policy checking
rather than open-ended investigation.

Grounded in the real repo structure:
  - config/input_data_config/<target_type>.yml has a top-level
    <target_type>: {sql_column_mapping: {attr: sql_expr, ...}} block with
    the REAL (unmasked) SQL expression per attribute.
  - config/input_data_config_dummy/<target_type>.yml mirrors that same
    structure, but CID attributes are masked, e.g.
    `ip_frst_x: substring(MD5(b.ip_frst_x),1,8)`.
  - sql_column_mapping/<target_type>/**/*.yml files are flat
    {attr: sql_expr} dicts (a different, per-insight_type mapping,
    distinct from the inline sql_column_mapping key inside
    input_data_config).

SCOPE: this check only ever looks at attributes that are actually part of
this branch's changes, in a config/input_data_config/<tt>.yml file that
this branch itself changed. It is not a whole-repository audit -- a
target_type whose input_data_config file this branch didn't touch is out
of scope entirely, and within a changed file, only the attributes that
were added or whose SQL expression changed are checked (pre-existing,
untouched attributes are left alone).

An attribute is treated as CID by ANY of three independent signals:
  (a) it's already MD5-masked somewhere in input_data_config_dummy (the
      "established pattern" signal -- reliable, but by definition blind to
      an attribute that has never been masked anywhere before), or
  (b) its name matches a known PII-naming pattern (email, ssn, phone,
      dob, address, account/client name, etc.) -- fast and free, but a
      fixed keyword list necessarily misses real cases (e.g. this
      codebase's own `ip_frst_x`/`ip_last_x` -- individual profile first/
      last name -- match no keyword literally). Attribute names that look
      like boolean flags (has_email, is_verified, email_flag, ...) are
      explicitly EXCLUDED from this signal -- a flag indicating whether
      identifying data exists is not itself identifying data.
  (c) wasn't caught by (a) or (b), so an LLM is asked to judge whether the
      attribute name and its SQL expression look like client-identifying
      data -- given the other CID attributes already established for the
      same target_type as few-shot context. This is the only LLM-touched
      part of this module; everything else stays deterministic. Cost
      stays bounded to however many changed attributes an actual branch
      introduces (typically a handful), not every attribute in every file.

Three checks, run against the union of in-scope attributes recognized by
any signal:
  1. config/input_data_config_dummy/<target_type>.yml should exist
     alongside config/input_data_config/<target_type>.yml -- checked on
     both the branch and the base branch, for target_types whose real
     config file this branch changed.
  2. A CID attribute present in config/input_data_config/<tt>.yml must
     have a masked (MD5-wrapped) counterpart in
     config/input_data_config_dummy/<tt>.yml -- flagged as high severity
     if newly added on this branch, medium if it's a pre-existing gap
     that a modification on this branch didn't fix.
  3. A CID attribute already defined in config/input_data_config/<tt>.yml
     must NOT also appear as a key in any
     config/sql_column_mapping/<tt>/**/*.yml file.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None

MD5_PATTERN = re.compile(r"\bmd5\s*\(", re.IGNORECASE)
INPUT_DATA_CONFIG_PREFIX = "config/input_data_config/"
INPUT_DATA_CONFIG_DUMMY_PREFIX = "config/input_data_config_dummy/"
SQL_COLUMN_MAPPING_PREFIX = "sql_column_mapping/"

PII_NAME_KEYWORDS = [
    "email", "e_mail", "ssn", "social_security", "tax_id", "taxid",
    "phone", "mobile", "telephone",
    "dob", "date_of_birth", "birth_date", "birthdate",
    "address", "addr", "zip", "postal",
    "passport", "national_id", "ssi",
    "client_name", "customer_name", "full_name", "first_name", "last_name",
    "fname", "lname", "account_name", "account_title",
    "credit_card", "card_number", "card_num", "iban", "routing_number",
]
_PII_PATTERN = re.compile("|".join(re.escape(k) for k in PII_NAME_KEYWORDS), re.IGNORECASE)

# An attribute named like a boolean flag (has_email, is_verified,
# email_flag, dob_ind, ...) indicates the PRESENCE of some data, not the
# data itself -- explicitly excluded from the name-heuristic signal even
# if it contains a PII keyword. "has_email" is a true/false column, not an
# email address.
_BOOLEAN_FLAG_PREFIXES = ("has_", "is_", "does_", "flag_", "had_")
_BOOLEAN_FLAG_SUFFIXES = ("_flag", "_flg", "_ind", "_indicator", "_bool", "_yn", "_y_n", "_bit")


def _looks_like_boolean_flag(attr: str) -> bool:
    lower = attr.lower()
    return lower.startswith(_BOOLEAN_FLAG_PREFIXES) or lower.endswith(_BOOLEAN_FLAG_SUFFIXES)


def looks_like_pii_name(attr: str) -> bool:
    if _looks_like_boolean_flag(attr):
        return False
    return bool(_PII_PATTERN.search(attr))


LLM_CID_SYSTEM_PROMPT = """You are a data-privacy reviewer for a financial-services codebase. Given an \
attribute name, the SQL expression that populates it, and a target_type context, judge whether this \
attribute holds client-identifying data (CID) -- information that could identify or help identify a \
specific individual or account holder (names, contact details, government IDs, dates of birth, \
addresses, account/household identifiers tied to a person, etc.). Purely aggregate, categorical, or \
metric data (counts, dates of an event, product/category labels, monetary amounts not tied to \
identity) is NOT CID. A BOOLEAN FLAG indicating whether identifying data exists or some condition is \
true (e.g. has_email, is_verified, dob_on_file) is NOT itself CID, even if its name references a PII \
concept -- it is a true/false indicator, not the identifying value.

You will also be given a few attribute names already established as CID in this same codebase (via \
existing MD5 masking), as calibration for what counts as CID in this specific context -- use them as \
examples of the kind of attribute this organization already treats as sensitive, not as an exhaustive \
list.

Reply with strict JSON only, no markdown fences:
{"is_cid": true|false, "confidence": "low|medium|high", "reasoning": "<one sentence>"}"""


def llm_classify_attribute(attr: str, sql_expr: str, target_type: str, settings,
                            known_cid_examples: Optional[List[str]] = None) -> Optional[dict]:
    """Asks the LLM to judge whether a single attribute is CID. Returns
    None if the LLM is unavailable or the call fails -- callers should
    treat that as "couldn't classify," not as "not CID" (see
    check_cid_compliance, which flags it for manual review either way)."""
    from nlg_code_reader import llm_client
    if not getattr(settings, "llm_enabled", False):
        return None
    examples = ", ".join(sorted(known_cid_examples or [])[:8]) or "(none available)"
    user_prompt = (
        f"target_type: {target_type}\n"
        f"attribute_name: {attr}\n"
        f"sql_expression: {sql_expr}\n"
        f"already-known CID attributes in this codebase (calibration examples): {examples}"
    )
    return llm_client.call_llm_json(settings, LLM_CID_SYSTEM_PROMPT, user_prompt)


@dataclass
class CidViolation:
    target_type: str
    attribute: str
    violation_type: str   # "missing_dummy_file" | "cid_not_masked_in_dummy" | "cid_duplicated_in_sql_column_mapping"
    detail: str
    severity: str = "high"
    basis: str = "md5_registry"   # "md5_registry" | "name_heuristic" | "llm_judgment" -- see module docstring


def _load_yaml_dict(raw_files: Dict[str, str], path: str) -> dict:
    if yaml is None or path not in raw_files:
        return {}
    try:
        data = yaml.safe_load(raw_files[path])
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def _sql_column_mapping_of(raw_files: Dict[str, str], path: str, target_type: str) -> dict:
    data = _load_yaml_dict(raw_files, path)
    inner = data.get(target_type, data)
    if isinstance(inner, dict):
        mapping = inner.get("sql_column_mapping", {})
        return mapping if isinstance(mapping, dict) else {}
    return {}


def _changed_target_types(file_changes) -> Set[str]:
    """target_types whose config/input_data_config/<tt>.yml is actually
    part of this branch's changeset -- the scope boundary for this whole
    check. A target_type this branch never touched is not considered at
    all, regardless of what state its config is in."""
    out = set()
    for fc in file_changes or []:
        path = getattr(fc, "new_path", None) or getattr(fc, "old_path", None)
        if path and path.startswith(INPUT_DATA_CONFIG_PREFIX) and path.endswith((".yml", ".yaml")):
            name = path[len(INPUT_DATA_CONFIG_PREFIX):].rsplit(".", 1)[0]
            if "/" not in name:
                out.add(name)
    return out


def build_global_cid_registry(raw_files: Dict[str, str]) -> Set[str]:
    """Every attribute name masked with MD5(...) ANYWHERE across all
    input_data_config_dummy files -- signal (a). Intentionally scans the
    WHOLE codebase (not just branch-changed files): this is the reference/
    calibration signal, not itself something being flagged."""
    registry = set()
    for path in raw_files:
        if not (path.startswith(INPUT_DATA_CONFIG_DUMMY_PREFIX) and path.endswith((".yml", ".yaml"))):
            continue
        tt = path[len(INPUT_DATA_CONFIG_DUMMY_PREFIX):].rsplit(".", 1)[0]
        mapping = _sql_column_mapping_of(raw_files, path, tt)
        for attr, expr in mapping.items():
            if isinstance(expr, str) and MD5_PATTERN.search(expr):
                registry.add(attr)
    return registry


def check_cid_compliance(hierarchy_after, hierarchy_before, file_changes,
                          branch_name: str = "branch", base_branch_name: str = "base branch",
                          settings=None, use_llm_signal: bool = True) -> List[CidViolation]:
    """Checks CID masking compliance, SCOPED to attributes that are part
    of this branch's changes, in an input_data_config file this branch
    actually changed (see module docstring). `file_changes` is the
    deterministic changeset from change_analyzer.py -- required, since it
    defines the scope boundary. `hierarchy_before` is used to know exactly
    which attributes within a changed file were added or modified by this
    branch; if unavailable, every attribute in a confirmed-changed file is
    conservatively treated as in-scope. `settings` (with a configured LLM)
    enables the third, LLM-judgment signal."""
    violations: List[CidViolation] = []
    raw_after = hierarchy_after.src_index.raw_files
    raw_before = hierarchy_before.src_index.raw_files if hierarchy_before else {}

    global_cid = build_global_cid_registry(raw_after)
    if raw_before:
        global_cid |= build_global_cid_registry(raw_before)
    llm_enabled = use_llm_signal and settings is not None and getattr(settings, "llm_enabled", False)

    for tt in sorted(_changed_target_types(file_changes)):
        real_path = f"{INPUT_DATA_CONFIG_PREFIX}{tt}.yml"
        dummy_path = f"{INPUT_DATA_CONFIG_DUMMY_PREFIX}{tt}.yml"

        if dummy_path not in raw_after:
            violations.append(CidViolation(
                tt, "(file)", "missing_dummy_file",
                f"{dummy_path} does not exist on '{branch_name}', but {real_path} was changed by this branch.",
            ))
        if raw_before and dummy_path not in raw_before:
            violations.append(CidViolation(
                tt, "(file)", "missing_dummy_file",
                f"{dummy_path} does not exist on '{base_branch_name}' either.",
                severity="medium",
            ))
        if dummy_path not in raw_after:
            continue

        real_mapping_after = _sql_column_mapping_of(raw_after, real_path, tt)
        real_mapping_before = _sql_column_mapping_of(raw_before, real_path, tt) if raw_before else {}
        dummy_mapping_after = _sql_column_mapping_of(raw_after, dummy_path, tt)

        added_attrs = set(real_mapping_after) - set(real_mapping_before)
        modified_attrs = {
            a for a in (set(real_mapping_after) & set(real_mapping_before))
            if real_mapping_after.get(a) != real_mapping_before.get(a)
        }
        if raw_before:
            in_scope_attrs = added_attrs | modified_attrs
        else:
            in_scope_attrs = set(real_mapping_after)

        tt_cid_examples = [a for a in dummy_mapping_after if a in global_cid]

        for attr in sorted(in_scope_attrs):
            is_newly_added = attr in added_attrs
            in_md5_registry = attr in global_cid
            matches_name_heuristic = looks_like_pii_name(attr)

            basis = None
            llm_result = None
            if in_md5_registry:
                basis = "md5_registry"
            elif matches_name_heuristic:
                basis = "name_heuristic"
            elif llm_enabled:
                llm_result = llm_classify_attribute(
                    attr, str(real_mapping_after.get(attr, "")), tt, settings,
                    known_cid_examples=tt_cid_examples or sorted(global_cid),
                )
                if llm_result and llm_result.get("is_cid"):
                    basis = "llm_judgment"

            if basis is None:
                continue

            dummy_expr = dummy_mapping_after.get(attr)
            is_masked = isinstance(dummy_expr, str) and MD5_PATTERN.search(dummy_expr)
            if not is_masked:
                if basis == "md5_registry":
                    basis_note = "an established MD5-masking pattern elsewhere in input_data_config_dummy"
                elif basis == "name_heuristic":
                    basis_note = ("its name matching a known PII pattern (e.g. 'email') -- verify manually, "
                                   "this is a name-based signal, not a confirmed pattern match")
                else:
                    conf = llm_result.get("confidence", "?") if llm_result else "?"
                    reasoning = llm_result.get("reasoning", "") if llm_result else ""
                    basis_note = (f"an LLM judgment ({conf} confidence: {reasoning}) -- not caught by the "
                                   f"masking-history or name-pattern signals; verify manually, this is the "
                                   f"least certain of the three signals")
                violations.append(CidViolation(
                    tt, attr, "cid_not_masked_in_dummy",
                    f"'{attr}' is a" + (" newly added" if is_newly_added else " modified") +
                    f" CID attribute on this branch (recognized via {basis_note}) in {real_path}, but is "
                    f"missing or not MD5-masked in {dummy_path}.",
                    severity="high" if is_newly_added else "medium",
                    basis=basis,
                ))

            for path in raw_after:
                if not (path.startswith(f"{SQL_COLUMN_MAPPING_PREFIX}{tt}/") and path.endswith((".yml", ".yaml"))):
                    continue
                flat = _load_yaml_dict(raw_after, path)
                if attr in flat:
                    violations.append(CidViolation(
                        tt, attr, "cid_duplicated_in_sql_column_mapping",
                        f"'{attr}' is a CID attribute (basis: {basis}) added/changed on this branch in "
                        f"{real_path}, but is also present in {path} (sql_column_mapping/) for the same "
                        f"target_type -- should not be duplicated there.",
                        basis=basis,
                    ))

    return violations
