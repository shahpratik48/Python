"""
Turns a raw file-level diff (from git_diff.get_compare) into structured,
semantic change records -- and NOT limited to function/method bodies.
A change can be:

  - inside a function/method (its body differs -- calls added/removed,
    or some other internal change like a literal/condition/logic change)
  - the function/method itself added/removed
  - a whole class added/removed
  - a class-level attribute (not a method) added/removed/changed
  - MODULE-level: an import added/removed/changed, a module-level
    constant/config dict added/removed/changed, or any other top-level
    statement

All are surfaced as evidence for the agent -- nothing is silently
dropped just because it isn't a function body. This is pure static
analysis (no LLM); only the *judgment* about what each fact means for
testing scope is left to the agent (agent.py).
"""
from __future__ import annotations

import ast
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set

from .git_diff import CompareResult, FileDiff


@dataclass
class FunctionChange:
    name: str                      # bare name (function or method)
    owner_class: Optional[str]     # class name if this is a method, else None
    kind: str                      # "added" | "removed" | "modified"
    calls_added: List[str] = field(default_factory=list)     # only meaningful for kind == "modified"
    calls_removed: List[str] = field(default_factory=list)
    body_changed_beyond_calls: bool = False    # True if source differs but no call-set change was detected
                                                 # (e.g. a changed literal, condition, or logic) -- inspect
                                                 # old_snippet/new_snippet for the actual difference
    old_snippet: str = ""
    new_snippet: str = ""


@dataclass
class TopLevelChange:
    """A change OUTSIDE any function/method body: a module-level import,
    constant, config dict, or other top-level statement; or a class-level
    attribute (not a method); or a whole class added/removed."""
    key: str                       # e.g. "MAX_RETRY_ATTEMPTS", "import:pluralizer", "NLG.DEFAULT_TIMEOUT_SECONDS", "class:NLG"
    scope: str                     # "module" | "class_attribute" | "class"
    kind: str                      # "added" | "removed" | "modified"
    old_snippet: str = ""
    new_snippet: str = ""


@dataclass
class FileChange:
    old_path: str
    new_path: str
    change_type: str               # "added" | "deleted" | "renamed" | "modified"
    is_python: bool
    function_changes: List[FunctionChange] = field(default_factory=list)
    top_level_changes: List[TopLevelChange] = field(default_factory=list)
    raw_diff: str = ""             # used as-is for non-Python files, or when AST parsing fails


# ---------------------------------------------------------------- functions/methods
def _calls_in(node) -> Set[str]:
    calls = set()
    for sub in ast.walk(node):
        if isinstance(sub, ast.Call):
            f = sub.func
            if isinstance(f, ast.Name):
                calls.add(f.id)
            elif isinstance(f, ast.Attribute):
                calls.add(f.attr)
    return calls


def _unparse(node) -> str:
    try:
        return ast.unparse(node)
    except Exception:
        return ""


def _defs_with_calls(body: List[ast.stmt]) -> Dict[str, dict]:
    """name -> {owner_class, source, calls} for every function AND class
    method found in `body` (module body or, recursively, class bodies).
    Name-based (same convention as the rest of nlg_code_reader's tooling),
    so a name collision across unrelated classes is a known, documented
    limitation -- see README."""
    out: Dict[str, dict] = {}
    for node in body:
        if isinstance(node, ast.ClassDef):
            for item in node.body:
                if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    out[item.name] = {"owner_class": node.name, "source": _unparse(item), "calls": _calls_in(item)}
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            out[node.name] = {"owner_class": None, "source": _unparse(node), "calls": _calls_in(node)}
    return out


def diff_functions(old_content: str, new_content: str) -> List[FunctionChange]:
    """Compares every function/method definition between two versions of a
    file's content and classifies each as added / removed / modified (with
    call-level added/removed detail, and a flag for internal changes that
    AREN'T call additions/removals -- e.g. a changed literal or condition).
    Unchanged functions are NOT included -- only real deltas."""
    try:
        old_body = ast.parse(old_content).body if old_content else []
    except SyntaxError:
        old_body = []
    try:
        new_body = ast.parse(new_content).body if new_content else []
    except SyntaxError:
        new_body = []

    old_defs = _defs_with_calls(old_body)
    new_defs = _defs_with_calls(new_body)
    changes: List[FunctionChange] = []

    for name in sorted(set(old_defs) - set(new_defs)):
        d = old_defs[name]
        changes.append(FunctionChange(name=name, owner_class=d["owner_class"], kind="removed",
                                       old_snippet=d["source"]))

    for name in sorted(set(new_defs) - set(old_defs)):
        d = new_defs[name]
        changes.append(FunctionChange(name=name, owner_class=d["owner_class"], kind="added",
                                       new_snippet=d["source"]))

    for name in sorted(set(old_defs) & set(new_defs)):
        old_d, new_d = old_defs[name], new_defs[name]
        if old_d["source"] == new_d["source"]:
            continue  # byte-for-byte identical AST -- e.g. only a comment/docstring/whitespace changed
        calls_added = sorted(new_d["calls"] - old_d["calls"])
        calls_removed = sorted(old_d["calls"] - new_d["calls"])
        changes.append(FunctionChange(
            name=name, owner_class=new_d["owner_class"], kind="modified",
            calls_added=calls_added, calls_removed=calls_removed,
            body_changed_beyond_calls=not calls_added and not calls_removed,
            old_snippet=old_d["source"], new_snippet=new_d["source"],
        ))
    return changes


# ---------------------------------------------------------------- module/class level (outside functions)
def _statement_key(node: ast.stmt, index: int) -> str:
    """A stable-ish key for a non-def top-level statement, so it can be
    matched between old/new versions: variable name for assignments,
    module name for imports, else a positional fallback (still detected
    as added/removed if statements were inserted/deleted, just less
    precisely matched if heavily reordered -- get_raw_diff is the
    ground-truth fallback for exact line-level detail either way)."""
    if isinstance(node, ast.Assign) and node.targets:
        names = []
        for t in node.targets:
            if isinstance(t, ast.Name):
                names.append(t.id)
            elif isinstance(t, ast.Tuple):
                names.extend(e.id for e in t.elts if isinstance(e, ast.Name))
        if names:
            return "var:" + ",".join(names)
    if isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
        return "var:" + node.target.id
    if isinstance(node, ast.Import):
        return "import:" + ",".join(a.name for a in node.names)
    if isinstance(node, ast.ImportFrom):
        return "import_from:" + (node.module or "") + ":" + ",".join(a.name for a in node.names)
    return f"stmt#{index}:{type(node).__name__}"


def _non_def_statements(body: List[ast.stmt]) -> Dict[str, str]:
    """key -> unparsed source, for every statement in `body` that is NOT a
    function/method or class definition -- imports, module-level
    constants/config dicts, class attributes, and any other top-level
    statement (if/else blocks, setup calls executed at import time, etc.)."""
    out: Dict[str, str] = {}
    for i, node in enumerate(body):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            continue
        src = _unparse(node)
        if src:
            out[_statement_key(node, i)] = src
    return out


def _diff_statement_dict(old: Dict[str, str], new: Dict[str, str], scope: str,
                           key_prefix: str = "") -> List[TopLevelChange]:
    changes = []
    for k in sorted(set(old) - set(new)):
        changes.append(TopLevelChange(key=key_prefix + k, scope=scope, kind="removed", old_snippet=old[k]))
    for k in sorted(set(new) - set(old)):
        changes.append(TopLevelChange(key=key_prefix + k, scope=scope, kind="added", new_snippet=new[k]))
    for k in sorted(set(old) & set(new)):
        if old[k] != new[k]:
            changes.append(TopLevelChange(key=key_prefix + k, scope=scope, kind="modified",
                                            old_snippet=old[k], new_snippet=new[k]))
    return changes


def diff_top_level(old_content: str, new_content: str) -> List[TopLevelChange]:
    """Everything diff_functions() does NOT cover: module-level statements
    (imports, constants, config dicts, arbitrary top-level code) and
    class-level attributes (not methods), plus whole classes added/removed."""
    try:
        old_body = ast.parse(old_content).body if old_content else []
    except SyntaxError:
        old_body = []
    try:
        new_body = ast.parse(new_content).body if new_content else []
    except SyntaxError:
        new_body = []

    out: List[TopLevelChange] = []

    out.extend(_diff_statement_dict(_non_def_statements(old_body), _non_def_statements(new_body), scope="module"))

    old_classes = {n.name: n for n in old_body if isinstance(n, ast.ClassDef)}
    new_classes = {n.name: n for n in new_body if isinstance(n, ast.ClassDef)}

    for cname in sorted(set(old_classes) & set(new_classes)):
        out.extend(_diff_statement_dict(_non_def_statements(old_classes[cname].body),
                                          _non_def_statements(new_classes[cname].body),
                                          scope="class_attribute", key_prefix=f"{cname}."))
    for cname in sorted(set(new_classes) - set(old_classes)):
        out.append(TopLevelChange(key=f"class:{cname}", scope="class", kind="added",
                                    new_snippet=f"class {cname}(...): ...  # new class"))
    for cname in sorted(set(old_classes) - set(new_classes)):
        out.append(TopLevelChange(key=f"class:{cname}", scope="class", kind="removed",
                                    old_snippet=f"class {cname}(...): ...  # removed class"))

    return out


def analyze_changeset(compare: CompareResult, old_file_reader, new_file_reader) -> List[FileChange]:
    """`old_file_reader(path) -> str | None` and `new_file_reader(path) ->
    str | None` fetch a file's content at the base/head ref respectively
    (None if the file doesn't exist at that ref, e.g. a brand-new file).
    Returns one FileChange per file in the compare, each carrying its
    function-level changes, its top-level (module/class-attribute)
    changes (Python), or a raw diff hunk (everything else)."""
    out: List[FileChange] = []
    for d in compare.diffs:
        is_py = d.new_path.endswith(".py") or d.old_path.endswith(".py")
        fc = FileChange(old_path=d.old_path, new_path=d.new_path, change_type=d.change_type,
                         is_python=is_py, raw_diff=d.diff)
        if is_py:
            old_content = "" if d.new_file else (old_file_reader(d.old_path) or "")
            new_content = "" if d.deleted_file else (new_file_reader(d.new_path) or "")
            fc.function_changes = diff_functions(old_content, new_content)
            fc.top_level_changes = diff_top_level(old_content, new_content)
        out.append(fc)
    return out
