"""
Turns the raw transcript (report.transcript -- a plain list of chat
messages, exactly as sent to/received from the LLM) into a readable,
plain-text rendering: numbered steps, pretty-printed JSON arguments and
results, and large result lists intelligently truncated (showing the
first few items plus a count) so a 92-task result doesn't drown the page.

Usage:
    from nlg_impact_agent.transcript_format import format_transcript, export_transcript

    print(format_transcript(report))               # readable in a notebook/terminal
    export_transcript(report, "transcript.txt")     # readable in any text editor
"""
from __future__ import annotations

import json
from typing import Any

WIDTH = 92


def _truncate(obj: Any, max_list_items: int = 8, max_str_len: int = 500) -> Any:
    """Recursively shortens long lists/strings so the formatted output
    stays readable -- e.g. a 92-item task list becomes the first 8 plus
    a '... and 84 more' marker, not 92 lines of noise."""
    if isinstance(obj, dict):
        return {k: _truncate(v, max_list_items, max_str_len) for k, v in obj.items()}
    if isinstance(obj, list):
        if len(obj) > max_list_items:
            head = [_truncate(x, max_list_items, max_str_len) for x in obj[:max_list_items]]
            return head + [f"... and {len(obj) - max_list_items} more item(s) (truncated for readability)"]
        return [_truncate(x, max_list_items, max_str_len) for x in obj]
    if isinstance(obj, str) and len(obj) > max_str_len:
        return obj[: max_str_len] + f" ... [truncated, {len(obj)} chars total]"
    return obj


def _pretty(obj: Any) -> str:
    return json.dumps(obj, indent=2, default=str, ensure_ascii=False)


def _indent(text: str, prefix: str = "    ") -> str:
    return "\n".join(prefix + line for line in text.splitlines())


def format_transcript(report, max_list_items: int = 8, max_str_len: int = 500) -> str:
    """Returns the full transcript as one readable, plain-text string:
    a header, then one clearly-separated block per tool call showing the
    step number, the tool name and arguments, and the (truncated) result
    that came back."""
    lines = []
    lines.append("=" * WIDTH)
    lines.append("AGENT TOOL-CALL TRANSCRIPT".center(WIDTH))
    lines.append(f"branch: {report.branch}    base_branch: {report.base_branch}".center(WIDTH))
    lines.append("=" * WIDTH)
    lines.append("")

    step = 0
    for msg in report.transcript:
        role = msg.get("role")

        if role == "assistant" and msg.get("tool_calls"):
            for tc in msg["tool_calls"]:
                step += 1
                name = tc.get("function", {}).get("name", "?")
                raw_args = tc.get("function", {}).get("arguments") or "{}"
                try:
                    args = json.loads(raw_args)
                except Exception:
                    args = raw_args

                label = "FINAL CALL" if name == "finalize_report" else f"STEP {step}"
                lines.append(f"[{label}]  {name}(...)")
                lines.append("-" * WIDTH)
                lines.append("  arguments:")
                lines.append(_indent(_pretty(args), "    "))
                lines.append("")

        elif role == "tool":
            raw = msg.get("content", "")
            try:
                parsed = json.loads(raw)
                parsed = _truncate(parsed, max_list_items, max_str_len)
                pretty = _pretty(parsed)
            except Exception:
                pretty = raw[:max_str_len]

            lines.append("  result:")
            lines.append(_indent(pretty, "    "))
            lines.append("")
            lines.append("=" * WIDTH)
            lines.append("")

    if step == 0:
        lines.append("(no tool calls recorded in this transcript)")

    return "\n".join(lines)


def export_transcript(report, path: str, max_list_items: int = 8, max_str_len: int = 500) -> str:
    """Writes format_transcript()'s output to a plain-text file -- useful
    for sharing the transcript outside a notebook (email, ticket, review)."""
    import os
    text = format_transcript(report, max_list_items=max_list_items, max_str_len=max_str_len)
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)
    return path
