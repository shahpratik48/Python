"""
nlg_impact_agent
=================
Project 3: a genuinely agentic branch change-impact analyzer, separate
from (but reusing the config/GitLab/LLM/DB setup of) nlg_code_reader
(Project 1) and reusing nlg_code_reader's Hierarchy for structural
reachability.

Given a branch name, this:
  1. Diffs it against a base branch (default "develop") via GitLab's
     Compare API -- finds every file added/modified/deleted/renamed.
  2. AST-diffs every changed Python file into function/method/call-level
     changes (pure static analysis).
  3. Builds the full DAG/TaskGroup/Task hierarchy for both the branch and
     the base branch (reusing Project 1's build_hierarchy verbatim).
  4. Hands all of that to an LLM agent, as TOOLS it can call in whatever
     order and however many times it decides -- the agent autonomously
     investigates each change and produces a reasoned impact
     determination, not a pre-scripted "everything downstream is
     impacted" heuristic.
  5. Exports the result to an xlsx report (DAG/sub-DAG/TaskGroup/task/
     method/file detail + a Change & Impact column + a testing-scope
     summary sheet).

Always connects to GitLab -- local checkouts are intentionally not
supported here (ImpactSettings raises if local_dags_dir/local_src_dir are
set), since the entire point is analyzing a specific branch's real state.
"""
from .config import ImpactSettings
from .agent import analyze_branch_impact, ImpactReport
from .xlsx_report import export_xlsx, default_output_filename
from .verification import verify_report, summarize_verification
from .cid_check import check_cid_compliance, CidViolation
from .transcript_format import format_transcript, export_transcript

__all__ = ["ImpactSettings", "analyze_branch_impact", "ImpactReport", "export_xlsx", "default_output_filename",
           "verify_report", "summarize_verification", "check_cid_compliance", "CidViolation",
           "format_transcript", "export_transcript"]
