"""
Automated grounding verification for an ImpactReport.

This does NOT judge whether the agent's *conclusion* was the right call --
that's a human review question, and there's no ground-truth dataset to
score it against. What it DOES check, automatically and reliably: did the
agent's cited evidence (impacted_dags/impacted_tasks) actually match what
its own tools return when re-queried right now? If the agent's report says
"92 tasks" for a method but a fresh get_tasks_using_method call finds a
different set, that's a concrete, catchable grounding error -- the kind of
thing worth flagging before trusting a report at scale.

Usage:
    from nlg_impact_agent.verification import verify_report
    results = verify_report(report)
    for r in results:
        print(r["change"], "->", r["status"], r["notes"])
"""
from __future__ import annotations

from typing import List, Optional

from .agent_tools import AgentToolbox


def verify_report(report) -> List[dict]:
    """Re-runs the relevant tool(s) for every change in `report.changes`
    that cited impacted_dags/impacted_tasks, and compares the fresh result
    against what was claimed. Requires report.hierarchy_after (and,
    ideally, report.hierarchy_before) to still be attached -- true for any
    report produced by analyze_branch_impact() without being pickled/
    reloaded from disk in between."""
    if report.hierarchy_after is None:
        raise ValueError(
            "report.hierarchy_after is not available (e.g. the report was reloaded from a "
            "saved file rather than kept in memory from analyze_branch_impact()) -- verification "
            "needs the same hierarchy the agent used to re-check its claims."
        )

    toolbox = AgentToolbox(hierarchy_after=report.hierarchy_after, hierarchy_before=report.hierarchy_before,
                            file_changes=report.file_changes)

    results = []
    for change in report.changes:
        claimed_dags = set(change.get("impacted_dags") or [])
        claimed_tasks = set(change.get("impacted_tasks") or [])
        methods = change.get("impacted_methods") or []

        if not methods and not claimed_dags and not claimed_tasks:
            results.append({
                "change": change.get("change_description", ""), "file": change.get("file", ""),
                "status": "not_checkable",
                "notes": "No impacted_methods/dags/tasks were cited to re-check (e.g. a has_impact=false "
                         "change, or a config change checked via target_type -- not covered by this "
                         "verifier yet).",
            })
            continue

        actual_dags, actual_tasks = set(), set()
        checked_via = []
        for m in methods:
            hit = toolbox.get_tasks_using_method(m, ref="after")
            actual_dags.update(t.get("dag", "") for t in hit["tasks"])
            actual_tasks.update(t.get("task", "") for t in hit["tasks"])
            checked_via.append(f"get_tasks_using_method('{m}')")

        if not methods and change.get("file"):
            hit = toolbox.get_tasks_using_file(change["file"], ref="after")
            actual_dags.update(t.get("dag", "") for t in hit["tasks"])
            actual_tasks.update(t.get("task", "") for t in hit["tasks"])
            checked_via.append(f"get_tasks_using_file('{change['file']}')")

        dag_mismatch = claimed_dags and not claimed_dags.issubset(actual_dags)
        task_mismatch = claimed_tasks and not claimed_tasks.issubset(actual_tasks)

        if dag_mismatch or task_mismatch:
            status = "MISMATCH"
            notes = (f"Claimed dags {sorted(claimed_dags)} / tasks (n={len(claimed_tasks)}) do not fully "
                     f"match live tool results: actual dags {sorted(actual_dags)} / actual tasks "
                     f"(n={len(actual_tasks)}). Re-check this row manually.")
        else:
            status = "grounded"
            notes = f"Claims consistent with live results via {', '.join(checked_via)}."

        results.append({
            "change": change.get("change_description", ""), "file": change.get("file", ""),
            "status": status, "notes": notes,
        })

    return results


def summarize_verification(results: List[dict]) -> str:
    total = len(results)
    grounded = sum(1 for r in results if r["status"] == "grounded")
    mismatch = sum(1 for r in results if r["status"] == "MISMATCH")
    not_checkable = sum(1 for r in results if r["status"] == "not_checkable")
    return (f"{total} change(s): {grounded} grounded (evidence matches live tool results), "
            f"{mismatch} MISMATCH (needs manual review), "
            f"{not_checkable} not automatically checkable.")
