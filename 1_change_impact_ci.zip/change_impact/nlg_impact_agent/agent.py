"""
Ties everything together: given ImpactSettings (branch + base_branch),

  1. Fetches the file-level diff between branch and base_branch (GitLab
     Compare API -- git_diff.py).
  2. AST-diffs every changed Python file into function/call-level changes
     (change_analyzer.py) -- pure static analysis, no LLM.
  3. Builds Project 1's full DAG/TaskGroup/Task/method hierarchy for BOTH
     branch (after) and base_branch (before) -- reusing nlg_code_reader
     verbatim, so structural reachability (which tasks execute which code)
     is exactly as accurate as Project 1's.
  4. Hands the changeset + hierarchy access (as tools) to an LLM agent
     that autonomously decides what to inspect and produces the final,
     reasoned impact determination per change (agent_tools.py /
     agent_llm_client.py) -- this is the only step that isn't pure static
     analysis, because "does this change actually matter" is a judgment
     call, not a lookup.
  5. Returns a structured ImpactReport ready for xlsx_report.py.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, List, Optional

from nlg_code_reader.pipeline import build_hierarchy, Hierarchy

from .config import ImpactSettings
from .git_diff import get_compare, CompareResult
from .change_analyzer import analyze_changeset, FileChange
from .agent_tools import AgentToolbox, all_tool_schemas, make_tool_schemas
from .agent_llm_client import run_agent_loop
from .cid_check import check_cid_compliance, CidViolation
from .cid_check import check_cid_compliance, CidViolation

SYSTEM_PROMPT = """You are an expert code-change impact analyst for the NLG narrative-generation Airflow \
pipeline. A developer has made changes on a git branch, and your job is to determine EXACTLY which \
DAGs, TaskGroups, tasks, and methods are impacted -- precisely enough that a tester can scope their \
testing to only what actually needs verification.

Changes are NOT limited to inside a function/method body. A change can be:
- inside a function/method (its logic, a call it makes, a literal/condition it uses)
- the function/method itself, added or removed entirely
- a whole class, added or removed
- a class-level ATTRIBUTE (not a method) -- e.g. a default/config value defined on the class
- a MODULE-level statement outside any function or class -- an import added/changed/removed, a \
module-level constant or config dict added/changed/removed, or any other top-level code
list_changed_files() gives you BOTH function_level_changes AND top_level_changes for every file -- \
always check both, never assume a change is only ever inside a function body. Use \
get_top_level_change_detail for the full before/after of a module- or class-attribute-level change, \
the same way get_function_change_detail works for a function/method change. If a function is marked \
'modified' but calls_added/calls_removed are both empty, the change is something else internal to the \
function (a literal, condition, or logic change, not a new/removed call) -- read old_snippet vs \
new_snippet to see exactly what changed before judging impact.

You have tools to inspect the changeset (which files/functions/calls/imports/constants/attributes \
changed, and how) and the current DAG hierarchy (which tasks execute which code, today). Use them \
however many times you need, in whatever order makes sense -- there is no fixed sequence. Investigate \
every change before you conclude anything about it.

Critical principle: a code change does NOT automatically mean everything downstream is impacted, and \
NOT every changed file/function/constant is even reachable from a DAG task. Judge each change on its \
own merits:
- A brand-new function that nothing calls yet -> no current impact (note it for future reference, but \
has_impact should be false).
- A comment, docstring, logging statement, or purely cosmetic change -> no behavioral impact.
- A private helper function change where get_tasks_using_method finds zero tasks -> likely no impact \
(but double check get_callers_of_function too, in case it's called by another function that IS used, \
rather than directly by a task).
- A change to a widely-dispatched method (e.g. one used by many rule tasks) -> genuinely wide impact; \
say so explicitly and list the impacted tasks/DAGs.
- A module-level constant or config dict changed -> check get_callers_of_function for every function \
that reads it (a constant with no readers in the changeset's files has no impact; one read by a \
function used by many tasks has wide impact -- trace it the same way you'd trace a call).
- A changed/removed import -> check whether anything in the SAME changeset (or elsewhere) actually \
used the old imported name; an unused import changing has no impact, but a renamed import used \
throughout the file could break every function in that file.
- A class-level attribute change (e.g. a default/config value on the class) -> check every method of \
that class for whether it reads that attribute (via get_function_change_detail or get_raw_diff on the \
class's methods), then trace those methods' task reachability the normal way.
- A file rename -> check get_tasks_using_file with the OLD path (ref="before") to see who imported it; \
a rename with no impacted tasks might still break OTHER files in the same changeset that import the \
old name -- check get_callers_of_function too before concluding no impact.
- A removed function/call -> use ref="before" tools, since it no longer exists in the current hierarchy.
- A config/yaml value change -> use get_tasks_using_target_type.

For every entry in your final report, ground `impact_reasoning` in the SPECIFIC tool results you saw \
(cite task names, caller files, etc.) -- do not assert impact or its absence without evidence.

When you have investigated every change (function-level AND top-level) and are confident in your \
SECOND, AND EQUALLY IMPORTANT: judge whether the branch is COMPLETE.

A change made in one place often implies the same change elsewhere. A developer adds a key to one \
config but not its sibling; updates three of four call sites; wires a new insight_type into the SQL \
mapping but never into the dummy config or the DAG. None of that shows up as a "change" -- the \
evidence is in the files nobody touched.

You have repo-wide tools for exactly this: search_code, find_usages, find_definition, read_file and \
list_repo_files see the WHOLE branch, not only the diff. search_code and find_usages tell you which \
matching files the branch did NOT change; those are your candidates.

Work it deliberately. For each substantive change ask: what else mentions this symbol, key or \
pattern? Are there sibling files of the same kind? If four places matched and only three were \
touched, look at the fourth and decide whether it needed the same edit. Confirm with read_file \
before you report anything.

Report what you find in completeness_gaps, with file paths and line numbers as evidence. Report a \
low-confidence gap rather than staying silent -- a developer can dismiss a wrong suggestion in \
seconds, but will not find an omission you never mentioned. Equally, do not invent gaps: an empty \
list is the right answer when you looked and the branch is consistent.

When you have finished BOTH the impact assessment and the completeness review, call \
finalize_report exactly once with one entry per DISTINCT change (not one entry per \
file -- a file can have several changes), an overall_summary of the testing scope for this branch, AND \
a functional_summary explaining what this branch is actually FOR -- readable by someone who understands \
the business (which products/target_types/insights this affects and why) as well as someone who \
understands the code (which files/functions changed to achieve it), without requiring either reader to \
already know the other side."""


@dataclass
class ImpactReport:
    branch: str
    base_branch: str
    compare: CompareResult
    file_changes: List[FileChange]
    changes: List[dict]              # from the agent's finalize_report, one per distinct change
    overall_summary: str
    completeness_gaps: List[dict] = field(default_factory=list)   # possible missed edits
    functional_summary: str = ""     # what this branch is FOR, in both business and technical terms
    transcript: List[dict] = field(default_factory=list)   # full tool-call audit trail
    hierarchy_after: Optional[Hierarchy] = None    # kept for verify_report() -- avoids re-fetching from GitLab
    hierarchy_before: Optional[Hierarchy] = None
    cid_violations: List[CidViolation] = field(default_factory=list)   # from cid_check.py, deterministic, no LLM involved
    cid_violations: List[CidViolation] = field(default_factory=list)   # from cid_check.py, deterministic, no LLM involved


def analyze_branch_impact(settings: ImpactSettings,
                            progress: Optional[Callable[[str], None]] = None) -> ImpactReport:
    """The single entry point used by both the notebook and the Airflow
    DAG. `progress(message)` is an optional callback for status/log lines."""
    def log(msg):
        if progress:
            progress(msg)

    log(f"Comparing {settings.branch} against {settings.base_branch} on GitLab...")
    compare = get_compare(settings)
    log(f"{len(compare.diffs)} changed file(s) in scope (dags/nlg/dags + dags/nlg/src), "
        f"{len(compare.commits)} commit(s).")

    log(f"Building hierarchy from '{settings.branch}' (after)...")
    settings_after = _branch_settings(settings, settings.branch)
    hierarchy_after = build_hierarchy(settings_after)

    log(f"Building hierarchy from '{settings.base_branch}' (before)...")
    settings_before = _branch_settings(settings, settings.base_branch)
    hierarchy_before = build_hierarchy(settings_before)

    log("Running AST-level diff on changed Python files...")
    old_files = {f.old_path: content for f, content in _read_all(hierarchy_before, compare.diffs, "old")}
    new_files = {f.new_path: content for f, content in _read_all(hierarchy_after, compare.diffs, "new")}
    file_changes = analyze_changeset(
        compare,
        old_file_reader=lambda p: old_files.get(p),
        new_file_reader=lambda p: new_files.get(p),
    )
    n_func_changes = sum(len(fc.function_changes) for fc in file_changes)
    log(f"{n_func_changes} function/method-level change(s) found across {len(file_changes)} file(s).")

    log("Checking CID attribute masking compliance (input_data_config vs input_data_config_dummy vs sql_column_mapping)...")
    cid_violations = check_cid_compliance(hierarchy_after, hierarchy_before, file_changes,
                                            branch_name=settings.branch, base_branch_name=settings.base_branch,
                                            settings=settings)
    n_high = sum(1 for v in cid_violations if v.severity == "high")
    log(f"{len(cid_violations)} CID compliance issue(s) found ({n_high} high severity). "
        f"This check is deterministic -- not part of the agent's judgment.")

    log("Starting agent (tool-calling loop)...")
    toolbox = AgentToolbox(hierarchy_after=hierarchy_after, hierarchy_before=hierarchy_before,
                            file_changes=file_changes)

    def dispatch(name: str, args: dict) -> dict:
        return getattr(toolbox, name)(**args)

    user_prompt = (f"Branch '{settings.branch}' vs base '{settings.base_branch}'. "
                    f"{len(file_changes)} file(s) changed. Start by calling list_changed_files. "
                    f"Assess impact, then review the branch for INCOMPLETE changes using the "
                    f"repo-wide tools before you finalize.")

    def on_tool_call(name, args, i, total):
        log(f"  agent tool call [{i}/{total}]: {name}({args})")

    result, transcript = run_agent_loop(
        settings, SYSTEM_PROMPT, user_prompt, all_tool_schemas(), dispatch,
        max_iterations=settings.max_agent_iterations, on_tool_call=on_tool_call,
    )
    gaps = result.get("completeness_gaps", []) or []
    log(f"Agent finalized: {len(result.get('changes', []))} distinct change(s) assessed, "
        f"{len(gaps)} possible incomplete change(s).")
    for g in gaps:
        log(f"  POSSIBLY INCOMPLETE [{g.get('confidence','?')}]: {g.get('title','')}")

    return ImpactReport(
        branch=settings.branch, base_branch=settings.base_branch, compare=compare,
        file_changes=file_changes, changes=result.get("changes", []),
        overall_summary=result.get("overall_summary", ""),
        functional_summary=result.get("functional_summary", ""),
        completeness_gaps=gaps,
        transcript=transcript,
        hierarchy_after=hierarchy_after, hierarchy_before=hierarchy_before,
        cid_violations=cid_violations,
    )


def _branch_settings(settings: ImpactSettings, branch: str):
    """A plain nlg_code_reader.Settings (not ImpactSettings) pointed at a
    specific branch, reusing every other config value (LLM, GitLab
    project/paths, token) unchanged."""
    from nlg_code_reader.config import Settings as BaseSettings
    import dataclasses
    base_fields = {f.name for f in dataclasses.fields(BaseSettings)}
    kwargs = {k: v for k, v in dataclasses.asdict(settings).items() if k in base_fields}
    s = BaseSettings(**kwargs)
    s.default_base_branch = branch
    s.local_dags_dir = None
    s.local_src_dir = None
    return s


def _read_all(hierarchy: Hierarchy, diffs, which: str):
    """Yields (FileDiff, content) for every diff whose relevant side
    exists in this hierarchy's already-fetched source (no extra network
    calls -- build_hierarchy() already pulled everything)."""
    src_files = hierarchy.src_index.raw_files
    for d in diffs:
        path = d.old_path if which == "old" else d.new_path
        if not path:
            continue
        yield d, src_files.get(path)
