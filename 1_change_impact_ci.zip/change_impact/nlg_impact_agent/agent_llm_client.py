"""
A tool-calling chat loop against Azure OpenAI (or the internal LLM
Gateway, assumed OpenAI-compatible -- same assumption nlg_code_reader's
llm_client.py already makes). This is what makes the agent genuinely
agentic: the model receives the tool schemas and a system prompt
describing the task, and DECIDES for itself which tools to call and in
what order, based on what it's already learned -- there is no
pre-scripted sequence of tool calls here. The loop just executes whatever
the model asks for and feeds the result back, until the model calls
`finalize_report` or the iteration cap is hit.
"""
from __future__ import annotations

import json
from typing import Callable, Dict, List, Optional, Tuple

from nlg_code_reader.config import Settings


class AgentLoopError(RuntimeError):
    pass


def _post_chat(settings: Settings, messages: List[dict], tools: List[dict]) -> dict:
    """One request/response round-trip. Returns the raw assistant message
    dict (may contain `content` and/or `tool_calls`)."""
    import requests
    body = {
        "messages": messages,
        "tools": tools,
        "tool_choice": "auto",
        "temperature": settings.llm_temperature,
        "max_tokens": settings.llm_max_tokens,
    }
    if settings.llm_provider == "azure_openai":
        # One call, to the right URL for this endpoint, with the header the
        # v1 endpoint actually accepts. No "try the deployments form first
        # and fall back" -- that guess produced a 404 followed by a 403.
        from nlg_code_reader.azure_v1 import post_chat
        return post_chat(settings.azure_openai_endpoint, settings.azure_openai_api_key,
                         body, deployment=settings.azure_openai_deployment,
                         api_version=settings.azure_openai_api_version, timeout=180
                         )["choices"][0]["message"]
    elif settings.llm_provider == "azure_gateway":
        url = settings.llm_gateway_url.rstrip("/") + "/v1/chat/completions"
        headers = {"Authorization": f"Bearer {settings.llm_api_key}", "Content-Type": "application/json"}
        body["model"] = settings.llm_model
        r = requests.post(url, headers=headers, json=body, timeout=180)
    else:
        raise AgentLoopError(f"Unsupported/unconfigured LLM provider for the agent: {settings.llm_provider}")
    r.raise_for_status()
    data = r.json()
    return data["choices"][0]["message"]


def run_agent_loop(settings: Settings, system_prompt: str, user_prompt: str, tools: List[dict],
                    dispatch: Callable[[str, dict], dict], finalize_tool_name: str = "finalize_report",
                    max_iterations: int = 40,
                    on_tool_call: Optional[Callable[[str, dict, int, int], None]] = None
                    ) -> Tuple[dict, List[dict]]:
    """Runs the agentic tool-calling loop.

    `dispatch(tool_name, arguments) -> dict` executes ONE tool call (bound
    to AgentToolbox in agent.py) and returns its JSON-serializable result.
    `on_tool_call(name, arguments, iteration, max_iterations)` is an
    optional progress callback.

    Returns (finalize_report_arguments, full_message_transcript) -- the
    transcript is kept for audit/debugging even though the report is the
    primary output.
    """
    messages = [{"role": "system", "content": system_prompt}, {"role": "user", "content": user_prompt}]

    for iteration in range(1, max_iterations + 1):
        assistant_msg = _post_chat(settings, messages, tools)
        messages.append(assistant_msg)

        tool_calls = assistant_msg.get("tool_calls") or []
        if not tool_calls:
            # Model replied with plain text instead of calling a tool --
            # nudge it back on track rather than silently giving up.
            messages.append({"role": "user", "content":
                              f"You must call {finalize_tool_name} (or another tool) to proceed -- "
                              f"plain text replies aren't accepted. If you're done, call {finalize_tool_name} now."})
            continue

        for tc in tool_calls:
            name = tc["function"]["name"]
            try:
                args = json.loads(tc["function"].get("arguments") or "{}")
            except json.JSONDecodeError:
                args = {}

            if on_tool_call:
                on_tool_call(name, args, iteration, max_iterations)

            if name == finalize_tool_name:
                return args, messages

            try:
                result = dispatch(name, args)
            except Exception as e:
                result = {"error": f"{type(e).__name__}: {e}"}

            messages.append({
                "role": "tool", "tool_call_id": tc.get("id", ""), "name": name,
                "content": json.dumps(result, default=str)[:12000],   # keep transcript bounded
            })

    raise AgentLoopError(
        f"Agent did not call {finalize_tool_name} within {max_iterations} iterations. "
        f"Raise ImpactSettings.max_agent_iterations if the branch has an unusually large changeset, "
        f"or inspect the transcript to see where it got stuck."
    )
