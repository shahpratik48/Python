"""
GitLab access for the crew report.

Two things distinguish this from a per-project client:

**Recursive discovery.** Projects are not listed anywhere in configuration.
The crew's issue group and MR group are scanned with `include_subgroups`,
so every project in every sub-group beneath them is found automatically and
new repositories appear in the report without a config change.

**Full context per item.** Each issue carries the state history needed to
work out when it actually started (label events for "in progress",
iteration events for when it was scheduled), plus its iteration and epic.
Each merge request carries its commits, so the first file check-in can be
found.

**Parallel by default.** That per-item context is the whole cost of the
run: one HTTP round trip per issue for its label history, another for
iteration history where needed, and one per merge request for its commits.
Done sequentially that is thousands of round trips end to end, and it is
almost entirely waiting on the network rather than doing work -- so the
calls are issued from a thread pool. Each thread keeps its own session, and
the connection pool is sized to match, so connections are reused instead of
being renegotiated per request.
"""
from __future__ import annotations

import threading
import time
import urllib.parse
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Callable, Dict, Iterable, List, Optional

from delivery_settings import get_logger

log = get_logger("delivery.gitlab")


def parallel_map(fn: Callable, items: Iterable, workers: int, progress=None,
                 label: str = "", every: Optional[int] = None) -> List:
    """Runs `fn` over `items` in a thread pool, preserving input order.

    Progress cadence ADAPTS to the batch size. A fixed interval meant a
    148-item phase printed nothing until it finished -- two minutes of
    apparent silence that looked like a hang. The interval is now roughly a
    twentieth of the batch, bounded, so every phase reports steadily
    regardless of size, and each line carries elapsed time and an ETA so a
    long phase visibly moves.
    """
    items = list(items)
    n = len(items)
    if not n:
        return []
    if workers <= 1 or n == 1:
        return [fn(x) for x in items]

    if every is None:
        every = max(1, min(500, n // 20 or 1))

    out = [None] * n
    done = 0
    t0 = time.time()
    with ThreadPoolExecutor(max_workers=workers) as ex:
        futs = {ex.submit(fn, it): i for i, it in enumerate(items)}
        for fut in as_completed(futs):
            i = futs[fut]
            try:
                out[i] = fut.result()
            except Exception as e:
                log.error("%s task %d failed: %s", label or "parallel", i, e)
                out[i] = None
            done += 1
            if progress and (done % every == 0 or done == n):
                el = time.time() - t0
                rate = done / el if el > 0 else 0
                eta = (n - done) / rate if rate > 0 else 0
                progress("    %s %d/%d  (%.0fs elapsed, %.0f/s%s)"
                         % (label or "done", done, n, el, rate,
                            ", ~%.0fs left" % eta if done < n else ""))
    if progress:
        log.info("%s: %d item(s) in %.1fs", label or "phase", n, time.time() - t0)
    return out


class GitLabClient:
    def __init__(self, settings, workers: Optional[int] = None):
        import requests
        self._r = requests
        self.s = settings
        self.base = settings.gitlab_url.rstrip("/")
        self.workers = int(workers or getattr(settings, "max_workers", 12))
        self._local = threading.local()
        self._gid: Dict[str, int] = {}
        self._gid_lock = threading.Lock()
        log.info("GitLab client ready for %s (%d worker(s))", self.base, self.workers)

    @property
    def _sess(self):
        """One session per thread, with the pool sized to the worker count.

        A shared session would serialise on its connection pool and give
        back much of the parallelism; a fresh session per request would pay
        a new TLS handshake every time.
        """
        s = getattr(self._local, "sess", None)
        if s is None:
            from requests.adapters import HTTPAdapter
            try:
                from urllib3.util.retry import Retry
                retry = Retry(total=3, backoff_factor=0.6,
                              status_forcelist=[429, 500, 502, 503, 504],
                              allowed_methods=frozenset(["GET"]))
            except Exception:
                retry = 3
            s = self._r.Session()
            s.headers.update({"PRIVATE-TOKEN": self.s.gitlab_token})
            ad = HTTPAdapter(pool_connections=self.workers, pool_maxsize=self.workers * 2,
                             max_retries=retry)
            s.mount("https://", ad)
            s.mount("http://", ad)
            self._local.sess = s
        return s

    # ------------------------------------------------------------------ core
    def _get(self, path, params=None, allow_404=False):
        r = self._sess.get(self.base + "/api/v4" + path, params=params or {}, timeout=90)
        if r.status_code == 404 and allow_404:
            return None
        if r.status_code in (401, 403):
            log.warning("%s on %s -- token may lack access; treating as empty.",
                        r.status_code, path)
            return None
        r.raise_for_status()
        return r.json()

    def _paged(self, path, params=None, max_pages=200) -> List[dict]:
        out, page = [], 1
        params = dict(params or {})
        params.setdefault("per_page", 100)
        while page <= max_pages:
            params["page"] = page
            batch = self._get(path, params)
            if not batch:
                break
            out.extend(batch)
            if len(batch) < params["per_page"]:
                break
            page += 1
        if page > max_pages:
            log.warning("Hit the %d-page cap on %s -- results may be partial.", max_pages, path)
        return out

    def group_id(self, path: str) -> Optional[int]:
        with self._gid_lock:
            if path in self._gid:
                return self._gid[path]
        data = self._get("/groups/" + urllib.parse.quote(path, safe=""), allow_404=True)
        if not data:
            log.error("Group not found or not accessible: %s", path)
            return None
        with self._gid_lock:
            self._gid[path] = data["id"]
        log.info("Group '%s' -> id %s", path, data["id"])
        return data["id"]

    # ------------------------------------------------------- discovery
    def resolve_projects(self, paths) -> List[dict]:
        """Turns configured project paths into project records.

        A path may name a single project or a group. Projects are tried
        first, and anything that is not one is expanded as a group, so a
        pod can list either without the config having to say which.
        Resolution runs in parallel and de-duplicates by project id, since
        two pods may legitimately share a repository.
        """
        paths = [p for p in (paths or []) if str(p).strip()]
        if not paths:
            return []

        def _one(path):
            enc = urllib.parse.quote(path, safe="")
            proj = self._get("/projects/%s" % enc, allow_404=True)
            if proj and proj.get("id"):
                return [proj]
            found = self.discover_projects(path)
            if not found:
                log.warning("'%s' is neither a readable project nor a group with projects "
                            "-- skipped.", path)
            return found

        out, seen = [], set()
        for group in parallel_map(_one, paths, min(self.workers, max(1, len(paths))),
                                  None, "resolve"):
            for p in (group or []):
                if p.get("id") not in seen:
                    seen.add(p.get("id"))
                    out.append(p)
        log.info("Resolved %d configured path(s) to %d project(s).", len(paths), len(out))
        return out

    def discover_projects(self, group_path: str) -> List[dict]:
        """Every project beneath `group_path`, at any depth.

        Archived projects are excluded: they are not active work, and
        including them would inflate historical months with repositories
        the crew no longer runs.
        """
        if not group_path:
            return []
        gid = self.group_id(group_path)
        if gid is None:
            return []
        projects = self._paged("/groups/%s/projects" % gid,
                               {"include_subgroups": "true", "archived": "false",
                                "with_shared": "false", "order_by": "path", "sort": "asc"})
        log.info("Discovered %d project(s) beneath '%s'.", len(projects), group_path)
        for p in projects:
            log.debug("   %s", p.get("path_with_namespace"))
        return projects

    # ------------------------------------------------------------ issues
    def closed_issues(self, project_id: int, updated_after: str) -> List[dict]:
        return self._paged("/projects/%s/issues" % project_id,
                           {"state": "closed", "updated_after": updated_after,
                            "scope": "all", "order_by": "updated_at", "sort": "desc"}) or []

    def issue_label_events(self, project_id: int, iid: int) -> List[dict]:
        return self._paged("/projects/%s/issues/%s/resource_label_events" % (project_id, iid)) or []

    def issue_iteration_events(self, project_id: int, iid: int) -> List[dict]:
        """When an iteration was added to the issue -- this is what the crew
        treats as the issue being 'opened' for cycle-time purposes when no
        in-progress transition exists."""
        return self._paged(
            "/projects/%s/issues/%s/resource_iteration_events" % (project_id, iid)) or []

    def issue_state_events(self, project_id: int, iid: int) -> List[dict]:
        return self._paged("/projects/%s/issues/%s/resource_state_events" % (project_id, iid)) or []

    # ---------------------------------------------------- merge requests
    def merged_requests(self, project_id: int, updated_after: str) -> List[dict]:
        """MERGED merge requests only.

        Opened, closed-without-merging and locked ones are excluded
        entirely: the crew's lead-time measure is about delivered code, and
        an abandoned branch never delivered anything.
        """
        mrs = self._paged("/projects/%s/merge_requests" % project_id,
                          {"state": "merged", "updated_after": updated_after,
                           "scope": "all", "order_by": "updated_at", "sort": "desc"}) or []
        return [m for m in mrs if str(m.get("state", "")).lower() == "merged"]

    def merge_requests_all(self, project_id: int, updated_after: str) -> List[dict]:
        """Every merge request regardless of state.

        Listing costs the same number of requests as filtering to merged --
        one per project page -- so the extra states come essentially free and
        let the report show what was abandoned alongside what shipped. Only
        merged ones go on to a commit lookup or into a metric.
        """
        return self._paged("/projects/%s/merge_requests" % project_id,
                           {"state": "all", "updated_after": updated_after,
                            "scope": "all", "order_by": "updated_at", "sort": "desc"}) or []

    def mr_commits(self, project_id: int, iid: int) -> List[dict]:
        """Commits on a merge request.

        Only the EARLIEST commit matters here (the first file check-in), and
        GitLab returns commits newest-first -- so for a large MR we read the
        page count from the response header and jump straight to the last
        page rather than walking every page in between. Small MRs, which are
        the overwhelming majority, still cost exactly one request.
        """
        path = "/projects/%s/merge_requests/%s/commits" % (project_id, iid)
        url = self.base + "/api/v4" + path
        r = self._sess.get(url, params={"per_page": 100, "page": 1}, timeout=90)
        if r.status_code in (401, 403, 404):
            return []
        r.raise_for_status()
        first = r.json() or []
        if len(first) < 100:
            return first
        try:
            total_pages = int(r.headers.get("X-Total-Pages") or 1)
        except (TypeError, ValueError):
            total_pages = 1
        if total_pages <= 1:
            return first
        last = self._get(path, {"per_page": 100, "page": total_pages}) or []
        return first + last

    def mr_first_approved_at(self, project_id: int, iid: int):
        """When the merge request was FIRST approved, or None.

        Approvals are a Premium feature and the endpoint 404s where it is not
        available, so a missing value is normal rather than an error.
        """
        from delivery_metrics import parse_ts
        data = self._get("/projects/%s/merge_requests/%s/approvals" % (project_id, iid),
                         allow_404=True)
        if not data:
            return None
        stamps = []
        for a in (data.get("approved_by") or []):
            ts = parse_ts(a.get("created_at") or a.get("updated_at"))
            if ts:
                stamps.append(ts)
        if not stamps:
            ts = parse_ts(data.get("approved_at") or data.get("updated_at"))
            if ts and data.get("approved"):
                stamps.append(ts)
        return min(stamps) if stamps else None

    # -------------------------------------------------------- iterations
    def group_iterations(self, group_path: str) -> Dict[int, dict]:
        """`iteration id -> {title, cadence, start, due}` for the group tree.

        GitLab iterations very often have a NULL title -- the human name a
        board shows ("STAAT DS insight iteration") belongs to the iteration
        *cadence*, not the iteration. Issues only carry the iteration, so the
        cadence has to be resolved separately or every row ends up labelled
        "Iteration 4207".

        Fetched once for the whole run (a handful of requests), then looked
        up in memory per issue.
        """
        if not group_path:
            return {}
        gid = self.group_id(group_path)
        if gid is None:
            return {}

        cadences: Dict[int, str] = {}
        try:
            for c in self._paged("/groups/%s/iteration_cadences" % gid) or []:
                if c.get("id") and c.get("title"):
                    cadences[c["id"]] = str(c["title"])
            log.info("Resolved %d iteration cadence(s).", len(cadences))
        except Exception as e:
            log.warning("Could not list iteration cadences (%s) -- iteration names will fall "
                        "back to whatever the issue itself carries.", e)

        out: Dict[int, dict] = {}
        try:
            iters = self._paged("/groups/%s/iterations" % gid,
                                {"include_ancestors": "true", "state": "all"}) or []
        except Exception as e:
            log.warning("Could not list group iterations (%s).", e)
            return {}

        for it in iters:
            iid = it.get("id")
            if not iid:
                continue
            cad = it.get("iteration_cadence") or {}
            cad_title = str(cad.get("title") or cadences.get(cad.get("id"), "") or "")
            out[iid] = {"title": str(it.get("title") or ""), "cadence": cad_title,
                        "start": str(it.get("start_date") or ""),
                        "due": str(it.get("due_date") or "")}
        named = sum(1 for v in out.values() if v["title"] or v["cadence"])
        log.info("Resolved %d iteration(s), %d with a usable name.", len(out), named)
        return out

    # ------------------------------------------------------------- epics
    def epic(self, group_id: int, epic_iid: int) -> Optional[dict]:
        return self._get("/groups/%s/epics/%s" % (group_id, epic_iid), allow_404=True)


def folder_trail(project_path: str, base_group: str, sep: str = " | ") -> str:
    """The sub-group trail from the crew group down to the project.

    `.../staat-data-science/staat-ds-genesis/genesis-platform/nlg-dags`
    against base `.../staat-data-science`
    becomes `staat-ds-genesis | genesis-platform | nlg-dags`.

    Falls back to the full path when the project sits outside the base
    group, so nothing is silently blanked.
    """
    p = (project_path or "").strip("/")
    b = (base_group or "").strip("/")
    if b and p.startswith(b):
        rel = p[len(b):].strip("/")
    elif b:
        rel = p
    else:
        # no base to measure against -- show the last two segments, which is
        # the useful part (sub-group and repository) without the long prefix
        parts = [x for x in p.split("/") if x]
        rel = "/".join(parts[-2:])
    return sep.join([x for x in rel.split("/") if x])
