"""
The four delivery parameters, per month, for the whole crew.

    Issue Throughput        issues closed in the month, DIVIDED BY THE NUMBER
                            OF PODS in the crew -- the crew spans several
                            pods, so a raw count says more about headcount
                            than about delivery
    Cycle Time (Days)       average elapsed BUSINESS days per closed issue
                            (weekends excluded)
    Merged MR per Author    merged MRs / distinct authors
    Lead Time (Hrs)         average elapsed hours per merged MR

SCOPE -- which items feed the metrics and the graph:

    Issues      only those that actually reached IN PROGRESS and were then
                CLOSED. Measured from the FIRST in-progress transition to the
                LAST closed event. An issue that never went in progress is
                reported but not counted: its elapsed time would describe how
                long it sat in a backlog, not how long the work took.
                The slowest 15% by cycle time are then trimmed, so a handful
                of stale tickets cannot dominate the average.

    Merge requests   merged only, and only where the lead time is under one
                year. A year-old branch is noise rather than signal.

Everything outside that is still listed in full in the detail tables, marked
"Out of scope" with the reason -- excluded from the arithmetic, never hidden.

Cycle Time start point, in priority order -- kept for reporting, since an
out-of-scope issue still shows how it would have been measured:

    1. the first time the issue moved to IN PROGRESS   (the only in-scope case)
    2. otherwise, the day an ITERATION was assigned to it
    3. otherwise, the creation date

Which of the three was used is carried on every issue row, because an
iteration-based figure reads differently from an in-progress one and a
reader should be able to see which they are looking at.

Elapsed time is measured in BUSINESS days: Saturdays and Sundays are
excluded entirely, so an issue opened Friday and closed Monday counts as
roughly one day rather than three. Public holidays are not accounted for.

Lead Time runs from the FIRST FILE CHECK-IN -- the earliest commit on the
merge request -- to the merge itself. Only merged MRs are considered at
all; opened, closed-without-merging and locked ones never enter the data.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Sequence, Tuple

from delivery_settings import get_logger

log = get_logger("delivery.metrics")

METRIC_DEFS = [
    ("throughput", "Issue Throughput", False),
    ("cycle_time", "Cycle Time (Days)", True),
    ("mr_per_author", "Merged MR per Author", False),
    ("lead_time", "Lead Time (Hrs)", True),
]
METRIC_KEYS = [m[0] for m in METRIC_DEFS]
LOWER_IS_BETTER = {a: low for a, _l, low in METRIC_DEFS}

ONE_YEAR_HOURS = 365 * 24.0        # merge requests slower than this are noise

FROM_IN_PROGRESS = "in_progress"
FROM_ITERATION = "iteration_assigned"
FROM_CREATED = "created"


# ------------------------------------------------------------------ time
def parse_ts(v: Optional[str]) -> Optional[datetime]:
    if not v:
        return None
    t = str(v).strip().replace("Z", "+00:00")
    try:
        dt = datetime.fromisoformat(t)
    except ValueError:
        for f in ("%Y-%m-%dT%H:%M:%S.%f%z", "%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%d"):
            try:
                dt = datetime.strptime(t, f)
                break
            except ValueError:
                continue
        else:
            return None
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt.astimezone(timezone.utc)


def elapsed_days(a: datetime, b: datetime) -> Optional[float]:
    """Fractional BUSINESS days between two instants, excluding Sat/Sun.

    Walks the interval a day at a time and counts only the portion falling
    on a weekday, so Friday afternoon to Monday morning is well under one
    business day rather than three. Whole weekends contribute nothing.
    """
    if not a or not b or b < a:
        return None
    total, cur, guard = 0.0, a, 0
    while cur < b and guard < 4000:
        nxt = (cur + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
        seg_end = min(nxt, b)
        if cur.weekday() < 5:                     # Mon=0 .. Fri=4
            total += (seg_end - cur).total_seconds() / 86400.0
        cur, guard = seg_end, guard + 1
    return round(total, 2)


def elapsed_hours(a: datetime, b: datetime) -> Optional[float]:
    if not a or not b or b < a:
        return None
    return round((b - a).total_seconds() / 3600.0, 2)


def month_key(dt: datetime) -> str:
    return dt.strftime("%Y-%m")


def month_range(start: str, end: str) -> List[str]:
    y, m = (int(x) for x in start.split("-"))
    ey, em = (int(x) for x in end.split("-"))
    out = []
    while (y, m) <= (ey, em):
        out.append("%04d-%02d" % (y, m))
        m += 1
        if m > 12:
            y, m = y + 1, 1
    return out


def month_label(mk: str) -> str:
    y, m = mk.split("-")
    return "%s %s" % (["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul",
                       "Aug", "Sep", "Oct", "Nov", "Dec"][int(m) - 1], y[2:])


def month_start(mk: str) -> datetime:
    return datetime.strptime(mk + "-01", "%Y-%m-%d").replace(tzinfo=timezone.utc)


# ------------------------------------------------------------------ rows
@dataclass
class IssueRow:
    project_path: str
    folders: str
    iid: int
    title: str
    author: str
    assignee: str
    month: str
    measured_from: str
    start_at: Optional[datetime]
    closed_at: Optional[datetime]
    cycle_days: Optional[float]
    flagged: bool
    iteration_name: str = ""
    iteration_start: str = ""
    iteration_end: str = ""
    epic_id: str = ""
    epic_name: str = ""
    web_url: str = ""
    pod_name: str = ""            # which pod this belongs to, for the crew roll-up
    in_scope: bool = False        # counted in the metrics and the graph
    scope_reason: str = ""        # why it was excluded, when it was


@dataclass
class MRRow:
    project_path: str
    folders: str
    iid: int
    title: str
    author: str
    month: str
    first_commit_at: Optional[datetime]
    merged_at: Optional[datetime]
    lead_hours: Optional[float]
    flagged: bool
    web_url: str = ""
    mr_id: str = ""                       # global MR id, distinct from the per-project iid
    target_project_id: str = ""
    source_branch: str = ""
    target_branch: str = ""
    created_at: Optional[datetime] = None
    first_approved_at: Optional[datetime] = None
    pod_name: str = ""
    in_scope: bool = False
    scope_reason: str = ""


@dataclass
class MonthStats:
    month: str
    closed_count: int = 0            # raw issues closed
    throughput: Optional[float] = None   # closed_count / pod_count
    state_counts: Dict[str, int] = field(default_factory=dict)   # opened/merged/closed/locked
    cycle_time: Optional[float] = None
    mr_count: int = 0
    author_count: int = 0
    mr_per_author: Optional[float] = None
    lead_time: Optional[float] = None
    issues_flagged: int = 0
    mrs_flagged: int = 0
    from_in_progress: int = 0
    from_iteration: int = 0
    from_created: int = 0
    issues_total: int = 0          # every closed issue, in scope or not
    issues_out_of_scope: int = 0
    mrs_total: int = 0
    mrs_out_of_scope: int = 0

    @property
    def from_opened(self) -> int:
        """Issues whose clock started at the iteration assignment or, failing
        that, at creation -- both are "opened" in the crew's terms."""
        return self.from_iteration + self.from_created

    @property
    def not_measurable(self) -> int:
        return max(0, self.closed_count - self.from_in_progress - self.from_opened)

    @property
    def issues_in_scope(self) -> int:
        return self.closed_count

    def value(self, k):
        return getattr(self, k)


# ------------------------------------------------------------------ helpers
def first_in_progress(events: List[dict], wanted: Sequence[str]) -> Optional[datetime]:
    """Earliest moment an 'in progress' style label was ADDED."""
    w = [x.lower() for x in wanted]
    stamps = []
    for ev in events or []:
        if str(ev.get("action", "")).lower() != "add":
            continue
        name = str((ev.get("label") or {}).get("name", "")).lower()
        if not name:
            continue
        tail = name.split("::")[-1].strip()
        if any(x == name or x == tail or x in name for x in w):
            ts = parse_ts(ev.get("created_at"))
            if ts:
                stamps.append(ts)
    return min(stamps) if stamps else None


def last_closed(events: List[dict]) -> Optional[datetime]:
    """The LAST time the issue was closed, from its state history.

    An issue reopened and closed again should be measured to the final
    closure, not the first -- the work genuinely continued past it.
    """
    stamps = []
    for ev in events or []:
        if str(ev.get("state", "")).lower() == "closed":
            ts = parse_ts(ev.get("created_at"))
            if ts:
                stamps.append(ts)
    return max(stamps) if stamps else None


def first_iteration_assigned(events: List[dict]) -> Optional[datetime]:
    """Earliest moment an iteration was ADDED to the issue."""
    stamps = []
    for ev in events or []:
        if str(ev.get("action", "")).lower() not in ("add", "added"):
            continue
        ts = parse_ts(ev.get("created_at"))
        if ts:
            stamps.append(ts)
    return min(stamps) if stamps else None


def _iteration_name(it: dict, lookup: Dict[int, dict]):
    """The name a board would show for this iteration, plus its dates.

    Priority: the iteration's own title, then its CADENCE name (which is what
    is normally displayed, since iteration titles are usually null), then a
    date range, and only as a last resort the bare id.
    """
    if not it:
        return "", "", ""
    ref = lookup.get(it.get("id")) or {}
    title = str(it.get("title") or ref.get("title") or "").strip()
    cadence = str(ref.get("cadence") or (it.get("iteration_cadence") or {}).get("title")
                  or "").strip()
    start = str(it.get("start_date") or ref.get("start") or "")
    due = str(it.get("due_date") or ref.get("due") or "")

    if title and cadence and title.lower() != cadence.lower():
        name = "%s - %s" % (cadence, title)
    else:
        name = title or cadence
    if not name:
        name = ("%s to %s" % (start, due)) if (start and due) else ("Iteration %s" % it.get("id"))
    return name, start, due


def _person(o, fallback="unknown") -> str:
    if not o:
        return fallback
    return str(o.get("name") or o.get("username") or fallback)


# ------------------------------------------------------------------ collect
def collect(client, settings, months: List[str], progress=None):
    """Scans every project under the crew's groups and builds one row per
    closed issue and per merged MR inside the reporting window.

    Runs in phases rather than item by item. The per-item context -- label
    history, iteration history, MR commits -- is one HTTP round trip each
    and is the entire cost of the job. Gathering the lists first and then
    issuing all the detail calls through a thread pool turns thousands of
    sequential waits into a handful of concurrent batches.
    """
    from delivery_gitlab import folder_trail, parallel_map

    def say(msg):
        log.info(msg)
        if progress:
            progress(msg)

    workers = int(getattr(settings, "max_workers", 12))
    earliest = month_start(months[0]).isoformat()
    in_window = set(months)

    # Resolved once for the whole run so every issue can be given the name a
    # board actually shows, rather than a bare iteration id.
    try:
        iteration_lookup = client.group_iterations(pod.group_path if pod else "")
    except Exception as e:
        log.warning("Iteration lookup unavailable (%s).", e)
        iteration_lookup = {}

    pod = getattr(settings, "pod", None)
    pod_name = pod.name if pod else ""

    # ============================ ISSUES ============================
    # Projects are listed explicitly per pod rather than discovered by
    # scanning a group: a pod's issue boards and its MR repositories live in
    # different parts of the tree, and only the config knows which belong
    # together.
    issue_paths = list(pod.issue_projects) if pod else []
    say("Pod '%s': resolving %d issue project(s)..." % (pod_name, len(issue_paths)))
    projects = client.resolve_projects(issue_paths)
    say("  %d project(s); fetching closed issues with %d worker(s)..."
        % (len(projects), workers))

    def _issues_for(proj):
        try:
            return proj, client.closed_issues(proj["id"], earliest)
        except Exception as e:
            log.error("  issues failed for %s: %s", proj.get("path_with_namespace"), e)
            return proj, []

    pending = []          # (project, issue) still inside the window
    for res in parallel_map(_issues_for, projects, workers, progress, "projects"):
        if not res:
            continue
        proj, issues = res
        for iss in issues:
            closed = parse_ts(iss.get("closed_at"))
            if closed and month_key(closed) in in_window:
                pending.append((proj, iss, closed))
    say("  %d closed issue(s) in window; fetching label history..." % len(pending))

    # phase 2 -- label events for every issue, in parallel
    def _labels(item):
        proj, iss, _c = item
        try:
            return client.issue_label_events(proj["id"], iss.get("iid"))
        except Exception:
            return []

    label_sets = parallel_map(_labels, pending, workers, progress, "label history")

    # The start of the clock, resolved in strict priority order and recorded
    # as it is decided -- so the tier is known once rather than re-derived
    # later, and every row carries the basis it was actually measured on.
    #
    #   1. first IN PROGRESS transition
    #   2. else first ITERATION assignment
    #   3. else the issue CREATION date
    starts: List[Optional[datetime]] = []
    bases: List[str] = []
    for ev in label_sets:
        ip = first_in_progress(ev or [], settings.in_progress_labels)
        starts.append(ip)
        bases.append(FROM_IN_PROGRESS if ip else "")

    # phase 3 -- iteration history ONLY for the issues tier 1 could not resolve
    need_iter = [i for i, st in enumerate(starts) if st is None]
    if need_iter:
        say("  %d issue(s) have no in-progress transition; checking iteration history..."
            % len(need_iter))

        def _iters(i):
            proj, iss, _c = pending[i]
            try:
                return client.issue_iteration_events(proj["id"], iss.get("iid"))
            except Exception:
                return []

        for i, ev in zip(need_iter, parallel_map(_iters, need_iter, workers, progress,
                                                 "iteration history")):
            it_start = first_iteration_assigned(ev or [])
            if it_start is not None:
                starts[i] = it_start
                bases[i] = FROM_ITERATION

    # phase 3b -- the LAST closed event, only for issues that reached in
    # progress. Those are the only ones that can be in scope, so there is no
    # point paying for the call on the rest.
    in_prog_idx = [i for i, b in enumerate(bases) if b == FROM_IN_PROGRESS]
    last_closed_at = {}
    if in_prog_idx:
        say("  %d issue(s) reached in progress; fetching state history for the final closure..."
            % len(in_prog_idx))

        def _states(i):
            proj, iss, _c = pending[i]
            try:
                return client.issue_state_events(proj["id"], iss.get("iid"))
            except Exception:
                return []

        for i, ev in zip(in_prog_idx, parallel_map(_states, in_prog_idx, workers, progress,
                                                   "state history")):
            lc = last_closed(ev or [])
            if lc:
                last_closed_at[i] = lc

    issue_rows: List[IssueRow] = []
    for k, ((proj, iss, closed), _lab) in enumerate(zip(pending, label_sets)):
        start, measured = starts[k], bases[k]
        if start is None:                          # tier 3
            start = parse_ts(iss.get("created_at"))
            measured = FROM_CREATED if start else ""

        # In scope when the issue actually went in progress. Measure to the
        # LAST closed event where there is one at or after the transition;
        # otherwise fall back to the issue's own closed_at.
        #
        # The fallback matters: state events can be missing, or a label can
        # be applied after the fact so the recorded transition lands after
        # the closure. GitLab reporting a closed_at means the issue WAS
        # closed, so it stays in scope either way -- an accounting quirk in
        # the event history should not remove real delivered work from the
        # numbers.
        api_closed = closed
        in_scope, reason = False, ""
        if measured == FROM_IN_PROGRESS:
            lc = last_closed_at.get(k)
            if lc is not None and start is not None and lc >= start:
                closed = lc
            else:
                closed = api_closed
            if closed is not None:
                in_scope = True
                if start is not None and closed < start:
                    # closed before the recorded transition: counted for
                    # throughput, but no meaningful duration to average
                    reason = ("in-progress recorded after closure; counted, but cycle "
                              "time is not measurable")
            else:
                reason = "no closed date"
        elif measured == FROM_ITERATION:
            reason = "never moved to in progress (measured from iteration assignment)"
        elif measured == FROM_CREATED:
            reason = "never moved to in progress (measured from creation)"
        else:
            reason = "no usable start date"

        days = elapsed_days(start, closed) if start else None
        it = iss.get("iteration") or {}
        ep = iss.get("epic") or {}
        ppath = proj.get("path_with_namespace", "")
        it_name, it_start, it_due = _iteration_name(it, iteration_lookup)
        issue_rows.append(IssueRow(
            project_path=ppath, folders=folder_trail(ppath, settings.issue_group),
            iid=iss.get("iid"), title=str(iss.get("title", ""))[:300],
            author=_person(iss.get("author")), assignee=_person(iss.get("assignee"), "unassigned"),
            month=month_key(closed), measured_from=measured, start_at=start, closed_at=closed,
            cycle_days=days,
            flagged=bool(days is not None and days > settings.issue_sla_days),
            in_scope=in_scope, scope_reason=reason, pod_name=pod_name,
            iteration_name=it_name, iteration_start=it_start, iteration_end=it_due,
            epic_id=str(ep.get("id") or ""), epic_name=str(ep.get("title") or ""),
            web_url=str(iss.get("web_url", ""))))
    # Trim the slowest tail per month. One stale ticket closed after six
    # months would otherwise dominate a month's average on its own.
    pct = float(getattr(settings, "issue_slowest_trim_pct", 15.0))
    if pct > 0:
        trimmed = 0
        for mk in months:
            cand = [r for r in issue_rows
                    if r.month == mk and r.in_scope and r.cycle_days is not None]
            if len(cand) < 3:            # too few for a percentile to mean anything
                continue
            cand.sort(key=lambda r: r.cycle_days, reverse=True)
            n_drop = int(len(cand) * pct / 100.0)
            for r in cand[:n_drop]:
                r.in_scope = False
                r.scope_reason = "slowest %g%% of issues closed in %s" % (pct, mk)
                trimmed += 1
        if trimmed:
            say("  Excluded %d issue(s) as the slowest %g%% of their month." % (trimmed, pct))

    from collections import Counter as _C
    mix = _C(r.measured_from for r in issue_rows)
    say("Collected %d closed issue(s)  [in-progress %d | iteration %d | created %d]  "
        "-- %d in scope for the metrics"
        % (len(issue_rows), mix.get(FROM_IN_PROGRESS, 0), mix.get(FROM_ITERATION, 0),
           mix.get(FROM_CREATED, 0), sum(1 for r in issue_rows if r.in_scope)))

    # ============================ MERGE REQUESTS ============================
    mr_paths = list(pod.mr_repos.values()) if pod else []
    say("Pod '%s': resolving %d MR repo(s)..." % (pod_name, len(mr_paths)))
    mr_projects = client.resolve_projects(mr_paths)
    say("  %d project(s); fetching merged MRs with %d worker(s)..." % (len(mr_projects), workers))

    def _mrs_for(proj):
        try:
            # every state is listed so the breakdown table can show them;
            # only merged ones go on to cost a commit lookup or enter a metric
            return proj, client.merge_requests_all(proj["id"], earliest)
        except Exception as e:
            log.error("  merge requests failed for %s: %s", proj.get("path_with_namespace"), e)
            return proj, []

    pending_mr = []
    state_counts: Dict[str, Dict[str, int]] = {mm: {} for mm in months}
    for res in parallel_map(_mrs_for, mr_projects, workers, progress, "projects"):
        if not res:
            continue
        proj, mrs = res
        for mr in mrs:
            state = str(mr.get("state", "")).lower().strip() or "opened"
            merged = parse_ts(mr.get("merged_at"))
            # bucket by the timestamp that matches the state
            at = merged or parse_ts(mr.get("closed_at")) or parse_ts(mr.get("created_at"))
            if at and month_key(at) in in_window:
                state_counts[month_key(at)][state] = \
                    state_counts[month_key(at)].get(state, 0) + 1
            if state == "merged" and merged and month_key(merged) in in_window:
                pending_mr.append((proj, mr, merged))
    say("  %d merged MR(s) in window; fetching commit history..." % len(pending_mr))

    def _commits(item):
        proj, mr, _m = item
        try:
            return client.mr_commits(proj["id"], mr.get("iid"))
        except Exception:
            return []

    commit_sets = parallel_map(_commits, pending_mr, workers, progress, "commit history")

    def _approval(item):
        proj, mr, _m = item
        try:
            return client.mr_first_approved_at(proj["id"], mr.get("iid"))
        except Exception:
            return None

    approvals = parallel_map(_approval, pending_mr, workers, progress, "approvals")

    mr_rows: List[MRRow] = []
    for (proj, mr, merged), commits, approved in zip(pending_mr, commit_sets, approvals):
        stamps = [t for t in (parse_ts(c.get("committed_date") or c.get("created_at"))
                              for c in (commits or [])) if t]
        first = min(stamps) if stamps else None
        hours = elapsed_hours(first, merged) if first else None

        if hours is None:
            in_scope, reason = False, "no commit history, so lead time cannot be measured"
        elif hours > ONE_YEAR_HOURS:
            in_scope, reason = False, "lead time over one year"
        else:
            in_scope, reason = True, ""

        ppath = proj.get("path_with_namespace", "")
        mr_rows.append(MRRow(
            project_path=ppath, folders=folder_trail(ppath, ""),
            iid=mr.get("iid"), title=str(mr.get("title", ""))[:300],
            author=_person(mr.get("author")), month=month_key(merged),
            first_commit_at=first, merged_at=merged, lead_hours=hours,
            flagged=bool(hours is not None and hours > settings.mr_sla_hours),
            web_url=str(mr.get("web_url", "")),
            mr_id=str(mr.get("id") or ""),
            target_project_id=str(mr.get("target_project_id") or proj.get("id") or ""),
            source_branch=str(mr.get("source_branch") or ""),
            target_branch=str(mr.get("target_branch") or ""),
            created_at=parse_ts(mr.get("created_at")), first_approved_at=approved,
            pod_name=pod_name, in_scope=in_scope, scope_reason=reason))
    say("Collected %d merged MR(s) -- %d in scope (lead time under one year)."
        % (len(mr_rows), sum(1 for r in mr_rows if r.in_scope)))
    return issue_rows, mr_rows, state_counts


# ------------------------------------------------------------------ summarise
def monthly_stats(issue_rows: List[IssueRow], mr_rows: List[MRRow], months: List[str],
                  state_counts: Optional[Dict[str, Dict[str, int]]] = None,
                  pod_count: int = 1) -> Dict[str, MonthStats]:
    state_counts = state_counts or {}
    stats = {m: MonthStats(month=m, state_counts=dict(state_counts.get(m, {})))
             for m in months}
    for m in months:
        all_iss = [i for i in issue_rows if i.month == m]
        all_mrs = [x for x in mr_rows if x.month == m]
        # Metrics use IN-SCOPE items only; the detail tables still list
        # everything, marked with its scope and the reason.
        iss = [i for i in all_iss if i.in_scope]
        mrs = [x for x in all_mrs if x.in_scope]

        s = stats[m]
        s.closed_count = len(iss)
        s.throughput = round(len(iss) / float(pod_count), 2) if pod_count else float(len(iss))
        cyc = [i.cycle_days for i in iss if i.cycle_days is not None]
        s.cycle_time = round(sum(cyc) / len(cyc), 2) if cyc else None
        s.issues_flagged = sum(1 for i in iss if i.flagged)
        s.from_in_progress = sum(1 for i in iss if i.measured_from == FROM_IN_PROGRESS)
        s.from_iteration = sum(1 for i in iss if i.measured_from == FROM_ITERATION)
        s.from_created = sum(1 for i in iss if i.measured_from == FROM_CREATED)
        s.issues_total = len(all_iss)
        s.issues_out_of_scope = len(all_iss) - len(iss)

        s.mr_count = len(mrs)
        authors = {x.author for x in mrs}
        s.author_count = len(authors)
        s.mr_per_author = round(len(mrs) / len(authors), 2) if authors else None
        lead = [x.lead_hours for x in mrs if x.lead_hours is not None]
        s.lead_time = round(sum(lead) / len(lead), 2) if lead else None
        s.mrs_flagged = sum(1 for x in mrs if x.flagged)
        s.mrs_total = len(all_mrs)
        s.mrs_out_of_scope = len(all_mrs) - len(mrs)
    return stats


# ------------------------------------------------------------------ gains
def gain(metric: str, value: Optional[float], base: Optional[float]) -> Optional[float]:
    """Percentage improvement vs baseline, sign-corrected per metric so that
    a positive number always means better."""
    if value is None or base in (None, 0):
        return None
    raw = (value - base) / abs(base) * 100.0
    return round(-raw if LOWER_IS_BETTER[metric] else raw, 2)


def ramp_at(offset: Optional[int], target_pct: float, target_months: int) -> Optional[float]:
    """Aspiration ramp: 0% at the baseline, linear to the target, then flat.
    None before the baseline -- the ambition starts at the reference point."""
    if offset is None or offset < 0 or target_months <= 0:
        return None
    return round(min(offset / float(target_months), 1.0) * target_pct, 2)


@dataclass
class Series:
    months: List[str]
    baseline_month: str
    baseline_index: Optional[int] = None
    baseline_window: int = 3
    baseline_months: List[str] = field(default_factory=list)
    # 3-month rolling windows -- what the chart plots. The window starting at
    # the baseline month spans exactly the baseline months, so its average IS
    # the baseline: aspiration and actual meet there by construction.
    window_labels: List[str] = field(default_factory=list)
    baseline_window_index: Optional[int] = None
    w_actual: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    w_actual_prev: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    w_actual_curr: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    w_aspiration: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    w_gain_prev: List[Optional[float]] = field(default_factory=list)
    w_gain_curr: List[Optional[float]] = field(default_factory=list)
    w_gain_asp: List[Optional[float]] = field(default_factory=list)
    w_gain_actual: List[Optional[float]] = field(default_factory=list)
    actual: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    actual_prev: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    actual_curr: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    aspiration: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    baseline: Dict[str, Optional[float]] = field(default_factory=dict)
    shift_pct: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    progress_pct: Dict[str, Optional[float]] = field(default_factory=dict)
    gain_prev: List[Optional[float]] = field(default_factory=list)
    gain_curr: List[Optional[float]] = field(default_factory=list)
    gain_asp: List[Optional[float]] = field(default_factory=list)
    gain_actual: List[Optional[float]] = field(default_factory=list)
    overall_gain: Optional[float] = None


def _split(vals, bi):
    """One series drawn in two segments; the baseline point sits in both so
    the lines join rather than showing a break."""
    if bi is None:
        return list(vals), [None] * len(vals)
    return ([v if i <= bi else None for i, v in enumerate(vals)],
            [v if i >= bi else None for i, v in enumerate(vals)])


def _mean(vals):
    v = [x for x in vals if x is not None]
    return round(sum(v) / len(v), 2) if v else None


def window_slices(months: Sequence[str], window: int = 3):
    """Consecutive `window`-month spans stepping one month at a time:
    Nov 24-Jan 25, Dec 24-Feb 25, Jan 25-Mar 25, ..."""
    labels, spans = [], []
    for i in range(len(months) - window + 1):
        labels.append("%s-%s" % (month_label(months[i]), month_label(months[i + window - 1])))
        spans.append((i, i + window))
    return labels, spans


def window_average(values: Sequence[Optional[float]], spans) -> List[Optional[float]]:
    """Mean of each window, ignoring gaps -- a month with no data contributes
    nothing rather than counting as zero, which would invent a decline."""
    out = []
    for a, b in spans:
        vals = [v for v in values[a:b] if v is not None]
        out.append(round(sum(vals) / len(vals), 2) if vals else None)
    return out


def baseline_value(vals: Sequence[Optional[float]], baseline_index: Optional[int],
                   window: int) -> Optional[float]:
    """Baseline as the mean of `window` months starting at the baseline month.

    Averaging Nov-25, Dec-25 and Jan-26 rather than taking Nov-25 alone stops
    a single unusually quiet or busy month from skewing every percentage on
    the report -- which a one-month baseline demonstrably does.
    """
    if baseline_index is None:
        return None
    chunk = [v for v in vals[baseline_index:baseline_index + max(1, window)] if v is not None]
    return round(sum(chunk) / len(chunk), 2) if chunk else None


def build_series(stats: Dict[str, MonthStats], months: List[str], settings) -> Series:
    bm = settings.baseline_month
    win = int(getattr(settings, "baseline_window_months", 3))
    ser = Series(months=list(months), baseline_month=bm)
    ser.baseline_index = months.index(bm) if bm in months else None
    bi = ser.baseline_index

    for k in METRIC_KEYS:
        vals = [stats[m].value(k) for m in months]
        vals = [float(v) if v is not None else None for v in vals]
        ser.actual[k] = vals
        base = baseline_value(vals, bi, win)
        ser.baseline[k] = base
        ser.actual_prev[k], ser.actual_curr[k] = _split(vals, bi)

        lower = LOWER_IS_BETTER[k]
        asp = []
        for i in range(len(months)):
            step = ramp_at(None if bi is None else i - bi,
                           settings.target_gain_pct, settings.target_months)
            if base is None or step is None:
                asp.append(None)
            else:
                f = (1 - step / 100.0) if lower else (1 + step / 100.0)
                asp.append(round(base * f, 2))
        ser.aspiration[k] = asp

        ser.shift_pct[k] = [gain(k, v, base) for v in vals]
        latest = next((v for v in reversed(vals) if v is not None), None)
        ser.progress_pct[k] = gain(k, latest, base)

    for i in range(len(months)):
        ser.gain_actual.append(_mean([ser.shift_pct[k][i] for k in METRIC_KEYS]))
        ser.gain_asp.append(ramp_at(None if bi is None else i - bi,
                                    settings.target_gain_pct, settings.target_months))
    ser.gain_prev, ser.gain_curr = _split(ser.gain_actual, bi)
    ser.overall_gain = _mean([ser.progress_pct[k] for k in METRIC_KEYS])

    # ---------------- 3-month windows for the chart ----------------
    labels, spans = window_slices(months, win)
    ser.window_labels = labels
    bwi = bi if (bi is not None and bi < len(labels)) else None
    ser.baseline_window_index = bwi

    for k in METRIC_KEYS:
        wv = window_average(ser.actual[k], spans)
        ser.w_actual[k] = wv
        ser.w_actual_prev[k], ser.w_actual_curr[k] = _split(wv, bwi)
        # anchored on the window value at the baseline window, which equals
        # ser.baseline[k] -- the same three months averaged the same way
        wbase = wv[bwi] if bwi is not None and bwi < len(wv) else None
        lower = LOWER_IS_BETTER[k]
        asp = []
        for j in range(len(labels)):
            step = ramp_at(None if bwi is None else j - bwi,
                           settings.target_gain_pct, settings.target_months)
            if wbase is None or step is None:
                asp.append(None)
            else:
                f = (1 - step / 100.0) if lower else (1 + step / 100.0)
                asp.append(round(wbase * f, 2))
        ser.w_aspiration[k] = asp

    for j in range(len(labels)):
        ser.w_gain_actual.append(_mean([gain(k, ser.w_actual[k][j],
                                             ser.w_actual[k][bwi] if bwi is not None else None)
                                        for k in METRIC_KEYS]))
        ser.w_gain_asp.append(ramp_at(None if bwi is None else j - bwi,
                                      settings.target_gain_pct, settings.target_months))
    ser.w_gain_prev, ser.w_gain_curr = _split(ser.w_gain_actual, bwi)

    ser.baseline_window = win
    ser.baseline_months = months[bi:bi + win] if bi is not None else []
    log.info("Series built: baseline = mean of %s, overall gain %s%%",
             ", ".join(ser.baseline_months) or bm, ser.overall_gain)
    return ser
