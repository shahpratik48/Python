"""
HTML reports.

Self-contained (inline CSS, no external assets) so a report renders
correctly straight from disk or as an email attachment.
"""
from __future__ import annotations

import datetime as _dt
import html
import os
from typing import Dict, List, Optional

from gl_settings import get_logger

log = get_logger("gitlab.report")

_CSS = """
body{font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;margin:0;padding:24px;
color:#1a1a1a;background:#f6f7f9;}
.wrap{max-width:1180px;margin:0 auto;background:#fff;padding:28px 32px;border-radius:10px;
box-shadow:0 1px 3px rgba(0,0,0,.08);}
h1{margin:0 0 4px;font-size:24px;} h2{margin:30px 0 10px;font-size:18px;
border-bottom:2px solid #e6e8eb;padding-bottom:6px;} h3{margin:20px 0 8px;font-size:15px;}
.sub{color:#666;font-size:13px;margin-bottom:18px;}
table{border-collapse:collapse;width:100%;margin:10px 0;font-size:13px;}
th{background:#305496;color:#fff;text-align:left;padding:8px 10px;font-weight:600;}
td{border-bottom:1px solid #e6e8eb;padding:7px 10px;vertical-align:top;}
tr:nth-child(even) td{background:#fafbfc;}
.flag{background:#fdecec !important;}
.flag td{border-bottom:1px solid #f3c9c9;}
.badge{display:inline-block;padding:2px 9px;border-radius:11px;font-size:11px;font-weight:600;}
.b-flag{background:#fdecec;color:#9b1c1c;} .b-ok{background:#e6f5ec;color:#0b6b36;}
.b-unk{background:#fff6e0;color:#9a6700;}
.cards{display:flex;flex-wrap:wrap;gap:12px;margin:14px 0;}
.card{flex:1 1 190px;background:#f8f9fb;border:1px solid #e6e8eb;border-radius:8px;padding:12px 14px;}
.card .k{font-size:11px;color:#666;text-transform:uppercase;letter-spacing:.4px;}
.card .v{font-size:23px;font-weight:700;margin-top:3px;}
.card.warn .v{color:#9b1c1c;}
.note{background:#f2f6ff;border-left:3px solid #305496;padding:9px 13px;margin:10px 0;
font-size:13px;color:#33415c;}
code{font-family:Consolas,Monaco,monospace;background:#f2f3f5;padding:1px 5px;border-radius:3px;font-size:12px;}
.meta td{border:none;padding:3px 12px 3px 0;font-size:13px;}
.none{color:#0b6b36;font-size:14px;padding:8px 0;}
.foot{margin-top:32px;padding-top:14px;border-top:1px solid #e6e8eb;color:#777;font-size:12px;}
"""


def _e(x) -> str:
    return html.escape(str(x if x is not None else ""))


def _fmt(dt) -> str:
    return dt.strftime("%Y-%m-%d %H:%M") if dt else "&mdash;"


def _count_badge(n: int, kind: str) -> str:
    """A count rendered as a coloured badge when non-zero, plain "0" otherwise.

    Kept as a helper rather than inlined: building this markup inside an
    f-string expression needs escaped quotes, and f-string expressions
    cannot contain backslashes before Python 3.12. This code has to run on
    Python 3.8, so all such markup is built here instead.
    """
    if not n:
        return "0"
    return '<span class="badge b-%s">%d</span>' % (kind, n)


def _link(url: str, text: str) -> str:
    """An anchor when there is a URL, otherwise just the text."""
    if url:
        return '<a href="%s">%s</a>' % (_e(url), text)
    return text


def _action_badge(action: str) -> str:
    if action == "failed":
        kind = "b-flag"
    elif action in ("skipped_existing", "dry_run"):
        kind = "b-unk"
    else:
        kind = "b-ok"
    return '<span class="badge %s">%s</span>' % (kind, _e(action))


def _shell(title: str, body: str) -> str:
    return (f'<!DOCTYPE html><html><head><meta charset="utf-8"><title>{_e(title)}</title>'
            f"<style>{_CSS}</style></head><body><div class=\"wrap\">{body}</div></body></html>")


def _card(label: str, value, warn: bool = False) -> str:
    return (f'<div class="card{" warn" if warn else ""}"><div class="k">{_e(label)}</div>'
            f'<div class="v">{_e(value)}</div></div>')


# ------------------------------------------------------------------ DAG 1
def build_metrics_report(settings, months, issue_metrics, issue_summaries,
                         mr_metrics, mr_summaries, log_path: str = "") -> str:
    from gl_metrics import BASIS_IN_PROGRESS, MR_STATES

    gen = _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    repos = list(settings.code_repos.keys())

    tot_closed = sum(s.closed_count for s in issue_summaries.values())
    tot_iflag = sum(s.flagged_count for s in issue_summaries.values())
    tot_merged = sum(s.merged_count for s in mr_summaries.values())
    tot_mflag = sum(s.flagged_count for s in mr_summaries.values())

    cards = "".join([
        _card("Issues closed", tot_closed),
        _card("Issues over %g bd" % settings.issue_sla_business_days, tot_iflag, tot_iflag > 0),
        _card("Merge requests merged", tot_merged),
        _card("Merged over %g h" % settings.mr_sla_hours, tot_mflag, tot_mflag > 0),
    ])

    # ---------------- Task 1: monthly ----------------
    t1_parts = []
    for m in months:
        s = issue_summaries[m]
        avg = "&mdash;" if s.avg_business_days is None else ("%.2f" % s.avg_business_days)
        t1_parts.append(
            "<tr><td><b>%s</b></td><td>%d</td><td>%d</td><td>%d</td><td>%s</td><td>%s</td>"
            "<td>%s</td></tr>"
            % (_e(m), s.closed_count, s.from_in_progress, s.from_opened, avg,
               _count_badge(s.flagged_count, "flag"), _count_badge(s.unmeasurable, "unk")))
    t1_rows = "".join(t1_parts)

    def issue_rows(items):
        out = []
        for i in items:
            if i.elapsed_business_days is None:
                badge, val = '<span class="badge b-unk">not measurable</span>', "&mdash;"
            elif i.flagged:
                badge, val = '<span class="badge b-flag">over SLA</span>', "%.2f" % i.elapsed_business_days
            else:
                badge, val = '<span class="badge b-ok">ok</span>', "%.2f" % i.elapsed_business_days
            if i.basis == BASIS_IN_PROGRESS:
                basis = '<span class="badge b-ok">in progress</span>'
                start_dt = _fmt(i.in_progress_at)
            elif i.basis:
                basis = '<span class="badge b-unk">opened</span>'
                start_dt = _fmt(i.created_at)
            else:
                basis, start_dt = "&mdash;", "&mdash;"
            out.append(
                '<tr class="%s"><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td>'
                "<td>%s</td><td>%s</td><td><small>%s</small></td></tr>"
                % ("flag" if i.flagged else "", _link(i.web_url, "#%s" % i.iid), _e(i.title),
                   _e(i.assignee_name), _e(i.month), basis, start_dt, _fmt(i.closed_at),
                   val + " " + badge, _e(i.note)))
        return "".join(out)

    issues_sorted = sorted(issue_metrics,
                           key=lambda x: (not x.flagged, x.month, -(x.elapsed_business_days or 0)))
    t1_detail = ("<table><tr><th>Issue</th><th>Title</th><th>Assignee</th><th>Month</th>"
                 "<th>Measured from</th><th>Start</th><th>Closed</th><th>Business days</th>"
                 "<th>Note</th></tr>" + issue_rows(issues_sorted) + "</table>"
                 if issues_sorted else '<div class="none">No closed issues in this window.</div>')

    # ---------------- Task 2: state breakdown ----------------
    st_parts = []
    for m in months:
        s = mr_summaries[m]
        cells = "".join("<td>%d</td>" % s.state_counts.get(st, 0) for st in MR_STATES)
        st_parts.append("<tr><td><b>%s</b></td>%s<td><b>%d</b></td></tr>"
                        % (_e(m), cells, sum(s.state_counts.values())))
    totals = "".join("<td><b>%d</b></td>"
                     % sum(mr_summaries[m].state_counts.get(st, 0) for m in months)
                     for st in MR_STATES)
    grand = sum(sum(mr_summaries[m].state_counts.values()) for m in months)
    st_parts.append("<tr><td><b>All months</b></td>%s<td><b>%d</b></td></tr>" % (totals, grand))
    state_head = "".join("<th>%s</th>" % _e(st) for st in MR_STATES)
    state_tbl = ("<table><tr><th>Month</th>" + state_head + "<th>Total</th></tr>"
                 + "".join(st_parts) + "</table>")

    # ---------------- Task 2: merged counts per repository ----------------
    repo_parts = []
    for m in months:
        s = mr_summaries[m]
        cells = "".join("<td>%d</td>" % s.per_repo.get(r, 0) for r in repos)
        repo_parts.append("<tr><td><b>%s</b></td>%s<td><b>%d</b></td></tr>"
                          % (_e(m), cells, s.merged_count))
    rtot = "".join("<td><b>%d</b></td>" % sum(mr_summaries[m].per_repo.get(r, 0) for m in months)
                   for r in repos)
    repo_parts.append("<tr><td><b>All months</b></td>%s<td><b>%d</b></td></tr>" % (rtot, tot_merged))
    repo_head = "".join("<th>%s</th>" % _e(r) for r in repos)
    repo_tbl = ("<table><tr><th>Month</th>" + repo_head + "<th>Total</th></tr>"
                + "".join(repo_parts) + "</table>")

    # ---------------- Task 2: monthly elapsed summary ----------------
    t2_parts = []
    for m in months:
        s = mr_summaries[m]
        avg = "&mdash;" if s.avg_hours is None else ("%.2f" % s.avg_hours)
        t2_parts.append("<tr><td><b>%s</b></td><td>%d</td><td>%d</td><td>%d</td><td>%s</td>"
                        "<td>%s</td><td>%s</td></tr>"
                        % (_e(m), s.merged_count, len(s.per_author), s.measured_count, avg,
                           _count_badge(s.flagged_count, "flag"),
                           _count_badge(s.unknown_count, "unk")))
    t2_rows = "".join(t2_parts)

    # ---------------- Task 2: merged per author ----------------
    authors = sorted({a for s in mr_summaries.values() for a in s.per_author})
    if authors:
        head = "".join("<th>%s</th>" % _e(m) for m in months)
        body = ""
        for a in authors:
            row = [mr_summaries[m].per_author.get(a, 0) for m in months]
            body += ("<tr><td><b>%s</b></td>%s<td><b>%d</b></td></tr>"
                     % (_e(a), "".join("<td>%d</td>" % v for v in row), sum(row)))
        mt = "".join("<td><b>%d</b></td>" % mr_summaries[m].merged_count for m in months)
        body += "<tr><td><b>All authors</b></td>%s<td><b>%d</b></td></tr>" % (mt, tot_merged)
        author_tbl = "<table><tr><th>Author</th>" + head + "<th>Total</th></tr>" + body + "</table>"
    else:
        author_tbl = '<div class="none">No merged merge requests in this window.</div>'

    # ---------------- Task 2: detail, one section per month ----------------
    def mr_rows(items):
        out = []
        for m in items:
            if m.elapsed_hours is None:
                val = "&mdash;"
                badge = ('<span class="badge b-unk">n/a</span>' if m.state != "merged"
                         else '<span class="badge b-unk">unknown</span>')
            elif m.flagged:
                val, badge = "%.2f" % m.elapsed_hours, '<span class="badge b-flag">over SLA</span>'
            else:
                val, badge = "%.2f" % m.elapsed_hours, '<span class="badge b-ok">ok</span>'
            skind = {"merged": "b-ok", "closed": "b-flag", "locked": "b-unk"}.get(m.state, "b-unk")
            out.append(
                '<tr class="%s"><td>%s</td><td>%s</td><td>%s</td><td>%s</td>'
                '<td><span class="badge %s">%s</span></td><td>%s</td><td>%s</td>'
                "<td>%s %s</td><td><small>%s</small></td></tr>"
                % ("flag" if m.flagged else "", _e(m.repo), _link(m.web_url, "!%s" % m.iid),
                   _e(m.title), _e(m.author_name), skind, _e(m.state),
                   _fmt(m.first_touch_at), _fmt(m.merged_at or m.closed_at), val, badge,
                   _e(m.note)))
        return "".join(out)

    detail_sections = []
    for m in months:
        rows_for_month = sorted([x for x in mr_metrics if x.month == m],
                                key=lambda x: (not x.flagged, x.state != "merged",
                                               -(x.elapsed_hours or 0)))
        s = mr_summaries[m]
        counts = ", ".join("%s %d" % (st, s.state_counts.get(st, 0)) for st in MR_STATES)
        detail_sections.append("<h3>%s &mdash; %d merge request(s) (%s)</h3>"
                               % (_e(m), sum(s.state_counts.values()), _e(counts)))
        if rows_for_month:
            detail_sections.append(
                "<table><tr><th>Repo</th><th>MR</th><th>Title</th><th>Author</th><th>State</th>"
                "<th>First file touched</th><th>Merged / closed</th><th>Hours</th>"
                "<th>Note</th></tr>" + mr_rows(rows_for_month) + "</table>")
        else:
            detail_sections.append('<div class="none">No merge requests in this month.</div>')
    t2_detail = "".join(detail_sections)

    log_row = ('<tr><td><b>Log file</b></td><td><code>%s</code></td></tr>'
               % _e(os.path.basename(log_path))) if log_path else ""

    body = """
<h1>GitLab Productivity Report</h1>
<div class="sub">Issue throughput and merge request cycle time</div>
<table class="meta">
<tr><td><b>Reporting months</b></td><td>%s (current month plus the previous %d)</td></tr>
<tr><td><b>Issue project</b></td><td><code>%s</code></td></tr>
<tr><td><b>Code repositories</b></td><td>%s</td></tr>
<tr><td><b>Generated</b></td><td>%s</td></tr>
%s
</table>
<div class="cards">%s</div>

<h2>Task 1 &mdash; Issues closed per month</h2>
<div class="note">Elapsed time is measured in <b>business days</b> (weekends excluded) and flagged over
%g. It runs from the <b>in progress</b> transition where one exists; where it does not, it falls back
to <b>opened &rarr; closed</b> so every issue still contributes a figure. The two columns below show
how many issues used each basis &mdash; an opened-based figure will usually read higher, so it is worth
knowing how much of the average rests on the fallback.</div>
<table><tr><th>Month</th><th>Closed</th><th>From in progress</th><th>From opened</th>
<th>Avg business days</th><th>Flagged</th><th>Not measurable</th></tr>%s</table>
<h3>Every closed issue (flagged first)</h3>
%s

<h2>Task 2 &mdash; Merge requests</h2>
<div class="note">Summed across %s. <b>Counts consider merged merge requests only</b> &mdash; an
abandoned MR is not delivered work. <b>Elapsed hours</b> run from the earliest commit on the MR (when a
file in it was first touched) until it was <b>merged</b>, and are flagged over %g hours; opened,
closed-without-merging and locked MRs have no elapsed time by definition.</div>

<h3>Merge requests by state</h3>
<div class="note">All four states, for visibility. <code>closed</code> means closed
<i>without</i> merging.</div>
%s

<h3>Merged merge requests per repository</h3>
%s

<h3>Merged merge requests &mdash; elapsed time</h3>
<table><tr><th>Month</th><th>Merged</th><th>Authors</th><th>Measured</th><th>Avg hours</th>
<th>Flagged</th><th>Unknown</th></tr>%s</table>

<h3>Merged merge requests per author</h3>
%s

<h3>Every merge request, by month</h3>
%s

<div class="foot">Business-day elapsed time excludes Saturdays and Sundays but does not account for
public holidays or working-hour boundaries. Names shown are GitLab display names.</div>"""
    body = body % (_e(", ".join(months)), settings.months_back, _e(settings.project_path),
                   _e(", ".join(repos)), _e(gen), log_row, cards,
                   settings.issue_sla_business_days, t1_rows, t1_detail,
                   _e(", ".join(repos)), settings.mr_sla_hours,
                   state_tbl, repo_tbl, t2_rows, author_tbl, t2_detail)

    log.info("Metrics report built (%d issue rows, %d MR rows).", len(issue_metrics), len(mr_metrics))
    return _shell("GitLab Productivity Report", body)


# ------------------------------------------------------------ DAG 2 / DAG 3
def build_ticket_report(settings, result, mode: str, log_path: str = "") -> str:
    gen = _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    verb = "created" if mode == "create" else "closed"
    primary = result.created if mode == "create" else result.closed

    cards = "".join([
        _card(f"Tickets {verb}", primary),
        _card("Skipped (already existed)", result.skipped) if mode == "create" else "",
        _card("Failed", result.failed, result.failed > 0),
    ])

    row_parts = []
    for a in result.actions:
        issue_cell = _link(a.web_url, "#%s" % a.issue_iid) if a.issue_iid else "&mdash;"
        row_parts.append(
            '<tr class="%s"><td>%s</td><td>%s</td><td>%s</td><td><small>%s</small></td></tr>'
            % ("flag" if a.action == "failed" else "", _e(a.title),
               _action_badge(a.action), issue_cell, _e(a.detail)))
    rows = "".join(row_parts)

    dry = ('<div class="note"><b>DRY RUN</b> &mdash; nothing was actually created or closed. '
           'Every action listed below is what <i>would</i> have happened.</div>'
           if result.dry_run else "")

    body = f"""
<h1>GitLab BAU Ticket {verb.capitalize()}</h1>
<div class="sub">{'Creating the standing BAU ticket set' if mode == 'create' else 'Closing open BAU tickets'} in the current iteration</div>
{dry}
<table class="meta">
<tr><td><b>Project</b></td><td><code>{_e(settings.project_path)}</code></td></tr>
<tr><td><b>Iteration</b></td><td>{_e(result.iteration_title)} (id {_e(result.iteration_id)})</td></tr>
<tr><td><b>Parent</b></td><td>{_e(result.epic_title)}{f' (id {_e(result.epic_id)})' if result.epic_id else ''}</td></tr>
<tr><td><b>Label</b></td><td><code>{_e(settings.ticket_label)}</code></td></tr>
<tr><td><b>Weight</b></td><td>{_e(settings.ticket_weight)}</td></tr>
<tr><td><b>Generated</b></td><td>{_e(gen)}</td></tr>
{f'<tr><td><b>Log file</b></td><td><code>{_e(os.path.basename(log_path))}</code></td></tr>' if log_path else ''}
</table>
<div class="cards">{cards}</div>
<h2>Actions</h2>
{f'<table><tr><th>Title</th><th>Action</th><th>Issue</th><th>Detail</th></tr>{rows}</table>' if result.actions else '<div class="none">No tickets matched -- nothing to do.</div>'}
<div class="foot">Ticket creation is idempotent: a ticket whose title is already open in the current
iteration is skipped rather than duplicated.</div>"""
    log.info("Ticket report built (%d action rows).", len(result.actions))
    return _shell(f"GitLab BAU Ticket {verb.capitalize()}", body)


def write_report(html_text: str, output_dir: str, prefix: str) -> str:
    os.makedirs(output_dir, exist_ok=True)
    path = os.path.join(output_dir,
                        f"{prefix}_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.html")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(html_text)
    log.info("Report written: %s", path)
    return path
