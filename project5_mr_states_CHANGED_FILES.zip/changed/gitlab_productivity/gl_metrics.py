"""
Metrics for DAG 1.

Task 1 -- issues: how many closed per month, elapsed time to closure for
each, and the monthly average, in BUSINESS days (weekends excluded).
Anything over the SLA is flagged.

    Elapsed time is measured from the "In progress" transition to closure
    where that transition exists. Where it does not, it falls back to
    OPENED -> closed rather than reporting nothing, so every closed issue
    contributes a number. Which basis was used is recorded per issue and
    summarised per month, because an issue measured from opening will
    usually look slower than one measured from in-progress and you should
    be able to see how much of the average rests on that fallback.

Task 2 -- merge requests across IKG / NLG / ODM:

    * Merge requests are reported by state -- opened, merged, closed
      (meaning closed WITHOUT merging), and locked -- per month and per
      repository.
    * COUNTS (per author, per repository, per month) consider MERGED
      merge requests only. An abandoned MR is not delivered work.
    * ELAPSED HOURS run from the moment a file in the MR was first touched
      (the earliest commit on the MR) until it was MERGED. Only merged MRs
      have an elapsed time; opened, closed-unmerged and locked ones do not.

Month bucketing follows the state: merged MRs bucket by `merged_at`,
closed-unmerged by `closed_at`, and still-open or locked ones by
`created_at` -- so an open MR appears in the month it was raised.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Tuple

from gl_settings import get_logger

log = get_logger("gitlab.metrics")

MR_STATES = ("opened", "merged", "closed", "locked")

BASIS_IN_PROGRESS = "in_progress"
BASIS_OPENED = "opened"


# ------------------------------------------------------------------ time utils
def parse_ts(value: Optional[str]) -> Optional[datetime]:
    """Parses GitLab ISO 8601 timestamps into timezone-aware UTC datetimes."""
    if not value:
        return None
    txt = str(value).strip().replace("Z", "+00:00")
    try:
        dt = datetime.fromisoformat(txt)
    except ValueError:
        for fmt in ("%Y-%m-%dT%H:%M:%S.%f%z", "%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%d"):
            try:
                dt = datetime.strptime(txt, fmt)
                break
            except ValueError:
                continue
        else:
            log.warning("Could not parse timestamp %r", value)
            return None
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt.astimezone(timezone.utc)


def business_days_between(start: datetime, end: datetime) -> float:
    """Fractional business days between two instants, excluding Sat/Sun."""
    if not start or not end or end <= start:
        return 0.0
    total, cur, guard = 0.0, start, 0
    while cur < end and guard < 4000:
        nxt = (cur + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
        seg_end = min(nxt, end)
        if cur.weekday() < 5:                      # Mon=0 .. Fri=4
            total += (seg_end - cur).total_seconds() / 86400.0
        cur, guard = seg_end, guard + 1
    return round(total, 2)


def elapsed_hours(start: datetime, end: datetime) -> float:
    if not start or not end or end <= start:
        return 0.0
    return round((end - start).total_seconds() / 3600.0, 2)


def month_key(dt: datetime) -> str:
    return dt.strftime("%Y-%m")


def month_window(months_back: int, now: Optional[datetime] = None) -> Tuple[List[str], datetime]:
    """The month buckets to report on (current month plus `months_back`
    previous months) and the UTC cutoff to fetch from."""
    now = now or datetime.now(timezone.utc)
    keys, cursor = [], now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    for _ in range(months_back + 1):
        keys.append(month_key(cursor))
        cursor = (cursor - timedelta(days=1)).replace(day=1)
    keys.reverse()
    earliest = datetime.strptime(keys[0] + "-01", "%Y-%m-%d").replace(tzinfo=timezone.utc)
    log.info("Reporting window: %s (fetching data updated on/after %s)",
             ", ".join(keys), earliest.date())
    return keys, earliest


def _person_name(obj: Optional[dict], fallback: str = "unknown") -> str:
    """Display name of a GitLab user, falling back to username then a
    placeholder. Reports show names rather than usernames."""
    if not obj:
        return fallback
    return str(obj.get("name") or obj.get("username") or fallback)


# ------------------------------------------------------------------ models
@dataclass
class IssueMetric:
    iid: int
    title: str
    author_name: str
    assignee_name: str
    month: str
    created_at: Optional[datetime]
    in_progress_at: Optional[datetime]
    closed_at: Optional[datetime]
    elapsed_business_days: Optional[float]
    basis: str                       # BASIS_IN_PROGRESS | BASIS_OPENED | ""
    flagged: bool
    note: str = ""
    web_url: str = ""


@dataclass
class MonthIssueSummary:
    month: str
    closed_count: int = 0
    measured_count: int = 0
    from_in_progress: int = 0
    from_opened: int = 0             # measured via the opened -> closed fallback
    unmeasurable: int = 0            # no usable start timestamp at all
    avg_business_days: Optional[float] = None
    flagged_count: int = 0


@dataclass
class MRMetric:
    repo: str
    iid: int
    title: str
    author_name: str
    month: str
    state: str                       # opened | merged | closed | locked
    created_at: Optional[datetime]
    first_touch_at: Optional[datetime]
    merged_at: Optional[datetime]
    closed_at: Optional[datetime]
    elapsed_hours: Optional[float]   # merged MRs only
    flagged: bool
    note: str = ""
    web_url: str = ""


@dataclass
class MonthMRSummary:
    month: str
    state_counts: Dict[str, int] = field(default_factory=dict)   # all four states
    merged_count: int = 0
    per_author: Dict[str, int] = field(default_factory=dict)     # merged only
    per_repo: Dict[str, int] = field(default_factory=dict)       # merged only
    measured_count: int = 0
    unknown_count: int = 0
    avg_hours: Optional[float] = None
    flagged_count: int = 0


# ------------------------------------------------------------------ Task 1
def _first_in_progress(events: List[dict], wanted: List[str]) -> Optional[datetime]:
    """Earliest moment an 'in progress' style label was ADDED."""
    wanted_lc = [w.lower() for w in wanted]
    stamps = []
    for ev in events or []:
        if str(ev.get("action", "")).lower() != "add":
            continue
        name = str((ev.get("label") or {}).get("name", "")).lower()
        if not name:
            continue
        tail = name.split("::")[-1].strip()      # handles `workflow::In progress`
        if any(w == name or w == tail or w in name for w in wanted_lc):
            ts = parse_ts(ev.get("created_at"))
            if ts:
                stamps.append(ts)
    return min(stamps) if stamps else None


def collect_issue_metrics(client, settings, months: List[str],
                          earliest: datetime) -> Tuple[List[IssueMetric], Dict[str, MonthIssueSummary]]:
    log.info("=== Task 1: issue closure metrics ===")
    issues = client.closed_issues(settings.project_path, earliest.isoformat())

    metrics: List[IssueMetric] = []
    summaries = {m: MonthIssueSummary(month=m) for m in months}

    for issue in issues:
        closed_at = parse_ts(issue.get("closed_at"))
        if not closed_at:
            continue
        mkey = month_key(closed_at)
        if mkey not in summaries:
            continue                                    # closed outside the window
        iid = issue.get("iid")
        created_at = parse_ts(issue.get("created_at"))

        try:
            events = client.issue_label_events(settings.project_path, iid)
        except Exception as e:
            log.error("Could not read label events for issue #%s: %s", iid, e)
            events = []

        in_prog = _first_in_progress(events, settings.in_progress_labels)

        if in_prog and in_prog <= closed_at:
            start, basis = in_prog, BASIS_IN_PROGRESS
            note = ""
        elif created_at and created_at <= closed_at:
            start, basis = created_at, BASIS_OPENED
            note = ("No 'in progress' transition found, so this is measured from when the issue was "
                    "OPENED to when it closed -- which will usually read higher than an "
                    "in-progress-based figure.")
        else:
            start, basis, note = None, "", "No usable start timestamp, so elapsed time cannot be measured."

        if start:
            days = business_days_between(start, closed_at)
            flagged = days > settings.issue_sla_business_days
            if flagged:
                note = (note + " " if note else "") + \
                    "Over the %g-business-day SLA." % settings.issue_sla_business_days
        else:
            days, flagged = None, False

        metrics.append(IssueMetric(
            iid=iid, title=str(issue.get("title", ""))[:200],
            author_name=_person_name(issue.get("author")),
            assignee_name=_person_name(issue.get("assignee"), "unassigned"),
            month=mkey, created_at=created_at, in_progress_at=in_prog, closed_at=closed_at,
            elapsed_business_days=days, basis=basis, flagged=flagged, note=note,
            web_url=str(issue.get("web_url", ""))))

        s = summaries[mkey]
        s.closed_count += 1
        if days is None:
            s.unmeasurable += 1
        else:
            s.measured_count += 1
            if basis == BASIS_IN_PROGRESS:
                s.from_in_progress += 1
            else:
                s.from_opened += 1
            if flagged:
                s.flagged_count += 1

    for mkey, s in summaries.items():
        vals = [m.elapsed_business_days for m in metrics
                if m.month == mkey and m.elapsed_business_days is not None]
        s.avg_business_days = round(sum(vals) / len(vals), 2) if vals else None
        log.info("%s -> closed=%d measured=%d (in-progress=%d, opened-fallback=%d) "
                 "unmeasurable=%d avg=%s flagged=%d",
                 mkey, s.closed_count, s.measured_count, s.from_in_progress,
                 s.from_opened, s.unmeasurable, s.avg_business_days, s.flagged_count)

    log.info("Task 1 complete: %d issue(s) in window, %d flagged.",
             len(metrics), sum(s.flagged_count for s in summaries.values()))
    return metrics, summaries


# ------------------------------------------------------------------ Task 2
def _mr_state(mr: dict) -> str:
    state = str(mr.get("state", "")).lower().strip()
    return state if state in MR_STATES else (state or "opened")


def collect_mr_metrics(client, settings, months: List[str],
                       earliest: datetime) -> Tuple[List[MRMetric], Dict[str, MonthMRSummary]]:
    log.info("=== Task 2: merge request metrics across %s ===",
             ", ".join(settings.code_repos.keys()))
    metrics: List[MRMetric] = []
    summaries = {m: MonthMRSummary(month=m,
                                    state_counts={s: 0 for s in MR_STATES},
                                    per_repo={r: 0 for r in settings.code_repos})
                 for m in months}

    for repo_name, repo_path in settings.code_repos.items():
        log.info("--- repository %s ---", repo_name)
        try:
            mrs = client.merge_requests(repo_path, earliest.isoformat())
        except Exception as e:
            log.error("Could not fetch merge requests for %s (%s): %s", repo_name, repo_path, e)
            continue

        counted = 0
        for mr in mrs:
            iid = mr.get("iid")
            state = _mr_state(mr)
            created_at = parse_ts(mr.get("created_at"))
            merged_at = parse_ts(mr.get("merged_at"))
            closed_at = parse_ts(mr.get("closed_at"))

            # bucket by the timestamp that matches the state
            if state == "merged":
                event_at = merged_at or closed_at or created_at
            elif state == "closed":
                event_at = closed_at or created_at
            else:                                        # opened / locked
                event_at = created_at
            if not event_at:
                log.debug("%s MR !%s has no usable timestamp -- skipped.", repo_name, iid)
                continue
            mkey = month_key(event_at)
            if mkey not in summaries:
                continue

            # elapsed hours apply to MERGED merge requests only
            hours, flagged, note, first_touch = None, False, "", None
            if state == "merged" and merged_at:
                try:
                    commits = client.mr_commits(repo_path, iid)
                except Exception as e:
                    log.error("Could not read commits for %s MR !%s: %s", repo_name, iid, e)
                    commits = []
                stamps = [t for t in (parse_ts(c.get("committed_date") or c.get("created_at"))
                                      for c in commits) if t]
                first_touch = min(stamps) if stamps else None
                if first_touch and first_touch <= merged_at:
                    hours = elapsed_hours(first_touch, merged_at)
                    flagged = hours > settings.mr_sla_hours
                    if flagged:
                        note = "Over the %g-hour SLA." % settings.mr_sla_hours
                else:
                    note = ("No commit history available, so the time from first file touched to "
                            "merge cannot be measured.")
            else:
                note = "Elapsed time applies to merged merge requests only."

            metrics.append(MRMetric(
                repo=repo_name, iid=iid, title=str(mr.get("title", ""))[:200],
                author_name=_person_name(mr.get("author")), month=mkey, state=state,
                created_at=created_at, first_touch_at=first_touch, merged_at=merged_at,
                closed_at=closed_at, elapsed_hours=hours, flagged=flagged, note=note,
                web_url=str(mr.get("web_url", ""))))

            s = summaries[mkey]
            s.state_counts[state] = s.state_counts.get(state, 0) + 1
            counted += 1

            # counts are MERGED-only
            if state == "merged":
                s.merged_count += 1
                s.per_author[_person_name(mr.get("author"))] = \
                    s.per_author.get(_person_name(mr.get("author")), 0) + 1
                s.per_repo[repo_name] = s.per_repo.get(repo_name, 0) + 1
                if hours is None:
                    s.unknown_count += 1
                else:
                    s.measured_count += 1
                    if flagged:
                        s.flagged_count += 1

        log.info("%s: %d merge request(s) fell inside the reporting window.", repo_name, counted)

    for mkey, s in summaries.items():
        vals = [m.elapsed_hours for m in metrics if m.month == mkey and m.elapsed_hours is not None]
        s.avg_hours = round(sum(vals) / len(vals), 2) if vals else None
        log.info("%s -> states=%s merged=%d per_repo=%s authors=%d measured=%d unknown=%d "
                 "avg_hours=%s flagged=%d",
                 mkey, s.state_counts, s.merged_count, s.per_repo, len(s.per_author),
                 s.measured_count, s.unknown_count, s.avg_hours, s.flagged_count)

    total_merged = sum(s.merged_count for s in summaries.values())
    log.info("Task 2 complete: %d MR(s) in window (%d merged), %d flagged.",
             len(metrics), total_merged, sum(s.flagged_count for s in summaries.values()))
    return metrics, summaries


# ------------------------------------------------------------------ serde
# Airflow passes data between tasks through XCom, which must be JSON-safe.
def _dt_out(dt: Optional[datetime]) -> Optional[str]:
    return dt.isoformat() if dt else None


def metrics_to_payload(issue_metrics, issue_summaries, mr_metrics, mr_summaries) -> dict:
    return {
        "issue_metrics": [{**vars(m), "created_at": _dt_out(m.created_at),
                           "in_progress_at": _dt_out(m.in_progress_at),
                           "closed_at": _dt_out(m.closed_at)} for m in issue_metrics],
        "issue_summaries": {k: dict(vars(v)) for k, v in issue_summaries.items()},
        "mr_metrics": [{**vars(m), "created_at": _dt_out(m.created_at),
                        "first_touch_at": _dt_out(m.first_touch_at),
                        "merged_at": _dt_out(m.merged_at),
                        "closed_at": _dt_out(m.closed_at)} for m in mr_metrics],
        "mr_summaries": {k: dict(vars(v)) for k, v in mr_summaries.items()},
    }


def payload_to_metrics(payload: dict):
    payload = payload or {}
    issues = [IssueMetric(**{**d, "created_at": parse_ts(d.get("created_at")),
                             "in_progress_at": parse_ts(d.get("in_progress_at")),
                             "closed_at": parse_ts(d.get("closed_at"))})
              for d in payload.get("issue_metrics", [])]
    isums = {k: MonthIssueSummary(**v) for k, v in (payload.get("issue_summaries") or {}).items()}
    mrs = [MRMetric(**{**d, "created_at": parse_ts(d.get("created_at")),
                       "first_touch_at": parse_ts(d.get("first_touch_at")),
                       "merged_at": parse_ts(d.get("merged_at")),
                       "closed_at": parse_ts(d.get("closed_at"))})
           for d in payload.get("mr_metrics", [])]
    msums = {k: MonthMRSummary(**v) for k, v in (payload.get("mr_summaries") or {}).items()}
    return issues, isums, mrs, msums
