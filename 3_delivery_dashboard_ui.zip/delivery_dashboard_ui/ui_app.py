"""
The dashboard UI: cascading multi-select filters beside the chart.

    Division > Subdivision > Stream > Crew > Pod

Every level is multi-select and narrows the levels below it. Selecting
nothing at a level means "all", which is what a dashboard filter is
normally expected to do.

**Crew-level vs pod-level data.** When the selection covers exactly one
crew and *all* of its pods, the pre-computed `crew_rollup_*` tables are used
directly -- that is what they are for, and it guarantees the UI agrees with
the crew XLSX/HTML report. Any other selection (a subset of pods, or pods
spanning crews) is combined on the fly from the pod tables, since no stored
roll-up exists for an arbitrary subset.

**Fetch once, filter many.** Every pod's monthly rows are read in one query
and cached, so moving the dropdowns is arithmetic over a few hundred numbers
rather than a database round trip.

Widgets are optional: with `ipywidgets` you get the live filters, and
without it `render(...)` produces exactly the same chart from a scripted
selection.
"""
from __future__ import annotations

import os
from typing import Dict, List, Optional, Sequence

from ui_charts import build_figure, save_png
from ui_data import (LEVELS, DbSettings, MonthRow, Org, all_months, baseline_months,
                     combine_pods, get_logger, load_monthly, load_org)
from ui_series import build_series

log = get_logger("ui.app")

try:
    import ipywidgets as widgets
    from IPython.display import clear_output, display
    HAVE_WIDGETS = True
except ImportError:                                   # pragma: no cover
    widgets = None
    HAVE_WIDGETS = False


class DashboardApp:
    def __init__(self, db: DbSettings, baseline_month: str = "2025-11",
                 baseline_window_months: int = 3, target_gain_pct: float = 20.0,
                 target_months: int = 14, rolling_window: int = 3,
                 output_dir: str = "."):
        self.db = db
        self.baseline_month = baseline_month
        self.baseline_window_months = baseline_window_months
        self.target_gain_pct = target_gain_pct
        self.target_months = target_months
        self.window = rolling_window
        self.output_dir = output_dir

        self.org = load_org(db)
        self._pod_cache: Dict[str, dict] = {}
        self._crew_cache: Dict[str, dict] = {}
        self.last_figure = None
        self.last_series = None

    # ------------------------------------------------------------- data
    def load(self, progress=None):
        """Reads every pod's and every crew's monthly rows, once."""
        def say(m):
            log.info(m)
            if progress:
                progress(m)

        pods = self.org.pods()
        crews = self.org.crews()
        say("Loading %d pod(s) and %d crew roll-up(s) from Greenplum..."
            % (len(pods), len(crews)))
        self._pod_cache = load_monthly(self.db, "pod", pods)
        self._crew_cache = load_monthly(self.db, "crew", crews)
        empty = [p for p in pods if not self._pod_cache.get(p)]
        if empty:
            say("No stored rows for: %s -- has the reporting job run for them yet?"
                % ", ".join(empty))
        say("Cached %d pod scope(s), %d crew scope(s)."
            % (len(self._pod_cache), len(self._crew_cache)))
        return self

    def _resolve(self, selection):
        """(level, scope names, per-scope rows, label) for a selection.

        Returns crew-level rows when the selection is exactly one whole crew,
        otherwise pod rows to be combined.
        """
        pods = self.org.pods(selection)
        crews = self.org.crews(selection)
        if not pods:
            return "pod", [], {}, "no selection"

        if len(crews) == 1:
            crew = crews[0]
            if set(pods) == set(self.org.pods_of_crew(crew)) and self._crew_cache.get(crew):
                # the whole crew, and a stored roll-up exists for it
                return "crew", [crew], {crew: self._crew_cache[crew]}, "%s (crew)" % crew

        per = {p: self._pod_cache.get(p, {}) for p in pods}
        label = pods[0] if len(pods) == 1 else "%d pods: %s" % (len(pods), ", ".join(pods))
        return "pod", pods, per, label

    # ------------------------------------------------------------- render
    def render(self, selection: Optional[Dict[str, Sequence[str]]] = None,
               save: bool = False, show: bool = True):
        selection = selection or {}
        level, scopes, per, label = self._resolve(selection)
        if not scopes:
            log.warning("Nothing matches this selection.")
            return None, None, None

        months = all_months(per)
        if not months:
            log.warning("No stored data for %s.", label)
            return None, None, None

        rows = (per[scopes[0]] if level == "crew" else combine_pods(per, months))
        bm = self.baseline_month
        stored = baseline_months(per)
        if stored and bm not in stored:
            # trust what the reporting job flagged over the local default
            bm = sorted(stored)[0]

        ser = build_series(rows, months, bm, self.baseline_window_months,
                           self.target_gain_pct, self.target_months, self.window,
                           scopes=scopes)
        fig = build_figure(ser, label)
        self.last_figure, self.last_series = fig, ser

        path = None
        if save:
            safe = "".join(c if (c.isalnum() or c in "._-") else "_" for c in label).strip("_")
            path = save_png(fig, self.output_dir, "%s_dashboard" % safe[:60])
        if show:
            try:
                from IPython.display import display as _d
                _d(fig)
            except Exception:
                pass
        return fig, ser, path

    # ------------------------------------------------------------- widgets
    def show(self, width: str = "300px"):
        if not HAVE_WIDGETS:
            raise RuntimeError(
                "ipywidgets is not installed, so the interactive filters are unavailable. "
                "The dashboard still works -- call app.render({'pod': ['Insights']}) with "
                "whatever selection you want, or install ipywidgets for the dropdowns.")

        titles = {"division": "Select Division", "subdivision": "Select Subdivision",
                  "stream": "Select Stream", "crew": "Select Crew", "pod": "Select Pod"}
        self._boxes = {}
        rows = []
        for lv in LEVELS:
            box = widgets.SelectMultiple(options=self.org.options(lv), value=(), rows=4,
                                         layout=widgets.Layout(width=width))
            box.observe(self._on_change, names="value")
            self._boxes[lv] = box
            rows.append(widgets.VBox([
                widgets.HTML("<b style='font-size:13px'>%s</b>"
                             "<div style='color:#777;font-size:11px'>none selected = all</div>"
                             % titles[lv]), box]))

        self._status = widgets.HTML("")
        reload_btn = widgets.Button(description="Reload from Greenplum", icon="refresh",
                                    layout=widgets.Layout(width=width))
        reload_btn.on_click(self._on_reload)
        save_btn = widgets.Button(description="Save PNG", icon="download",
                                  layout=widgets.Layout(width=width))
        save_btn.on_click(self._on_save)

        left = widgets.VBox(rows + [reload_btn, save_btn, self._status],
                            layout=widgets.Layout(padding="6px", border="1px solid #e6e8eb"))
        self._out = widgets.Output()
        display(widgets.HBox([left, self._out]))
        self._redraw()

    def _selection(self):
        return {lv: list(self._boxes[lv].value) for lv in LEVELS}

    def _on_change(self, change):
        """Repopulates the levels BELOW the one that changed.

        Selections that are no longer valid are dropped -- a stale choice
        from a previous division would otherwise filter everything out.
        """
        changed = next((lv for lv in LEVELS if self._boxes[lv] is change["owner"]), None)
        if changed is None:
            return
        sel = self._selection()
        for lv in LEVELS[LEVELS.index(changed) + 1:]:
            box = self._boxes[lv]
            opts = self.org.options(lv, sel)
            keep = tuple(v for v in box.value if v in opts)
            box.unobserve(self._on_change, names="value")
            box.options = opts
            box.value = keep
            box.observe(self._on_change, names="value")
            sel[lv] = list(keep)
        self._redraw()

    def _redraw(self):
        sel = self._selection()
        level, scopes, _per, label = self._resolve(sel)
        self._status.value = (
            "<div style='font-size:11px;color:#555;padding-top:6px'>%s<br>source: <b>%s</b> "
            "tables</div>" % (label, level))
        with self._out:
            clear_output(wait=True)
            if not scopes:
                print("No pods match this selection.")
                return
            self.render(sel, save=False, show=True)

    def _on_reload(self, _btn):
        with self._out:
            clear_output(wait=True)
            print("Reloading from Greenplum...")
            self.org = load_org(self.db)
            self.load(progress=print)
        self._redraw()

    def _on_save(self, _btn):
        if self.last_figure is None:
            return
        _f, _s, path = self.render(self._selection(), save=True, show=False)
        if path:
            self._status.value = ("<div style='font-size:11px;color:#0b6b36;padding-top:6px'>"
                                  "Saved %s</div>" % os.path.basename(path))
