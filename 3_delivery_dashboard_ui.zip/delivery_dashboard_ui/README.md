# Delivery Productivity Dashboard (UI)

Interactive charts built **entirely from the Greenplum tables** that the reporting job already
loaded. Nothing here touches GitLab and nothing is recomputed from raw issues — the numbers shown are
the same ones in the XLSX and HTML reports.

Cascading multi-select filters: **Division → Subdivision → Stream → Crew → Pod**. Selecting nothing
at a level means *all*.

## Which tables get used

| Selection | Source |
|---|---|
| Exactly one crew, **all** its pods | `crew_rollup_issue_monthly_summary` · `crew_rollup_mr_monthly_summary` |
| A single pod, or any subset of pods | `pod_issue_monthly_summary` · `pod_mr_monthly_summary`, combined on the fly |

**There is no pod-to-table map.** Every pod's rows live in the same four tables, distinguished by
`scope_name` — one naming convention rather than a mapping that would have to be maintained by hand
and would drift the first time a pod was renamed.

The stored crew roll-up is preferred whenever it applies, so the UI agrees with the crew report
exactly. An arbitrary subset of pods has no stored roll-up, so those are combined here.

## Tables read

```
sandbox_prj_smart_insights.delivery_org_hierarchy              -- the dropdowns
sandbox_prj_smart_insights.pod_issue_monthly_summary
sandbox_prj_smart_insights.pod_mr_monthly_summary
sandbox_prj_smart_insights.crew_rollup_issue_monthly_summary
sandbox_prj_smart_insights.crew_rollup_mr_monthly_summary
```

Read-only. Nothing is written.

## Files

| File | Purpose |
|---|---|
| `ui_data.py` | Greenplum access, the hierarchy, cascading filter logic, pod combination |
| `ui_series.py` | Baseline, shift, aspiration and the 3-month windows |
| `ui_charts.py` | The dashboard figure |
| `ui_app.py` | `DashboardApp` — filters, cache, PNG export |
| `run_dashboard_ui.ipynb` | The notebook |

## Running it

```python
from ui_data import DbSettings
from ui_app import DashboardApp

db = DbSettings(); db.resolve_password(interactive=True)
app = DashboardApp(db, baseline_month="2025-11", baseline_window_months=3)
app.load()
app.show()                                   # interactive filters
app.render({"pod": ["Insights"]})            # or a scripted selection
```

The password resolves as `GREENPLUM_PASSWORD` → Airflow Variable → prompt.

## Things worth knowing

**Fetch once, filter many.** Every pod's and crew's monthly rows are read in one query at `load()`,
so moving the dropdowns is arithmetic over a few hundred numbers rather than a database round trip.
*Reload from Greenplum* refreshes after the reporting job has run.

**Combining pods.** Counts add up; averages are **not** averaged again. Cycle time and lead time are
weighted by volume, and merged-MRs-per-author is recomputed from total merges over total authors —
otherwise a pod that closed two issues would sway the mean as hard as one that closed fifty.

**Baseline** comes from the months flagged `is_baseline_month` in the tables, so the UI follows what
the reporting job actually used rather than a local guess.

**Widgets are optional.** With `ipywidgets` you get the live filters; without it `render(...)`
produces the same chart from a scripted selection, so the dashboard degrades rather than failing.

## Validation performed

Tested against a stubbed database with three pods over 21 months:

- **Table routing** — no filters, an explicit crew, and all three pods listed each resolved to the
  **crew** tables; a single pod and a two-of-three subset resolved to the **pod** tables.
- **Cascading options** populated at all five levels.
- **Rendering** succeeded for every selection, each producing 19 three-month windows with the
  baseline correctly read as Nov-25/Dec-25/Jan-26 from the stored flags.
- **Aspiration meets actual** at the baseline window for all four parameters.
