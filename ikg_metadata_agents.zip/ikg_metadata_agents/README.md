# IKG Metadata + Knowledge Graph — agent-based

Multi-agent program that generates, for every attribute of every IKG profile table, a **functional name,
precise business description, entity, type, unit and confidence score (with what is required when low)**,
an **abbreviation glossary**, and a **knowledge graph** (entities as nodes, attributes as leaves,
relationships between entities).

**Outputs:** `output/IKG_Profile_Attribute_Metadata.xlsx` and `output/knowledge_graph/knowledge_graph.html`
(plus a picture per entity, GraphML and Neo4j CSV).

## Agents

| Agent | Understands | Tools |
|---|---|---|
| **Master** | the whole program | runs specialists, quality report, escalation, write outputs (gated) |
| **Skill** | `skills/*.md` (firm knowledge) | list / read / search skills |
| **Data Dictionary** | EDW Data Dictionary, abbreviations | EDW lookup / search / table columns, token usage, repo search |
| **Table Catalog** | Greenplum: `ikg_profile_table_descriptions`, `information_schema`, `ikg_column_lineage_master_auto_refresh`, actual values | catalogue, lineage walk, lineage rows, **read-only value profiling** |
| **Code** | GitLab `ikg-dags` code | read profile SQL, find table writers, read any SQL/Python file, regex search, code lineage |
| **Metadata Author** | all evidence | evidence pack + all of the above on demand |
| **Reviewer** | all evidence | same; verdict correct / revised / insufficient_evidence |
| **Graph** | entities and relationships | relationships + evidence, entity attributes, table entities |

Order of work (enforced): skills → dictionary → catalog + code → author → reviewer → escalation of Low
(max 2 per attribute) → graph → outputs. `agents.orchestration: llm` lets the master agent decide within
these gates; `deterministic` runs the fixed order.

## Accuracy safeguards
* **Grounding:** a skill fact, abbreviation or SQL rule is accepted only if its quote is found verbatim in
  the skill file, EDW dictionary or repository. Otherwise it is rejected and the agent must fix it.
* **Schema validation:** results must use allowed entities and enums, give unique names within a table, and keep
  unresolved abbreviations out of names. Errors are sent back to the agent.
* **Two independent lineages:** the lineage table walked upstream (unqualified columns resolved, PARTITION BY keys
  not followed) plus a parser over all repository SQL, with intermediate filters.
* **Full code reading:** the code agent reads every complete create script and the upstream code. The author and
  reviewer receive the full script with every batch.
* **Real data:** the catalog agent profiles the actual values of flags and codes (read-only template SQL,
  identifiers validated, 60-second timeout).
* **Confidence score:** 0.6 × model rubric + 0.4 × evidence score. The score is capped below High when an abbreviation
  is unresolved, and the `what_is_required` column lists the concrete missing input.
* **Audit:** every agent step and tool call is logged in the `Agent_Trace` sheet. Agent results are cached by
  their inputs, so re-runs are repeatable and only redo work affected by new knowledge.

## Scope: IKG profile tables + ODM tables + NLG tables (one run)
| Domain | Tables | Source of truth | Metadata target | Skip rule (vs `ikg_attribute_business_description`) | Graph / `_v2` |
|---|---|---|---|---|---|
| IKG | every `*_profile_curr_ikg` create script in `ikg-dags` | create script, lineage table, EDW dictionary, skills | `ikg_attribute_business_description` | column level (delta) | yes (unchanged) |
| ODM | `core_ikg.si_odm_insights_active`, `core_ikg.odm_exclusion_insight_type` (`domains.odm.tables`) | `odm-dags` (DDL `odm_table_creation.sql`, every rule script that inserts, exclusion script), information_schema, `skills/odm_knowledge_skill.md` | same table | **column level**: an attribute already present is skipped, the others are added | no |
| NLG | every table of `nlg-dags/dags/nlg/src/config/nlg_db_tables.ini` section `[prod_active]` (`environment: PROD`, `schema_nlg = core_nlg`), `[dev_active]` (`UAT`, `schema_nlg = sandbox_prj_insights_nlg`) or `[dev_review]` (`TEST`, `schema_nlg = sandbox_prj_insights_nlg`); schema resolved from the code (`{settings['schema_x']}.{settings['key']}`), the key prefix and information_schema (core_ikg / core_nlg) | `nlg-dags` Python / YAML / ini (NLG writes its tables from Python), information_schema, `skills/nlg_knowledge_skill.md` | same table | **table level**: a table with ANY attribute already present is skipped completely | no |

IKG profile tables referenced by the ini (`input_tbl_*`) stay IKG tables (listed in the `ODM_NLG_Tables` sheet as
"documented by the IKG profile metadata"). For every ODM / NLG column the evidence pack carries, in addition to the
usual lineage / EDW / glossary items: `code_mentions` (file:line excerpts), `published_definition` (same column name
already described for a profile table - names and descriptions stay consistent), `upstream_candidates` (tables in
`core_ikg` / `core_nlg` / `core_wma_shared` carrying the same column name - the agents hop there with
`find_table_writers` / `read_sql_file` / `edw_lookup`). ODM columns also get the distinct SQL expressions of the rule
scripts (`sql_expression`) and the resolved source columns. `generation.mode: full` regenerates the profile tables
but the ODM / NLG skip rules still apply. New glossary tokens from ODM / NLG column names are added to the glossary.

**Knowledge-graph viewer**: the sidebar links to separate pages under `output/knowledge_graph/diagrams/` - ODM
architecture, NLG architecture, narratives (client / household rules, Field-Leader rules, prospect rules) and one
flow per NLG product (client briefings, FA alerts, FA subscriptions, banker alerts, FL talent report, market event
alerts, prospect alerts, JSON insights, retention pack, no-e-mail interaction). Table names on the pages come from
the ini section of the run and every page lists the tables with the attribute descriptions generated / published.

**Skills folder** (`skills/`): `ikg_knowledge_skills.md` (household definitions, statement household / acc_mhh_n,
metadata writing standards - the former three files merged), `odm_knowledge_skill.md`, `nlg_knowledge_skill.md`.
If an ODM / NLG skill file is missing it is written ONCE from the repository (`domains.generate_missing_skill_files`)
and never recreated; when the skills folder is read-only (Airflow DAG folder) it goes to `output/skills/`.

## Which tables (IKG scope = the lineage query)
`generation.ikg_table_scope: lineage` (default) runs `generation.ikg_lineage_tables_sql` - the query that lists every
table of the IKG schema (`pg_class`, relkind r / m / v, no `_prt_` partitions) that appears in the lineage table as
target, sub-target or source. Profile tables keep their full treatment (metadata, graph, `_v2`); every other table of
that list is an **intermediate (lineage) table**: columns from its create / insert script in the repository (any
folder, script whose stem is the table name) or from information_schema, metadata authored with the same agents
(no code-agent brief - `agents.code_agent_domains`), written to the same workbook / metadata table, skipped column by
column once published; no graph entity, no `_v2`. ODM and NLG tables as before.

## Daily budget (why a run fits in 5-10 minutes)
`generation.max_new_attributes_per_run` (400) and `time_budget_minutes` (10): a run authors at most that many NEW
attributes - whole tables, profile tables first, then ODM / NLG, then intermediate tables - and stops starting new
tables after the time budget; everything else is a **backlog** that the next run picks up (Delta_Summary and the
e-mail show `backlog_attributes_for_next_runs` / `backlog_tables_for_next_runs`). The workbook and the metadata table
are always complete for what was authored; the first load of a big scope therefore spreads over several daily runs
instead of one 5-hour run. Raise the two values (or set them to 0 = no limit) for a one-off full load.

The time budget counts from the **start of the run** (repository download, evidence, glossary included), so the whole
program - not only the agents - stays inside it; `min_tables_per_run` (8) tables are always authored even when the data
layer used the budget up. Three more things keep a delta run short: the dictionary agent resolves only the name
tokens of the attributes authored this run (`agents.dictionary_scope: run`), intermediate lineage-scope attributes
that are already published get no evidence pack, and a table list passed to the pipeline (e.g. by the LLM master)
is always cut down to the tables that have something new. Use `orchestration: deterministic` (the default, also in
the notebook) - the LLM master may call the table pipeline for tables that have nothing to author.

## Run time and tokens (why the first run took 5 hours, what changed)
The log of the 5-hour run shows the real limiter: the Azure deployment's ~200k tokens-per-minute quota - every 429
cost a 30 s pause and halved the concurrency, the LLM master re-ran escalation for 228 Low batches (90 min alone),
the reviewer re-checked every non-High attribute, and every author / code call carried up to 40-200k characters of
SQL. 1,567 new attributes in 97 tables simply need a few million tokens; at 200k TPM that is never 5 minutes.
Defaults now: deterministic orchestration (no LLM master), `escalation_rounds: 0`, `review_scope: low`,
`columns_per_call: 30`, prefixes capped (`author_sql_chars` 15k, `code_agent_sql_chars` 30k, `upstream_prefetch_chars`
10k, `max_sql_chars` 30k), reasoning effort `low` for the code / author agents, no value profiling (`catalog_agent:
false`), requests paced to `tokens_per_minute: 180000` (no 429 storms), repositories downloaded in parallel and
re-used for `gitlab.cache_hours`, the code-mention index cached on disk. Expected: a **delta run (a few new
attributes) finishes in 3-8 minutes** (repository check, lineage, evidence, graph, pages, clones); a **first load of
~1,500 attributes needs ~2 million tokens = 15-25 minutes** at the 180k TPM pace - raise `tokens_per_minute` /
`parallel_calls` if the deployment quota is higher. `output/token_stats.txt` (+ the `Token_Stats` sheet) shows
total / per-process tokens, prompt-cache hits, reasoning share, rate-limit hits and tokens per minute of every run.

## What every run writes (`output/`)
| File | Content |
|---|---|
| `Insights_attribute_metadata.xlsx` | all sheets (Metadata with `upstream` + `current_datetime`, ODM_NLG_Tables, Clone_*, Token_Stats ...) |
| `log_<YYYYMMDD_HHMMSS>.txt` | every log line of the run |
| `token_stats.txt` / `.json` | token statistics (total, per process / agent, averages, cache hits, tokens / minute) |
| `profile_table_clones.sql.txt` | the `_v2` script (create once + drop columns) |
| `refreshed_tables.sql.txt` | every Greenplum table touched by the run (metadata, glossary, graph tables, `_v2`) with a check query |
| `knowledge_graph/knowledge_graph.html` + `.md`, `md/<Entity>.md`, `md/odm_nlg_tables.md` | the graph as interactive page and as markdown (mermaid entity model, tables per entity, every attribute) |
| `knowledge_graph/diagrams/*.html` + `*.md` | ODM / NLG diagrams; the markdown twins hold the same boxes and lines as mermaid flowcharts |
| `knowledge_graph/skill.md` | index skill file that refers to every markdown file |

Order of a run: agents -> **workbook + `ikg_attribute_business_description` insert / update first** -> graph agent,
HTML + markdown pages -> `_v2` clones -> token statistics. The metadata table gets two columns added when they are
missing (`ALTER TABLE ... ADD COLUMN`): `upstream` (hops `table.column <- hop <- ... <- source`) and
`current_datetime` (the run time, set on EVERY row each run; `upstream` is filled for existing rows the first time).
`_v2` clones are created once (`CREATE TABLE ... AS SELECT *`, never dropped / re-created); every run only drops the
duplicated columns still present; every duplicate is removed in one pass (no "review" leftovers - `Clone_Report`
flags copies without a joining key or with a different lineage; keep any of them with `output.dedupe.never_remove`);
`output.clone_refresh_data: true` reloads the clone data every run.

## Two editions - identical logic (`ikgmeta/` is the same package)
| | Notebook / command line (this zip) | Airflow DAG (`Insights_metadata_airflow.zip`) |
|---|---|---|
| start | `IKG_Metadata_Agents.ipynb` or `python run_pipeline.py` | DAG `Insights_metadata` (folder `Insights_metadata/`, file `Insights_metadata.py`), one task `run_insights_metadata` + `send_metadata_email`, Mon-Fri 06:00 America/New_York |
| configuration | `config/ikg_metadata_config.yaml` (`odm_env: PROD` / `UAT` / `TEST`, or env variable `ODM_ENV`, or `--env` -> `environments:` block: IKG schema, NLG ini section, owner / reader roles; nothing else names a schema or role) | same file under `Insights_metadata/scripts/config/`; Variable `ODM_ENV` (PROD / UAT / TEST) selects the same block; `IKG_SCHEMA`, `IKG_TABLE_OWNER_GROUP`, `IKG_TABLE_READER_GROUP`, `EDW_INPUT_SCHEMA` override it |
| secrets | asked at run time (hidden) or env `IKG_AZURE_OPENAI_API_KEY` / `IKG_GP_PASSWORD` / `IKG_GITLAB_TOKEN` | Variables `GENESIS_DDLC_IKG_GIT_SECRET` (GitLab), `IKG_AZURE_OPENAI_API_KEY` (Azure), Connection `IKG_GP_GPRDSP` (Greenplum) - read into memory only |
| output | `output/` next to the notebook | Variable `INSIGHTS_METADATA_OUTPUT_DIR` (default `/opt/airflow/data/insights_metadata` when writable, else `<tmp>/insights_metadata`); e-mail attaches the workbook, graph html, clone `.sql.txt`, token stats, refreshed-table queries and the log (each < 15 MB) |
| entry code | `ikgmeta/agents.prepare` + `agents.run` | `ikgmeta/airflow_runner.run_insights_metadata` (same two calls) |

## Setup
```bash
pip install -r requirements.txt          # optional: Graphviz "dot" for SVG pictures
```
Put **`EDW Data Dictionary.xlsx`** and the **`skills/`** folder next to the notebook. Skill files are markdown
files **directly in `skills/`** (no sub-folders). Secrets are asked at runtime (hidden) or read from
`IKG_AZURE_OPENAI_API_KEY`, `IKG_GP_PASSWORD`, `IKG_GITLAB_TOKEN`; nothing secret is stored. The GitLab token
needs read access to `ikg-dags`, `odm-dags` and `nlg-dags` (branch `main`).

## Run
Notebook `IKG_Metadata_Agents.ipynb` (top to bottom), or:
```bash
python run_pipeline.py --check                  # Greenplum, GitLab, Azure OpenAI
python run_pipeline.py --selftest               # full agent system with a scripted offline model (no tokens)
python run_pipeline.py --tables household_art_profile_curr_ikg client_profile_curr_ikg   # pilot
python run_pipeline.py                          # all tables (master agent)
python run_pipeline.py --orchestration deterministic
python run_pipeline.py --env UAT                # sandbox_ikg_pre_prd, NLG ini [dev_active], smart_insights roles (TEST: sandbox_prj_smart_insights, [dev_review])
python run_pipeline.py --no-domains             # profile tables only (ODM / NLG off)
```

## Performance
* **Streaming per-table pipelines** (`run_table_pipelines`): each table runs profile → code brief → author →
  review → escalation on its own, and all tables run concurrently, so stages overlap; the LLM client caps the real
  number of concurrent Azure calls (`llm.parallel_calls`, default 12).
* **Catalog step without an LLM** (`agents.catalog_agent: profile_only`): value profiles of flag/code columns are
  computed directly and attached as evidence.
* Every agent gets its evidence **prefetched** (dictionary: EDW columns + skill passages per token; catalog:
  catalogue + value profiles; code: first-level upstream scripts; author/reviewer: full evidence pack), so most
  tasks finish in 1-2 model turns; tools are only for gaps. Tool calls issued in one turn run in parallel.
* `llm.parallel_calls` (default 8) concurrent agent tasks; raise to 12-16 if the deployment quota allows
  (429s are retried with back-off). Catalog + code agents for all tables run in a single pool.
* `agents.reasoning_effort` per agent: low for skill / dictionary / catalog / reviewer / graph / master,
  medium for code and author (set author to `low` for ~2x faster, slightly less precise output).
* Cached agent results (`output/cache/llm/agent_*.json`) carry `table_name` / `column_name` on every item.
* Agent results are cached by input (`output/cache`), so interrupted or repeated runs only redo new work.
* A failed or forced submission is accepted with its issues recorded (`_validation_issues`, Agent_Trace)
  instead of losing the batch; invalid evidence is downgraded, never used.

## Azure rate limits (429)
The deployment's tokens-per-minute quota is the real throughput limit. The client adapts to it: on a 429 the
number of concurrent calls is halved and all threads pause for Azure's Retry-After, then the limit grows back
after successes; a rate-limited request is retried for up to `rate_limit_max_wait_seconds` (30 min) so no batch
is dropped. Set `llm.tokens_per_minute` to your quota to pace requests before they hit 429. Author / reviewer
calls carry at most `agents.author_sql_chars` of the table script (the code agent gets the full script once).

## Greenplum tables (core_ikg) and delta mode
| table | content | refresh |
|---|---|---|
| `ikg_attribute_business_description` | the `Metadata` tab (table_name, column_name, business_attribute_name, description, confidence …) | created once (IF NOT EXISTS); each run inserts only NEW (table, column) pairs |
| `ikg_graph_relationship` | entity relationships with evidence | replaced each run |
| `ikg_graph_joining_key` | joining key per relationship (e.g. Client–Household on acc_mhh_n) with the tables that carry it | replaced each run |
| `ikg_metadata_glossary_llm` | abbreviation glossary | replaced each run |
| `<profile_table>_v2` | clone of every profile table without duplicated columns: every attribute keeps exactly ONE home table (owner table of its entity, e.g. `mhh_*` -> `household_profile_curr_ikg`; otherwise the biggest table of that entity carrying it), every other table that can re-join on a key loses the copy. `Clone_Duplicates` sheet = one row per duplicated attribute with its home and where it was removed; `Clone_Report` = every column decision. Config `output.dedupe.home_overrides` / `never_remove` adjust it | dropped + re-created each run |

Every table gets `ALTER TABLE … OWNER TO <owner>` and `GRANT SELECT … TO <reader>`: PROD `erd_gpdb_prj_ikg` /
`erd_gpdb_prj_ikg_ro`, UAT and TEST `erd_gpdb_prj_smart_insights` / `erd_gpdb_prj_smart_insights_ro`
(`environments.<env>.table_owner_role` / `table_reader_role`; Airflow Variables `IKG_TABLE_OWNER_GROUP` / `IKG_TABLE_READER_GROUP` override). `generation.mode: delta` (default) compares the deployed
`%profile_curr_ikg` tables and columns against `ikg_attribute_business_description`: only new tables / columns are
generated and inserted; a column name already published for another table is copied for consistency
(`same_name_policy: always`). The clone script is also written to `output/profile_table_clones.sql.txt`.

## Workbook sheets
Run_Info · **Metadata** (table_name, column_name, business_attribute_name, description, confidence score/band,
entity, attribute type, unit, derivation type, data type, confidence reason, difficult to generate, what is
required, evidence used, verify verdict) · **ODM_NLG_Tables** (every ODM / NLG table: schema, ini key, role, columns,
already in the metadata table, authored this run, status) · Joining_Keys · Clone_Summary · Clone_Report · Delta_Summary ·
Attribute_Metadata (all evidence columns incl. domain, schema_name, code_mentions, upstream_candidates, published_definition) ·
Needs_Review · Glossary · Glossary_Needs_Input · Table_Summary (with domain / schema) · Entity_Relationships ·
Skills_Knowledge · Table_Briefs · Value_Profiles · Graph_Review · Agent_Trace

## Correcting a column meaning (example: acc_mhh_n)
State the fact in a skill file in plain prose, e.g. `acc_mhh_n = statement household (sourced from
household_plus), not the marketing household`, or under `column_definitions` in `config/glossary_overrides.yaml`.
The skill agent extracts it (verbatim quote required), it is attached as an AUTHORITATIVE definition to that
column in every profile table, glossary tokens that conflict with it (mhh = "Market Household") are sent back to
the dictionary agent, and the author / reviewer must follow skill definitions and lineage over name expansions.
Then re-run with `generation.only_columns: ["acc_mhh_n", "mhh_*"]` to regenerate only those attributes.

## Improving results
Fill `Glossary_Needs_Input` meanings into a skill file (`abbr = Meaning`) or `config/glossary_overrides.yaml`,
add definitions / code values / table notes to `skills/*.md`, then re-run.

## Folder
```
IKG_Metadata_Agents.ipynb   run_pipeline.py   requirements.txt   README.md
config/   ikg_metadata_config.yaml, entity_model.yaml, glossary_overrides.yaml, business_definitions.md
skills/   ikg_knowledge_skills.md, odm_knowledge_skill.md, nlg_knowledge_skill.md
prompts/agents/   one prompt per agent        prompts/   legacy single-pass prompts
ikgmeta/  sources (3 repositories), sql_parser, code_lineage, lineage, glossary, llm, pipeline (data layer),
          domains (ODM / NLG table discovery + evidence), skill_writer (skill files written once), diagrams
          (ODM / NLG pages), airflow_runner (Airflow entry), report, knowledge_graph, skills,
          agents/ (base, context, tools, specialists, master, selftest)
samples/  sample EDW dictionary rows, profile descriptions, lineage rows
```
