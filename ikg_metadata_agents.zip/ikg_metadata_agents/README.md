# IKG Metadata + Knowledge Graph — agent-based

Multi-agent program that generates, for every attribute of every IKG profile table, a **functional name,
precise business description, entity, type, unit and confidence score (with what is required when low)**,
an **abbreviation glossary**, and a **knowledge graph** (entities as nodes, attributes as leaves,
relationships between entities).

**Outputs:** `output/IKG_Profile_Attribute_Metadata.xlsx` and `output/knowledge_graph/knowledge_graph.html`
(plus a picture per entity, GraphML and Neo4j CSV).

## Agents

| Agent | Understands | Tools |
|---|---|---|
| **Master** | the whole program | runs specialists, quality report, escalation, write outputs (gated) |
| **Skill** | `skills/*.md` (firm knowledge) | list / read / search skills |
| **Data Dictionary** | EDW Data Dictionary, abbreviations | EDW lookup / search / table columns, token usage, repo search |
| **Table Catalog** | Greenplum: `ikg_profile_table_descriptions`, `information_schema`, `ikg_column_lineage_master_auto_refresh`, actual values | catalogue, lineage walk, lineage rows, **read-only value profiling** |
| **Code** | GitLab `ikg-dags` code | read profile SQL, find table writers, read any SQL/Python file, regex search, code lineage |
| **Metadata Author** | all evidence | evidence pack + all of the above on demand |
| **Reviewer** | all evidence | same; verdict correct / revised / insufficient_evidence |
| **Graph** | entities and relationships | relationships + evidence, entity attributes, table entities |

Order of work (enforced): skills → dictionary → catalog + code → author → reviewer → escalation of Low
(max 2 per attribute) → graph → outputs. `agents.orchestration: llm` lets the master agent decide within
these gates; `deterministic` runs the fixed order.

## Accuracy safeguards
* **Grounding:** a skill fact, abbreviation or SQL rule is accepted only if its quote is found verbatim in
  the skill file, EDW dictionary or repository. Otherwise it is rejected and the agent must fix it.
* **Schema validation:** results must use allowed entities and enums, give unique names within a table, and keep
  unresolved abbreviations out of names. Errors are sent back to the agent.
* **Two independent lineages:** the lineage table walked upstream (unqualified columns resolved, PARTITION BY keys
  not followed) plus a parser over all repository SQL, with intermediate filters.
* **Full code reading:** the code agent reads every complete create script and the upstream code. The author and
  reviewer receive the full script with every batch.
* **Real data:** the catalog agent profiles the actual values of flags and codes (read-only template SQL,
  identifiers validated, 60-second timeout).
* **Confidence score:** 0.6 × model rubric + 0.4 × evidence score. The score is capped below High when an abbreviation
  is unresolved, and the `what_is_required` column lists the concrete missing input.
* **Audit:** every agent step and tool call is logged in the `Agent_Trace` sheet. Agent results are cached by
  their inputs, so re-runs are repeatable and only redo work affected by new knowledge.

## Setup
```bash
pip install -r requirements.txt          # optional: Graphviz "dot" for SVG pictures
```
Put **`EDW Data Dictionary.xlsx`** and the **`skills/`** folder next to the notebook (an example skills
folder is included - replace/extend it). Secrets are asked at runtime (hidden) or read from
`IKG_AZURE_OPENAI_API_KEY`, `IKG_GP_PASSWORD`, `IKG_GITLAB_TOKEN`; nothing secret is stored.

## Run
Notebook `IKG_Metadata_Agents.ipynb` (top to bottom), or:
```bash
python run_pipeline.py --check                  # Greenplum, GitLab, Azure OpenAI
python run_pipeline.py --selftest               # full agent system with a scripted offline model (no tokens)
python run_pipeline.py --tables household_art_profile_curr_ikg client_profile_curr_ikg   # pilot
python run_pipeline.py                          # all tables (master agent)
python run_pipeline.py --orchestration deterministic
```

## Workbook sheets
Run_Info · Attribute_Metadata · Needs_Review · Glossary · Glossary_Needs_Input · Table_Summary ·
Entity_Relationships · Skills_Knowledge · Table_Briefs · Value_Profiles · Graph_Review · Agent_Trace

## Improving results
Fill `Glossary_Needs_Input` meanings into a skill file (`abbr = Meaning`) or `config/glossary_overrides.yaml`,
add definitions / code values / table notes to `skills/*.md`, then re-run.

## Folder
```
IKG_Metadata_Agents.ipynb   run_pipeline.py   requirements.txt   README.md
config/   ikg_metadata_config.yaml, entity_model.yaml, glossary_overrides.yaml, business_definitions.md
skills/   example skill files (household definitions, metadata standards)
prompts/agents/   one prompt per agent        prompts/   legacy single-pass prompts
ikgmeta/  sources, sql_parser, code_lineage, lineage, glossary, llm, pipeline (data layer), report,
          knowledge_graph, skills, agents/ (base, context, tools, specialists, master, selftest)
samples/  sample EDW dictionary rows, profile descriptions, lineage rows
```
