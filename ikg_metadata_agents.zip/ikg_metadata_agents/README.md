# IKG Metadata + Knowledge Graph — agent-based

Multi-agent program that generates, for every attribute of every IKG profile table, a **functional name,
precise business description, entity, type, unit and confidence score (with what is required when low)**,
an **abbreviation glossary**, and a **knowledge graph** (entities as nodes, attributes as leaves,
relationships between entities).

**Outputs:** `output/IKG_Profile_Attribute_Metadata.xlsx` and `output/knowledge_graph/knowledge_graph.html`
(plus a picture per entity, GraphML and Neo4j CSV).

## Agents

| Agent | Understands | Tools |
|---|---|---|
| **Master** | the whole program | runs specialists, quality report, escalation, write outputs (gated) |
| **Skill** | `skills/*.md` (firm knowledge) | list / read / search skills |
| **Data Dictionary** | EDW Data Dictionary, abbreviations | EDW lookup / search / table columns, token usage, repo search |
| **Table Catalog** | Greenplum: `ikg_profile_table_descriptions`, `information_schema`, `ikg_column_lineage_master_auto_refresh`, actual values | catalogue, lineage walk, lineage rows, **read-only value profiling** |
| **Code** | GitLab `ikg-dags` code | read profile SQL, find table writers, read any SQL/Python file, regex search, code lineage |
| **Metadata Author** | all evidence | evidence pack + all of the above on demand |
| **Reviewer** | all evidence | same; verdict correct / revised / insufficient_evidence |
| **Graph** | entities and relationships | relationships + evidence, entity attributes, table entities |

Order of work (enforced): skills → dictionary → catalog + code → author → reviewer → escalation of Low
(max 2 per attribute) → graph → outputs. `agents.orchestration: llm` lets the master agent decide within
these gates; `deterministic` runs the fixed order.

## Accuracy safeguards
* **Grounding:** a skill fact, abbreviation or SQL rule is accepted only if its quote is found verbatim in
  the skill file, EDW dictionary or repository. Otherwise it is rejected and the agent must fix it.
* **Schema validation:** results must use allowed entities and enums, give unique names within a table, and keep
  unresolved abbreviations out of names. Errors are sent back to the agent.
* **Two independent lineages:** the lineage table walked upstream (unqualified columns resolved, PARTITION BY keys
  not followed) plus a parser over all repository SQL, with intermediate filters.
* **Full code reading:** the code agent reads every complete create script and the upstream code. The author and
  reviewer receive the full script with every batch.
* **Real data:** the catalog agent profiles the actual values of flags and codes (read-only template SQL,
  identifiers validated, 60-second timeout).
* **Confidence score:** 0.6 × model rubric + 0.4 × evidence score. The score is capped below High when an abbreviation
  is unresolved, and the `what_is_required` column lists the concrete missing input.
* **Audit:** every agent step and tool call is logged in the `Agent_Trace` sheet. Agent results are cached by
  their inputs, so re-runs are repeatable and only redo work affected by new knowledge.

## Setup
```bash
pip install -r requirements.txt          # optional: Graphviz "dot" for SVG pictures
```
Put **`EDW Data Dictionary.xlsx`** and the **`skills/`** folder next to the notebook. Skill files are markdown
files **directly in `skills/`** (no sub-folders); two examples are included - replace/extend them. Secrets are asked at runtime (hidden) or read from
`IKG_AZURE_OPENAI_API_KEY`, `IKG_GP_PASSWORD`, `IKG_GITLAB_TOKEN`; nothing secret is stored.

## Run
Notebook `IKG_Metadata_Agents.ipynb` (top to bottom), or:
```bash
python run_pipeline.py --check                  # Greenplum, GitLab, Azure OpenAI
python run_pipeline.py --selftest               # full agent system with a scripted offline model (no tokens)
python run_pipeline.py --tables household_art_profile_curr_ikg client_profile_curr_ikg   # pilot
python run_pipeline.py                          # all tables (master agent)
python run_pipeline.py --orchestration deterministic
```

## Performance
* **Streaming per-table pipelines** (`run_table_pipelines`): each table runs profile → code brief → author →
  review → escalation on its own, and all tables run concurrently, so stages overlap; the LLM client caps the real
  number of concurrent Azure calls (`llm.parallel_calls`, default 12).
* **Catalog step without an LLM** (`agents.catalog_agent: profile_only`): value profiles of flag/code columns are
  computed directly and attached as evidence.
* Every agent gets its evidence **prefetched** (dictionary: EDW columns + skill passages per token; catalog:
  catalogue + value profiles; code: first-level upstream scripts; author/reviewer: full evidence pack), so most
  tasks finish in 1-2 model turns; tools are only for gaps. Tool calls issued in one turn run in parallel.
* `llm.parallel_calls` (default 8) concurrent agent tasks; raise to 12-16 if the deployment quota allows
  (429s are retried with back-off). Catalog + code agents for all tables run in a single pool.
* `agents.reasoning_effort` per agent: low for skill / dictionary / catalog / reviewer / graph / master,
  medium for code and author (set author to `low` for ~2x faster, slightly less precise output).
* Cached agent results (`output/cache/llm/agent_*.json`) carry `table_name` / `column_name` on every item.
* Agent results are cached by input (`output/cache`), so interrupted or repeated runs only redo new work.
* A failed or forced submission is accepted with its issues recorded (`_validation_issues`, Agent_Trace)
  instead of losing the batch; invalid evidence is downgraded, never used.

## Azure rate limits (429)
The deployment's tokens-per-minute quota is the real throughput limit. The client adapts to it: on a 429 the
number of concurrent calls is halved and all threads pause for Azure's Retry-After, then the limit grows back
after successes; a rate-limited request is retried for up to `rate_limit_max_wait_seconds` (30 min) so no batch
is dropped. Set `llm.tokens_per_minute` to your quota to pace requests before they hit 429. Author / reviewer
calls carry at most `agents.author_sql_chars` of the table script (the code agent gets the full script once).

## Greenplum tables (core_ikg) and delta mode
| table | content | refresh |
|---|---|---|
| `ikg_attribute_business_description` | the `Metadata` tab (table_name, column_name, business_attribute_name, description, confidence …) | created once (IF NOT EXISTS); each run inserts only NEW (table, column) pairs |
| `ikg_graph_relationship` | entity relationships with evidence | replaced each run |
| `ikg_graph_joining_key` | joining key per relationship (e.g. Client–Household on acc_mhh_n) with the tables that carry it | replaced each run |
| `ikg_metadata_glossary_llm` | abbreviation glossary | replaced each run |
| `<profile_table>_v2` | clone of every profile table without duplicated columns (`Clone_Report` sheet says which) | dropped + re-created each run |

Every table gets `ALTER TABLE … OWNER TO erd_gpdb_prj_ikg` and `GRANT SELECT … TO erd_gpdb_prj_ikg_ro`
(`greenplum.table_owner_role` / `table_reader_role`). `generation.mode: delta` (default) compares the deployed
`%profile_curr_ikg` tables and columns against `ikg_attribute_business_description`: only new tables / columns are
generated and inserted; a column name already published for another table is copied for consistency
(`same_name_policy: always`). The clone script is also written to `output/profile_table_clones.sql.txt`.

## Workbook sheets
Run_Info · **Metadata** (table_name, column_name, business_attribute_name, description, confidence score/band,
entity, attribute type, unit, derivation type, data type, confidence reason, difficult to generate, what is
required, evidence used, verify verdict) · Joining_Keys · Clone_Summary · Clone_Report · Delta_Summary · Attribute_Metadata (all evidence columns) · Needs_Review · Glossary · Glossary_Needs_Input · Table_Summary ·
Entity_Relationships · Skills_Knowledge · Table_Briefs · Value_Profiles · Graph_Review · Agent_Trace

## Correcting a column meaning (example: acc_mhh_n)
State the fact in a skill file in plain prose, e.g. `acc_mhh_n = statement household (sourced from
household_plus), not the marketing household`, or under `column_definitions` in `config/glossary_overrides.yaml`.
The skill agent extracts it (verbatim quote required), it is attached as an AUTHORITATIVE definition to that
column in every profile table, glossary tokens that conflict with it (mhh = "Market Household") are sent back to
the dictionary agent, and the author / reviewer must follow skill definitions and lineage over name expansions.
Then re-run with `generation.only_columns: ["acc_mhh_n", "mhh_*"]` to regenerate only those attributes.

## Improving results
Fill `Glossary_Needs_Input` meanings into a skill file (`abbr = Meaning`) or `config/glossary_overrides.yaml`,
add definitions / code values / table notes to `skills/*.md`, then re-run.

## Folder
```
IKG_Metadata_Agents.ipynb   run_pipeline.py   requirements.txt   README.md
config/   ikg_metadata_config.yaml, entity_model.yaml, glossary_overrides.yaml, business_definitions.md
skills/   example skill files (household definitions, metadata standards)
prompts/agents/   one prompt per agent        prompts/   legacy single-pass prompts
ikgmeta/  sources, sql_parser, code_lineage, lineage, glossary, llm, pipeline (data layer), report,
          knowledge_graph, skills, agents/ (base, context, tools, specialists, master, selftest)
samples/  sample EDW dictionary rows, profile descriptions, lineage rows
```
