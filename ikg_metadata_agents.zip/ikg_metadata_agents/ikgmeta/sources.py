"""
Input sources:
  * GitLab repository code (SQL + Python under dags/ikg) - downloaded once as an archive
  * Greenplum tables: column lineage, profile table descriptions, information_schema
  * EDW Data Dictionary.xlsx
"""
from __future__ import annotations

import io
import logging
import re
import shutil
import time
import zipfile
from pathlib import Path
from collections import defaultdict
from typing import Dict, List, Optional
from urllib.parse import quote, quote_plus

import pandas as pd

from .config import Config, get_secret, ssl_verify

log = logging.getLogger(__name__)


# =============================================================================
# GitLab
# =============================================================================
class GitLabCode:
    """Makes repository code available locally: <cache>/repo[_<name>]/dags/<...>

    One instance per repository (ikg-dags, odm-dags, nlg-dags). `g` is the gitlab block of the config for that
    repository: url, project_path, ref, code_root, ssl_verify, optional local_repo_path / profile_sql_folder."""

    KEEP = (".sql", ".py", ".yaml", ".yml", ".json", ".txt", ".ini", ".md", ".cfg", ".html")

    def __init__(self, cfg_or_block, cache_dir: Path, name: str = "ikg"):
        self.g = cfg_or_block["gitlab"] if "gitlab" in cfg_or_block else cfg_or_block
        self.name = name
        self.cache = Path(cache_dir) / ("repo" if name == "ikg" else f"repo_{name}")

    @property
    def root(self) -> Path:
        if self.g.get("local_repo_path"):
            return Path(self.g["local_repo_path"])
        return self.cache

    def code_root(self) -> Path:
        return self.root / Path(self.g.get("code_root", "dags"))

    def sql_root(self) -> Path:
        if self.name == "ikg":
            return self.root / "dags" / "ikg" / "scripts" / "sql"
        return self.code_root()

    def profile_dir(self) -> Path:
        return self.root / Path(self.g["profile_sql_folder"])

    def python_root(self) -> Path:
        return self.root / "dags" / "ikg" if self.name == "ikg" else self.code_root()

    def _ready(self) -> bool:
        return self.profile_dir().exists() if self.name == "ikg" else self.code_root().exists()

    # -------------------------------------------------------------- download
    def fetch(self, refresh: bool = False) -> Path:
        if self.g.get("local_repo_path"):
            if not self._ready():
                raise FileNotFoundError(f"{self.name}: code folder not found under local_repo_path: {self.code_root()}")
            log.info("%s: using local repository %s", self.name, self.root)
            return self.root
        marker = self.cache / ".ref"
        cached_ref = marker.read_text(encoding="utf-8").strip() if marker.exists() else ""
        hours = float(self.g.get("cache_hours", 24) or 0)
        age_h = (time.time() - marker.stat().st_mtime) / 3600 if marker.exists() else 1e9
        if self._ready() and not refresh and cached_ref == self.g["ref"] and hours > 0 and age_h <= hours:
            log.info("%s: using cached repository code %s @%s (%.1f h old; refresh=True to re-download)", self.name, self.cache, cached_ref, age_h)
            return self.cache
        if self._ready() and cached_ref and cached_ref != self.g["ref"]:
            log.info("%s: cached code is from branch %s, config now says %s - re-downloading", self.name, cached_ref, self.g["ref"])
        import requests
        token = get_secret("gitlab_token")
        verify = ssl_verify(self.g.get("ssl_verify", True))
        base = self.g["url"].rstrip("/") + "/api/v4/projects/" + quote(self.g["project_path"], safe="")
        hdr = {"PRIVATE-TOKEN": token}
        if self.cache.exists():
            shutil.rmtree(self.cache)
        self.cache.mkdir(parents=True)
        try:
            url = f"{base}/repository/archive.zip"
            log.info("%s: downloading %s@%s:%s as archive ...", self.name, self.g["project_path"], self.g["ref"], self.g["code_root"])
            r = requests.get(url, headers=hdr, params={"sha": self.g["ref"], "path": self.g["code_root"]},
                             verify=verify, timeout=900)
            r.raise_for_status()
            self._extract(r.content)
            marker.write_text(self.g["ref"], encoding="utf-8")
        except Exception as e:  # noqa: BLE001
            log.warning("%s: archive download failed (%s) - falling back to file-by-file download", self.name, e)
            self._fetch_files(base, hdr, verify)
            marker.write_text(self.g["ref"], encoding="utf-8")
        n = len(list(self.sql_root().rglob("*.sql"))) if self.sql_root().exists() else 0
        log.info("%s: repository code ready: %d SQL files under %s", self.name, n, self.sql_root())
        if not self._ready():
            raise FileNotFoundError(f"{self.name}: code folder missing after download: {self.code_root()}")
        return self.cache

    def _extract(self, content: bytes) -> None:
        with zipfile.ZipFile(io.BytesIO(content)) as z:
            for m in z.infolist():
                if m.is_dir():
                    continue
                parts = m.filename.split("/", 1)          # strip "<project>-<ref>-<sha>-<path>/" prefix
                if len(parts) < 2:
                    continue
                rel = parts[1]
                if not rel.startswith("dags/"):
                    idx = rel.find("dags/")
                    if idx < 0:
                        continue
                    rel = rel[idx:]
                if not rel.endswith(self.KEEP):
                    continue
                dst = self.cache / rel
                dst.parent.mkdir(parents=True, exist_ok=True)
                dst.write_bytes(z.read(m))

    def _fetch_files(self, base: str, hdr: dict, verify) -> None:
        import requests
        files, page = [], 1
        while True:
            r = requests.get(f"{base}/repository/tree", headers=hdr, verify=verify, timeout=120,
                             params={"path": self.g["code_root"], "ref": self.g["ref"], "recursive": True,
                                     "per_page": 100, "page": page})
            r.raise_for_status()
            items = r.json()
            files += [i["path"] for i in items if i["type"] == "blob" and i["path"].endswith(self.KEEP)]
            nxt = r.headers.get("X-Next-Page")
            if not nxt:
                break
            page = int(nxt)
        log.info("%s: downloading %d files one by one ...", self.name, len(files))
        for i, fp in enumerate(files, 1):
            for attempt in range(3):
                try:
                    r = requests.get(f"{base}/repository/files/{quote(fp, safe='')}/raw", headers=hdr,
                                     params={"ref": self.g["ref"]}, verify=verify, timeout=120)
                    r.raise_for_status()
                    dst = self.cache / fp
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    dst.write_bytes(r.content)
                    break
                except Exception:  # noqa: BLE001
                    time.sleep(2 * (attempt + 1))
            if i % 100 == 0:
                log.info("  %d / %d", i, len(files))

    def web_url(self, rel_path: str) -> str:
        return f"{self.g['url'].rstrip('/')}/{self.g['project_path']}/-/blob/{self.g['ref']}/{rel_path}"

    def rel(self, path) -> str:
        """Path relative to the repository root (as shown to agents: '<name>:dags/...')."""
        try:
            return f"{self.name}:{Path(path).resolve().relative_to(self.root.resolve())}"
        except ValueError:
            return str(path)


# =============================================================================
# Greenplum
# =============================================================================
class Greenplum:
    def __init__(self, cfg: Config):
        self.c = cfg.greenplum
        self._engine = None

    @property
    def engine(self):
        if self._engine is None:
            from sqlalchemy import create_engine
            pwd = quote_plus(get_secret("gp_password"))       # special characters safe
            url = (f"postgresql+psycopg2://{self.c['user']}:{pwd}@{self.c['host']}:{self.c['port']}"
                   f"/{self.c['database']}")
            self._engine = create_engine(url, connect_args={"sslmode": self.c.get("sslmode", "prefer"),
                                                            "connect_timeout": 30})
        return self._engine

    def test(self) -> str:
        from sqlalchemy import text
        with self.engine.connect() as con:
            return con.execute(text("select version()")).scalar()

    def read(self, sql: str, params: Optional[dict] = None) -> pd.DataFrame:
        from sqlalchemy import text
        with self.engine.connect() as con:
            return pd.read_sql_query(text(sql), con, params=params)

    def write(self, df: pd.DataFrame, schema: str, table: str) -> None:
        df.to_sql(table, self.engine, schema=schema, if_exists="replace", index=False, chunksize=2000,
                  method="multi")
        log.info("Wrote %d rows to %s.%s", len(df), schema, table)


LINEAGE_COLS = ["file", "path", "target_table", "target_schema", "process", "sub_target_table",
                "sub_target_schema", "target_column", "source_table", "source_schema", "source_column",
                "logic", "sql_process"]
DESC_COLS = ["table_name", "topic_area", "description", "entity_type", "grain", "primary_key", "join_keys",
             "important_columns", "additional_notes"]


def _norm_frame(df: pd.DataFrame, wanted: List[str]) -> pd.DataFrame:
    df = df.copy()
    df.columns = [str(c).strip().lower() for c in df.columns]
    for c in wanted:
        if c not in df.columns:
            df[c] = ""
    df = df[wanted].fillna("").astype(str)
    for c in df.columns:
        df[c] = df[c].str.strip()
    return df


def load_lineage(cfg: Config, gp: Optional[Greenplum]) -> pd.DataFrame:
    s = cfg.sources
    if s["mode"] == "db":
        log.info("Reading %s ...", s["lineage_table"])
        df = gp.read(f"select {', '.join(LINEAGE_COLS)} from {s['lineage_table']}")
    else:
        p = cfg.path(s["lineage_file"])
        df = pd.read_excel(p, dtype=str) if p.suffix.lower() in (".xlsx", ".xls") else pd.read_csv(p, dtype=str)
    df = _norm_frame(df, LINEAGE_COLS)
    for c in ("target_table", "sub_target_table", "target_column", "source_table", "source_column",
              "source_schema", "target_schema"):
        df[c] = df[c].str.lower().replace({"nan": "", "none": ""})
    log.info("Lineage rows: %d (%d target tables)", len(df), df.target_table.nunique())
    return df


def load_profile_descriptions(cfg: Config, gp: Optional[Greenplum]) -> pd.DataFrame:
    s = cfg.sources
    try:
        if s["mode"] == "db":
            df = gp.read(f"select * from {s['profile_descriptions_table']}")
        else:
            p = cfg.path(s["profile_descriptions_file"])
            df = pd.read_excel(p, dtype=str) if p.suffix.lower() in (".xlsx", ".xls") else pd.read_csv(p, dtype=str)
    except Exception as e:  # noqa: BLE001
        log.warning("Profile table descriptions not available: %s", e)
        return pd.DataFrame(columns=DESC_COLS)
    df = _norm_frame(df, DESC_COLS)
    df["table_name"] = df["table_name"].str.lower()
    df = df.replace({"[NULL]": "", "nan": "", "None": ""})
    log.info("Profile table descriptions: %d", len(df))
    return df.drop_duplicates("table_name", keep="last")


def load_column_types(cfg: Config, gp: Optional[Greenplum], tables: List[str]) -> pd.DataFrame:
    """information_schema data types of the profile tables (authoritative)."""
    cols = ["table_name", "column_name", "data_type", "ordinal_position"]
    try:
        if cfg.sources["mode"] == "db":
            df = gp.read("""select table_name, column_name,
                                   case when data_type in ('character varying','character') and character_maximum_length is not null
                                        then data_type || '(' || character_maximum_length || ')'
                                        when data_type = 'numeric' and numeric_precision is not null
                                        then 'numeric(' || numeric_precision || ',' || coalesce(numeric_scale,0) || ')'
                                        else data_type end as data_type, ordinal_position
                            from information_schema.columns
                            where table_schema = :s and table_name = any(:t)""",
                         {"s": cfg.greenplum["schema"], "t": list(tables)})
        elif cfg.sources.get("column_types_file"):
            df = pd.read_csv(cfg.path(cfg.sources["column_types_file"]), dtype=str)
        else:
            return pd.DataFrame(columns=cols)
    except Exception as e:  # noqa: BLE001
        log.warning("information_schema not available: %s", e)
        return pd.DataFrame(columns=cols)
    df = _norm_frame(df, cols)
    df["table_name"] = df["table_name"].str.lower()
    df["column_name"] = df["column_name"].str.lower()
    return df


def load_column_types_for(cfg: Config, gp: Optional[Greenplum], pairs: List[tuple]) -> pd.DataFrame:
    """information_schema data types for (schema, table) pairs of any schema (ODM / NLG tables)."""
    cols = ["table_schema", "table_name", "column_name", "data_type", "ordinal_position"]
    if not pairs or gp is None:
        return pd.DataFrame(columns=cols)
    frames = []
    by_schema = defaultdict(list)
    for s, t in pairs:
        by_schema[s].append(t)
    for s, ts in by_schema.items():
        try:
            df = gp.read("""select table_schema, table_name, column_name,
                                   case when data_type in ('character varying','character') and character_maximum_length is not null
                                        then data_type || '(' || character_maximum_length || ')'
                                        when data_type = 'numeric' and numeric_precision is not null
                                        then 'numeric(' || numeric_precision || ',' || coalesce(numeric_scale,0) || ')'
                                        else data_type end as data_type, ordinal_position
                            from information_schema.columns
                            where table_schema = :s and table_name = any(:t)""", {"s": s, "t": list(ts)})
            frames.append(_norm_frame(df, cols))
        except Exception as e:  # noqa: BLE001
            log.warning("information_schema not available for %s: %s", s, e)
    if not frames:
        return pd.DataFrame(columns=cols)
    df = pd.concat(frames, ignore_index=True)
    for c in ("table_schema", "table_name", "column_name"):
        df[c] = df[c].str.lower()
    return df


def tables_in_schemas(gp: Optional[Greenplum], schemas: List[str]) -> pd.DataFrame:
    """(table_schema, table_name) of every table / view in the schemas (existence checks for ini keys)."""
    if gp is None or not schemas:
        return pd.DataFrame(columns=["table_schema", "table_name"])
    try:
        df = gp.read("select table_schema, table_name from information_schema.tables where table_schema = any(:s)",
                     {"s": list(schemas)})
    except Exception as e:  # noqa: BLE001
        log.warning("information_schema.tables not available: %s", e)
        return pd.DataFrame(columns=["table_schema", "table_name"])
    df = _norm_frame(df, ["table_schema", "table_name"])
    return df.apply(lambda c: c.str.lower())


def columns_named(gp: Optional[Greenplum], names: List[str], schemas: List[str]) -> pd.DataFrame:
    """Where else a column name exists (upstream hopping across core_ikg / core_nlg / core_wma_shared)."""
    if gp is None or not names or not schemas:
        return pd.DataFrame(columns=["table_schema", "table_name", "column_name", "data_type"])
    try:
        df = gp.read("select table_schema, table_name, column_name, data_type from information_schema.columns "
                     "where table_schema = any(:s) and column_name = any(:c)", {"s": list(schemas), "c": list(names)})
    except Exception as e:  # noqa: BLE001
        log.warning("upstream column lookup failed: %s", e)
        return pd.DataFrame(columns=["table_schema", "table_name", "column_name", "data_type"])
    df = _norm_frame(df, ["table_schema", "table_name", "column_name", "data_type"])
    for c in ("table_schema", "table_name", "column_name"):
        df[c] = df[c].str.lower()
    return df


# =============================================================================
# EDW data dictionary
# =============================================================================
_EDW_HEADER_MAP = {
    "table business name": "table_business_name", "physical table name": "physical_table",
    "table definition": "table_definition", "schema": "schema",
    "business column name": "business_column_name", "column name": "column_name",
    "column definition": "column_definition", "datatype": "datatype", "data type": "datatype",
    "null option": "null_option",
}


def load_edw_dictionary(path: Path) -> pd.DataFrame:
    """Read every sheet that looks like the EDW dictionary layout; tolerant to header spelling."""
    cols = list(dict.fromkeys(_EDW_HEADER_MAP.values()))
    if not Path(path).exists():
        log.warning("EDW data dictionary not found: %s", path)
        return pd.DataFrame(columns=cols)
    frames = []
    for sheet, raw in pd.read_excel(path, sheet_name=None, dtype=str, header=None).items():
        hdr_row = None
        for i in range(min(15, len(raw))):
            vals = [re.sub(r"\s+", " ", str(v)).strip().lower() for v in raw.iloc[i].tolist()]
            if "column name" in vals and ("physical table name" in vals or "column definition" in vals):
                hdr_row = i
                break
        if hdr_row is None:
            continue
        df = raw.iloc[hdr_row + 1:].copy()
        df.columns = [_EDW_HEADER_MAP.get(re.sub(r"\s+", " ", str(v)).strip().lower(), f"x{j}")
                      for j, v in enumerate(raw.iloc[hdr_row].tolist())]
        frames.append(df[[c for c in cols if c in df.columns]])
        log.info("EDW dictionary sheet '%s': %d rows", sheet, len(df))
    if not frames:
        log.warning("No EDW dictionary sheet recognised in %s", path)
        return pd.DataFrame(columns=cols)
    df = pd.concat(frames, ignore_index=True)
    for c in cols:
        if c not in df.columns:
            df[c] = ""
    df = df[cols].fillna("").astype(str)
    for c in cols:
        df[c] = df[c].str.replace(r"\s+", " ", regex=True).str.strip()
    df["physical_table"] = df["physical_table"].str.lower()
    df["column_name"] = df["column_name"].str.lower()
    df = df[df["column_name"].ne("") & df["column_name"].ne("nan")]
    log.info("EDW dictionary: %d column definitions, %d tables", len(df), df.physical_table.nunique())
    return df.drop_duplicates(["physical_table", "column_name"])


def load_business_definitions(cfg: Config) -> str:
    p = cfg.path(cfg.sources["business_definitions"])
    if not p.exists():
        return ""
    txt = p.read_text(encoding="utf-8")
    return re.sub(r"<!--.*?-->", "", txt, flags=re.S).strip()
