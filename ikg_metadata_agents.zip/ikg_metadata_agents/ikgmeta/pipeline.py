"""
IKG profile attribute metadata pipeline.

  step 1  load_sources()     GitLab code, Greenplum lineage + table descriptions + information_schema,
                             EDW data dictionary, business definitions, SME overrides, entity model
  step 2  parse_code()       exact column list / expression / type for every profile table (sqlglot)
  step 3  build_evidence()   per column: lineage (lineage table + code), filters, EDW definitions,
                             python writers, glossary expansion
  step 4  build_glossary()   abbreviations: SME > EDW alignment > code aliases > LLM > NEEDS_INPUT
  step 5  analyze_tables()   LLM reads the COMPLETE create script of each profile table
  step 6  generate()         LLM column metadata (table SQL + analysis as cached prefix)
  step 7  verify()           LLM reviewer re-checks every non-High attribute against evidence
  step 8  score()            composite confidence (LLM rubric + deterministic evidence) + what is required
  step 9  write()            Excel workbook (+ optional Greenplum tables)
"""
from __future__ import annotations

import concurrent.futures as cf
import json
import logging
import re
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd
import yaml

from . import sources as src
from .code_lineage import LineageResolver
from .config import Config, PACKAGE_ROOT
from .glossary import Glossary, tokenize
from .lineage import EdwDictionary, LineageTableWalker, python_writers
from .llm import LLM
from .sql_parser import extract_table_schema

log = logging.getLogger(__name__)
PROMPTS = PACKAGE_ROOT / "prompts"

ATTRIBUTE_TYPES = {"identifier", "foreign_key", "name_text", "date", "amount", "quantity", "count", "percentage",
                   "ratio", "rate", "flag", "code", "category", "score", "rank", "text", "technical"}


def _prompt(name: str) -> str:
    return (PROMPTS / name).read_text(encoding="utf-8")


class MetadataPipeline:
    def __init__(self, cfg: Config, llm: Optional[LLM] = None, gp: Optional[src.Greenplum] = None):
        self.cfg = cfg
        self.out = cfg.path(cfg.output["folder"])
        self.out.mkdir(parents=True, exist_ok=True)
        self.cache = self.out / "cache"
        self.gitlab = src.GitLabCode(cfg, self.cache)
        self.gp = gp if gp is not None else (src.Greenplum(cfg) if cfg.sources["mode"] == "db" else None)
        self.llm = llm
        self.gen = cfg.generation
        self.table_analysis: Dict[str, dict] = {}
        self.results: Optional[pd.DataFrame] = None

    # ------------------------------------------------------------------ step 1
    def load_sources(self, refresh_code: bool = False) -> None:
        self.gitlab.fetch(refresh=refresh_code)
        self.lineage_df = src.load_lineage(self.cfg, self.gp)
        self.descriptions = src.load_profile_descriptions(self.cfg, self.gp)
        self.edw_df = src.load_edw_dictionary(self.cfg.path(self.cfg.sources["edw_data_dictionary"]))
        self.edw = EdwDictionary(self.edw_df)
        self.business_defs = src.load_business_definitions(self.cfg)
        ov = self.cfg.path(self.cfg.sources["glossary_overrides"])
        self.overrides = yaml.safe_load(ov.read_text(encoding="utf-8")) if ov.exists() else {}
        self.skill_column_defs: Dict[str, str] = {str(k).lower(): f"{v} [config/glossary_overrides.yaml]"
                                                  for k, v in ((self.overrides or {}).get("column_definitions") or {}).items()}
        self.entity_model = yaml.safe_load(self.cfg.path(self.cfg.sources["entity_model"]).read_text(encoding="utf-8"))
        log.info("Sources loaded")

    # ------------------------------------------------------------------ step 2
    def parse_code(self) -> pd.DataFrame:
        pdir = self.gitlab.profile_dir()
        files = sorted(pdir.glob("*.sql"))
        wanted = {t.lower() for t in (self.gen.get("profile_tables") or [])}
        if wanted:
            files = [f for f in files if f.stem.lower() in wanted]
        self.schemas = {}
        for f in files:
            ts = extract_table_schema(f)
            self.schemas[ts.table] = ts
            if ts.warnings:
                log.info("%s: %s", ts.table, "; ".join(ts.warnings))
        self.sql_text = {t: Path(s.source_file).read_text(encoding="utf-8", errors="replace")
                         for t, s in self.schemas.items()}
        self.col_types = src.load_column_types(self.cfg, self.gp, list(self.schemas))
        missing = sorted(set(self.descriptions.table_name) - set(self.schemas)) if not wanted else []
        if missing:
            log.warning("Tables in profile descriptions without a create script in %s: %s", pdir, missing)
        log.info("Parsed %d profile tables, %d columns", len(self.schemas),
                 sum(len(s.columns) for s in self.schemas.values()))
        return pd.DataFrame([{"table_name": t, "columns": len(s.columns), "method": s.method,
                              "distribution_key": ",".join(s.distribution_key), "warnings": "; ".join(s.warnings)}
                             for t, s in self.schemas.items()])

    # ------------------------------------------------------------------ helpers
    def table_entity(self, table: str) -> str:
        em = self.entity_model
        if table in (em.get("table_overrides") or {}):
            return em["table_overrides"][table]
        d = self.descriptions[self.descriptions.table_name == table]
        if len(d):
            et = d.iloc[0]["entity_type"].lower()
            # "A x B" = one row per A per B: the attributes describe the finer grain B -> last matching part
            for part in reversed([p.strip() for p in re.split(r"\s+x\s+|/|,", et) if p.strip()]):
                for ent, spec in em["entities"].items():
                    if part == ent.lower() or part in [a.lower() for a in spec.get("aliases", [])]:
                        return ent
        for pre, ent in sorted((em.get("table_prefix_entity") or {}).items(), key=lambda kv: -len(kv[0])):
            if table.startswith(pre):
                return ent
        return ""

    def description_row(self, table: str) -> dict:
        d = self.descriptions[self.descriptions.table_name == table]
        return d.iloc[0].to_dict() if len(d) else {}

    # ------------------------------------------------------------------ step 3
    def build_evidence(self) -> pd.DataFrame:
        log.info("Indexing repository SQL for code lineage ...")
        self.code = LineageResolver(self.gitlab.sql_root(), max_depth=self.gen["lineage_max_depth"],
                                    max_steps=self.gen["lineage_max_steps"])
        walker = LineageTableWalker(self.lineage_df, self.gen["lineage_max_depth"], self.gen["lineage_max_steps"],
                                    code_from_tables=self.code.from_tables)
        edw_pairs = self.edw.pairs()
        types = {(r.table_name, r.column_name): r for r in self.col_types.itertuples(index=False)}
        db_cols = defaultdict(list)
        for r in self.col_types.itertuples(index=False):
            db_cols[r.table_name].append(r)
        technical = set(self.entity_model.get("technical_columns", []))
        code_values = (self.overrides or {}).get("code_values") or {}
        rows, stopped = [], set()
        for table, ts in self.schemas.items():
            code_cols = {c.name: c for c in ts.columns if c.name != "*"}
            names = list(code_cols)
            for r in sorted(db_cols.get(table, []), key=lambda r: int(r.ordinal_position or 0)):
                if r.column_name not in code_cols:
                    names.append(r.column_name)            # deployed but not visible in code (SELECT *)
            tent = self.table_entity(table)
            for i, name in enumerate(names, 1):
                c = code_cols.get(name)
                t = types.get((table, name))
                db = walker.walk(table, name, edw_pairs)
                chain, code_src, _ = self.code.resolve(table, name)
                stopped.update(s.split(".")[0] for s in db.stopped_at)
                terminals = [f"{s}.{t_}.{col}" if s else f"{t_}.{col}" for s, t_, col in db.terminal_sources]
                terminals += [x for x in code_src if x not in terminals]
                defs, qual = [], []
                for term in terminals[:8]:
                    parts = term.split(".")
                    if len(parts) < 2:
                        continue
                    internal = len(parts) >= 3 and "ikg" in parts[0].lower()      # IKG-built table: exact match only
                    d, q = self.edw.describe(parts[-2], parts[-1], exact_only=internal)
                    if d:
                        defs.append(d)
                        qual.append(q)
                for (s_, t_, col) in db.terminal_sources:
                    if not s_.upper().startswith("EDW") and t_.endswith("_ikg"):
                        stopped.add(t_)
                rows.append({
                    "table_name": table, "column_name": name,
                    "ordinal": int(t.ordinal_position) if t is not None and str(t.ordinal_position).isdigit() else i,
                    "data_type": (t.data_type if t is not None else "") or (c.data_type if c else ""),
                    "in_database": t is not None if len(self.col_types) else None,
                    "in_code": c is not None,
                    "sql_expression": c.expression if c else "",
                    "select_alias": (c.select_alias if c and c.select_alias and c.select_alias != name else ""),
                    "lineage_db": db.chain_text(),
                    "lineage_code": "\n".join(s.as_text() for s in chain[1:]),
                    "filters": db.filters_text(),
                    "terminal_sources": "; ".join(terminals[:8]),
                    "source_definitions": "\n".join(defs),
                    "edw_match": "exact" if "exact" in qual else ("column_only" if qual else "none"),
                    "lineage_found": bool(db.found_in_lineage_table),
                    "lineage_reached_source": bool(terminals),
                    "lineage_ambiguous": db.ambiguous,
                    "lineage_stopped_at": "; ".join(db.stopped_at),
                    "code_values": json.dumps(code_values.get(name)) if name in code_values else "",
                    "table_entity": tent,
                    "is_technical": name in technical or name.endswith("_key"),
                    "source_file": Path(ts.source_file).name,
                    "web_url": self.gitlab.web_url(f"{self.cfg.gitlab['profile_sql_folder']}/{Path(ts.source_file).name}"),
                })
        self.ctx = pd.DataFrame(rows)
        # python code that writes tables where SQL lineage stops
        self.py_snippets = python_writers(self.gitlab.python_root(), {s for s in stopped if s})
        self.ctx["python_code"] = self.ctx.lineage_stopped_at.map(
            lambda s: "\n".join(self.py_snippets.get(x.split(".")[0], "")[:2500] for x in s.split("; ") if x)[:3000])
        log.info("Evidence: %d columns | lineage table hit %.0f%% | reached source %.0f%% | EDW definition %.0f%%",
                 len(self.ctx), 100 * self.ctx.lineage_found.mean(), 100 * self.ctx.lineage_reached_source.mean(),
                 100 * self.ctx.edw_match.ne("none").mean())
        return self.ctx

    # ------------------------------------------------------------------ step 4
    def build_glossary(self, use_llm: bool = True) -> pd.DataFrame:
        usage = defaultdict(list)
        for t, c in self.ctx[["table_name", "column_name"]].itertuples(index=False):
            for tok in dict.fromkeys(tokenize(c)):
                usage[tok].append(f"{t}.{c}")
        # also upstream / EDW column names contribute evidence via the EDW dictionary itself
        pairs = [(c.name, c.select_alias) for s in self.schemas.values() for c in s.columns]
        cat_text = " ".join(self.descriptions[["description", "additional_notes", "grain"]].astype(str)
                            .agg(" ".join, axis=1).tolist()) + " " + self.business_defs
        self.glossary = Glossary(self.overrides, self.edw_df, pairs, cat_text)
        self.glossary.build(usage)
        if use_llm and self.llm is not None:
            ctx_for = {}
            for tok in self.glossary.unresolved():
                ex = [u for u in usage[tok][:4]]
                bits = []
                for u in ex:
                    t, c = u.split(".", 1)
                    r = self.ctx[(self.ctx.table_name == t) & (self.ctx.column_name == c)]
                    if len(r):
                        r = r.iloc[0]
                        bits.append(f"{u} = {r.sql_expression[:150]} | src: {r.terminal_sources[:150]} | "
                                    f"{r.source_definitions[:200]}")
                ctx_for[tok] = " || ".join(bits)
            self.glossary.resolve_with_llm(self.llm, _prompt("glossary_prompt.txt"), ctx_for, self.business_defs)
        exp_unres = self.ctx.column_name.map(self.glossary.expand)
        self.ctx["abbreviations"] = exp_unres.map(lambda x: x[0])
        self.ctx["unresolved_tokens"] = exp_unres.map(lambda x: ", ".join(x[1]))
        g = self.glossary.frame()
        log.info("Glossary: %d tokens, %d abbreviations, %d need input", len(g), int(g.is_abbreviation.sum()),
                 int((g.status != "RESOLVED").sum()))
        return g

    # ------------------------------------------------------------------ prompts
    def _system(self, name: str) -> str:
        ents = "\n".join(f"- {k}: {v.get('description', '')}" for k, v in self.entity_model["entities"].items())
        return (f"{_prompt(name)}\n\nALLOWED ENTITIES:\n{ents}\n\nFIRM BUSINESS DEFINITIONS:\n"
                f"{self.business_defs or '(none supplied)'}")

    def _table_prefix(self, table: str, with_analysis: bool = True, max_chars: Optional[int] = None) -> str:
        desc = {k: v for k, v in self.description_row(table).items() if v and k != "table_name"}
        sql = self.sql_text.get(table, "")
        cap = int(max_chars if max_chars is not None else self.gen["max_sql_chars"])
        if len(sql) > cap:
            sql = (sql[:cap] + f"\n-- [script truncated at {cap} of {len(sql)} characters - the column SQL "
                   "expressions and lineage are in the evidence; use read_profile_sql(table, start_line, end_line) "
                   "to read any other part]")
        parts = [f"PROFILE TABLE: {table}", f"PRIMARY ENTITY (catalogue / model): {self.table_entity(table)}",
                 "CATALOGUE DESCRIPTION (core_ikg.ikg_profile_table_descriptions):",
                 json.dumps(desc, ensure_ascii=False, indent=1) if desc else "(none)"]
        if with_analysis and table in self.table_analysis:
            parts += ["ANALYSIS OF THE TABLE CODE:", json.dumps(self.table_analysis[table], ensure_ascii=False, indent=1)]
        if self.gen.get("include_full_profile_sql", True):
            parts += [f"COMPLETE CREATE SCRIPT ({self.schemas[table].source_file.split('/')[-1]}):", sql]
        return "\n\n".join(parts)

    def _column_payload(self, rows: pd.DataFrame, extra: Optional[Dict[str, dict]] = None) -> str:
        cols = []
        for i, r in enumerate(rows.itertuples(index=False), 1):
            item = {"id": f"c{i:03d}", "column": r.column_name, "data_type": r.data_type,
                    "sql_expression": r.sql_expression or "(not visible in code - column comes from SELECT *)"}
            for k in ("select_alias", "lineage_db", "lineage_code", "filters", "source_definitions",
                      "abbreviations", "code_values", "python_code"):
                v = getattr(r, k)
                if v:
                    item[k] = v
            if r.unresolved_tokens:
                item["unresolved_abbreviations"] = r.unresolved_tokens
            if extra and r.column_name in extra:
                item["draft"] = extra[r.column_name]
            cols.append(item)
        rel = {t: self.glossary.entries[t]["full_form"] for c in rows.column_name for t in tokenize(c)
               if t in self.glossary.entries and self.glossary.entries[t]["status"] == "RESOLVED"
               and self.glossary.entries[t]["is_abbreviation"]}
        return json.dumps({"glossary_for_these_columns": rel, "columns": cols}, ensure_ascii=False)

    def _batches(self):
        n = int(self.gen["columns_per_call"])
        for t, g in self.ctx.sort_values(["table_name", "ordinal"]).groupby("table_name", sort=True):
            for i in range(0, len(g), n):
                yield t, g.iloc[i:i + n]

    # ------------------------------------------------------------------ step 5
    def analyze_tables(self) -> pd.DataFrame:
        sysp = self._system("table_analysis_prompt.txt")

        def run(t):
            return t, self.llm.json_call(sysp, "Analyse this table.", prefix=self._table_prefix(t, False),
                                         cache_key=("table_analysis", t))
        with cf.ThreadPoolExecutor(int(self.cfg.llm["parallel_calls"])) as ex:
            for fut in cf.as_completed([ex.submit(run, t) for t in self.schemas]):
                try:
                    t, a = fut.result()
                    self.table_analysis[t] = a
                except Exception as e:  # noqa: BLE001
                    log.error("table analysis failed: %s", e)
        log.info("Table analysis done for %d tables", len(self.table_analysis))
        return pd.DataFrame([{"table_name": t, **{k: (json.dumps(v, ensure_ascii=False) if isinstance(v, (list, dict)) else v)
                                                   for k, v in a.items()}} for t, a in self.table_analysis.items()])

    # ------------------------------------------------------------------ step 6
    def generate(self) -> pd.DataFrame:
        sysp = self._system("column_metadata_prompt.txt")
        allowed = set(self.entity_model["entities"])
        out, failed = [], []

        def run(tb):
            t, rows = tb
            data = self.llm.json_call(sysp, self._column_payload(rows), prefix=self._table_prefix(t),
                                      cache_key=("columns", t))
            return self._map(rows, data.get("columns", []), allowed)

        batches = list(self._batches())
        log.info("Generating metadata: %d LLM calls", len(batches))
        with cf.ThreadPoolExecutor(int(self.cfg.llm["parallel_calls"])) as ex:
            futs = {ex.submit(run, b): b[0] for b in batches}
            for i, fut in enumerate(cf.as_completed(futs), 1):
                try:
                    out.extend(fut.result())
                except Exception as e:  # noqa: BLE001
                    failed.append(futs[fut])
                    log.error("batch failed for %s: %s", futs[fut], e)
                if i % 20 == 0:
                    log.info("  %d / %d batches", i, len(batches))
        if failed:
            log.error("Failed batches (re-run generate(); cached batches are skipped): %s", sorted(set(failed)))
        gen = pd.DataFrame(out)
        self.results = self.ctx.merge(gen, on=["table_name", "column_name"], how="left")
        return self.results

    @staticmethod
    def _map(rows: pd.DataFrame, items: list, allowed: set) -> List[dict]:
        by_id = {str(x.get("id")): x for x in items if isinstance(x, dict)}
        res = []
        for i, r in enumerate(rows.itertuples(index=False), 1):
            x = by_id.get(f"c{i:03d}", {})
            ent = x.get("entity", "")
            res.append({
                "table_name": r.table_name, "column_name": r.column_name,
                "functional_name": (x.get("functional_name") or "").strip(),
                "business_description": (x.get("business_description") or "").strip(),
                "entity": ent if ent in allowed else (r.table_entity or ent),
                "entity_llm_raw": ent,
                "attribute_type": x.get("attribute_type", "") if x.get("attribute_type") in ATTRIBUTE_TYPES else x.get("attribute_type", ""),
                "derivation_type": x.get("derivation_type", ""),
                "unit": x.get("unit", ""),
                "llm_confidence": _int(x.get("llm_confidence"), 0),
                "confidence_reason": x.get("confidence_reason", "") if x else "LLM returned no result",
                "difficult_to_generate": bool(x.get("difficult_to_generate", not x)),
                "what_is_required_llm": x.get("what_is_required", "") or "",
                "unresolved_abbreviations_llm": ", ".join(x.get("unresolved_abbreviations") or []),
                "verify_verdict": "", "verify_issues": "",
            })
        return res

    # ------------------------------------------------------------------ step 7
    def verify(self, only_below_band: str = "High") -> pd.DataFrame:
        if self.results is None:
            raise RuntimeError("run generate() first")
        self.score()
        todo = self.results[self.results.confidence_band != only_below_band] if only_below_band else self.results
        if todo.empty:
            return self.results
        sysp = self._system("verify_prompt.txt")
        n = int(self.gen["columns_per_call"])
        tasks = []
        for t, g in todo.groupby("table_name"):
            for i in range(0, len(g), n):
                tasks.append((t, g.iloc[i:i + n]))
        log.info("Verification pass: %d attributes in %d calls", len(todo), len(tasks))

        def run(tb):
            t, rows = tb
            drafts = {r.column_name: {"functional_name": r.functional_name, "business_description": r.business_description,
                                      "llm_confidence": r.llm_confidence, "what_is_required": r.what_is_required_llm}
                      for r in rows.itertuples(index=False)}
            ctx_rows = self.ctx.set_index(["table_name", "column_name"]).loc[[(t, c) for c in rows.column_name]].reset_index()
            data = self.llm.json_call(sysp, self._column_payload(ctx_rows, drafts), prefix=self._table_prefix(t),
                                      cache_key=("verify", t))
            by_id = {str(x.get("id")): x for x in data.get("columns", [])}
            return [(t, c, by_id.get(f"c{i:03d}")) for i, c in enumerate(rows.column_name, 1)]

        idx = {(r.table_name, r.column_name): i for i, r in enumerate(self.results.itertuples(index=False))}
        with cf.ThreadPoolExecutor(int(self.cfg.llm["parallel_calls"])) as ex:
            for fut in cf.as_completed([ex.submit(run, tb) for tb in tasks]):
                try:
                    for t, c, x in fut.result():
                        if not x:
                            continue
                        i = self.results.index[idx[(t, c)]]
                        self.results.at[i, "verify_verdict"] = x.get("verdict", "")
                        self.results.at[i, "verify_issues"] = x.get("issues", "")
                        if x.get("functional_name"):
                            self.results.at[i, "functional_name"] = x["functional_name"].strip()
                        if x.get("business_description"):
                            self.results.at[i, "business_description"] = x["business_description"].strip()
                        if x.get("llm_confidence") is not None:
                            self.results.at[i, "llm_confidence"] = _int(x["llm_confidence"], 0)
                        if x.get("what_is_required"):
                            self.results.at[i, "what_is_required_llm"] = x["what_is_required"]
                        if x.get("verdict") == "insufficient_evidence":
                            self.results.at[i, "difficult_to_generate"] = True
                except Exception as e:  # noqa: BLE001
                    log.error("verify batch failed: %s", e)
        return self.results

    # ------------------------------------------------------------------ step 8
    def score(self) -> pd.DataFrame:
        self.results = self.score_df(self.results)
        return self.results

    def score_df(self, r: pd.DataFrame) -> pd.DataFrame:
        """Composite confidence for any frame with the evidence + agent columns (thread-safe, no state)."""
        r = r.copy()
        bands = self.gen["confidence_bands"]
        ev, gaps = [], []
        for x in r.itertuples(index=False):
            s, g = 0, []
            if x.sql_expression:
                s += 15
            else:
                g.append("column not visible in the create script (SELECT *) - expression unknown")
            if x.lineage_reached_source:
                s += 25
            elif x.lineage_db or x.lineage_code:
                s += 12
                g.append("lineage incomplete" + (f" - no SQL lineage for {x.lineage_stopped_at}" if x.lineage_stopped_at else ""))
            elif not x.is_technical:
                g.append("no lineage found in ikg_column_lineage_master_auto_refresh or code")
            if x.edw_match == "exact":
                s += 20
            elif x.edw_match == "column_only":
                s += 10
                g.append("EDW definition matched by column name only - confirm source table")
            elif x.lineage_reached_source and not x.is_technical:
                g.append(f"no EDW data dictionary definition for source column(s): {str(x.terminal_sources)[:200]}")
            unres = [t for t in str(x.unresolved_tokens or "").split(", ") if t]
            s += max(0, 20 - 7 * len(unres))
            if unres:
                g.append(f"meaning of abbreviation(s): {', '.join(unres)} (fill config/glossary_overrides.yaml)")
            if x.data_type:
                s += 5
            if self.description_row(x.table_name):
                s += 15
            if x.lineage_ambiguous:
                g.append("lineage ambiguous (unqualified column in multi-table query)")
            used = str(getattr(x, "evidence_used", "") or "")
            if "value_profile" in used:
                s += 5                       # agent verified meaning against actual values
            if "skill_file" in used:
                s += 5                       # firm documentation used
            if x.is_technical:
                s = max(s, 80)
            ev.append(min(100, s))
            gaps.append(g)
        r["evidence_score"] = ev
        llm_c = pd.to_numeric(r.get("llm_confidence", 0), errors="coerce").fillna(0)
        score = (0.6 * llm_c + 0.4 * r["evidence_score"]).round()
        has_unres = r["unresolved_tokens"].fillna("").ne("") | r.get("unresolved_abbreviations_llm", "").fillna("").ne("")
        score = score.where(~has_unres, score.clip(upper=bands["high"] - 1))
        no_basis = r["sql_expression"].eq("") & r["lineage_db"].eq("") & r["lineage_code"].eq("") & ~r["is_technical"]
        score = score.where(~no_basis, score.clip(upper=bands["medium"] - 10))
        empty = r["functional_name"].fillna("").eq("") | r["business_description"].fillna("").eq("")
        score = score.where(~empty, 0)
        r["confidence_score"] = score.astype(int)
        r["confidence_band"] = pd.cut(r["confidence_score"], [-1, bands["medium"] - 1, bands["high"] - 1, 101],
                                      labels=["Low", "Medium", "High"]).astype(str)
        dup = r.duplicated(["table_name", "functional_name"], keep=False) & r["functional_name"].fillna("").ne("")
        r["difficult_to_generate"] = r["difficult_to_generate"].fillna(True).astype(bool) | empty
        req = []
        for x, g, d in zip(r.itertuples(index=False), gaps, dup):
            items = []
            if getattr(x, "what_is_required_llm", ""):
                items.append(str(x.what_is_required_llm))
            if x.confidence_band != "High":
                items += [i for i in g if i not in items]
            if d:
                items.append("functional name duplicated within table - disambiguate")
            req.append(" | ".join(items))
        r["what_is_required"] = req
        r["needs_review"] = r["confidence_band"].ne("High") | r["difficult_to_generate"] | dup
        return r

    # ------------------------------------------------------------------ dry run
    def preview_prompts(self, path: Optional[Path] = None) -> Path:
        path = path or self.out / "prompts_preview.jsonl"
        sysp = self._system("column_metadata_prompt.txt")
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(json.dumps({"system": sysp}, ensure_ascii=False) + "\n")
            for t, rows in self._batches():
                fh.write(json.dumps({"table": t, "prefix_chars": len(self._table_prefix(t)),
                                     "user": json.loads(self._column_payload(rows))}, ensure_ascii=False) + "\n")
        n = sum(1 for _ in self._batches())
        log.info("Prompt preview: %d column calls (+%d table analyses, + verification) -> %s", n, len(self.schemas), path)
        return path

    def estimate_tokens(self) -> dict:
        pre = {t: len(self._table_prefix(t)) // 4 for t in self.schemas}
        calls = list(self._batches())
        inp = sum(pre[t] + len(self._column_payload(r)) // 4 + 3000 for t, r in calls) + sum(pre.values())
        return {"table_analysis_calls": len(self.schemas), "column_calls": len(calls),
                "approx_input_tokens": inp, "approx_output_tokens": len(self.ctx) * 450}

    # ------------------------------------------------------------------ step 9
    def write(self, relationships: Optional[pd.DataFrame] = None, agent_ctx=None) -> Path:
        from .report import write_workbook
        path = self.out / self.cfg.output["metadata_xlsx"]
        tbl = self.table_summary()
        extra = agent_sheets(agent_ctx) if agent_ctx is not None else {}
        info = self.run_info()
        if agent_ctx is not None:
            info["orchestration"] = self.cfg.get("agents", {}).get("orchestration", "llm")
            info["skill_files"] = ", ".join(agent_ctx.skills.files) or "(none)"
            info["agent_tool_calls"] = sum(1 for r in agent_ctx.trace.rows if r["kind"] == "tool")
        write_workbook(path, self.results, self.glossary.frame(), tbl, relationships, info, extra)
        if self.cfg.output.get("write_to_greenplum") and self.gp is not None:
            sch = self.cfg.output["target_schema"]
            cols = [c for c in REPORT_DB_COLUMNS if c in self.results.columns]
            self.gp.write(self.results[cols].astype(str), sch, self.cfg.output["metadata_table"])
            self.gp.write(self.glossary.frame().astype(str), sch, self.cfg.output["glossary_table"])
        log.info("Metadata workbook: %s", path)
        return path

    def table_summary(self) -> pd.DataFrame:
        rows = []
        r = self.results
        for t, s in self.schemas.items():
            g = r[r.table_name == t]
            a = self.table_analysis.get(t, {})
            d = self.description_row(t)
            rows.append({
                "table_name": t, "entity": self.table_entity(t), "topic_area": d.get("topic_area", ""),
                "catalogue_description": d.get("description", ""), "grain (catalogue)": d.get("grain", ""),
                "table_purpose (LLM)": a.get("table_purpose", ""), "grain (LLM from code)": a.get("grain", ""),
                "population (LLM)": a.get("population", ""),
                "key_business_rules (LLM)": "\n".join(a.get("key_business_rules", []) or []),
                "caveats (LLM)": "\n".join(a.get("caveats", []) or []),
                "columns": len(g), "high": int((g.confidence_band == "High").sum()),
                "medium": int((g.confidence_band == "Medium").sum()), "low": int((g.confidence_band == "Low").sum()),
                "avg_confidence": round(float(g.confidence_score.mean()), 1) if len(g) else None,
                "parse_method": s.method, "distribution_key": ",".join(s.distribution_key),
                "parse_warnings": "; ".join(s.warnings), "source_file": Path(s.source_file).name,
            })
        return pd.DataFrame(rows)

    def run_info(self) -> dict:
        u = self.llm.usage if self.llm else {}
        return {"run_timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "model": f"{self.cfg.llm['model_name']} (deployment {self.cfg.llm['deployment']}, api {self.cfg.llm['api_version']})",
                "gitlab": f"{self.cfg.gitlab['project_path']}@{self.cfg.gitlab['ref']}",
                "lineage_source": self.cfg.sources["lineage_table"] if self.cfg.sources["mode"] == "db" else self.cfg.sources["lineage_file"],
                "profile_descriptions": self.cfg.sources["profile_descriptions_table"],
                "edw_dictionary": f"{self.cfg.sources['edw_data_dictionary']} ({len(self.edw_df)} column definitions)",
                "profile_tables": len(self.schemas), "attributes": len(self.results) if self.results is not None else 0,
                "llm_calls": u.get("calls"), "llm_cache_hits": u.get("cache_hits"),
                "prompt_tokens": u.get("prompt_tokens"), "completion_tokens": u.get("completion_tokens"),
                "cached_prompt_tokens": u.get("cached_tokens"),
                "confidence_formula": "0.6 x LLM rubric confidence + 0.4 x evidence score; capped below High when an "
                                      "abbreviation is unresolved; capped Low when no code/lineage evidence",
                "evidence_score": "expression in code 15 + lineage to source 25 (partial 12) + EDW definition 20 "
                                  "(column-only 10) + abbreviations resolved 20 (-7 each unresolved) + data type 5 + "
                                  "table catalogue description 15"}

    # ------------------------------------------------------------------ agent integration
    def apply_skill_knowledge(self, brief: dict) -> None:
        """Verified skill-file knowledge -> glossary (abbreviations, code values). SME overrides still win."""
        n = 0
        for a in brief.get("abbreviations", []):
            t = str(a.get("abbreviation", "")).lower().strip()
            e = self.glossary.entries.get(t)
            if not t or not a.get("full_form") or (e and e["source"] == "SME override"):
                continue
            if e is None:
                e = {"abbreviation": t, "occurrences": 0, "example_columns": "", "evidence": ""}
                self.glossary.entries[t] = e
            e.update(full_form=a["full_form"], is_abbreviation=True, status="RESOLVED", confidence=97,
                     source=f"skill file ({a['source_file']})", evidence=f"skill quote: {a.get('quote', '')[:150]}")
            n += 1
        for cv in brief.get("code_values", []):
            col = str(cv.get("column", "")).lower()
            self.glossary.code_values.setdefault(col, {})[str(cv.get("code"))] = cv.get("meaning")
        # authoritative column definitions: SME overrides + skill files
        for cd in brief.get("column_definitions", []):
            col = str(cd.get("column", "")).lower()
            if col and cd.get("definition"):
                self.skill_column_defs[col] = f"{cd['definition']} [{cd.get('source_file', 'skill')}]"
        # tokens resolved from EDW / code aliases that occur in a skill-defined column are re-checked by the
        # dictionary agent against that definition (e.g. mhh in acc_mhh_n)
        rechecked = 0
        for col, definition in self.skill_column_defs.items():
            for tok in tokenize(col):
                e = self.glossary.entries.get(tok)
                if not e or not e.get("is_abbreviation") or e["source"] in ("SME override",) or "skill" in e["source"]:
                    continue
                if e["status"] == "RESOLVED" and e["full_form"].lower() not in definition.lower():
                    e.update(status="RECHECK", full_form="", confidence=0,
                             recheck_reason=f"earlier guess '{e['full_form']}' ({e['source']}) is not consistent with the "
                                            f"skill definition of {col}: {definition[:200]}")
                    rechecked += 1
        if rechecked:
            log.info("Glossary: %d token(s) sent back for re-check against skill column definitions", rechecked)
        self.refresh_glossary_columns()
        log.info("Skill knowledge applied: %d abbreviations, %d code values", n, len(brief.get("code_values", [])))

    def refresh_glossary_columns(self) -> None:
        exp_unres = self.ctx.column_name.map(self.glossary.expand)
        self.ctx["abbreviations"] = exp_unres.map(lambda x: x[0])
        self.ctx["unresolved_tokens"] = exp_unres.map(lambda x: ", ".join(x[1]))
        self.ctx["skill_definition"] = self.ctx.column_name.map(lambda c: self.skill_column_defs.get(c, ""))
        cv = self.glossary.code_values
        self.ctx["code_values"] = self.ctx.column_name.map(lambda c: json.dumps(cv[c]) if c in cv else "")

    def results_from_agents(self, results: Dict) -> None:
        self.results = self.frame_from_agents(results) if results else None

    def frame_from_agents(self, results: Dict, table: Optional[str] = None) -> pd.DataFrame:
        rows = [v for (t, _), v in results.items() if table is None or t == table]
        ctx = self.ctx if table is None else self.ctx[self.ctx.table_name == table]
        gen = pd.DataFrame(rows) if rows else pd.DataFrame(columns=["table_name", "column_name"])
        df = ctx.merge(gen, on=["table_name", "column_name"], how="left")
        for c, d in (("functional_name", ""), ("business_description", ""), ("llm_confidence", 0),
                     ("difficult_to_generate", True), ("what_is_required_llm", ""), ("verify_verdict", ""),
                     ("unresolved_abbreviations_llm", ""), ("evidence_used", "")):
            if c not in df:
                df[c] = d
            df[c] = df[c].fillna(d)
        return df

    # ------------------------------------------------------------------ all
    def run_all(self, use_llm: bool = True) -> Path:
        self.load_sources()
        self.parse_code()
        self.build_evidence()
        self.build_glossary(use_llm=use_llm)
        if not use_llm:
            self.preview_prompts()
            return self.out
        self.analyze_tables()
        self.generate()
        self.score()
        if self.gen.get("verify_pass", True):
            self.verify()
            self.score()
        from .knowledge_graph import KnowledgeGraph
        kg = KnowledgeGraph(self.cfg, self)
        kg.build()
        path = self.write(kg.relationships_frame())
        kg.export()
        return path


def agent_sheets(ctx) -> Dict[str, pd.DataFrame]:
    sb = ctx.skills_brief or {}
    rows = []
    for k in ("definitions", "abbreviations", "entity_definitions", "relationship_rules", "authoring_rules",
              "code_values", "table_notes"):
        for it in sb.get(k, []):
            rows.append({"kind": k, "item": " | ".join(str(it.get(x, "")) for x in it if x not in ("quote", "source_file")),
                         "source_file": it.get("source_file", ""), "quote": it.get("quote", "")})
    briefs = []
    for t, b in ctx.table_briefs.items():
        briefs.append({"table_name": t, "table_purpose": b.get("table_purpose", ""), "grain": b.get("grain", ""),
                       "population": b.get("population", ""),
                       "key_business_rules": "\n".join(f"- {x['rule']}  [SQL: {x['sql_quote'][:120]}]" for x in b.get("key_business_rules", [])),
                       "time_windows": "\n".join(f"{x['token']}: {x['meaning']}" for x in b.get("time_windows", [])),
                       "data_sources": "\n".join(b.get("data_sources", [])), "caveats": "\n".join(b.get("caveats", [])),
                       "catalog_notes": (ctx.catalog_notes.get(t) or {}).get("notes", ""),
                       "catalog_quality_flags": "\n".join((ctx.catalog_notes.get(t) or {}).get("data_quality_flags", []))})
    vp = [{"table_name": t, "column_name": c, "value_profile": v} for (t, c), v in ctx.value_profiles.items()]
    gr = ctx.graph_review or {}
    return {"Skills_Knowledge": pd.DataFrame(rows), "Table_Briefs": pd.DataFrame(briefs),
            "Value_Profiles": pd.DataFrame(vp),
            "Graph_Review": pd.DataFrame(gr.get("relationship_changes", [])),
            "Agent_Trace": pd.DataFrame(ctx.trace.rows)}


REPORT_DB_COLUMNS = ["table_name", "column_name", "ordinal", "entity", "functional_name", "business_description",
                     "attribute_type", "derivation_type", "unit", "data_type", "confidence_score", "confidence_band",
                     "needs_review", "difficult_to_generate", "what_is_required", "confidence_reason",
                     "verify_verdict", "terminal_sources", "source_definitions", "sql_expression"]


def _int(v, default=0) -> int:
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return default
