"""Agent-based IKG metadata + knowledge graph generation."""
from __future__ import annotations

import logging

from ..pipeline import MetadataPipeline
from .context import AgentContext
from .master import MasterAgent, Orchestrator

log = logging.getLogger(__name__)


def prepare(cfg, llm, gp=None, refresh_code: bool = False):
    """Deterministic data layer every agent works on: sources, parsed code, evidence, base glossary."""
    p = MetadataPipeline(cfg, llm=None, gp=gp)
    p.load_sources(refresh_code=refresh_code)
    p.parse_code()
    p.build_evidence()
    p.build_glossary(use_llm=False)          # EDW / code / skill evidence first; agents resolve the rest
    p.active_tables = sorted(p.schemas)
    p.prefilled = {}
    p.delta_info = {"mode": "full"}
    if gp is not None and cfg.output.get("load_to_greenplum", False) and str(cfg.generation.get("mode", "delta")) == "delta":
        from ..db_sync import GreenplumSync
        try:
            p.restrict_to_delta(GreenplumSync(gp, cfg))
        except Exception as e:  # noqa: BLE001
            log.warning("delta comparison against Greenplum failed (%s) - running in full mode", e)
    ctx = AgentContext(cfg, llm, p)
    log.info("Agent context ready: %d tables, %d attributes, %d skill files", len(p.schemas), len(p.ctx),
             len(ctx.skills.files))
    return ctx


def run(ctx: AgentContext, mode: str = None) -> dict:
    mode = mode or ctx.cfg.get("agents", {}).get("orchestration", "llm")
    orch = Orchestrator(ctx)
    if mode == "deterministic":
        out = orch.run_deterministic(int(ctx.cfg.get("agents", {}).get("escalation_rounds", 1)))
    else:
        summary = MasterAgent(ctx, orch).execute()
        out = {"master_summary": summary, **({"workbook": str(ctx.p.out / ctx.cfg.output["metadata_xlsx"])})}
        if not ctx.stage_done.get("outputs"):
            log.warning("master agent finished without writing outputs - completing deterministically")
            out.update(orch.stage_outputs())
    out["quality"] = orch.quality()
    return out
