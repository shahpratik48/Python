"""
Tools available to the agents. All are deterministic Python over the real sources:
GitLab code (downloaded), skill files, EDW dictionary, Greenplum tables (lineage, catalogue,
information_schema, read-only value profiling) and the knowledge graph.
"""
from __future__ import annotations

import fnmatch
import re
from pathlib import Path
from typing import List

import pandas as pd

from ..glossary import tokenize
from .base import B, I, S, Tool, arr, obj

MAX_LINES = 400


def _numbered(text: str, start: int = 1, end: int = 0) -> str:
    lines = text.splitlines()
    end = end or min(len(lines), start + MAX_LINES - 1)
    end = min(end, len(lines), start + MAX_LINES - 1)
    body = "\n".join(f"{i:5d}| {lines[i - 1]}" for i in range(max(1, start), end + 1))
    more = f"\n... ({len(lines) - end} more lines - call again with start_line={end + 1})" if end < len(lines) else ""
    return f"[lines {start}-{end} of {len(lines)}]\n{body}{more}"


# =============================================================================
# skill tools
# =============================================================================
def skill_tools(ctx) -> List[Tool]:
    lib = ctx.skills
    return [
        Tool("list_skills", "List all skill files (name, description, sections).", obj({}), lambda: lib.list()),
        Tool("read_skill", "Read a skill file, optionally only sections whose heading contains `section`.",
             obj({"file": S, "section": S}, ["file"]), lambda file, section="": lib.read(file, section)),
        Tool("search_skills", "Keyword search across all skill sections; returns the best matching sections.",
             obj({"query": S}), lambda query: lib.search(query)),
    ]


# =============================================================================
# code tools (GitLab repository)
# =============================================================================
def code_tools(ctx) -> List[Tool]:
    p = ctx.p
    root = p.gitlab.root

    def read_profile_sql(table: str, start_line: int = 1, end_line: int = 0):
        t = table.lower()
        if t not in p.sql_text:
            return f"ERROR: {t} is not a profile table in scope. Tables: {sorted(p.sql_text)[:60]}"
        return _numbered(p.sql_text[t], start_line, end_line)

    def list_profile_columns(table: str):
        t = table.lower()
        s = p.schemas.get(t)
        if not s:
            return f"ERROR: unknown table {t}"
        return [{"ordinal": c.ordinal, "column": c.name, "type": c.data_type, "expression": c.expression[:160],
                 **({"select_alias": c.select_alias} if c.select_alias and c.select_alias != c.name else {})}
                for c in s.columns]

    def find_table_writers(table: str):
        t = table.lower().split(".")[-1]
        ws = p.code.writers.get(t, [])
        hits = [{"file": str(Path(w.file).relative_to(root)) if str(w.file).startswith(str(root)) else w.file,
                 "temp_table": w.temp} for w in ws]
        if not hits:
            py = p.py_snippets.get(t) if hasattr(p, "py_snippets") else None
            return {"sql_writers": [], "note": "no SQL script writes this table (EDW/vendor source or built in Python)",
                    "python_snippet": (py or "")[:2500]}
        return {"sql_writers": hits}

    def read_sql_file(path: str, start_line: int = 1, end_line: int = 0):
        f = (root / path) if not Path(path).is_absolute() else Path(path)
        try:
            f.resolve().relative_to(Path(root).resolve())
        except ValueError:
            return "ERROR: path outside repository"
        if not f.exists():
            hits = list(Path(root).rglob(Path(path).name))
            if not hits:
                return f"ERROR: file not found: {path}"
            f = hits[0]
        return _numbered(f.read_text(encoding="utf-8", errors="replace"), start_line, end_line)

    def search_repo(pattern: str, file_glob: str = "*.sql", max_hits: int = 30):
        try:
            rx = re.compile(pattern, re.I)
        except re.error as e:
            return f"ERROR: bad regex: {e}"
        hits = []
        for f in Path(root).rglob("*"):
            if not f.is_file() or not fnmatch.fnmatch(f.name, file_glob):
                continue
            for i, line in enumerate(f.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
                if rx.search(line):
                    hits.append({"file": str(f.relative_to(root)), "line": i, "text": line.strip()[:200]})
                    if len(hits) >= max_hits:
                        return hits
        return hits

    def get_code_lineage(table: str, column: str):
        chain, srcs, where = p.code.resolve(table.lower(), column.lower())
        return {"chain": [s.as_text() for s in chain], "sources": srcs, "profile_where": where}

    return [
        Tool("read_profile_sql", "Read the create script of a profile table with line numbers (paged, 400 lines).",
             obj({"table": S, "start_line": I, "end_line": I}, ["table"]), read_profile_sql),
        Tool("list_profile_columns", "All columns of a profile table with type and populating SQL expression.",
             obj({"table": S}), list_profile_columns),
        Tool("find_table_writers", "Which repository SQL file(s) create/insert a table (upstream tables included); "
             "if none, returns Python code that writes it.", obj({"table": S}), find_table_writers),
        Tool("read_sql_file", "Read any repository file (relative path from find_table_writers/search_repo), paged.",
             obj({"path": S, "start_line": I, "end_line": I}, ["path"]), read_sql_file),
        Tool("search_repo", "Regex search in repository files (default *.sql; use '*.py' for Python).",
             obj({"pattern": S, "file_glob": S, "max_hits": I}, ["pattern"]), search_repo),
        Tool("get_code_lineage", "Lineage of a column parsed from the code (with intermediate WHERE filters).",
             obj({"table": S, "column": S}), get_code_lineage),
    ]


# =============================================================================
# EDW data dictionary + glossary tools
# =============================================================================
def dictionary_tools(ctx) -> List[Tool]:
    p = ctx.p
    edw = p.edw_df

    def edw_lookup(table: str, column: str):
        r, q = p.edw.lookup(table, column)
        if not r:
            return {"match": "none"}
        return {"match": q, **{k: r[k] for k in ("physical_table", "table_business_name", "business_column_name",
                                                 "column_name", "column_definition", "datatype")}}

    def edw_search(text: str, max_hits: int = 25):
        t = text.lower()
        m = edw[edw.business_column_name.str.lower().str.contains(t, regex=False) |
                edw.column_definition.str.lower().str.contains(t, regex=False) |
                edw.column_name.str.contains(t, regex=False)]
        return m.head(max_hits)[["physical_table", "column_name", "business_column_name", "column_definition"]] \
            .to_dict("records")

    def edw_table_columns(table: str):
        from ..lineage import normalize_edw_table
        n = normalize_edw_table(table)
        m = edw[edw.physical_table.map(normalize_edw_table) == n]
        if m.empty:
            return {"error": f"table {table} not in EDW dictionary"}
        return {"table_business_name": m.iloc[0].table_business_name, "table_definition": m.iloc[0].table_definition,
                "columns": m[["column_name", "business_column_name", "column_definition", "datatype"]]
                .head(300).to_dict("records")}

    def glossary_lookup(token: str):
        e = p.glossary.entries.get(token.lower())
        return e or {"error": f"token {token} not in glossary"}

    def token_usage(token: str, max_hits: int = 15):
        t = token.lower()
        prof = [f"{a}.{b}" for a, b in p.ctx[["table_name", "column_name"]].itertuples(index=False)
                if t in tokenize(b)][:max_hits]
        e = edw[edw.column_name.map(lambda c: t in tokenize(c))].head(max_hits)
        return {"profile_columns": prof,
                "edw_columns": e[["column_name", "business_column_name", "column_definition"]].to_dict("records")}

    return [
        Tool("edw_lookup", "EDW Data Dictionary definition of a source table.column (table names normalised).",
             obj({"table": S, "column": S}), edw_lookup),
        Tool("edw_search", "Search the EDW Data Dictionary (column names, business names, definitions).",
             obj({"text": S, "max_hits": I}, ["text"]), edw_search),
        Tool("edw_table_columns", "All dictionary columns of one EDW table.", obj({"table": S}), edw_table_columns),
        Tool("glossary_lookup", "Current glossary entry of an abbreviation token (meaning, status, evidence).",
             obj({"token": S}), glossary_lookup),
        Tool("token_usage", "Columns (profile + EDW dictionary) whose name contains a token.",
             obj({"token": S, "max_hits": I}, ["token"]), token_usage),
    ]


# =============================================================================
# catalog / Greenplum tools
# =============================================================================
def catalog_tools(ctx) -> List[Tool]:
    p = ctx.p

    def get_table_catalog(table: str):
        t = table.lower()
        d = p.description_row(t)
        cols = p.col_types[p.col_types.table_name == t] if len(p.col_types) else None
        s = p.schemas.get(t)
        return {"catalogue": d or "not in core_ikg.ikg_profile_table_descriptions",
                "entity_resolved": p.table_entity(t),
                "deployed_columns": int(len(cols)) if cols is not None else "information_schema not available",
                "parsed_columns": len(s.columns) if s else 0,
                "distribution_key": s.distribution_key if s else [],
                "columns_not_in_code": sorted(set(cols.column_name) - {c.name for c in s.columns})[:50]
                if (cols is not None and s) else []}

    def get_lineage(table: str, column: str):
        ev = ctx.evidence(table.lower(), column.lower())
        return {k: ev.get(k, "") for k in ("lineage_db", "terminal_sources", "filters", "lineage_stopped_at",
                                           "source_definitions")}

    def lineage_rows(table: str, column: str, max_rows: int = 25):
        df = p.lineage_df
        m = df[(df.target_table == table.lower()) & (df.target_column == column.lower())]
        return m.head(max_rows)[["sub_target_table", "source_schema", "source_table", "source_column", "logic",
                                 "sql_process"]].to_dict("records")

    def profile_column_values(table: str, column: str):
        return value_profile(ctx, table.lower(), column.lower())

    def list_columns_needing_values(table: str):
        c = p.ctx[p.ctx.table_name == table.lower()]
        mask = c.column_name.str.match(r"^(is_|has_)|.*(_c|_cd|_code|_flag|_flg|_ind|_type|_typ|_status|_stat)$")
        return c[mask & ~c.is_technical][["column_name", "data_type", "sql_expression"]].head(60).to_dict("records")

    return [
        Tool("get_table_catalog", "Catalogue description, resolved entity, deployed vs parsed columns of a table.",
             obj({"table": S}), get_table_catalog),
        Tool("get_lineage", "Lineage of a column from core_ikg.ikg_column_lineage_master_auto_refresh (walked "
             "upstream), with filters and EDW definitions of the terminal sources.", obj({"table": S, "column": S}),
             get_lineage),
        Tool("lineage_rows", "Raw lineage-table rows for one target column.",
             obj({"table": S, "column": S, "max_rows": I}, ["table", "column"]), lineage_rows),
        Tool("profile_column_values", "READ-ONLY profile of actual values in Greenplum for the latest profile: "
             "top values with counts (codes/flags/text) or min/max/avg/null% (numbers/dates).",
             obj({"table": S, "column": S}), profile_column_values),
        Tool("list_columns_needing_values", "Flag / code / type / status columns of a table - candidates for value "
             "profiling.", obj({"table": S}), list_columns_needing_values),
    ]


def value_profiles_for_table(ctx, table: str, columns: List[str]) -> dict:
    """ONE sampled query per table; profiles computed in pandas. Results cached in ctx.value_profiles."""
    p = ctx.p
    todo = [c for c in columns if (table, c) not in ctx.value_profiles]
    if not todo:
        return {c: ctx.value_profiles[(table, c)] for c in columns}
    if p.gp is None or not len(p.col_types):
        return {c: "value profiling not available (Greenplum not connected / sources.mode=files)" for c in columns}
    ct = p.col_types[(p.col_types.table_name == table) & (p.col_types.column_name.isin(todo))]
    cols = [c for c in todo if c in set(ct.column_name) and re.fullmatch(r"[a-z_][a-z0-9_]*", c)]
    if not cols or not re.fullmatch(r"[a-z_][a-z0-9_]*", table):
        return {c: "ERROR: not a deployed profile column" for c in todo}
    sch = p.cfg.greenplum["schema"]
    limit = int(p.cfg.get("agents", {}).get("value_profile_sample_rows", 200000))
    try:
        from sqlalchemy import text
        with p.gp.engine.connect() as con:
            con.execute(text("set statement_timeout = 120000"))
            df = pd.read_sql_query(text(f'select {", ".join(chr(34) + c + chr(34) for c in cols)} from "{sch}"."{table}" limit {limit}'), con)
    except Exception as e:  # noqa: BLE001
        for c in cols:
            ctx.value_profiles[(table, c)] = f"profiling failed: {str(e)[:200]}"
        return {c: ctx.value_profiles.get((table, c), "") for c in columns}
    types = dict(zip(ct.column_name, ct.data_type.str.lower()))
    n = len(df)
    for c in cols:
        s_ = df[c]
        dtype = types.get(c, "")
        nn = int(s_.notna().sum())
        if any(x in dtype for x in ("int", "numeric", "double", "real", "decimal", "date", "time")) and not c.startswith(("is_", "has_")):
            try:
                avg = f"{pd.to_numeric(s_, errors='coerce').mean():.4f}" if "date" not in dtype and "time" not in dtype else "n/a"
            except Exception:  # noqa: BLE001
                avg = "n/a"
            out = (f"sampled rows={n}, non-null={nn} ({(100 * nn / n) if n else 0:.1f}%), min={s_.min()}, max={s_.max()}, "
                   f"avg={avg}, distinct={s_.nunique(dropna=True)}")
        else:
            vc = s_.astype(str).where(s_.notna(), "NULL").value_counts().head(15)
            tot = int(vc.sum()) or 1
            out = "top values: " + "; ".join(f"{str(k)[:60]} ({100 * v / tot:.1f}%)" for k, v in vc.items())
        ctx.value_profiles[(table, c)] = out
    return {c: ctx.value_profiles.get((table, c), "") for c in columns}


def value_profile(ctx, table: str, column: str) -> str:
    """Safe, template-only SQL: identifiers validated against information_schema of the profile table."""
    p = ctx.p
    key = (table, column)
    if key in ctx.value_profiles:
        return ctx.value_profiles[key]
    if p.gp is None or not len(p.col_types):
        return "value profiling not available (Greenplum not connected / sources.mode=files)"
    ct = p.col_types[(p.col_types.table_name == table) & (p.col_types.column_name == column)]
    if ct.empty or table not in p.schemas:
        return f"ERROR: {table}.{column} is not a deployed profile column"
    if not re.fullmatch(r"[a-z_][a-z0-9_]*", table) or not re.fullmatch(r"[a-z_][a-z0-9_]*", column):
        return "ERROR: invalid identifier"
    sch = p.cfg.greenplum["schema"]
    dtype = str(ct.iloc[0].data_type).lower()
    fq, col = f'"{sch}"."{table}"', f'"{column}"'
    limit = int(p.cfg.get("agents", {}).get("value_profile_sample_rows", 200000))
    base = f"(select {col} as v from {fq} limit {limit}) s"
    try:
        from sqlalchemy import text
        with p.gp.engine.connect() as con:
            con.execute(text("set statement_timeout = 60000"))
            if any(x in dtype for x in ("int", "numeric", "double", "real", "decimal", "date", "time")) and \
                    not column.startswith(("is_", "has_")):
                r = con.execute(text(f"select count(*), count(v), min(v)::text, max(v)::text, "
                                     f"{'avg(v)::numeric(30,4)::text' if 'date' not in dtype and 'time' not in dtype else 'null'}, "
                                     f"count(distinct v) from {base}")).fetchone()
                out = (f"sampled rows={r[0]}, non-null={r[1]} ({(100 * r[1] / r[0]) if r[0] else 0:.1f}%), "
                       f"min={r[2]}, max={r[3]}, avg={r[4]}, distinct={r[5]}")
            else:
                rows = con.execute(text(f"select v::text, count(*) c from {base} group by 1 order by 2 desc limit 15")).fetchall()
                tot = sum(x[1] for x in rows) or 1
                out = "top values: " + "; ".join(f"{(x[0] if x[0] is not None else 'NULL')[:60]} ({100 * x[1] / tot:.1f}%)"
                                                 for x in rows)
    except Exception as e:  # noqa: BLE001
        out = f"profiling failed: {str(e)[:200]}"
    ctx.value_profiles[key] = out
    return out


# =============================================================================
# evidence + graph tools
# =============================================================================
def evidence_tools(ctx) -> List[Tool]:
    return [Tool("get_column_evidence", "Complete evidence pack of one profile column (expression, both lineages, "
                 "filters, EDW definitions, glossary, value profile, catalog note).",
                 obj({"table": S, "column": S}), lambda table, column: ctx.evidence(table.lower(), column.lower()))]


def graph_tools(ctx, kg) -> List[Tool]:
    def list_relationships():
        return kg.relationships_frame().to_dict("records")

    def entity_attributes(entity: str, limit: int = 80):
        rows = [a for (e, c), a in kg.attrs.items() if e == entity and not a["is_technical"]]
        return {"count": len(rows), "sample": [{"column": a["column"], "name": a["functional_name"],
                                               "tables": a["tables"][:3]} for a in rows[:limit]]}

    def table_entities():
        return [{"table": t["table"], "entity": e, "grain": t["grain"]} for e, ts in kg.ent_tables.items() for t in ts]

    def key_columns():
        return kg.key_owner

    return [Tool("list_relationships", "Current entity relationships with evidence.", obj({}), list_relationships),
            Tool("entity_attributes", "Attributes currently attached to an entity.",
                 obj({"entity": S, "limit": I}, ["entity"]), entity_attributes),
            Tool("table_entities", "Profile table -> entity mapping with grain.", obj({}), table_entities),
            Tool("key_columns", "Key column -> owning entity map from the entity model.", obj({}), key_columns)]
