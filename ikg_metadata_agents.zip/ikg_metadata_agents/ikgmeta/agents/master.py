"""
Master agent: plans and drives the specialists, checks quality, escalates weak attributes.

orchestration modes (config agents.orchestration):
  llm            the master is an LLM agent whose tools run the specialists. Code-enforced gates make it
                 impossible to skip prerequisites or finish before outputs are written.
  deterministic  same specialists, fixed order (skills -> dictionary -> catalog -> code -> author ->
                 reviewer -> escalation rounds -> graph -> outputs). Useful as fallback / for comparison.
"""
from __future__ import annotations

import concurrent.futures as cf
import json
import logging
import time
from typing import List, Optional

import pandas as pd

from ..knowledge_graph import KnowledgeGraph
from .base import Agent, I, S, Tool, arr, obj
from .context import AgentContext
from .specialists import (CodeAgent, DataDictionaryAgent, GraphAgent, MetadataAuthorAgent, ReviewerAgent,
                          SkillAgent, TableCatalogAgent, _prompt)

log = logging.getLogger(__name__)


class Orchestrator:
    """Holds the specialists and the stage functions used by both orchestration modes."""

    def __init__(self, ctx: AgentContext):
        self.ctx = ctx
        self.p = ctx.p
        self.ac = ctx.cfg.get("agents", {})
        self.par = int(ctx.cfg.llm["parallel_calls"])
        self.kg: Optional[KnowledgeGraph] = None
        self.errors: List[str] = []

    # ------------------------------------------------------------ helpers
    def _tables(self, tables=None) -> List[str]:
        all_t = sorted(getattr(self.p, "active_tables", None) or self.p.schemas)
        if not tables:
            return all_t
        bad = [t for t in tables if t.lower() not in self.p.schemas]
        if bad:
            raise ValueError(f"unknown tables {bad}")
        return [t.lower() for t in tables]

    def _parallel(self, fn, items, what: str):
        """Run fn over items with the configured parallelism; logs progress + ETA."""
        out, items = [], list(items)
        if not items:
            return out
        t0, done, n = time.time(), 0, len(items)
        with cf.ThreadPoolExecutor(self.par) as ex:
            futs = {ex.submit(fn, *(i if isinstance(i, tuple) else (i,))): i for i in items}
            for f in cf.as_completed(futs):
                done += 1
                try:
                    out.append(f.result())
                except Exception as e:  # noqa: BLE001
                    msg = f"{what} failed for {str(futs[f])[:80]}: {e}"
                    log.error(msg)
                    self.errors.append(msg)
                if done == n or done % max(1, n // 5) == 0:
                    el = time.time() - t0
                    log.info("%s: %d/%d done, %.0fs elapsed, ETA %.0fs", what, done, n, el, el / done * (n - done))
        return out

    def _require(self, *stages):
        missing = [s for s in stages if not self.ctx.stage_done.get(s)]
        if missing:
            raise RuntimeError(f"prerequisite stage(s) not done: {missing}")

    # ------------------------------------------------------------ stages
    def stage_skills(self):
        b = SkillAgent(self.ctx).execute()
        self.p.apply_skill_knowledge(b)
        self.ctx.mark("skills")
        return {k: (len(v) if isinstance(v, list) else v) for k, v in b.items() if not k.startswith("_")}

    def stage_dictionary(self):
        self._require("skills")
        r = DataDictionaryAgent(self.ctx).execute()
        self.ctx.mark("dictionary")
        g = self.p.glossary.frame()
        return {**r, "glossary_needs_input": int(((g.status != "RESOLVED") & g.is_abbreviation).sum())}

    def stage_catalog(self, tables=None):
        mode = self._catalog_mode()
        if mode == "off":
            self.ctx.mark("catalog")
            return "catalog agent disabled in config"
        ts = self._tables(tables)
        if mode == "profile_only":
            self._parallel(self.profile_table, ts, "value profiling")
        else:
            self._parallel(lambda t: TableCatalogAgent(self.ctx).execute(t), ts, "catalog agent")
        if not tables or set(ts) >= set(self.p.schemas):
            self.ctx.mark("catalog")
        return {"tables": len(ts), "value_profiles": len(self.ctx.value_profiles)}

    def stage_code(self, tables=None):
        self._require("skills")
        ts = self._tables(tables)
        self._parallel(lambda t: CodeAgent(self.ctx).execute(t), ts, "code agent")
        if set(self.ctx.table_briefs) >= set(self.p.schemas):
            self.ctx.mark("code")
        return {"tables_with_brief": len(self.ctx.table_briefs)}

    def stage_understand(self, tables=None):
        """Catalog agent and code agent for all tables in ONE pool (they are independent)."""
        self._require("skills")
        ts = self._tables(tables)
        jobs, mode = [], self._catalog_mode()
        if mode != "off":
            jobs += [("catalog", t) for t in ts]
        jobs += [("code", t) for t in ts]

        def run(kind, t):
            if kind == "code":
                return CodeAgent(self.ctx).execute(t)
            return self.profile_table(t) if mode == "profile_only" else TableCatalogAgent(self.ctx).execute(t)
        self._parallel(run, jobs, "catalog+code agents")
        if mode == "off" or not tables or set(ts) >= set(self.p.schemas):
            self.ctx.mark("catalog")
        if set(self.ctx.table_briefs) >= set(self.p.schemas):
            self.ctx.mark("code")
        return {"tables": len(ts), "briefs": len(self.ctx.table_briefs), "value_profiles": len(self.ctx.value_profiles)}

    # ------------------------------------------------------------ deterministic value profiling (no LLM)
    def profile_table(self, table: str) -> int:
        """Catalog step without an LLM: value profiles of the flag/code columns become evidence directly."""
        from . import tools as T
        p = self.p
        if p.gp is None or not len(p.col_types):
            return 0
        tools = {t.name: t for t in T.catalog_tools(self.ctx)}
        cands = tools["list_columns_needing_values"](table=table)
        n_max = int(self.ac.get("value_profile_max_columns", 12))
        ev = p.ctx

        def rank(c):
            r = ev[(ev.table_name == table) & (ev.column_name == c["column_name"])]
            return 0 if (len(r) and r.iloc[0].edw_match == "none") else 1
        chosen = [c["column_name"] for c in sorted(cands, key=rank)[:n_max]]
        T.value_profiles_for_table(self.ctx, table, chosen)
        return len(chosen)

    def _catalog_mode(self) -> str:
        v = self.ac.get("catalog_agent", "profile_only")
        return "llm" if v is True else ("off" if v is False else str(v))

    # ------------------------------------------------------------ streaming per-table pipeline (fastest)
    def stage_tables_pipeline(self, tables=None, escalation_rounds: int = None):
        """Every table runs its own pipeline (profile -> code brief -> author -> review -> escalate) and all
        tables run concurrently; the LLM client caps the real API concurrency. Stages overlap instead of
        waiting for the slowest table."""
        self._require("skills", "dictionary")
        ts = self._tables(tables)
        rounds = int(self.ac.get("escalation_rounds", 1)) if escalation_rounds is None else escalation_rounds
        n_cols = int(self.p.gen["columns_per_call"])
        inner = max(2, min(6, self.par))
        mode = self._catalog_mode()
        t_start = time.time()
        done = {"n": 0}

        def batches(cols):
            return [cols[i:i + n_cols] for i in range(0, len(cols), n_cols)]

        def run_batches(fn, jobs, what):
            if not jobs:
                return []
            out = []
            with cf.ThreadPoolExecutor(min(inner, len(jobs))) as ex:
                for f in cf.as_completed([ex.submit(fn, *j) for j in jobs]):
                    try:
                        out.append(f.result())
                    except Exception as e:  # noqa: BLE001
                        self.errors.append(f"{what} failed: {e}")
                        log.error("%s failed: %s", what, e)
            return out

        import fnmatch
        only = [x.lower() for x in (self.p.gen.get("only_columns") or [])]
        prev = self._previous_results() if only else {}

        rep_of = getattr(self.p, "rep_of", None)
        if rep_of is None:
            self.p.plan_shared_columns()
            rep_of = self.p.rep_of

        def wanted(c):
            return not only or any(fnmatch.fnmatch(c, pat) for pat in only)

        def owned(t, c):
            """author here only if this table is the representative of the column (or it is not shared)"""
            return (t, c) not in prefilled and rep_of.get((t, c), (t, c)) == (t, c)

        prefilled = getattr(self.p, "prefilled", {}) or {}

        def one_table(t):
            # 0. delta mode: columns whose name already has a published description are copied, not authored
            for k, v in prefilled.items():
                if k[0] == t and k not in self.ctx.results:
                    self.ctx.results[k] = dict(v)
            # 0b. targeted regeneration: keep previous results for columns not selected
            if only:
                for c in self.p.ctx[self.p.ctx.table_name == t].column_name:
                    if not wanted(c) and (t, c) in prev and (t, c) not in self.ctx.results:
                        self.ctx.results[(t, c)] = prev[(t, c)]
            # 1. catalog: value profiles (deterministic) or catalog agent
            if mode == "llm":
                TableCatalogAgent(self.ctx).execute(t)
            elif mode == "profile_only":
                self.profile_table(t)
            # 2. code brief
            CodeAgent(self.ctx).execute(t)
            # 3. author
            cols = [c for c in self.p.ctx[self.p.ctx.table_name == t].sort_values("ordinal").column_name
                    if wanted(c) and owned(t, c)]
            for batch in run_batches(lambda c: MetadataAuthorAgent(self.ctx).execute(t, c), [(b,) for b in batches(cols)], f"author {t}"):
                for x in batch:
                    self.ctx.results[(x["table_name"], x["column_name"])] = x
            # 4. review non-High + escalation rounds
            for rnd in range(rounds + 1):
                df = self.p.score_df(self.p.frame_from_agents(self.ctx.results, t))
                if rnd == 0:
                    todo = [c for c in df[df.confidence_band != "High"].column_name if wanted(c) and owned(t, c)]
                    for batch in run_batches(lambda c: ReviewerAgent(self.ctx).execute(t, c), [(b,) for b in batches(todo)], f"review {t}"):
                        self._apply_review(batch)
                    continue
                df = self.p.score_df(self.p.frame_from_agents(self.ctx.results, t))
                low = [c for c in df[df.confidence_band == "Low"].column_name
                       if wanted(c) and owned(t, c) and self.ctx.escalations.get((t, c), 0) < 2]
                if not low:
                    break
                for c in low:
                    self.ctx.escalations[(t, c)] = self.ctx.escalations.get((t, c), 0) + 1
                jobs = []
                for b in [low[i:i + 8] for i in range(0, len(low), 8)]:
                    issues = {c: (self.ctx.reviews.get((t, c)) or {}).get("issues", "") for c in b}
                    instr = ("ESCALATION: these attributes scored Low. Use the tools to close the gaps (read the SQL "
                             "lines, upstream scripts, EDW definitions, skills, actual values). Reviewer issues: "
                             + json.dumps(issues, ensure_ascii=False))
                    jobs.append((b, instr))
                for batch in run_batches(lambda b, i: MetadataAuthorAgent(self.ctx).execute(t, b, i, f"escalate {t}"), jobs, f"escalate {t}"):
                    for x in batch:
                        self.ctx.results[(x["table_name"], x["column_name"])] = x
                for batch in run_batches(lambda c: ReviewerAgent(self.ctx).execute(t, c), [(b,) for b in batches(low)], f"re-review {t}"):
                    self._apply_review(batch)
            done["n"] += 1
            el = time.time() - t_start
            log.info("table pipeline: %s done (%d/%d tables, %.0fs elapsed, ETA %.0fs)", t, done["n"], len(ts), el,
                     el / done["n"] * (len(ts) - done["n"]))
            return t

        with cf.ThreadPoolExecutor(max_workers=len(ts)) as ex:
            for f in cf.as_completed([ex.submit(one_table, t) for t in ts]):
                try:
                    f.result()
                except Exception as e:  # noqa: BLE001
                    self.errors.append(f"table pipeline failed: {e}")
                    log.error("table pipeline failed: %s", e)
        n = self.p.propagate_shared(self.ctx.results)
        log.info("Shared-column metadata copied to %d table columns", n)
        if not tables or set(ts) >= set(self._tables()):
            for st in ("catalog", "code", "author", "review"):
                self.ctx.mark(st)
        self.score()
        return self.quality(brief=True)

    def _previous_results(self) -> dict:
        """Previous workbook -> results dict (used by generation.only_columns to keep untouched columns)."""
        path = self.p.out / self.p.cfg.output["metadata_xlsx"]
        if not path.exists():
            log.warning("only_columns set but no previous workbook at %s - unselected columns will be empty", path)
            return {}
        df = pd.read_excel(path, sheet_name="Attribute_Metadata", dtype=str).fillna("")
        keep = ["functional_name", "business_description", "entity", "attribute_type", "derivation_type", "unit",
                "llm_confidence", "confidence_reason", "difficult_to_generate", "what_is_required_llm",
                "unresolved_abbreviations_llm", "evidence_used", "verify_verdict", "verify_issues"]
        if "what_is_required_llm" not in df.columns:
            df["what_is_required_llm"] = df.get("what_is_required", "")
        out = {}
        for r in df.to_dict("records"):
            x = {"table_name": r["table_name"], "column_name": r["column_name"]}
            for k in keep:
                v = r.get(k, "")
                x[k] = (v.lower() == "true") if k == "difficult_to_generate" else (int(float(v)) if k == "llm_confidence" and v else v)
            out[(r["table_name"], r["column_name"])] = x
        log.info("only_columns: %d previous attribute results loaded from %s", len(out), path.name)
        return out

    def _apply_review(self, batch):
        for x in batch:
            k = (x["table_name"], x["column_name"])
            d = self.ctx.results.get(k)
            if not d:
                continue
            self.ctx.reviews[k] = x
            d["verify_verdict"], d["verify_issues"] = x.get("verdict", ""), x.get("issues", "")
            if x.get("functional_name"):
                d["functional_name"] = x["functional_name"].strip()
            if x.get("business_description"):
                d["business_description"] = x["business_description"].strip()
            if x.get("llm_confidence") is not None:
                d["llm_confidence"] = int(x["llm_confidence"])
            if x.get("what_is_required"):
                d["what_is_required_llm"] = x["what_is_required"]
            if x.get("verdict") == "insufficient_evidence":
                d["difficult_to_generate"] = True

    def stage_author(self, tables=None):
        self._require("skills", "dictionary")
        ts = self._tables(tables)
        missing = [t for t in ts if t not in self.ctx.table_briefs]
        if missing:
            raise RuntimeError(f"run the code agent first for: {missing[:10]}")
        n = int(self.p.gen["columns_per_call"])
        jobs = []
        for t in ts:
            cols = self.p.ctx[self.p.ctx.table_name == t].sort_values("ordinal").column_name.tolist()
            jobs += [(t, cols[i:i + n]) for i in range(0, len(cols), n)]
        res = self._parallel(lambda t, cols: MetadataAuthorAgent(self.ctx).execute(t, cols), jobs, "author agent")
        for batch in res:
            for x in batch:
                self.ctx.results[(x["table_name"], x["column_name"])] = x
        if all((t, c) in self.ctx.results for t, c in self.p.ctx[["table_name", "column_name"]].itertuples(index=False)):
            self.ctx.mark("author")
        self.score()
        return self.quality(brief=True)

    def stage_review(self, tables=None, scope: str = "non_high"):
        self._require("author")
        df = self.score()
        if tables:
            df = df[df.table_name.isin(self._tables(tables))]
        if scope == "non_high":
            df = df[df.confidence_band != "High"]
        n = int(self.p.gen["columns_per_call"])
        jobs = []
        for t, g in df.groupby("table_name"):
            cols = g.column_name.tolist()
            jobs += [(t, cols[i:i + n]) for i in range(0, len(cols), n)]
        res = self._parallel(lambda t, cols: ReviewerAgent(self.ctx).execute(t, cols), jobs, "reviewer agent")
        for batch in res:
            for x in batch:
                k = (x["table_name"], x["column_name"])
                d = self.ctx.results.get(k)
                if not d:
                    continue
                self.ctx.reviews[k] = x
                d["verify_verdict"], d["verify_issues"] = x.get("verdict", ""), x.get("issues", "")
                if x.get("functional_name"):
                    d["functional_name"] = x["functional_name"].strip()
                if x.get("business_description"):
                    d["business_description"] = x["business_description"].strip()
                if x.get("llm_confidence") is not None:
                    d["llm_confidence"] = int(x["llm_confidence"])
                if x.get("what_is_required"):
                    d["what_is_required_llm"] = x["what_is_required"]
                if x.get("verdict") == "insufficient_evidence":
                    d["difficult_to_generate"] = True
        self.ctx.mark("review")
        self.score()
        return {"reviewed": int(len(df)), **self.quality(brief=True)}

    def stage_escalate(self, max_columns: int = 400):
        """Low attributes go back to the author with the reviewer's issues + instruction to use tools, then re-review."""
        self._require("review")
        df = self.score()
        low = df[df.confidence_band == "Low"]
        low = low[[self.ctx.escalations.get((t, c), 0) < 2 for t, c in zip(low.table_name, low.column_name)]]
        low = low.head(max_columns)
        if low.empty:
            return "no Low attributes left to escalate"
        jobs = []
        for t, g in low.groupby("table_name"):
            cols = g.column_name.tolist()
            for i in range(0, len(cols), 8):
                chunk = cols[i:i + 8]
                issues = {c: (self.ctx.reviews.get((t, c)) or {}).get("issues", "") for c in chunk}
                instr = ("ESCALATION: these attributes scored Low. Before answering, use the tools to close the gaps: "
                         "read the relevant SQL lines (read_profile_sql / find_table_writers / read_sql_file), check "
                         "EDW definitions (edw_lookup / edw_search), skills (search_skills) and actual values "
                         "(profile_column_values). Reviewer issues: " + json.dumps(issues, ensure_ascii=False))
                jobs.append((t, chunk, instr))
        for t, c in zip(low.table_name, low.column_name):
            self.ctx.escalations[(t, c)] = self.ctx.escalations.get((t, c), 0) + 1
        res = self._parallel(lambda t, cols, instr: MetadataAuthorAgent(self.ctx).execute(t, cols, instr, f"escalate {t}"),
                             jobs, "escalation")
        for batch in res:
            for x in batch:
                self.ctx.results[(x["table_name"], x["column_name"])] = x
        self.stage_review(scope="non_high", tables=sorted(set(low.table_name)))
        return {"escalated": int(len(low)), **self.quality(brief=True)}

    def stage_graph(self):
        self._require("author")
        self.score()
        self.kg = KnowledgeGraph(self.ctx.cfg, self.p, results=self.p.all_results_frame()).build()
        if self.ac.get("graph_agent", True):
            review = GraphAgent(self.ctx, self.kg).execute()
            self.kg.apply_review(review)
        self.ctx.mark("graph")
        return {"relationships": len(self.kg.rels), "attribute_leaves": len(self.kg.attrs)}

    def stage_outputs(self):
        self._require("author", "review", "graph")
        from ..clone_tables import CloneTablesBuilder
        from ..report import metadata_sheet
        df = self.score()
        cfg = self.ctx.cfg
        sync = None
        if self.p.gp is not None and cfg.output.get("load_to_greenplum", False):
            from ..db_sync import GreenplumSync
            sync = GreenplumSync(self.p.gp, cfg)
        # extra sheets: joining keys, delta summary, combined-table coverage
        jk = self.kg.joining_keys_frame()
        self.ctx.extra_sheets = {"Joining_Keys": jk}
        di = getattr(self.p, "delta_info", {}) or {}
        if di:
            self.ctx.extra_sheets["Delta_Summary"] = pd.DataFrame(
                [{"item": k, "value": (", ".join(".".join(x) if isinstance(x, tuple) else str(x) for x in v)
                                       if isinstance(v, list) else v)} for k, v in di.items()])
        clone_sql = ""
        try:
            builder = CloneTablesBuilder(self.p, self.kg)
            clone_sql = builder.build()
            sql_path = self.p.out / cfg.output["clone_sql_file"]
            sql_path.write_text(clone_sql, encoding="utf-8")
            self.ctx.extra_sheets["Clone_Summary"] = builder.summary_frame()
            self.ctx.extra_sheets["Clone_Report"] = builder.report_frame()
            log.info("clone script: %s", sql_path)
        except Exception as e:  # noqa: BLE001
            self.errors.append(f"clone script failed: {e}")
            log.error("clone script failed: %s", e)
        path = self.p.write(self.kg.relationships_frame(), agent_ctx=self.ctx)
        out = self.kg.export()
        loaded = {}
        if sync is not None:
            try:
                created = sync.ensure_metadata_table()
                info = self.p.run_info()
                n = sync.insert_metadata(metadata_sheet(self.p.results), info["run_timestamp"], info["model"])
                loaded["metadata_table"] = f"{'created, ' if created else ''}{n} rows inserted"
                sync.write_glossary(self.p.glossary.frame())
                sync.write_graph(self.kg.relationships_frame(), jk)
                loaded["graph_tables"] = "replaced"
                if clone_sql and cfg.output.get("create_clones", True):
                    sync.run_script(clone_sql)
                    loaded["clone_tables"] = f"{len(self.p.schemas)} clones re-created"
            except Exception as e:  # noqa: BLE001
                self.errors.append(f"Greenplum load failed: {e}")
                log.error("Greenplum load failed: %s", e)
        self.ctx.mark("outputs")
        return {"workbook": str(path), "graph_html": str(out / "knowledge_graph.html"),
                "clone_sql": str(self.p.out / cfg.output["clone_sql_file"]), "greenplum": loaded or "not loaded"}

    # ------------------------------------------------------------ quality
    def score(self) -> pd.DataFrame:
        self.p.results_from_agents(self.ctx.results)
        return self.p.score() if self.p.results is not None and len(self.p.results) else pd.DataFrame()

    def quality(self, brief: bool = False) -> dict:
        r = self.p.results
        if r is None or not len(r) or "confidence_band" not in r:
            return {"attributes_done": 0}
        done = r[r.functional_name.fillna("") != ""]
        q = {"attributes_total": int(len(self.p.ctx)), "attributes_done": int(len(done)),
             "high": int((r.confidence_band == "High").sum()), "medium": int((r.confidence_band == "Medium").sum()),
             "low": int((r.confidence_band == "Low").sum()), "difficult": int(r.difficult_to_generate.sum()),
             "glossary_needs_input": int(((self.p.glossary.frame().status != "RESOLVED") &
                                          self.p.glossary.frame().is_abbreviation).sum()),
             "errors": len(self.errors)}
        if not brief:
            worst = r.groupby("table_name").confidence_score.mean().sort_values().head(8).round(1).to_dict()
            q["lowest_tables"] = worst
            q["top_missing_inputs"] = r[r.confidence_band == "Low"].what_is_required.str.split(" \\| ").explode() \
                .value_counts().head(10).to_dict()
            q["stages_done"] = [k for k, v in self.ctx.stage_done.items() if v]
            q["recent_errors"] = self.errors[-5:]
        return q

    # ------------------------------------------------------------ deterministic mode
    def run_deterministic(self, escalation_rounds: int = 1) -> dict:
        self.stage_skills()
        self.stage_dictionary()
        self.stage_tables_pipeline(escalation_rounds=escalation_rounds)
        self.stage_graph()
        return self.stage_outputs()


# =============================================================================
class MasterAgent(Agent):
    name, max_steps = "master_agent", 40

    SCHEMA = obj({"summary": S, "open_issues": arr(S)})

    def __init__(self, ctx: AgentContext, orch: Orchestrator):
        self.orch = orch
        o = orch
        tl = obj({"tables": arr(S)}, [])

        def wrap(fn):
            def call(**kw):
                return fn(**kw)
            return call
        tools = [
            Tool("run_skill_agent", "Skill agent reads all skill files -> verified definitions, abbreviations, "
                 "entity definitions, authoring rules. Run first.", obj({}), wrap(o.stage_skills)),
            Tool("run_dictionary_agent", "Data-dictionary agent resolves unresolved abbreviations from the EDW "
                 "dictionary / skills / code; unknown ones become NEEDS_INPUT. Needs skills.", obj({}), wrap(o.stage_dictionary)),
            Tool("run_catalog_agent", "Table-catalog agent per table: catalogue vs code, lineage, value profiles of "
                 "flags/codes. Optional list of tables (default all).", tl, wrap(o.stage_catalog)),
            Tool("run_code_agent", "Code agent per table: reads the complete create script and upstream code -> "
                 "table brief with SQL-quoted business rules. Needs skills.", tl, wrap(o.stage_code)),
            Tool("run_table_pipelines", "FASTEST PATH: for every table run catalog profiling -> code agent -> "
                 "author -> reviewer -> escalation of Low, all tables concurrently (stages overlap). Replaces "
                 "run_catalog_and_code_agents + run_author_agent + run_reviewer_agent + escalate_low_confidence. "
                 "Needs skills + dictionary.", tl, wrap(o.stage_tables_pipeline)),
            Tool("run_catalog_and_code_agents", "FASTEST: catalog agent + code agent for all tables in one parallel "
                 "pool (use instead of calling them separately). Needs skills.", tl, wrap(o.stage_understand)),
            Tool("run_author_agent", "Metadata author agent writes name/description/confidence for every column. "
                 "Needs skills, dictionary and code briefs of the tables.", tl, wrap(o.stage_author)),
            Tool("run_reviewer_agent", "Reviewer agent re-checks attributes against evidence. scope 'non_high' "
                 "(default) or 'all'.", obj({"tables": arr(S), "scope": S}, []), wrap(o.stage_review)),
            Tool("escalate_low_confidence", "Send Low attributes back to the author with reviewer issues and an "
                 "instruction to use tools, then re-review. Max 2 escalations per attribute.",
                 obj({"max_columns": I}, []), wrap(o.stage_escalate)),
            Tool("run_graph_agent", "Build the knowledge graph and let the graph agent validate relationships / "
                 "entity descriptions. Needs author.", obj({}), wrap(o.stage_graph)),
            Tool("quality_report", "Current quality: bands, difficult, glossary needs-input, lowest tables, top "
                 "missing inputs, stages done, errors.", obj({}), lambda: o.quality()),
            Tool("write_outputs", "Write the metadata xlsx and the knowledge-graph html. Needs author, review, graph.",
                 obj({}), wrap(o.stage_outputs)),
        ]
        super().__init__(ctx, tools, self.SCHEMA, _prompt("master_agent"))

    def ground(self, r: dict, task: dict):
        if not self.ctx.stage_done.get("outputs"):
            return r, ["outputs not written yet - call write_outputs before submitting"]
        return r, []

    def execute(self) -> dict:
        task = {"profile_tables": len(self.orch.p.schemas), "attributes": int(len(self.orch.p.ctx)),
                "skill_files": len(self.ctx.skills.files), "edw_definitions": int(len(self.orch.p.edw_df)),
                "value_profiling_available": self.orch.p.gp is not None,
                "quality_target": "maximise High; every Low must have what_is_required; escalate Low at most twice"}
        return self.run(task, task_label="master", use_cache=False)
