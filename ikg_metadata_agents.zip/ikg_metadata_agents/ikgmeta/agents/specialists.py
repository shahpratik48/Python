"""
Specialist agents. Each = prompt (prompts/agents/<name>.md) + tools + output schema + grounding check.

  SkillAgent            skills/*.md                 -> verified definitions, abbreviations, entity defs, rules
  DataDictionaryAgent   EDW dictionary + glossary    -> abbreviation meanings (NEEDS_INPUT when unknown)
  TableCatalogAgent     Greenplum catalogue/lineage  -> table notes, value profiles of flags/codes
  CodeAgent             GitLab repository code       -> table brief (purpose, grain, rules with SQL quotes)
  MetadataAuthorAgent   all of the above             -> functional name, description, confidence per column
  ReviewerAgent         all of the above             -> verdict / correction per column
  GraphAgent            knowledge graph              -> relationship + entity corrections, entity descriptions
"""
from __future__ import annotations

import json
import logging
import re
from typing import Dict, List

from pathlib import Path

from ..config import PACKAGE_ROOT
from ..glossary import tokenize
from .base import B, I, S, Agent, arr, norm_text, obj, quote_in
from . import tools as T

log = logging.getLogger(__name__)
PROMPT_DIR = PACKAGE_ROOT / "prompts" / "agents"

ATTRIBUTE_TYPES = ["identifier", "foreign_key", "name_text", "date", "amount", "quantity", "count", "percentage",
                   "ratio", "rate", "flag", "code", "category", "score", "rank", "text", "technical"]
DERIVATION = ["pass_through", "renamed", "derived", "aggregated", "windowed", "flag_rule", "lookup", "constant",
              "technical"]
EVIDENCE = ["sql_expression", "profile_sql", "upstream_sql", "lineage_db", "lineage_code", "edw_definition",
            "skill_file", "value_profile", "catalog", "table_brief", "glossary", "python_code"]


def _prompt(name: str) -> str:
    return (PROMPT_DIR / f"{name}.md").read_text(encoding="utf-8")


def _quoted(schema_props: dict) -> dict:
    return {**schema_props, "quote": S, "source_file": S}


# =============================================================================
class SkillAgent(Agent):
    name, max_steps = "skill_agent", 12
    SCHEMA = obj({
        "summary": S,
        "definitions": arr(obj(_quoted({"term": S, "definition": S}))),
        "abbreviations": arr(obj(_quoted({"abbreviation": S, "full_form": S}))),
        "entity_definitions": arr(obj(_quoted({"entity": S, "definition": S, "keys": arr(S)}))),
        "relationship_rules": arr(obj(_quoted({"from_entity": S, "label": S, "to_entity": S}))),
        "authoring_rules": arr(obj(_quoted({"rule": S}))),
        "code_values": arr(obj(_quoted({"column": S, "code": S, "meaning": S}))),
        "table_notes": arr(obj(_quoted({"table": S, "note": S}))),
    })

    def __init__(self, ctx):
        super().__init__(ctx, T.skill_tools(ctx), self.SCHEMA, _prompt("skill_agent"))

    def ground(self, r: dict, task: dict):
        lib, errs = self.ctx.skills, []
        ents = set(self.ctx.p.entity_model["entities"])
        clean = {"summary": r.get("summary", "")}
        for k in ("definitions", "abbreviations", "entity_definitions", "relationship_rules", "authoring_rules",
                  "code_values", "table_notes"):
            keep = []
            for it in r.get(k, []):
                f = lib.files.get(it.get("source_file", "")) or next(
                    (v for kk, v in lib.files.items() if kk.endswith(it.get("source_file", "") or "\0")), None)
                if not f or not quote_in(it.get("quote", ""), f["text"]):
                    errs.append(f"{k}: quote not found verbatim in '{it.get('source_file')}': {str(it.get('quote'))[:80]}")
                    continue
                if k == "entity_definitions" and it.get("entity") not in ents:
                    errs.append(f"entity_definitions: '{it.get('entity')}' is not an allowed entity {sorted(ents)}")
                    continue
                if k == "relationship_rules" and (it.get("from_entity") not in ents or it.get("to_entity") not in ents):
                    errs.append(f"relationship_rules: entities must be in {sorted(ents)}")
                    continue
                it["source_file"] = f["file"]
                keep.append(it)
            clean[k] = keep
        return clean, errs

    def execute(self) -> dict:
        lib = self.ctx.skills
        if not lib.files:
            log.info("No skill files found in %s", lib.folder)
            self.ctx.skills_brief = {"summary": "no skill files", "definitions": []}
            return self.ctx.skills_brief
        full = lib.total_chars() <= int(self.ctx.cfg.get("agents", {}).get("skills_full_text_chars", 150000))
        prefix = ("COMPLETE SKILL FILES:\n" + lib.full_text()) if full else None
        task = {"skill_files": lib.list(), "full_text_provided": full,
                "allowed_entities": list(self.ctx.p.entity_model["entities"]),
                "profile_tables": sorted(self.ctx.p.schemas)}
        self.ctx.skills_brief = self.run(task, prefix=prefix, task_label="skills")
        return self.ctx.skills_brief


# =============================================================================
class DataDictionaryAgent(Agent):
    name, max_steps, strict_grounding = "dictionary_agent", 5, False
    SCHEMA = obj({"tokens": arr(obj({
        "token": S, "full_form": S, "is_abbreviation": B, "confidence": I,
        "evidence_type": {"type": "string", "enum": ["edw_dictionary", "skill_file", "code", "industry_standard", "unknown"]},
        "evidence_quote": S, "reason": S}))})

    def __init__(self, ctx):
        tools = T.dictionary_tools(ctx) + T.skill_tools(ctx)[2:] + [t for t in T.code_tools(ctx) if t.name == "search_repo"]
        super().__init__(ctx, tools, self.SCHEMA, _prompt("dictionary_agent"))

    def ground(self, r: dict, task: dict):
        """Lenient: invalid quotes -> token downgraded to 'unknown' (kept as unconfirmed guess); missing tokens
        are added as unknown. Nothing is sent back for a fix round - precision is kept by the downgrade."""
        want = [t["token"] for t in task["tokens"]]
        errs, keep, got = [], [], {}
        for it in r.get("tokens", []):
            tok = str(it.get("token", "")).lower()
            if tok not in want or tok in got:
                continue
            et = it.get("evidence_type")
            if et in ("edw_dictionary", "skill_file", "code") and \
                    not quote_in(it.get("evidence_quote", ""), self.ctx.norm_corpus(et), 3, normalized=True):
                errs.append(f"{tok}: evidence_quote not found in {et} -> downgraded to unknown")
                it["evidence_type"], it["confidence"] = "unknown", min(int(it.get("confidence", 0) or 0), 50)
            if et == "industry_standard":
                it["confidence"] = min(int(it.get("confidence", 0) or 0), 85)
            got[tok] = it
        for tok in want:
            if tok not in got:
                errs.append(f"{tok}: no answer -> unknown")
                got[tok] = {"token": tok, "full_form": "UNKNOWN", "is_abbreviation": True, "confidence": 0,
                            "evidence_type": "unknown", "evidence_quote": "", "reason": "no answer from agent"}
        return {"tokens": [got[t] for t in want]}, errs

    def _evidence_for(self, tok: str) -> dict:
        """Prefetched evidence so the agent normally needs no tool calls."""
        p = self.ctx.p
        e = p.glossary.entries[tok]
        edw = p.edw_df
        hits = edw[edw.column_name.map(lambda c: tok in tokenize(c))].head(8)
        ev = {"token": tok, "current_guess": e["full_form"], "evidence_so_far": e["evidence"][:300],
              "example_profile_columns": e["example_columns"][:400]}
        if len(hits):
            ev["edw_columns_containing_token"] = [f"{r.column_name} = '{r.business_column_name}'"
                                                 + (f" - {r.column_definition[:120]}" if r.column_definition else "")
                                                 for r in hits.itertuples(index=False)]
        sk = self.ctx.skills.search(tok, k=2) if self.ctx.skills.files else []
        sk = [h for h in sk if re.search(rf"\b{re.escape(tok)}\b", h["text"], re.I)]
        if sk:
            ev["skill_passages"] = [f"[{h['file']}] {h['text'][:300]}" for h in sk]
        return ev

    def execute(self, batch: int = 50) -> dict:
        g = self.ctx.p.glossary
        todo = g.unresolved()
        log.info("Dictionary agent: %d unresolved tokens in %d batches", len(todo), (len(todo) + batch - 1) // batch)
        import concurrent.futures as cf
        chunks = [todo[i:i + batch] for i in range(0, len(todo), batch)]
        known = g.known_sample(120)

        def run(chunk):
            items = [self._evidence_for(t) for t in chunk]
            return self.run({"tokens": items, "known_abbreviations": known,
                             "note": "evidence is prefetched per token; call tools only when it is insufficient"},
                            task_label=f"tokens {chunk[0]}..{chunk[-1]}")
        applied = 0
        with cf.ThreadPoolExecutor(int(self.ctx.cfg.llm["parallel_calls"])) as ex:
            for fut in cf.as_completed([ex.submit(run, c) for c in chunks]):
                try:
                    res = fut.result()
                except Exception as e:  # noqa: BLE001
                    log.error("dictionary batch failed: %s", e)
                    continue
                for it in res.get("tokens", []):
                    e = g.entries.get(it["token"].lower())
                    if not e or e["source"] == "SME override":
                        continue
                    ff, et, conf = (it.get("full_form") or "").strip(), it.get("evidence_type"), int(it.get("confidence", 0) or 0)
                    ev = f"{e['evidence']} | agent[{et}]: {str(it.get('evidence_quote', ''))[:120]} - {it.get('reason', '')}".strip(" |")
                    if et == "unknown" or not ff or ff.upper() == "UNKNOWN":
                        e.update(status="NEEDS_INPUT", evidence=ev, confidence=min(conf, 50),
                                 full_form=ff if ff and ff.upper() != "UNKNOWN" else e["full_form"])
                        continue
                    e.update(full_form=ff, is_abbreviation=bool(it.get("is_abbreviation", True)), confidence=conf,
                             source=f"dictionary agent ({et})", evidence=ev,
                             status="RESOLVED" if conf >= 75 else "NEEDS_INPUT")
                    applied += 1
        self.ctx.p.refresh_glossary_columns()
        self.ctx.dictionary_notes = {"tokens_sent": len(todo), "resolved_by_agent": applied}
        return self.ctx.dictionary_notes


# =============================================================================
class TableCatalogAgent(Agent):
    name, max_steps, strict_grounding = "catalog_agent", 6, False
    SCHEMA = obj({"table": S, "grain_confirmed": S, "catalog_consistent_with_code": B, "notes": S,
                  "column_notes": arr(obj({"column": S, "note": S,
                                           "basis": {"type": "string", "enum": ["value_profile", "lineage", "catalog", "edw_definition"]}})),
                  "data_quality_flags": arr(S)})

    def __init__(self, ctx):
        tools = T.catalog_tools(ctx) + [t for t in T.dictionary_tools(ctx) if t.name in ("edw_lookup", "edw_table_columns")]
        super().__init__(ctx, tools, self.SCHEMA, _prompt("catalog_agent"))

    def ground(self, r: dict, task: dict):
        t = task["table"]
        cols = set(self.ctx.p.ctx[self.ctx.p.ctx.table_name == t].column_name)
        errs, keep = [], []
        for n in r.get("column_notes", []):
            c = str(n.get("column", "")).lower()
            if c not in cols:
                errs.append(f"column_notes: {c} is not a column of {t} - dropped")
                continue
            if n.get("basis") == "value_profile" and (t, c) not in self.ctx.value_profiles:
                n["basis"] = "catalog"
            n["column"] = c
            keep.append(n)
        r["column_notes"] = keep
        r["table"] = t
        return r, errs

    def execute(self, table: str) -> dict:
        tools = {t.name: t for t in self.tools.values()}
        catalog = tools["get_table_catalog"](table=table)
        cands = tools["list_columns_needing_values"](table=table)
        profiles = {}
        if self.ctx.p.gp is not None and len(self.ctx.p.col_types):
            n_max = int(self.ctx.cfg.get("agents", {}).get("value_profile_max_columns", 12))
            ev = self.ctx.p.ctx
            # profile first the candidates with no EDW definition (meaning least known)
            def rank(c):
                r = ev[(ev.table_name == table) & (ev.column_name == c["column_name"])]
                return 0 if (len(r) and r.iloc[0].edw_match == "none") else 1
            for c in sorted(cands, key=rank)[:n_max]:
                profiles[c["column_name"]] = T.value_profile(self.ctx, table, c["column_name"])
        task = {"table": table, "catalog": catalog, "flag_and_code_columns": cands,
                "value_profiles_prefetched": profiles,
                "value_profiling_available": self.ctx.p.gp is not None and len(self.ctx.p.col_types) > 0,
                "note": "catalogue and value profiles are prefetched; call tools only for additional columns"}
        out = self.run(task, task_label=table)
        self.ctx.catalog_notes[table] = {**out, "column_notes": {n["column"]: f"{n['note']} [{n['basis']}]"
                                                                for n in out.get("column_notes", [])}}
        return out


# =============================================================================
class CodeAgent(Agent):
    name, max_steps = "code_agent", 10
    SCHEMA = obj({
        "table_purpose": S, "grain": S, "population": S,
        "key_business_rules": arr(obj({"rule": S, "sql_quote": S})),
        "time_windows": arr(obj({"token": S, "meaning": S, "sql_quote": S})),
        "data_sources": arr(S),
        "column_groups": arr(obj({"columns_like": S, "meaning": S})),
        "caveats": arr(S)})

    def __init__(self, ctx):
        tools = T.code_tools(ctx) + [t for t in T.catalog_tools(ctx) if t.name in ("get_lineage",)]
        super().__init__(ctx, tools, self.SCHEMA, _prompt("code_agent"))

    def ground(self, r: dict, task: dict):
        corpus, errs = self.ctx.norm_corpus("code"), []
        for k in ("key_business_rules", "time_windows"):
            keep = []
            for it in r.get(k, []):
                if quote_in(it.get("sql_quote", ""), corpus, 8, normalized=True):
                    keep.append(it)
                else:
                    errs.append(f"{k}: sql_quote not found verbatim in repository SQL: {str(it.get('sql_quote'))[:80]}")
            r[k] = keep
        return r, errs

    def _upstream_scripts(self, table: str) -> str:
        """First-level upstream IKG scripts (prefetched so the agent rarely needs read_sql_file)."""
        p = self.ctx.p
        cap_total = int(self.ctx.cfg.get("agents", {}).get("upstream_prefetch_chars", 60000))
        root = p.gitlab.root
        parts, used, seen = [], 0, set()
        for _, t in sorted(p.code.from_tables(table)):
            for w in p.code.writers.get(t, [])[:1]:
                if w.file in seen or t == table:
                    continue
                seen.add(w.file)
                try:
                    txt = Path(w.file).read_text(encoding="utf-8", errors="replace")
                except OSError:
                    continue
                rel = str(Path(w.file).relative_to(root)) if str(w.file).startswith(str(root)) else w.file
                chunk = txt[:20000] + ("\n-- [truncated - use read_sql_file for the rest]" if len(txt) > 20000 else "")
                if used + len(chunk) > cap_total:
                    parts.append(f"-- (more upstream scripts not prefetched: use find_table_writers / read_sql_file)")
                    break
                parts.append(f"===== UPSTREAM SCRIPT {rel} (writes {t}) =====\n{chunk}")
                used += len(chunk)
        return "\n\n".join(parts)

    def execute(self, table: str) -> dict:
        prefix = self.ctx.p._table_prefix(table, with_analysis=False)
        up = self._upstream_scripts(table)
        if up:
            prefix += "\n\nFIRST-LEVEL UPSTREAM SCRIPTS (prefetched):\n" + up
        note = self.ctx.catalog_notes.get(table)
        sk = [n for n in self.ctx.skills_brief.get("table_notes", []) if n.get("table", "").lower() == table]
        task = {"table": table, "catalog_agent_notes": {k: v for k, v in (note or {}).items() if k != "column_notes"},
                "skill_notes": sk}
        out = self.run(task, prefix=prefix, task_label=table)
        self.ctx.table_briefs[table] = out
        self.ctx.p.table_analysis[table] = {
            "table_purpose": out.get("table_purpose"), "grain": out.get("grain"), "population": out.get("population"),
            "key_business_rules": [x["rule"] for x in out.get("key_business_rules", [])],
            "time_windows": [f"{x['token']}: {x['meaning']}" for x in out.get("time_windows", [])],
            "data_sources": out.get("data_sources", []), "column_groups": out.get("column_groups", []),
            "caveats": out.get("caveats", [])}
        return out


# =============================================================================
class MetadataAuthorAgent(Agent):
    name, max_steps = "author_agent", 8
    SCHEMA = obj({"columns": arr(obj({
        "id": S, "functional_name": S, "business_description": S, "entity": S,
        "attribute_type": {"type": "string", "enum": ATTRIBUTE_TYPES},
        "derivation_type": {"type": "string", "enum": DERIVATION}, "unit": S,
        "llm_confidence": I, "confidence_reason": S, "difficult_to_generate": B, "what_is_required": S,
        "unresolved_abbreviations": arr(S), "evidence_used": arr({"type": "string", "enum": EVIDENCE})}))})

    def __init__(self, ctx):
        tools = (T.evidence_tools(ctx) + T.code_tools(ctx) + T.dictionary_tools(ctx)[:3] + T.skill_tools(ctx)[1:] +
                 [t for t in T.catalog_tools(ctx) if t.name in ("profile_column_values", "lineage_rows")])
        super().__init__(ctx, tools, self.SCHEMA, _prompt("author_agent"))

    def ground(self, r: dict, task: dict):
        return ground_columns(self.ctx, r, task, review=False)

    def execute(self, table: str, columns: List[str], instructions: str = "", label: str = "") -> List[dict]:
        p = self.ctx.p
        items = []
        for i, c in enumerate(columns, 1):
            ev = self.ctx.evidence(table, c)
            ev.pop("table_name", None)
            items.append({"id": f"c{i:03d}", "column": c, **{k: v for k, v in ev.items() if k != "column_name"}})
        rel = {t: p.glossary.entries[t]["full_form"] for c in columns for t in tokenize(c)
               if t in p.glossary.entries and p.glossary.entries[t]["status"] == "RESOLVED"
               and p.glossary.entries[t]["is_abbreviation"]}
        existing = sorted({v["functional_name"] for (t, c), v in self.ctx.results.items()
                           if t == table and c not in columns and v.get("functional_name")})
        task = {"table": table, "glossary_for_these_columns": rel, "columns": items,
                "functional_names_already_used_in_table": existing[:400]}
        if instructions:
            task["additional_instructions"] = instructions
        if instructions:
            self.max_steps = 12          # escalation: more room for tool use
        out = self.run(task, prefix=self.ctx.table_prefix(table), task_label=label or f"{table} {columns[0]}..")
        return map_columns(self.ctx, table, columns, out.get("columns", []))


class ReviewerAgent(Agent):
    name, max_steps = "reviewer_agent", 6
    SCHEMA = obj({"columns": arr(obj({
        "id": S, "verdict": {"type": "string", "enum": ["correct", "revised", "insufficient_evidence"]},
        "functional_name": S, "business_description": S, "llm_confidence": I, "issues": S, "what_is_required": S}))})

    def __init__(self, ctx):
        tools = (T.evidence_tools(ctx) + T.code_tools(ctx) + T.dictionary_tools(ctx)[:3] + T.skill_tools(ctx)[1:] +
                 [t for t in T.catalog_tools(ctx) if t.name in ("profile_column_values",)])
        super().__init__(ctx, tools, self.SCHEMA, _prompt("reviewer_agent"))

    def ground(self, r: dict, task: dict):
        return ground_columns(self.ctx, r, task, review=True)

    def execute(self, table: str, columns: List[str]) -> List[dict]:
        items = []
        for i, c in enumerate(columns, 1):
            ev = self.ctx.evidence(table, c)
            d = self.ctx.results.get((table, c), {})
            items.append({"id": f"c{i:03d}", "column": c, "evidence": {k: v for k, v in ev.items() if k not in ("table_name", "column_name")},
                          "draft": {k: d.get(k) for k in ("functional_name", "business_description", "entity", "attribute_type",
                                                          "unit", "llm_confidence", "what_is_required_llm")}})
        out = self.run({"table": table, "columns": items}, prefix=self.ctx.table_prefix(table),
                       task_label=f"review {table} {columns[0]}..")
        by = {x["id"]: x for x in out.get("columns", [])}
        res = []
        for i, c in enumerate(columns, 1):
            x = by.get(f"c{i:03d}")
            if x:
                res.append({"table_name": table, "column_name": c, **x})
        return res


def ground_columns(ctx, r: dict, task: dict, review: bool):
    ids = [c["id"] for c in task["columns"]]
    by = {str(x.get("id")): x for x in r.get("columns", [])}
    errs = []
    missing = [i for i in ids if i not in by]
    if missing:
        errs.append(f"missing ids: {missing}")
    ents = set(ctx.p.entity_model["entities"])
    names = {}
    used = set(n.lower() for n in task.get("functional_names_already_used_in_table", []))
    for c in task["columns"]:
        x = by.get(c["id"])
        if not x:
            continue
        nm = (x.get("functional_name") or "").strip()
        desc = (x.get("business_description") or "").strip()
        if not nm or not desc:
            errs.append(f"{c['id']} {c['column']}: functional_name and business_description are required")
        if not review and x.get("entity") not in ents:
            errs.append(f"{c['id']}: entity '{x.get('entity')}' not allowed {sorted(ents)}")
        unres = [t for t in str(c.get("unresolved_tokens", "")).split(", ") if t]
        bad = [t for t in unres if re.search(rf"\b{re.escape(t)}\b", nm, re.I)]
        if bad:
            errs.append(f"{c['id']}: functional_name contains unresolved abbreviation(s) {bad} - describe generically")
        if re.match(r"^\s*(this|the) (column|field|attribute)\b", desc, re.I):
            errs.append(f"{c['id']}: description must not start with 'This column/field'")
        key = nm.lower()
        if key and (key in names or key in used):
            errs.append(f"{c['id']}: functional_name '{nm}' duplicates another column ({names.get(key, 'already used in table')}) - make it distinguishing")
        names[key] = c["column"]
    return r, errs


def map_columns(ctx, table, columns, items) -> List[dict]:
    by = {str(x.get("id")): x for x in items}
    out = []
    for i, c in enumerate(columns, 1):
        x = by.get(f"c{i:03d}", {})
        out.append({"table_name": table, "column_name": c,
                    "functional_name": (x.get("functional_name") or "").strip(),
                    "business_description": (x.get("business_description") or "").strip(),
                    "entity": x.get("entity", ""), "attribute_type": x.get("attribute_type", ""),
                    "derivation_type": x.get("derivation_type", ""), "unit": x.get("unit", ""),
                    "llm_confidence": int(x.get("llm_confidence") or 0),
                    "confidence_reason": x.get("confidence_reason", "") if x else "author agent returned no result",
                    "difficult_to_generate": bool(x.get("difficult_to_generate", not x)),
                    "what_is_required_llm": x.get("what_is_required", "") or "",
                    "unresolved_abbreviations_llm": ", ".join(x.get("unresolved_abbreviations") or []),
                    "evidence_used": ", ".join(x.get("evidence_used") or []),
                    "verify_verdict": "", "verify_issues": ""})
    return out


# =============================================================================
class GraphAgent(Agent):
    name, max_steps, strict_grounding = "graph_agent", 8, False
    SCHEMA = obj({
        "relationship_changes": arr(obj({"from_entity": S, "to_entity": S, "label": S,
                                         "action": {"type": "string", "enum": ["keep", "relabel", "remove", "add"]},
                                         "new_label": S, "evidence": S, "reason": S})),
        "relationship_descriptions": arr(obj({"from_entity": S, "label": S, "to_entity": S, "description": S})),
        "entity_descriptions": arr(obj({"entity": S, "description": S})),
        "summary": S})

    def __init__(self, ctx, kg):
        self.kg = kg
        tools = T.graph_tools(ctx, kg) + T.skill_tools(ctx)[2:] + [t for t in T.code_tools(ctx) if t.name == "list_profile_columns"]
        super().__init__(ctx, tools, self.SCHEMA, _prompt("graph_agent"))

    def ground(self, r: dict, task: dict):
        ents = set(self.ctx.p.entity_model["entities"])
        cur = {(v["from"], v["to"]) for v in self.kg.rels.values()} | {(v["to"], v["from"]) for v in self.kg.rels.values()}
        errs, keep = [], []
        for ch in r.get("relationship_changes", []):
            a, b = ch.get("from_entity"), ch.get("to_entity")
            if a not in ents or b not in ents:
                errs.append(f"unknown entity in {a}->{b}")
                continue
            if ch["action"] in ("relabel", "remove") and (a, b) not in cur:
                errs.append(f"{ch['action']} {a}->{b}: relationship does not exist")
                continue
            if ch["action"] == "add":
                m = re.match(r"\s*([a-z0-9_]+)\s*\.\s*([a-z0-9_]+)", str(ch.get("evidence", "")).lower())
                ok = bool(m) and ((self.ctx.p.ctx.table_name == m.group(1)) & (self.ctx.p.ctx.column_name == m.group(2))).any()
                if not ok:
                    errs.append(f"add {a}->{b}: evidence must start with an existing profile 'table.column' carrying the key")
                    continue
            keep.append(ch)
        r["relationship_changes"] = keep
        r["entity_descriptions"] = [d for d in r.get("entity_descriptions", []) if d.get("entity") in ents]
        return r, errs

    def execute(self) -> dict:
        task = {"relationships": self.kg.relationships_frame().to_dict("records"),
                "entities": {e: {"attributes": sum(1 for (x, _), a in self.kg.attrs.items() if x == e and not a["is_technical"])}
                             for e in self.ctx.p.entity_model["entities"]},
                "skill_relationship_rules": self.ctx.skills_brief.get("relationship_rules", []),
                "skill_entity_definitions": self.ctx.skills_brief.get("entity_definitions", [])}
        out = self.run(task, task_label="graph")
        self.ctx.graph_review = out
        return out
