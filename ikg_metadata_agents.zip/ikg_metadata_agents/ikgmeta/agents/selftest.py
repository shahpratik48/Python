"""
Offline self-test: a scripted stand-in for the LLM that speaks the tool-calling protocol.
It exercises every agent, every tool round-trip, schema/grounding rejection + correction, the master's
gates and the output writers - WITHOUT network or tokens. Output content is placeholder text.

    python run_pipeline.py --selftest       (uses your real sources; no Azure calls)
"""
from __future__ import annotations

import itertools
import json
import re
from types import SimpleNamespace as NS

from ..llm import LLM

_ids = itertools.count(1)


def _call(name, args):
    return NS(id=f"call_{next(_ids)}", type="function", function=NS(name=name, arguments=json.dumps(args)))


def _msg(calls=None, content=""):
    return NS(content=content, tool_calls=calls or None)


class ScriptedLLM(LLM):
    def check(self):
        return "OK (scripted self-test model)"

    def chat(self, messages, tools=None, tool_choice="auto", reasoning_effort=None):
        with self._lock:
            self.usage["calls"] += 1
        system = messages[0]["content"]
        role = re.search(r"# Role: (\w[\w-]*)", system).group(1).lower()
        task = next((json.loads(m["content"][5:]) for m in messages if m["role"] == "user"
                     and str(m["content"]).startswith("TASK:")), {})
        prefix = next((m["content"] for m in messages[1:2] if m["role"] == "user" and not m["content"].startswith("TASK:")), "")
        tool_msgs = [m for m in messages if m["role"] == "tool"]
        rejected = sum(1 for m in tool_msgs if str(m["content"]).startswith("REJECTED"))
        names = {t["function"]["name"] for t in tools or []}
        forced = isinstance(tool_choice, dict)
        fn = getattr(self, f"_{role.replace('-', '_')}", None)
        return fn(task, prefix, tool_msgs, rejected, names, forced, messages)

    # ------------------------------------------------------------------ agents
    def _master(self, task, prefix, tool_msgs, rejected, names, forced, messages):
        order = ["run_skill_agent", "run_dictionary_agent", "run_author_agent", "run_table_pipelines",
                 "quality_report", "run_graph_agent", "write_outputs"]
        # (the first run_author_agent is deliberately premature -> must be refused by the gate)
        n = len(tool_msgs)
        if n < len(order) and not forced:
            return _msg([_call(order[n], {})])
        return _msg([_call("submit_result", {"summary": "self-test run complete", "open_issues": ["placeholder"]})])

    def _skill(self, task, prefix, tool_msgs, rejected, names, forced, messages):
        if not prefix and not tool_msgs:
            return _msg([_call("list_skills", {})])
        text = prefix or "\n".join(m["content"] for m in tool_msgs)
        files = re.findall(r"===== SKILL FILE: (.+?) =====\n(.*?)(?======|\Z)", text, re.S)
        defs = []
        for f, body in files:
            sent = next((s.strip() for s in re.split(r"(?<=\.)\s", body) if len(s.strip()) > 40), "")
            if sent:
                defs.append({"term": f.rsplit(".", 1)[0], "definition": sent[:200], "quote": sent[:120], "source_file": f})
        if rejected == 0 and defs:      # first submission contains one fabricated quote -> must be rejected
            defs.append({"term": "fake", "definition": "x", "quote": "this sentence does not exist anywhere", "source_file": files[0][0]})
        abbr = [{"abbreviation": "shh", "full_form": "Statement Household", "quote": "shh = Statement Household",
                 "source_file": f} for f, b in files if "shh = Statement Household" in b]
        cdefs = [{"column": "acc_mhh_n", "definition": "Statement household identifier sourced from household_plus; not the marketing household",
                  "quote": "acc_mhh_n = statement household (sourced from household_plus), not the marketing household", "source_file": f}
                 for f, b in files if "acc_mhh_n = statement household" in b]
        cdefs.append({"column": "no_such_col", "definition": "x", "quote": "acc_mhh_n = statement household", "source_file": files[0][0] if files else ""})
        return _msg([_call("submit_result", {"summary": "skills read", "definitions": defs, "abbreviations": abbr, "column_definitions": cdefs,
                                             "entity_definitions": [], "relationship_rules": [], "authoring_rules":
                                             [{"rule": "Flags end with the word Indicator", "quote": "Flags end with the word Indicator",
                                               "source_file": f} for f, b in files if "Flags end with the word Indicator" in b],
                                             "code_values": [], "table_notes": []})])

    def _data_dictionary(self, task, prefix, tool_msgs, rejected, names, forced, messages):
        # reproduces the production failure: keeps calling tools until the step budget forces a submit,
        # then submits with some unverifiable quotes -> lenient grounding must downgrade + accept (no exception)
        toks = task.get("tokens", [])
        if not forced and toks:
            return _msg([_call("token_usage", {"token": toks[len(tool_msgs) % len(toks)]["token"]})])
        out = []
        for i, t in enumerate(toks):
            if i % 3 == 0:
                out.append({"token": t["token"], "full_form": "Bogus Expansion", "is_abbreviation": True, "confidence": 95,
                            "evidence_type": "edw_dictionary", "evidence_quote": "quote that does not exist", "reason": "bad"})
            elif i % 3 == 1:
                out.append({"token": t["token"], "full_form": f"{t['token'].title()} (test)", "is_abbreviation": True,
                            "confidence": 80, "evidence_type": "industry_standard", "evidence_quote": "", "reason": "self-test"})
            # i % 3 == 2 -> omitted on purpose: must be filled as unknown
        return _msg([_call("submit_result", {"tokens": out})])

    def _table_catalog(self, task, prefix, tool_msgs, rejected, names, forced, messages):
        t = task["table"]
        notes = [{"column": c, "note": "self-test note", "basis": "value_profile"} for c in list(task.get("value_profiles_prefetched", {}))[:2]]
        notes.append({"column": "no_such_column", "note": "must be dropped", "basis": "catalog"})
        return _msg([_call("submit_result", {"table": t, "grain_confirmed": "self-test", "catalog_consistent_with_code": True,
                                             "notes": "self-test", "column_notes": notes, "data_quality_flags": []})])

    def _code(self, task, prefix, tool_msgs, rejected, names, forced, messages):
        t = task["table"]
        if not tool_msgs:
            return _msg([_call("list_profile_columns", {"table": t})])
        sql = prefix.split("COMPLETE CREATE SCRIPT", 1)[-1]
        line = next((ln.strip() for ln in sql.splitlines()[2:] if len(ln.strip()) > 20), "")
        return _msg([_call("submit_result", {"table_purpose": f"self-test brief of {t}", "grain": "self-test",
                                             "population": "self-test",
                                             "key_business_rules": [{"rule": "self-test rule", "sql_quote": line[:60]}],
                                             "time_windows": [], "data_sources": [], "column_groups": [], "caveats": []})])

    def _metadata(self, task, prefix, tool_msgs, rejected, names, forced, messages):
        cols = task["columns"]
        if not tool_msgs and cols:
            return _msg([_call("get_column_evidence", {"table": task["table"], "column": cols[0]["column"]})])
        out = [{"id": c["id"], "functional_name": f"Test {c['column']}", "business_description": f"Self-test description of {c['column']}.",
                "entity": "Household", "attribute_type": "amount", "derivation_type": "derived", "unit": "USD",
                "llm_confidence": [95, 85, 70, 45][i % 4], "confidence_reason": "self-test", "difficult_to_generate": False,
                "what_is_required": "", "unresolved_abbreviations": [], "evidence_used": ["sql_expression", "lineage_db"]}
               for i, c in enumerate(cols)]
        return _msg([_call("submit_result", {"columns": out})])

    def _reviewer(self, task, prefix, tool_msgs, rejected, names, forced, messages):
        out = [{"id": c["id"], "verdict": "revised", "functional_name": c["draft"]["functional_name"] + " Reviewed",
                "business_description": c["draft"]["business_description"], "llm_confidence": 88, "issues": "self-test",
                "what_is_required": ""} for c in task["columns"]]
        return _msg([_call("submit_result", {"columns": out})])

    def _graph(self, task, prefix, tool_msgs, rejected, names, forced, messages):
        if not tool_msgs:
            return _msg([_call("list_relationships", {})])
        rels = task.get("relationships", [])
        return _msg([_call("submit_result", {
            "relationship_changes": [{"from_entity": r["from_entity"], "to_entity": r["to_entity"], "label": r["relationship"],
                                      "action": "keep", "new_label": "", "evidence": "", "reason": "self-test"} for r in rels],
            "relationship_descriptions": [{"from_entity": r["from_entity"], "label": r["relationship"], "to_entity": r["to_entity"],
                                           "description": "self-test description"} for r in rels],
            "entity_descriptions": [], "summary": "self-test"})])
