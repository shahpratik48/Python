"""Shared context (blackboard) for all agents: config, LLM, trace, deterministic data layer, knowledge."""
from __future__ import annotations

import json
import logging
import threading
from typing import Dict, Optional, Tuple

from ..skills import SkillLibrary
from .base import Trace

log = logging.getLogger(__name__)


class AgentContext:
    def __init__(self, cfg, llm, pipeline):
        self.cfg = cfg
        self.llm = llm
        self.p = pipeline                      # MetadataPipeline = deterministic data layer
        self.trace = Trace()
        self.lock = threading.Lock()
        self.skills = SkillLibrary(cfg.path(cfg.get("skills", {}).get("folder", "skills")))
        # ---- knowledge written by agents (verified) ----
        self.skills_brief: dict = {}
        self.dictionary_notes: dict = {}
        self.table_briefs: Dict[str, dict] = {}
        self.catalog_notes: Dict[str, dict] = {}
        self.value_profiles: Dict[Tuple[str, str], str] = {}
        self.results: Dict[Tuple[str, str], dict] = {}
        self.reviews: Dict[Tuple[str, str], dict] = {}
        self.graph_review: dict = {}
        self.stage_done: Dict[str, bool] = {}
        self.escalations: Dict[Tuple[str, str], int] = {}

    # ---------------------------------------------------------------- shared prompt context
    def entities_text(self) -> str:
        em = self.p.entity_model["entities"]
        ents = self.skills_brief.get("entity_definitions") or []
        extra = {e["entity"]: e["definition"] for e in ents if e.get("entity") in em}
        return "\n".join(f"- {k}: {extra.get(k) or v.get('description', '')}" for k, v in em.items())

    def shared_context(self) -> str:
        """Verified firm knowledge every agent sees (stable text -> prompt cache friendly)."""
        parts = ["ALLOWED ENTITIES:\n" + self.entities_text()]
        defs = self.skills_brief.get("definitions") or []
        if defs:
            parts.append("FIRM DEFINITIONS (verified from skill files):\n" +
                         "\n".join(f"- {d['term']}: {d['definition']}  [{d['source_file']}]" for d in defs[:80]))
        if self.p.skill_column_defs:
            parts.append("AUTHORITATIVE COLUMN DEFINITIONS (skill files / SME; apply in every table, override any "
                         "name-based guess):\n" + "\n".join(f"- {c}: {d}" for c, d in sorted(self.p.skill_column_defs.items())[:120]))
        if self.p.business_defs:
            parts.append("FIRM DEFINITIONS (config/business_definitions.md):\n" + self.p.business_defs[:6000])
        rules = self.skills_brief.get("authoring_rules") or []
        if rules:
            parts.append("METADATA AUTHORING RULES (from skill files - follow them):\n" +
                         "\n".join(f"- {r['rule']}" for r in rules[:40]))
        return "\n\n".join(parts)

    # ---------------------------------------------------------------- evidence pack
    def evidence(self, table: str, column: str) -> dict:
        ctx = self.p.ctx
        r = ctx[(ctx.table_name == table) & (ctx.column_name == column)]
        if r.empty:
            return {"error": f"{table}.{column} not found"}
        r = r.iloc[0].to_dict()
        keep = ["table_name", "column_name", "data_type", "sql_expression", "select_alias", "lineage_db",
                "lineage_code", "filters", "terminal_sources", "source_definitions", "abbreviations",
                "unresolved_tokens", "code_values", "python_code", "is_technical", "lineage_stopped_at"]
        ev = {k: r[k] for k in keep if r.get(k) not in ("", None, False)}
        sd = self.p.skill_column_defs.get(column)
        if sd:
            ev["AUTHORITATIVE_skill_definition"] = sd
        vp = self.value_profiles.get((table, column))
        if vp:
            ev["value_profile"] = vp
        notes = (self.catalog_notes.get(table) or {}).get("column_notes", {})
        if column in notes:
            ev["catalog_note"] = notes[column]
        return ev

    def reasoning_effort(self, agent: str):
        eff = (self.cfg.get("agents", {}).get("reasoning_effort") or {})
        return eff.get(agent.replace("_agent", "")) or eff.get("default") or self.cfg.llm.get("reasoning_effort")

    def norm_corpus(self, kind: str) -> str:
        """Normalised text of a large corpus, computed once (quote checks run against it)."""
        from .base import norm_text
        cache = self.__dict__.setdefault("_norm", {})
        if kind not in cache:
            if kind == "code":
                txt = self.repo_text()
            elif kind == "edw_dictionary":
                e = self.p.edw_df
                txt = " | ".join((e.column_name + " " + e.business_column_name + " " + e.column_definition).tolist())
            elif kind == "skill_file":
                txt = self.skills.full_text()
            else:
                txt = ""
            cache[kind] = norm_text(txt)
        return cache[kind]

    def repo_text(self) -> str:
        """All repository SQL text (for verifying SQL quotes)."""
        if getattr(self, "_repo_text", None) is None:
            root = self.p.gitlab.sql_root()
            self._repo_text = "\n".join(f.read_text(encoding="utf-8", errors="replace") for f in sorted(root.rglob("*.sql")))
        return self._repo_text

    def table_prefix(self, table: str) -> str:
        """Stable per-table context: catalogue, code-agent brief, catalog notes, skill notes, full SQL."""
        cap = int(self.cfg.get("agents", {}).get("author_sql_chars", 40000))
        parts = [self.p._table_prefix(table, with_analysis=True, max_chars=cap)]
        cn = self.catalog_notes.get(table)
        if cn:
            parts.insert(0, "TABLE CATALOG AGENT NOTES:\n" + json.dumps({k: v for k, v in cn.items() if k != "column_notes"},
                                                                        ensure_ascii=False, default=str))
        sk = [n for n in self.skills_brief.get("table_notes", []) if n.get("table", "").lower() == table]
        if sk:
            parts.insert(0, "SKILL NOTES FOR THIS TABLE:\n" + "\n".join(f"- {n['note']} [{n['source_file']}]" for n in sk))
        return "\n\n".join(parts)

    def mark(self, stage: str) -> None:
        self.stage_done[stage] = True
        log.info("stage complete: %s", stage)

    def to_json(self, x) -> str:
        return json.dumps(x, ensure_ascii=False, default=str)
