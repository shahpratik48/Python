"""
Architecture / flow diagrams for ODM and NLG, exported as separate offline HTML pages (SVG drawn here, no
external library) and linked from the knowledge-graph viewer:

    diagrams/index.html
    diagrams/odm_architecture.html            ODM rule engine (DAGs, rule folders, tables, exclusion, archive)
    diagrams/nlg_architecture.html            NLG end to end (inputs -> rules -> narratives -> products -> delivery)
    diagrams/narratives_client_rules.html     how a client / household narrative is produced
    diagrams/narratives_fl_rules.html         Field-Leader narratives
    diagrams/narratives_prospect_rules.html   prospect narratives
    diagrams/product_<name>.html              one page per NLG product (client briefing, FA alerts, ...)

Table names are taken from nlg_db_tables.ini (the section of the current ENV) when the NLG repository was loaded,
and every page lists the tables with the attribute descriptions produced by this run / already published.
"""
from __future__ import annotations

import html
import json
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

log = logging.getLogger(__name__)

COLORS = {            # kind -> (fill, stroke, text)
    "source": ("#dbeafe", "#2563eb", "#1e3a8a"),
    "odm": ("#ffedd5", "#ea580c", "#7c2d12"),
    "nlg": ("#dcfce7", "#16a34a", "#14532d"),
    "process": ("#e2e8f0", "#475569", "#0f172a"),
    "table": ("#f8fafc", "#94a3b8", "#0f172a"),
    "product": ("#ede9fe", "#7c3aed", "#3b0764"),
    "delivery": ("#ccfbf1", "#0d9488", "#134e4a"),
    "config": ("#fef9c3", "#ca8a04", "#713f12"),
    "warn": ("#fee2e2", "#dc2626", "#7f1d1d"),
}
NODE_W, LANE_GAP, NODE_GAP, PAD_TOP, LINE_H = 236, 110, 18, 56, 16


@dataclass
class Node:
    id: str
    label: str
    kind: str = "process"
    sub: str = ""                       # smaller second text (table name, file ...)
    mono: bool = False


@dataclass
class Diagram:
    name: str
    title: str
    description: str
    lanes: List[Tuple[str, List[Node]]]
    edges: List[Tuple[str, str, str]] = field(default_factory=list)     # (from, to, label)
    notes: List[str] = field(default_factory=list)
    tables: List[Tuple[str, str]] = field(default_factory=list)          # (schema.table, role)
    examples: List[Tuple[str, str]] = field(default_factory=list)        # (title, code)
    group: str = "NLG"

    # ------------------------------------------------------------------ mermaid (markdown)
    def mermaid(self) -> str:
        out = ["flowchart LR"]
        kinds = {}
        for li, (title, nodes) in enumerate(self.lanes):
            out.append(f'  subgraph L{li}["{_mm(title)}"]')
            out.append("    direction TB")
            for n in nodes:
                lab = _mm(n.label) + (f"<br/><i>{_mm(n.sub)}</i>" if n.sub else "")
                out.append(f'    {n.id}["{lab}"]')
                kinds.setdefault(n.kind, []).append(n.id)
            out.append("  end")
        for a, b, lab in self.edges:
            out.append(f'  {a} -->|{_mm(lab)}| {b}' if lab else f"  {a} --> {b}")
        for kind, ids in kinds.items():
            fill, stroke, col = COLORS.get(kind, COLORS["process"])
            out.append(f"  classDef {kind} fill:{fill},stroke:{stroke},color:{col};")
            out.append(f"  class {','.join(ids)} {kind};")
        return "\n".join(out)

    def markdown(self, attr_rows=None) -> str:
        """The page as markdown: title, description, mermaid diagram (lines), key points, tables, examples."""
        md = [f"# {self.title}", "", self.description, "", "```mermaid", self.mermaid(), "```", ""]
        if self.notes:
            md += ["## Key points", ""] + [f"- {n}" for n in self.notes] + [""]
        if self.tables:
            md += ["## Tables involved", "", "| table | role | attribute metadata |", "| --- | --- | --- |"]
            for t, role in self.tables:
                attrs = (attr_rows or {}).get(t.split(".")[-1], [])
                desc = "; ".join(f"`{a['column_name']}` {a.get('functional_name', '')}" for a in attrs[:5])
                if len(attrs) > 5:
                    desc += f"; ... {len(attrs)} attributes"
                md.append(f"| `{t}` | {role} | {desc or '-'} |")
            md.append("")
        for t, code in self.examples:
            md += [f"## {t}", "", "```sql" if "select" in code.lower() or "insert" in code.lower() else "```yaml", code, "```", ""]
        return "\n".join(md)

    # ------------------------------------------------------------------ svg
    def svg(self) -> str:
        pos: Dict[str, Tuple[float, float, float, float]] = {}
        lane_x = 20.0
        heights = []
        texts: Dict[str, List[str]] = {}
        for _, nodes in self.lanes:
            y = PAD_TOP
            for n in nodes:
                lines = _wrap(n.label, 26)
                if n.sub:
                    lines += [f" {l}" for l in _wrap(n.sub, 30)]
                texts[n.id] = lines
                h = 14 + LINE_H * len(lines)
                pos[n.id] = (lane_x, y, NODE_W, h)
                y += h + NODE_GAP
            heights.append(y)
            lane_x += NODE_W + LANE_GAP
        width, height = lane_x - LANE_GAP + 20, max(heights + [200]) + 20
        out = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width:.0f} {height:.0f}" width="100%" '
               f'style="max-width:{width:.0f}px;font-family:Helvetica,Arial,sans-serif;font-size:12px">',
               '<defs><marker id="arr" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="8" markerHeight="8" orient="auto-start-reverse">'
               '<path d="M 0 0 L 10 5 L 0 10 z" fill="#475569"/></marker></defs>']
        # lanes
        x = 20.0
        for title, nodes in self.lanes:
            out.append(f'<rect x="{x - 8}" y="8" width="{NODE_W + 16}" height="{height - 16}" rx="10" fill="#f1f5f9" stroke="#e2e8f0"/>')
            out.append(f'<text x="{x + NODE_W / 2}" y="32" text-anchor="middle" font-weight="700" font-size="13" fill="#334155">{html.escape(title)}</text>')
            x += NODE_W + LANE_GAP
        # edges (behind nodes)
        for a, b, lab in self.edges:
            if a not in pos or b not in pos:
                continue
            ax, ay, aw, ah = pos[a]
            bx, by, bw, bh = pos[b]
            if abs(ax - bx) < 1:                                    # same lane: vertical
                if by > ay:
                    p1, p2 = (ax + aw / 2, ay + ah), (bx + bw / 2, by)
                    d = f"M {p1[0]:.0f} {p1[1]:.0f} L {p2[0]:.0f} {p2[1]:.0f}"
                else:                                               # upwards: curve along the left side
                    p1, p2 = (ax - 4, ay + ah / 2), (bx - 4, by + bh / 2)
                    d = f"M {p1[0]:.0f} {p1[1]:.0f} C {p1[0] - 46:.0f} {p1[1]:.0f} {p2[0] - 46:.0f} {p2[1]:.0f} {p2[0]:.0f} {p2[1]:.0f}"
            elif bx > ax:
                p1, p2 = (ax + aw, ay + ah / 2), (bx, by + bh / 2)
                dx = (p2[0] - p1[0]) / 2
                d = f"M {p1[0]:.0f} {p1[1]:.0f} C {p1[0] + dx:.0f} {p1[1]:.0f} {p2[0] - dx:.0f} {p2[1]:.0f} {p2[0]:.0f} {p2[1]:.0f}"
            else:                                                  # backwards
                p1, p2 = (ax, ay + ah / 2), (bx + bw, by + bh / 2)
                dx = (p1[0] - p2[0]) / 2
                d = f"M {p1[0]:.0f} {p1[1]:.0f} C {p1[0] - dx:.0f} {p1[1] + 30:.0f} {p2[0] + dx:.0f} {p2[1] + 30:.0f} {p2[0]:.0f} {p2[1]:.0f}"
            out.append(f'<path d="{d}" fill="none" stroke="#64748b" stroke-width="1.4" marker-end="url(#arr)"/>')
            if lab:
                lab = lab if len(lab) <= 24 else lab[:22] + "\u2026"
                mx, my = (p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2 - 6
                w = 6.2 * len(lab) + 8
                out.append(f'<rect x="{mx - w / 2:.0f}" y="{my - 10:.0f}" width="{w:.0f}" height="14" rx="3" fill="white" fill-opacity="0.92"/>')
                out.append(f'<text x="{mx:.0f}" y="{my + 1:.0f}" text-anchor="middle" font-size="10.5" fill="#334155">{html.escape(lab)}</text>')
        # nodes
        for _, nodes in self.lanes:
            for n in nodes:
                x0, y0, w, h = pos[n.id]
                fill, stroke, col = COLORS.get(n.kind, COLORS["process"])
                out.append(f'<rect x="{x0}" y="{y0}" width="{w}" height="{h}" rx="7" fill="{fill}" stroke="{stroke}" stroke-width="1.4"/>')
                for i, line in enumerate(texts[n.id]):
                    small = line.startswith(" ")
                    ff = ' font-family="ui-monospace,Menlo,Consolas,monospace"' if (n.mono or small) else ""
                    fs = ' font-size="10.5"' if small else ' font-size="12"'
                    fw = "" if (small or i > 0) else ' font-weight="600"'
                    out.append(f'<text x="{x0 + w / 2}" y="{y0 + 17 + LINE_H * i}" text-anchor="middle" fill="{col}"{ff}{fs}{fw}>'
                               f'{html.escape(line.strip(chr(0x2009)))}</text>')
        out.append("</svg>")
        return "\n".join(out)


def _mm(text: str) -> str:
    """Mermaid-safe label text."""
    return (text.replace('"', "'").replace("<", "&lt;").replace(">", "&gt;").replace("[", "(").replace("]", ")")
            .replace("{", "(").replace("}", ")").replace("|", "/"))


def _wrap(text: str, width: int) -> List[str]:
    words: List[str] = []
    for w in text.split():                       # long identifiers break after '_' / '.' / '/'
        while len(w) > width:
            cut = max(w.rfind("_", 1, width), w.rfind(".", 1, width), w.rfind("/", 1, width))
            if cut <= 0:
                cut = width - 1
            words.append(w[:cut + 1])
            w = w[cut + 1:]
        words.append(w)
    lines, cur = [], ""
    for w in words:
        if len(cur) + len(w) + 1 > width and cur:
            lines.append(cur)
            cur = w
        else:
            cur = f"{cur} {w}".strip()
    if cur:
        lines.append(cur)
    return lines or [""]


def _short(d: "Diagram") -> str:
    t = d.title
    if " - " in t and (d.name.startswith("product_") or d.name.startswith("narratives_")):
        t = t.split(" - ", 1)[1].split(" (")[0]
    else:
        t = t.split(" - ")[0]
    return t


# =============================================================================
class DiagramSet:
    def __init__(self, cfg, pipeline):
        self.cfg = cfg
        self.p = pipeline
        ld = getattr(pipeline, "loader", None)
        self.ini: Dict[str, str] = dict(getattr(ld, "nlg_settings", {}) or {})
        self.section = getattr(ld, "nlg_section", "") or "prod_active"
        self.odm_schema = ((cfg.get("domains") or {}).get("odm") or {}).get("schema") or cfg.greenplum["schema"]
        self.ikg_schema = cfg.greenplum["schema"]
        self.nlg_schema = self.ini.get("schema_nlg", "<schema_nlg>")
        self.results = None
        try:
            self.results = pipeline.all_results_frame()
        except Exception:  # noqa: BLE001
            self.results = None

    # ------------------------------------------------------------------ helpers
    def T(self, key: str, default: str) -> str:
        return self.ini.get(key, default)

    def S(self, key: str, default: str) -> str:
        return self.ini.get(key, default)

    def tbl(self, key: str, default: str, schema_key: str = "schema_nlg", default_schema: str = "") -> str:
        return f"{self.S(schema_key, default_schema or self.nlg_schema)}.{self.T(key, default)}"

    def _ikg_tables(self, n: int = 7) -> List[str]:
        ts = sorted(getattr(self.p, "ikg_schemas", lambda: {})()) if self.p is not None else []
        pref = [t for t in ("household_profile_curr_ikg", "client_profile_curr_ikg", "account_profile_curr_ikg") if t in ts]
        return (pref + [t for t in ts if t not in pref])[:n]

    def _nlg_input_tables(self) -> List[Tuple[str, str]]:
        return [(f"{self.S('schema_ikg', self.ikg_schema)}.{v}", k[len("input_tbl_"):]) for k, v in sorted(self.ini.items())
                if k.startswith("input_tbl_") and re.match(r"^[a-z_0-9]+$", v)]

    # ------------------------------------------------------------------ diagrams
    def all(self) -> List[Diagram]:
        ds = [self.odm_architecture(), self.nlg_architecture(), self.narratives_client(), self.narratives_fl(),
              self.narratives_prospect()]
        ds += self.products()
        return ds

    def odm_architecture(self) -> Diagram:
        sch = self.odm_schema
        ikg = self._ikg_tables()
        lanes = [
            (f"IKG profiles ({self.ikg_schema})", [Node("ikg", "IKG profile tables (weekly refresh)", "source",
                                              ", ".join(ikg[:5]) + (" ..." if len(ikg) > 5 else "")),
                                         Node("runstatus", "ikg_run_status", "table", "odm_run_status / ODM_RUN_UUID", True)]),
            ("ODM pre-tasks", [Node("dq", "odm_master_runner / odm_data_quality_check", "odm", "duplicate-key checks on IKG profiles"),
                               Node("create", "odm_table_creation.sql", "odm", "CREATE TABLE IF NOT EXISTS ODM_TABLE / ODM_ARCH_TABLE", True),
                               Node("trunc", "truncate si_odm_insights_active", "odm", "start of every run")]),
            ("Rule DAGs (one task per .sql file)", [
                Node("client", "odm_client_rules", "odm", "ds_client_insights/ (~415 rules, 35+ categories)"),
                Node("prospect", "odm_prospect_rules", "odm", "prospect_insights/ (~43 rules)"),
                Node("fl", "odm_fl_rules", "odm", "field_leader_insights/ (~57 rules)"),
                Node("market", "odm_market_event_rules", "odm", "market_event_insights/")]),
            ("ODM tables", [Node("active", f"{sch}.si_odm_insights_active", "table",
                                 "insight_type, target_type, target_key, metric_*, run_id, insight_date_time", True),
                            Node("excl", f"{sch}.odm_exclusion_insight_type", "table", "insight_type, excluded_date, last_upd_dte, is_curr", True),
                            Node("arch", f"{sch}.si_odm_insights_archive", "table", "history of every run (run_id)", True)]),
            ("Post-tasks and consumers", [Node("exlist", "set_odm_exclusion.odm_exclusion_list", "odm",
                                               "Airflow Variable ODM_RULES_EXCLUDE_LIST -> is_curr 1 / 0"),
                                          Node("archive", "odm_archival_load", "odm", "copy run rows to the archive"),
                                          Node("status", "update_status_endtime", "odm", "odm_run_status = COMPLETED"),
                                          Node("nlg", "NLG (nlg_master)", "nlg", "polls the run status, reads the active insights")]),
        ]
        edges = [("ikg", "dq", ""), ("runstatus", "dq", "ODM_RUN_UUID"), ("dq", "create", ""), ("create", "trunc", ""),
                 ("trunc", "client", ""), ("trunc", "prospect", ""), ("trunc", "fl", ""), ("trunc", "market", ""),
                 ("client", "active", "INSERT"), ("prospect", "active", "INSERT"), ("fl", "active", "INSERT"), ("market", "active", "INSERT"),
                 ("active", "exlist", ""), ("exlist", "excl", "insert / flip is_curr"), ("excl", "active", "DELETE excluded types"),
                 ("active", "archive", ""), ("archive", "arch", "INSERT"), ("archive", "status", ""), ("status", "nlg", "polling"),
                 ("active", "nlg", "target_type / insight_type / target_key")]
        notes = [
            "Every rule is one SQL file whose name is the insight_type; the DAG builder turns each file into a task (no DAG code change to add a rule).",
            "All rule types write the SAME table; rows differ by insight_type / insight_category / target_type (client, household, account, prospect, fa, fl).",
            "run_id (ODM_RUN_UUID) ties the rows of one weekly run together; NLG reads only the current run.",
            "odm_exclusion_insight_type is SCD-2 style: is_curr = 1 means the rule output is currently suppressed; nothing is hard-deleted.",
        ]
        tables = [(f"{sch}.si_odm_insights_active", "current run insight hits"), (f"{sch}.odm_exclusion_insight_type", "excluded rule types"),
                  (f"{sch}.si_odm_insights_archive", "archived insight hits")]
        ex = [("Rule file skeleton (ds_client_insights/<category>/si_<rule>.sql)",
               "INSERT INTO {{ params.IKG_SCHEMA }}.{{ params.ODM_TABLE }}\n (insight_type, target_type, target_key, metric_name, metric_type, metric_val,\n"
               "  run_id, insight_date_time, insight_category, insight_att_name, insight_att_val)\nSELECT 'si_<rule>', 'household', h.acc_mhh_n::text, '<metric>', 'amount', h.<metric>::text,\n"
               "       '{{ params.ODM_RUN_UUID }}', h.profile_date, '<category>', null, null\nFROM {{ params.IKG_SCHEMA }}.household_profile_curr_ikg h\nWHERE <business rule>;"),
              ("Active insights of the current run without excluded types",
               f"select insight_type, target_type, count(*)\nfrom {sch}.si_odm_insights_active a\nwhere not exists (select 1 from {sch}.odm_exclusion_insight_type e where e.insight_type = a.insight_type and e.is_curr = 1)\ngroup by 1, 2 order by 3 desc;")]
        return Diagram("odm_architecture", "ODM architecture - Opportunity Data Model rule engine",
                       "ODM reads the IKG profile tables, applies hundreds of SQL rules (client, prospect, Field-Leader, market events) "
                       "and writes every hit into si_odm_insights_active; excluded rule types are maintained in odm_exclusion_insight_type.",
                       lanes, edges, notes, tables, ex, group="ODM")

    def nlg_architecture(self) -> Diagram:
        nlg, ikg = self.S("schema_nlg", self.nlg_schema), self.S("schema_ikg", self.ikg_schema)
        inputs = self._nlg_input_tables()
        lanes = [
            ("Inputs", [Node("odm", f"{self.S('schema_odm', self.odm_schema)}.{self.T('odm_insights_tbl', 'si_odm_insights_active')}", "table", "ODM insight hits", True),
                        Node("ikg", f"{len(inputs)} IKG profile tables ({ikg})", "source",
                             ", ".join(t.split(".")[-1] for t, _ in inputs[:4]) + " ..."),
                        Node("ref", "reference tables", "table", f"{self.T('ref_tbl_insight_layout', 'si_nlg_insight_layout')}, "
                             f"{self.T('ref_tbl_insight_group_and_rank', 'si_nlg_insight_group_and_rank')}, {self.T('ref_tbl_pilot_fa_mhh_map', 'si_pilot_fa_shp_map')}, "
                             f"{self.T('ref_tbl_fa_pilot_list', 'si_pilot_fa_list')} ...", True),
                        Node("yml", "repository config", "config", "nlg_db_tables.ini, rules/, group_logic/, sql_column_mapping/, insight_group_layout/")]),
            ("nlg_master DAG (Mon-Fri 06:00)", [Node("check", "check_odm_run_completion", "nlg", "ExternalTaskSensor ikg_master / polling"),
                                                Node("latest", "populate_latest_odm_insights", "nlg", "refresh_odm_insights_curr (non-prod)"),
                                                Node("pre", "nlg_preprocess", "nlg", "sync layout yml -> tables, sync ref tables, exclusions, prev-week time_sent"),
                                                Node("rules", "nlg_rules", "nlg", "one task per target type (nlg_rules_<target_type>): fetch ODM+IKG, group, tracery narratives"),
                                                Node("post", "nlg_post_process", "nlg", "fill end times, notify, trigger distribution sync")]),
            ("Narratives", [Node("narr", self.tbl("output_tbl_narratives_fa", "si_nlg_fa_narratives_active"), "table",
                                 "one row per target_key x insight_type x run (time_created, week_start_date)", True),
                            Node("curr", self.tbl("output_tbl_narratives_curr_fa", "si_nlg_fa_narratives_active_curr"), "table",
                                 "latest run, partitioned by hh_percentile_idx", True),
                            Node("fl", self.tbl("output_tbl_narratives_fl", "si_nlg_fl_narratives_active"), "table", "+ _curr (FL)", True),
                            Node("pp", self.tbl("output_tbl_narratives_fa_prospect", "si_nlg_fa_prospect_narratives_active"), "table", "+ _curr (prospects)", True)]),
            ("Products", [Node("cb", "Client briefings (FA_MEETING_MAIL)", "product", self.T("output_tbl_fa_html_curr", "si_nlg_fa_email_bullets_html_v2_active_curr")),
                          Node("alerts", "FA alerts / subscriptions / banker alerts", "product", self.T("output_tbl_fa_alert_template_curr", "si_nlg_fa_alert_html_active_curr")),
                          Node("json", "JSON insights (portal / panels)", "product", self.T("output_tbl_mhh_insights_in_json_curr", "si_nlg_household_insights_in_json_active_curr")),
                          Node("fltr", "FL talent report (monthly / weekly)", "product", self.T("output_tbl_fl_talent_report_curr", "si_nlg_fl_talent_report_active_curr")),
                          Node("mkt", "Market event alerts (+ banking)", "product", self.T("output_tbl_market_alert_curr", "si_nlg_market_event_html_active_curr")),
                          Node("pa", "Prospect alerts (FA_PROSPECT_MAIL)", "product", self.T("output_tbl_fa_prospect_html_curr", "si_nlg_fa_prospect_email_bullets_html_active_curr"))]),
            ("Delivery", [Node("email", "e-mail sender DAGs", "delivery", "nlg_staat_email_sender_* (Mon/Thu/Fri 11:00, Wed 16:00) -> *_weekly_emails status tables"),
                          Node("dist", "distribution DB sync", "delivery", "nlg_post_process_sync_to_distribution_db -> core_prj_insights_nlg (portal, panels, Tableau)"),
                          Node("hist", f"{nlg}.{self.T('nlg_run_history', 'si_nlg_run_history_active')}", "table",
                               f"{self.T('nlg_run_error_log', 'si_nlg_run_error_log_active')}, {self.T('ref_ikg_odm_nlg_polling_tbl', 'ikg_run_status')}", True)]),
        ]
        edges = [("odm", "check", ""), ("check", "latest", ""), ("latest", "pre", ""), ("pre", "rules", ""), ("yml", "pre", "layout / ref sync"),
                 ("ikg", "rules", "join on acc_mhh_n / ip_cli_i / acc_i"), ("ref", "rules", ""), ("odm", "rules", "insight_type + target_key"),
                 ("rules", "narr", "csv buffer -> insert"), ("narr", "curr", "update_rule_narratives_curr_table"), ("rules", "fl", ""), ("rules", "pp", ""),
                 ("curr", "cb", "layout + FA/household map"), ("curr", "alerts", "materiality, suppression"), ("curr", "json", ""),
                 ("fl", "fltr", ""), ("curr", "mkt", ""), ("pp", "pa", ""),
                 ("cb", "email", ""), ("alerts", "email", ""), ("fltr", "email", ""), ("mkt", "email", ""), ("pa", "email", ""),
                 ("json", "dist", ""), ("cb", "dist", ""), ("post", "hist", ""), ("rules", "post", "")]
        notes = [
            f"Configuration section used: [{self.section}] of nlg_db_tables.ini (schema_nlg = {nlg}, schema_ikg = {ikg}).",
            "odm_env (dummy / review / test / active) and code_env (dev / prod) select the ini section: <code_env>_<odm_env>; production = prod_active.",
            "Rules stage = ODM hit + IKG profile row -> YAML rule (tracery grammar) -> narrative text; products assemble narratives per FA / household using the insight layout.",
            "Every output table has an _active (all runs) and an _active_curr (latest run) version; products read the _curr tables.",
        ]
        tables = [(f"{self.S('schema_odm', self.odm_schema)}.{self.T('odm_insights_tbl', 'si_odm_insights_active')}", "ODM hits")] + \
                 [(t, f"input - target type {k}") for t, k in inputs] + \
                 [(f"{nlg}.{v}", k) for k, v in sorted(self.ini.items()) if k.startswith(("output_tbl_", "ref_tbl_", "nlg_")) and re.match(r"^[a-z_0-9]+$", v)]
        ex = [("Narratives of one household in the latest run",
               f"select insight_type, narrative_title, narrative_raw, metric_name, metric_val\nfrom {self.tbl('output_tbl_narratives_curr_fa', 'si_nlg_fa_narratives_active_curr')}\nwhere acc_mhh_n = '<household id>' order by insight_type;"),
              ("Layout of an insight type per product",
               f"select l.product, l.group_name, g.insight_section, g.category, l.materiality, l.suppression_weeks, l.order_in_group\nfrom {self.tbl('ref_tbl_insight_layout', 'si_nlg_insight_layout', 'schema_ref')} l\njoin {self.tbl('ref_tbl_insight_group_and_rank', 'si_nlg_insight_group_and_rank', 'schema_ref')} g on g.product = l.product and g.group_name = l.group_name\nwhere l.insight_type = 'si_client_birthday';")]
        return Diagram("nlg_architecture", "NLG architecture - Natural Language Generation pipeline",
                       "NLG turns ODM insight hits into narratives (one YAML rule per insight type) and assembles them into FA-facing products "
                       "(client briefings, alerts, talent reports, JSON insights) delivered by e-mail and through the FA portal.",
                       lanes, edges, notes, tables, ex)

    # ------------------------------------------------------------------ narratives
    def narratives_client(self) -> Diagram:
        lanes = [
            ("1. Inputs for one target type", [
                Node("odm", f"{self.T('odm_insights_tbl', 'si_odm_insights_active')}", "table", "where target_type = '<target_type>' and insight_type = '<insight_type>'", True),
                Node("ikg", f"input_tbl_<target_type> ({self.S('schema_ikg', self.ikg_schema)})", "table", "e.g. client -> client_profile_curr_ikg; join a.target_key = b.<input_db_join_col>", True),
                Node("cfg", "config/input_data_config/<target_type>.yml", "config", "target_key_conversion, input_db_join_col, insights_target_user_type, sql_column_mapping"),
                Node("map", "sql_column_mapping/<target_type>/<insight_type>.json|yml", "config", "columns / SQL expressions available to the rule"),
                Node("refc", "ref_table_columns/<target_type>/<insight_type>.yml", "config", "extra joins to reference tables")]),
            ("2. Fetch + group", [Node("fetch", "fetch_data_with_insights", "nlg", "utils_narratives.py: SQL built from the mappings; pilot_only / hh_id_range / fields_not_null"),
                                  Node("dummy", "inject_input_data_for_dummy_households", "nlg", "non-prod only (si_nlg_dummy_client_cid_info)"),
                                  Node("group", "group_logic/<target_type>/<insight_type>.yml", "config", "group_key (acc_mhh_n ...), items_in_group_sort_key, distinct_on, item narratives")]),
            ("3. Narrative generation", [Node("rule", "rules/<target_type>/<insight_type>.yml", "config", "tracery grammar: rule_narrative, rule_narrative_title, footer; #field.modifier()#"),
                                         Node("mod", "modifiers/", "config", "date_format, format_multi_names, convert_number_to_m_or_k, deeplinks ..."),
                                         Node("gen", "generate_narratives_with_(no_)group_logic", "nlg", "batch of 5000 (tracery_batch_size)"),
                                         Node("attach", "INSIGHTS_ATTACH_LOGIC / INSIGHTS_COMBINE_LOGIC", "nlg", "e.g. si_client_birthday + birthday milestones; struc_prod combine"),
                                         Node("xform", "transform_narrative_entry", "nlg", "global_key, target_keys, included_clients, week_start_date, url tracking tags")]),
            ("4. Store", [Node("csv", "csv buffer + buffer table", "process", f"{self.T('output_tbl_narratives_buffer_base', 'si_nlg_fa_narr_bfr_base')}_<env>_<target>_<ts>", True),
                          Node("narr", self.tbl("output_tbl_narratives_fa", "si_nlg_fa_narratives_active"), "table", "raw narratives, all runs", True),
                          Node("odmfree", self.tbl("output_tbl_narratives_odm_free_fa", "si_nlg_fa_narratives_odm_free_active"), "table", "insight_type_from_odm = 0 rules, merged in", True),
                          Node("curr", self.tbl("output_tbl_narratives_curr_fa", "si_nlg_fa_narratives_active_curr"), "table", "post_nlg_update_narrative_curr_table: latest run, hh_percentile_idx from si_nlg_household_percentile_range", True),
                          Node("err", self.tbl("nlg_run_error_log", "si_nlg_run_error_log_active"), "warn", "insight-type failures (nlg_stage = raw_narrative_generation)", True)]),
        ]
        edges = [("odm", "fetch", ""), ("ikg", "fetch", ""), ("cfg", "fetch", ""), ("map", "fetch", ""), ("refc", "fetch", ""),
                 ("fetch", "dummy", "non-prod"), ("fetch", "group", ""), ("group", "gen", ""), ("rule", "gen", ""), ("mod", "rule", ""),
                 ("gen", "attach", ""), ("attach", "xform", ""), ("xform", "csv", ""), ("csv", "narr", ""), ("odmfree", "narr", "update_rule_narratives_curr_table"),
                 ("narr", "curr", ""), ("fetch", "err", "on exception")]
        notes = [
            "Target types (enums.InsightTargetType): account, account_mtg, client, household, household_art, household_holding, household_recipient, client_ext_acc, "
            "client_medallia, client_wealthx(_delta/_attributes), client_fga_goal, client_windfall, account_sbl, account_holding(_mat_sec/_mmf), client_speedeon, "
            "client_bknight(_mls), asset_allocation, client_zoominfo_*, yodlee_mtp_*, household_optimus, client_brightscope, market_event(_bank_im), client_newsedge, client_npo ...",
            "Account-level target types (InsightAccountLevelTargetType) keep account_ids / target_entity_ids per narrative.",
            "The rules stage runs once per target type as an Airflow task nlg_rules_<target_type> (asset_allocation in 3 household-id batches).",
            "A narrative row = target_key x insight_type x time_created; week_start_date groups a weekly run; narrative_raw / narrative_title carry html with bullet delimiters.",
        ]
        tables = [(self.tbl("output_tbl_narratives_fa", "si_nlg_fa_narratives_active"), "raw narratives"),
                  (self.tbl("output_tbl_narratives_curr_fa", "si_nlg_fa_narratives_active_curr"), "latest run"),
                  (self.tbl("output_tbl_narratives_odm_free_fa", "si_nlg_fa_narratives_odm_free_active"), "rules without ODM hit"),
                  (self.tbl("output_tbl_narratives_buffer_base", "si_nlg_fa_narr_bfr_base"), "buffer template"),
                  (self.tbl("nlg_run_error_log", "si_nlg_run_error_log_active"), "errors")]
        ex = [("rules/client/milestones/si_client_birthday.yml (tracery)",
               "rule_narrative:\n- >-\n  <b>#client_names_by_dob.format_multi_names(<delimiter>,1,asc)#'s #client_age.formate_num_with_th# birthday</b> is #ip_dob_d.date_format(%B <S>)#.\nrule_narrative_footer:\n- >-\n  To add ... click <a href=\"#client_name_with_birthday.generate_portal_calendar_event_deeplink( Birthday)#\">here</a>."),
              ("group_logic/client/si_client_birthday.yml", "group_key:\n- acc_mhh_n\n- ip_dob_d\nitems_in_group_sort_key:\n- ip_cli_i")]
        return Diagram("narratives_client_rules", "Narratives - client / household rules flow",
                       "How one ODM hit becomes a narrative sentence for the FA: inputs per target type, grouping, the tracery rule, attach / combine logic and the narrative tables.",
                       lanes, edges, notes, tables, ex)

    def narratives_fl(self) -> Diagram:
        lanes = [
            ("Inputs (FL)", [Node("odm", f"{self.T('odm_insights_tbl_fl', self.T('odm_insights_tbl', 'si_odm_insights_active'))}", "table", "FL rules of ODM: target_type fl_recruitment / fl_ubs_fa / fl_ubs_client", True),
                             Node("ikg", "input_tbl_fl_* profile tables", "table", f"{self.T('input_tbl_fl_ubs_fa', 'fl_fa_profile_curr_ikg')}, {self.T('input_tbl_fl_recruitment', 'fl_recruitment_profile_curr_ikg')}, {self.T('input_tbl_fl_ubs_client', 'fl_client_profile_curr_ikg')}", True),
                             Node("maps", "FL mapping tables", "table", f"{self.T('ref_tbl_fl_info_tbl', 'fl_to_wire_code_ikg')}, {self.T('ref_tbl_fl_role_tbl', 'fl_individual_role_ikg')}, {self.T('ref_tbl_fl_exclusion', 'fl_talent_report_exclusion_list')}", True)]),
            ("DAG nlg_fl_report_generation", [Node("trig", "triggered by ikg_master", "nlg", "days 11-17: monthly FL_TALENT_REPORT, else weekly FL_TALENT_REPORT_WEEKLY"),
                                              Node("rules", "nlg rules (is_fl_run = 1)", "nlg", "fetch_data_with_insights_for_fl: join map table input_tbl_<tt>_map_tbl"),
                                              Node("comb", "INSIGHTS_COMBINE_LOGIC (fl_ubs_fa, fl_recruitment)", "nlg", "red-flag insights joined per fl_gpn x fa_gpn; recruits per individual_gpn x rep_crd")]),
            ("Narratives (FL)", [Node("narr", self.tbl("output_tbl_narratives_fl", "si_nlg_fl_narratives_active"), "table", "insights_target_user_type = fl", True),
                                 Node("curr", self.tbl("output_tbl_narratives_curr_fl", "si_nlg_fl_narratives_active_curr"), "table", "update_rule_narratives_curr_table_fl(product): only insight types of the product", True)]),
            ("Product + delivery", [Node("prod", "FL talent report", "product", "run_fl_talent_report: per FL (get_fl_records), branches, insight history"),
                                    Node("out", self.tbl("output_tbl_fl_talent_report", "si_nlg_fl_talent_report_active"), "table", "+ _curr; insight_html per fl_gpn", True),
                                    Node("hist", self.tbl("output_tbl_fl_talent_report_insight_history", "si_nlg_fl_talent_report_insight_history_active"), "table", "last date sent per insight", True),
                                    Node("mail", "nlg_generate_fl_talent_report_emails -> nlg_send_fl_talent_emails", "delivery", self.T("output_tbl_fl_talent_report_weekly_emails", "si_nlg_fl_talent_report_weekly_email_active"))]),
        ]
        edges = [("odm", "rules", ""), ("ikg", "rules", ""), ("maps", "rules", ""), ("trig", "rules", ""), ("rules", "comb", ""), ("comb", "narr", ""),
                 ("narr", "curr", ""), ("curr", "prod", "layout product FL_TALENT_REPORT(_WEEKLY)"), ("prod", "out", ""), ("hist", "prod", "suppression"),
                 ("out", "hist", ""), ("out", "mail", "")]
        notes = ["Field-Leader insights are aggregated per FL (fl_gpn) over the FAs / clients of the FL's branches; sections like ADVISORS WITH POTENTIAL TO MOVE, "
                 "COMPATIBILITY RATING UPGRADES, NOTABLE MOVES, ATTRITION RISKS, MILESTONES come from insight_layout_ranks.yml.",
                 "Monthly and weekly reports share the narratives table; the _curr table is filtered by the product's insight types to avoid bleeding."]
        tables = [(self.tbl("output_tbl_narratives_fl", "si_nlg_fl_narratives_active"), "FL narratives"),
                  (self.tbl("output_tbl_narratives_curr_fl", "si_nlg_fl_narratives_active_curr"), "latest"),
                  (self.tbl("output_tbl_fl_talent_report", "si_nlg_fl_talent_report_active"), "talent report html"),
                  (self.tbl("output_tbl_fl_talent_report_insight_history", "si_nlg_fl_talent_report_insight_history_active"), "history")]
        return Diagram("narratives_fl_rules", "Narratives - Field Leader (FL) rules flow",
                       "Field-Leader narratives: FL target types, mapping tables, combine logic per FL x FA and the FL talent report product.",
                       lanes, edges, notes, tables)

    def narratives_prospect(self) -> Diagram:
        lanes = [
            ("Inputs (prospects)", [Node("odm", f"{self.T('odm_insights_tbl_prospect', self.T('odm_insights_tbl', 'si_odm_insights_active'))}", "table", "ODM prospect rules; key main_prospect_id", True),
                                    Node("ikg", "prospect profile tables", "table", f"{self.T('input_tbl_prospect', 'prospect_profile_curr_ikg')}, {self.T('input_tbl_prospect_speedeon', 'speedeon_prospect_profile_curr_ikg')}, {self.T('input_tbl_prospect_wealthx_delta', 'prospects_wealthx_delta_profile_curr_ikg')}, windfall, mls", True),
                                    Node("map", f"{self.T('ref_tbl_fa_prospect_map', 'ikg_prospect_fa_mapping')}", "table", "prospect -> FA (fa_gpn)", True)]),
            ("DAG nlg_prospect_master", [Node("pre", "pre_nlg_sync_insight_type_layout / ref tables", "nlg", ""),
                                         Node("rules", "nlg_rules_prospect_* (is_prospect_run = 1)", "nlg", "prospect_speedeon, prospect_wealthx_delta, prospect, prospect_windfall, prospect_mls_blacknight"),
                                         Node("attach", "INSIGHTS_ATTACH_LOGIC[prospect]", "nlg", "si_prospect_birthday + retirement / medicare / social security")]),
            ("Narratives (prospects)", [Node("narr", self.tbl("output_tbl_narratives_fa_prospect", "si_nlg_fa_prospect_narratives_active"), "table", "+ odm_free variant", True),
                                        Node("curr", self.tbl("output_tbl_narratives_curr_fa_prospect", "si_nlg_fa_prospect_narratives_active_curr"), "table", "update_prospect_rule_narratives_curr_table", True)]),
            ("Product + delivery", [Node("prod", "Prospect alerts (FA_PROSPECT_MAIL)", "product", "run_prospect_alert: per FA, MAX_PROSPECT_IN_ALERT = 22, materiality"),
                                    Node("out", self.tbl("output_tbl_fa_prospect_html", "si_nlg_fa_prospect_email_bullets_html_active"), "table", "+ _curr", True),
                                    Node("hist", self.tbl("output_tbl_pp_alert_insight_history", "si_nlg_pp_alert_insight_history_active"), "table", "suppression history", True),
                                    Node("mail", "nlg_generate_prospect_alerts_emails -> e-mail sender", "delivery", self.T("output_tbl_prospect_alert_weekly_emails", "si_nlg_prospect_alert_weekly_email_active"))]),
        ]
        edges = [("odm", "rules", ""), ("ikg", "rules", ""), ("pre", "rules", ""), ("rules", "attach", ""), ("attach", "narr", ""), ("narr", "curr", ""),
                 ("curr", "prod", ""), ("map", "prod", "FA of the prospect"), ("prod", "out", ""), ("hist", "prod", ""), ("out", "mail", "")]
        notes = ["Prospect narratives use main_prospect_id instead of acc_mhh_n as target key; the table layout is the same as the client narratives.",
                 "The prospect master DAG is triggered by ikg_master after the prospect profiles are refreshed."]
        tables = [(self.tbl("output_tbl_narratives_fa_prospect", "si_nlg_fa_prospect_narratives_active"), "prospect narratives"),
                  (self.tbl("output_tbl_narratives_curr_fa_prospect", "si_nlg_fa_prospect_narratives_active_curr"), "latest"),
                  (self.tbl("output_tbl_fa_prospect_html", "si_nlg_fa_prospect_email_bullets_html_active"), "prospect alert html")]
        return Diagram("narratives_prospect_rules", "Narratives - prospect rules flow",
                       "Prospect narratives (main_prospect_id): prospect target types, attach logic and the FA prospect alert product.",
                       lanes, edges, notes, tables)

    # ------------------------------------------------------------------ products
    def products(self) -> List[Diagram]:
        T, tbl = self.T, self.tbl
        curr = tbl("output_tbl_narratives_curr_fa", "si_nlg_fa_narratives_active_curr")
        layout = tbl("ref_tbl_insight_layout", "si_nlg_insight_layout", "schema_ref")
        rank = tbl("ref_tbl_insight_group_and_rank", "si_nlg_insight_group_and_rank", "schema_ref")
        famap = tbl("ref_tbl_pilot_fa_mhh_map", "si_pilot_fa_shp_map", "schema_fa_ta_mhh_map", self.ikg_schema)
        pilot = tbl("ref_tbl_fa_pilot_list", "si_pilot_fa_list", "schema_ref")
        optout = tbl("ref_tbl_fa_opt_out", "si_pilot_fa_opt_out", "schema_ref")
        specs = [
            dict(name="client_briefing", title="Product - Client briefings (FA_MEETING_MAIL)", product="FA_MEETING_MAIL",
                 desc="Weekly briefing per household for its FA(s): narratives of the latest run arranged by the insight layout (sections, categories, groups), "
                      "feedback questions, announcement banners and explorer links; produced in two household-percentile halves.",
                 steps=[("start", "nlg_client_briefing_start (cb_time_start)", ""), ("gen", "run_client_briefing (2 tasks: hh percentiles 0-49, 50-99)", "get_fa_mhh_records + get_product_target_narratives_with_layout + run_client_briefing_in_batch"),
                        ("upd", "nlg_client_briefing_update_curr_table", "buffer -> product table -> _curr"), ("unnest", "create_fa_cb_unnest_table", T("output_tbl_fa_unnest_html_curr", "si_nlg_fa_unnest_html_active_curr")),
                        ("ret", "retention pack processing", T("output_tbl_retention_pack_cb_curr", "si_nlg_hh_retention_pack_cb_active_curr")), ("mailgen", "post_nlg_product_client_briefing_email_generation", "staat_ds_nlg_cb_email_generation (Mon/Thu 10:00 UTC)")],
                 inputs=[(curr, "narratives (latest)"), (layout, "insight layout"), (rank, "groups / ranks"), (famap, "FA x household map"), (pilot, "pilot FAs"), (optout, "FA opt-out"),
                         (tbl("fa_insight_preference_tbl", "user_preferences_extract_test", "fa_insight_preference_tbl_schema", self.nlg_schema), "FA insight preferences (portal)"),
                         (f"{self.S('schema_ikg', self.ikg_schema)}.{T('ref_tbl_fga_entitlement', 'fga_fa_entitlements_ikg')}", "FGA entitlements")],
                 outputs=[(tbl("output_tbl_fa_cb_buffer", "si_nlg_fa_cb_buffer_v2_active"), "buffer"), (tbl("output_tbl_fa_html", "si_nlg_fa_email_bullets_html_v2_active"), "briefing html per FA x household"),
                          (tbl("output_tbl_fa_html_curr", "si_nlg_fa_email_bullets_html_v2_active_curr"), "latest"), (tbl("output_tbl_fa_email_mhh_status", "si_nlg_fa_email_mhh_status_active"), "send status"),
                          (tbl("output_tbl_client_briefing_weekly_emails", "si_nlg_client_briefing_weekly_email_v2_active"), "weekly e-mails"), (tbl("output_tbl_fa_cb_summary_weekly_emails", "si_nlg_client_briefing_summary_weekly_email_v2_active"), "CB summary e-mails")],
                 delivery="nlg_send_client_briefing_emails / nlg_staat_email_sender_mon_thur_fri_execution; nlg_send_cb_summary_emails",
                 notes=["PRODUCT_BULLET_CNT_THRESHOLD FA_MEETING_MAIL: min 3 bullets; CLIENT_BRIEFING_SUMMARY: 1-3.",
                        "FAs of a household are grouped by (FGA keys, explorer links, suppressions) so identical content is generated once per group.",
                        "Sections (insight_layout_ranks.yml SECTION_RANK): Household Stats, Top Insights, Newsedge, Recap of Milestones, Housekeeping Checklist, RMD Summary, Banking Summary, FGA Status ..."]),
            dict(name="fa_alerts", title="Product - FA alerts (FA_ALERT)", product="FA_ALERT",
                 desc="Material, time-sensitive insights per FA (not per household): households above the asset threshold, alert materiality and suppression by insight history.",
                 steps=[("gen", "run_fa_alert", "get_fa_mhh_records(agg_option=fa) + narratives with layout (mhh_assets >= 250000) + run_fa_alerts_in_batch"),
                        ("upd", "nlg_fa_alerts_update_curr_table", ""), ("mailgen", "nlg_product_fa_alerts_email_generation", "intro sections, disclaimer, household id encryption"),
                        ("notify", "nlg_product_fa_alerts_email_generation_notify", "")],
                 inputs=[(curr, "narratives (latest)"), (layout, "layout (product FA_ALERT, materiality)"), (famap, "FA x household map"), (tbl("output_tbl_fa_alert_insight_history", "si_nlg_fa_alert_insight_history_active"), "last date sent per insight"),
                         (f"{self.S('schema_ikg', self.ikg_schema)}.{T('input_tbl_household', 'household_profile_curr_ikg')}", "mhh_assets_curr threshold")],
                 outputs=[(tbl("output_tbl_fa_alert_template", "si_nlg_fa_alert_html_active"), "alert html per FA"), (tbl("output_tbl_fa_alert_template_curr", "si_nlg_fa_alert_html_active_curr"), "latest"),
                          (tbl("output_tbl_fa_alert_status", "si_nlg_fa_alert_status_active"), "status"), (tbl("output_tbl_fa_alert_weekly_emails", "si_nlg_fa_alert_weekly_email_active"), "weekly e-mails")],
                 delivery="nlg_staat_email_sender_* DAGs (FA alert e-mails)",
                 notes=["Constants: ALERT_MATERIALITY_THRESHOLD = 75, FA_ALERT_MHH_ASSETS_THRESHOLD = 250000, FA_ALERTS_SPLIT_THRESHOLD = 15 households per e-mail, MAX_HOUSEHOLDS_IN_PRODUCT FA_ALERT = 15.",
                        "Minor clients and Fisher-agreement households are excluded; household ids in links are encrypted (HouseholdIdEncryption)."]),
            dict(name="fa_subscriptions", title="Product - FA subscriptions (FA_SUBSCRIPTIONS)", product="FA_SUBSCRIPTIONS",
                 desc="Insights an FA subscribed to in the portal (insight types / households), sent as a digest.",
                 steps=[("gen", "run_fa_subscriptions", "product/fa_subscription: subscribed insight types per FA, MAX_HOUSEHOLDS_PER_INSIGHT_TYPE_SUBSCRIPTION = 3"),
                        ("upd", "nlg_fa_subscriptions_update_curr_table", ""), ("mailgen", "nlg_product_fa_subscriptions_email_generation", "")],
                 inputs=[(curr, "narratives"), (layout, "layout (FA_SUBSCRIPTIONS)"), (tbl("fa_insight_preference_tbl", "user_preferences_extract_test", "fa_insight_preference_tbl_schema", self.nlg_schema), "subscriptions / preferences"),
                         (tbl("output_tbl_fa_subscriptions_insight_history", "si_nlg_fa_subscriptions_insight_history_active"), "history")],
                 outputs=[(tbl("output_tbl_fa_subscriptions_template", "si_nlg_fa_subscriptions_html_active"), "html"), (tbl("output_tbl_fa_subscriptions_template_curr", "si_nlg_fa_subscriptions_html_active_curr"), "latest"),
                          (tbl("output_tbl_fa_subscriptions_status", "si_nlg_fa_subscriptions_status_active"), "status"), (tbl("output_tbl_fa_subscriptions_weekly_emails", "si_nlg_fa_subscriptions_weekly_email_active"), "weekly e-mails")],
                 delivery="e-mail sender DAGs", notes=[]),
            dict(name="banker_alerts", title="Product - Banker alerts (BANKER_ALERTS)", product="BANKER_ALERTS",
                 desc="Banking-role insights (cash, lending, mortgage) addressed to bankers instead of FAs; opt-out via Airflow Variable bankers_opt_out_dict.",
                 steps=[("gen", "run_banker_alerts", "banking_roles in the layout group; banker_gpn"), ("mailgen", "nlg_send_banker_alert_emails", "")],
                 inputs=[(curr, "narratives"), (rank, "groups with banking_roles"), (famap, "FA / banker x household map")],
                 outputs=[(tbl("output_tbl_banker_alerts_template", "si_nlg_banker_alerts_html_active"), "html"), (tbl("output_tbl_banker_alerts_template_curr", "si_nlg_banker_alerts_html_active_curr"), "latest"),
                          (tbl("output_tbl_banker_alerts_weekly_emails", "si_nlg_banker_alerts_weekly_email_active"), "weekly e-mails")],
                 delivery="nlg_send_banker_alert_emails DAG", notes=[]),
            dict(name="fl_talent_report", title="Product - FL talent report (FL_TALENT_REPORT / _WEEKLY)", product="FL_TALENT_REPORT",
                 desc="Monthly (days 11-17) full report and weekly simplified report for Field Leaders built from the FL narratives.",
                 steps=[("gen", "run_fl_talent_report", "get_fl_records, get_fl_branches, run_fl_talent_report_in_batch"), ("upd", "update curr table (product filter)", ""),
                        ("mailgen", "run_fl_talent_report_email_generation", "intro sections + announcement banners")],
                 inputs=[(tbl("output_tbl_narratives_curr_fl", "si_nlg_fl_narratives_active_curr"), "FL narratives"), (layout, "layout (FL products)"),
                         (f"{self.S('schema_ikg', self.ikg_schema)}.{T('ref_tbl_fl_info_tbl', 'fl_to_wire_code_ikg')}", "FL / branch info"),
                         (tbl("ref_tbl_fl_exclusion", "fl_talent_report_exclusion_list"), "exclusions")],
                 outputs=[(tbl("output_tbl_fl_talent_report", "si_nlg_fl_talent_report_active"), "report html per FL"), (tbl("output_tbl_fl_talent_report_curr", "si_nlg_fl_talent_report_active_curr"), "latest"),
                          (tbl("output_tbl_fl_talent_report_insight_history", "si_nlg_fl_talent_report_insight_history_active"), "history"),
                          (tbl("output_tbl_fl_talent_report_weekly_emails", "si_nlg_fl_talent_report_weekly_email_active"), "e-mails")],
                 delivery="nlg_generate_fl_talent_report_emails -> nlg_send_fl_talent_emails / nlg_fl_report_staat_email_sender_automation", notes=[]),
            dict(name="market_alerts", title="Product - Market event alerts (FA_MARKET_ALERT, FA_MARKET_ALERT_BANKING)", product="FA_MARKET_ALERT",
                 desc="Event-driven alerts (market events, bank / IM risk events) generated by the nlg_market_alert_generation DAG from market_event target types.",
                 steps=[("gen", "run_market_alert / run_market_alert_banking", "target types market_event, market_event_bank_im; MARKET_ALERTS_SPLIT_THRESHOLD = 15"),
                        ("mailgen", "run_market_event_(banking_)email_generation", "")],
                 inputs=[(curr, "narratives (market_event target types)"), (f"{self.S('schema_ikg', self.ikg_schema)}.{T('input_tbl_market_event', 'market_event_profile_curr_ikg')}", "market event profile"), (famap, "FA x household map")],
                 outputs=[(tbl("output_tbl_market_alert", "si_nlg_market_event_html_active"), "html"), (tbl("output_tbl_market_alert_curr", "si_nlg_market_event_html_active_curr"), "latest"),
                          (tbl("output_tbl_market_alert_banking", "si_nlg_market_event_banking_html_active"), "banking html"), (tbl("output_tbl_market_alert_weekly_emails", "si_nlg_market_alert_weekly_email_active"), "e-mails")],
                 delivery="nlg_send_market_alert_emails DAG", notes=[]),
            dict(name="prospect_alerts", title="Product - Prospect alerts (FA_PROSPECT_MAIL)", product="FA_PROSPECT_MAIL",
                 desc="Prospect insights per FA (up to 22 prospects per alert) from the prospect narratives.",
                 steps=[("gen", "run_prospect_alert", "MAX_PROSPECT_IN_ALERT = 22, PP_ALERTS_BATCH_MATERIALITY = 75"), ("upd", "nlg_prospect_alert_update_curr_table", ""),
                        ("mailgen", "run_prospect_alert_email_generation", "")],
                 inputs=[(tbl("output_tbl_narratives_curr_fa_prospect", "si_nlg_fa_prospect_narratives_active_curr"), "prospect narratives"),
                         (tbl("ref_tbl_fa_prospect_map", "ikg_prospect_fa_mapping", "schema_fa_ta_prospect_map", self.ikg_schema), "prospect x FA map"),
                         (tbl("output_tbl_pp_alert_insight_history", "si_nlg_pp_alert_insight_history_active"), "history")],
                 outputs=[(tbl("output_tbl_fa_prospect_html", "si_nlg_fa_prospect_email_bullets_html_active"), "html"), (tbl("output_tbl_fa_prospect_html_curr", "si_nlg_fa_prospect_email_bullets_html_active_curr"), "latest"),
                          (tbl("output_tbl_pp_alert_status_prospect", "si_nlg_pp_alert_status_active"), "status"), (tbl("output_tbl_prospect_alert_weekly_emails", "si_nlg_prospect_alert_weekly_email_active"), "e-mails")],
                 delivery="nlg_generate_prospect_alerts_emails -> nlg_post_product_sync_prospect_email_to_prod", notes=[]),
            dict(name="json_insights", title="Product - JSON insights (FA portal / panels)", product="JSON_INSIGHTS",
                 desc="All narratives of a household as JSON (layout applied) for the FA portal, panels and the insights explorer; synced to the distribution DB.",
                 steps=[("gen", "run_insights_in_json (3 parallel tasks)", "products FA_PORTAL / FA_PANELS / FA_INSIGHTS_EXPLORER layouts"), ("copy", "nlg_json_insights_copy_from_csv", "csv buffer -> buffer table"),
                        ("upd", "nlg_json_insights_update_curr_table", ""), ("test", "load_prod_test_insights_to_curr_tbl", "prod test users"), ("sync", "nlg_post_process_sync_to_distribution_db", "core_prj_insights_nlg + Tableau sources")],
                 inputs=[(curr, "narratives"), (layout, "layout"), (rank, "groups / ranks"), (tbl("ref_tbl_household_id_encryption", "si_nlg_household_id_encryption_active"), "household id encryption")],
                 outputs=[(tbl("output_tbl_mhh_insights_in_json_buffer", "si_nlg_household_insights_in_json_buffer_active"), "buffer"), (tbl("output_tbl_mhh_insights_in_json", "si_nlg_household_insights_in_json_active"), "json per household"),
                          (tbl("output_tbl_mhh_insights_in_json_curr", "si_nlg_household_insights_in_json_active_curr"), "latest (synced to core_prj_insights_nlg)")],
                 delivery="distribution DB (core_prj_insights_nlg) -> FA portal API / panels / Tableau", notes=[]),
            dict(name="retention_pack", title="Product - FA retention pack (FA_RETENTION_PACK)", product="FA_RETENTION_PACK",
                 desc="Client-briefing style pack for FA retention conversations (households up to max_mhh_assets), enhanced insight html.",
                 steps=[("gen", "run_retention_pack_client_briefing", "run_retention_pack_cb_in_batch"), ("upd", "nlg_retention_pack_update_curr_table", "")],
                 inputs=[(curr, "narratives"), (layout, "layout"), (famap, "FA x household map")],
                 outputs=[(tbl("output_tbl_retention_pack_cb_buffer", "si_nlg_hh_retention_pack_cb_buffer_active"), "buffer"), (tbl("output_tbl_fa_retention_pack_cb", "si_nlg_hh_retention_pack_cb_active"), "pack"),
                          (tbl("output_tbl_retention_pack_cb_curr", "si_nlg_hh_retention_pack_cb_active_curr"), "latest")],
                 delivery="generate_cb_pack_for_fa (files per FA)", notes=[]),
            dict(name="no_email_interaction", title="Product - No e-mail interaction alerts (NO_EMAIL_INTERACTION)", product="NO_EMAIL_INTERACTION",
                 desc="Households of an FA with no e-mail interaction (process insights), MAX_HOUSEHOLDS_IN_PRODUCT = 15.",
                 steps=[("gen", "product NO_EMAIL_INTERACTION", "product_settings in nlg_product_class.py")],
                 inputs=[(curr, "narratives (process category no_email_interaction)"), (famap, "FA x household map")],
                 outputs=[(tbl("output_tbl_fa_no_email_interaction_template", "si_nlg_fa_no_email_interaction_html_active"), "html"),
                          (tbl("output_tbl_fa_no_email_interaction_template_curr", "si_nlg_fa_no_email_interaction_html_active_curr"), "latest")],
                 delivery="e-mail sender DAGs", notes=[]),
        ]
        out = []
        for sp in specs:
            lanes = [("Inputs", [Node(f"in{i}", t.split(".")[-1], "table", r, True) for i, (t, r) in enumerate(sp["inputs"])]),
                     (f"Processing ({sp['product']})", [Node(sid, lab, "nlg", sub) for sid, lab, sub in sp["steps"]]),
                     ("Output tables", [Node(f"out{i}", t.split(".")[-1], "table", r, True) for i, (t, r) in enumerate(sp["outputs"])]),
                     ("Delivery", [Node("deliv", sp["delivery"], "delivery", "")])]
            first = sp["steps"][0][0]
            edges = [(f"in{i}", first, "") for i in range(len(sp["inputs"]))]
            edges += [(sp["steps"][i][0], sp["steps"][i + 1][0], "") for i in range(len(sp["steps"]) - 1)]
            last_proc = sp["steps"][min(1, len(sp["steps"]) - 1)][0]
            edges += [(last_proc, f"out{i}", "") for i in range(len(sp["outputs"]))]
            edges += [(f"out{len(sp['outputs']) - 1}", "deliv", "")]
            out.append(Diagram(f"product_{sp['name']}", sp["title"], sp["desc"], lanes, edges, sp["notes"],
                               sp["inputs"] + sp["outputs"]))
        return out

    # ------------------------------------------------------------------ export
    def export(self, folder: Path) -> List[dict]:
        folder.mkdir(parents=True, exist_ok=True)
        diagrams = self.all()
        links = []
        attr_rows = {}
        for d in diagrams:
            for t, _ in d.tables:
                attr_rows.setdefault(t.split(".")[-1], self._attr_rows(t))
        md_index = ["# ODM / NLG architecture and flow diagrams", "", "[Knowledge graph](../knowledge_graph.md)", ""]
        for d in diagrams:
            (folder / f"{d.name}.html").write_text(self._page(d, diagrams), encoding="utf-8")
            (folder / f"{d.name}.md").write_text(d.markdown(attr_rows) + "\n\n[All diagrams](index.md) · [Knowledge graph](../knowledge_graph.md)\n",
                                                 encoding="utf-8")
            links.append({"name": d.name, "title": d.title, "group": d.group, "file": f"diagrams/{d.name}.html",
                          "md": f"diagrams/{d.name}.md", "description": d.description})
            md_index.append(f"- [{d.title}]({d.name}.md) - {d.description}")
        (folder / "index.html").write_text(self._index(diagrams), encoding="utf-8")
        (folder / "index.md").write_text("\n".join(md_index) + "\n", encoding="utf-8")
        (folder / "diagrams.json").write_text(json.dumps(links, indent=1), encoding="utf-8")
        log.info("Diagrams written: %d pages in %s", len(diagrams), folder)
        return links

    def _attr_rows(self, table: str) -> List[dict]:
        r = self.results
        if r is None or not len(r) or "table_name" not in r:
            return []
        t = table.split(".")[-1]
        g = r[r.table_name == t]
        return g.to_dict("records")

    def _page(self, d: Diagram, all_d: List[Diagram]) -> str:
        nav = " · ".join(f'<a href="{x.name}.html">{html.escape(_short(x))}</a>' for x in all_d if x.name != d.name)
        rows = []
        for t, role in d.tables:
            attrs = self._attr_rows(t)
            desc = ""
            if attrs:
                top = [a for a in attrs if str(a.get("business_description", ""))][:6]
                desc = "<ul>" + "".join(f"<li><code>{html.escape(str(a['column_name']))}</code> - {html.escape(str(a.get('functional_name', '')))}: "
                                        f"{html.escape(str(a.get('business_description', ''))[:220])}</li>" for a in top) + \
                       (f"<li>... {len(attrs)} attributes in the metadata workbook</li>" if len(attrs) > 6 else "") + "</ul>"
            rows.append(f"<tr><td><code>{html.escape(t)}</code></td><td>{html.escape(role)}</td><td>{desc or '<span class=muted>no attribute metadata in this run</span>'}</td></tr>")
        examples = "".join(f"<h3>{html.escape(t)}</h3><pre>{html.escape(c)}</pre>" for t, c in d.examples)
        legend = "".join(f'<span class="lg"><i style="background:{v[0]};border-color:{v[1]}"></i>{k}</span>' for k, v in COLORS.items() if k != "warn")
        return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>{html.escape(d.title)}</title>
<style>
:root{{--ink:#0f172a;--muted:#64748b;--line:#e2e8f0;--bg:#f6f7f9;--panel:#fff;--accent:#2563eb}}
@media (prefers-color-scheme: dark){{:root:not([data-theme="light"]){{--ink:#e5e9f2;--muted:#94a3b8;--line:#1f2a44;--bg:#0b1020;--panel:#121a2e;--accent:#60a5fa}}}}
:root[data-theme="dark"]{{--ink:#e5e9f2;--muted:#94a3b8;--line:#1f2a44;--bg:#0b1020;--panel:#121a2e;--accent:#60a5fa}}
body{{margin:0;background:var(--bg);color:var(--ink);font:14px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif}}
header{{background:var(--panel);border-bottom:1px solid var(--line);padding:12px 20px}} header h1{{font-size:18px;margin:0 0 4px}}
nav{{font-size:12.5px;color:var(--muted)}} nav a{{color:var(--accent);text-decoration:none}} a{{color:var(--accent)}}
main{{padding:16px 20px;max-width:1500px;margin:0 auto}} .card{{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:14px 16px;margin:0 0 14px}}
.svgwrap{{overflow:auto;background:#fff;border-radius:8px;padding:8px}} table{{border-collapse:collapse;width:100%;font-size:13px}}
td,th{{border-bottom:1px solid var(--line);padding:6px 8px;text-align:left;vertical-align:top}} code,pre{{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12px}}
pre{{background:var(--bg);border:1px solid var(--line);border-radius:8px;padding:10px;white-space:pre-wrap}} .muted{{color:var(--muted)}}
ul{{margin:4px 0;padding-left:18px}} .lg{{display:inline-flex;align-items:center;gap:6px;margin-right:12px;font-size:12px;color:var(--muted)}}
.lg i{{width:14px;height:14px;border:1.5px solid;border-radius:4px;display:inline-block}} h2{{font-size:15px;margin:0 0 8px}}
</style></head><body>
<header><h1>{html.escape(d.title)}</h1><nav><a href="../knowledge_graph.html">&larr; Knowledge graph</a> · <a href="index.html">All diagrams</a> · {nav}</nav></header>
<main>
<div class="card"><p>{html.escape(d.description)}</p><div class="svgwrap">{d.svg()}</div><div style="margin-top:8px">{legend}</div></div>
{('<div class="card"><h2>Key points</h2><ul>' + ''.join(f'<li>{html.escape(n)}</li>' for n in d.notes) + '</ul></div>') if d.notes else ''}
<div class="card"><h2>Tables involved ({len(d.tables)})</h2><table><tr><th>table</th><th>role</th><th>attribute metadata (this run / published)</th></tr>{''.join(rows)}</table></div>
{('<div class="card"><h2>Examples</h2>' + examples + '</div>') if d.examples else ''}
</main></body></html>"""

    def _index(self, diagrams: List[Diagram]) -> str:
        groups: Dict[str, List[Diagram]] = {}
        for d in diagrams:
            key = "NLG products" if d.name.startswith("product_") else d.group
            groups.setdefault(key, []).append(d)
        body = ""
        for g, ds in groups.items():
            body += f"<h2>{html.escape(g)}</h2><ul>" + "".join(f'<li><a href="{d.name}.html">{html.escape(d.title)}</a><br><span class="muted">{html.escape(d.description[:160])}</span></li>' for d in ds) + "</ul>"
        return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>ODM / NLG diagrams</title>
<style>body{{margin:0;padding:20px;background:#f6f7f9;color:#0f172a;font:14px/1.5 -apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif}} a{{color:#2563eb}} .muted{{color:#64748b;font-size:12.5px}} h2{{font-size:15px;margin:18px 0 6px}} li{{margin:0 0 8px}}
@media (prefers-color-scheme: dark){{body{{background:#0b1020;color:#e5e9f2}} a{{color:#60a5fa}}}}</style></head>
<body><h1 style="font-size:18px">ODM / NLG architecture and flow diagrams</h1><p><a href="../knowledge_graph.html">&larr; Knowledge graph</a></p>{body}</body></html>"""
