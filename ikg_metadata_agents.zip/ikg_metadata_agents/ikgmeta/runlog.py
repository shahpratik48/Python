"""Run log file (log_<date_timestamp>.txt) and token statistics (token_stats.json / .txt / workbook sheet)."""
from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Optional

import pandas as pd

_HANDLERS = {}


def start_log_file(out_dir, level: int = logging.INFO) -> Path:
    """Every log line of the run (all modules) goes to <out_dir>/log_<YYYYMMDD_HHMMSS>.txt (and still to the console)."""
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    path = out / f"log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    root = logging.getLogger()
    for k, h in list(_HANDLERS.items()):           # one log file per run
        root.removeHandler(h)
        _HANDLERS.pop(k, None)
    fh = logging.FileHandler(path, encoding="utf-8")
    fh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))
    fh.setLevel(level)
    root.addHandler(fh)
    if root.level > level or root.level == logging.NOTSET:
        root.setLevel(level)
    if not any(isinstance(h, logging.StreamHandler) and not isinstance(h, logging.FileHandler) for h in root.handlers):
        logging.basicConfig(level=level, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    for n in ("sqlglot", "httpx", "httpx2", "openai", "urllib3"):
        logging.getLogger(n).setLevel(logging.ERROR)
    _HANDLERS[str(path)] = fh
    logging.getLogger(__name__).info("log file: %s", path)
    return path


def current_log_file() -> Optional[Path]:
    return Path(next(iter(_HANDLERS))) if _HANDLERS else None


def token_stats_frames(llm, trace_rows=None):
    """(totals frame, per-process frame, per-table frame) from the LLM counters (+ agent trace for per-table calls)."""
    st = llm.token_stats() if hasattr(llm, "token_stats") else {"total": dict(getattr(llm, "usage", {})), "by_process": []}
    tot = pd.DataFrame([{"item": k, "value": v} for k, v in st["total"].items()])
    by = pd.DataFrame(st["by_process"])
    per_table = pd.DataFrame()
    if trace_rows:
        tr = pd.DataFrame(trace_rows)
        if len(tr) and "kind" in tr:
            turns = tr[tr.kind == "turn"]
            if len(turns):
                per_table = (turns.groupby(["agent", "task"]).size().reset_index(name="llm_turns")
                             .sort_values("llm_turns", ascending=False).head(400))
    return tot, by, per_table


def write_token_stats(llm, out_dir, trace_rows=None) -> dict:
    """token_stats.json + token_stats.txt in the output folder; returns the stats dict."""
    out = Path(out_dir)
    st = llm.token_stats() if hasattr(llm, "token_stats") else {"total": dict(getattr(llm, "usage", {})), "by_process": []}
    (out / "token_stats.json").write_text(json.dumps(st, indent=1, default=str), encoding="utf-8")
    tot = st["total"]
    lines = ["TOKEN STATISTICS", "=" * 60,
             f"model / deployment      : {tot.get('model', '')} / {tot.get('deployment', '')}",
             f"LLM calls               : {tot.get('calls', 0)}  (cache hits: {tot.get('cache_hits', 0)}, rate-limit hits: {tot.get('rate_limit_hits', 0)})",
             f"prompt tokens           : {tot.get('prompt_tokens', 0):,}  (prompt-cache hit {tot.get('prompt_cache_hit_pct', 0)} %, cached {tot.get('cached_tokens', 0):,})",
             f"completion tokens       : {tot.get('completion_tokens', 0):,}  (reasoning {tot.get('reasoning_tokens', 0):,} = {tot.get('reasoning_share_of_completion_pct', 0)} %)",
             f"TOTAL tokens            : {tot.get('total_tokens', 0):,}",
             f"avg per call            : prompt {tot.get('avg_prompt_tokens_per_call', 0):,} / completion {tot.get('avg_completion_tokens_per_call', 0):,}",
             f"elapsed                 : {tot.get('elapsed_minutes', 0)} min, {tot.get('tokens_per_minute_avg', 0):,} tokens/min on average",
             "", "PER PROCESS / AGENT", "-" * 60,
             f"{'process':28s}{'calls':>7s}{'prompt':>12s}{'completion':>12s}{'cached':>10s}{'total':>12s}{'share%':>8s}{'s/call':>8s}"]
    for r in st["by_process"]:
        lines.append(f"{r['process'][:27]:28s}{r['calls']:7d}{r['prompt_tokens']:12,}{r['completion_tokens']:12,}"
                     f"{r['cached_tokens']:10,}{r['total_tokens']:12,}{r['share_of_total_pct']:8.1f}{r['avg_seconds_per_call']:8.1f}")
    (out / "token_stats.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    logging.getLogger(__name__).info("token statistics: %s", "; ".join(lines[2:8]))
    return st
