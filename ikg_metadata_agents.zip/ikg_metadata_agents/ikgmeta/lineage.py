"""
Upstream lineage for a profile column, from two independent sources:

  1. core_ikg.ikg_column_lineage_master_auto_refresh (primary, as requested)
       target_table.target_column  <-  source_table.source_column  (logic, sql_process)
     walked recursively upstream until a table that no IKG script writes (= EDW / vendor source).
     Rows with an empty source_table (unqualified column in a multi-table query) are resolved
     against the FROM/JOIN tables of the same target.
  2. the SQL code itself (sqlglot resolver, code_lineage.py) - independent cross-check that also
     returns intermediate WHERE filters and CTE expressions.

Terminal source columns are looked up in the EDW Data Dictionary.
"""
from __future__ import annotations

import logging
import re
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple

import pandas as pd

log = logging.getLogger(__name__)

_NOISE_SRC = re.compile(r"^\{\{|^'|^\d|\(|^(null|true|false|current_date|now)$", re.I)


@dataclass
class Hop:
    depth: int
    table: str
    column: str
    source_schema: str
    source_table: str
    source_column: str
    logic: str
    sql_process: str
    inferred_source: bool = False     # source_table was empty and inferred from FROM/JOIN

    def text(self) -> str:
        if not self.source_table and (not self.source_column or _NOISE_SRC.search(self.source_column)):
            return f"{'  ' * self.depth}{self.table}.{self.column} = {self.logic.strip()[:200]} (literal / parameter)"
        src = f"{self.source_schema + '.' if self.source_schema else ''}{self.source_table or '?'}.{self.source_column}"
        inf = " (source table inferred)" if self.inferred_source else ""
        lg = self.logic.replace("\n", " ")
        lg = lg if len(lg) <= 300 else lg[:300] + " …"
        return f"{'  ' * self.depth}{self.table}.{self.column} <- {src}{inf} | {lg}"


@dataclass
class LineageResult:
    hops: List[Hop] = field(default_factory=list)
    terminal_sources: List[Tuple[str, str, str]] = field(default_factory=list)   # (schema, table, column)
    filters: Dict[str, List[str]] = field(default_factory=dict)                   # table -> where clauses
    found_in_lineage_table: bool = False
    ambiguous: bool = False
    stopped_at: List[str] = field(default_factory=list)                           # ikg tables with no lineage rows

    def chain_text(self) -> str:
        return "\n".join(h.text() for h in self.hops)

    def filters_text(self, limit: int = 6) -> str:
        out = []
        for t, fl in list(self.filters.items())[:limit]:
            for f in fl[:2]:
                f = f.replace("\n", " ")
                out.append(f"{t}: {f[:300]}")
        return "\n".join(out)


def _strip_window_specs(logic: str) -> str:
    """remove OVER ( ... ) blocks (balanced) so partition / order keys are not treated as values."""
    out, i, low = [], 0, logic.lower()
    while i < len(logic):
        m = re.compile(r"\bover\s*\(").search(low, i)
        if not m:
            out.append(logic[i:])
            break
        out.append(logic[i:m.start()])
        depth, j = 0, m.end() - 1
        while j < len(logic):
            if logic[j] == "(":
                depth += 1
            elif logic[j] == ")":
                depth -= 1
                if depth == 0:
                    break
            j += 1
        i = j + 1
    return "".join(out)


def is_value_reference(logic: str, column: str) -> bool:
    if not logic or not column:
        return True
    pat = re.compile(rf"(?<![\w]){re.escape(column)}(?![\w])", re.I)
    if not pat.search(logic):
        return True                       # resolved through an alias / sub-query: keep walking
    body = _strip_window_specs(logic)
    body = re.split(r"\bas\s+\w+\s*$", body.strip(), flags=re.I)[0]
    return pat.search(body) is not None   # False only if the column appears solely in OVER(...)


class LineageTableWalker:
    def __init__(self, lineage: pd.DataFrame, max_depth: int = 8, max_steps: int = 18, code_from_tables=None):
        self.max_depth, self.max_steps = max_depth, max_steps
        self.code_from_tables = code_from_tables      # callable(table) -> {(schema, table)} from the SQL code
        sel = lineage[lineage.sql_process.isin(["select", "select-value", "select*"]) &
                      lineage.target_column.ne("")]
        self.by_target: Dict[Tuple[str, str], List[dict]] = defaultdict(list)
        for r in sel.to_dict("records"):
            self.by_target[(r["target_table"], r["target_column"])].append(r)
        self.targets: Set[str] = set(lineage.target_table.unique())
        self.cols_of: Dict[str, Set[str]] = defaultdict(set)
        for (t, c) in self.by_target:
            self.cols_of[t].add(c)
        # FROM / JOIN tables per target (for unqualified columns)
        self.from_tables: Dict[str, Set[Tuple[str, str]]] = defaultdict(set)
        for r in lineage[lineage.source_table.ne("")][["target_table", "source_schema", "source_table"]] \
                .drop_duplicates().to_dict("records"):
            self.from_tables[r["target_table"]].add((r["source_schema"], r["source_table"]))
        flt = lineage[lineage.sql_process.isin(["where", "having"]) & lineage.logic.ne("")]
        self.filters: Dict[str, List[str]] = defaultdict(list)
        for t, g in flt.groupby("target_table"):
            self.filters[t] = list(dict.fromkeys(g.logic.tolist()))[:4]

    def has_table(self, table: str) -> bool:
        return table in self.targets

    def columns(self, table: str) -> Set[str]:
        return self.cols_of.get(table, set())

    def _infer_source(self, table: str, column: str, edw_cols: Set[Tuple[str, str]]) -> List[Tuple[str, str]]:
        cands = [(s, t) for s, t in self.from_tables.get(table, set()) if t != table]
        if not cands and self.code_from_tables:
            cands = [(s, t) for s, t in self.code_from_tables(table) if t != table]
        if len(cands) == 1:
            return cands
        hit = [(s, t) for s, t in cands if column in self.cols_of.get(t, set())]
        if not hit:
            hit = [(s, t) for s, t in cands if (t, column) in edw_cols]
        return hit

    def walk(self, table: str, column: str, edw_cols: Set[Tuple[str, str]] = frozenset()) -> LineageResult:
        res = LineageResult()
        seen: Set[Tuple[str, str]] = set()
        stack = [(table.lower(), column.lower(), 0)]
        while stack and len(res.hops) < self.max_steps:
            t, c, d = stack.pop(0)
            if (t, c) in seen:
                continue
            seen.add((t, c))
            rows = self.by_target.get((t, c), [])
            if not rows:
                if d > 0:
                    if t in self.targets:
                        res.stopped_at.append(f"{t}.{c}")
                continue
            if d == 0:
                res.found_in_lineage_table = True
            if t in self.filters and t not in res.filters:
                res.filters[t] = self.filters[t]
            uniq = {(r["source_schema"], r["source_table"], r["source_column"], r["logic"]): r for r in rows}
            for (ss, st, sc, lg), r in list(uniq.items())[:6]:
                if not sc or sc == "*" or _NOISE_SRC.search(sc):
                    res.hops.append(Hop(d, t, c, "", "", sc or "(literal)", lg, r["sql_process"]))
                    continue
                inferred = False
                targets = [(ss, st)] if st else []
                if not st:
                    targets = self._infer_source(t, sc, edw_cols)
                    inferred = True
                    if len(targets) > 1:
                        res.ambiguous = True
                if not targets:
                    res.hops.append(Hop(d, t, c, "", "", sc, lg, r["sql_process"], True))
                    continue
                value_ref = is_value_reference(lg, sc)
                for s2, t2 in targets[:2]:
                    res.hops.append(Hop(d, t, c, s2, t2, sc, lg, r["sql_process"], inferred))
                    if not value_ref:          # only a PARTITION BY / ORDER BY key: do not walk it
                        continue
                    if t2 in self.targets and d + 1 <= self.max_depth and t2 != t:
                        stack.append((t2, sc, d + 1))
                    elif t2 not in self.targets:
                        res.terminal_sources.append((s2, t2, sc))
        res.terminal_sources = list(dict.fromkeys(res.terminal_sources))
        return res


# =============================================================================
# EDW dictionary lookup
# =============================================================================
_SUFFIXES = re.compile(r"(_weekly|_daily|_monthly|_curr|_cur|_hist|_history|_view|_vw|_v|_snapshot|_ikg|_latest)$")


def normalize_edw_table(name: str) -> str:
    n = (name or "").lower().split(".")[-1].strip('"')
    n = re.sub(r"^(mv_|v_|vw_)", "", n)
    prev = None
    while prev != n:
        prev = n
        n = _SUFFIXES.sub("", n)
    return n


class EdwDictionary:
    def __init__(self, df: pd.DataFrame):
        self.df = df
        self.by_tc: Dict[Tuple[str, str], dict] = {}
        self.by_c: Dict[str, List[dict]] = defaultdict(list)
        for r in df.to_dict("records"):
            nt = normalize_edw_table(r["physical_table"])
            self.by_tc[(nt, r["column_name"])] = r
            self.by_c[r["column_name"]].append(r)
        self.norm_tables = {normalize_edw_table(t) for t in df.physical_table.unique()}

    def pairs(self) -> Set[Tuple[str, str]]:
        return {(t, c) for (t, c) in self.by_tc}

    def lookup(self, table: str, column: str) -> Tuple[Optional[dict], str]:
        """returns (row, match_quality) quality in exact | column_unique | column_ambiguous | none"""
        column = (column or "").lower()
        r = self.by_tc.get((normalize_edw_table(table), column))
        if r:
            return r, "exact"
        rows = self.by_c.get(column, [])
        if len({x["column_definition"] for x in rows if x["column_definition"]}) == 1:
            return next(x for x in rows if x["column_definition"]), "column_unique"
        if rows:
            best = next((x for x in rows if x["column_definition"]), rows[0])
            return best, "column_ambiguous"
        return None, "none"

    def describe(self, table: str, column: str) -> Tuple[str, str]:
        r, q = self.lookup(table, column)
        if not r:
            return "", "none"
        defin = r["column_definition"] or ""
        txt = (f"{r['physical_table']}.{column}: '{r['business_column_name']}'"
               f"{' - ' + defin if defin else ''} [{r['datatype']}] (table: {r['table_business_name']}"
               f"{' - ' + r['table_definition'][:160] if r['table_definition'] else ''})")
        if q != "exact":
            txt += f" [matched by column name only: {q}]"
        return txt, q


def python_writers(python_root, table_names: Set[str], max_chars: int = 2500) -> Dict[str, str]:
    """For tables with no SQL lineage, find Python code that writes them (snippet around the name)."""
    out: Dict[str, str] = {}
    if not table_names:
        return out
    pat = re.compile("|".join(re.escape(t) for t in sorted(table_names, key=len, reverse=True)))
    for p in python_root.rglob("*.py"):
        try:
            txt = p.read_text(encoding="utf-8", errors="replace")
        except Exception:  # noqa: BLE001
            continue
        for m in pat.finditer(txt):
            t = m.group(0)
            if t in out:
                continue
            s = max(0, m.start() - max_chars // 2)
            out[t] = f"# {p.name}\n" + txt[s:s + max_chars]
    return out
