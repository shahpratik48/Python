"""
Knowledge graph: entities = nodes, attributes = leaves, relationships between entities.

Relationship evidence (all recorded in the 'evidence' column):
  * key columns: a table of entity E carrying the key of entity F           (e.g. client table has acc_mhh_n)
  * join_keys of core_ikg.ikg_profile_table_descriptions
  * bridge / mapping tables in the code (acc_cli_shhp_map_ikg, fa_details_ikg, statement_plus ...)

Outputs (output/knowledge_graph/):
  knowledge_graph.html          interactive viewer, offline single file
  pictures/<Entity>.svg|png     picture per entity (attributes as leaves, related entities)
  pictures/overview.svg|png     all entities + relationships
  knowledge_graph.json / .graphml, neo4j_nodes.csv, neo4j_relationships.csv
"""
from __future__ import annotations

import html
import json
import logging
import re
import shutil
import subprocess
from collections import defaultdict
from pathlib import Path
from typing import Dict, Optional

import pandas as pd
import yaml

from .config import Config
from .sql_parser import extract_table_schema

log = logging.getLogger(__name__)
HERE = Path(__file__).resolve().parent


class KnowledgeGraph:
    def __init__(self, cfg: Config, pipeline=None, results: Optional[pd.DataFrame] = None,
                 descriptions: Optional[pd.DataFrame] = None, sql_root: Optional[Path] = None):
        self.cfg = cfg
        self.em = yaml.safe_load(cfg.path(cfg.sources["entity_model"]).read_text(encoding="utf-8"))
        self.p = pipeline
        self.results = results if results is not None else pipeline.results
        self.descriptions = descriptions if descriptions is not None else (
            pipeline.descriptions if pipeline is not None else pd.DataFrame(columns=["table_name", "join_keys"]))
        self.sql_root = sql_root or (pipeline.gitlab.sql_root() if pipeline is not None else None)
        self.out = cfg.path(cfg.output["folder"]) / "knowledge_graph"
        self.ents = self.em["entities"]
        self.key_owner = {k: e for e, v in self.ents.items() for k in v.get("keys", [])}

    @classmethod
    def from_workbook(cls, cfg: Config, xlsx: Path, sql_root: Optional[Path] = None,
                      descriptions: Optional[pd.DataFrame] = None):
        res = pd.read_excel(xlsx, sheet_name="Attribute_Metadata", dtype=str).fillna("")
        for c in ("needs_review", "is_technical"):
            if c in res:
                res[c] = res[c].str.lower().eq("true")
        return cls(cfg, results=res, descriptions=descriptions, sql_root=sql_root)

    # ------------------------------------------------------------------ build
    def _table_entity(self, table: str, row_entity: str = "") -> str:
        if self.p is not None:
            return self.p.table_entity(table)
        return row_entity

    def build(self) -> "KnowledgeGraph":
        r = self.results.fillna("")
        tech = set(self.em.get("technical_columns", []))
        prefix = sorted((self.em.get("attribute_prefix_entity") or {}).items(), key=lambda kv: -len(kv[0]))
        self.attrs: Dict[tuple, dict] = {}
        self.rels: Dict[tuple, dict] = {}
        self.ent_tables = defaultdict(list)
        for table, g in r.groupby("table_name"):
            tent = self._table_entity(table, g["table_entity"].iloc[0] if "table_entity" in g else "")
            if not tent:
                continue
            self.ent_tables[tent].append({"table": table, "grain": self._grain(table), "columns": len(g)})
            for x in g.to_dict("records"):
                col = x["column_name"]
                is_tech = col in tech or col.endswith("_key") or x.get("attribute_type") == "technical"
                if col in self.key_owner:
                    home = self.key_owner[col]
                    if home != tent:
                        self._rel(tent, home, f"{table} ({col})")
                elif x.get("entity") in self.ents and not is_tech:
                    home = x["entity"]
                else:
                    home = next((e for p, e in prefix if col.startswith(p)), tent)
                leaf = self.attrs.setdefault((home, col), {
                    "entity": home, "column": col, "data_type": x.get("data_type", ""),
                    "functional_name": x.get("functional_name", ""), "draft_name": col,
                    "description": x.get("business_description", ""), "attribute_type": x.get("attribute_type", ""),
                    "confidence": str(x.get("confidence_score", "")), "band": x.get("confidence_band", ""),
                    "needs_review": str(x.get("needs_review", "")).lower() == "true",
                    "is_key": col in self.key_owner, "is_technical": is_tech,
                    "expression": str(x.get("sql_expression", ""))[:300], "tables": [], "primary_table": ""})
                leaf["tables"].append(table)
                if tent == home and not leaf["primary_table"]:
                    leaf["primary_table"] = table
            # catalogue join keys
            jk = self._desc(table, "join_keys")
            for k in re.findall(r"[a-z_][a-z0-9_]+", jk.lower()):
                if k in self.key_owner and self.key_owner[k] != tent:
                    self._rel(tent, self.key_owner[k], f"{table} (catalogue join_keys: {k})")
        for a in self.attrs.values():
            a["primary_table"] = a["primary_table"] or a["tables"][0]
        self._bridges()
        log.info("Knowledge graph: %d entities with attributes, %d attribute leaves, %d relationships",
                 len({a['entity'] for a in self.attrs.values()}), len(self.attrs), len(self.rels))
        return self

    def _desc(self, table: str, col: str) -> str:
        d = self.descriptions[self.descriptions.table_name == table] if len(self.descriptions) else []
        return str(d.iloc[0][col]) if len(d) and col in d.columns else ""

    def _grain(self, table: str) -> str:
        if self.p is not None and table in self.p.table_analysis:
            return self.p.table_analysis[table].get("grain", "") or self._desc(table, "grain")
        return self._desc(table, "grain")

    def _rel(self, a: str, b: str, ev: str) -> None:
        lab = self.em.get("relationship_labels", {})
        if a == b:
            return
        if f"{a}->{b}" in lab:
            k = (a, b, lab[f"{a}->{b}"])
        elif f"{b}->{a}" in lab:
            k = (b, a, lab[f"{b}->{a}"])
        else:
            k = (a, b, "RELATED_TO")
        self.rels.setdefault(k, {"from": k[0], "to": k[1], "label": k[2], "evidence": []})["evidence"].append(ev)

    def _bridges(self) -> None:
        if not self.sql_root:
            return
        for bt, spec in (self.em.get("bridge_tables") or {}).items():
            f = Path(self.sql_root) / spec["folder"] / f"{bt}.sql"
            if not f.exists():
                hits = list(Path(self.sql_root).rglob(f"{bt}.sql"))
                if not hits:
                    log.warning("bridge table script not found: %s", bt)
                    continue
                f = hits[0]
            cols = {c.name for c in extract_table_schema(f).columns}
            present = [(c, e) for c, e in spec["links"].items() if c in cols]
            for i, (ca, ea) in enumerate(present):
                for cb, eb in present[i + 1:]:
                    self._rel(ea, eb, f"{bt} ({ca} / {cb})")

    def apply_review(self, review: dict) -> None:
        """Apply the graph agent's validated changes and descriptions."""
        self.ent_desc = {d["entity"]: d["description"] for d in review.get("entity_descriptions", [])}
        for ch in review.get("relationship_changes", []):
            a, b, act = ch["from_entity"], ch["to_entity"], ch["action"]
            keys = [k for k in self.rels if {k[0], k[1]} == {a, b}]
            if act == "remove":
                for k in keys:
                    self.rels.pop(k, None)
            elif act == "relabel" and keys and ch.get("new_label"):
                for k in keys:
                    v = self.rels.pop(k)
                    v.update(label=ch["new_label"], **{"from": a, "to": b})
                    v["evidence"].append(f"graph agent: {ch.get('reason', '')}")
                    self.rels[(a, b, ch["new_label"])] = v
            elif act == "add":
                lab = ch.get("new_label") or ch.get("label") or "RELATED_TO"
                self.rels.setdefault((a, b, lab), {"from": a, "to": b, "label": lab, "evidence": []})["evidence"].append(
                    f"{ch.get('evidence', '')} (graph agent: {ch.get('reason', '')})")
        for d in review.get("relationship_descriptions", []):
            for k, v in self.rels.items():
                if v["from"] == d.get("from_entity") and v["to"] == d.get("to_entity") and v["label"] == d.get("label"):
                    v["description"] = d.get("description", "")

    def joining_keys_frame(self) -> pd.DataFrame:
        """For every relationship: the key column(s) that join the two entities' tables, with the tables that carry it."""
        tables_of = {e: [t["table"] for t in ts] for e, ts in self.ent_tables.items()}
        cols_of = {}
        r = self.results.fillna("")
        for t, g in r.groupby("table_name"):
            cols_of[t] = set(g.column_name)
        rows = []
        for v in self.rels.values():
            a, b = v["from"], v["to"]
            for key, owner in self.key_owner.items():
                if owner not in (a, b):
                    continue
                ta = [t for t in tables_of.get(a, []) if key in cols_of.get(t, ())]
                tb = [t for t in tables_of.get(b, []) if key in cols_of.get(t, ())]
                if ta and tb:
                    rows.append({"from_entity": a, "relationship": v["label"], "to_entity": b, "joining_key": key,
                                 "key_owner_entity": owner, "from_tables": "; ".join(ta[:12]), "to_tables": "; ".join(tb[:12]),
                                 "join_condition": f"{a}.{key} = {b}.{key}"})
        return pd.DataFrame(rows, columns=["from_entity", "relationship", "to_entity", "joining_key", "key_owner_entity",
                                           "from_tables", "to_tables", "join_condition"])

    def relationships_frame(self) -> pd.DataFrame:
        return pd.DataFrame([{"from_entity": v["from"], "relationship": v["label"], "to_entity": v["to"],
                              "description": v.get("description", ""),
                              "evidence_count": len(set(v["evidence"])), "evidence": "; ".join(sorted(set(v["evidence"])))}
                             for v in self.rels.values()])

    # ------------------------------------------------------------------ export
    def to_json(self) -> dict:
        cnt = defaultdict(int)
        for a in self.attrs.values():
            if not a["is_technical"]:
                cnt[a["entity"]] += 1
        used = {a["entity"] for a in self.attrs.values()} | {v["from"] for v in self.rels.values()} | \
               {v["to"] for v in self.rels.values()}
        nodes = [{"id": f"E:{e}", "type": "entity", "name": e, "color": v.get("color", "#64748b"),
                  "description": getattr(self, "ent_desc", {}).get(e) or v.get("description", ""), "keys": v.get("keys", []),
                  "tables": self.ent_tables.get(e, []), "attribute_count": cnt[e]}
                 for e, v in self.ents.items() if e in used]
        nodes += [{"id": f"A:{e}:{c}", "type": "attribute", **a} for (e, c), a in sorted(self.attrs.items())]
        edges = [{"id": f"R:{v['from']}:{v['label']}:{v['to']}", "type": "relationship", "from": f"E:{v['from']}",
                  "to": f"E:{v['to']}", "label": v["label"], "description": v.get("description", ""),
                   "evidence": sorted(set(v["evidence"]))}
                 for v in self.rels.values()]
        edges += [{"id": f"H:{e}:{c}", "type": "has_attribute", "from": f"E:{e}", "to": f"A:{e}:{c}"}
                  for (e, c) in self.attrs]
        return {"nodes": nodes, "edges": edges}

    def export(self) -> Path:
        self.out.mkdir(parents=True, exist_ok=True)
        g = self.to_json()
        (self.out / "knowledge_graph.json").write_text(json.dumps(g, indent=1, ensure_ascii=False), encoding="utf-8")
        self._graphml(g)
        self._html(g)
        self.pictures(g)
        log.info("Knowledge graph written to %s", self.out)
        return self.out

    def _graphml(self, g: dict) -> None:
        import networkx as nx
        G = nx.MultiDiGraph()
        for n in g["nodes"]:
            G.add_node(n["id"], **{k: (json.dumps(v) if isinstance(v, (list, dict)) else ("" if v is None else v))
                                   for k, v in n.items() if k != "id"})
        for e in g["edges"]:
            G.add_edge(e["from"], e["to"], key=e["id"], label=e.get("label", "HAS_ATTRIBUTE"),
                       evidence="; ".join(e.get("evidence", [])))
        nx.write_graphml(G, self.out / "knowledge_graph.graphml")
        pd.DataFrame([{":ID": n["id"], ":LABEL": "Entity" if n["type"] == "entity" else "Attribute",
                       "name": n.get("name") or n.get("column"), "entity": n.get("entity", n.get("name")),
                       "functional_name": n.get("functional_name", ""), "description": n.get("description", ""),
                       "confidence": n.get("confidence", "")} for n in g["nodes"]]
                     ).to_csv(self.out / "neo4j_nodes.csv", index=False)
        pd.DataFrame([{":START_ID": e["from"], ":END_ID": e["to"], ":TYPE": e.get("label", "HAS_ATTRIBUTE"),
                       "evidence": "; ".join(e.get("evidence", []))} for e in g["edges"]]
                     ).to_csv(self.out / "neo4j_relationships.csv", index=False)

    def _html(self, g: dict) -> None:
        tpl = (HERE / "kg_viewer_template.html").read_text(encoding="utf-8")
        vis = HERE / "assets" / "vis-network.min.js"
        lib = f"<script>{vis.read_text(encoding='utf-8')}</script>"
        data = json.dumps(g, ensure_ascii=False).replace("</", "<\\/")
        page = (tpl.replace("/*__VIS_LIB__*/", lib).replace("__TITLE__", "IKG Knowledge Graph")
                .replace("/*__GRAPH_DATA__*/null", data).replace("/*__HAS_METADATA__*/false", "true"))
        (self.out / "knowledge_graph.html").write_text(page, encoding="utf-8")

    # ------------------------------------------------------------------ pictures
    def pictures(self, g: dict, max_attrs_per_table: int = 80) -> Path:
        pic = self.out / "pictures"
        pic.mkdir(parents=True, exist_ok=True)
        if shutil.which("dot"):
            self._graphviz(g, pic, max_attrs_per_table)
        else:
            log.info("Graphviz 'dot' not installed - drawing pictures with matplotlib")
            self._matplotlib(g, pic, max_attrs_per_table)
        return pic

    def _graphviz(self, g, pic, maxn):
        ents = {n["name"]: n for n in g["nodes"] if n["type"] == "entity"}
        rels = [e for e in g["edges"] if e["type"] == "relationship"]
        leaves = defaultdict(list)
        for n in g["nodes"]:
            if n["type"] == "attribute" and not n["is_technical"]:
                leaves[n["entity"]].append(n)
        esc = lambda s: html.escape(str(s), quote=True)  # noqa: E731

        def enode(name, big=False, nid=None):
            n = ents[name]
            return (f'"{nid or name}" [shape=box style="rounded,filled" fillcolor="{n["color"]}" fontcolor="white" '
                    f'fontname="Helvetica-Bold" fontsize={20 if big else 13} margin="0.25,0.12" '
                    f'label="{name}\\n{n["attribute_count"]} attributes"];')
        dots = {"overview": "\n".join(
            ['digraph G { graph [rankdir=LR overlap=false splines=true bgcolor="white" pad=0.4 nodesep=0.5 ranksep=1.2];',
             'edge [fontname="Helvetica" fontsize=10 color="#64748b" fontcolor="#334155"];']
            + [enode(e) for e in ents]
            + [f'"{r["from"][2:]}" -> "{r["to"][2:]}" [label="{r["label"]}"];' for r in rels] + ["}"])}
        for name in ents:
            by_t = defaultdict(list)
            for a in sorted(leaves[name], key=lambda a: a["column"]):
                by_t[a["primary_table"]].append(a)
            L = ['digraph G { graph [rankdir=LR bgcolor="white" pad=0.4 nodesep=0.25 ranksep=0.9];',
                 'node [fontname="Helvetica" fontsize=10]; edge [color="#94a3b8" fontname="Helvetica" fontsize=9];',
                 enode(name, True)]
            for i, (t, items) in enumerate(sorted(by_t.items())):
                rows = "".join(
                    f'<TR><TD ALIGN="LEFT" BGCOLOR="{ {"High": "#ecfdf5", "Medium": "#fffbeb", "Low": "#fef2f2"}.get(a.get("band"), "#ffffff") }">'
                    f'{esc(a["functional_name"] or a["column"])}</TD><TD ALIGN="LEFT"><FONT COLOR="#64748b">{esc(a["column"])}</FONT></TD></TR>'
                    for a in items[:maxn])
                more = f'<TR><TD COLSPAN="2"><I>+ {len(items) - maxn} more</I></TD></TR>' if len(items) > maxn else ""
                L.append(f'"t{i}" [shape=none margin=0 label=<<TABLE BORDER="0" CELLBORDER="1" CELLSPACING="0" CELLPADDING="3">'
                         f'<TR><TD COLSPAN="2" BGCOLOR="#e2e8f0"><B>{esc(t)}</B> ({len(items)})</TD></TR>{rows}{more}</TABLE>>];')
                L.append(f'"{name}" -> "t{i}" [arrowhead=none];')
            for r in rels:
                a, b = r["from"][2:], r["to"][2:]
                if name in (a, b):
                    other = b if a == name else a
                    L.append(enode(other, nid=f"rel_{other}"))
                    s, d = (name, f"rel_{other}") if a == name else (f"rel_{other}", name)
                    L.append(f'"{s}" -> "{d}" [label="{r["label"]}" color="#334155" penwidth=1.4];')
            dots[name] = "\n".join(L + ["}"])
        for name, srcdot in dots.items():
            fn = re.sub(r"[^A-Za-z0-9]+", "_", name).strip("_")
            (pic / f"{fn}.dot").write_text(srcdot, encoding="utf-8")
            subprocess.run(["dot", "-Tsvg", str(pic / f"{fn}.dot"), "-o", str(pic / f"{fn}.svg")], check=False)
            # PNG: cap the bitmap so cairo never has to scale it (large entities keep the SVG as the full picture)
            subprocess.run(["dot", "-Tpng", "-Gdpi=96", "-Gsize=60,60", str(pic / f"{fn}.dot"), "-o", str(pic / f"{fn}.png")],
                           check=False, capture_output=True)

    def _matplotlib(self, g, pic, maxn):
        import math
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import networkx as nx
        ents = {n["name"]: n for n in g["nodes"] if n["type"] == "entity"}
        rels = [e for e in g["edges"] if e["type"] == "relationship"]
        # overview
        G = nx.DiGraph()
        for r in rels:
            G.add_edge(r["from"][2:], r["to"][2:], label=r["label"])
        G.add_nodes_from(ents)
        pos = nx.kamada_kawai_layout(G) if len(G) > 2 else nx.circular_layout(G)
        fig, ax = plt.subplots(figsize=(18, 12))
        nx.draw_networkx_edges(G, pos, ax=ax, edge_color="#94a3b8", arrows=True, arrowsize=14, node_size=4200)
        nx.draw_networkx_edge_labels(G, pos, nx.get_edge_attributes(G, "label"), font_size=7, ax=ax)
        for n, (x, y) in pos.items():
            ax.text(x, y, f"{n}\n{ents[n]['attribute_count']} attrs", ha="center", va="center", fontsize=10,
                    color="white", weight="bold",
                    bbox=dict(boxstyle="round,pad=0.5", fc=ents[n]["color"], ec="none"))
        ax.axis("off")
        fig.savefig(pic / "overview.png", dpi=130, bbox_inches="tight")
        plt.close(fig)
        # per entity: table hubs on a ring, attributes listed beside each hub
        leaves = defaultdict(list)
        for n in g["nodes"]:
            if n["type"] == "attribute" and not n["is_technical"]:
                leaves[n["entity"]].append(n)
        for name, e in ents.items():
            by_t = defaultdict(list)
            for a in sorted(leaves[name], key=lambda a: a["column"]):
                by_t[a["primary_table"]].append(a)
            blocks = []
            for t, items in sorted(by_t.items(), key=lambda kv: -len(kv[1])):
                lines = [a["functional_name"] or a["column"] for a in items[:maxn]]
                if len(items) > maxn:
                    lines.append(f"+ {len(items) - maxn} more")
                blocks.append((f"{t} ({len(items)})", lines))
            ncol = max(1, min(4, len(blocks)))
            colw, lh = 10.0, 0.32
            rel_here = [r for r in rels if name in (r["from"][2:], r["to"][2:])]
            width = max(ncol * colw, len(rel_here) * 4.5, 12)
            # grid of table blocks below the entity
            y0, placed, col_y = -2.5, [], [-2.5] * ncol
            for i, (title, lines) in enumerate(blocks):
                c = max(range(ncol), key=lambda k: col_y[k])   # emptiest column
                h = (len(lines) + 1) * lh + 0.6
                x = -width / 2 + colw * c + colw / 2 + (width - ncol * colw) / 2
                placed.append((x, col_y[c], title, lines))
                col_y[c] -= h + 0.8
            bottom = min(col_y) - 1
            fig_h = max(8, (3.5 - bottom) * 0.42)
            fig, ax = plt.subplots(figsize=(max(12, width * 0.85), fig_h))
            ax.text(0, 0, f"{name}\n{e['attribute_count']} attributes", ha="center", va="center", fontsize=16,
                    color="white", weight="bold", bbox=dict(boxstyle="round,pad=0.6", fc=e["color"], ec="none"), zorder=3)
            for x, y, title, lines in placed:
                ax.plot([0, x], [-0.7, y + 0.1], color=e["color"], lw=0.8, zorder=0)
                ax.text(x, y, title + "\n" + "\n".join("• " + l[:60] for l in lines), ha="center", va="top",
                        fontsize=7, family="DejaVu Sans", linespacing=1.35,
                        bbox=dict(boxstyle="round,pad=0.5", fc="#f8fafc", ec=e["color"]), zorder=2)
            for j, r in enumerate(rel_here):
                other = r["to"][2:] if r["from"][2:] == name else r["from"][2:]
                ox = -width / 2 + (j + .5) * width / max(1, len(rel_here))
                outgoing = r["from"][2:] == name
                ax.annotate("", xy=(ox, 2.6) if outgoing else (0, 0.7), xytext=(0, 0.7) if outgoing else (ox, 2.6),
                            arrowprops=dict(arrowstyle="-|>", color="#334155", lw=1.1), zorder=1)
                ax.text(ox, 3.0, f"{other}", ha="center", va="center", fontsize=9, color="white", weight="bold",
                        bbox=dict(boxstyle="round,pad=0.35", fc=ents[other]["color"], ec="none"))
                ax.text((ox + 0) / 2, 1.65, r["label"], ha="center", va="center", fontsize=7, color="#334155",
                        bbox=dict(boxstyle="round,pad=0.15", fc="white", ec="none"))
            ax.set_xlim(-width / 2 - 1, width / 2 + 1)
            ax.set_ylim(bottom, 3.8)
            ax.axis("off")
            fn = re.sub(r"[^A-Za-z0-9]+", "_", name).strip("_")
            fig.savefig(pic / f"{fn}.png", dpi=110, bbox_inches="tight")
            plt.close(fig)
