"""Azure OpenAI (GPT-5) client: JSON calls, disk cache, retries, token accounting."""
from __future__ import annotations

import hashlib
import json
import logging
import random
import threading
import time
from pathlib import Path
from typing import Optional

from .config import Config, get_secret, ssl_verify

log = logging.getLogger(__name__)


class LLM:
    def __init__(self, cfg: Config, cache_dir: Path, client=None):
        self.c = cfg.llm
        self.cache_dir = Path(cache_dir) / "llm"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self._client = client
        self.extra = {"reasoning_effort": self.c["reasoning_effort"]} if self.c.get("reasoning_effort") else {}
        self.json_mode = True
        self.usage = {"calls": 0, "cache_hits": 0, "prompt_tokens": 0, "completion_tokens": 0, "cached_tokens": 0}
        self._lock = threading.Lock()

    @property
    def client(self):
        if self._client is None:
            from openai import AzureOpenAI
            kw = {}
            verify = ssl_verify(self.c.get("ssl_verify", True))
            if verify is not True:                      # corporate CA bundle path or verification disabled
                try:
                    import httpx
                except ImportError:                     # newer openai releases ship httpx2
                    import httpx2 as httpx
                kw["http_client"] = httpx.Client(verify=verify, timeout=self.c["request_timeout_seconds"])
            self._client = AzureOpenAI(
                azure_endpoint=self.c["endpoint"], api_version=self.c["api_version"],
                api_key=get_secret("llm_api_key"), timeout=self.c["request_timeout_seconds"], **kw)
        return self._client

    def check(self) -> str:
        r = self.client.chat.completions.create(
            model=self.c["deployment"], max_completion_tokens=2000,
            messages=[{"role": "user", "content": "Reply with the single word OK"}], **self.extra)
        return (r.choices[0].message.content or "").strip()

    def _key(self, *parts) -> str:
        h = hashlib.sha256()
        h.update(self.c["deployment"].encode())
        for p in parts:
            h.update(json.dumps(p, sort_keys=True, ensure_ascii=False, default=str).encode())
        return h.hexdigest()[:40]

    def json_call(self, system: str, user: str, prefix: Optional[str] = None, cache_key=None,
                  use_cache: bool = True) -> dict:
        """system + optional stable prefix message (e.g. full table SQL) + user payload -> JSON dict.
        The stable prefix comes first so Azure prompt caching can reuse it across batches."""
        key = self._key(system, prefix, user, cache_key)
        cf = self.cache_dir / f"{key}.json"
        if use_cache and cf.exists():
            with self._lock:
                self.usage["cache_hits"] += 1
            return json.loads(cf.read_text(encoding="utf-8"))
        msgs = [{"role": "system", "content": system}]
        if prefix:
            msgs.append({"role": "user", "content": prefix})
        msgs.append({"role": "user", "content": user})
        last = None
        for attempt in range(1, int(self.c["max_retries"]) + 1):
            try:
                kw = dict(model=self.c["deployment"], messages=msgs,
                          max_completion_tokens=int(self.c["max_completion_tokens"]), **self.extra)
                if self.json_mode:
                    kw["response_format"] = {"type": "json_object"}
                r = self.client.chat.completions.create(**kw)
                txt = (r.choices[0].message.content or "").strip()
                if not txt:
                    raise ValueError(f"empty response (finish_reason={r.choices[0].finish_reason}) - "
                                     "increase max_completion_tokens or reduce columns_per_call")
                if txt.startswith("```"):
                    txt = txt.split("\n", 1)[1].rsplit("```", 1)[0]
                data = json.loads(txt)
                self._account(r)
                cf.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
                return data
            except Exception as e:  # noqa: BLE001
                msg, last = str(e), e
                if "reasoning_effort" in msg and self.extra:
                    log.warning("reasoning_effort rejected by api_version - continuing without it")
                    self.extra = {}
                    continue
                if "response_format" in msg and self.json_mode:
                    log.warning("response_format rejected - continuing without JSON mode")
                    self.json_mode = False
                    continue
                if any(x in msg for x in ("401", "403", "DeploymentNotFound", "invalid subscription key")):
                    raise
                log.warning("LLM attempt %d failed: %s", attempt, msg[:300])
                time.sleep(float(self.c["retry_delay_seconds"]) * attempt)
        raise RuntimeError(f"LLM call failed after retries: {last}")

    def _account(self, r) -> None:
        u = getattr(r, "usage", None)
        with self._lock:
            self.usage["calls"] += 1
            if u:
                self.usage["prompt_tokens"] += getattr(u, "prompt_tokens", 0) or 0
                self.usage["completion_tokens"] += getattr(u, "completion_tokens", 0) or 0
                d = getattr(u, "prompt_tokens_details", None)
                self.usage["cached_tokens"] += (getattr(d, "cached_tokens", 0) or 0) if d else 0


    # ------------------------------------------------------------------ tool calling (agents)
    def chat(self, messages: list, tools: Optional[list] = None, tool_choice="auto", reasoning_effort=None):
        """One chat turn with function tools. Returns the assistant message object
        (.content, .tool_calls). Retries transient errors; drops unsupported optional params."""
        last = None
        for attempt in range(1, int(self.c["max_retries"]) + 1):
            try:
                extra = dict(self.extra)
                if reasoning_effort and extra:
                    extra["reasoning_effort"] = reasoning_effort
                kw = dict(model=self.c["deployment"], messages=messages,
                          max_completion_tokens=int(self.c["max_completion_tokens"]), **extra)
                if tools:
                    kw["tools"] = tools
                    kw["tool_choice"] = tool_choice
                r = self.client.chat.completions.create(**kw)
                self._account(r)
                return r.choices[0].message
            except Exception as e:  # noqa: BLE001
                msg, last = str(e), e
                if "reasoning_effort" in msg and self.extra:
                    log.warning("reasoning_effort rejected by api_version - continuing without it")
                    self.extra = {}
                    continue
                if "tool_choice" in msg and tool_choice not in ("auto", None):
                    tool_choice = "auto"
                    continue
                if any(x in msg for x in ("401", "403", "DeploymentNotFound", "invalid subscription key")):
                    raise
                log.warning("LLM chat attempt %d failed: %s", attempt, msg[:300])
                wait = float(self.c["retry_delay_seconds"]) * attempt
                if "429" in msg or "rate" in msg.lower():
                    wait = max(wait, 15.0 * attempt)
                time.sleep(wait + random.uniform(0, 2))
        raise RuntimeError(f"LLM chat failed after retries: {last}")

    def cache_get(self, key: str):
        f = self.cache_dir / f"agent_{key}.json"
        return json.loads(f.read_text(encoding="utf-8")) if f.exists() else None

    def cache_put(self, key: str, value) -> None:
        (self.cache_dir / f"agent_{key}.json").write_text(json.dumps(value, ensure_ascii=False, indent=1, default=str),
                                                          encoding="utf-8")
