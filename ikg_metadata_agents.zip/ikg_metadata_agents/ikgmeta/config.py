"""Configuration + runtime secrets (never persisted)."""
from __future__ import annotations

import getpass
import logging
import os
from pathlib import Path
from typing import Any, Dict, Optional

import yaml

log = logging.getLogger(__name__)

PACKAGE_ROOT = Path(__file__).resolve().parent.parent      # folder with the notebook
DEFAULT_CONFIG = PACKAGE_ROOT / "config" / "ikg_metadata_config.yaml"

_SECRETS: Dict[str, str] = {}
SECRET_SPECS = {
    "llm_api_key": ("IKG_AZURE_OPENAI_API_KEY", "Azure OpenAI subscription key"),
    "gp_password": ("IKG_GP_PASSWORD", "Greenplum password"),
    "gitlab_token": ("IKG_GITLAB_TOKEN", "GitLab personal access token"),
}


class Config(dict):
    """dict with attribute access + path resolution relative to the package root."""

    def __getattr__(self, k):
        v = self[k]
        return Config(v) if isinstance(v, dict) else v

    def path(self, rel: str) -> Path:
        p = Path(rel)
        return p if p.is_absolute() else PACKAGE_ROOT / p


def load_config(path: Optional[str] = None) -> Config:
    p = Path(path) if path else DEFAULT_CONFIG
    cfg = Config(yaml.safe_load(p.read_text(encoding="utf-8")))
    log.info("Loaded config %s", p)
    return cfg


def get_secret(name: str, allow_prompt: bool = True) -> str:
    """Secret from cache -> environment variable -> hidden prompt (asked once per session)."""
    if name in _SECRETS:
        return _SECRETS[name]
    env, label = SECRET_SPECS[name]
    val = os.environ.get(env, "")
    if not val and allow_prompt:
        val = getpass.getpass(f"{label} (input hidden): ").strip()
    if not val:
        raise RuntimeError(f"{label} not provided (set env {env} or enter it when prompted)")
    _SECRETS[name] = val
    return val


def set_secret(name: str, value: str) -> None:
    _SECRETS[name] = value


def ask_all_secrets(need_llm=True, need_db=True, need_gitlab=True) -> None:
    """Notebook helper: prompt for every secret up-front."""
    if need_llm:
        get_secret("llm_api_key")
    if need_db:
        get_secret("gp_password")
    if need_gitlab:
        get_secret("gitlab_token")


def ssl_verify(value: Any):
    if isinstance(value, str) and value and value.lower() not in ("true", "false"):
        return value                       # CA bundle path
    return str(value).lower() != "false"
