"""
Markdown twins of the HTML pages (kept side by side in output/knowledge_graph/):

    knowledge_graph.md          entity overview (mermaid graph with the relationships), relationships, joining keys,
                                tables per entity; one file per entity under md/<Entity>.md with every attribute
    diagrams/<name>.md          written by diagrams.py (mermaid flowchart = the same boxes and lines)
    skill.md                    index skill file that refers to every markdown file (what it holds, when to read it)
"""
from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import List

import pandas as pd

log = logging.getLogger(__name__)


def _safe(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", name).strip("_")


def _cell(v) -> str:
    return str(v if v is not None else "").replace("|", "/").replace("\n", " ").strip()


def export_markdown(cfg, p, kg, out: Path) -> List[Path]:
    out = Path(out)
    md_dir = out / "md"
    md_dir.mkdir(parents=True, exist_ok=True)
    g = kg.to_json()
    ents = [n for n in g["nodes"] if n["type"] == "entity"]
    attrs = [n for n in g["nodes"] if n["type"] == "attribute"]
    rels = [e for e in g["edges"] if e["type"] == "relationship"]
    written: List[Path] = []
    # ---- overview
    lines = ["# IKG Knowledge Graph", "",
             f"{len(ents)} entities, {sum(1 for a in attrs if not a['is_technical'])} business attributes, "
             f"{len(rels)} relationships, {len({t for a in attrs for t in a['tables']})} profile tables "
             f"(schema `{cfg.greenplum['schema']}`). HTML viewer: [knowledge_graph.html](knowledge_graph.html).", "",
             "## Entity model", "", "```mermaid", "flowchart LR"]
    for e in ents:
        lines.append(f'  {_safe(e["name"])}["{e["name"]}<br/>{e["attribute_count"]} attributes"]')
    for r in rels:
        lines.append(f'  {_safe(r["from"][2:])} -->|{r["label"]}| {_safe(r["to"][2:])}')
    lines += ["```", "", "## Relationships", "", "| from | relationship | to | description | evidence |", "| --- | --- | --- | --- | --- |"]
    for r in rels:
        lines.append(f"| {r['from'][2:]} | {r['label']} | {r['to'][2:]} | {_cell(r.get('description', ''))} | {_cell('; '.join(r.get('evidence', [])[:4]))} |")
    jk = kg.joining_keys_frame()
    if len(jk):
        lines += ["", "## Joining keys", "", "| from | relationship | to | key | join condition | tables |", "| --- | --- | --- | --- | --- | --- |"]
        for r in jk.itertuples(index=False):
            lines.append(f"| {r.from_entity} | {r.relationship} | {r.to_entity} | `{r.joining_key}` | `{r.join_condition}` | {_cell(r.from_tables)} / {_cell(r.to_tables)} |")
    lines += ["", "## Entities", "", "| entity | description | keys | attributes | tables | page |", "| --- | --- | --- | --- | --- | --- |"]
    for e in sorted(ents, key=lambda x: -x["attribute_count"]):
        lines.append(f"| {e['name']} | {_cell(e.get('description', ''))} | {', '.join(e.get('keys', []))} | {e['attribute_count']} | "
                     f"{len(e.get('tables', []))} | [md/{_safe(e['name'])}.md](md/{_safe(e['name'])}.md) |")
    dlinks = getattr(kg, "diagram_links", []) or []
    if dlinks:
        lines += ["", "## ODM / NLG diagrams", ""] + [f"- [{d['title']}]({d.get('md', d['file'])})" for d in dlinks]
    lines += ["", "See [skill.md](skill.md) for the index of every markdown file."]
    f = out / "knowledge_graph.md"
    f.write_text("\n".join(lines) + "\n", encoding="utf-8")
    written.append(f)
    # ---- one page per entity
    by_ent = {}
    for a in attrs:
        by_ent.setdefault(a["entity"], []).append(a)
    for e in ents:
        rows = sorted(by_ent.get(e["name"], []), key=lambda a: (a["primary_table"], a["column"]))
        el = [f"# {e['name']}", "", _cell(e.get("description", "")), "",
              f"Keys: {', '.join('`' + k + '`' for k in e.get('keys', [])) or '-'} · {e['attribute_count']} business attributes",
              "", "## Relationships", ""]
        rs = [r for r in rels if r["from"] == e["id"] or r["to"] == e["id"]]
        el += [f"- {r['from'][2:]} **{r['label']}** {r['to'][2:]}" for r in rs] or ["- none"]
        el += ["", "## Profile tables (primary entity)", ""]
        el += [f"- `{t['table']}` - one row per {_cell(t.get('grain', ''))} ({t['columns']} columns)" for t in e.get("tables", [])] or ["- attributes arrive from other tables"]
        el += ["", "## Attributes", "", "| column | business name | description | type | confidence | tables |", "| --- | --- | --- | --- | --- | --- |"]
        for a in rows:
            el.append(f"| `{a['column']}` | {_cell(a.get('functional_name', ''))} | {_cell(a.get('description', ''))[:400]} | "
                      f"{_cell(a.get('attribute_type', ''))} | {_cell(a.get('confidence', ''))} {_cell(a.get('band', ''))} | {', '.join(a.get('tables', [])[:6])} |")
        el += ["", "[Knowledge graph](../knowledge_graph.md)"]
        fe = md_dir / f"{_safe(e['name'])}.md"
        fe.write_text("\n".join(el) + "\n", encoding="utf-8")
        written.append(fe)
    # ---- ODM / NLG table pages (metadata of the domain tables)
    dom = getattr(p, "table_domain", {}) or {}
    if dom:
        res = getattr(p, "final_results", None)
        res = res if res is not None else p.all_results_frame()
        tl = ["# ODM and NLG tables - attribute metadata", "", "| domain | schema | table | attributes |", "| --- | --- | --- | --- |"]
        for t, d in sorted(dom.items()):
            g_ = res[res.table_name == t] if len(res) else res
            tl.append(f"| {d} | {p.table_schema(t)} | `{t}` | {len(g_)} |")
        tl += [""]
        for t, d in sorted(dom.items()):
            g_ = res[res.table_name == t] if len(res) else res
            tl += [f"## {d.upper()} `{p.table_schema(t)}.{t}`", "", "| column | business name | description | upstream |", "| --- | --- | --- | --- |"]
            for r in g_.itertuples(index=False):
                tl.append(f"| `{r.column_name}` | {_cell(getattr(r, 'functional_name', ''))} | {_cell(getattr(r, 'business_description', ''))[:400]} | {_cell(getattr(r, 'upstream', ''))[:200]} |")
            tl.append("")
        ft = md_dir / "odm_nlg_tables.md"
        ft.write_text("\n".join(tl) + "\n", encoding="utf-8")
        written.append(ft)
    # ---- skill.md: index of every markdown file
    sk = ["---", "name: insights-knowledge-graph", "description: Index of the IKG / ODM / NLG knowledge graph pages (markdown) - entities, attributes, "
          "relationships, ODM / NLG architecture, narrative rule flows and product flows. Read the file that matches the question.", "---", "",
          "# Insights knowledge graph - skill index", "",
          f"Generated by the metadata program (schema `{cfg.greenplum['schema']}`, environment {cfg.get('environment', '')}). "
          "Every page exists as HTML (interactive) and as markdown (this index refers to the markdown files).", "",
          "## How to use", "", "- Entity, its keys, relationships and attributes -> `md/<Entity>.md`",
          "- Which key joins two entities -> `knowledge_graph.md` (Joining keys)",
          "- ODM / NLG table columns -> `md/odm_nlg_tables.md`",
          "- How ODM / NLG work (DAGs, rules, products) -> `diagrams/*.md`", "",
          "## Files", "", "| file | content |", "| --- | --- |",
          "| [knowledge_graph.md](knowledge_graph.md) | entity model (mermaid), relationships, joining keys, entity list |"]
    for e in sorted(ents, key=lambda x: -x["attribute_count"]):
        sk.append(f"| [md/{_safe(e['name'])}.md](md/{_safe(e['name'])}.md) | {e['name']}: {e['attribute_count']} attributes, keys {', '.join(e.get('keys', [])) or '-'} |")
    if dom:
        sk.append("| [md/odm_nlg_tables.md](md/odm_nlg_tables.md) | ODM / NLG tables with their attribute metadata |")
    for d in dlinks:
        sk.append(f"| [{d.get('md', d['file'])}]({d.get('md', d['file'])}) | {d['title']}: {_cell(d.get('description', ''))} |")
    sk.append("| [diagrams/index.md](diagrams/index.md) | list of all ODM / NLG diagrams |")
    skill_files = (cfg.get("skills") or {}).get("folder", "skills")
    sk += ["", f"Firm knowledge skill files (not generated): `{skill_files}/ikg_knowledge_skills.md`, `odm_knowledge_skill.md`, `nlg_knowledge_skill.md`."]
    fs = out / "skill.md"
    fs.write_text("\n".join(sk) + "\n", encoding="utf-8")
    written.append(fs)
    log.info("markdown pages written: %d files under %s (index skill.md)", len(written) + len(dlinks), out)
    return written
