"""
Skill library: every *.md file under the skills folder (next to the notebook), any depth.
Supports Anthropic-style SKILL.md files with YAML front-matter (name / description) and plain markdown.
Files are split into sections (by headings) and indexed for keyword search (BM25).
"""
from __future__ import annotations

import math
import re
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List

import yaml

_WORD = re.compile(r"[a-z0-9_]+")


@dataclass
class Section:
    file: str
    heading: str
    text: str
    start_line: int


class SkillLibrary:
    def __init__(self, folder: Path):
        self.folder = Path(folder)
        self.files: Dict[str, dict] = {}
        self.sections: List[Section] = []
        if self.folder.exists():
            for p in sorted(self.folder.rglob("*.md")):
                if p.name.lower() != "readme.md":          # folder instructions, not firm knowledge
                    self._load(p)
        self._index()

    def _load(self, p: Path) -> None:
        rel = str(p.relative_to(self.folder)).replace("\\", "/")
        raw = p.read_text(encoding="utf-8", errors="replace")
        meta, body = {}, raw
        m = re.match(r"^---\s*\n(.*?)\n---\s*\n", raw, re.S)
        if m:
            try:
                meta = yaml.safe_load(m.group(1)) or {}
            except yaml.YAMLError:
                meta = {}
            body = raw[m.end():]
        body = re.sub(r"<!--.*?-->", "", body, flags=re.S)
        self.files[rel] = {"file": rel, "name": meta.get("name", p.stem), "description": meta.get("description", ""),
                           "chars": len(body), "text": body}
        cur, buf, start = "(top)", [], 1
        for i, line in enumerate(body.splitlines(), 1):
            if re.match(r"^#{1,4}\s", line):
                if "".join(buf).strip():
                    self.sections.append(Section(rel, cur, "\n".join(buf).strip(), start))
                cur, buf, start = line.lstrip("#").strip(), [], i
            else:
                buf.append(line)
        if "".join(buf).strip():
            self.sections.append(Section(rel, cur, "\n".join(buf).strip(), start))

    def _index(self) -> None:
        self.tf = [Counter(_WORD.findall((s.heading + " " + s.text).lower())) for s in self.sections]
        df = Counter(w for tf in self.tf for w in tf)
        n = max(1, len(self.sections))
        self.idf = {w: math.log(1 + (n - c + .5) / (c + .5)) for w, c in df.items()}
        self.avg = sum(sum(tf.values()) for tf in self.tf) / n if self.tf else 1

    # ------------------------------------------------------------- API (tools)
    def list(self) -> List[dict]:
        return [{"file": f["file"], "name": f["name"], "description": f["description"], "chars": f["chars"],
                 "sections": [s.heading for s in self.sections if s.file == f["file"]]} for f in self.files.values()]

    def read(self, file: str, section: str = "") -> str:
        f = self.files.get(file) or next((v for k, v in self.files.items() if k.endswith(file)), None)
        if not f:
            return f"ERROR: skill file '{file}' not found. Files: {list(self.files)}"
        if section:
            secs = [s for s in self.sections if s.file == f["file"] and section.lower() in s.heading.lower()]
            if secs:
                return "\n\n".join(f"## {s.heading}\n{s.text}" for s in secs)
        return f["text"]

    def search(self, query: str, k: int = 6) -> List[dict]:
        q = _WORD.findall(query.lower())
        scores = []
        for i, tf in enumerate(self.tf):
            ln = sum(tf.values())
            s = sum(self.idf.get(w, 0) * tf[w] * 2.2 / (tf[w] + 1.2 * (.25 + .75 * ln / self.avg)) for w in q if w in tf)
            if s > 0:
                scores.append((s, i))
        out = []
        for s, i in sorted(scores, reverse=True)[:k]:
            sec = self.sections[i]
            out.append({"file": sec.file, "section": sec.heading, "score": round(s, 2), "text": sec.text[:1500]})
        return out

    def full_text(self) -> str:
        return "\n\n".join(f"===== SKILL FILE: {k} =====\n{v['text']}" for k, v in self.files.items())

    def total_chars(self) -> int:
        return sum(f["chars"] for f in self.files.values())
