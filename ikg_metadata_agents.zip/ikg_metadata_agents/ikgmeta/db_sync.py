"""
Greenplum persistence.

  * ikg_attribute_business_description  - Metadata tab; created once (IF NOT EXISTS), then only NEW
                                           (table_name, column_name) pairs are inserted (delta mode)
  * ikg_metadata_glossary_llm            - replaced each run
  * ikg_graph_relationship               - replaced each run
  * ikg_graph_joining_key                - replaced each run
  * ikg_combined_household_client_account_profile_curr - dropped and re-created each run (combined_table.py)

Every table this program creates gets:
  ALTER TABLE <schema>.<table> OWNER TO <table_owner_role>;  GRANT SELECT ON <schema>.<table> TO <table_reader_role>;
"""
from __future__ import annotations

import logging
import re
from typing import Iterable, List, Optional, Set, Tuple

import pandas as pd

log = logging.getLogger(__name__)

METADATA_COLUMNS = [            # Metadata tab minus id / data_type, plus audit columns
    ("table_name", "varchar(200)"), ("column_name", "varchar(200)"),
    ("business_attribute_name", "varchar(400)"), ("description", "text"),
    ("confidence_score", "integer"), ("confidence_band", "varchar(20)"), ("entity", "varchar(100)"),
    ("attribute_type", "varchar(50)"), ("unit", "varchar(50)"), ("derivation_type", "varchar(50)"),
    ("confidence_reason", "text"), ("difficult_to_generate", "boolean"), ("what_is_required", "text"),
    ("evidence_used", "varchar(400)"), ("verify_verdict", "varchar(50)"),
    ("run_timestamp", "timestamp"), ("model", "varchar(200)"),
    ("upstream", "text"),                    # upstream hops of the attribute (table.column <- hop <- ... <- source)
    ("current_datetime", "timestamp"),       # last run that touched / confirmed the row (same value for every row)
]
ADDED_COLUMNS = [("upstream", "text"), ("current_datetime", "timestamp")]   # added to an existing table when missing


def _ident(name: str) -> str:
    if not re.fullmatch(r"[a-z_][a-z0-9_]*", name):
        raise ValueError(f"invalid identifier: {name}")
    return name


class GreenplumSync:
    def __init__(self, gp, cfg):
        self.gp = gp
        self.cfg = cfg
        self.schema = _ident(cfg.output["target_schema"])
        self.owner = cfg.greenplum.get("table_owner_role", "")
        self.reader = cfg.greenplum.get("table_reader_role", "")

    # ------------------------------------------------------------------ helpers
    def exec(self, sql: str, params: Optional[dict] = None) -> None:
        from sqlalchemy import text
        with self.gp.engine.begin() as con:
            con.execute(text(sql), params or {})

    def table_exists(self, table: str) -> bool:
        df = self.gp.read("select 1 from information_schema.tables where table_schema = :s and table_name = :t",
                          {"s": self.schema, "t": table})
        return len(df) > 0

    def grant_sql(self, table: str) -> str:
        t = f"{self.schema}.{_ident(table)}"
        out = []
        if self.owner:
            out.append(f"ALTER TABLE {t} OWNER TO {_ident(self.owner)};")
        if self.reader:
            out.append(f"GRANT SELECT ON {t} TO {_ident(self.reader)};")
        return "\n".join(out)

    def apply_grants(self, table: str) -> None:
        for stmt in self.grant_sql(table).split("\n"):
            if stmt.strip():
                self.exec(stmt)
        log.info("owner/grant applied to %s.%s", self.schema, table)

    def replace_table(self, df: pd.DataFrame, table: str) -> None:
        """Drop + create a table from a frame (all text), then owner/grant."""
        t = _ident(table)
        self.exec(f"DROP TABLE IF EXISTS {self.schema}.{t}")
        df.astype(str).to_sql(t, self.gp.engine, schema=self.schema, if_exists="replace", index=False,
                              chunksize=2000, method="multi")
        self.apply_grants(t)
        log.info("replaced %s.%s with %d rows", self.schema, t, len(df))

    # ------------------------------------------------------------------ metadata table
    def ensure_metadata_table(self) -> bool:
        """Create the business-description table once. Returns True when it was created now."""
        t = _ident(self.cfg.output["metadata_table"])
        if self.table_exists(t):
            return False
        cols = ",\n  ".join(f"{c} {typ}" for c, typ in METADATA_COLUMNS)
        self.exec(f"CREATE TABLE {self.schema}.{t} (\n  {cols}\n) DISTRIBUTED BY (table_name, column_name)")
        self.apply_grants(t)
        log.info("created %s.%s", self.schema, t)
        return True

    def columns_of(self, table: str, schema: Optional[str] = None) -> List[str]:
        df = self.gp.read("select column_name from information_schema.columns where table_schema = :s and table_name = :t "
                          "order by ordinal_position", {"s": schema or self.schema, "t": table})
        return [str(c).lower() for c in df.iloc[:, 0].tolist()]

    def ensure_columns(self, table: str, columns: List[Tuple[str, str]], schema: Optional[str] = None) -> List[str]:
        """ALTER TABLE ... ADD COLUMN for every column that does not exist yet ("add columns if not exists")."""
        sch = _ident(schema or self.schema)
        t = _ident(table)
        have = set(self.columns_of(t, sch))
        added = []
        for c, typ in columns:
            if c.lower() not in have:
                self.exec(f"ALTER TABLE {sch}.{t} ADD COLUMN {_ident(c)} {typ}")
                added.append(c)
                log.info("added column %s %s to %s.%s", c, typ, sch, t)
        return added

    def refresh_existing_rows(self, run_timestamp: str, upstream: Optional[pd.DataFrame] = None) -> dict:
        """current_datetime = this run for EVERY row; upstream filled where it is empty (first run after the column was
        added) from the frame (table_name, column_name, upstream) through a staging table."""
        t = _ident(self.cfg.output["metadata_table"])
        if not self.table_exists(t):
            return {}
        out = {}
        self.exec(f"UPDATE {self.schema}.{t} SET current_datetime = :ts", {"ts": pd.to_datetime(run_timestamp).to_pydatetime()})
        out["current_datetime_rows"] = "all"
        if upstream is not None and len(upstream):
            stg = f"{t}_upstream_stg"
            df = upstream[["table_name", "column_name", "upstream"]].copy()
            df = df[df.upstream.fillna("").ne("")]
            if len(df):
                self.replace_table(df, stg)
                self.exec(f"UPDATE {self.schema}.{t} SET upstream = (SELECT s.upstream FROM {self.schema}.{stg} s "
                          f"WHERE s.table_name = {self.schema}.{t}.table_name AND s.column_name = {self.schema}.{t}.column_name) "
                          f"WHERE (upstream IS NULL OR upstream = '') AND EXISTS (SELECT 1 FROM {self.schema}.{stg} s "
                          f"WHERE s.table_name = {self.schema}.{t}.table_name AND s.column_name = {self.schema}.{t}.column_name)")
                self.exec(f"DROP TABLE IF EXISTS {self.schema}.{stg}")
                out["upstream_candidates"] = int(len(df))
        log.info("existing rows refreshed in %s.%s: %s", self.schema, t, out)
        return out

    def existing_pairs(self) -> Set[Tuple[str, str]]:
        t = _ident(self.cfg.output["metadata_table"])
        if not self.table_exists(t):
            return set()
        df = self.gp.read(f"select table_name, column_name from {self.schema}.{t}")
        return {(a.lower(), b.lower()) for a, b in df.itertuples(index=False)}

    def deployed_profile_pairs(self) -> Set[Tuple[str, str]]:
        """(table, column) of every deployed table matching generation.profile_table_pattern."""
        pat = self.cfg.generation.get("profile_table_pattern", "%profile_curr_ikg")
        df = self.gp.read("select table_name, column_name from information_schema.columns "
                          "where table_schema = :s and table_name like :p",
                          {"s": self.cfg.greenplum["schema"], "p": pat})
        return {(a.lower(), b.lower()) for a, b in df.itertuples(index=False)}

    def insert_metadata(self, metadata: pd.DataFrame, run_timestamp: str, model: str,
                        only_pairs: Optional[Set[Tuple[str, str]]] = None) -> int:
        """Append rows of the Metadata frame (never updates existing pairs)."""
        t = _ident(self.cfg.output["metadata_table"])
        df = metadata.copy()
        existing = self.existing_pairs()
        keep = [(a, b) not in existing and (only_pairs is None or (a, b) in only_pairs)
                for a, b in zip(df.table_name.str.lower(), df.column_name.str.lower())]
        df = df[keep]
        if df.empty:
            log.info("no new attributes to insert into %s.%s", self.schema, t)
            return 0
        df["run_timestamp"] = run_timestamp
        df["model"] = model
        df["current_datetime"] = run_timestamp
        cols = [c for c, _ in METADATA_COLUMNS]
        for c in cols:
            if c not in df.columns:
                df[c] = None
        df = df[cols]
        df["confidence_score"] = pd.to_numeric(df["confidence_score"], errors="coerce").fillna(0).astype(int)
        df["difficult_to_generate"] = df["difficult_to_generate"].astype(str).str.lower().eq("true")
        df["run_timestamp"] = pd.to_datetime(df["run_timestamp"])
        df["current_datetime"] = pd.to_datetime(df["current_datetime"])
        df.to_sql(t, self.gp.engine, schema=self.schema, if_exists="append", index=False, chunksize=2000, method="multi")
        log.info("inserted %d new attribute rows into %s.%s", len(df), self.schema, t)
        return len(df)

    # ------------------------------------------------------------------ graph tables
    def write_graph(self, relationships: pd.DataFrame, joining_keys: pd.DataFrame) -> None:
        self.replace_table(relationships, self.cfg.output["graph_relationship_table"])
        self.replace_table(joining_keys, self.cfg.output["graph_joining_key_table"])

    def write_glossary(self, glossary: pd.DataFrame) -> None:
        self.replace_table(glossary, self.cfg.output["glossary_table"])

    # ------------------------------------------------------------------ key uniqueness (combined table)
    def key_is_unique(self, table: str, keys: List[str], date_col: str = "profile_date") -> Optional[bool]:
        """True when (keys) identify one row per key in the latest snapshot of the table."""
        try:
            sch = _ident(self.cfg.greenplum["schema"])
            t = _ident(table)
            ks = ", ".join(_ident(k) for k in keys)
            has_date = len(self.gp.read("select 1 from information_schema.columns where table_schema=:s and "
                                        "table_name=:t and column_name=:c", {"s": sch, "t": t, "c": date_col})) > 0
            where = f"where {date_col} = (select max({date_col}) from {sch}.{t})" if has_date else ""
            df = self.gp.read(f"select count(*) n, count(distinct ({ks})) d from {sch}.{t} {where}")
            n, d = int(df.iloc[0].n), int(df.iloc[0].d)
            return n == d
        except Exception as e:  # noqa: BLE001
            log.warning("uniqueness check failed for %s: %s", table, e)
            return None

    @staticmethod
    def split_script(sql: str) -> List[str]:
        """Statements of a script (comment lines removed, split on ';' at line end)."""
        clean = "\n".join(l for l in sql.splitlines() if not l.strip().startswith("--"))
        return [s.strip().rstrip(";") for s in re.split(r";\s*\n", clean + "\n") if s.strip()]

    def run_script(self, sql: str, label: str = "") -> None:
        """Run a multi-statement script one statement at a time, logging each step."""
        stmts = self.split_script(sql)
        for i, st in enumerate(stmts, 1):
            self.exec(st)
            log.info("%s step %d/%d ok: %s", label or "script", i, len(stmts), self._describe(st))

    @staticmethod
    def _describe(stmt: str) -> str:
        s = " ".join(stmt.split())
        m = re.match(r"(?i)(drop table if exists|create table|alter table|grant select on)\s+(\S+)\s*(.*)", s)
        if not m:
            return s[:80]
        verb, obj, rest = m.group(1).lower(), m.group(2), m.group(3)
        if verb.startswith("drop table"):
            return f"dropped {obj} (if existed)"
        if verb.startswith("create"):
            return f"created {obj} as select * from source"
        if verb.startswith("grant"):
            return f"granted select on {obj} to {rest.split()[-1]}"
        if "owner to" in rest.lower():
            return f"owner of {obj} set to {rest.split()[-1]}"
        mc = re.search(r"(?i)drop column if exists\s+(\S+)", rest)
        return f"dropped column {mc.group(1)} from {obj}" if mc else f"altered {obj}"
