"""
Airflow entry point (DAG Insights_metadata) - same logic as the notebook, only the inputs differ:

    notebook : config/ikg_metadata_config.yaml + secrets asked at run time (or env variables)
    Airflow  : Variables ENV, IKG_SCHEMA, EDW_INPUT_SCHEMA, GENESIS_DDLC_IKG_GIT_SECRET, IKG_AZURE_OPENAI_API_KEY
               + Connection IKG_GP_GPRDSP  (names configurable in config: airflow.*)

`run_insights_metadata(...)` is Airflow-agnostic (plain arguments) so it can be unit-tested; the DAG file collects
the Variables / Connection and calls it. Secrets are put into the in-memory secret store only.
"""
from __future__ import annotations

import json
import logging
import os
import tempfile
import time
import traceback
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

log = logging.getLogger(__name__)


def build_config(env: str = "PROD", ikg_schema: Optional[str] = None, edw_input_schema: Optional[str] = None,
                 gp: Optional[dict] = None, output_dir: Optional[str] = None, config_path: Optional[str] = None,
                 owner_role: Optional[str] = None, reader_role: Optional[str] = None):
    """Config for one Airflow run: ODM_ENV (PROD | UAT | TEST) selects schema, NLG ini section and roles; the
    Variables IKG_SCHEMA / IKG_TABLE_OWNER_GROUP / IKG_TABLE_READER_GROUP override them when set."""
    from .config import apply_environment, load_config
    cfg = load_config(config_path, environment=env)
    apply_environment(cfg, env, ikg_schema=ikg_schema, owner_role=owner_role, reader_role=reader_role)
    if edw_input_schema:
        cfg["domains"]["edw_input_schema"] = edw_input_schema.strip().lower()
        ups = list(cfg["domains"].get("upstream_schemas") or [])
        if cfg["domains"]["edw_input_schema"] not in ups:
            ups.append(cfg["domains"]["edw_input_schema"])
        cfg["domains"]["upstream_schemas"] = ups
    if gp:
        for k in ("host", "port", "database", "user"):
            if gp.get(k):
                cfg["greenplum"][k] = gp[k]
    out = Path(output_dir) if output_dir else Path(tempfile.gettempdir()) / "insights_metadata"
    cfg["output"]["folder"] = str(out)
    cfg["skills"]["generated_folder"] = str(out / "skills")       # DAG folder is usually read-only
    return cfg


def run_insights_metadata(env: str = "PROD", ikg_schema: Optional[str] = None, edw_input_schema: Optional[str] = None,
                          gitlab_token: Optional[str] = None, azure_key: Optional[str] = None,
                          gp: Optional[dict] = None, output_dir: Optional[str] = None, run_id: str = "",
                          config_path: Optional[str] = None, orchestration: Optional[str] = None,
                          selftest: bool = False, owner_role: Optional[str] = None, reader_role: Optional[str] = None) -> dict:
    """Whole pipeline (prepare -> agents -> outputs -> Greenplum load). Returns a JSON-serialisable summary that the
    DAG pushes to XCom and renders into the e-mail."""
    from . import agents
    from . import sources as src
    from .config import set_secret
    from .llm import LLM

    t0 = time.time()
    cfg = build_config(env, ikg_schema, edw_input_schema, gp, output_dir, config_path, owner_role, reader_role)
    out = Path(cfg["output"]["folder"])
    out.mkdir(parents=True, exist_ok=True)
    _file_logging(out / "run.log")
    log.info("Insights_metadata run %s | ODM_ENV=%s | IKG schema %s | EDW schema %s | owner %s | reader %s | output %s",
             run_id, cfg["environment"], cfg["greenplum"]["schema"], cfg["domains"].get("edw_input_schema"),
             cfg["greenplum"]["table_owner_role"], cfg["greenplum"]["table_reader_role"], out)
    if gitlab_token:
        set_secret("gitlab_token", gitlab_token)
    if azure_key:
        set_secret("llm_api_key", azure_key)
    if gp and gp.get("password"):
        set_secret("gp_password", gp["password"])
    summary: Dict[str, object] = {"run_id": run_id, "environment": cfg["environment"], "ikg_schema": cfg["greenplum"]["schema"],
                                  "table_owner_role": cfg["greenplum"]["table_owner_role"], "table_reader_role": cfg["greenplum"]["table_reader_role"],
                                  "nlg_ini_section": (cfg["domains"]["nlg"].get("ini_section") or {}).get(cfg["environment"], ""),
                                  "edw_input_schema": cfg["domains"].get("edw_input_schema"), "output_dir": str(out),
                                  "started": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "status": "running"}
    try:
        gp_client = src.Greenplum(cfg) if cfg["sources"]["mode"] == "db" else None
        if selftest:
            from .agents.selftest import ScriptedLLM
            llm = ScriptedLLM(cfg, out / "cache")
        else:
            llm = LLM(cfg, out / "cache")
        ctx = agents.prepare(cfg, llm, gp_client)
        p = ctx.p
        summary["tables"] = {"ikg_profile": len(p.ikg_schemas()),
                             "odm": sorted(t for t, d in p.table_domain.items() if d == "odm"),
                             "nlg": sorted(t for t, d in p.table_domain.items() if d == "nlg"),
                             "nlg_ini_section": getattr(p.loader, "nlg_section", "") if p.loader else ""}
        summary["delta"] = {k: v for k, v in (p.delta_info or {}).items() if k not in ("deployed_but_not_in_code",)}
        res = agents.run(ctx, orchestration or cfg.get("agents", {}).get("orchestration", "llm"))
        q = res.get("quality", {})
        summary.update({"status": "success", "quality": q, "greenplum": res.get("greenplum"),
                        "workbook": res.get("workbook") or str(out / cfg["output"]["metadata_xlsx"]),
                        "graph_html": res.get("graph_html") or str(out / "knowledge_graph" / "knowledge_graph.html"),
                        "diagrams": str(out / "knowledge_graph" / "diagrams" / "index.html"),
                        "llm_usage": getattr(llm, "usage", {}), "errors": list(q.get("recent_errors") or [])[:20]})
    except Exception as e:  # noqa: BLE001
        log.exception("Insights_metadata failed")
        summary.update({"status": "failed", "error": f"{type(e).__name__}: {e}", "traceback": traceback.format_exc()[-4000:]})
    summary["duration_minutes"] = round((time.time() - t0) / 60, 1)
    summary["finished"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    summary["email_html"] = email_html(summary)
    (out / "run_summary.json").write_text(json.dumps(summary, indent=1, default=str), encoding="utf-8")
    summary["attachments"] = attachments(summary)          # workbook (if < 15 MB) + run_summary.json
    if summary["status"] != "success":
        raise RuntimeError(summary.get("error", "Insights_metadata failed"))
    return summary


# ----------------------------------------------------------------------------- helpers
def _file_logging(path: Path) -> None:
    root = logging.getLogger()
    if not any(isinstance(h, logging.FileHandler) and getattr(h, "baseFilename", "") == str(path) for h in root.handlers):
        fh = logging.FileHandler(path, encoding="utf-8")
        fh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))
        root.addHandler(fh)
    if root.level > logging.INFO:
        root.setLevel(logging.INFO)
    for n in ("sqlglot", "httpx", "httpx2", "openai"):
        logging.getLogger(n).setLevel(logging.ERROR)


def attachments(summary: dict, max_mb: float = 15.0) -> List[str]:
    files = []
    for key in ("workbook",):
        f = summary.get(key)
        if f and os.path.exists(str(f)) and os.path.getsize(str(f)) <= max_mb * 1024 * 1024:
            files.append(str(f))
    rs = os.path.join(str(summary.get("output_dir", "")), "run_summary.json")
    if os.path.exists(rs):
        files.append(rs)
    return files


def email_html(s: dict) -> str:
    import html as H
    ok = s.get("status") == "success"
    q = s.get("quality") or {}
    d = s.get("delta") or {}
    t = s.get("tables") or {}
    rows = [
        ("Status", "SUCCESS" if ok else f"FAILED - {s.get('error', '')}"),
        ("ODM_ENV / IKG schema / NLG ini section", f"{s.get('environment')} / {s.get('ikg_schema')} / [{s.get('nlg_ini_section', '')}]"),
        ("Table owner / reader role", f"{s.get('table_owner_role')} / {s.get('table_reader_role')}"),
        ("Started / finished / duration", f"{s.get('started')} / {s.get('finished')} / {s.get('duration_minutes')} min"),
        ("IKG profile tables in scope", t.get("ikg_profile", "")),
        ("ODM tables", ", ".join(t.get("odm", []) or []) or "(none)"),
        ("NLG tables", f"{len(t.get('nlg', []) or [])} from nlg_db_tables.ini [{t.get('nlg_ini_section', '')}]"),
        ("Delta", f"mode {d.get('mode', '')}; existing {d.get('existing_in_db', '')}; new attributes {d.get('new_pairs', d.get('attributes', ''))}"),
        ("ODM / NLG tables skipped (already in metadata table)", ", ".join(d.get("odm_nlg_tables_skipped (already in metadata table)", []) or []) or "(none)"),
        ("Attributes authored", f"{q.get('attributes_done', 0)} (High {q.get('high', 0)}, Medium {q.get('medium', 0)}, Low {q.get('low', 0)}, difficult {q.get('difficult', 0)})"),
        ("Glossary needs input", q.get("glossary_needs_input", "")),
        ("Greenplum load", H.escape(json.dumps(s.get("greenplum"), default=str)) if s.get("greenplum") else "(not loaded)"),
        ("Errors", "<br>".join(H.escape(str(x)) for x in (s.get("errors") or [])) or str(q.get("errors", 0))),
        ("Workbook", s.get("workbook", "")), ("Knowledge graph", s.get("graph_html", "")), ("ODM / NLG diagrams", s.get("diagrams", "")),
        ("LLM usage", H.escape(json.dumps(s.get("llm_usage"), default=str)) if s.get("llm_usage") else ""),
    ]
    body = "".join(f"<tr><td style='padding:4px 10px;color:#555;white-space:nowrap'><b>{H.escape(str(k))}</b></td>"
                   f"<td style='padding:4px 10px'>{v if k in ('Greenplum load', 'Errors', 'LLM usage') else H.escape(str(v))}</td></tr>" for k, v in rows)
    color = "#2e7d32" if ok else "#c62828"
    return (f"<div style='font-family:Segoe UI,Arial,sans-serif;font-size:13px'><h3 style='color:{color}'>Insights metadata "
            f"(IKG profiles + ODM + NLG) - {'Success' if ok else 'Failed'}</h3><table style='border-collapse:collapse'>{body}</table>"
            f"<p style='color:#777'>Generated by the Insights_metadata DAG (run {H.escape(str(s.get('run_id', '')))}).</p></div>")
