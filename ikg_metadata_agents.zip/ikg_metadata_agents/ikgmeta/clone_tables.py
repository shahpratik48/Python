"""
Normalised clones of every profile table: <table><clone_suffix>  (default suffix _norm).

A clone keeps the table's OWN attributes and its joining keys and drops the columns that are duplicated copies
of another table's attributes, reachable through a joining key. Data of every kept column is identical to the
original (CREATE TABLE AS SELECT <kept columns> FROM <original>).

A column is removed from table T only when ALL hold:
  1. it is not a key (entity_model keys / catalogue join keys) and not technical (index, ikg_key, profile_date ...)
  2. the same column exists in an OWNER table: the primary table of the entity the column belongs to
     (mhh_* -> household_profile_curr_ikg, ip_* -> client_profile_curr_ikg, acc_* -> account_profile_curr_ikg,
     or, for other entities, the entity's biggest one-row-per-key table), and the owner table is not T itself
  3. T carries the joining key of that owner entity (acc_mhh_n / ip_cli_i / acc_i ...) - the column can be re-joined
  4. the lineage of T.column and owner.column ends in the same source column (or both are pass-throughs of the
     same name) - it is the same fact, not a same-named different measure
Every decision is written to the Clone_Report sheet (kept / removed + owner table + joining key + reason) and
the full script to output/<clone_sql_file>; with Greenplum connected the clones are dropped and re-created,
then ALTER OWNER / GRANT SELECT are applied.
"""
from __future__ import annotations

import logging
import re
from typing import Dict, List, Optional, Set, Tuple

import pandas as pd

log = logging.getLogger(__name__)


class CloneTablesBuilder:
    def __init__(self, pipeline, kg):
        self.p = pipeline
        self.kg = kg
        self.cfg = pipeline.cfg
        self.schema = self.cfg.greenplum["schema"]
        self.out_schema = self.cfg.output["target_schema"]
        self.suffix = self.cfg.output.get("clone_suffix", "_norm")
        em = pipeline.entity_model
        self.tech = set(em.get("technical_columns", []))
        self.keys: Set[str] = {k for v in em["entities"].values() for k in v.get("keys", [])}
        self.key_owner: Dict[str, str] = {k: e for e, v in em["entities"].items() for k in v.get("keys", [])}
        self.prefix_entity = sorted((em.get("attribute_prefix_entity") or {}).items(), key=lambda kv: -len(kv[0]))
        self.report: List[dict] = []
        self.summary: List[dict] = []

    # ------------------------------------------------------------------ helpers
    def _owner_tables(self) -> Dict[str, str]:
        """entity -> primary (owner) table: the entity's biggest table whose grain is the entity key."""
        fixed = {"Household": "household_profile_curr_ikg", "Client": "client_profile_curr_ikg",
                 "Account": "account_profile_curr_ikg"}
        owners = {e: t for e, t in fixed.items() if t in self.p.schemas}
        by_ent: Dict[str, List[str]] = {}
        for t in self.p.schemas:
            by_ent.setdefault(self.p.table_entity(t), []).append(t)
        for e, ts in by_ent.items():
            if e and e not in owners:
                owners[e] = max(ts, key=lambda t: len(self.p.schemas[t].columns))
        return owners

    def _col_entity(self, col: str, table_entity: str) -> str:
        if col in self.key_owner:
            return self.key_owner[col]
        for pfx, e in self.prefix_entity:
            if col.startswith(pfx):
                return e
        return table_entity

    def _join_key_for(self, table: str, owner_entity: str) -> Optional[str]:
        cols = {c.name for c in self.p.schemas[table].columns}
        for k, e in self.key_owner.items():
            if e == owner_entity and k in cols:
                return k
        return None

    def _source(self, table: str, col: str) -> str:
        ctx = getattr(self.p, "ctx_full", self.p.ctx)
        r = ctx[(ctx.table_name == table) & (ctx.column_name == col)]
        if r.empty:
            return ""
        return str(r.iloc[0].terminal_sources or "").split("; ")[0]

    # ------------------------------------------------------------------ build
    def build(self) -> str:
        owners = self._owner_tables()
        owner_cols = {t: {c.name for c in self.p.schemas[t].columns} for t in owners.values()}
        catalog_keys: Dict[str, Set[str]] = {}
        for t in self.p.schemas:
            jk = self.p.description_row(t).get("join_keys", "")
            catalog_keys[t] = set(re.findall(r"[a-z_][a-z0-9_]+", jk.lower()))
        scripts = []
        for t in sorted(self.p.schemas):
            tent = self.p.table_entity(t)
            kept, removed = [], []
            for c in self.p.schemas[t].columns:
                n = c.name
                if n == "*":
                    continue
                row = {"table_name": t, "clone_table": t + self.suffix, "column_name": n, "table_entity": tent}
                if n in self.tech or n.endswith("_key"):
                    kept.append(n); row.update(action="kept", reason="technical column"); self.report.append(row); continue
                if n in self.keys or n in catalog_keys.get(t, ()):
                    kept.append(n); row.update(action="kept", reason="joining key"); self.report.append(row); continue
                ent = self._col_entity(n, tent)
                owner = owners.get(ent)
                if not owner or owner == t or n not in owner_cols.get(owner, ()):
                    kept.append(n); row.update(action="kept", reason="own attribute (no owner table carries it)"); self.report.append(row); continue
                jk = self._join_key_for(t, ent)
                if not jk:
                    kept.append(n); row.update(action="kept", reason=f"copy of {owner}.{n} but no joining key to {ent} in this table"); self.report.append(row); continue
                s1, s2 = self._source(t, n), self._source(owner, n)
                if s1 and s2 and s1 != s2:
                    kept.append(n); row.update(action="kept", reason=f"same name as {owner}.{n} but different lineage ({s1} vs {s2})"); self.report.append(row); continue
                removed.append(n)
                row.update(action="removed", owner_table=owner, owner_entity=ent, joining_key=jk,
                           reason=f"duplicate of {owner}.{n}; re-join on {jk}")
                self.report.append(row)
            self.summary.append({"table_name": t, "clone_table": t + self.suffix, "entity": tent,
                                 "columns_original": len(kept) + len(removed), "columns_kept": len(kept),
                                 "columns_removed": len(removed), "removed_columns": ", ".join(removed)})
            scripts.append(self._script(t, kept, removed))
        log.info("clone script: %d tables, %d columns removed in total", len(scripts),
                 sum(s["columns_removed"] for s in self.summary))
        return "\n\n".join(scripts)

    def _script(self, t: str, kept: List[str], removed: List[str]) -> str:
        clone = f"{self.out_schema}.{t}{self.suffix}"
        owner, reader = self.cfg.greenplum.get("table_owner_role", ""), self.cfg.greenplum.get("table_reader_role", "")
        dist = self.p.schemas[t].distribution_key
        dist = [d for d in dist if d in kept]
        dist_sql = f"DISTRIBUTED BY ({', '.join(dist)})" if dist else "DISTRIBUTED RANDOMLY"
        sel = ",\n  ".join(kept)
        grants = "\n".join(x for x in [f"ALTER TABLE {clone} OWNER TO {owner};" if owner else "",
                                       f"GRANT SELECT ON {clone} TO {reader};" if reader else ""] if x)
        return (f"-- {t}{self.suffix}: clone of {t} without {len(removed)} duplicated column(s)"
                f"{': ' + ', '.join(removed) if removed else ''}\n"
                f"DROP TABLE IF EXISTS {clone};\nCREATE TABLE {clone} AS\nSELECT\n  {sel}\nFROM {self.schema}.{t}\n{dist_sql};\n{grants}")

    def report_frame(self) -> pd.DataFrame:
        cols = ["table_name", "clone_table", "column_name", "table_entity", "action", "owner_table", "owner_entity",
                "joining_key", "reason"]
        df = pd.DataFrame(self.report)
        for c in cols:
            if c not in df.columns:
                df[c] = ""
        return df[cols].fillna("")

    def summary_frame(self) -> pd.DataFrame:
        return pd.DataFrame(self.summary)
