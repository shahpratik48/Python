"""
Clones of every profile table: <table><clone_suffix>  (default suffix _v2).

Rule: every business attribute lives in exactly ONE profile table (its HOME); every other profile table that carries
the same column and can re-join the home table on a key loses it in the clone. Keys and technical columns are
always kept. Data of every kept column is identical to the original (CREATE TABLE AS SELECT * ... then DROP COLUMN).

Home of a column (first that applies):
  1. output.dedupe.home_overrides  (column -> table) in the config
  2. the OWNER table of the column's entity (prefix rule: mhh_* -> household_profile_curr_ikg, ip_*/cli_* ->
     client_profile_curr_ikg, acc_* -> account_profile_curr_ikg, other entities -> their biggest one-row-per-key table)
     when that table carries the column
  3. otherwise the biggest table of that entity that carries the column (then the biggest table overall)
A column is removed from table T when T is not the home, T carries a joining key to the home's entity (or shares a
key column with the home table), and the lineage of both columns does not end in DIFFERENT source columns
(same-named but different facts are kept and flagged "review"). Columns listed in output.dedupe.never_remove are
always kept. Every decision is written to the Clone_Report sheet (kept / removed + home table + joining key +
reason), the duplicated columns and their homes to the Clone_Duplicates sheet, and the full script to
output/<clone_sql_file>; with Greenplum connected the clones are dropped and re-created table by table.
"""
from __future__ import annotations

import logging
import re
from typing import Dict, List, Optional, Set, Tuple

import pandas as pd

log = logging.getLogger(__name__)


class CloneTablesBuilder:
    def __init__(self, pipeline, kg):
        self.p = pipeline
        self.kg = kg
        self.cfg = pipeline.cfg
        self.schema = self.cfg.greenplum["schema"]
        self.out_schema = self.cfg.output["target_schema"]
        self.suffix = self.cfg.output.get("clone_suffix", "_v2")
        em = pipeline.entity_model
        self.tech = set(em.get("technical_columns", []))
        self.keys: Set[str] = {k for v in em["entities"].values() for k in v.get("keys", [])}
        self.key_owner: Dict[str, str] = {k: e for e, v in em["entities"].items() for k in v.get("keys", [])}
        self.prefix_entity = sorted((em.get("attribute_prefix_entity") or {}).items(), key=lambda kv: -len(kv[0]))
        self.report: List[dict] = []
        self.summary: List[dict] = []
        self.scripts: Dict[str, str] = {}      # table -> its own DDL block (run one table at a time)

    # ------------------------------------------------------------------ helpers
    def _owner_tables(self) -> Dict[str, str]:
        """entity -> primary (owner) table: the entity's biggest table whose grain is the entity key."""
        fixed = {"Household": "household_profile_curr_ikg", "Client": "client_profile_curr_ikg",
                 "Account": "account_profile_curr_ikg"}
        owners = {e: t for e, t in fixed.items() if t in self.p.schemas}
        by_ent: Dict[str, List[str]] = {}
        for t in self.p.schemas:
            by_ent.setdefault(self.p.table_entity(t), []).append(t)
        for e, ts in by_ent.items():
            if e and e not in owners:
                owners[e] = max(ts, key=lambda t: len(self.p.schemas[t].columns))
        return owners

    def _col_entity(self, col: str, table_entity: str) -> str:
        if col in self.key_owner:
            return self.key_owner[col]
        for pfx, e in self.prefix_entity:
            if col.startswith(pfx):
                return e
        return table_entity

    def _join_key_for(self, table: str, owner_entity: str) -> Optional[str]:
        cols = {c.name for c in self.p.schemas[table].columns}
        for k, e in self.key_owner.items():
            if e == owner_entity and k in cols:
                return k
        return None

    def _source(self, table: str, col: str) -> str:
        ctx = getattr(self.p, "ctx_full", self.p.ctx)
        r = ctx[(ctx.table_name == table) & (ctx.column_name == col)]
        if r.empty:
            return ""
        return str(r.iloc[0].terminal_sources or "").split("; ")[0]

    # ------------------------------------------------------------------ build
    def _key_cols(self, t: str, catalog_keys: Dict[str, Set[str]]) -> Set[str]:
        return {c.name for c in self.p.schemas[t].columns if c.name in self.keys or c.name in catalog_keys.get(t, ())}

    def _link(self, t: str, home: str, home_entity: str, catalog_keys: Dict[str, Set[str]]) -> Optional[str]:
        """Joining key from t to the home table: the home entity's key, else any key column both tables share."""
        jk = self._join_key_for(t, home_entity)
        if jk:
            return jk
        shared = self._key_cols(t, catalog_keys) & self._key_cols(home, catalog_keys)
        return sorted(shared)[0] if shared else None

    @staticmethod
    def _src_col(src: str) -> str:
        return (src or "").split(".")[-1].strip().lower()

    def build(self) -> str:
        dd = self.cfg.output.get("dedupe") or {}
        overrides = {str(k).lower(): v for k, v in (dd.get("home_overrides") or {}).items()}
        never = {str(c).lower() for c in (dd.get("never_remove") or [])}
        owners = self._owner_tables()
        catalog_keys: Dict[str, Set[str]] = {}
        for t in self.p.schemas:
            jk = self.p.description_row(t).get("join_keys", "")
            catalog_keys[t] = set(re.findall(r"[a-z_][a-z0-9_]+", jk.lower()))
        tables = sorted(self.p.schemas)
        ncols = {t: len(self.p.schemas[t].columns) for t in tables}
        # 1. which tables carry each column
        carriers: Dict[str, List[str]] = {}
        for t in tables:
            for c in self.p.schemas[t].columns:
                if c.name != "*":
                    carriers.setdefault(c.name, []).append(t)
        # 2. the home of every column that appears in more than one table
        self.homes: Dict[str, dict] = {}
        for n, ts in carriers.items():
            if len(ts) < 2 or n in self.tech or n.endswith("_key") or n in self.keys:
                continue
            ents = {t: self._col_entity(n, self.p.table_entity(t)) for t in ts}
            ent = max(set(ents.values()), key=lambda e: sum(1 for v in ents.values() if v == e))
            owner = owners.get(ent)
            if n in overrides and overrides[n] in ts:
                home, how = overrides[n], "home_overrides"
            elif owner in ts:
                home, how = owner, f"owner table of {ent}"
            else:
                same = [t for t in ts if self.p.table_entity(t) == ent] or ts
                home, how = max(same, key=lambda t: ncols[t]), f"biggest {ent} table carrying it"
            self.homes[n] = {"column_name": n, "entity": ent, "home_table": home, "how": how, "tables": ts}
        # 3. decide per table / column
        scripts = []
        for t in tables:
            tent = self.p.table_entity(t)
            kept, removed = [], []
            for c in self.p.schemas[t].columns:
                n = c.name
                if n == "*":
                    continue
                row = {"table_name": t, "clone_table": t + self.suffix, "column_name": n, "table_entity": tent}
                if n in self.tech or n.endswith("_key"):
                    kept.append(n); row.update(action="kept", reason="technical column"); self.report.append(row); continue
                if n in self.keys or n in catalog_keys.get(t, ()):
                    kept.append(n); row.update(action="kept", reason="joining key"); self.report.append(row); continue
                h = self.homes.get(n)
                if h is None:
                    kept.append(n); row.update(action="kept", reason="only this table carries it"); self.report.append(row); continue
                home, ent = h["home_table"], h["entity"]
                row.update(owner_table=home, owner_entity=ent)
                if home == t:
                    kept.append(n); row.update(action="kept", reason=f"home of the attribute ({h['how']}); also in {', '.join(x for x in h['tables'] if x != t)}")
                    self.report.append(row); continue
                if n in never:
                    kept.append(n); row.update(action="kept", reason=f"duplicate of {home}.{n} but listed in dedupe.never_remove"); self.report.append(row); continue
                jk = self._link(t, home, ent, catalog_keys)
                if not jk:
                    kept.append(n); row.update(action="kept", reason=f"duplicate of {home}.{n} but no joining key to {home} in this table - review"); self.report.append(row); continue
                s1, s2 = self._src_col(self._source(t, n)), self._src_col(self._source(home, n))
                if s1 and s2 and s1 != s2 and s1 != n and s2 != n:
                    kept.append(n); row.update(action="kept", reason=f"same name as {home}.{n} but different source column ({s1} vs {s2}) - review"); self.report.append(row); continue
                removed.append(n)
                row.update(action="removed", joining_key=jk, reason=f"duplicate of {home}.{n}; re-join on {jk}")
                self.report.append(row)
            self.summary.append({"table_name": t, "clone_table": t + self.suffix, "entity": tent,
                                 "columns_original": len(kept) + len(removed), "columns_kept": len(kept),
                                 "columns_removed": len(removed), "removed_columns": ", ".join(removed)})
            self.scripts[t] = self._script(t, kept, removed)
            scripts.append(self.scripts[t])
        kept_copies = {}
        for r in self.report:
            h = self.homes.get(r["column_name"])
            if h and r["action"] == "kept" and r["table_name"] != h["home_table"]:
                kept_copies.setdefault(r["column_name"], []).append(r["table_name"])
        log.info("clone script: %d tables, %d attributes carried by more than one table, %d column copies removed, %d copies kept for review",
                 len(scripts), len(self.homes), sum(s["columns_removed"] for s in self.summary), sum(len(v) for v in kept_copies.values()))
        for n, ts in list(kept_copies.items())[:30]:
            log.info("  still duplicated (review): %s in %s", n, ", ".join(ts))
        return "\n\n".join(scripts)

    def _script(self, t: str, kept: List[str], removed: List[str]) -> str:
        """Clone the table as is (CREATE TABLE ... AS SELECT *), apply owner/grant, then drop the
        duplicated columns one by one with ALTER TABLE ... DROP COLUMN IF EXISTS."""
        src = f"{self.schema}.{t}"
        clone = f"{self.out_schema}.{t}{self.suffix}"
        owner, reader = self.cfg.greenplum.get("table_owner_role", ""), self.cfg.greenplum.get("table_reader_role", "")
        dist = [d for d in self.p.schemas[t].distribution_key if d in kept]
        dist_sql = f"\nDISTRIBUTED BY ({', '.join(dist)})" if dist else ""     # keep the original distribution
        lines = [f"-- {t}{self.suffix}: clone of {t}" +
                 (f" without {len(removed)} duplicated column(s): {', '.join(removed)}" if removed else " (no columns removed)"),
                 f"DROP TABLE IF EXISTS {clone};",
                 f"CREATE TABLE {clone} AS SELECT * FROM {src}{dist_sql};"]
        if owner:
            lines.append(f"ALTER TABLE {clone} OWNER TO {owner};")
        if reader:
            lines.append(f"GRANT SELECT ON {clone} TO {reader};")
        for c in removed:
            lines.append(f"ALTER TABLE {clone} DROP COLUMN IF EXISTS {c};")
        return "\n".join(lines)

    def report_frame(self) -> pd.DataFrame:
        cols = ["table_name", "clone_table", "column_name", "table_entity", "action", "owner_table", "owner_entity",
                "joining_key", "reason"]
        df = pd.DataFrame(self.report)
        for c in cols:
            if c not in df.columns:
                df[c] = ""
        return df[cols].fillna("")

    def summary_frame(self) -> pd.DataFrame:
        return pd.DataFrame(self.summary)

    def duplicates_frame(self) -> pd.DataFrame:
        """One row per attribute carried by several tables: its home and where it is removed / kept."""
        rows = []
        for n, h in sorted(getattr(self, "homes", {}).items()):
            rem = [r["table_name"] for r in self.report if r["column_name"] == n and r["action"] == "removed"]
            kept = [r["table_name"] for r in self.report if r["column_name"] == n and r["action"] == "kept" and r["table_name"] != h["home_table"]]
            rows.append({"column_name": n, "entity": h["entity"], "home_table": h["home_table"], "home_rule": h["how"],
                         "tables_carrying": len(h["tables"]), "removed_from": ", ".join(rem), "still_in_review": ", ".join(kept)})
        return pd.DataFrame(rows, columns=["column_name", "entity", "home_table", "home_rule", "tables_carrying", "removed_from", "still_in_review"])
