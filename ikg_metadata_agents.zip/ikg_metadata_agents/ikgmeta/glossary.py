"""
Abbreviation glossary for column-name tokens.

Resolution priority (highest first):
  1. SME overrides            config/glossary_overrides.yaml                 confidence 100
  2. EDW data dictionary      token aligned with Business Column Name words   confidence from support
       e.g.  brn_dimn_i  <->  "Branch Dimension Identifier"  =>  brn=Branch, dimn=Dimension, i=Identifier
  3. code evidence            SELECT aliases that spell a token out (mhh_x AS market_hh_x)
  4. LLM                      token + example columns + their SQL/lineage context
  5. otherwise                status NEEDS_INPUT  (sheet Glossary_Needs_Input)
"""
from __future__ import annotations

import itertools
import json
import logging
import re
from collections import Counter, defaultdict
from typing import Dict, Iterable, List, Optional, Tuple

import pandas as pd

log = logging.getLogger(__name__)

TIME_TOKEN = re.compile(r"^(\d+)(d|w|wk|wks|m|mo|q|y|yr|yrs)$")
TIME_WORD = {"d": "days", "w": "weeks", "wk": "weeks", "wks": "weeks", "m": "months", "mo": "months",
             "q": "quarters", "y": "years", "yr": "years", "yrs": "years"}
COMMON_WORDS = set("""
account accounts active activity address age all alert alerts allocation amount annual annuity any approval asset assets
attribute attributes average balance bank banking base benchmark beneficiary benefit best birth bond bonds bottom branch
brokerage business call capital card cards cash category change charge city class client clients close closed code
commodities company complete contract count country credit current customer daily data date day days deceased decile
delta deposit deposits description detail details discount distribution distributions dividend dividends due early
education eligible email employee employer end equity estate event events exception expense external fee fees first
fixed flag flags foreign fund funds gain gains gender goal goals group growth headline high highest history holding holdings
home household id identifier impact income index industry insight insights insurance intent interest internal
investment investments investor issue joint key last latest lead lending level life limit line list listing listings loan loans
long loss losses low lowest maintenance management manager margin market marketing match maturity max member members
min model money month monthly months mortgage name names net new news next number offset open opportunity order other
owner owners parent party payment payments pending percent percentage performance period phone plan planning policy
portfolio position positive negative premium previous price primary principal prior product products profile property
prospect prospects purchase purpose quarter rank rate rates ratio reason recent record refi region relationship
retirement return returns revenue review risk rule rules sale sales savings score scores sector security segment
sequence share shares short signal size source spending start state status story street summary survey symbol target
tax taxable team term text tier time title top total trade trades transfer transfers trust type unit units update
updated url user value values version volume week weekly weeks wire wires withdrawal withdrawals year yearly years yield
zip flag is has transaction transactions advisor financial
""".split())
SHORT_WORDS = {"is", "in", "to", "of", "at", "by", "on", "or", "and", "has", "no", "yes", "per", "as"}
STOP = {"of", "the", "a", "an", "to", "for", "in", "on", "and", "or", "by", "with", "at", "per", "is"}


def tokenize(column: str) -> List[str]:
    return [t for t in re.split(r"[_\W]+", (column or "").lower()) if t]


def is_abbrev_of(token: str, words: List[str]) -> bool:
    """token can be split into len(words) non-empty parts, each starting with the word's first
    letter and being a subsequence of that word (brn~branch, dimn~dimension, fa~financial advisor)."""
    if not words or len(token) < len(words):
        return False

    def subseq(a: str, b: str) -> bool:
        it = iter(b)
        return all(ch in it for ch in a)

    def loose(p: str, w: str) -> bool:
        # common IT abbreviations are not strict subsequences: txn~transaction, xfer~transfer
        return subseq(p, w) or (len(p) <= 4 and p[0] == w[0] and sum(ch in w for ch in p[1:]) >= len(p) - 2)

    n = len(words)
    for cuts in itertools.combinations(range(1, len(token)), n - 1):
        parts = [token[i:j] for i, j in zip((0,) + cuts, cuts + (len(token),))]
        if n == 1 and len(words[0]) < len(token):
            return False                      # an expansion is never shorter than the token
        if all(p[0] == w[0] and (subseq(p, w) if n > 1 else loose(p, w)) for p, w in zip(parts, words)):
            return True
    return False


def align(tokens: List[str], words: List[str]) -> Optional[List[Tuple[str, str]]]:
    """Align column tokens to business-name words; each token covers 1..3 consecutive words."""
    words = [w for w in words if w]
    memo: Dict[Tuple[int, int], Optional[list]] = {}

    def go(i: int, j: int):
        if (i, j) in memo:
            return memo[(i, j)]
        if i == len(tokens):
            res = [] if j == len(words) else None
            memo[(i, j)] = res
            return res
        res = None
        for k in (1, 2, 3):
            if j + k > len(words):
                break
            span = words[j:j + k]
            if is_abbrev_of(tokens[i], [w for w in span if w not in STOP] or span):
                rest = go(i + 1, j + k)
                if rest is not None:
                    res = [(tokens[i], " ".join(span))] + rest
                    break
        memo[(i, j)] = res
        return res

    res = go(0, 0)
    if res is None and len(words) > len(tokens):
        memo.clear()
        words = words[1:]                 # business names sometimes carry an extra leading word
        res = go(0, 0)
    return res


def edw_token_evidence(edw: pd.DataFrame) -> Dict[str, Counter]:
    ev: Dict[str, Counter] = defaultdict(Counter)
    for col, bname in edw[["column_name", "business_column_name"]].itertuples(index=False):
        if not col or not bname:
            continue
        words = [w.lower() for w in re.findall(r"[A-Za-z0-9]+", bname)]
        toks = tokenize(col)
        if len(toks) == len(words):
            pairs = [(t, w) for t, w in zip(toks, words) if t[0] == w[0]]
            if len(pairs) == len(toks):
                for t, w in pairs:
                    ev[t][w] += 1
                continue
        al = align(toks, words)
        if al:
            for t, phrase in al:
                ev[t][phrase] += 1
    return ev


def alias_token_evidence(pairs: Iterable[Tuple[str, str]]) -> Dict[str, Counter]:
    """(column_name, select_alias) pairs from the code: mhh_assets <- market_hh_assets."""
    ev: Dict[str, Counter] = defaultdict(Counter)
    for col, alias in pairs:
        if not alias or alias == col:
            continue
        al = align(tokenize(col), tokenize(alias))
        if al:
            for t, phrase in al:
                if t != phrase.replace(" ", ""):
                    ev[t][phrase] += 1
    return ev


def _merge_spellings(cnt: Counter) -> Counter:
    """merge near-identical phrases (typos such as 'transacation'), keeping the dictionary spelling."""
    import difflib
    groups: List[List[str]] = []
    for ph in sorted(cnt, key=lambda p: -cnt[p]):
        for g in groups:
            if difflib.SequenceMatcher(None, ph, g[0]).ratio() >= 0.88:
                g.append(ph)
                break
        else:
            groups.append([ph])
    out = Counter()
    for g in groups:
        rep = next((p for p in g if all(w in COMMON_WORDS for w in p.split())), g[0])
        out[rep] = sum(cnt[p] for p in g)
    return out


class Glossary:
    def __init__(self, overrides: dict, edw: pd.DataFrame, code_pairs: Iterable[Tuple[str, str]] = (),
                 extra_text: str = ""):
        self.overrides = {str(k).lower(): str(v) for k, v in ((overrides or {}).get("abbreviations") or {}).items()}
        self.code_values = (overrides or {}).get("code_values") or {}
        self.edw_ev = edw_token_evidence(edw) if len(edw) else {}
        self.alias_ev = alias_token_evidence(code_pairs)
        self.entries: Dict[str, dict] = {}
        # vocabulary of real words: EDW business names/definitions + catalogue text + built-in business words
        txt = " ".join(edw.get("business_column_name", pd.Series(dtype=str)).tolist()
                       + edw.get("column_definition", pd.Series(dtype=str)).tolist()) + " " + (extra_text or "")
        self.vocab = {w for w in re.findall(r"[a-z]{3,}", txt.lower())} | COMMON_WORDS

    # ---------------------------------------------------------------- build
    def build(self, column_usage: Dict[str, List[str]]) -> pd.DataFrame:
        """column_usage: token -> list of 'table.column' where it appears."""
        for tok, uses in column_usage.items():
            e = {"abbreviation": tok, "occurrences": len(uses), "example_columns": ", ".join(uses[:6]),
                 "full_form": "", "is_abbreviation": True, "source": "", "confidence": 0,
                 "evidence": "", "status": "NEEDS_INPUT"}
            m = TIME_TOKEN.match(tok)
            if tok in self.overrides:
                e.update(full_form=self.overrides[tok], source="SME override", confidence=100, status="RESOLVED")
            elif m:
                e.update(full_form=f"{m.group(1)} {TIME_WORD[m.group(2)][:-1] if m.group(1) == '1' else TIME_WORD[m.group(2)]}", source="rule (time window)",
                         confidence=95, status="RESOLVED")
            elif tok.isdigit():
                e.update(full_form=tok, is_abbreviation=False, source="number", confidence=100, status="RESOLVED")
            elif tok in SHORT_WORDS or (tok in self.vocab and len(tok) >= 3 and not self.edw_ev.get(tok)):
                e.update(full_form=tok, is_abbreviation=False, source="plain word", confidence=95, status="RESOLVED")
            else:
                self._from_counter(e, self.edw_ev.get(tok), "EDW data dictionary")
                if e["status"] != "RESOLVED":
                    self._from_counter(e, self.alias_ev.get(tok), "code alias", base=70)
            self.entries[tok] = e
        return self.frame()

    @staticmethod
    def _from_counter(e: dict, cnt: Optional[Counter], source: str, base: int = 75) -> None:
        if not cnt:
            return
        cnt = _merge_spellings(cnt)
        phrase, n = cnt.most_common(1)[0]
        total = sum(cnt.values())
        share = n / total
        conf = min(98, int(base + 10 * min(n, 3) * share - (0 if share > .8 else 15)))
        alts = "; ".join(f"{p} ({c})" for p, c in cnt.most_common(4))
        plain = phrase.replace(" ", "") == e["abbreviation"]
        e.update(full_form=phrase.title() if not plain else phrase, is_abbreviation=not plain, source=source,
                 confidence=conf, evidence=f"{source}: {alts}",
                 status="RESOLVED" if (conf >= 70 and share >= .6) else "AMBIGUOUS")

    def unresolved(self) -> List[str]:
        return [t for t, e in self.entries.items() if e["status"] != "RESOLVED" and e.get("is_abbreviation", True)]

    # ---------------------------------------------------------------- LLM
    def resolve_with_llm(self, llm, prompt: str, context_for: Dict[str, str], business_defs: str,
                         batch: int = 40) -> None:
        todo = self.unresolved()
        log.info("Glossary: %d tokens resolved without LLM, %d sent to LLM", len(self.entries) - len(todo), len(todo))
        for i in range(0, len(todo), batch):
            chunk = todo[i:i + batch]
            items = [{"token": t, "current_guess": self.entries[t]["full_form"],
                      "evidence": self.entries[t]["evidence"], "used_in": context_for.get(t, "")} for t in chunk]
            payload = json.dumps({"business_definitions": business_defs[:4000],
                                  "known_abbreviations": self.known_sample(150), "tokens": items},
                                 ensure_ascii=False)
            data = llm.json_call(prompt, payload, cache_key=("glossary", payload))
            for r in data.get("tokens", []):
                t = str(r.get("token", "")).lower()
                if t not in self.entries:
                    continue
                e = self.entries[t]
                conf = int(r.get("confidence", 0) or 0)
                ff = (r.get("full_form") or "").strip()
                is_abbr = bool(r.get("is_abbreviation", True))
                if not ff or ff.upper() == "UNKNOWN":
                    e.update(status="NEEDS_INPUT", source=e["source"] or "LLM",
                             evidence=(e["evidence"] + " | LLM: " + r.get("reason", "")).strip(" |"))
                    continue
                e.update(full_form=ff, is_abbreviation=is_abbr, confidence=conf,
                         source=("LLM" if not e["source"] else e["source"] + " + LLM"),
                         evidence=(e["evidence"] + " | LLM: " + r.get("reason", "")).strip(" |"),
                         status="RESOLVED" if conf >= 75 else "NEEDS_INPUT")

    def known_sample(self, n: int) -> Dict[str, str]:
        res = {t: e["full_form"] for t, e in self.entries.items()
               if e["status"] == "RESOLVED" and e["is_abbreviation"]}
        return dict(sorted(res.items(), key=lambda kv: -self.entries[kv[0]]["occurrences"])[:n])

    # ---------------------------------------------------------------- use
    def expand(self, column: str) -> Tuple[str, List[str]]:
        """'mhh_cash_dist_4w' -> ('mhh=Market Household; dist=Distribution; 4w=4 weeks', [unresolved])"""
        parts, unresolved = [], []
        for t in tokenize(column):
            e = self.entries.get(t)
            if not e:
                continue
            if e["status"] == "RESOLVED":
                if e["is_abbreviation"] and e["full_form"].lower() != t:
                    parts.append(f"{t}={e['full_form']}")
            else:
                unresolved.append(t)
                if e["full_form"]:
                    parts.append(f"{t}=?{e['full_form']} (unconfirmed)")
        return "; ".join(parts), unresolved

    def frame(self) -> pd.DataFrame:
        cols = ["abbreviation", "full_form", "is_abbreviation", "status", "confidence", "source", "occurrences",
                "example_columns", "evidence"]
        df = pd.DataFrame(list(self.entries.values()))
        if df.empty:
            return pd.DataFrame(columns=cols)
        return df[cols].sort_values(["status", "occurrences"], ascending=[True, False])

    def for_prompt(self) -> str:
        """compact glossary text for the system prompt (stable ordering -> prompt cache friendly)."""
        rows = sorted((t, e) for t, e in self.entries.items() if e["is_abbreviation"])
        lines = []
        for t, e in rows:
            if e["status"] == "RESOLVED":
                lines.append(f"{t}: {e['full_form']}")
            elif e["full_form"]:
                lines.append(f"{t}: ?{e['full_form']} (UNCONFIRMED)")
            else:
                lines.append(f"{t}: UNKNOWN")
        cv = "\n".join(f"{c}: {json.dumps(v)}" for c, v in sorted(self.code_values.items()))
        return "\n".join(lines) + ("\n\nCODE VALUES:\n" + cv if cv else "")
