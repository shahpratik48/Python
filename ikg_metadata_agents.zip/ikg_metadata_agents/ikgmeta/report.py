"""Excel workbook output (formatted)."""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import pandas as pd
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

MAIN_COLS = [
    ("table_name", 34), ("column_name", 30), ("ordinal", 7), ("entity", 14), ("functional_name", 36),
    ("business_description", 70), ("attribute_type", 13), ("derivation_type", 13), ("unit", 9), ("data_type", 16),
    ("confidence_score", 10), ("confidence_band", 10), ("needs_review", 9), ("difficult_to_generate", 10),
    ("what_is_required", 60), ("confidence_reason", 50), ("verify_verdict", 12), ("verify_issues", 40),
    ("evidence_used", 30), ("unresolved_tokens", 16), ("abbreviations", 40), ("llm_confidence", 9), ("evidence_score", 9),
    ("sql_expression", 50), ("select_alias", 20), ("terminal_sources", 45), ("source_definitions", 60),
    ("lineage_db", 70), ("lineage_code", 70), ("filters", 50), ("lineage_found", 9), ("lineage_reached_source", 9),
    ("edw_match", 11), ("in_database", 8), ("in_code", 8), ("table_entity", 14), ("source_file", 30), ("web_url", 40),
]
HDR_FILL = PatternFill("solid", fgColor="1F3864")
HDR_FONT = Font(color="FFFFFF", bold=True)
BAND_FILL = {"High": "C6EFCE", "Medium": "FFEB9C", "Low": "FFC7CE"}


def _sheet(xw, name: str, df: pd.DataFrame, widths: Optional[dict] = None, band_col: Optional[str] = None):
    df = df.copy()
    for c in df.columns:
        if df[c].dtype == object:
            df[c] = df[c].map(lambda v: v[:32000] if isinstance(v, str) else v)
    df.to_excel(xw, sheet_name=name, index=False)
    ws = xw.sheets[name]
    ws.freeze_panes = "C2" if name in ("Metadata", "Attribute_Metadata", "Needs_Review") else "B2"
    ws.auto_filter.ref = ws.dimensions
    for j, col in enumerate(df.columns, 1):
        cell = ws.cell(row=1, column=j)
        cell.fill, cell.font = HDR_FILL, HDR_FONT
        cell.alignment = Alignment(wrap_text=True, vertical="center")
        w = (widths or {}).get(col) or min(60, max(10, int(df[col].astype(str).str.len().quantile(.9)) if len(df) else 12))
        ws.column_dimensions[get_column_letter(j)].width = w
    wrap = Alignment(wrap_text=True, vertical="top")
    for row in ws.iter_rows(min_row=2, max_row=min(ws.max_row, 20000)):
        for cell in row:
            cell.alignment = wrap
    if band_col and band_col in df.columns and len(df):
        letter = get_column_letter(list(df.columns).index(band_col) + 1)
        rng = f"A2:{get_column_letter(len(df.columns))}{len(df) + 1}"
        for band, color in BAND_FILL.items():
            ws.conditional_formatting.add(
                f"{letter}2:{letter}{len(df) + 1}",
                FormulaRule(formula=[f'${letter}2="{band}"'], fill=PatternFill("solid", fgColor=color)))
        _ = rng


METADATA_COLS = ["profile_table", "column_name", "id", "functional_name", "business_description", "confidence_score",
                 "confidence_band", "entity", "attribute_type", "unit", "derivation_type", "data_type",
                 "confidence_reason", "difficult_to_generate", "what_is_required", "evidence_used", "verify_verdict"]


def metadata_sheet(results: pd.DataFrame) -> pd.DataFrame:
    r = results.sort_values(["table_name", "ordinal"]).copy()
    r["profile_table"] = r["table_name"]
    r["id"] = r["table_name"] + "." + r["column_name"]
    for c in METADATA_COLS:
        if c not in r.columns:
            r[c] = ""
    return r[METADATA_COLS]


def write_workbook(path: Path, results: pd.DataFrame, glossary: pd.DataFrame, tables: pd.DataFrame,
                   relationships: Optional[pd.DataFrame], run_info: dict, extra: Optional[dict] = None) -> None:
    widths = dict(MAIN_COLS)
    widths.update({"profile_table": 34, "id": 44})
    cols = [c for c, _ in MAIN_COLS if c in results.columns]
    res = results[cols].sort_values(["table_name", "ordinal"])
    review = res[res["needs_review"] == True].sort_values(["confidence_score", "table_name"])  # noqa: E712
    abbr = glossary[glossary["is_abbreviation"] == True]  # noqa: E712
    need = abbr[abbr["status"] != "RESOLVED"]
    legend = pd.DataFrame([
        ("High", ">= 80", "Fully supported by code + lineage + source definition; publish after spot check"),
        ("Medium", "60 - 79", "Derivation clear but some business meaning inferred; SME review recommended"),
        ("Low", "< 60", "Missing input - see what_is_required; supply it and re-run"),
    ], columns=["band", "score", "meaning"])
    with pd.ExcelWriter(path, engine="openpyxl") as xw:
        info = pd.DataFrame(list(run_info.items()), columns=["item", "value"])
        summary = pd.DataFrame([
            ("attributes", len(res)), ("High", int((res.confidence_band == "High").sum())),
            ("Medium", int((res.confidence_band == "Medium").sum())), ("Low", int((res.confidence_band == "Low").sum())),
            ("needs_review", int(res.needs_review.sum())), ("difficult_to_generate", int(res.difficult_to_generate.sum())),
            ("abbreviations", len(abbr)), ("abbreviations needing input", len(need))], columns=["item", "value"])
        _sheet(xw, "Run_Info", pd.concat([info, pd.DataFrame([("", "")], columns=["item", "value"]), summary,
                                          pd.DataFrame([("", "")], columns=["item", "value"])]),
               {"item": 28, "value": 120})
        start = len(info) + len(summary) + 4
        legend.to_excel(xw, sheet_name="Run_Info", startrow=start, index=False)
        _sheet(xw, "Metadata", metadata_sheet(results), widths, "confidence_band")
        _sheet(xw, "Attribute_Metadata", res, widths, "confidence_band")
        _sheet(xw, "Needs_Review", review, widths, "confidence_band")
        _sheet(xw, "Glossary", abbr.sort_values("abbreviation"),
               {"abbreviation": 14, "full_form": 34, "evidence": 80, "example_columns": 60})
        _sheet(xw, "Glossary_Needs_Input", need.assign(sme_full_form="").sort_values("occurrences", ascending=False),
               {"abbreviation": 14, "full_form": 30, "evidence": 70, "example_columns": 70, "sme_full_form": 30})
        _sheet(xw, "Table_Summary", tables, {"table_purpose (LLM)": 60, "key_business_rules (LLM)": 70,
                                             "catalogue_description": 50, "caveats (LLM)": 50})
        if relationships is not None and len(relationships):
            _sheet(xw, "Entity_Relationships", relationships, {"evidence": 90})
        plain = glossary[glossary["is_abbreviation"] == False]  # noqa: E712
        if len(plain):
            _sheet(xw, "Plain_Word_Tokens", plain[["abbreviation", "full_form", "source", "occurrences"]])
        for name, df in (extra or {}).items():
            if df is not None and len(df):
                _sheet(xw, name, df, {"quote": 60, "item": 70, "key_business_rules": 80, "detail": 80,
                                      "table_purpose": 60, "value_profile": 80})
