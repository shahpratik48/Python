"""
ODM and NLG tables ("domains") next to the IKG profile tables.

  odm   core_ikg.si_odm_insights_active, core_ikg.odm_exclusion_insight_type  (config domains.odm.tables)
        columns      information_schema (authoritative) or the CREATE TABLE in odm_table_creation.sql
        code         every rule script that INSERTs into the table (jinja {{params.ODM_TABLE}} resolved)
  nlg   every table named in nlg_db_tables.ini, section [prod_active] (ENV=PROD) or [dev_active] (ENV=DEV)
        schema       resolved from the code (which schema_* key the table key is used with), the key prefix and
                     information_schema (where the table actually exists)
        code         Python / YAML / SQL that reads or writes the table (NLG writes tables from Python)

For every table the loader produces the same things the IKG profile tables have, so that the agents, the scoring,
the workbook and the Greenplum load work unchanged:
    TableSchema (columns with data types), an evidence "script" (DDL + code excerpts), a catalogue row,
    per-column code mentions, upstream candidates (same column name in core_ikg / core_nlg / core_wma_shared)
    and the published definition of the same column name in the metadata table (upstream hopping).
"""
from __future__ import annotations

import configparser
import logging
import re
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

import pandas as pd

from . import sources as src
from .sql_parser import ColumnInfo, TableSchema

log = logging.getLogger(__name__)

_IDENT = re.compile(r"^[a-z_][a-z0-9_]*$")
_WORD = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
CODE_EXT = (".py", ".yml", ".yaml", ".json", ".sql", ".ini", ".txt", ".cfg")
ROLE_BY_PREFIX = [
    ("odm_insights_tbl", "ODM insight hits read by NLG (rule results)"),
    ("input_tbl_", "input: IKG profile table read by the NLG rules of this target type"),
    ("ref_tbl_", "reference / mapping table used by the NLG rules and products"),
    ("ref_ikg_odm", "run-status / polling table shared by IKG, ODM and NLG"),
    ("output_tbl_", "output table written by NLG (narratives, product HTML, e-mail status)"),
    ("nlg_run", "NLG run history / error log"),
    ("nlg_", "NLG operational table"),
    ("fa_insight_preference", "FA insight preference table (portal API)"),
    ("minor_cli", "exclusion list (minor clients) used by NLG"),
]
PRODUCT_HINT = [
    ("narratives", "raw narratives (rule output of the NLG rules stage)"),
    ("fa_html", "client briefing (FA_MEETING_MAIL)"), ("cb_buffer", "client briefing (FA_MEETING_MAIL)"),
    ("cb_summary", "client briefing summary"), ("retention_pack", "FA retention pack"),
    ("unnest_html", "client briefing"), ("fa_alert", "FA alerts (FA_ALERT)"),
    ("fa_subscriptions", "FA subscriptions"), ("banker_alerts", "banker alerts"),
    ("no_email_interaction", "no-e-mail-interaction alerts"), ("fl_talent_report", "FL talent report"),
    ("market_alert", "market event alerts"), ("market_banking", "market event alerts (banking)"),
    ("prospect", "prospect alerts (FA_PROSPECT_MAIL)"), ("pp_alert", "prospect alerts"),
    ("insights_in_json", "JSON insights (FA portal / panels)"), ("insight_layout", "insight layout (products, groups, ranks)"),
    ("insight_group_and_rank", "insight layout (products, groups, ranks)"), ("household_id_encryption", "household id encryption map"),
    ("weekly_emails", "weekly e-mail sending status"), ("calendar", "FA calendar / client meeting map"),
]


@dataclass
class DomainTable:
    name: str
    schema: str
    domain: str
    key: str = ""                      # ini key (nlg) or "" (odm)
    role: str = ""
    columns: List[ColumnInfo] = field(default_factory=list)
    ddl_file: str = ""
    ddl_text: str = ""
    writer_files: List[str] = field(default_factory=list)
    reader_files: List[str] = field(default_factory=list)
    evidence_text: str = ""
    notes: List[str] = field(default_factory=list)
    column_source: str = "information_schema"

    def catalogue_row(self, entity: str, section: str = "") -> dict:
        d = f"{self.domain.upper()} table {self.schema}.{self.name}: {self.role}."
        if self.key:
            d += f" Configured in nlg_db_tables.ini [{section}] as {self.key} = {self.name}."
        hint = next((h for k, h in PRODUCT_HINT if k in self.name or k in self.key), "")
        if hint:
            d += f" Used for: {hint}."
        return {"table_name": self.name, "topic_area": self.domain.upper(), "description": d, "entity_type": entity,
                "grain": "", "primary_key": "", "join_keys": "", "important_columns": "",
                "additional_notes": "; ".join(self.notes)[:1500]}


class CodeMentions:
    """Which repository files mention which identifiers (tables, ini keys, columns). Built once per repository."""

    def __init__(self, root: Path, exts=CODE_EXT, max_file_chars: int = 2_000_000):
        self.root = Path(root)
        self.files: Dict[str, Set[str]] = {}        # rel path -> identifiers
        self.by_ident: Dict[str, List[str]] = defaultdict(list)
        for f in sorted(self.root.rglob("*")):
            if not f.is_file() or f.suffix.lower() not in exts:
                continue
            try:
                txt = f.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            if len(txt) > max_file_chars:
                continue
            rel = str(f.relative_to(self.root)).replace("\\", "/")
            idents = {w.lower() for w in _WORD.findall(txt)}
            self.files[rel] = idents
            for w in idents:
                self.by_ident[w].append(rel)
        log.info("code mentions indexed: %d files under %s", len(self.files), self.root)

    @staticmethod
    def _rank(rel: str) -> int:
        """production code first: utils / main modules, then DAGs and config, tests and analysis last"""
        r = rel.lower()
        if "/tests/" in r or r.startswith("tests/") or "/test_" in r or "regression" in r or "/analysis/" in r:
            return 4
        if "dummy" in r or "anonym" in r:
            return 3
        if r.endswith((".yml", ".yaml", ".json", ".ini")):
            return 2
        if "/utils/" in r or "/src/nlg_" in r or r.endswith("_class.py") or "/script/" in r or "/scripts/" in r:
            return 0
        return 1

    def files_for(self, ident: str, limit: int = 50) -> List[str]:
        return sorted(self.by_ident.get(ident.lower(), []), key=lambda r: (self._rank(r), r))[:limit]

    def lines(self, ident: str, max_files: int = 4, max_lines: int = 3, width: int = 220) -> List[str]:
        """'file:line: text' examples of an identifier (whole word)."""
        out = []
        rx = re.compile(rf"(?<![A-Za-z0-9_]){re.escape(ident)}(?![A-Za-z0-9_])", re.I)
        for rel in self.files_for(ident, max_files * 3):
            if len(out) >= max_files * max_lines:
                break
            try:
                txt = (self.root / rel).read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            n = 0
            for i, line in enumerate(txt.splitlines(), 1):
                if rx.search(line):
                    out.append(f"{rel}:{i}: {line.strip()[:width]}")
                    n += 1
                    if n >= max_lines:
                        break
        return out

    def excerpt(self, rel: str, ident: str, around: int = 14, max_chars: int = 2500) -> str:
        try:
            txt = (self.root / rel).read_text(encoding="utf-8", errors="replace")
        except OSError:
            return ""
        lines = txt.splitlines()
        rx = re.compile(rf"(?<![A-Za-z0-9_]){re.escape(ident)}(?![A-Za-z0-9_])", re.I)
        hit = next((i for i, l in enumerate(lines) if rx.search(l)), None)
        if hit is None:
            return ""
        a, b = max(0, hit - around), min(len(lines), hit + around + 1)
        body = "\n".join(f"{i + 1:5d}| {lines[i]}" for i in range(a, b))
        return body[:max_chars]


# =============================================================================
class DomainLoader:
    def __init__(self, cfg, gp, repos: Dict[str, src.GitLabCode], env: str, ikg_profile_tables: Optional[Set[str]] = None):
        self.cfg = cfg
        self.gp = gp
        self.repos = repos
        self.env = (env or "PROD").upper()
        self.ikg_profile_tables = {t.lower() for t in (ikg_profile_tables or set())}
        pat = str((cfg.get("generation") or {}).get("profile_table_pattern", "%profile_curr_ikg")).lower()
        self._profile_rx = re.compile("^" + re.escape(pat).replace("%", ".*") + "$")
        self.ikg_referenced: List[Tuple[str, str, str]] = []      # (ini key, table, schema) handled by the IKG metadata
        self.dcfg = cfg.get("domains") or {}
        self.tables: Dict[str, DomainTable] = {}
        self.mentions: Dict[str, CodeMentions] = {}
        self.nlg_settings: Dict[str, str] = {}
        self.nlg_section = ""
        self.ini_path: Optional[Path] = None

    # ------------------------------------------------------------------ public
    def discover(self) -> Dict[str, DomainTable]:
        if (self.dcfg.get("odm") or {}).get("enabled") and "odm" in self.repos:
            try:
                self._odm()
            except Exception as e:  # noqa: BLE001
                log.error("ODM table discovery failed: %s", e)
        if (self.dcfg.get("nlg") or {}).get("enabled") and "nlg" in self.repos:
            try:
                self._nlg()
            except Exception as e:  # noqa: BLE001
                log.error("NLG table discovery failed: %s", e)
        self._columns()
        for t in self.tables.values():
            t.evidence_text = self._evidence(t)
        log.info("Domain tables: %s", {d: sum(1 for t in self.tables.values() if t.domain == d) for d in ("odm", "nlg")})
        return self.tables

    def schemas_frame(self) -> Dict[str, TableSchema]:
        out = {}
        for t in self.tables.values():
            ts = TableSchema(table=t.name, source_file=t.ddl_file or f"{t.domain}:{t.schema}.{t.name}",
                             columns=t.columns, method=t.column_source)
            if not t.columns:
                ts.warnings.append("no columns found (table missing in information_schema and no DDL in the code)")
            out[t.name] = ts
        return out

    def col_types_frame(self) -> pd.DataFrame:
        rows = [{"table_name": t.name, "column_name": c.name, "data_type": c.data_type, "ordinal_position": str(c.ordinal)}
                for t in self.tables.values() for c in t.columns]
        return pd.DataFrame(rows, columns=["table_name", "column_name", "data_type", "ordinal_position"])

    def descriptions_frame(self) -> pd.DataFrame:
        rows = [t.catalogue_row((self.dcfg.get(t.domain) or {}).get("entity", t.domain.upper()), self.nlg_section)
                for t in self.tables.values()]
        return pd.DataFrame(rows, columns=src.DESC_COLS)

    # ------------------------------------------------------------------ ODM
    def _odm(self) -> None:
        c = self.dcfg["odm"]
        repo = self.repos["odm"]
        schema = (c.get("schema") or self.cfg.greenplum["schema"]).lower()
        root = repo.code_root()
        self.mentions["odm"] = CodeMentions(root)
        ddl = self._find_ddl(root, [t.lower() for t in c.get("tables", [])], c.get("table_params") or {})
        for t in c.get("tables", []):
            t = t.lower()
            dt = DomainTable(name=t, schema=schema, domain="odm",
                             role="ODM (Opportunity Data Model) rule-engine table" +
                                  (" - current run insight hits written by every client / prospect / FL / market-event rule script"
                                   if "insights" in t else " - rule types excluded from the active insights (SCD2, is_curr)"))
            if t in ddl:
                dt.ddl_file, dt.ddl_text = ddl[t]
            params = {v.lower(): k for k, v in (c.get("table_params") or {}).items()}
            idents = [t] + ([params[t]] if t in params else [])
            writers, readers = set(), set()
            for ident in idents:
                for rel in self.mentions["odm"].files_for(ident, 2000):
                    if rel.endswith(".sql"):
                        txt = (root / rel).read_text(encoding="utf-8", errors="replace").lower()
                        if re.search(rf"(insert\s+into|update|delete\s+from|truncate)\s+[^;]*{re.escape(ident.lower())}", txt):
                            writers.add(rel)
                        else:
                            readers.add(rel)
            dt.writer_files = sorted(writers)
            dt.reader_files = sorted(readers)
            dt.notes.append(f"{len(writers)} script(s) write the table, {len(readers)} read it")
            self.tables[t] = dt

    @staticmethod
    def _find_ddl(root: Path, tables: List[str], params: dict) -> Dict[str, Tuple[str, str]]:
        """CREATE TABLE statements of the wanted tables anywhere in the repository (jinja parameters resolved)."""
        out = {}
        inv = {k.upper(): v.lower() for k, v in params.items()}
        for f in sorted(root.rglob("*.sql")):
            txt = f.read_text(encoding="utf-8", errors="replace")
            plain = re.sub(r"\{\{\s*params\.([A-Za-z0-9_]+)\s*\}\}", lambda m: inv.get(m.group(1).upper(), m.group(1)), txt)
            for m in re.finditer(r"(?is)create\s+table\s+(?:if\s+not\s+exists\s+)?([a-z0-9_.]+)\s*\((.*?)\)\s*(?:distributed[^;]*)?;", plain):
                name = m.group(1).split(".")[-1].lower()
                if name in tables and name not in out:
                    rel = str(f.relative_to(root)).replace("\\", "/")
                    out[name] = (rel, m.group(0))
        return out

    # ------------------------------------------------------------------ NLG
    def _nlg(self) -> None:
        c = self.dcfg["nlg"]
        repo = self.repos["nlg"]
        root = repo.code_root()
        ini = next(iter(sorted(root.rglob(c.get("tables_ini", "nlg_db_tables.ini")))), None)
        if ini is None:
            raise FileNotFoundError(f"{c.get('tables_ini')} not found under {root}")
        self.ini_path = ini
        section = (c.get("ini_section") or {}).get(self.env) or ("prod_active" if self.env == "PROD" else "dev_active")
        cp = configparser.ConfigParser(interpolation=None)
        cp.optionxform = str
        cp.read(ini, encoding="utf-8")
        if section not in cp:
            raise KeyError(f"section [{section}] not in {ini} (sections: {cp.sections()})")
        settings = {k: v.strip() for k, v in cp[section].items()}
        settings.update((c.get("schema_overrides") or {}).get(self.env) or {})
        self.nlg_settings, self.nlg_section = settings, section
        schemas = {k: v.lower() for k, v in settings.items() if k.startswith("schema_")}
        log.info("NLG ini %s [%s]: %d keys, schemas %s", ini.name, section, len(settings), schemas)
        self.mentions["nlg"] = CodeMentions(root)
        key_schema = self._key_schema_from_code(root)
        exclude_keys = set(c.get("exclude_keys") or [])
        exclude_tables = {t.lower() for t in (c.get("exclude_tables") or [])}
        existing = src.tables_in_schemas(self.gp, sorted(set(schemas.values())))
        exists = defaultdict(set)
        for s, t in existing.itertuples(index=False):
            exists[t].add(s)
        order = [schemas[k] for k in (c.get("schema_search_order") or []) if k in schemas]
        for key, val in settings.items():
            if key.startswith("schema_") or key in exclude_keys or not _IDENT.match(val.lower()):
                continue
            name = val.lower()
            if name in exclude_tables or name in self.tables:
                continue
            if name in self.ikg_profile_tables or self._profile_rx.match(name):
                # IKG profile table read by NLG: documented by the IKG profile metadata, never as an NLG table
                self.ikg_referenced.append((key, name, schemas.get("schema_ikg", "")))
                continue
            # schema: code usage > key prefix rule > existence in information_schema
            cand = []
            if key in key_schema:
                cand += [schemas[s] for s, _ in key_schema[key].most_common() if s in schemas]
            if key.startswith("input_tbl_") or key.startswith("ref_ikg_odm"):
                cand.append(schemas.get("schema_ikg", ""))
            if key == "fa_insight_preference_tbl" and settings.get("fa_insight_preference_tbl_schema"):
                cand.append(settings["fa_insight_preference_tbl_schema"].lower())
            cand += [schemas.get("schema_nlg", "")] + order
            cand = [s for s in dict.fromkeys(cand) if s]
            schema = next((s for s in cand if s in exists.get(name, ())), "")
            if not schema:
                if len(existing):
                    log.info("NLG: %s = %s not found in %s - skipped", key, name, sorted(set(cand)))
                    continue
                schema = cand[0]                          # no DB (files mode): best guess
            role = next((r for p, r in ROLE_BY_PREFIX if key.startswith(p)), "NLG table")
            dt = DomainTable(name=name, schema=schema, domain="nlg", key=key, role=role)
            usage = self.mentions["nlg"].files_for(key, 2000) + self.mentions["nlg"].files_for(name, 2000)
            usage = sorted(set(usage))
            dt.reader_files = [u for u in usage if u.endswith((".py", ".sql", ".yml", ".yaml"))][:60]
            dt.notes.append(f"referenced in {len(usage)} file(s), e.g. {', '.join(usage[:6])}")
            src_sch = next((s for s, _ in key_schema[key].most_common(1)), "") if key in key_schema else ""
            if src_sch:
                dt.notes.append(f"code uses it with {src_sch} (= {schemas.get(src_sch, '?')})")
            self.tables[name] = dt
        log.info("NLG: %d tables from [%s]; %d IKG profile tables referenced by the ini are left to the IKG metadata",
                 sum(1 for t in self.tables.values() if t.domain == "nlg"), section, len(self.ikg_referenced))

    @staticmethod
    def _key_schema_from_code(root: Path):
        """ini key -> Counter(schema_* key) from f-strings like {settings['schema_nlg']}.{settings['output_tbl_x']}"""
        from collections import Counter
        pat = re.compile(r"\[\s*f?['\"](schema_[a-z_]+)['\"]\s*\]\s*\}\s*\.\s*\{\s*\w+(?:\.\w+)*\s*\[\s*f?['\"]([a-z_]+)['\"]\s*\]")
        out: Dict[str, Counter] = defaultdict(Counter)
        for f in root.rglob("*.py"):
            try:
                txt = f.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            for s, k in pat.findall(txt):
                out[k][s] += 1
        return out

    # ------------------------------------------------------------------ columns
    def _columns(self) -> None:
        pairs = [(t.schema, t.name) for t in self.tables.values()]
        ct = src.load_column_types_for(self.cfg, self.gp, pairs)
        by = defaultdict(list)
        for r in ct.itertuples(index=False):
            by[(r.table_schema, r.table_name)].append(r)
        for t in self.tables.values():
            rows = sorted(by.get((t.schema, t.name), []), key=lambda r: int(r.ordinal_position or 0))
            if rows:
                t.columns = [ColumnInfo(r.column_name, r.data_type, "", i) for i, r in enumerate(rows, 1)]
                t.column_source = "information_schema"
            elif t.ddl_text:
                t.columns = self._columns_from_ddl(t.ddl_text)
                t.column_source = "ddl"
            else:
                m = self.mentions.get(t.domain)
                ddl = self._find_ddl(m.root, [t.name], {}) if m else {}
                if t.name in ddl:
                    t.ddl_file, t.ddl_text = ddl[t.name]
                    t.columns = self._columns_from_ddl(t.ddl_text)
                    t.column_source = "ddl"

    @staticmethod
    def _columns_from_ddl(ddl: str) -> List[ColumnInfo]:
        body = ddl[ddl.index("(") + 1:]
        depth, buf, items = 0, [], []
        for ch in body:
            if ch == "(":
                depth += 1
            elif ch == ")":
                if depth == 0:
                    break
                depth -= 1
            if ch == "," and depth == 0:
                items.append("".join(buf))
                buf = []
            else:
                buf.append(ch)
        if "".join(buf).strip():
            items.append("".join(buf))
        cols = []
        for it in items:
            parts = it.strip().split()
            if len(parts) >= 2 and _IDENT.match(parts[0].lower()) and parts[0].lower() not in ("primary", "constraint", "unique"):
                cols.append(ColumnInfo(parts[0].lower(), " ".join(parts[1:]).rstrip(",").split(" default")[0], "", len(cols) + 1))
        return cols

    # ------------------------------------------------------------------ evidence script
    def _evidence(self, t: DomainTable) -> str:
        m = self.mentions.get(t.domain)
        parts = [f"-- {t.domain.upper()} TABLE {t.schema}.{t.name}",
                 f"-- role: {t.role}" + (f" | ini key: {t.key} [{self.nlg_section}]" if t.key else ""),
                 f"-- columns from: {t.column_source}"]
        if t.ddl_text:
            parts.append(f"-- ===== DDL ({t.ddl_file}) =====\n{t.ddl_text}")
        elif t.columns:
            parts.append("-- ===== COLUMNS (information_schema) =====\n" +
                         "\n".join(f"--   {c.name:40s} {c.data_type}" for c in t.columns))
        if t.domain == "odm" and m is not None:
            parts.append(f"-- ===== WRITERS: {len(t.writer_files)} script(s) insert / update this table =====\n"
                         + "\n".join(f"--   {w}" for w in t.writer_files[:40])
                         + ("\n--   ..." if len(t.writer_files) > 40 else ""))
            shown = 0
            for w in t.writer_files:
                if shown >= 4:
                    break
                txt = (m.root / w).read_text(encoding="utf-8", errors="replace")
                parts.append(f"-- ===== SCRIPT {w} =====\n{txt[:6000]}")
                shown += 1
        if t.domain == "nlg" and m is not None:
            idents = [t.key, t.name] if t.key else [t.name]
            shown, seen = 0, set()
            for ident in idents:
                for rel in m.files_for(ident, 200):
                    if rel in seen or shown >= 6 or not rel.endswith((".py", ".sql", ".yml", ".yaml")):
                        continue
                    ex = m.excerpt(rel, ident)
                    if ex:
                        parts.append(f"-- ===== CODE {rel} (mentions {ident}) =====\n{ex}")
                        seen.add(rel)
                        shown += 1
        return "\n\n".join(parts)

    # ------------------------------------------------------------------ per column evidence
    def column_mentions(self, t: DomainTable, column: str) -> str:
        m = self.mentions.get(t.domain)
        if m is None:
            return ""
        return "\n".join(m.lines(column, max_files=4, max_lines=2))[:1800]

    def writer_expressions(self, t: DomainTable, column: str, resolver, limit: int = 6) -> Tuple[str, str, List[str]]:
        """ODM: the same column is written by many rule scripts -> distinct expressions + resolved sources."""
        if resolver is None:
            return "", "", []
        ws = resolver.writers.get(t.name, [])
        exprs, chains, sources = [], [], []
        seen = set()
        for w in ws:
            try:
                e = resolver._projection_for(w.select, column, w.ddl_cols)
            except Exception:  # noqa: BLE001
                e = None
            if e is None:
                continue
            txt = e.sql(dialect="postgres")
            if txt in seen:
                continue
            seen.add(txt)
            rel = Path(w.file).name
            exprs.append(f"{txt}  [{rel}]")
            if len(exprs) >= limit:
                break
        for w in ws[:3]:
            try:
                chain, srcs, _ = resolver.resolve(t.name, column)
            except Exception:  # noqa: BLE001
                continue
            chains += [s.as_text() for s in chain[1:3]]
            sources += srcs
            break
        return " | ".join(exprs), "\n".join(chains), list(dict.fromkeys(sources))
