"""
Extract the authoritative column list (name, data type, SQL expression) for each
profile table from its create script.

Strategy per file:
  1. Jinja placeholders ({{params.X}}) are masked so sqlglot can parse Greenplum SQL.
  2. If the file has an explicit DDL  CREATE TABLE <profile> (col type, ...)  that is
     used for column order + data type, and the INSERT INTO <profile> SELECT ...
     projection supplies the expression of each column (positional match).
  3. Otherwise the CTAS  CREATE TABLE <profile> AS SELECT ...  projection is used.
     SELECT * from a temp table / CTE defined in the same file is expanded.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

import sqlglot
from sqlglot import exp

_JINJA = re.compile(r"\{\{\s*params\.([A-Za-z0-9_]+)\s*\}\}")


@dataclass
class ColumnInfo:
    name: str
    data_type: str = ""
    expression: str = ""
    ordinal: int = 0
    select_alias: str = ""   # alias used in the SELECT when it differs from the DDL name


@dataclass
class TableSchema:
    table: str
    source_file: str
    columns: List[ColumnInfo] = field(default_factory=list)
    method: str = ""
    distribution_key: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


_GP_DIST = re.compile(r"\bDISTRIBUTED\s+(?:BY\s*\(([^)]*)\)|RANDOMLY|REPLICATED)", re.I)
_GP_WITH = re.compile(r"\bWITH\s*\(\s*appendonly[^)]*\)", re.I)
_LINE_COMMENT = re.compile(r"--[^\n]*")


def _split_statements(sql: str) -> List[str]:
    """Split on semicolons that are outside quotes/comments."""
    out, buf, i, n = [], [], 0, len(sql)
    quote = None
    while i < n:
        ch = sql[i]
        if quote:
            buf.append(ch)
            if ch == quote:
                quote = None
        elif ch in ("'", '"'):
            quote = ch
            buf.append(ch)
        elif sql.startswith("--", i):
            j = sql.find("\n", i)
            i = n if j < 0 else j
            continue
        elif sql.startswith("/*", i):
            j = sql.find("*/", i + 2)
            i = n if j < 0 else j + 2
            continue
        elif ch == ";":
            out.append("".join(buf))
            buf = []
        else:
            buf.append(ch)
        i += 1
    out.append("".join(buf))
    return [s for s in out if s.strip()]


def _mask(sql: str) -> str:
    # schema placeholders -> plain identifier, value placeholders -> literal
    sql = re.sub(r"\{\{\s*params\.([A-Za-z0-9_]*SCHEMA[A-Za-z0-9_]*)\s*\}\}", r"\1", sql)
    sql = re.sub(r"'\{\{\s*params\.([A-Za-z0-9_]+)\s*\}\}'", r"'__\1__'", sql)
    sql = _JINJA.sub(lambda m: f"'__{m.group(1)}__'", sql)
    return sql


def _unmask(text: str) -> str:
    return re.sub(r"'__([A-Za-z0-9_]+)__'", r"{{params.\1}}", text)


def _parse(sql: str, dist_keys: Dict[str, List[str]]):
    """Parse statement by statement so one unsupported statement never hides the rest."""
    stmts = []
    for raw in _split_statements(sql):
        m_tbl = re.search(r"CREATE\s+(?:TEMP\w*\s+)?TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?([\w.]+)", raw, re.I)
        m_dist = _GP_DIST.search(raw)
        if m_tbl and m_dist and m_dist.group(1):
            dist_keys[m_tbl.group(1).split(".")[-1].lower()] = [k.strip().lower() for k in m_dist.group(1).split(",")]
        clean = _GP_WITH.sub("", _GP_DIST.sub("", raw))
        st = _try_parse(clean)
        if st is None and m_tbl:
            st = _fallback_ddl(clean, m_tbl)
        if st is None:
            # statements embedded in PL/pgSQL blocks:  DO $$ ... IF .. THEN INSERT INTO ...
            m = _EMBEDDED.search(clean)
            if m and m.start() > 0:
                st = _try_parse(clean[m.start():])
        if st is not None:
            stmts.append(st)
    return stmts


def _fallback_ddl(sql: str, m_tbl) -> Optional[exp.Expression]:
    """CREATE TABLE t (col type, ...) <greenplum partition / storage clauses>:
    keep only the column list and re-parse."""
    start = sql.find("(", m_tbl.end())
    if start < 0 or sql[m_tbl.end():start].strip().upper().startswith("AS"):
        return None
    depth, end = 0, -1
    for i in range(start, len(sql)):
        if sql[i] == "(":
            depth += 1
        elif sql[i] == ")":
            depth -= 1
            if depth == 0:
                end = i
                break
    if end < 0:
        return None
    return _try_parse(f"CREATE TABLE {m_tbl.group(1)} {sql[start:end + 1]}")


_EMBEDDED = re.compile(r"\b(INSERT\s+INTO|CREATE\s+(?:TEMP\w*\s+)?TABLE)\b", re.I)


def _try_parse(sql: str):
    try:
        st = sqlglot.parse_one(sql, read="postgres")
    except Exception:
        return None
    return None if st is None or isinstance(st, exp.Command) else st


def _arg(node: exp.Expression, name: str):
    """sqlglot >= 26 renamed some args (from -> from_, with -> with_); support both."""
    v = node.args.get(name + "_")
    return v if v is not None else node.args.get(name)


def _table_name(node) -> str:
    t = node.find(exp.Table) if not isinstance(node, exp.Table) else node
    return (t.name or "").lower() if t is not None else ""


def _final_select(q: exp.Expression) -> Optional[exp.Select]:
    """Return the outermost SELECT (first branch for UNIONs)."""
    while isinstance(q, (exp.Union, exp.Subquery)):
        q = q.this if isinstance(q, exp.Subquery) else q.left
    return q if isinstance(q, exp.Select) else None


def _projection(select: exp.Select, known: Dict[str, List[ColumnInfo]]) -> List[ColumnInfo]:
    out: List[ColumnInfo] = []
    ctes = {c.alias_or_name.lower(): c.this for c in (_arg(select, "with").expressions if _arg(select, "with") else [])}
    for e in select.expressions:
        if isinstance(e, exp.Star) or (isinstance(e, exp.Column) and isinstance(e.this, exp.Star)):
            # expand from FROM table if it's a known temp table / CTE
            src = _arg(select, "from")
            src_name = _table_name(src.this) if src else ""
            if src_name in known:
                out.extend(ColumnInfo(c.name, c.data_type, f"{src_name}.{c.name}", select_alias=c.name) for c in known[src_name])
            elif src_name in ctes and _final_select(ctes[src_name]) is not None:
                out.extend(_projection(_final_select(ctes[src_name]), known))
            else:
                out.append(ColumnInfo("*", "", f"* from {src_name}"))
            continue
        name = e.alias_or_name or f"_unnamed_{len(out) + 1}"   # keep position for positional INSERTs
        out.append(ColumnInfo(name.lower(), "", _unmask(e.sql(dialect="postgres")), select_alias=name.lower()))
    return out


def extract_table_schema(sql_path: Path) -> TableSchema:
    target = sql_path.stem.lower()
    raw = sql_path.read_text(encoding="utf-8", errors="replace")
    ts = TableSchema(table=target, source_file=str(sql_path))
    dist: Dict[str, List[str]] = {}
    stmts = _parse(_mask(raw), dist)
    ts.distribution_key = dist.get(target, [])

    known: Dict[str, List[ColumnInfo]] = {}   # temp tables created in the same file
    ddl: Optional[List[ColumnInfo]] = None
    insert_proj: Optional[List[ColumnInfo]] = None
    ctas_proj: Optional[List[ColumnInfo]] = None

    for st in stmts:
        if isinstance(st, exp.Create) and (st.args.get("kind") or "").upper() == "TABLE":
            name = _table_name(st.this)
            schema_node = st.this if isinstance(st.this, exp.Schema) else None
            if schema_node is not None and schema_node.expressions:
                cols = [ColumnInfo(cd.name.lower(), cd.args["kind"].sql(dialect="postgres") if cd.args.get("kind") else "")
                        for cd in schema_node.expressions if isinstance(cd, exp.ColumnDef)]
                if name == target:
                    ddl = cols
                known[name] = cols
            elif st.expression is not None:
                sel = _final_select(st.expression)
                if sel is not None:
                    proj = _projection(sel, known)
                    known[name] = proj
                    if name == target:
                        ctas_proj = proj
        elif isinstance(st, exp.Insert):
            name = _table_name(st.this)
            sel = _final_select(st.expression) if st.expression is not None else None
            if name == target and sel is not None:
                insert_proj = _projection(sel, known)
                ins_cols = [c.name.lower() for c in st.this.expressions] if isinstance(st.this, exp.Schema) else []
                if ins_cols and len(ins_cols) == len(insert_proj):
                    for c, p in zip(ins_cols, insert_proj):
                        p.name = c

    if ddl:
        ts.method = "ddl"
        if insert_proj and len(insert_proj) == len(ddl):
            for d, p in zip(ddl, insert_proj):
                d.expression = p.expression
                d.select_alias = p.select_alias if p.select_alias != d.name else ""
        elif insert_proj:
            by_name = {p.name: p.expression for p in insert_proj}
            for d in ddl:
                d.expression = by_name.get(d.name, "")
            ts.warnings.append(f"DDL has {len(ddl)} columns, INSERT projects {len(insert_proj)}; matched by name")
        ts.columns = ddl
    elif ctas_proj:
        ts.method = "ctas"
        ts.columns = ctas_proj
    else:
        ts.method = "unparsed"
        ts.warnings.append("No CREATE/INSERT for target table could be parsed")

    # de-duplicate + ordinal
    seen, cols = set(), []
    for c in ts.columns:
        if c.name in seen:
            continue
        seen.add(c.name)
        c.ordinal = len(cols) + 1
        cols.append(c)
    ts.columns = cols
    if any(c.name == "*" for c in cols):
        ts.warnings.append("Unresolved SELECT * - column list needs information_schema")
    return ts


def extract_all(profile_dir: Path) -> List[TableSchema]:
    return [extract_table_schema(p) for p in sorted(Path(profile_dir).glob("*.sql"))]


if __name__ == "__main__":
    import sys
    for t in extract_all(Path(sys.argv[1])):
        print(f"{t.table:55s} {t.method:9s} {len(t.columns):4d} {'; '.join(t.warnings)}")
