"""
Upstream column-lineage resolver.

Indexes every table created / inserted by any SQL file under dags/ikg/scripts/sql and,
for a given (table, column), walks the SELECT expression back through aliases, CTEs,
sub-queries, temp tables and upstream IKG tables until it reaches a table that is NOT
built by the IKG repo (an EDW / vendor source) or the depth limit.

The resulting chain is what the LLM sees, so descriptions are grounded in the real
derivation logic rather than guessed from the column name.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

from sqlglot import exp

from .sql_parser import _arg, _final_select, _mask, _parse, _unmask

log = logging.getLogger(__name__)

MAX_EXPR_CHARS = 400


@dataclass
class Step:
    obj: str          # table / cte name
    kind: str         # profile | cte | subquery | ikg_table | temp_table | source
    column: str
    expression: str = ""
    file: str = ""
    filter: str = ""

    def as_text(self) -> str:
        e = f" = {self.expression}" if self.expression and self.expression != self.column else ""
        f = f"  | WHERE {self.filter}" if self.filter else ""
        return f"[{self.kind}] {self.obj}.{self.column}{e}{f}"


@dataclass
class _Writer:
    file: str
    select: exp.Select
    ctes: Dict[str, exp.Expression]
    ddl_cols: List[str] = field(default_factory=list)
    schema: str = ""
    temp: bool = False


def _in_window_spec(col: exp.Column) -> bool:
    """True if the column only appears in a window PARTITION BY / ORDER BY (a grouping key, not a value)."""
    node = col
    while node.parent is not None:
        parent = node.parent
        if isinstance(parent, exp.Window) and node is not parent.this:
            return True
        node = parent
    return False


def _short(e: exp.Expression, limit: int = MAX_EXPR_CHARS) -> str:
    s = _unmask(e.sql(dialect="postgres"))
    return s if len(s) <= limit else s[:limit] + " …"


class LineageResolver:
    def __init__(self, sql_root: Path, max_depth: int = 6, max_steps: int = 14):
        self.max_depth = max_depth
        self.max_steps = max_steps
        self.writers: Dict[str, List[_Writer]] = {}
        self._index(Path(sql_root))

    # ------------------------------------------------------------------ index
    def _index(self, root: Path) -> None:
        files = sorted(root.rglob("*.sql"))
        for f in files:
            try:
                dist: Dict[str, List[str]] = {}
                stmts = _parse(_mask(f.read_text(encoding="utf-8", errors="replace")), dist)
            except Exception as e:  # pragma: no cover
                log.warning("skip %s: %s", f, e)
                continue
            ddl: Dict[str, List[str]] = {}
            for st in stmts:
                ctes = {c.alias_or_name.lower(): c.this for c in st.find_all(exp.CTE)}
                if isinstance(st, exp.Create) and (st.args.get("kind") or "").upper() == "TABLE":
                    tbl = st.this.find(exp.Table)
                    if tbl is None:
                        continue
                    name = tbl.name.lower()
                    temp = bool(st.args.get("properties") and "TEMP" in st.args["properties"].sql().upper())
                    if isinstance(st.this, exp.Schema) and st.this.expressions:
                        ddl[name] = [c.name.lower() for c in st.this.expressions if isinstance(c, exp.ColumnDef)]
                    sel = _final_select(st.expression) if st.expression is not None else None
                    if sel is not None:
                        self.writers.setdefault(name, []).append(
                            _Writer(str(f), sel, ctes, [], tbl.db or "", temp))
                elif isinstance(st, exp.Insert):
                    tbl = st.this.find(exp.Table)
                    sel = _final_select(st.expression) if st.expression is not None else None
                    if tbl is None or sel is None:
                        continue
                    name = tbl.name.lower()
                    cols = ([c.name.lower() for c in st.this.expressions] if isinstance(st.this, exp.Schema)
                            else ddl.get(name, []))
                    self.writers.setdefault(name, []).append(_Writer(str(f), sel, ctes, cols, tbl.db or ""))
        log.info("Indexed %d tables from %d SQL files", len(self.writers), len(files))

    # --------------------------------------------------------------- helpers
    @staticmethod
    def _projection_for(select: exp.Select, column: str, ddl_cols: List[str]) -> Optional[exp.Expression]:
        exprs = select.expressions
        if ddl_cols and column in ddl_cols and len(ddl_cols) == len(exprs):
            return exprs[ddl_cols.index(column)]
        for e in exprs:
            if (e.alias_or_name or "").lower() == column:
                return e
        return None

    @staticmethod
    def _sources(select: exp.Select) -> Dict[str, exp.Expression]:
        """alias -> Table | Subquery for FROM + JOINs of this select."""
        out: Dict[str, exp.Expression] = {}
        nodes = []
        if _arg(select, "from") is not None:
            nodes.append(_arg(select, "from").this)
        nodes += [j.this for j in select.args.get("joins") or []]
        for n in nodes:
            alias = (n.alias_or_name or "").lower()
            out[alias] = n
            if isinstance(n, exp.Table):
                out.setdefault(n.name.lower(), n)
        return out

    def _star_sources(self, select: exp.Select) -> List[exp.Expression]:
        srcs = self._sources(select)
        res = []
        for e in select.expressions:
            if isinstance(e, exp.Star):
                res += list({id(v): v for v in srcs.values()}.values())
            elif isinstance(e, exp.Column) and isinstance(e.this, exp.Star):
                q = (e.table or "").lower()
                if q in srcs:
                    res.append(srcs[q])
        return res

    def _has_column(self, src: exp.Expression, col: str, ctes: Dict[str, exp.Expression]) -> bool:
        sel = None
        if isinstance(src, exp.Subquery):
            sel = _final_select(src.this)
        elif isinstance(src, exp.Table):
            n = src.name.lower()
            if n in ctes:
                sel = _final_select(ctes[n])
            elif n in self.writers:
                w = self.writers[n][0]
                if col in w.ddl_cols:
                    return True
                sel = w.select
        if sel is None:
            return False
        names = {(e.alias_or_name or "").lower() for e in sel.expressions}
        return col in names or bool(self._star_sources(sel))

    def from_tables(self, table: str):
        """(schema, table) referenced in FROM / JOIN of the statement that writes `table`."""
        out = set()
        for w in self.writers.get(table.lower(), [])[:1]:
            for n in w.select.find_all(exp.Table):
                name = n.name.lower()
                if name and name not in w.ctes:
                    out.add((n.db or "", name))
        return out

    # --------------------------------------------------------------- resolve
    def resolve(self, table: str, column: str) -> Tuple[List[Step], List[str], str]:
        """Return (chain, source_columns, where_clause_of_profile_select)."""
        table, column = table.lower(), column.lower()
        self._filters_shown: Set[str] = set()
        chain: List[Step] = []
        sources: List[str] = []
        seen: Set[Tuple[str, str, int]] = set()
        where = ""
        ws = self.writers.get(table)
        if ws and _arg(ws[0].select, "where") is not None:
            where = _short(_arg(ws[0].select, "where").this)
        self._resolve_table(table, column, 0, chain, sources, seen, kind="profile")
        return chain, list(dict.fromkeys(sources)), where

    def _resolve_table(self, table, column, depth, chain, sources, seen, kind="ikg_table", schema=""):
        key = (table, column, 0)
        if key in seen:
            return
        seen.add(key)
        if not table:          # e.g. table functions such as generate_series()
            return
        ws = self.writers.get(table)
        if not ws or depth > self.max_depth:
            label = f"{schema + '.' if schema else ''}{table}.{column}"
            sources.append(label)
            chain.append(Step(f"{schema + '.' if schema else ''}{table}", "source", column))
            return
        w = ws[0]
        k = "temp_table" if w.temp else kind
        self._resolve_select(w.select, column, w.ctes, w.ddl_cols, table, k, w.file, depth,
                             chain, sources, seen)

    def _resolve_select(self, select, column, ctes, ddl_cols, obj, kind, file, depth,
                        chain, sources, seen):
        key = (obj, column, id(select))
        if key in seen or len(chain) >= self.max_steps:
            return
        seen.add(key)
        proj = self._projection_for(select, column, ddl_cols)
        if proj is None:
            # maybe provided via SELECT * / alias.*
            for src in self._star_sources(select):
                if self._has_column(src, column, ctes):
                    self._follow(src, column, ctes, file, depth, chain, sources, seen)
                    return
            chain.append(Step(obj, kind, column, "(not found in SELECT)", file))
            return
        inner = proj.this if isinstance(proj, exp.Alias) else proj
        flt = ""
        w = _arg(select, "where")
        if w is not None and kind != "profile":
            flt = _short(w.this, 250)
            if flt in self._filters_shown:      # show each filter once per resolution
                flt = ""
            else:
                self._filters_shown.add(flt)
        chain.append(Step(obj, kind, column, _short(inner), file, flt))
        srcs = self._sources(select)
        refs = [c for c in inner.find_all(exp.Column)
                if not isinstance(c.this, exp.Star) and not _in_window_spec(c)]
        refs = list({(r.table or "", r.name.lower()): r for r in refs}.values())
        for ref in refs[:8]:
            col = ref.name.lower()
            q = (ref.table or "").lower()
            src = srcs.get(q) if q else None
            if src is None and not q:
                cands = [s for s in {id(v): v for v in srcs.values()}.values()]
                if len(cands) == 1:
                    src = cands[0]
                else:
                    src = next((s for s in cands if self._has_column(s, col, ctes)), None)
            if src is None:
                continue
            self._follow(src, col, ctes, file, depth, chain, sources, seen)

    def _follow(self, src, col, ctes, file, depth, chain, sources, seen):
        if isinstance(src, exp.Subquery):
            sel = _final_select(src.this)
            if sel is not None:
                self._resolve_select(sel, col, ctes, [], src.alias_or_name or "subquery", "subquery",
                                     file, depth, chain, sources, seen)
            return
        if isinstance(src, exp.Table):
            n = src.name.lower()
            if n in ctes:
                sel = _final_select(ctes[n])
                if sel is not None:
                    self._resolve_select(sel, col, ctes, [], n, "cte", file, depth, chain, sources, seen)
                return
            self._resolve_table(n, col, depth + 1, chain, sources, seen, schema=src.db or "")


if __name__ == "__main__":
    import sys
    logging.basicConfig(level=logging.INFO)
    r = LineageResolver(Path(sys.argv[1]))
    chain, srcs, where = r.resolve(sys.argv[2], sys.argv[3])
    for s in chain:
        print(" ", s.as_text())
    print("SOURCES:", srcs)
    print("WHERE:", where)
