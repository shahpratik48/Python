"""
Knowledge skill files for ODM and NLG, written ONCE from the repository code when they are absent.

    skills/odm_knowledge_skill.md   skills/nlg_knowledge_skill.md

If the file exists it is never touched (the shipped files are curated; edit them by hand). When the skills folder
is read-only (Airflow DAG folder) the file goes to output/skills/ and is loaded from there.

The writer builds a digest of the repository (folder tree, configuration, enums / constants, DAGs and task ids,
product code, rule / layout examples, SQL) and asks the model for the sections below, one call per section group,
with the digest as a stable prefix (prompt-cache friendly).
"""
from __future__ import annotations

import logging
import re
from datetime import date
from pathlib import Path
from typing import Dict, List

log = logging.getLogger(__name__)

SECTIONS = {
    "nlg": [
        ("1. What NLG is, where it sits (IKG -> ODM -> NLG -> FA products) and the end-to-end architecture",
         "2. Airflow DAGs (names, schedules, triggers, task groups, environments / odm_env / code_env)",
         "3. Rules stage: target types, insight types, rules / rule_logic / group_logic / sql_column_mapping / "
         "ref_table_columns YAML, attach + combine logic, tracery narrative generation, narrative tables"),
        ("4. Products: client briefing, FA alerts, FA subscriptions, banker alerts, FL talent report (monthly / weekly), "
         "market event alerts (+ banking), prospect alerts, JSON insights, retention pack, no-e-mail interaction - "
         "for each: trigger, inputs, logic, output tables, e-mail / portal delivery",
         "5. Insight layout: insight_group_layout YAML, sections / categories / groups / ranks, materiality, "
         "suppression weeks, products per insight, si_nlg_insight_layout / si_nlg_insight_group_and_rank"),
        ("6. Key tables (nlg_db_tables.ini): every table with its schema, role (input / ref / output), who writes "
         "and reads it, important columns and their meaning",
         "7. Glossary and abbreviations used in column names (acc_mhh_n, fa_gpn, fl_gpn, cb, pp, mhh, hh_percentile_idx ...)",
         "8. Example queries (narratives of a household, products of an FA, layout of an insight type, run history) "
         "and operational notes (polling, run history, error log, distribution DB sync, e-mail senders)"),
    ],
    "odm": [
        ("1. What ODM is, the three rule DAGs (client / prospect / FL) + market events, end-to-end flow IKG -> ODM -> NLG",
         "2. Tables: si_odm_insights_active, si_odm_insights_archive, odm_exclusion_insight_type - every column "
         "with a precise business meaning, how rows are produced, run_id / exclusion / archival lifecycle"),
        ("3. Rule SQL conventions (file = insight_type, INSERT columns, target_type values, metric columns, "
         "jinja parameters), rule folders and categories, how rules are discovered as tasks",
         "4. Airflow variables / parameters, example queries, glossary of abbreviations"),
    ],
}

SYSTEM = """# Role: skill-writer
You write a knowledge skill file (markdown) that other agents read to understand a system precisely.
Only state what the repository digest supports; quote identifiers (table / column / file / DAG / task names) exactly.
Prefer tables and short bullet lists; include small code / SQL / YAML examples taken from the digest; give concrete
examples (an insight type, a product, a query). Do not invent columns, tables or rules that are not in the digest.
Write ONLY the requested sections, as markdown starting with '## ' headings. No preamble."""


def ensure_domain_skills(cfg, llm, p) -> List[str]:
    """Write the missing <domain>_knowledge_skill.md files once. Returns the files written."""
    written = []
    dcfg = cfg.get("domains") or {}
    folder = cfg.path((cfg.get("skills") or {}).get("folder", "skills"))
    gen = (cfg.get("skills") or {}).get("generated_folder") or str(cfg.path(cfg.output["folder"]) / "skills")
    gen = cfg.path(gen)
    for d in ("odm", "nlg"):
        dc = dcfg.get(d) or {}
        name = dc.get("skill_file") or f"{d}_knowledge_skill.md"
        if not dc.get("enabled") or d not in getattr(p, "repos", {}):
            continue
        if (folder / name).exists() or (gen / name).exists():
            log.info("skill file %s exists - not recreated", name)
            continue
        log.info("skill file %s missing - writing it from the %s repository (one time)", name, d)
        text = write_skill(d, cfg, llm, p)
        target = folder / name
        try:
            folder.mkdir(parents=True, exist_ok=True)
            target.write_text(text, encoding="utf-8")
        except OSError as e:
            log.warning("skills folder not writable (%s) - writing %s to %s", e, name, gen)
            gen.mkdir(parents=True, exist_ok=True)
            target = gen / name
            target.write_text(text, encoding="utf-8")
        written.append(str(target))
        log.info("skill file written: %s (%d chars)", target, len(text))
    return written


# ----------------------------------------------------------------------------- digest
def _read(path: Path, cap: int) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="replace")[:cap]
    except OSError:
        return ""


def _tree(root: Path, max_entries: int = 400) -> str:
    rows = []
    for d in sorted(x for x in root.rglob("*") if x.is_dir()):
        files = [f for f in d.iterdir() if f.is_file()]
        if files:
            rows.append(f"{d.relative_to(root)}/  ({len(files)} files, e.g. {', '.join(sorted(f.name for f in files)[:4])})")
        if len(rows) >= max_entries:
            rows.append("...")
            break
    return "\n".join(rows)


def _grep(root: Path, pattern: str, glob: str, cap: int = 120) -> str:
    rx = re.compile(pattern)
    out = []
    for f in sorted(root.rglob(glob)):
        for i, line in enumerate(_read(f, 400000).splitlines(), 1):
            if rx.search(line):
                out.append(f"{f.relative_to(root)}:{i}: {line.strip()[:160]}")
                if len(out) >= cap:
                    return "\n".join(out)
    return "\n".join(out)


def digest(domain: str, cfg, p, cap_total: int = 160000) -> str:
    repo = p.repos[domain]
    root = repo.code_root()
    parts: List[str] = [f"REPOSITORY {domain}: {repo.g.get('project_path', root)} @ {repo.g.get('ref', '')}, code root {repo.g.get('code_root', '')}",
                        "FOLDER TREE:\n" + _tree(root)]
    tables = {t: dt for t, dt in getattr(p, "domain_tables", {}).items() if dt.domain == domain}
    if tables:
        parts.append("TABLES IN SCOPE (schema.table, columns from information_schema / DDL):\n" + "\n".join(
            f"{dt.schema}.{t}" + (f" [{dt.key}]" if dt.key else "") + f": {dt.role}\n   columns: " +
            ", ".join(f"{c.name} {c.data_type}" for c in p.schemas[t].columns) for t, dt in sorted(tables.items())))
    if domain == "nlg":
        ld = getattr(p, "loader", None)
        if ld is not None and ld.nlg_settings:
            parts.append(f"nlg_db_tables.ini [{ld.nlg_section}] (ENV {p.env}):\n" +
                         "\n".join(f"{k} = {v}" for k, v in ld.nlg_settings.items()))
        for rel in ("src/config/enums.py", "src/config/constants.py", "src/config/insights_combine_logic.py",
                    "src/config/insights_attach_logic.py", "src/config/insight_layout_ranks.yml",
                    "src/nlg_product_class.py", "src/nlg_main_class.py", "src/nlg_main.py",
                    "dags/nlg_master.py", "dags/nlg_prospect_master.py", "dags/staat_ds_nlg_fl.py",
                    "dags/staat_ds_nlg_market_alert.py", "dags/nlg_staat_email_sender_automation.py",
                    "src/utils/utils_main.py", "src/utils/utils_narratives.py", "src/utils/utils_products_run.py",
                    "src/utils/utils_products_common.py", "src/utils/utils_nlg_run.py", "src/utils/automation_utils.py"):
            f = next(iter(root.rglob(rel.split("/")[-1])), None)
            if f is not None:
                parts.append(f"FILE {f.relative_to(root)}:\n" + _read(f, 14000))
        parts.append("DAG ids / schedules:\n" + _grep(root, r"dag_id\s*=|schedule_interval\s*=|DAG\(\s*['\"]", "*.py", 150))
        parts.append("Task ids (nlg_taskgroups.py):\n" + _grep(root, r"task_id\s*=", "nlg_taskgroups.py", 200))
        for sub, n in (("rules", 3), ("group_logic", 2), ("sql_column_mapping", 1), ("ref_table_columns", 1),
                       ("rule_logic", 1), ("insight_group_layout", 3), ("input_data_config", 2), ("email_templates", 1)):
            d = next((x for x in root.rglob(sub) if x.is_dir()), None)
            if d is None:
                continue
            files = sorted(f for f in d.rglob("*") if f.is_file() and f.suffix in (".yml", ".yaml", ".json", ".html"))
            parts.append(f"{sub}/: {len(files)} files, sub-folders: {sorted({str(f.parent.relative_to(d)) for f in files})[:60]}")
            for f in files[:n]:
                parts.append(f"EXAMPLE {f.relative_to(root)}:\n" + _read(f, 3500))
    else:
        parts.append("SQL files:\n" + "\n".join(str(f.relative_to(root)) for f in sorted(root.rglob("*.sql"))[:400]))
        for f in sorted(root.rglob("*.txt"))[:6]:
            parts.append(f"FILE {f.relative_to(root)} (first lines):\n" + "\n".join(_read(f, 6000).splitlines()[:80]))
        for pat in ("*table_creation*.sql", "*exclusion*.sql", "*archiv*.sql"):
            for f in sorted(root.rglob(pat))[:3]:
                parts.append(f"FILE {f.relative_to(root)}:\n" + _read(f, 8000))
        rules = [f for f in sorted(root.rglob("*.sql")) if "insights" in str(f.parent).lower()]
        for f in rules[:6]:
            parts.append(f"EXAMPLE RULE {f.relative_to(root)}:\n" + _read(f, 4000))
        for f in sorted(root.rglob("*.py"))[:8]:
            parts.append(f"FILE {f.relative_to(root)}:\n" + _read(f, 6000))
    text = "\n\n".join(parts)
    return text[:cap_total]


# ----------------------------------------------------------------------------- write
def write_skill(domain: str, cfg, llm, p) -> str:
    dig = digest(domain, cfg, p)
    repo = p.repos[domain]
    head = (f"---\nname: {domain}-knowledge\ndescription: Technical and functional knowledge of {domain.upper()} "
            f"(generated from the {domain}-dags repository on {date.today()}; edit by hand, never regenerated)\n---\n\n"
            f"# {domain.upper()} knowledge skill\n\nRepository: {repo.g.get('project_path', repo.root)} @ {repo.g.get('ref', '')}\n")
    body = []
    effort = (cfg.get("agents", {}).get("reasoning_effort") or {}).get("skill") or cfg.llm.get("reasoning_effort")
    for group in SECTIONS[domain]:
        user = ("Write these sections of the skill file (markdown, '## ' headings, precise, with examples):\n- "
                + "\n- ".join(group))
        msgs = [{"role": "system", "content": SYSTEM}, {"role": "user", "content": "REPOSITORY DIGEST:\n" + dig},
                {"role": "user", "content": user}]
        m = llm.chat(msgs, tools=None, tool_choice="none", reasoning_effort=effort)
        txt = (getattr(m, "content", None) or "").strip()
        if txt.startswith("```"):
            txt = txt.split("\n", 1)[1].rsplit("```", 1)[0]
        body.append(txt)
    return head + "\n\n" + "\n\n".join(body) + "\n"
