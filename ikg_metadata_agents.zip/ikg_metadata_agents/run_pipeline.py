"""
Command-line runner for the agent-based IKG metadata + knowledge-graph program (same as the notebook).

  python run_pipeline.py --check                     # Greenplum, GitLab, Azure OpenAI connectivity
  python run_pipeline.py --selftest                  # whole agent system with a scripted offline model (no tokens)
  python run_pipeline.py --prepare-only              # data layer only: evidence + base glossary (no LLM)
  python run_pipeline.py --tables household_art_profile_curr_ikg client_profile_curr_ikg   # pilot
  python run_pipeline.py                             # all profile tables, master agent orchestrates
  python run_pipeline.py --orchestration deterministic

Secrets are prompted (hidden) or read from IKG_AZURE_OPENAI_API_KEY / IKG_GP_PASSWORD / IKG_GITLAB_TOKEN.
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from ikgmeta import agents  # noqa: E402
from ikgmeta import sources as src  # noqa: E402
from ikgmeta.config import load_config  # noqa: E402
from ikgmeta.llm import LLM  # noqa: E402


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config")
    ap.add_argument("--tables", nargs="*")
    ap.add_argument("--orchestration", choices=["llm", "deterministic"])
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--prepare-only", action="store_true")
    ap.add_argument("--refresh-code", action="store_true")
    a = ap.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    for n in ("sqlglot", "httpx", "httpx2", "openai"):
        logging.getLogger(n).setLevel(logging.ERROR)

    cfg = load_config(a.config)
    if a.tables:
        cfg["generation"]["profile_tables"] = a.tables
    out = cfg.path(cfg.output["folder"])
    if a.selftest:
        cfg["output"]["folder"] = str(out / "selftest")
        out = cfg.path(cfg.output["folder"])

    gp = src.Greenplum(cfg) if cfg.sources["mode"] == "db" else None
    if a.check:
        if gp:
            print("Greenplum:", gp.test())
        print("GitLab code:", src.GitLabCode(cfg, out / "cache").fetch(refresh=a.refresh_code))
        print("Azure OpenAI:", LLM(cfg, out / "cache").check())
        return

    if a.selftest:
        from ikgmeta.agents.selftest import ScriptedLLM
        llm = ScriptedLLM(cfg, out / "cache")
    else:
        llm = LLM(cfg, out / "cache")
    ctx = agents.prepare(cfg, llm, gp, refresh_code=a.refresh_code)
    if a.prepare_only:
        ctx.p.ctx.to_csv(out / "attribute_evidence.csv", index=False)
        ctx.p.glossary.frame().to_csv(out / "glossary_base.csv", index=False)
        print("Estimated volume (non-agent baseline):", ctx.p.estimate_tokens())
        return
    res = agents.run(ctx, a.orchestration)
    print(json.dumps(res, indent=1, default=str))


if __name__ == "__main__":
    main()
