"""
Command-line runner for the agent-based IKG metadata + knowledge-graph program (same as the notebook).

  python run_pipeline.py --check                     # Greenplum, GitLab, Azure OpenAI connectivity
  python run_pipeline.py --selftest                  # whole agent system with a scripted offline model (no tokens)
  python run_pipeline.py --prepare-only              # data layer only: evidence + base glossary (no LLM)
  python run_pipeline.py --tables household_art_profile_curr_ikg client_profile_curr_ikg   # pilot
  python run_pipeline.py                             # all profile tables, master agent orchestrates
  python run_pipeline.py --orchestration deterministic
  python run_pipeline.py --backfill-runs 30 --backfill-minutes 240   # drain the backlog: budgeted runs back to back

Secrets are prompted (hidden) or read from IKG_AZURE_OPENAI_API_KEY / IKG_GP_PASSWORD / IKG_GITLAB_TOKEN.
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from ikgmeta import agents  # noqa: E402
from ikgmeta import sources as src  # noqa: E402
from ikgmeta.config import load_config  # noqa: E402
from ikgmeta.llm import LLM  # noqa: E402


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config")
    ap.add_argument("--tables", nargs="*")
    ap.add_argument("--orchestration", choices=["llm", "deterministic"])
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--prepare-only", action="store_true")
    ap.add_argument("--refresh-code", action="store_true")
    ap.add_argument("--env", choices=["PROD", "UAT", "TEST"], help="overrides config environment (schema, NLG ini section, roles)")
    ap.add_argument("--no-domains", action="store_true", help="profile tables only (ODM / NLG tables off)")
    ap.add_argument("--backfill-runs", type=int, default=1,
                    help="repeat budgeted runs back to back until the backlog is empty (max N runs); 1 = one normal run")
    ap.add_argument("--backfill-minutes", type=float, default=0, help="stop the backfill after this many minutes (0 = no limit)")
    a = ap.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    for n in ("sqlglot", "httpx", "httpx2", "openai"):
        logging.getLogger(n).setLevel(logging.ERROR)

    cfg = load_config(a.config, environment=a.env)            # odm_env: config, env variable ODM_ENV or --env
    from ikgmeta.runlog import start_log_file
    start_log_file(cfg.path(cfg.output["folder"]))
    if a.no_domains:
        for d in ("odm", "nlg"):
            cfg["domains"][d]["enabled"] = False
    if a.tables:
        cfg["generation"]["profile_tables"] = a.tables
    out = cfg.path(cfg.output["folder"])
    if a.selftest:
        cfg["output"]["folder"] = str(out / "selftest")
        out = cfg.path(cfg.output["folder"])

    gp = src.Greenplum(cfg) if cfg.sources["mode"] == "db" else None
    if a.check:
        if gp:
            print("Greenplum:", gp.test())
        print("GitLab code:", src.GitLabCode(cfg, out / "cache").fetch(refresh=a.refresh_code))
        for d in ("odm", "nlg"):
            if cfg["domains"][d]["enabled"]:
                print(f"GitLab {d}:", src.GitLabCode(cfg["domains"][d]["gitlab"], out / "cache", d).fetch(refresh=a.refresh_code))
        print("Azure OpenAI:", LLM(cfg, out / "cache").check())
        return

    if a.selftest:
        from ikgmeta.agents.selftest import ScriptedLLM
        llm = ScriptedLLM(cfg, out / "cache")
    else:
        llm = LLM(cfg, out / "cache")
    if a.backfill_runs and a.backfill_runs > 1 and not a.prepare_only:
        ctx, res = agents.run_until_done(cfg, llm, gp, max_runs=a.backfill_runs, max_minutes=a.backfill_minutes,
                                         mode=a.orchestration, refresh_code=a.refresh_code)
        print(json.dumps(res, indent=1, default=str))
        return
    ctx = agents.prepare(cfg, llm, gp, refresh_code=a.refresh_code)
    if a.prepare_only:
        ctx.p.ctx.to_csv(out / "attribute_evidence.csv", index=False)
        ctx.p.glossary.frame().to_csv(out / "glossary_base.csv", index=False)
        print("Estimated volume (non-agent baseline):", ctx.p.estimate_tokens())
        return
    res = agents.run(ctx, a.orchestration)
    res["backlog"] = agents.backlog_of(ctx)
    print(json.dumps(res, indent=1, default=str))


if __name__ == "__main__":
    main()
