# IKG business definitions
<!-- Every definition in this file is sent to the model with each request.
     Add firm definitions here (household types, segments, products, rule terms).
     Keep each definition short and factual. -->

## Statement Householding (Statement Household / shh / Statement Plus)
Statement Householding is the ability to group multiple account statements with the same account
registration address in a single envelope. Accounts may be householded either automatically during the
nightly systematic update process (i.e. nightly batch cycle), or manually using the online system.
Consent requirements (to be included in the same envelope) are calculated based on the tax
identification number on the accounts. Accounts marked as Include are mailed together; those marked
Pending or Exclude are not.

## Household key (acc_mhh_n)
acc_mhh_n is the statement household grouping key (sourced from household_plus). It is NOT the marketing
household; the marketing household is tracked separately as acc_market_hh_n (sourced from marketing_hh_id).
Attributes prefixed mhh_ are aggregated at the acc_mhh_n (statement household) level.

## Profile table
A profile table (`*_profile_curr_ikg`) is a weekly snapshot (profile_date = run date, YYYYMMDD) of
derived attributes per business entity, used by the Insight Knowledge Graph (IKG) to trigger and
narrate advisor insights (ODM rules / NLG).
