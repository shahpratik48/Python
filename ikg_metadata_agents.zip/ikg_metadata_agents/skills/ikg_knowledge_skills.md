---
name: ikg-knowledge-skills
description: Firm knowledge for the IKG profile tables - household definitions, statement household (acc_mhh_n), metadata writing standards
---
# IKG knowledge skills

This file is the single place for firm knowledge about the IKG profile tables (`core_ikg.*_profile_curr_ikg`).
It merges the former skill files `household_definitions.md`, `statement_household.md` and `ikg_metadata_standards.md`.
ODM and NLG knowledge live in `odm_knowledge_skill.md` and `nlg_knowledge_skill.md` next to this file.

Rules for maintaining this file: write facts plainly (the skill agent must quote them verbatim); put column
definitions as `column = meaning`, abbreviations as `abbr = Full Form`, code values as `column: CODE = meaning`.

## Household definitions

### Statement Householding
Statement Householding is the ability to group multiple account statements with the same account
registration address in a single envelope. Accounts may be householded either automatically during the
nightly systematic update process (i.e. nightly batch cycle), or manually using the online system.
Consent requirements (to be included in the same envelope) are calculated based on the tax identification
number on the accounts. Accounts marked as Include are mailed together; those marked Pending or Exclude
are not.

### Abbreviations
- shh = Statement Household
- mhh = Marketing Household (as a token in column names such as mhh_assets_curr the measures are computed at the household level keyed by acc_mhh_n)
- hh = Household
<!-- SME: add other household abbreviations here -->

## Statement household key (acc_mhh_n)
In all profile tables, acc_mhh_n - is this marketing household or statement household?

source - ubs_base_acc_features_ikg. Let's check that table's definition of acc_mhh_n.

This confirms it: acc_mhh_n = b.household_plus, while acc_market_hh_n is separately populated from b.marketing_hh_id. So acc_mhh_n is distinct from the marketing household ID - it's the "household_plus" value, which (per the lineage docs) is UBS's statement/household grouping key (distinct from marketing_hh_id).

acc_mhh_n = statement household (sourced from household_plus), not the marketing household. The marketing household is tracked separately as acc_market_hh_n (sourced from marketing_hh_id).

- acc_mhh_n = statement household identifier (household_plus); the key that joins household, client and account profile tables and the NLG narrative tables
- acc_market_hh_n = marketing household identifier (marketing_hh_id)
- ip_cli_i = client (involved party) identifier
- acc_i = account identifier
- fa_gpn = Financial Advisor GPN (global personnel number)
- fl_gpn = Field Leader GPN
- main_prospect_id = prospect identifier used by the prospect profiles, ODM prospect rules and NLG prospect narratives
- profile_date = business date of the weekly profile snapshot

## Metadata writing standards

### Functional names
- Use Title Case business names without abbreviations, for example "Household Cash Distributions Last 4 Weeks".
- Flags end with the word Indicator; counts end with the word Count.
- Identifiers end with the word Identifier (or Key for technical keys); dates end with the word Date.

### Descriptions
- State the unit (USD, percent, count, days) and the time window explicitly.
- For flags state what 1 means and what 0 means.
- Name the source system or vendor when known (EDW, Black Knight, ZoomInfo, Wealth-X, Yodlee, Speedeon, Windfall).
- For ODM and NLG attributes name the producing process (ODM rule scripts, NLG rules stage, NLG product) and the
  consumer (NLG, FA e-mail, FA portal) when the code shows it.
- The same column name must get the same functional name and description in every table (profile, ODM and NLG tables).
