---
name: nlg-knowledge
description: NLG (Natural Language Generation, nlg-dags) - architecture, DAGs, rules stage, products, insight layout, every table of nlg_db_tables.ini with its role and key columns, glossary, example queries
---
# NLG - Natural Language Generation | Knowledge Skill

**Repository:** `nlg-dags` (`ubs/gwma/smart-technology-and-analytics/staat-data-science/staat-ds-genesis/genesis-platform/nlg-dags`, branch `main`)
**Code root:** `dags/nlg/` with `dags/` (Airflow DAGs) and `src/` (Python package `nlg.src`, configuration, rules)
**Schemas (prod_active):** `schema_nlg = core_nlg` (NLG tables), `schema_ikg = core_ikg` (IKG profiles, polling, FA maps), `schema_odm = core_ikg` (ODM hits), `schema_ref = core_nlg`, `schema_fa_ta_mhh_map = core_ikg`, `schema_fa_ta_prospect_map = core_ikg`
**Schemas (dev_active):** `schema_nlg = sandbox_prj_insights_nlg`, `schema_ikg = schema_odm = schema_fa_ta_mhh_map = schema_fa_ta_prospect_map = sandbox_ikg_pre_prd`, `schema_ref = sandbox_prj_insights_nlg`
**Platform:** Apache Airflow (Genesis), Greenplum connection id `INSIGHT_PIPELINE_RUNNER_DB_CONNECTOR` (gprdsp)

---

## 1. What NLG is

NLG is the last stage of the Smart Insights pipeline. It turns the rule hits produced by ODM (one row per
`insight_type` x `target_key` in `core_ikg.si_odm_insights_active`) into **narratives** - short HTML sentences
written for the Financial Advisor - and assembles the narratives into **products** (client briefings, FA alerts,
subscriptions, banker alerts, Field-Leader talent reports, market-event alerts, prospect alerts, JSON insights for
the FA portal). Narratives are generated from YAML rules with the **tracery** grammar library; no model is involved.

```
IKG profiles (core_ikg.*_profile_curr_ikg)  -->  ODM rules (core_ikg.si_odm_insights_active)
      |                                                   |
      +-------------------- NLG rules stage --------------+   rules/<target_type>/<insight_type>.yml (tracery)
                                   |
                     core_nlg.si_nlg_fa_narratives_active (+ _curr, fl, fa_ma, prospect)
                                   |
      products: client briefing | FA alerts | subscriptions | banker alerts | FL talent report | market alerts | prospect alerts | JSON insights
                                   |
      delivery: e-mail sender DAGs (Adobe / SMTP, *_weekly_emails_active status tables) and distribution DB core_prj_insights_nlg (FA portal, panels, Tableau)
```

Key concepts:
- **target type** = the kind of entity a rule works on (`client`, `household`, `account_sbl`, `fl_ubs_fa`, `prospect` ...; enum `InsightTargetType` in `src/config/enums.py`). One Airflow task per target type in the rules stage.
- **insight type** = one rule = one ODM SQL file name = one NLG rule YAML (`si_client_birthday`, `si_sbl_in_margin_call` ...). The list of insight types of a target type is read from ODM (`get_insight_types_of_target_type`) unless `--insight_types` is given.
- **insights_target_user_type** = `fa` (advisor products) or `fl` (field leader) - set per target type in `config/input_data_config/<target_type>.yml`; decides which narratives table is written (`output_tbl_narratives_fa` vs `output_tbl_narratives_fl`).
- **odm_env** = `dummy | dummy2 | review | test | active | regression` (which input data / ODM table set) and **code_env** = `dev | prod`; together they select the ini section `<code_env>_<odm_env>` of `src/config/nlg_db_tables.ini`. Production = `prod_active`; dev pre-prod = `dev_active`.
- **time_created / week_start_date** = run identifiers of a weekly run (Monday of the week); `_active` tables keep every run, `_active_curr` tables keep only the latest run.

---

## 2. Airflow DAGs (dags/nlg/dags)

| DAG id | File | Schedule / trigger | What it does |
|---|---|---|---|
| `nlg_master` | nlg_master.py | `0 6 * * 1-5` on UAT (NLG_SCHEDULE_INTERVAL), otherwise triggered by `ikg_master` | Full weekly NLG run: `start_nlg >> check_odm_run_completion >> populate_latest_odm_insights >> nlg_preprocess >> nlg_rules >> [nlg_product_client_briefings, nlg_product_others, nlg_json_insights] >> nlg_post_process >> end_nlg` (task groups in nlg_taskgroups.py). Params: `odm_env` (Variable ODM_FOLDER), `triggered_by_master_dag`, `master_run_id`. |
| `staat_ds_nlg` | staat_ds_nlg.py | triggered by ikg_master | Older full pipeline variant (same stages as task operators). |
| `nlg_prospect_master` | nlg_prospect_master.py | triggered by ikg_master | Prospect run: sync layout + ref tables -> `nlg_rules_prospect_speedeon`, `nlg_rules_prospects_wealthx_delta`, `nlg_rules_prospect`, `nlg_rules_prospect_windfall`, `nlg_rules_prospect_mls_blacknight` -> `post_nlg_update_narrative_curr_table` -> `nlg_prospect_alert` (FA_PROSPECT_MAIL) -> update curr -> notify -> e-mail generation (`nlg_generate_prospect_alerts_emails`). |
| `nlg_fl_report_generation` | staat_ds_nlg_fl.py | triggered by ikg_master (config `is_monthly`, `product`, `target_types`) | Field-Leader run: days 11-17 of the month = monthly `FL_TALENT_REPORT`, other days = weekly `FL_TALENT_REPORT_WEEKLY`; target types `fl_recruitment`, `fl_ubs_fa` (+ `fl_ubs_client`); triggers `nlg_generate_fl_talent_report_emails`. |
| `nlg_market_alert_generation` | staat_ds_nlg_market_alert.py | triggered | Market-event products `FA_MARKET_ALERT`, `FA_MARKET_ALERT_BANKING` (target types `market_event`, `market_event_bank_im`). |
| `nlg_generate_cb_emails` (staat_ds_nlg_cb_email_generation.py) | `0 10 * * 1,4` UTC (Mon, Thu) | client briefing e-mail generation, then `nlg_post_product_sync_cb_email_to_prod`, `nlg_post_process_create_tableau_data_sources` |
| `nlg_staat_email_sender_mon_thur_fri_execution` | nlg_staat_email_sender_automation.py | `0 11 * * 1,4,5` | sends the generated e-mails (waits for `nlg_generate_cb_emails`) |
| `nlg_staat_email_sender_wed_delayed_execution` | nlg_staat_email_sender_delayed_execution.py | `0 16 * * 3` | Wednesday delayed send |
| `nlg_staat_email_sender` | nlg_staat_email_sender.py | manual (params odm_env, sampling_flag, sample_size, reciever_email, product_type, campaign_date, household_no, insight_type) | sends one product type (`fa_alert`, `banker_alert`, `fl_report`, `market_alert`, `client_briefing`, `client_briefing_summary`, `market_banking_alert`, `prospect_alert`) via `SmartEmailClass`; full sends only on Live, samples elsewhere |
| `nlg_send_client_briefing_emails`, `nlg_send_cb_summary_emails`, `nlg_send_fl_talent_emails`, `nlg_send_market_alert_emails`, `nlg_send_banker_alert_emails` | nlg_send_*.py | triggered | product specific senders |
| `nlg_post_process_sync_to_distribution_db` | nlg_post_process_sync_to_distribution_db.py | triggered by the pipeline | copies `si_fa_calendar_client_map`, `si_nlg_household_insights_in_json_active_curr`, `si_nlg_insight_group_and_rank`, `si_nlg_insight_layout`, `si_pilot_rel_shp_map`, `fl_fa_common_shp_map`, `si_pilot_fa_shp_map` ... into `core_prj_insights_nlg` (backup copy with a timestamp suffix first), then triggers the Tableau data-source DAG |
| `nlg_post_process_create_tableau_data_sources` | nlg_post_process_create_tables_for_tableau.py | triggered | reporting tables for Tableau |
| `nlg_post_product_sync_cb_email_to_prod` / `_fl_email_to_prod` / `_prospect_email_to_prod` | nlg_post_product_sync_*.py | triggered | copy generated e-mail content to the production sending schema |
| `nlg_regression` | nlg_regression.py | manual | regression run on `dev_regression` settings + `regression_data_comparison.py` |
| `nlg_insight_reporting`, `nlg_latest_deployed_files`, `nlg_briefing_cal_id_map_job`, `nlg_staat_email_alert_cleaner`, `staat_ds_nlg_db_changes_in_prod`, `staat_ds_nlg_distribution_db_changes_prod` | | manual / ad hoc | reporting, deployment check, calendar id map, alert cleaning, DDL changes |
| `staat_ds_calendar_entity_matching` | staat_ds_calendar_entity_matching.py | `0 5 * * *` | matches FA calendar events to clients (`si_fa_calendar_client_map`) used by the client briefings |

### nlg_master task groups (nlg_taskgroups.py)
- `check_odm_run_completion`: `ExternalTaskSensor` on `ikg_master.run_odm_rules_trigger` when triggered by the master DAG, else skipped; `set_nlg_start_time` writes `nlg_run_start_time` into the polling table `ikg_run_status` (`ref_ikg_odm_nlg_polling_tbl`).
- `populate_latest_odm_insights`: `refresh_odm_insights_curr` (refresh_odm_insights_review_curr.py) for review / dummy environments; skipped in prod.
- `nlg_preprocess`: non-prod `pre_nlg_sync_fa_ta_mhh_map_data_anonymize` + `pre_nlg_sync_exclude_ids`; prod `pre_nlg_update_time_sent_for_prev_week`, `pre_nlg_sync_ref_tables_for_prod`; always `pre_nlg_sync_insight_type_layout` (YAML -> `si_nlg_insight_layout`, `si_nlg_insight_group_and_rank`).
- `nlg_rules`: `nlg_rules_asset_allocation_batch_1..3` (household id ranges < 31095161, < 34767372, rest), `nlg_rules_account`, `nlg_rules_account_asset_cat`, `nlg_rules_account_sbl`, `nlg_rules_account_mtg`, `nlg_rules_household_art`, `nlg_rules_client`, `nlg_rules_household`, `nlg_rules_household_holding`, `nlg_rules_household_recipient`, `nlg_rules_household_spending`, `nlg_rules_client_ext_acc`, `nlg_rules_account_holding_mat_sec`, `nlg_rules_client_medallia`, `nlg_rules_wealthx`, `nlg_rules_client_bknight_mls`, `nlg_rules_account_insurance_policy`, `nlg_rules_client_fga_goal`, `nlg_rules_account_holding`, `nlg_rules_client_speedeon`, `nlg_rules_client_bknight`, `nlg_rules_zoominfo`, `nlg_rules_client_windfall`, `nlg_rules_account_holding_mmf`, `nlg_rules_client_newsedge`, `nlg_rules_client_fga_asset`, `nlg_rules_deceased_client`, `nlg_rules_client_card_txn`, `nlg_rules_client_npo`; then `post_nlg_update_narrative_curr_table`, `post_nlg_fill_end_time`. Each task calls `NLG(args).generate_rule_narratives()` with `action = generate_rule_narratives`, `nlg_time_start = from_polling_table`.
- `nlg_product_client_briefings`: `nlg_client_briefing_start` (cb_time_start) -> `nlg_client_briefing_1` (hh percentiles 0-49) and `_2` (50-99) -> `nlg_client_briefing_update_curr_table` -> truncate buffers -> `nlg_retention_pack_update_curr_table` -> `nlg_create_fa_cb_unnest_table` -> `retention_pack_processing` / `post_nlg_product_client_briefing_email_generation` (review / regression only).
- `nlg_product_others`: `nlg_product_fa_alerts` -> `nlg_fa_alerts_update_curr_table` -> `nlg_product_fa_alerts_email_generation`; `nlg_product_fa_subscriptions` -> update curr -> e-mail generation; `nlg_product_banker_alerts`; `nlg_product_fa_alerts_email_generation_notify`.
- `nlg_json_insights`: `nlg_json_insights_1..3` (parallel) -> `nlg_json_insights_copy_from_csv` -> `nlg_json_insights_update_curr_table` -> truncate buffer -> `nlg_json_insights_load_prod_test_insights_to_curr_tbl` (prod).
- `nlg_post_process`: `post_nlg_fill_products_end_time`, `nlg_completion_notify`, `run_nlg_post_process_sync_to_distribution_db` (TriggerDagRunOperator).

Airflow Variables used: `ODM_FOLDER` (odm_env), `NLG_CODE_ENV` (code_env), `IKG_PROFILE_DATE`, `AirflowSPNId` / `AirflowSPNSecret` (EVA household-id encryption API), `bankers_opt_out_dict`, `NLG_STAAT_EMAIL_ODM_ENV`, `NLG_STAAT_EMAIL_SAMPLE_RECIPIENT`, `AIRFLOW_UAT_URL`.
Pod templates: `genesis_pod_template_dedicated_highcpu.yaml` (rules), `genesis_pod_template_dedicated_highmem.yaml` / `_50g` / `_32g` (products).
Paths in the pods: `config_ref_data_root_path = /opt/airflow/dags/nlg/src/`, `data_file_root_path = /opt/airflow/data/cid/nlg/output/`, `log_file_path = /opt/airflow/data/cid/nlg/logs/`.

---

## 3. Rules stage (narrative generation)

Entry points: `src/nlg_main.py` (CLI) / `src/nlg_main_class.py` (`NLG` class, used by Airflow) -> `utils/utils_main.run_nlg`.

### 3.1 Per target type
1. `config/input_data_config/<target_type>.yml` (or `input_data_config_dummy/`): `target_key_conversion` (e.g. `::float::numeric`), `input_db_join_col` (`ip_cli_i`, `acc_mhh_n`, `acc_i` ...), `insights_target_user_type` (`fa` / `fl`) and the base `sql_column_mapping` (narrative field -> SQL expression on the IKG profile row `b.` and the ODM row `a.`).
2. Insight types of the target type come from ODM (`insight_type_from_odm = 1`) or from the arguments; `--insight_types_exclusion` removes some. Insight types that take part in attach / combine logic run together, the others separately.
3. For every insight type (`run_nlg_of_insight_type`):
   - `rules/<target_type>/<insight_type>.yml` - the **tracery grammar**: `rule_narrative`, `rule_narrative_title`, `rule_narrative_footer`, optional `narrative_combination`, `narrative_compound_version`, each field of the data row is a symbol `#field#`, modifiers are called as `#field.modifier(params)#` (modifiers in `src/modifiers/common.py` and `business_logic_related.py`: `date_format`, `format_multi_names`, `convert_to_m_or_k`, `format_num_with_comma`, `formate_num_with_th`, `show_text_if_true`, `generate_portal_calendar_event_deeplink`, `format_hh_return_ytd` ...). Files can have environment specific variants (`load_yaml_files_by_name_and_env`).
   - `rule_logic/<target_type>/<insight_type>.yml` - optional extra SQL filter (`ikg_filter`).
   - `sql_column_mapping/<target_type>/<insight_type>.json|yml` - additional columns for this insight (merged into the base mapping).
   - `ref_table_columns/<target_type>/<insight_type>.yml` - extra reference data: `columns`, `sql` (with `{schema_ikg}.{input_tbl_account}` placeholders resolved from the ini), `join_keys`, `arr_columns_to_format`, `columns_merged_from_arr_cols`.
   - `group_logic/<target_type>/<insight_type>.yml` - `group_key` (e.g. `acc_mhh_n`, `ip_dob_d`), `items_in_group_sort_key`, `distinct_on`, `fields_not_null`, `item_narrative_from_yml`, `only_use_group_logic_for_multi_items`, `join_narrative_items_with_sub_bullets` -> several rows become ONE narrative (e.g. two clients with the same birthday).
   - `fetch_data_with_insights` (`utils/utils_narratives.py`) builds and runs the SQL: `select <mapping> from (select ... from {schema_odm}.{odm_insights_tbl} where target_type = '<tt>' and insight_type = '<it>') a inner join {schema_ikg}.{input_tbl_<tt>} b on a.target_key = b.<join col> [pilot join on si_pilot_fa_shp_map x si_pilot_fa_list] [ref joins] where b.acc_mhh_n is not null [hh id range] [fields_not_null]`. Variants: `_for_fl` (joins `input_tbl_<tt>_map_tbl`), `_for_pr` (prospects, key `main_prospect_id`), dummy household injection for non-prod (`si_nlg_dummy_client_cid_info`).
   - `generate_narratives_with_group_logic` / `_no_group_logic` run tracery in batches of `tracery_batch_size` (5000); beta insights (`is_beta_insight` in the layout) get a beta bullet.
   - `transform_narrative_entry` builds the row of the narratives table (see 6.3), adds URL tracking tags and the week.
4. Attach logic (`config/insights_attach_logic.py`, `INSIGHTS_ATTACH_LOGIC`): a main insight absorbs attached insights of the same group key, e.g. `si_client_birthday` + `si_client_birthday_milestone`, `_inc_retirement_cont`, `_mandatory_rmd`, `_recommend_rmd`, `_medicare`, `_social_security`, `_basis_planning`, `_college_planning`, `_workforce_new`, `_rmd_required`; `si_prospect_birthday` + retirement / medicare / social security; `si_household_art_review_overdue` + `_upcoming`; Medallia team ratings.
5. Combine logic (`config/insights_combine_logic.py`, `INSIGHTS_COMBINE_LOGIC`): several insights of one group key become one narrative (`combine_option` = `overwritten` or `join` with `join_delimiter`), e.g. household `si_struc_prod_yield_enhance` + `si_struc_prod_intl_exp_trade`; Medallia real-estate life events; ZoomInfo intent signals per `znfo_company_id`; FL red flags per `fl_gpn` x `fa_gpn` (`si_fl_ubs_fa_red_flag_*`); FL recruits per `individual_gpn` x `rep_crd`.
6. Save: `save_narrative_list_to_db_via_csv_buffer` writes a CSV (`nlg_buffer/<odm_env>/`), creates a buffer table from the template `output_tbl_narratives_buffer_base` (`si_nlg_fa_narr_bfr_base`) named `<template>_<odm_env>_<target>_<yymmdd_HHMMSS>`, copies the CSV in, inserts into the narratives table and drops the buffer. A full run first deletes rows of the same `week_start_date` + `time_created` + target types.
7. Errors per insight type go to `nlg_run_error_log` (`si_nlg_run_error_log_active`: week_start_date, raw_narrative_time_start, insight_type, target_type, nlg_stage, error_log) and optionally e-mail `dl-staat-data-science-nlg@ubs.com`.

### 3.2 Curr tables (`post_nlg_update_narrative_curr_table*`)
- `update_rule_narratives_curr_table` (FA): merges the latest `odm_free` narratives into `si_nlg_fa_narratives_active`, truncates `si_nlg_fa_narratives_active_curr` and reloads the latest run partitioned by `hh_percentile_idx` using `si_nlg_household_percentile_range` (hh_percentile_idx, min_hh_id, max_hh_id); for dummy households it limits insights per section (Recap of Milestones 1 group, Top Insights 6 groups, else 3) and de-duplicates on (acc_mhh_n, insight_type); writes a row into `nlg_run_history` (`si_nlg_run_history_active`: week_start_date, raw_narrative_time_start, raw_narrative_time_end, time_created).
- `update_rule_narratives_curr_table_fl(product)`: `si_nlg_fl_narratives_active_curr` = latest run, filtered to the insight types of the product (`FL_TALENT_REPORT` vs `FL_TALENT_REPORT_WEEKLY`) so monthly and weekly do not bleed.
- `update_rule_narratives_curr_table_fa_ma`: `si_nlg_fa_ma_narratives_active_curr` (market alerts).
- `update_prospect_rule_narratives_curr_table`: prospect tables (`si_nlg_fa_prospect_narratives_active` / `_curr`, odm_free variant).

### 3.3 Target types
`InsightTargetType`: account, account_mtg, client, household, household_art, household_holding, household_recipient, client_ext_acc, client_medallia, client_wealthx, client_wealthx_delta, client_fga_goal, client_windfall, account_sbl, account_holding, client_speedeon, client_bknight, asset_allocation, client_zoominfo_intent, client_zoominfo_scoop, fl_recruitment, fl_ubs_fa, fl_ubs_client, client_zoominfo_firmographic, account_holding_mat_sec, client_wealthx_attributes, yodlee_mtp_acc, yodlee_mtp_acc_holding, yodlee_mtp_transaction, household_optimus, client_brightscope, market_event, market_event_bank_im, client_bknight_mls, prospect_speedeon, prospect, prospect_wealthx_delta, prospect_windfall (+ account_asset_cat, account_holding_mmf, account_insurance_policy, household_spending, client_card_txn, client_newsedge, client_fga_asset, deceased_client, client_npo, prospect_mls_blacknight as rule folders).
`InsightAccountLevelTargetType` (narratives keep `account_ids`): account_sbl, account, account_mtg, client_ext_acc, account_holding, yodlee_mtp_acc, yodlee_mtp_acc_holding, yodlee_mtp_transaction, account_holding_mat_sec.
Each target type maps to one IKG profile table: `input_tbl_<target_type>` in the ini (client -> client_profile_curr_ikg, household -> household_profile_curr_ikg, account -> account_profile_curr_ikg, account_sbl -> account_sbl_profile_curr_ikg, client_ext_acc -> mtp_profile_curr_ikg, household_recipient -> household_wire_transaction_profile_curr_ikg, fl_ubs_fa -> fl_fa_profile_curr_ikg, prospect -> prospect_profile_curr_ikg ...).

---

## 4. Products (`src/nlg_product_class.py` -> `utils/utils_products_run.py`)

`NlgProduct(args).generate_products()` / `generate_product_emails()`; `product_settings` maps each product to its buffer / product / `_curr` table (keys of the ini):

| Product | product_alias | Generator | Input narratives | Output tables (ini key) | Delivery |
|---|---|---|---|---|---|
| `FA_MEETING_MAIL` (client briefing) | client_briefing | `run_client_briefing` - per household percentile partition: `get_fa_mhh_records(agg_option=household)`, `get_product_target_narratives_with_layout`, `run_client_briefing_in_batch` (FAs grouped by FGA keys / explorer links / suppressions), feedback questions (`config/feedback_question_bank.yml`), `template_style_params.yml`, disclaimer | `si_nlg_fa_narratives_active_curr` | buffer `output_tbl_fa_cb_buffer` (si_nlg_fa_cb_buffer_v2_active), `output_tbl_fa_html` (si_nlg_fa_email_bullets_html_v2_active), `output_tbl_fa_html_curr`, `output_tbl_fa_unnest_html_curr`, `output_tbl_fa_email_mhh_status` | `nlg_generate_cb_emails` -> `output_tbl_client_briefing_weekly_emails` (si_nlg_client_briefing_weekly_email_v2_active), CB summary e-mails `output_tbl_fa_cb_summary_weekly_emails` |
| `FA_RETENTION_PACK` | retention_pack | `run_retention_pack_client_briefing` (households up to `max_mhh_assets`, enhanced insight html) | same | `output_tbl_retention_pack_cb_buffer`, `output_tbl_fa_retention_pack_cb`, `output_tbl_retention_pack_cb_curr` | `generate_cb_pack_for_fa` (files per FA) |
| `JSON_INSIGHTS` | json_insights | `run_insights_in_json` (3 parallel tasks; products FA_PORTAL / FA_PANELS / FA_INSIGHTS_EXPLORER layouts; `json_insight_as_key_val_pairs`) | same | `output_tbl_mhh_insights_in_json_buffer`, `output_tbl_mhh_insights_in_json` (si_nlg_household_insights_in_json_active), `output_tbl_mhh_insights_in_json_curr` | distribution DB `core_prj_insights_nlg.si_nlg_household_insights_in_json_active_curr` -> FA portal API / panels |
| `FA_ALERT` | fa_alerts | `run_fa_alert`: per FA (`agg_option=fa`), households with `mhh_assets_curr >= 250000`, `ALERT_MATERIALITY_THRESHOLD = 75`, split 15 households per e-mail (`FA_ALERTS_SPLIT_THRESHOLD`), suppression by `output_tbl_fa_alert_insight_history`, minor clients and Fisher-agreement households excluded, household ids encrypted (EVA API) | same | `output_tbl_fa_alert_template` (si_nlg_fa_alert_html_active), `_curr`, `output_tbl_fa_alert_status`, `output_tbl_fa_alert_insight_history` | `output_tbl_fa_alert_weekly_emails` (si_nlg_fa_alert_weekly_email_active), senders |
| `FA_SUBSCRIPTIONS` | fa_subscriptions | `run_fa_subscriptions` (`utils/product/fa_subscription`): insight types / households the FA subscribed to in the portal, max 3 households per insight type | same | `output_tbl_fa_subscriptions_template` (si_nlg_fa_subscriptions_html_active), `_curr`, `output_tbl_fa_subscriptions_status`, `output_tbl_fa_subscriptions_insight_history` | `output_tbl_fa_subscriptions_weekly_emails` |
| `BANKER_ALERTS` | banker_alerts | `run_banker_alerts`: layout groups with `banking_roles`, banker opt-out `bankers_opt_out_dict` | same | `output_tbl_banker_alerts_template` (si_nlg_banker_alerts_html_active), `_curr` | `output_tbl_banker_alerts_weekly_emails`, `nlg_send_banker_alert_emails` |
| `NO_EMAIL_INTERACTION` | fa_no_email_interaction | process insights (no e-mail interaction), 15 households max | same | `output_tbl_fa_no_email_interaction_template` (si_nlg_fa_no_email_interaction_html_active), `_curr` | senders |
| `FL_TALENT_REPORT` (monthly) / `FL_TALENT_REPORT_WEEKLY` | fl_talent_report | `run_fl_talent_report`: `get_fl_records`, `get_fl_branches`, `run_fl_talent_report_in_batch`, suppression by `output_tbl_fl_talent_report_insight_history` | `si_nlg_fl_narratives_active_curr` | `output_tbl_fl_talent_report` (si_nlg_fl_talent_report_active), `_curr` | `nlg_generate_fl_talent_report_emails`, `output_tbl_fl_talent_report_weekly_emails`, `nlg_send_fl_talent_emails` |
| `FA_MARKET_ALERT` / `FA_MARKET_ALERT_BANKING` | fa_market_alert(_banking) | `run_market_alert` / `run_market_alert_banking` (`MARKET_ALERTS_SPLIT_THRESHOLD = 15`) | `si_nlg_fa_ma_narratives_active_curr` | `output_tbl_market_alert` (si_nlg_market_event_html_active), `_curr`, `output_tbl_market_alert_banking` (si_nlg_market_event_banking_html_active), `_curr` | `output_tbl_market_alert_weekly_emails`, `output_tbl_market_alert_banking_weekly_emails`, `nlg_send_market_alert_emails` |
| `FA_PROSPECT_MAIL` | prospect_alert | `run_prospect_alert` (`MAX_PROSPECT_IN_ALERT = 22`, `PP_ALERTS_BATCH_MATERIALITY = 75`, FA via `ref_tbl_fa_prospect_map` = ikg_prospect_fa_mapping) | `si_nlg_fa_prospect_narratives_active_curr` | buffer `output_tbl_fa_prospect_buffer`, `output_tbl_fa_prospect_html` (si_nlg_fa_prospect_email_bullets_html_active), `_curr`, `output_tbl_pp_alert_status_prospect` (si_nlg_pp_alert_status_active), `output_tbl_pp_alert_insight_history` (si_nlg_pp_alert_insight_history_active) | `output_tbl_prospect_alert_weekly_emails`, `nlg_generate_prospect_alerts_emails` |
| `CLIENT_BRIEFING_SUMMARY` | (layout product) | `generate_fa_cb_summary_from_cb_list` - 1-3 bullets summary per FA | client briefing list | `output_tbl_fa_cb_summary_weekly_emails` | `nlg_send_cb_summary_emails` |

`PRODUCT_BULLET_CNT_THRESHOLD` (constants.py): CLIENT_BRIEFING_SUMMARY 1-3 bullets, FA_MEETING_MAIL min 3, all others min 1.
`MAX_HOUSEHOLDS_IN_PRODUCT`: FA_ALERT 15, FA_SUBSCRIPTIONS 15, NO_EMAIL_INTERACTION 15. `max_cnt_insight_groups_in_product`: wealthx_top_prospects 5, top_prospects 5, fl_recruit_top 4, fl_retention_top 4, fl_retention_top_loan 4.
Products read narratives through `get_product_target_narratives_with_layout(db, ini, product, pilot_only, product_target_id, fa_gpn, hh_percentile_idx, mhh_assets_threshold, product_target_id_name, insights_target_user_type)` which joins the `_curr` narratives table with `si_nlg_insight_layout` (product, materiality, suppression) and the FA / household maps (`si_pilot_fa_shp_map` + `si_pilot_fa_list` for pilot runs, `wac_households_ikg`).
Every product also notifies completion (`notify_nlg_completion`, `notify_nlg_fl_completion`, `notify_product_email_generation_ready`) and fills end times in the polling table (`set_nlg_products_end_time_in_polling_table`).

---

## 5. Insight layout (products, sections, groups, ranks)

`insight_group_layout/<category folder>/<group>.yml` (folders: Advisory, account_list, admin, banking, business_owner, cash_management, cash_movement, client_profile, fga, fl_insights, fl_ubs_client_insights, fl_ubs_fa_insights, goals, growth_opportunities, insurance_and_planning, interaction, life_events, market_event, market_event_bank_im, medallia, milestones, money_in_motion, my_total_picture, newsedge, opportunities, performance, philanthropy, portfolio_management, prospect, prospect_mls_blacknight, prospect_profile, prospect_speedeon, prospect_windfall, rmd_summary, speedeon, windfall).

One file = one **insight group**: `products` (FA_MEETING_MAIL, FA_PANELS, FA_PORTAL, CLIENT_BRIEFING_SUMMARY, FA_INSIGHTS_EXPLORER, FA_SUBSCRIPTIONS, FA_ALERT, BANKER_ALERTS, FL_TALENT_REPORT ...), `category`, `sub_category`, `display_category`, `display_subcategory`, `group_name_label`, `max_insights_in_group`, `max_insights_in_group_for_summary`, `product_material`, `show_category_title`, `is_evergreen_insight`, `insight_section`, `max_bullets_in_category`, `suppressed_by_insight_group`, `banking_roles`, `included_in_supervision`, `json_insight_as_key_val_pairs`, `group_footnote`, `category_remark`, and `insight_types:` with per insight type `group_material`, `order_in_group`, `target_type`, `show_subtitle`, `show_bullet_in_header`, `has_table_in_narratives`, `raw_html_in_header`, `materiality` (0-100), `suppression_weeks` per product, `insight_type_label`, `is_beta_insight`, `show_beta_till`, `is_fga_insight`, `is_table_insight`, `intro_section`, `attributions`, `is_active`.

`config/insight_layout_ranks.yml`: `SECTION_RANK` (Household Stats, Top Insights, Newsedge, Prospect Info Card, Recap of Milestones, Housekeeping Checklist, RMD Summary, Banking Summary, FGA Status, Estate Planning Status, WealthX Update, Business Owner Profile, Real Estate, Client Dossier, Household Performance, Client Prospects, Insights Supplement, ADVISORS WITH POTENTIAL TO MOVE, COMPATIBILITY RATING UPGRADES, NOTABLE MOVES, OTHER NOTABLE CHANGES, ATTRITION RISKS, CLIENT ATTRITION RISKS, MILESTONES, Market Event Bank IM Risk, Market Event, Market Event Breakdown) and `CATEGORY_RANK` (category -> ordered group names).

`pre_nlg_sync_insight_type_layout` (`utils/utils_nlg_run.sync_insight_type_layout_from_yml`) truncates and reloads two tables:
- `si_nlg_insight_group_and_rank` (ini `ref_tbl_insight_group_and_rank`): product, category, category_rank, insight_section, insight_section_rank, max_bullets_in_category, suppressed_by_insight_group, sub_category, display_category, display_subcategory, group_name, group_rank, max_insights_in_group, max_insights_in_group_for_summary, product_material, group_rank_global (section.category.group), is_evergreen_insight, show_category_title, group_footnote, category_remark, sub_category_remark, group_name_label, category_material, category_max_materiality, included_in_supervision, json_insight_as_key_val_pairs, banking_roles, order_group_bullets_on_metric_val, group_name_header, show_sub_category_title.
- `si_nlg_insight_layout` (ini `ref_tbl_insight_layout`): product, insight_type, group_name, group_material, target_type, order_in_group, show_subtitle, show_bullet_in_header, has_table_in_narratives, raw_html_in_header, materiality, suppression_weeks, rows_in_table_header, header_font_size_small, included_in_supervision, intro_section, attributions, insight_type_label, is_beta_insight, show_beta_till, is_fga_insight, is_table_insight.
- Changes are logged to `si_nlg_insight_layout_change_log_active` (`ref_tbl_insight_change_log`) and history `si_nlg_insight_layout_history` (`ref_tbl_insight_layout_history`); `sync_insight_type_update_to_yml` writes UI edits back.

Materiality rules: an insight is shown when `materiality >= ALERT_MATERIALITY_THRESHOLD` (75) for alerts; `suppression_weeks` suppresses a repeated insight for the household for N weeks per product (history tables `*_insight_history_active`).

---

## 6. Key tables (nlg_db_tables.ini, section [prod_active])

Schema in prod: `core_nlg` unless stated; `core_ikg` tables are IKG-owned.

### 6.1 ODM / IKG inputs (core_ikg)
- `odm_insights_tbl = si_odm_insights_active` - ODM hits (insight_type, target_type, target_key, metric_name, metric_type, metric_val, run_id ...).
- `input_tbl_<target_type> = <x>_profile_curr_ikg` - the IKG profile read for each target type (e.g. input_tbl_client = client_profile_curr_ikg, input_tbl_household = household_profile_curr_ikg, input_tbl_account_sbl = account_sbl_profile_curr_ikg, input_tbl_client_ext_acc = mtp_profile_curr_ikg, input_tbl_household_recipient = household_wire_transaction_profile_curr_ikg, input_tbl_wma_profile = wma_profile_cur_ikg, input_tbl_asset_class_benchmark_ytd ...). These are documented as IKG profile tables (not re-described by NLG metadata).
- `ref_ikg_odm_nlg_polling_tbl = ikg_run_status`, `ref_ikg_odm_prospect_nlg_polling_tbl = prospect_ikg_run_status` - run status / polling: ikg_run_start_time, ikg_run_end_time, odm_run_start_time, odm_run_end_time, nlg_run_start_time, nlg_run_end_time, nlg_products_end_time; NLG polls `odm_run_end_time` (every 10 minutes, up to 20 hours) and sets its own start / end times.
- FA / household maps (`schema_fa_ta_mhh_map = core_ikg`): `ref_tbl_pilot_fa_mhh_map = si_pilot_fa_shp_map` (fa_gpn x household; `mhh_id_col_name_in_fa_mhh_map = household_plus`), `ref_tbl_pilot_ta_mhh_map = si_pilot_ta_shp_map`, `ref_tbl_pilot_all_mhh_map = si_pilot_rel_shp_map`, `ref_tbl_fa_prospect_map = ikg_prospect_fa_mapping` (schema_fa_ta_prospect_map), `ref_tbl_fga_entitlement = fga_fa_entitlements_ikg`, `minor_cli_exclude_household_ids = exclude_all_minor_households_ikg`, `wac_households_ikg` (WAC households always included), `ref_tbl_fl_info_tbl = fl_to_wire_code_ikg`, `ref_tbl_fl_role_tbl = fl_individual_role_ikg`.

### 6.2 Reference tables (core_nlg)
- `ref_tbl_fa_pilot_list = si_pilot_fa_list` (pilot FAs), `ref_tbl_fa_opt_out = si_pilot_fa_opt_out` (FAs opted out of e-mails), `ref_tbl_fa_ta_map = si_pilot_fa_ta_map` (FA -> team assistants: ta_gpns / ta_emails), `ref_tbl_fa_banner_pilot_list = si_pilot_banner_fa_list`.
- `ref_tbl_insight_layout = si_nlg_insight_layout`, `ref_tbl_insight_group_and_rank = si_nlg_insight_group_and_rank`, `ref_tbl_insight_change_log = si_nlg_insight_layout_change_log_active`, `ref_tbl_insight_layout_history = si_nlg_insight_layout_history` (section 5).
- `ref_tbl_household_id_encryption = si_nlg_household_id_encryption_active` - acc_mhh_n -> encrypted id used in portal deep links (EVA encryption API, `pre_nlg_encrypt_household_id_in_batch`).
- `ref_tbl_fa_client_calendar_event = si_fa_calendar_client_map` - FA calendar events matched to clients (calendar entity matching DAG) -> briefings for upcoming meetings.
- `ref_tbl_fl_exclusion = fl_talent_report_exclusion_list` - FLs excluded from the talent report.
- `fa_insight_preference_tbl = user_preferences_extract_test` in schema `fa_insight_preference_tbl_schema = sandbox_prj_insights_nlg` (prod_active; the dev sections use `user_preferences_extract` in `sandbox_wma_shared`) - FA insight preferences / suppressions from the portal API (`get_insight_list_to_filter_out_from_api`); `nlg_portal_customization_history = si_portal_customization_applied_active` - history of the portal customisations applied.
- `nlg_ui_user_tbl = si_nlg_ui_users` - users of the NLG review UI; `nlg_portal_customization_history`.
- `si_nlg_household_percentile_range` - hh_percentile_idx, min_hh_id, max_hh_id (partitioning of households for parallel product generation); `si_nlg_dummy_client_cid_info` - dummy households (non-prod).

### 6.3 Narratives (core_nlg)
- `output_tbl_narratives_buffer_base = si_nlg_fa_narr_bfr_base` - template for the per-run CSV buffer tables.
- `output_tbl_narratives_fa = si_nlg_fa_narratives_active` (all runs), `output_tbl_narratives_curr_fa = si_nlg_fa_narratives_active_curr` (latest run + `hh_percentile_idx`), `output_tbl_narratives_odm_free_fa = si_nlg_fa_narratives_odm_free_active` (rules that do not need an ODM hit, `insight_type_from_odm = 0`), `output_tbl_narratives_fl = si_nlg_fl_narratives_active` / `_curr`, `output_tbl_narratives_fa_ma = si_nlg_fa_ma_narratives_active` / `_curr` (market alerts), prospects `output_tbl_narratives_fa_prospect = si_nlg_fa_prospect_narratives_active` / `_curr` / odm_free, `output_tbl_narratives_buffer_base_prospect`.
- Columns (from `transform_narrative_entry`): global_key (`<target_key>_<insight_type>_<time_created>`), target_key (ODM target key as text), key_name (`ip_cli_i` / `acc_mhh_n` / `acc_i` - name of the key), target_id (household id the narrative is shown for), target_entity_id_name, target_entity_ids (array of entity ids grouped into the narrative), acc_mhh_n (statement household) / main_prospect_id (prospects), target_type, insight_type, narrative_raw (HTML bullet text with `<bullet-delimiter>` / `<sub-bullet-delimiter>` / `<primary-bullet-header-delimiter>` / `<primary-bullet-footer-delimiter>` markers), narrative_raw_compound, narrative_raw_compound_first, narrative_title, narrative_title_plain, narrative_title_summary, narrative_combined, narrative_combined_first, profile_date (IKG profile date minus 3 days in several mappings), time_created (run start), week_start_date (Monday of the run week), metric_name, metric_type, metric_val (from ODM), attached_insight_types (array), account_ids (account-level target types), included_clients (client names in the narrative), target_keys / target_keys_sorted (keys of all grouped rows), fga_keys (FGA plan keys), insight_date, hh_percentile_idx (curr table only).

### 6.4 Product output tables (core_nlg)
- Client briefing: `output_tbl_fa_cb_buffer = si_nlg_fa_cb_buffer_v2_active`, `output_tbl_fa_html = si_nlg_fa_email_bullets_html_v2_active`, `output_tbl_fa_html_curr = ..._curr`, `output_tbl_fa_unnest_html_curr = si_nlg_fa_unnest_html_active_curr` (one row per FA x household x insight bullet), `output_tbl_fa_email_mhh_status = si_nlg_fa_email_mhh_status_active` (sent / approved status per household), retention pack `si_nlg_hh_retention_pack_cb_buffer_active` / `si_nlg_hh_retention_pack_cb_active` / `_curr` / `si_nlg_hh_retention_pack_cb_enhanced_active_curr`. Columns of a briefing row: acc_mhh_n, fa_gpns / fa_first_names / fa_last_names / fa_emails / fa_i_list (FAs receiving it), ta_gpns / ta_emails (team assistants), receive_email_list, is_fa_list, pilot_list, acc_ttl1_x (household title), ip_frst_x / ip_last_x (lead client), subject_line, key_line, info_line, insight_html, hh_percentile_idx, raw_narratives_time_created, time_created, week_start_date.
- FA alerts: `si_nlg_fa_alert_html_active` / `_curr` (global_key, fa_gpn, fa_i, fa_email, fa_first_name, fa_last_name, ta_*, acc_mhh_n, target_key(s), insight_type(s), insight_types_unique, households, insight_html, subject_line, key_line, info_line, intro_section, is_fa_opt_out, fa_alerts_batch_idx, supervision_* (compliance supervision copies), campaign_date, date_sent, product_time_created, raw_narratives_time_created, time_created, week_start_date), `si_nlg_fa_alert_status_active`, `si_nlg_fa_alert_insight_history_active` (insight sent dates for suppression).
- Subscriptions: `si_nlg_fa_subscriptions_html_active` / `_curr`, `si_nlg_fa_subscriptions_status_active`, `si_nlg_fa_subscriptions_insight_history_active`.
- Banker alerts: `si_nlg_banker_alerts_html_active` / `_curr`. No e-mail interaction: `si_nlg_fa_no_email_interaction_html_active` / `_curr`.
- FL talent report: `si_nlg_fl_talent_report_active` / `_curr` (fl_gpn, report html, branches), `si_nlg_fl_talent_report_insight_history_active`.
- Market alerts: `si_nlg_market_event_html_active` / `_curr`, `si_nlg_market_event_banking_html_active` / `_curr`.
- Prospect alerts: `si_nlg_fa_prospect_buffer_active`, `si_nlg_fa_prospect_email_bullets_html_active` / `_curr`, `si_nlg_pp_alert_status_active`, `si_nlg_pp_alert_insight_history_active`.
- JSON insights: `si_nlg_household_insights_in_json_buffer_active`, `si_nlg_household_insights_in_json_active`, `_curr`, `si_nlg_test_household_insights_in_json_active` (prod test users) - one JSON document per household (insights grouped by section / category / group, key-value pairs for panels).
- Weekly e-mail status (one row per e-mail): `si_nlg_client_briefing_weekly_email_v2_active`, `si_nlg_client_briefing_summary_weekly_email_v2_active`, `si_nlg_fa_alert_weekly_email_active`, `si_nlg_fa_subscriptions_weekly_email_active`, `si_nlg_fl_talent_report_weekly_email_active`, `si_nlg_banker_alerts_weekly_email_active`, `si_nlg_market_alert_weekly_email_active`, `si_nlg_market_alert_banking_weekly_email_active`, `si_nlg_prospect_alert_weekly_email_active` - recipient, subject, html body, campaign_date, time_sent / date_sent (set by the e-mail sender; `pre_nlg_update_time_sent_for_prev_week` closes the previous week), resend flags.
- Misc outputs: `output_tbl_mhh_all_accts = mhh_all_accts_ikg`, `output_tbl_fa_map_oppo_exp = fa_map_oppo_exp_ikg` (FA x opportunity explorer links, camp ids `EM-CBE-FA-<date>-ITL` / `EM-ALE-FA-...`), `output_tbl_client_demographic_data = client_demographic_data_ikg`, `output_tbl_client_email_metadata_ikg = client_email_metadata_ikg`.

### 6.5 Operations (core_nlg)
- `nlg_run_history = si_nlg_run_history_active` (week_start_date, raw_narrative_time_start, raw_narrative_time_end, time_created), `nlg_prospect_run_history = si_nlg_prospect_run_history_active`.
- `nlg_run_error_log = si_nlg_run_error_log_active` (week_start_date, raw_narrative_time_start, insight_type, target_type, nlg_stage [raw_narrative_generation | client_briefing_generation | fa_alert_generation | fl_talent_report_generation ...], error_log), `nlg_automation_error_log = si_nlg_automation_error_log_active` (e-mail automation errors).

---

## 7. Glossary (column-name tokens)

- acc_mhh_n = statement household identifier (household_plus) - the key of all FA products
- main_prospect_id = prospect identifier (prospect narratives / alerts)
- ip_cli_i = client identifier; ip_frst_x / ip_last_x = client first / last name; ip_dob_d = date of birth
- acc_i = account identifier; acc_ttl1_x = account / household title line 1
- fa_gpn = Financial Advisor GPN (global personnel number); fa_i = FA identifier; ta_gpn = team assistant GPN; fl_gpn = Field Leader GPN; rep_crd = FINRA CRD number of a representative (FL recruitment)
- cb = client briefing; cb summary = client briefing summary e-mail; pa / pp = prospect alert / prospect; fl = field leader; fa_ma = FA market alert; ma = market alert
- hh = household; mhh = (marketing) household measures in IKG, keyed by acc_mhh_n; shp = statement household plus (si_pilot_fa_shp_map = FA to household map); hh_percentile_idx = household id percentile partition (si_nlg_household_percentile_range)
- odm_free = narratives produced without an ODM hit (insight_type_from_odm = 0)
- bfr = buffer; narr = narratives; tmpl / template = product html table; curr = latest run; active = all runs of the active environment
- week_start_date = Monday of the run week; time_created = run start timestamp (NLG start time from the polling table); raw_narratives_time_created = time_created of the narratives used by a product; product_time_created = product generation start
- materiality = 0-100 importance of an insight (layout); suppression_weeks = weeks an insight is not repeated per product; group_material / product_material = whether the group / product counts towards materiality
- insight_section / category / sub_category / group_name = layout hierarchy; group_rank_global = numeric rank section.category.group
- is_fa_opt_out = FA in si_pilot_fa_opt_out; pilot_only = restrict to pilot FAs (si_pilot_fa_list); wac = Wealth Advice Center households (wac_households_ikg)
- fga = Financial Goal Analysis (plan keys fga_keys, fga_mgpinvestorkey); rmd = required minimum distribution; sbl = securities-based lending; mtp = My Total Picture (Yodlee aggregated accounts); art = account review tool (household_art); npo = non-profit organisation donations; epas = estate planning; ols = online services login; pkr = periodic KYC (know-your-client) review that is due for a risk-rated client (rules si_client_pkr_due / _overdue / _active; confirm wording with SME); mls = Black Knight MLS listings; znfo = ZoomInfo; wx = Wealth-X
- EVA = internal API used for household id encryption (AirflowSPNId / AirflowSPNSecret); SmartEmailClass = e-mail sending (Adobe Campaign config `config/adobe_campaign_config.ini`)

---

## 8. Example queries and operational notes

```sql
-- narratives of a household in the latest run
select insight_type, narrative_title, narrative_raw, metric_name, metric_val, included_clients
from core_nlg.si_nlg_fa_narratives_active_curr
where acc_mhh_n = '<household id>' order by insight_type;

-- client briefings generated for an FA this week
select acc_mhh_n, subject_line, key_line, week_start_date, time_created
from core_nlg.si_nlg_fa_email_bullets_html_v2_active_curr
where '<fa gpn>' = any(fa_gpns);

-- layout of one insight type
select l.product, g.insight_section, g.category, l.group_name, l.materiality, l.suppression_weeks, l.order_in_group
from core_nlg.si_nlg_insight_layout l
join core_nlg.si_nlg_insight_group_and_rank g on g.product = l.product and g.group_name = l.group_name
where l.insight_type = 'si_client_birthday';

-- run history and errors of the current week
select * from core_nlg.si_nlg_run_history_active order by time_created desc limit 5;
select insight_type, target_type, nlg_stage, left(error_log, 200)
from core_nlg.si_nlg_run_error_log_active where week_start_date = date_trunc('week', current_date);

-- ODM hits that have an NLG rule file (join on insight_type) for a target type
select a.insight_type, count(*) from core_ikg.si_odm_insights_active a where a.target_type = 'client' group by 1 order by 2 desc;
```

Operational notes:
- The rules stage can be run locally: `python nlg_main.py --target_type client --insight_types si_client_birthday --odm_env review --code_env dev --save_to_db 0` (credentials from `~/.secure/si_nlg_credentials.properties`).
- Non-prod environments inject dummy households (`si_nlg_dummy_client_cid_info`) and anonymise FA / household maps (`pre_nlg_sync_fa_ta_mhh_map_tabl_anonymize_for_dummy`).
- `post_nlg_check_broken_links` validates URLs in narratives (`get_all_links_in_rule_narrative`).
- Supervision: insight groups / types flagged `included_in_supervision` are copied into supervision columns of the alert rows and summarised by `generate_supervision_logs` (e-mail to the supervision mailbox).
- Distribution DB `core_prj_insights_nlg` keeps a timestamped backup copy of every synced table (`<table>_<yyyymmdd_hhmmss>`) before replacing it.
