"""Build report by e-mail (email.* in the config). Attaches pack.md, manifest.json, health.json always and the pack zip when
it is smaller than attach_zip_max_mb. SMTP password (only when smtp_user is set) comes from the secret store, never from the config."""
from __future__ import annotations

import json
import logging
import smtplib
from email.message import EmailMessage
from pathlib import Path
from typing import List, Optional

from .config import secret

log = logging.getLogger("kpack.mailer")


def report_text(results: List[dict]) -> str:
    L = ["Knowledge Pack build report", ""]
    for r in results:
        m, h = r.get("manifest") or {}, r.get("health") or {}
        if r.get("error"):
            L.append(f"[{r.get('system', '?')}] FAILED: {r['error']}")
            continue
        c = m.get("counts", {})
        L.append(f"[{m.get('system')}] version {m.get('version')} - {h.get('status')} - {h.get('total_seconds')}s - {Path(m.get('zip', '')).name} {m.get('zip_mb')} MB"
                 + ("" if m.get("promoted", True) else "  ** NOT promoted: previous good pack kept **"))
        L.append(f"   repo {m.get('repo', {}).get('project')} @ {m.get('repo', {}).get('ref')}: {m.get('repo', {}).get('files')} files, "
                 f"{c.get('dag_files')} DAG files, {c.get('folders')} folders, {c.get('companion_patterns')} companion patterns")
        L.append(f"   tables: {c.get('tables_listed')} listed / {c.get('tables_described')} described; skills: {c.get('skills_documents')} docs -> "
                 f"{c.get('definitions')} definitions, {c.get('conventions')} conventions, {c.get('rules')} rules; {c.get('items')} items indexed")
        d = m.get("diff", {})
        if d.get("previous_version"):
            L.append(f"   since {d['previous_version']}: +{len(d.get('added_files', []))} / ~{len(d.get('changed_files', []))} / -{len(d.get('removed_files', []))} files, "
                     f"tables +{len(d.get('added_tables', []))} -{len(d.get('removed_tables', []))}, skills changed {len(d.get('changed_skills', []))}")
        cost = (m.get("cost") or {}).get("cost") or {}
        if cost:
            L.append(f"   model cost: {json.dumps(cost, default=str)[:200]}")
        for w in h.get("warnings", [])[:15]:
            L.append(f"   ! {w}")
        L.append(f"   folder: {r.get('path')}")
        L.append("")
    return "\n".join(L)


def _changed(diff: dict) -> bool:
    if not diff.get("previous_version"):
        return True
    return any(diff.get(k) for k in ("added_files", "removed_files", "changed_files", "added_tables", "removed_tables", "changed_skills"))


def send_report(cfg, results: List[dict], dry_run: bool = False) -> dict:
    e = cfg.get("email") or {}
    if not e.get("enabled"):
        return {"sent": False, "reason": "email disabled"}
    failed = any(r.get("error") or (r.get("health") or {}).get("status") != "ok" for r in results)
    if failed and not e.get("send_on_failure", True) and all(r.get("error") for r in results):
        return {"sent": False, "reason": "all builds failed and send_on_failure is false"}
    if e.get("only_on_change") and not failed:
        changed = [r for r in results if _changed((r.get("manifest") or {}).get("diff") or {})]
        if not changed:
            return {"sent": False, "reason": "only_on_change: no pack changed and all builds ok"}
    status = "FAILED" if any(r.get("error") for r in results) else ("DEGRADED" if failed else "OK")
    systems = ", ".join(r.get("system") or (r.get("manifest") or {}).get("system", "?") for r in results)
    versions = ", ".join((r.get("manifest") or {}).get("version", "-") for r in results)
    msg = EmailMessage()
    msg["Subject"] = str(e.get("subject", "[Knowledge Pack] {system} {version} - {status}")).format(system=systems, version=versions, status=status)
    msg["From"] = e.get("from", "")
    msg["To"] = ", ".join(e.get("to") or [])
    if e.get("cc"):
        msg["Cc"] = ", ".join(e["cc"])
    msg.set_content(report_text(results))
    max_mb = float(e.get("attach_zip_max_mb", 20))
    for r in results:
        p = Path(r.get("path") or "")
        if not p.is_dir():
            continue
        for name in ("pack.md", "manifest.json", "health.json"):
            f = p / name
            if f.exists():
                msg.add_attachment(f.read_bytes(), maintype="text", subtype="plain", filename=f"{r.get('system')}_{name}")
        z = Path(r.get("zip") or "")
        if z.exists() and z.stat().st_size <= max_mb * 1048576:
            msg.add_attachment(z.read_bytes(), maintype="application", subtype="zip", filename=z.name)
    if dry_run:
        return {"sent": False, "reason": "dry run", "subject": msg["Subject"], "to": msg["To"], "attachments": [a.get_filename() for a in msg.iter_attachments()]}
    recipients = list(e.get("to") or []) + list(e.get("cc") or [])
    try:
        with smtplib.SMTP(e.get("smtp_host", "localhost"), int(e.get("smtp_port", 25)), timeout=60) as s:
            if e.get("starttls"):
                s.starttls()
            if e.get("smtp_user"):
                s.login(e["smtp_user"], secret(cfg, "email_password", allow_prompt=False))
            s.send_message(msg, from_addr=e.get("from"), to_addrs=recipients)
        log.info("report sent to %s", recipients)
        return {"sent": True, "subject": msg["Subject"], "to": recipients}
    except Exception as ex:  # noqa: BLE001
        log.warning("e-mail failed: %s", ex)
        return {"sent": False, "reason": f"{type(ex).__name__}: {str(ex)[:200]}", "subject": msg["Subject"]}
