"""Offline self-test: a tiny sample repository + a sqlite file playing Greenplum -> a full pack build without any secret,
then a few consumer queries. `python app_kpack.py selftest`."""
from __future__ import annotations

import copy
import json
import sqlite3
import tempfile
from pathlib import Path

SAMPLE_TABLES = {
    "ikg_profile_table_descriptions": (["schema_name", "table_name", "table_description", "refresh_frequency"],
                                       [("core_ikg", "ikg_client_profile", "one row per client with household, advisor and asset attributes", "daily"),
                                        ("core_ikg", "ikg_account_profile", "one row per account with balances and product flags", "daily"),
                                        ("core_ikg", "ikg_advisor_profile", "one row per financial advisor", "weekly")]),
    "ikg_attribute_business_description": (["table_name", "column_name", "business_description", "data_type"],
                                           [("ikg_client_profile", "client_id", "unique client identifier", "varchar"),
                                            ("ikg_client_profile", "hh_id", "household identifier", "varchar"),
                                            ("ikg_client_profile", "total_assets", "total assets under management in USD", "numeric")]),
    "ikg_metadata_glossary_llm": (["term", "definition", "related_tables"],
                                  [("household", "a group of clients sharing finances, identified by hh_id", "ikg_client_profile"),
                                   ("AUM", "assets under management", "ikg_account_profile")]),
    "ikg_column_lineage_master_auto_refresh": (["source_table", "source_column", "target_table", "target_column", "script"],
                                               [("ikg_client_profile", "client_id", "si_client_recency", "client_id", "client_recency.sql")]),
    "ikg_graph_relationship": (["from_table", "to_table", "relationship"], [("ikg_client_profile", "ikg_account_profile", "one-to-many")]),
    "ikg_graph_joining_key": (["table_a", "table_b", "key"], [("ikg_client_profile", "ikg_account_profile", "client_id")]),
    "insights_dashboard_details": (["dashboard", "insight", "owner"], [("FA Daily", "si_bknight_mls_property_off_market", "STAAT")]),
    "odm_rule_metadata_auto_refresh": (["rule_id", "insight_type", "rule_logic", "target_table"],
                                       [("R1", "si_bknight_mls_property_off_market", "property listing removed within 30 days", "si_bknight_mls_property_off_market"),
                                        ("R2", "si_client_recency", "no contact in 90 days", "si_client_recency")]),
}


def make_sample_sqlite(path: Path) -> Path:
    con = sqlite3.connect(str(path))
    for t, (cols, rows) in SAMPLE_TABLES.items():
        con.execute(f'drop table if exists "{t}"')
        con.execute(f'create table "{t}" ({", ".join(c + " TEXT" for c in cols)})')
        con.executemany(f'insert into "{t}" values ({", ".join("?" for _ in cols)})', rows)
    con.commit(); con.close()
    return path


def make_sample_repo(root: Path) -> Path:
    files = {
        "dags/sample/sample_dag.py": '''"""Sample DAG: registers every SQL file under script/sql as a task (folder = task group)."""
import os
from airflow import DAG
from airflow.models import Variable
from airflow.utils.task_group import TaskGroup
from sample.script.python.props import SCHEMA
SQL_ROOT = "/opt/airflow/dags/sample/script/sql"

def build_sql_taskgroups_recursive(dag, root):
    for folder in sorted(os.listdir(root)):
        with TaskGroup(group_id=folder):
            for f in sorted(os.listdir(os.path.join(root, folder))):
                if f.endswith(".sql"):
                    task_id = f[:-4]
with DAG(dag_id="sample_daily", schedule="0 6 * * *") as dag:
    build_sql_taskgroups_recursive(dag, SQL_ROOT)
''',
        "dags/sample/script/python/props.py": 'SCHEMA = "core_ikg"\nPROFILE_DATE = "{{ ds }}"\n',
        "dags/sample/script/sql/client_insights/client_recency_curr_ikg.sql": "-- client recency: days since last contact per client\ncreate table {IKG_SCHEMA}.si_client_recency as\nselect client_id, hh_id, max(contact_date) last_contact from {IKG_SCHEMA}.ikg_client_profile p join {IKG_SCHEMA}.ikg_account_profile a on a.client_id = p.client_id group by 1,2\ndistributed by (client_id);\n",
        "dags/sample/script/sql/client_insights/client_assets_curr_ikg.sql": "-- client assets snapshot\ncreate table {IKG_SCHEMA}.si_client_assets as\nselect client_id, sum(total_assets) aum from {IKG_SCHEMA}.ikg_client_profile group by 1\ndistributed by (client_id);\n",
        "dags/sample/script/sql/client_insights_history/client_recency_ikg.sql": "-- history of client recency\ninsert into {IKG_SCHEMA}.si_client_recency_hist select *, current_date from {IKG_SCHEMA}.si_client_recency;\n",
        "dags/sample/script/sql/client_insights_history/client_assets_ikg.sql": "-- history of client assets\ninsert into {IKG_SCHEMA}.si_client_assets_hist select *, current_date from {IKG_SCHEMA}.si_client_assets;\n",
        "dags/sample/script/sql/validations/client_recency_validations.sql": "-- validation: no null client ids\nselect count(*) from {IKG_SCHEMA}.si_client_recency where client_id is null;\n",
        "dags/sample/script/sql/validations/client_assets_validations.sql": "-- validation: aum not negative\nselect count(*) from {IKG_SCHEMA}.si_client_assets where aum < 0;\n",
        "README.md": "# sample-dags\nSample repository for the knowledge pack self-test.\n",
    }
    for rel, txt in files.items():
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(txt, encoding="utf-8")
    return root


def selftest_config(base_cfg, tmp: Path):
    from agiledev.config import Config
    cfg = Config(copy.deepcopy(dict(base_cfg)))
    cfg["systems"] = {"sample": {"gitlab_url": "https://example.invalid", "project_path": "x/sample-dags", "branch": "", "subpath": "", "repo_name": "sample-dags",
                                 "schema": "core_ikg", "skills_folder": str(tmp / "skills"), "gp_folder": str(tmp / "gp")}}
    cfg["common_skills_folder"] = str(tmp / "skills_common")
    cfg["build"] = dict(cfg["build"], output_dir=str(tmp / "output"), embeddings=False, derived_layer=False, metadata_tables=["core_ikg.ikg_metadata_glossary_llm"])
    cfg["greenplum"] = dict(cfg["greenplum"], sqlite_path=str(make_sample_sqlite(tmp / "gp.sqlite")))
    cfg["email"] = dict(cfg["email"], enabled=False)
    cfg["storage"] = {"data_dir": str(tmp / "data"), "llm_cache_dir": str(tmp / "data/cache/llm"), "repo_cache_dir": str(tmp / "data/cache/repos")}
    (tmp / "skills").mkdir(exist_ok=True); (tmp / "skills_common").mkdir(exist_ok=True); (tmp / "gp").mkdir(exist_ok=True)
    (tmp / "skills" / "sample_standards.md").write_text("# Standards\n\n## Naming\nInsight tables start with si_.\n\n## History\nEvery *_curr_ikg.sql script needs a *_ikg.sql history script.\n", encoding="utf-8")
    (tmp / "gp" / "gp.md").write_text("| table | description |\n|---|---|\n| core_ikg.ikg_profile_table_descriptions | table descriptions |\n| core_ikg.odm_rule_metadata_auto_refresh | rules |\n| core_ikg.missing_table | does not exist |\n", encoding="utf-8")
    return cfg


class FakeLLM:
    """Stands in for Azure OpenAI in the self-test: deterministic JSON answers and hash-based embeddings."""

    def __init__(self):
        self.hits = 0
        self._cache = {}

    def json_call(self, system, user, reasoning_effort=None):
        if "KNOWLEDGE PACK" in system:
            return {"definitions": [{"term": "si_", "definition": "insight table prefix", "source": "sample_standards.md"}],
                    "conventions": [{"rule": "every *_curr_ikg.sql needs a *_ikg.sql history script", "applies_to": "client_insights", "source": "sample_standards.md"}],
                    "rules": [{"id": "si_prefix", "pattern": "create table .*\\.si_", "must_match": True, "severity": "high", "message": "insight tables start with si_", "languages": ["sql"], "applies_to": [], "exempt": []},
                              {"id": "broken", "pattern": "(", "must_match": True, "severity": "low", "message": "dropped by rules_sanity", "languages": ["sql"], "applies_to": [], "exempt": []}],
                    "notes_for_coder": ["use {IKG_SCHEMA}"]}
        if "code repository" in system:
            return {"system_summary": "Sample system (scripted).", "folders": {"dags/sample/script/sql/client_insights": {"purpose": "insight builders", "how_to_add": "add a sql file", "watch_out": ""}},
                    "how_to": [{"task": "add an insight", "steps": ["create x_curr_ikg.sql", "create x_ikg.sql", "create x_validations.sql"]}], "glossary": [{"term": "IKG", "meaning": "insights knowledge graph"}]}
        if "Greenplum tables" in system:
            return {"tables": {"core_ikg.odm_rule_metadata_auto_refresh": {"purpose": "rule catalogue", "grain": "one row per rule", "key_columns": ["rule_id"], "column_notes": {}, "used_for": "insights"}}}
        return {"bridge": [{"term": "recency", "synonyms": ["last contact"], "tables": ["si_client_recency"], "columns": ["last_contact"], "scripts_or_folders": ["client_insights"], "note": ""}]}

    def embed(self, texts, s):
        import re
        out = []
        for t in texts:                       # bag of hashed words: similar texts get similar vectors
            v = [0.0] * 64
            for w in re.findall(r"[a-z0-9_]+", t.lower()):
                v[hash(w) % 64 if False else sum(map(ord, w)) % 64] += 1.0
            out.append(v)
        return out

    def hash(self, *parts):
        import hashlib
        return hashlib.sha256("|".join(map(str, parts)).encode()).hexdigest()[:24]

    def cache_get(self, key):
        return self._cache.get(key)

    def cache_put(self, key, value):
        self._cache[key] = value

    def count_cache_hit(self):
        self.hits += 1

    def set_process(self, name):
        pass

    def token_stats(self):
        return {"cost": {"total": 0.0}, "calls": 0}


def run_selftest(say=print) -> bool:
    from .builder import PackBuilder
    from .config import load_config
    from .mailer import send_report
    from .pack import Pack
    tmp = Path(tempfile.mkdtemp(prefix="kpack_selftest_"))
    cfg = selftest_config(load_config(), tmp)
    repo = make_sample_repo(tmp / "repo")
    b = PackBuilder(cfg, "sample", progress=say, repo_path=str(repo), use_llm=False)
    r = b.build()
    m = r["manifest"]
    ok = True

    def check(cond, msg):
        nonlocal ok
        say(("  ok   " if cond else "  FAIL ") + msg)
        ok = ok and bool(cond)

    check(m["counts"]["dag_files"] == 1, "DAG detected")
    reg = json.loads((Path(r["path"]) / "facts/structure.json").read_text())["registration"]
    check(reg["dags/sample/script/sql/client_insights"]["rule"].startswith("AUTOMATIC"), "dynamic registration rule found for client_insights")
    check(m["counts"]["tables_described"] == 2, f"2 tables described from sqlite (got {m['counts']['tables_described']})")
    check(any("missing_table" in w for w in r["health"]["warnings"]), "missing table reported in health")
    check(m["counts"]["companion_patterns"] >= 1, f"companion patterns learnt ({m['counts']['companion_patterns']})")
    check(m["metadata_tables"].get("core_ikg.ikg_metadata_glossary_llm", {}).get("rows") == 2, "metadata table copied into store.sqlite")
    check((Path(r["path"]) / "index/bm25.pkl").exists(), "BM25 index written")
    check((Path(r["path"]) / "pack.md").exists() and (Path(r["path"]) / "raw/repo/README.md").exists(), "pack.md and raw repo copy written")
    p = Pack(r["path"])
    hits = p.search("client recency history script", k=5)
    check(hits and any("client_recency" in h["ref"] for h in hits), f"search works ({[h['ref'] for h in hits[:3]]})")
    comp = p.companions("dags/sample/script/sql/client_insights/client_recency_curr_ikg.sql")
    check(any(c["expected"] == "client_recency_ikg" for c in comp), f"companion expected name ({[c['expected'] for c in comp]})")
    check(p.table("core_ikg.odm_rule_metadata_auto_refresh").get("columns"), "table lookup")
    check(any(h["kind"] == "chunk" for h in p.search("insert into si_client_recency_hist", k=6)), "code chunks indexed with contextual headers")
    check("Registration of a new script" in p.card("folder", "dags/sample/script/sql/client_insights"), "folder card rendered")
    imp = p.impact("{ikg_schema}.si_client_recency")
    check(any("client_recency_ikg" in r for r in imp["read_by"]) and any("si_client_recency_hist" in d for d in imp["downstream_tables"]), f"graph impact analysis ({imp['read_by']}, {imp['downstream_tables']})")
    check(p.exemplar("dags/sample/script/sql/client_insights").get("file", "").endswith(".sql"), "exemplar per folder")
    check(len(p.context("client recency history")) > 200, "prompt-ready context block")
    mail = send_report(dict(cfg, email=dict(cfg["email"], enabled=True)), [dict(r, system="sample")], dry_run=True)
    check(mail.get("attachments") and "sample_pack.md" in mail["attachments"] and "sample_pack.zip" in mail["attachments"], f"e-mail composed ({mail.get('subject')}, {mail.get('attachments')})")
    zp = Path(r["zip"])
    check(zp.name == "sample_pack.zip" and r.get("promoted"), "one deliverable zip sample_pack.zip, promoted")
    pz = Pack(zp)
    check(pz.version == m["version"] and (pz.dir / "VERSION.txt").exists() and (pz.dir / "build_config.yaml").exists(), "pack opens from the zip alone (VERSION.txt, build_config.yaml)")
    # second build with a scripted model -> derived layer + dense index code paths, and the diff against the first build
    cfg2 = copy.deepcopy(cfg); cfg2["build"]["embeddings"] = True; cfg2["build"]["derived_layer"] = True
    r2 = PackBuilder(cfg2, "sample", progress=lambda m: None, repo_path=str(repo), use_llm=True, llm=FakeLLM()).build()
    check(r2["manifest"]["diff"]["previous_version"] == m["version"], "second build diffs against the first")
    check(r2["manifest"]["model_layer"] and r2["manifest"]["counts"]["conventions"] == 1, "derived layer stored (scripted model)")
    st = json.loads((Path(r2["path"]) / "index/status.json").read_text())
    check(st.get("dense") and st.get("items", 0) > 20, f"dense index built with the scripted embeddings ({st.get('items')} items)")
    p2 = Pack(r2["path"], llm=FakeLLM(), emb_cfg={"enabled": True})
    check(any(h.get("via") in ("both", "dense") for h in p2.search("recency", k=5)), "hybrid search uses the dense index")
    say(f"selftest {'PASSED' if ok else 'FAILED'} - {tmp}")
    return ok
