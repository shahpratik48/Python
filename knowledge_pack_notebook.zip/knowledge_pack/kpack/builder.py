"""Builds one System Knowledge Pack (IKG / ODM / NLG) from three inputs - repository, Greenplum tables, skills documents -
into output/<system>/<version>/ and ONE deliverable zip per system, output/<system>/<system>_pack.zip (complete, self-contained,
root folder <system>_pack/; replaced atomically on every good build; a degraded build is kept aside and never replaces it):

  VERSION.txt        system, version, repo ref, health (for humans)     build_config.yaml   the (secret-free) config used
  manifest.json      what is in the pack, versions, sources, counts, build cost
  health.json        warnings (missing inputs, failed stages, unexplained folders / tables), stage timings
  pack.md            the human index: how the system works, folder guide, DAGs, tables, rules, glossary, what changed
  raw/repo/...       the code files (so consumers can open any script without git access)
  raw/skills/...     the skills / standards / glossary documents as text
  raw/gp/...         the gp.md table lists
  facts/structure.json    DAGs, registration map, folder map, companions, table lineage, params, symbols, file list
  facts/tables.json       column-level description of every table (+ sample rows when allowed)
  facts/skills.json       the documents (text + sections)
  derived/derived.json    conventions, checkable rules, definitions, folder purposes, how-tos, table semantics, bridge
  items.jsonl             every knowledge item (the retrieval units, incl. code chunks with contextual headers)
  index/                  BM25 + vector store over the items (hybrid search, reciprocal-rank fusion)
  graph.json              knowledge graph: tables / columns / scripts / folders / DAGs / params / terms and their relations
  cards/                  prompt-ready markdown context cards (folder, table, dag, howto, system)
  exemplars.json          one canonical file per folder (few-shot example for code generation)
  synonyms.json           query expansion table (business words -> technical tokens)
  store.sqlite            optional metadata tables copied from Greenplum
"""
from __future__ import annotations

import hashlib
import json
import logging
import re
import shutil
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Dict, List, Optional

from agiledev.repoindex import RepoIndex

from .config import PACKAGE_ROOT, have_secret, secret, system_cfg
from .derived import Derived, rules_sanity
from . import enrich
from .index import PackIndex
from .inputs import copy_metadata_tables, describe_tables, open_greenplum, parse_gp_folder, read_skills
from .structure import RepoStructure

log = logging.getLogger("kpack.builder")


def _sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()[:16]


def _rel(cfg, rel: str) -> Path:
    p = Path(rel)
    return p if p.is_absolute() else PACKAGE_ROOT / p


class PackBuilder:
    def __init__(self, cfg, system: str, progress: Optional[Callable[[str], None]] = None, repo_path: str = "", use_llm: bool = True,
                 llm=None, allow_prompt: bool = False):
        self.cfg = cfg
        self.system = system
        self.sc = system_cfg(cfg, system)
        self.say = progress or (lambda m: log.info(m))
        self.repo_path = repo_path
        self.use_llm = use_llm
        self.llm = llm
        self.allow_prompt = allow_prompt
        self.b = cfg.build
        self.warnings: List[str] = []
        self.timings: Dict[str, float] = {}
        self.version = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        self.out_root = _rel(cfg, self.b.get("output_dir", "output")) / system
        self.out = self.out_root / self.version
        self.gp = None

    # ------------------------------------------------------------------ utilities
    def _stage(self, name: str):
        builder = self

        class _S:
            def __enter__(self_):
                self_.t0 = time.time(); builder.say(f"[{builder.system}] {name} ...")
                return self_

            def __exit__(self_, et, ev, tb):
                builder.timings[name] = round(time.time() - self_.t0, 1)
                if ev is not None:
                    builder.warnings.append(f"{name} failed: {type(ev).__name__}: {str(ev)[:300]}")
                    log.exception("stage %s failed", name)
                return True                      # a failed stage degrades the pack, it does not abort the build
        return _S()

    def _write(self, rel: str, data) -> None:
        p = self.out / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(data, (dict, list)):
            p.write_text(json.dumps(data, indent=1, ensure_ascii=False, default=str), encoding="utf-8")
        else:
            p.write_text(str(data), encoding="utf-8")

    def _llm(self):
        if not self.use_llm:
            return None
        if self.llm is not None:
            return self.llm
        if not (have_secret("llm_api_key") or secret(self.cfg, "llm_api_key", allow_prompt=self.allow_prompt)):
            self.warnings.append("no Azure OpenAI key - derived layer and dense index skipped (BM25 index only)")
            return None
        from agiledev.llm import LLM
        self.llm = LLM(self.cfg, _rel(self.cfg, self.cfg.storage.get("llm_cache_dir", "data/cache/llm")))
        return self.llm

    # ------------------------------------------------------------------ stages
    def fetch_repo(self) -> Path:
        if self.repo_path:
            p = Path(self.repo_path)
            if p.is_file() and p.suffix.lower() in (".txt", ".dump", ".log"):
                p = self._split_dump(p)          # a text dump (****name****** / ****repo/path****** headers + code) -> real files
            if not p.is_dir():
                raise FileNotFoundError(f"repo path {p} not found")
            return self._stage_local(p)
        from agiledev.gitclient import GitClient
        token = secret(self.cfg, "git_read_token", allow_prompt=self.allow_prompt)
        if not token:
            raise RuntimeError("no git read token and no --repo-path: cannot fetch the repository")
        url = self.sc["gitlab_url"].rstrip("/") + "/" + self.sc["project_path"].strip("/")
        gc = GitClient(url, token, ssl_verify=self.cfg.git.get("ssl_verify", True), default_provider=self.cfg.git.get("default_provider", "gitlab"))
        ref = self.sc.get("branch") or gc.project_info().get("default_branch", "main")
        dest = _rel(self.cfg, self.cfg.storage.get("repo_cache_dir", "data/cache/repos")) / self.system
        r = gc.download(dest, ref, list(self.b.get("code_extensions", ["py", "sql"])), int(self.b.get("max_file_kb", 800)),
                        int(self.b.get("max_files", 12000)), cache_hours=0.5, refresh=True, subpath=self.sc.get("subpath", ""), progress=self.say)
        self.repo_ref = ref
        self.say(f"repository ready: {r.get('files')} files at {ref}")
        return Path(r["path"])

    def _split_dump(self, dump: Path) -> Path:
        """Reconstructs a repository folder from a text dump where every file appears as `****name******`, then
        `****<repo>/<path>******`, then the code (optionally every line followed by an inserted blank line), files separated
        by a dashed line. Written once to data/cache/repos/<system>_dump/ and reused while the dump is unchanged."""
        dest = _rel(self.cfg, self.cfg.storage.get("repo_cache_dir", "data/cache/repos")) / f"{self.system}_dump"
        stamp = dest / ".dump_stamp"
        sig = f"{dump.stat().st_size}|{dump.stat().st_mtime}"
        if dest.exists() and stamp.exists() and stamp.read_text() == sig:
            return dest
        if dest.exists():
            shutil.rmtree(dest)
        hdr = re.compile(r"^\*{4}(.+?)\*{6}\s*$")
        files: Dict[str, List[str]] = {}
        cur = None
        for ln in dump.read_text(encoding="utf-8", errors="replace").splitlines():
            m = hdr.match(ln)
            if m:
                name = m.group(1).strip()
                if "/" in name:               # the second header carries the path; the first only the file name
                    cur = name; files[cur] = []
                elif cur is None or files.get(cur):
                    cur = name; files[cur] = []
                continue
            if ln.startswith("-----------------------------------------------------------------"):
                cur = None; continue
            if cur is not None:
                files[cur].append(ln)
        if any("/" in k for k in files):      # name-only headers are just labels for the path header that follows: drop their empty entries
            files = {k: v for k, v in files.items() if "/" in k or any(l.strip() for l in v)}
        root_prefix = None
        firsts = {k.split("/", 1)[0] for k in files if "/" in k}
        if len(firsts) == 1 and all("/" in k for k in files):
            root_prefix = firsts.pop() + "/"
        n = 0
        for path, lines in files.items():
            body = lines
            if len(lines) > 4 and sum(1 for l in lines if l.strip() == "") / len(lines) > 0.45:
                body, run = [], 0            # the dump interleaves a blank after every line: drop them, keep real blank lines
                for l in lines:
                    if l.strip() == "":
                        run += 1
                        if run == 2:
                            body.append("")
                    else:
                        run = 0; body.append(l.rstrip())
            rel = path[len(root_prefix):] if root_prefix and path.startswith(root_prefix) else path
            if not rel or rel.endswith("/"):
                continue
            f = dest / rel
            f.parent.mkdir(parents=True, exist_ok=True)
            f.write_text("\n".join(body).rstrip() + "\n", encoding="utf-8")
            n += 1
        stamp.write_text(sig)
        self.say(f"dump {dump.name}: {n} files reconstructed into {dest}")
        return dest

    def _stage_local(self, src: Path) -> Path:
        """A local repository copy is filtered like a GitLab download: code extensions only, size cap, no build / vendor folders."""
        exts = tuple("." + e.lower().lstrip(".") for e in self.b.get("code_extensions", ["py", "sql"]))
        max_kb, max_files = int(self.b.get("max_file_kb", 800)), int(self.b.get("max_files", 12000))
        skip_dirs = {"node_modules", "build", "dist", ".git", "__pycache__", ".idea", ".vscode", "venv", ".venv", "target", "logs"}
        dest = _rel(self.cfg, self.cfg.storage.get("repo_cache_dir", "data/cache/repos")) / self.system
        if dest.exists():
            shutil.rmtree(dest)
        n, skipped = 0, 0
        for f in sorted(src.rglob("*")):
            if not f.is_file():
                continue
            rel = f.relative_to(src)
            if any(part in skip_dirs or part.startswith(".") for part in rel.parts):
                continue
            if not f.name.lower().endswith(exts) or f.stat().st_size > max_kb * 1024 or n >= max_files:
                skipped += 1
                continue
            d = dest / rel
            d.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(f, d)
            n += 1
        (dest / ".agiledev_ref").write_text(f"local\n{time.time()}")
        self.say(f"local repository copy {src}: {n} code files staged ({skipped} skipped)")
        return dest

    def build(self) -> dict:
        t_all = time.time()
        self.out.mkdir(parents=True, exist_ok=True)
        self.repo_ref = self.sc.get("branch") or "local"
        structure, tables, skills, derived, items = {}, {}, {}, {}, []
        meta_status, repo_root, idx = {}, None, None

        with self._stage("repository"):
            repo_root = self.fetch_repo()
            idx = RepoIndex(repo_root, self.sc.get("repo_name") or repo_root.name, max_files=int(self.b.get("max_files", 12000)))
            self.say(f"indexed {len(idx.files)} files")

        with self._stage("structure"):
            if idx is not None:
                structure = RepoStructure(idx, self.system).analyse()
                self._write("facts/structure.json", structure)
                self.say(f"{len(structure['dags'])} DAG files, {len(structure['folders'])} folders, {len(structure['tables'])} tables referenced, "
                         f"{len(structure['companion_patterns'])} companion patterns")

        with self._stage("tables"):
            wanted = parse_gp_folder(_rel(self.cfg, self.sc["gp_folder"]), self.sc.get("schema", ""))
            for p in [_rel(self.cfg, self.sc["gp_folder"])]:
                if p.is_dir():
                    for f in p.iterdir():
                        if f.is_file():
                            (self.out / "raw" / "gp").mkdir(parents=True, exist_ok=True)
                            shutil.copyfile(f, self.out / "raw" / "gp" / f.name)
            seen = {f"{t['schema']}.{t['table']}" for t in wanted}
            if self.b.get("describe_tables_from_code", True):
                for t in structure.get("tables", {}):
                    if "." in t and "{" not in t and t not in seen and structure["tables"][t].get("written_by"):
                        s, _, n = t.partition(".")
                        wanted.append({"schema": s, "table": n, "description": "", "source": "code"}); seen.add(t)
            wanted = wanted[: int(self.b.get("max_described_tables", 400))]
            self.gp = open_greenplum(self.cfg, secret(self.cfg, "greenplum_password", allow_prompt=self.allow_prompt))
            if self.gp is None:
                self.warnings.append(f"no Greenplum password - {len(wanted)} tables listed but not described (columns unknown)")
                tables = {f"{t['schema']}.{t['table']}": dict(t, columns=[], described=False) for t in wanted}
            else:
                self.say(f"Greenplum: {self.gp.test()}")
                tables = describe_tables(self.gp, wanted, int(self.b.get("sample_rows", 3)), self.say, sqlite_mode=bool(self.cfg.greenplum.get("sqlite_path")))
                for t in tables.values():
                    t["described"] = not t.get("error") and bool(t.get("columns"))
                missing = [k for k, v in tables.items() if not v["described"]]
                if missing:
                    self.warnings.append(f"{len(missing)} tables could not be described (not found / no access): {', '.join(missing[:10])}")
            self._write("facts/tables.json", tables)

        with self._stage("metadata_tables"):
            names = list(self.b.get("metadata_tables") or [])
            if names and self.gp is not None:
                meta_status = copy_metadata_tables(self.gp, names, self.out / "store.sqlite", int(self.b.get("metadata_max_rows", 20000)), self.say,
                                                   sqlite_mode=bool(self.cfg.greenplum.get("sqlite_path")))
            elif names:
                self.warnings.append("metadata tables configured but Greenplum not available")

        with self._stage("skills"):
            folders = [_rel(self.cfg, self.sc["skills_folder"]), _rel(self.cfg, self.cfg.get("common_skills_folder", "skills/common"))]
            skills = read_skills(folders)
            if not skills:
                self.warnings.append(f"no skills documents found in {self.sc['skills_folder']} / common - conventions layer empty")
            self._write("facts/skills.json", skills)
            for folder in folders:
                if folder.is_dir():
                    for f in folder.rglob("*"):
                        if f.is_file() and not f.name.startswith("."):
                            d = self.out / "raw" / "skills" / folder.name / f.relative_to(folder)
                            d.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(f, d)

        with self._stage("raw_repo"):
            if repo_root is not None:
                dst = self.out / "raw" / "repo"
                for rel in idx.files:
                    s = repo_root / rel
                    d = dst / rel
                    d.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(s, d)

        with self._stage("derived"):
            llm = self._llm() if self.b.get("derived_layer", True) else None
            dv = Derived(self.cfg, llm, self.say, budget_usd=float(self.b.get("max_llm_cost_usd", 3.0)))
            facts = dv.facts(structure, tables)
            derived = {"facts": facts, "knowledge": {}, "repo": {}, "data": {}, "bridge": {}, "model_layer": bool(llm)}
            if llm is not None:
                headers = {f: v.get("header_samples", []) for f, v in structure.get("folders", {}).items()}
                derived["knowledge"] = dv.knowledge(skills, self.system)
                derived["knowledge"]["rules"] = rules_sanity(derived["knowledge"].get("rules", []))
                derived["repo"] = dv.repo_summary(facts, self.system, headers)
                described = {k: v for k, v in tables.items() if v.get("described")}
                derived["data"] = dv.data_semantics(described, structure, lambda rel: idx.read(rel, 4000) if idx else "", self.system)
                derived["bridge"] = dv.bridge(derived["knowledge"], derived["repo"], derived["data"], self.system)
                derived["model_calls"] = dv.calls
                self.warnings.extend(dv.errors)
            else:
                self.warnings.append("derived layer: model not used (facts only) - run with the Azure key for conventions / purposes / semantics")
            self._write("derived/derived.json", derived)

        with self._stage("enrich"):
            read = (lambda rel: idx.read(rel, 200000)) if idx else (lambda rel: "")
            enrich_counts = enrich.write_all(self.out, structure, tables, derived, skills, read, self.system)
            self.say(f"graph {enrich_counts['graph']['nodes']} nodes / {enrich_counts['graph']['edges']} edges, {enrich_counts['cards']} cards, "
                     f"{enrich_counts['exemplars']} exemplars, {enrich_counts['synonyms']} synonyms")

        with self._stage("items"):
            items = self.items(structure, tables, skills, derived, idx)
            if self.b.get("index_chunks", True):
                ch = enrich.chunks(structure, derived, read, self.system, int(self.b.get("max_chunks_per_file", 40)))
                items.extend(ch)
                self.say(f"{len(ch)} code chunks (contextual headers)")
            (self.out / "items.jsonl").write_text("\n".join(json.dumps(i, ensure_ascii=False) for i in items), encoding="utf-8")
            self.say(f"{len(items)} knowledge items")

        with self._stage("index"):
            emb = dict(self.cfg.get("embeddings") or {})
            emb["enabled"] = bool(emb.get("enabled", True)) and bool(self.b.get("embeddings", True))
            pi = PackIndex(self.out, emb, llm=self._llm() if emb["enabled"] else None,
                           cache_dir=_rel(self.cfg, self.cfg.storage.get("data_dir", "data")) / "cache" / "embeddings")
            st = pi.build(items, self.say)
            if not st.get("dense"):
                self.warnings.append(f"dense index not built ({st.get('error') or 'embeddings off'}) - BM25 search only")

        previous = self._previous()
        manifest = self.manifest(structure, tables, skills, derived, items, meta_status, previous)
        with self._stage("pack_md"):
            self._write("pack.md", self.pack_md(manifest, structure, tables, skills, derived, previous))
        health = {"status": "ok" if not any("failed" in w for w in self.warnings) else "degraded", "warnings": self.warnings,
                  "stage_seconds": self.timings, "total_seconds": round(time.time() - t_all, 1)}
        self._write("health.json", health)
        manifest["health"] = health["status"]
        self._write("manifest.json", manifest)
        # the ONE deliverable per system: output/<system>/<system>_pack.zip - a complete, self-contained pack (root folder
        # <system>_pack/, version inside VERSION.txt + manifest.json). The dated folder is kept only for the diff / history.
        zip_path = self.out_root / f"{self.system}_pack.zip"
        promoted = health["status"] == "ok" or not self.b.get("promote_only_if_ok", True)
        with self._stage("zip"):
            self._write("VERSION.txt", f"{self.system} pack {self.version}\nbuilt {manifest['built_at']}\nrepo {manifest['repo']['project']} @ {manifest['repo']['ref']}\nhealth {health['status']}\n")
            self._write("build_config.yaml", self._config_snapshot())
            tmp = self.out_root / f".{self.system}_pack.zip.part"
            with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zf:
                for p in sorted(self.out.rglob("*")):
                    if p.is_file():
                        zf.write(p, f"{self.system}_pack/{p.relative_to(self.out)}")
            manifest["zip_mb"] = round(tmp.stat().st_size / 1048576, 2)
            if promoted:
                tmp.replace(zip_path)                                   # atomic: readers never see a half-written zip
                manifest["zip"] = str(zip_path)
                (self.out_root / "latest.json").write_text(json.dumps({"system": self.system, "version": self.version, "path": str(self.out), "zip": str(zip_path),
                                                                       "built_at": manifest["built_at"], "health": health["status"]}, indent=1), encoding="utf-8")
            else:
                held = self.out_root / f"{self.system}_pack_{self.version}_degraded.zip"
                tmp.replace(held)
                manifest["zip"] = str(held)
                self.warnings.append(f"build degraded: {zip_path.name} and latest.json NOT replaced (previous good pack kept); this build saved as {held.name}")
                health["warnings"] = self.warnings
                self._write("health.json", health)
            manifest["promoted"] = promoted
            self._write("manifest.json", manifest)
            self._prune()
        if self.gp is not None:
            self.gp.close()
        self.say(f"[{self.system}] pack {self.version} {'ready' if promoted else 'built but NOT promoted'}: {manifest.get('zip')} ({manifest.get('zip_mb')} MB, {health['status']}, {health['total_seconds']}s)")
        return {"manifest": manifest, "health": health, "path": str(self.out), "zip": manifest.get("zip", ""), "promoted": promoted}

    def _config_snapshot(self) -> str:
        """The configuration this pack was built with (no secrets exist in it) - lets a consumer open the dense index with the
        same embedding deployment / dimensions and know which repo, branch, schema and folders the pack covers."""
        import yaml
        snap = {"system": self.system, "version": self.version, "source": dict(self.sc), "build": dict(self.b), "embeddings": dict(self.cfg.get("embeddings") or {}),
                "greenplum": {k: v for k, v in dict(self.cfg.get("greenplum") or {}).items() if k != "sqlite_path"}}
        return yaml.safe_dump(snap, sort_keys=False)

    # ------------------------------------------------------------------ knowledge items (retrieval units)
    def items(self, structure, tables, skills, derived, idx) -> List[dict]:
        out = []
        sysname = self.system
        d_repo, d_data, d_kn = derived.get("repo", {}), derived.get("data", {}).get("tables", {}), derived.get("knowledge", {})
        reg = structure.get("registration", {})
        if d_repo.get("system_summary"):
            out.append({"kind": "system", "ref": sysname, "title": f"{sysname} system overview", "text": d_repo["system_summary"]})
        for how in d_repo.get("how_to", []) or []:
            out.append({"kind": "howto", "ref": how.get("task", ""), "title": f"how to: {how.get('task', '')}", "text": "\n".join(f"- {s}" for s in how.get("steps", []))})
        for f, v in structure.get("folders", {}).items():
            purpose = (d_repo.get("folders", {}).get(f) or {})
            text = (f"purpose: {purpose.get('purpose') or v.get('purpose_hint', '')}\nhow to add: {purpose.get('how_to_add', '')}\n"
                    f"watch out: {purpose.get('watch_out', '')}\nfiles: {v['files']} {v['languages']}\ntypical files: {', '.join(v.get('typical_files', []))}\n"
                    f"name suffixes: {', '.join(v.get('common_name_suffixes', []))}\ntables built here: {', '.join(v.get('tables_built_here', [])[:20])}\n"
                    f"registration: {v.get('registration', '')}\nheaders: " + " | ".join(v.get("header_samples", [])[:3]))
            out.append({"kind": "folder", "ref": f or "(root)", "title": f"folder {f or '(root)'}", "text": text})
        for d in structure.get("dags", []):
            text = (f"dag ids: {', '.join(d.get('dag_ids', []))}\ntasks ({len(d.get('task_ids', []))}): {', '.join(d.get('task_ids', [])[:40])}\n"
                    f"task groups: {', '.join(d.get('task_groups', [])[:20])}\nfolders walked: {', '.join(d.get('folders_referenced', []))}\n"
                    f"dynamic registration: {', '.join(d.get('dynamic_registration', []))}\nvariables: {', '.join(d.get('variables', [])[:20])}\n"
                    f"dependencies: " + " ; ".join(d.get("dependency_chains", [])[:8]))
            out.append({"kind": "dag", "ref": d["path"], "title": f"DAG {d['path']}", "text": text})
        for c in structure.get("companion_patterns", []):
            out.append({"kind": "companion", "ref": f"{c['folder']}->{c['companion_folder_or_file']}", "title": f"companion rule {c['folder']}",
                        "text": f"{c['rule']}\nexample: {c['example']['file']} <-> {c['example']['companion']} {c['example']['line']}\noccurrences: {c['occurrences']}"})
        for t, info in tables.items():
            sem = d_data.get(t, {})
            cols = ", ".join(f"{c.get('name')} {c.get('type', '')}".strip() for c in info.get("columns", [])[:120])
            lin = structure.get("tables", {}).get(t, {})
            text = (f"description: {info.get('description', '')}\npurpose: {sem.get('purpose', '')}\ngrain: {sem.get('grain', '')}\nkey columns: {', '.join(sem.get('key_columns', []) or [])}\n"
                    f"columns: {cols}\ncolumn notes: {json.dumps(sem.get('column_notes', {}), ensure_ascii=False)[:1500]}\n"
                    f"built by: {', '.join(lin.get('written_by', [])[:10])}\nread by: {', '.join(lin.get('read_by', [])[:15])}\n"
                    f"described: {info.get('described')} rows~{info.get('rows_estimate', info.get('reltuples', ''))}")
            out.append({"kind": "table", "ref": t, "title": t, "text": text})
        for t, lin in structure.get("tables", {}).items():
            if t not in tables and lin.get("written_by"):
                out.append({"kind": "table", "ref": t, "title": t, "text": f"(not described) built by: {', '.join(lin['written_by'][:10])}\nread by: {', '.join(lin.get('read_by', [])[:15])}"})
        syms = structure.get("symbols", {})
        for rel, f in structure.get("file_list", {}).items():
            if f["language"] not in ("sql", "python", "airflow_dag", "r", "yaml", "shell", "ipynb", "md"):
                continue
            s = syms.get(rel, {})
            body = idx.read(rel, 1800) if idx else ""
            folder = rel.rsplit("/", 1)[0] if "/" in rel else ""
            text = (f"language: {f['language']} lines: {f['lines']}\nfolder: {folder}\nregistration: {reg.get(folder, {}).get('rule', '')[:200]}\n"
                    f"defs: {', '.join(s.get('defs', [])[:30])}\ntables: {', '.join(structure.get('script_tables', {}).get(rel, [])[:10])}\n"
                    f"header: {s.get('header', '')}\n{body}")
            out.append({"kind": "file", "ref": rel, "title": rel, "text": text})
        for name, doc in skills.items():
            secs = doc.get("sections") or []
            if secs:
                for i, sec in enumerate(secs[:80]):
                    title = sec.get("title") if isinstance(sec, dict) else str(sec)[:80]
                    body = sec.get("text", "") if isinstance(sec, dict) else ""
                    if body.strip():
                        out.append({"kind": doc.get("kind", "skills"), "ref": f"{name}#{i}", "title": f"{name}: {title}", "text": body[:4000]})
            elif doc.get("text"):
                t = doc["text"]
                for i in range(0, min(len(t), 60000), 3000):
                    out.append({"kind": doc.get("kind", "skills"), "ref": f"{name}#{i // 3000}", "title": name, "text": t[i:i + 3200]})
        for dfn in d_kn.get("definitions", []) or []:
            out.append({"kind": "definition", "ref": str(dfn.get("term", "")), "title": f"definition {dfn.get('term', '')}", "text": f"{dfn.get('definition', '')}\nsource: {dfn.get('source', '')}"})
        for i, c in enumerate(d_kn.get("conventions", []) or []):
            out.append({"kind": "convention", "ref": f"convention#{i}", "title": f"convention: {str(c.get('rule', ''))[:80]}", "text": f"{c.get('rule', '')}\napplies to: {c.get('applies_to', '')}\nsource: {c.get('source', '')}"})
        for r in d_kn.get("rules", []) or []:
            out.append({"kind": "rule", "ref": str(r.get("id", "")), "title": f"rule {r.get('id', '')}", "text": f"{r.get('message', '')}\npattern: {r.get('pattern', '')}\nmust match: {r.get('must_match')}\nlanguages: {r.get('languages')}\napplies to: {r.get('applies_to')}"})
        for p, v in list(structure.get("params", {}).items())[:200]:
            out.append({"kind": "param", "ref": p, "title": f"parameter {p}", "text": f"used {v['uses']} times, e.g. {', '.join(v['examples'][:4])}"})
        for g in (d_repo.get("glossary") or []) + [{"term": b.get("term"), "meaning": f"{b.get('note', '')} tables: {', '.join(b.get('tables', []) or [])} columns: {', '.join(b.get('columns', []) or [])} scripts: {', '.join(b.get('scripts_or_folders', []) or [])} synonyms: {', '.join(b.get('synonyms', []) or [])}"} for b in derived.get("bridge", {}).get("bridge", []) or []]:
            if g.get("term"):
                out.append({"kind": "glossary", "ref": str(g["term"]), "title": f"term {g['term']}", "text": str(g.get("meaning", ""))})
        return out

    # ------------------------------------------------------------------ manifest, diff, pack.md
    def _previous(self) -> Optional[dict]:
        lj = self.out_root / "latest.json"
        if not lj.exists():
            return None
        try:
            prev = json.loads(lj.read_text(encoding="utf-8"))
            pm = Path(prev["path"]) / "manifest.json"
            return json.loads(pm.read_text(encoding="utf-8")) if pm.exists() else None
        except Exception:  # noqa: BLE001
            return None

    def manifest(self, structure, tables, skills, derived, items, meta_status, previous) -> dict:
        hashes = {}
        for p in (self.out / "raw" / "repo").rglob("*"):
            if p.is_file():
                hashes[str(p.relative_to(self.out / "raw" / "repo")).replace("\\", "/")] = _sha(p)
        skill_hashes = {n: d.get("sha", "") for n, d in skills.items()}
        diff = {"added_files": [], "removed_files": [], "changed_files": [], "added_tables": [], "removed_tables": [], "changed_skills": [], "previous_version": None}
        if previous:
            ph = previous.get("file_hashes", {})
            diff["previous_version"] = previous.get("version")
            diff["added_files"] = sorted(set(hashes) - set(ph))[:300]
            diff["removed_files"] = sorted(set(ph) - set(hashes))[:300]
            diff["changed_files"] = sorted(k for k in set(hashes) & set(ph) if hashes[k] != ph[k])[:300]
            pt = set(previous.get("tables", []))
            diff["added_tables"] = sorted(set(tables) - pt)[:100]
            diff["removed_tables"] = sorted(pt - set(tables))[:100]
            psk = previous.get("skill_hashes", {})
            diff["changed_skills"] = sorted(k for k in skill_hashes if psk.get(k) != skill_hashes[k])
        cost = {}
        if self.llm is not None:
            try:
                cost = self.llm.token_stats()
            except Exception:  # noqa: BLE001
                cost = {}
        return {"system": self.system, "version": self.version, "built_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                "repo": {"name": self.sc.get("repo_name"), "project": self.sc.get("project_path"), "ref": getattr(self, "repo_ref", ""), "files": structure.get("files", 0),
                         "languages": structure.get("languages", {})},
                "counts": {"dag_files": len(structure.get("dags", [])), "folders": len(structure.get("folders", {})), "tables_referenced": len(structure.get("tables", {})),
                           "tables_described": sum(1 for t in tables.values() if t.get("described")), "tables_listed": len(tables), "skills_documents": len(skills),
                           "companion_patterns": len(structure.get("companion_patterns", [])), "definitions": len(derived.get("knowledge", {}).get("definitions", []) or []),
                           "conventions": len(derived.get("knowledge", {}).get("conventions", []) or []), "rules": len(derived.get("knowledge", {}).get("rules", []) or []),
                           "items": len(items), "chunks": sum(1 for i in items if i["kind"] == "chunk")},
                "model_layer": bool(derived.get("model_layer")), "model_calls": derived.get("model_calls", 0), "cost": cost,
                "tables": sorted(tables), "metadata_tables": meta_status, "file_hashes": hashes, "skill_hashes": skill_hashes, "diff": diff,
                "layout": {"pack.md": "human index", "facts/": "deterministic facts", "derived/": "model layer", "items.jsonl": "retrieval units (incl. code chunks)",
                           "index/": "BM25 + vectors (hybrid, RRF)", "graph.json": "knowledge graph (tables, scripts, folders, DAGs, params, terms)",
                           "cards/": "prompt-ready context cards per folder / table / DAG / how-to", "exemplars.json": "one canonical file per folder",
                           "synonyms.json": "query expansion (business word -> technical tokens)", "raw/": "repo code, skills, gp lists", "store.sqlite": "metadata tables (optional)"}}

    def pack_md(self, m, structure, tables, skills, derived, previous) -> str:
        L = []
        c = m["counts"]
        d_repo, d_kn, d_data = derived.get("repo", {}), derived.get("knowledge", {}), derived.get("data", {}).get("tables", {})
        L.append(f"# {self.system.upper()} System Knowledge Pack - {m['version']}\n")
        L.append(f"Built {m['built_at']} from `{m['repo']['project']}` @ `{m['repo']['ref']}` ({m['repo']['files']} files), {c['tables_listed']} tables "
                 f"({c['tables_described']} described from Greenplum), {c['skills_documents']} skills documents. Model layer: {'yes' if m['model_layer'] else 'no (facts only)'}. "
                 f"Items indexed: {c['items']}.\n")
        if self.warnings:
            L.append("## Health\n" + "\n".join(f"- {w}" for w in self.warnings) + "\n")
        if d_repo.get("system_summary"):
            L.append("## What the system does\n" + d_repo["system_summary"] + "\n")
        if d_repo.get("how_to"):
            L.append("## How to ...\n" + "\n".join(f"**{h.get('task')}**\n" + "\n".join(f"{i + 1}. {s}" for i, s in enumerate(h.get("steps", []))) for h in d_repo["how_to"]) + "\n")
        L.append("## DAGs\n| DAG file | dag ids | tasks | registration | folders walked |\n|---|---|---|---|---|")
        for d in structure.get("dags", [])[:60]:
            L.append(f"| `{d['path']}` | {', '.join(d.get('dag_ids', [])[:4])} | {len(d.get('task_ids', []))} | {'dynamic: ' + ', '.join(d['dynamic_registration']) if d.get('dynamic_registration') else 'static'} | {', '.join(d.get('folders_referenced', [])[:5])} |")
        L.append("\n## Folder guide\n| folder | files | purpose | registration | companions |\n|---|---|---|---|---|")
        comp_by = {}
        for cp in structure.get("companion_patterns", []):
            comp_by.setdefault(cp["folder"], []).append(cp["rule"])
        for f, v in structure.get("folders", {}).items():
            purpose = (d_repo.get("folders", {}).get(f) or {}).get("purpose") or v.get("purpose_hint", "")
            L.append(f"| `{f or '(root)'}` | {v['files']} | {purpose[:160]} | {v.get('registration', '')[:120]} | {'; '.join(comp_by.get(f, []))[:160]} |")
        L.append("\n## Tables\n| table | described | purpose | built by | read by |\n|---|---|---|---|---|")
        for t in sorted(tables)[:400]:
            lin = structure.get("tables", {}).get(t, {})
            L.append(f"| `{t}` | {'yes' if tables[t].get('described') else 'no'} | {(d_data.get(t, {}).get('purpose') or tables[t].get('description', ''))[:140]} | "
                     f"{', '.join(Path(x).name for x in lin.get('written_by', [])[:3])} | {len(lin.get('read_by', []))} scripts |")
        other = [t for t in structure.get("tables", {}) if t not in tables]
        if other:
            L.append(f"\nAlso referenced in code but not listed for description ({len(other)}): " + ", ".join(f"`{t}`" for t in other[:80]) + ("..." if len(other) > 80 else ""))
        if d_kn.get("conventions"):
            L.append("\n## Conventions\n" + "\n".join(f"- {x.get('rule')} _(applies to: {x.get('applies_to', '')}; source: {x.get('source', '')})_" for x in d_kn["conventions"][:150]))
        if d_kn.get("rules"):
            L.append("\n## Checkable rules\n| id | severity | languages | pattern | message |\n|---|---|---|---|---|")
            for r in d_kn["rules"][:100]:
                L.append(f"| {r.get('id')} | {r.get('severity')} | {r.get('languages')} | `{str(r.get('pattern', ''))[:60]}` | {str(r.get('message', ''))[:120]} |")
        if d_kn.get("definitions"):
            L.append("\n## Definitions\n" + "\n".join(f"- **{x.get('term')}**: {x.get('definition')} _({x.get('source', '')})_" for x in d_kn["definitions"][:300]))
        bridge = derived.get("bridge", {}).get("bridge", []) or []
        if bridge:
            L.append("\n## Business term -> technical object\n| term | tables | columns | scripts / folders |\n|---|---|---|---|")
            for b in bridge[:100]:
                L.append(f"| {b.get('term')} | {', '.join(b.get('tables', []) or [])[:100]} | {', '.join(b.get('columns', []) or [])[:100]} | {', '.join(b.get('scripts_or_folders', []) or [])[:100]} |")
        params = structure.get("params", {})
        if params:
            L.append("\n## Parameters\n" + ", ".join(f"`{p}` ({v['uses']})" for p, v in list(params.items())[:80]))
        if skills:
            L.append("\n## Skills documents\n" + "\n".join(f"- `{n}` ({d.get('kind')}, {d.get('chars', 0)} chars, {d.get('source_folder')})" for n, d in skills.items()))
        diff = m.get("diff", {})
        if diff.get("previous_version"):
            L.append(f"\n## What changed since {diff['previous_version']}\n- files added: {len(diff['added_files'])} {', '.join(diff['added_files'][:15])}\n"
                     f"- files changed: {len(diff['changed_files'])} {', '.join(diff['changed_files'][:15])}\n- files removed: {len(diff['removed_files'])} {', '.join(diff['removed_files'][:15])}\n"
                     f"- tables added: {', '.join(diff['added_tables'][:20]) or '-'}\n- tables removed: {', '.join(diff['removed_tables'][:20]) or '-'}\n"
                     f"- skills changed: {', '.join(diff['changed_skills']) or '-'}")
        else:
            L.append("\n## What changed\nFirst version of this pack.")
        L.append("\n## Build\n| stage | seconds |\n|---|---|\n" + "\n".join(f"| {k} | {v} |" for k, v in self.timings.items()))
        cost = m.get("cost") or {}
        if cost:
            L.append(f"\nModel usage: {json.dumps(cost.get('cost', cost), default=str)[:400]}")
        L.append("\n## Layout\n" + "\n".join(f"- `{k}`: {v}" for k, v in m["layout"].items()))
        return "\n".join(L)

    def _prune(self) -> None:
        keep = int(self.b.get("keep_versions", 3))
        vers = sorted([p for p in self.out_root.iterdir() if p.is_dir() and re.fullmatch(r"\d{8}_\d{4,6}", p.name)], key=lambda p: p.name)
        for p in vers[:-keep] if keep > 0 else []:
            shutil.rmtree(p, ignore_errors=True)
            for z in (self.out_root / f"{self.system}_pack_{p.name}.zip", self.out_root / f"{self.system}_pack_{p.name}_degraded.zip"):
                if z.exists():
                    z.unlink()
