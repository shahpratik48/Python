"""Config + secrets for the Knowledge Pack builder. Secrets are never written anywhere: Airflow Variable (inside Airflow)
-> environment variable (names under `secrets:`) -> hidden prompt (notebook) -> absent (the build degrades: no LLM layer,
no table descriptions, no e-mail)."""
from __future__ import annotations

import getpass
import logging
import os
from pathlib import Path
from typing import Dict, Optional

import yaml

from agiledev.config import Config, set_secret

log = logging.getLogger("kpack.config")
PACKAGE_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG = PACKAGE_ROOT / "config" / "kpack_config.yaml"
LABELS = {"llm_api_key": "Azure OpenAI key", "git_read_token": "GitLab read token (read_repository / read_api)",
          "greenplum_password": "Greenplum password", "email_password": "SMTP password"}
_SECRETS: Dict[str, str] = {}


def load_config(path: Optional[str] = None) -> Config:
    p = Path(path) if path else DEFAULT_CONFIG
    cfg = Config(yaml.safe_load(p.read_text(encoding="utf-8")) or {})
    cfg["_path"] = str(p)
    cfg["_root"] = str(PACKAGE_ROOT)
    for s in cfg.get("systems", {}).values():   # the agiledev library expects these keys too
        s.setdefault("branch", "")
    return cfg


def system_cfg(cfg: Config, system: str) -> Config:
    systems = cfg.get("systems") or {}
    if system not in systems:
        raise KeyError(f"unknown system {system!r}; configured: {', '.join(systems)}")
    s = Config(dict(systems[system]))
    s["name"] = system
    return s


def secret(cfg: Config, name: str, allow_prompt: bool = False, required: bool = False) -> str:
    """Airflow Variable -> environment variable -> hidden prompt. Kept in process memory only."""
    if name in _SECRETS:
        return _SECRETS[name]
    val = ""
    var_name = str(((cfg.get("airflow") or {}).get("variables") or {}).get(name if name != "llm_api_key" else "azure_openai_api_key") or "")
    if var_name and os.environ.get("AIRFLOW_HOME") or os.environ.get("AIRFLOW_CTX_DAG_ID"):
        try:
            from airflow.models import Variable  # type: ignore
            val = Variable.get(var_name, default_var="") or ""
        except Exception:  # noqa: BLE001
            val = ""
    if not val:
        env = str((cfg.get("secrets") or {}).get(name) or f"KPACK_{name.upper()}")
        val = os.environ.get(env, "")
        if not val and allow_prompt:
            try:
                val = getpass.getpass(f"{LABELS.get(name, name)} (input hidden; Enter to skip): ").strip()
            except Exception:  # noqa: BLE001
                val = ""
    if not val and required:
        raise RuntimeError(f"{LABELS.get(name, name)} not provided")
    if val:
        _SECRETS[name] = val
        if name == "llm_api_key":          # the shared agiledev LLM client reads the key through its own secret store
            set_secret("llm_api_key", val)
    return val


def put_secret(name: str, value: str) -> None:
    if value:
        _SECRETS[name] = value
        if name == "llm_api_key":
            set_secret("llm_api_key", value)


def have_secret(name: str) -> bool:
    return bool(_SECRETS.get(name))
