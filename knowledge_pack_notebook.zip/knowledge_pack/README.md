# Knowledge Pack builder (project 6)

One **System Knowledge Pack** per system - **IKG, ODM, NLG** - built from three inputs and refreshed every weekday evening, so every
use case (Agile Dev Assist, the STAAT Insights chatbot, future agents) starts from the same pre-built, indexed context
instead of re-reading git and Greenplum per question.

| input | where | what goes into the pack |
|---|---|---|
| repository | GitLab `systems.<sys>.project_path` (or a local copy) | every code file (`raw/repo`), DAGs + tasks, how scripts are registered (static list / dynamic folder walk), folder guide, companion patterns (`x_curr_ikg.sql` <-> `x_ikg.sql`), table lineage (built by / read by), parameters, symbols |
| tables | `gp/<sys>/gp.md` + tables the code creates | columns, types, keys, distribution, sample rows (`build.sample_rows`), lineage; optional metadata tables copied into `store.sqlite` |
| documents | `skills/<sys>/` + `skills/common/` (md, txt, docx, xlsx, html, yaml) | searchable sections; with the model layer: definitions, conventions, checkable regex rules, folder purposes, how-tos, table semantics, business-term bridge |

## Output (`output/<sys>/<version>/`)

```
pack.md                 human index: what the system does, how-tos, DAG table, folder guide, tables, conventions, rules, definitions, bridge, what changed
manifest.json           versions, counts, file hashes, diff vs previous version, model cost
health.json             warnings (missing inputs, undescribed tables, failed stages), stage timings
facts/structure.json    deterministic repository facts        facts/tables.json   column-level table descriptions   facts/skills.json
derived/derived.json    model layer (conventions, rules, purposes, semantics, bridge) + deterministic facts summary
items.jsonl             the retrieval units (kinds: system, howto, folder, dag, companion, table, file, chunk, skills/standards/glossary, definition, convention, rule, param, glossary)
index/                  bm25.pkl + vectors.npy + vector_ids.json (hybrid search, RRF fusion)
graph.json              knowledge graph (tables, columns, scripts, folders, DAGs, params, terms; builds/reads/registered_by/companion_of/...)
cards/                  prompt-ready context cards: folder/, table/, dag/, howto/, system.md
exemplars.json          one canonical file per folder (few-shot example for code generation)
synonyms.json           query-expansion table (business word -> technical tokens)
raw/repo raw/skills raw/gp   the inputs as text        store.sqlite   optional metadata tables
```
The deliverable is **one zip per system**: `output/ikg/ikg_pack.zip`, `output/odm/odm_pack.zip`, `output/nlg/nlg_pack.zip` - each a complete, self-contained pack (root folder `<sys>_pack/`, with `VERSION.txt` and `build_config.yaml` inside) that other projects take as their input. A good build replaces it atomically; a degraded build (`build.promote_only_if_ok`) is kept aside as `<sys>_pack_<version>_degraded.zip` and the previous good zip stays. The dated unzipped folders (`build.keep_versions`, 7) exist only for history and the diff.

## Run

```
pip install -r requirements.txt
set KPACK_AZURE_OPENAI_API_KEY=...   KPACK_GIT_READ_TOKEN=...   KPACK_GREENPLUM_PASSWORD=...     (or use --ask / the notebook prompts)
python app_kpack.py build --system all                      # ikg, odm, nlg -> output/, one e-mail report
python app_kpack.py build --system odm --repo-path /path/to/odm-dags --no-llm --no-email      # local folder, or a text dump of the repo (****file****** headers)
python app_kpack.py show --system ikg
python app_kpack.py search --system nlg "how are rules yml tested"
python app_kpack.py selftest                                # offline, no secrets
jupyter notebook KPACK_Builder.ipynb                        # hidden prompts, build, inspect
```

Airflow: copy the folder to the scheduler (or set `KPACK_HOME`), put `airflow/kpack_daily_dag.py` in the DAG folder, create the
Airflow Variables named in `airflow.variables` (`KPACK_AZURE_OPENAI_API_KEY`, `KPACK_GIT_READ_TOKEN`, `KPACK_GREENPLUM_PASSWORD`,
`KPACK_EMAIL_PASSWORD` when SMTP needs a login). DAG `knowledge_pack_daily`: Monday-Friday 19:00 America/New_York, tasks
`build_ikg`, `build_odm`, `build_nlg` (parallel) -> `send_report` (set `email.only_on_change: true` to get the daily mail only when a pack changed or a build degraded). Everything else (schedule, owner, retries, systems, SMTP, recipients)
is in `config/kpack_config.yaml`.

## Use a pack

```python
from kpack.pack import Pack
p = Pack.latest("odm")                                   # or Pack("output/odm/<version>") / Pack("<zip>")
p.search("how is a new client insight registered", k=8)  # hybrid BM25 + vectors (vectors need the Azure key via llm=)
p.table("core_ikg.odm_rule_metadata_auto_refresh")       # columns + semantics + lineage
p.folder("dags/odm/script/sql/ds_client_insights");  p.registration(folder);  p.companions(path)
p.rules();  p.conventions();  p.definitions();  p.bridge("household");  p.read("dags/odm/script/python/props.py")
p.context("add a new wealthx delta insight")             # one prompt-ready block: best cards + code chunks, deduplicated, capped
p.card("folder", folder);  p.exemplar(folder)            # pre-rendered card / canonical sibling file
p.impact("core_ikg.client_profile_curr_ikg")             # graph walk: readers, downstream tables, DAGs - no model call
p.neighbours("script:dags/odm/.../x.sql", hops=2)
```

## Retrieval design (what makes consumers faster, cheaper, more accurate)

| technique | in the pack | effect |
|---|---|---|
| hybrid retrieval: BM25 + dense embeddings, reciprocal-rank fusion | `index/` | exact identifiers (BM25) and paraphrased business language (vectors) both hit |
| contextual chunking: SQL statements / python functions with a context header (file, folder purpose, registration, tables) | `chunk` items | the right statement is found even when the identifying words are only in the file's context; smaller, cheaper context |
| knowledge graph | `graph.json` | impact analysis, lineage, "what else must change" by graph walk instead of model reasoning |
| pre-rendered context cards | `cards/` | agents paste a card instead of assembling facts with 5-10 tool calls |
| exemplars | `exemplars.json` | code generation copies the shape of the most typical sibling |
| query expansion from glossary / bridge / table-name tokens | `synonyms.json` | "household" also finds `household_profile_curr_ikg` |
| identifier boost + kind diversity in ranking | `index.py` | a table / file named in the question ranks first; results are not all of one kind |
| once-a-day model layer, cached by content hash, cost cap | `derived/` | conventions, rules, purposes, semantics paid once for all use cases |

## Faster and cheaper

- facts stage is pure code (seconds): token index for companions / registration, no model;
- the model layer runs once a day (cached: only changed chunks are re-sent), low reasoning, chunked, every call cached by input hash, capped by `build.max_llm_cost_usd`;
- embeddings cached by text hash (`data/cache/embeddings`) - a daily rebuild embeds only new or changed items;
- repository cloned shallow / sparse (`systems.<sys>.subpath`), size caps, build / vendor folders skipped;
- Greenplum: 3 catalog round trips for all tables, samples with a short timeout, read-only session with statement timeout.

## Security

No secret is ever written: config holds only names of variables; `secret()` reads Airflow Variable -> environment variable ->
hidden prompt into process memory; XCom carries counts and paths only; the pack contains code, metadata and samples - set
`build.sample_rows: 0` where sample values are not allowed.
