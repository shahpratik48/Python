"""
GitLab access for the CID check. Connects to the real project over the
REST API -- there is no local-file mode anywhere in this project, by
design: the whole point is to check what is actually on the branch.

Provides:
  1. `compare_files()` -- everything that differs between `branch` and
     `base_branch`. This is the ONLY source of the change set. Individual
     commits are never inspected: relying on the latest commit alone would
     miss anything introduced by an earlier commit on the same branch, so
     the branch is always compared against the base as a whole.
  2. `read_file()` / `read_tree()` -- file content at a specific ref, used
     to parse the "before" and "after" version of every changed file.
"""
from __future__ import annotations

import posixpath
import urllib.parse
from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class ChangedFile:
    old_path: str
    new_path: str
    change_type: str          # "added" | "modified" | "deleted" | "renamed"
    diff: str = ""

    @property
    def path(self) -> str:
        return self.new_path or self.old_path


class GitLabClient:
    def __init__(self, settings):
        import requests
        self._requests = requests
        self.s = settings
        self.base_url = settings.gitlab_url.rstrip("/")
        self.token = settings.gitlab_token
        self._project_id: Optional[int] = None
        if not self.token:
            raise RuntimeError(
                "No GitLab token available. Call settings.resolve_secrets() first "
                "(the notebook prompts for it; Airflow reads it from a Variable)."
            )

    # ---------------------------------------------------------------- core
    def _headers(self):
        return {"PRIVATE-TOKEN": self.token}

    def _project(self) -> int:
        if self._project_id is None:
            encoded = urllib.parse.quote(self.s.nlg_project_path, safe="")
            r = self._requests.get(f"{self.base_url}/api/v4/projects/{encoded}",
                                    headers=self._headers(), timeout=30)
            r.raise_for_status()
            self._project_id = r.json()["id"]
        return self._project_id

    def _strip_prefix(self, path: str) -> str:
        """GitLab returns repo-root-relative paths; we work relative to the
        nlg src subtree so paths match the config/... layout everywhere else."""
        prefix = self.s.nlg_src_subpath.strip("/") + "/"
        return path[len(prefix):] if path.startswith(prefix) else path

    def _in_scope(self, path: str) -> bool:
        prefix = self.s.nlg_src_subpath.strip("/") + "/"
        return bool(path) and path.startswith(prefix)

    @staticmethod
    def _classify(d: dict) -> str:
        if d.get("new_file"):
            return "added"
        if d.get("deleted_file"):
            return "deleted"
        if d.get("renamed_file"):
            return "renamed"
        return "modified"

    def _to_changed_files(self, diffs: List[dict]) -> List[ChangedFile]:
        out = []
        for d in diffs:
            old_p, new_p = d.get("old_path", ""), d.get("new_path", "")
            if not (self._in_scope(old_p) or self._in_scope(new_p)):
                continue
            out.append(ChangedFile(
                old_path=self._strip_prefix(old_p),
                new_path=self._strip_prefix(new_p),
                change_type=self._classify(d),
                diff=d.get("diff", ""),
            ))
        return out

    # ---------------------------------------------------------------- public
    def compare_files(self) -> List[ChangedFile]:
        """Everything that differs between `branch` and `base_branch`.

        Deliberately omits `straight=true`: GitLab's default compares from
        the MERGE BASE, so this reflects what the branch itself introduced,
        rather than also sweeping in whatever the base branch has done
        independently since the two diverged.
        """
        r = self._requests.get(
            f"{self.base_url}/api/v4/projects/{self._project()}/repository/compare",
            headers=self._headers(),
            params={"from": self.s.base_branch, "to": self.s.branch},
            timeout=120)
        r.raise_for_status()
        return self._to_changed_files(r.json().get("diffs", []))

    def read_file(self, path: str, ref: str) -> Optional[str]:
        """File content at a ref. `path` is relative to the nlg src subtree.
        Returns None when the file does not exist at that ref (a new file
        has no 'before', a deleted file has no 'after')."""
        full = posixpath.join(self.s.nlg_src_subpath.strip("/"), path)
        encoded = urllib.parse.quote(full, safe="")
        r = self._requests.get(
            f"{self.base_url}/api/v4/projects/{self._project()}/repository/files/{encoded}/raw",
            headers=self._headers(), params={"ref": ref}, timeout=30)
        if r.status_code == 404:
            return None
        r.raise_for_status()
        return r.text

    def read_tree(self, subdir: str, ref: str) -> List[str]:
        """Every file path under `subdir` at `ref`, relative to the src
        subtree. Used to enumerate all sql_column_mapping files for a
        target_type, and all dummy config files for the MD5 registry."""
        full = posixpath.join(self.s.nlg_src_subpath.strip("/"), subdir.strip("/"))
        out, page = [], 1
        while True:
            r = self._requests.get(
                f"{self.base_url}/api/v4/projects/{self._project()}/repository/tree",
                headers=self._headers(),
                params={"path": full, "ref": ref, "recursive": "true", "per_page": 100, "page": page},
                timeout=60)
            if r.status_code == 404:
                return []
            r.raise_for_status()
            batch = r.json()
            if not batch:
                break
            for item in batch:
                if item.get("type") == "blob":
                    out.append(self._strip_prefix(item["path"]))
            if len(batch) < 100:
                break
            page += 1
        return out
