from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any


@dataclass
class MethodRef:
    name: str
    file: str
    kind: str = "function"          # "function" | "method" | "N/A"
    resolution: str = "static"      # "static" | "dispatch" | "llm" | "unresolved"
    note: str = ""
    called_from: List[str] = field(default_factory=list)   # file paths that call this method/function


@dataclass
class ResourceRef:
    kind: str          # "yaml" | "sql" | "ini"
    path: str
    tag: str = ""       # e.g. "insight_type" for si_*.yml, "config" etc.


@dataclass
class TaskNode:
    task_id: str                    # short id, e.g. "nlg_rules_asset_allocation_batch_1"
    full_task_id: str               # dotted id, e.g. "nlg_rules.nlg_rules_asset_allocation_batch_1"
    operator: str                   # "PythonOperator" | "PostgresOperator" | "BranchPythonOperator" | ...
    python_callable: Optional[str] = None
    methods: List[MethodRef] = field(default_factory=list)
    target_type: Optional[str] = None
    product: Optional[str] = None
    insight_types: List[str] = field(default_factory=list)
    resources: List[ResourceRef] = field(default_factory=list)
    op_kwargs: Dict[str, Any] = field(default_factory=dict)
    source_file: str = ""
    source_line: int = 0
    sql_snippet: Optional[str] = None

    def to_dict(self):
        return {
            "task_id": self.task_id,
            "full_task_id": self.full_task_id,
            "operator": self.operator,
            "python_callable": self.python_callable,
            "methods": [m.__dict__ for m in self.methods],
            "target_type": self.target_type,
            "product": self.product,
            "insight_types": self.insight_types,
            "resources": [r.__dict__ for r in self.resources],
            "source_file": self.source_file,
            "source_line": self.source_line,
            "sql_snippet": (self.sql_snippet[:300] + "...") if self.sql_snippet and len(self.sql_snippet) > 300 else self.sql_snippet,
        }


@dataclass
class TaskGroupNode:
    group_id: str
    full_group_id: str
    defined_in_function: str
    source_file: str
    tasks: List[TaskNode] = field(default_factory=list)
    subgroups: List["TaskGroupNode"] = field(default_factory=list)

    def to_dict(self):
        return {
            "group_id": self.group_id,
            "full_group_id": self.full_group_id,
            "defined_in_function": self.defined_in_function,
            "source_file": self.source_file,
            "tasks": [t.to_dict() for t in self.tasks],
            "subgroups": [g.to_dict() for g in self.subgroups],
        }


@dataclass
class DagNode:
    dag_id: str
    source_file: str
    description: str = ""
    schedule: Optional[str] = None
    groups: List[TaskGroupNode] = field(default_factory=list)
    tasks: List[TaskNode] = field(default_factory=list)   # top-level tasks not in any group
    triggers: List[str] = field(default_factory=list)     # other dag_ids triggered via TriggerDagRunOperator

    def to_dict(self):
        return {
            "dag_id": self.dag_id,
            "source_file": self.source_file,
            "description": self.description,
            "schedule": self.schedule,
            "groups": [g.to_dict() for g in self.groups],
            "tasks": [t.to_dict() for t in self.tasks],
            "triggers": self.triggers,
        }
