# dags/scripts/ikg_column_lineage_master_auto_refresh_task.py
# -*- coding: utf-8 -*-
"""
Airflow-callable wrapper around ``ikg_column_lineage_master_auto_refresh``.

Single-task execution: fetches all SQL files from GitLab, parses column-level
lineage, writes results to Greenplum and produces an Excel attachment.

**Dual-mode execution** (same pattern as ``ikg_lineage_sql_stitcher_task.py``
and ``odm_metadata_python_module.py``):

- *Airflow*: all credentials, schemas, and roles come from Airflow
  Variables / ``ikg.scripts.python.props``.
- *Local*: falls back to ``GENESIS_DDLC_IKG_GIT_SECRET`` /
  ``IKG_POSTGRES_CONN_ID`` environment variables or interactive prompts.

Returns an XCom-compatible dict:
    {
        "row_count":    <int>,
        "excel_path":   <str>,   # absolute path — consumed by EmailOperator
        "temp_dir":     <str>,   # absolute path — consumed by cleanup task
        "error_count":  <int>,
        "db_saved":     <bool>,
    }
"""

from __future__ import annotations

import datetime as dt
import logging
import os
from pathlib import Path
from typing import Any, Dict

# NOTE: Requires dags/scripts/ikg_column_lineage_master_auto_refresh.py to exist.
from ikg_column_lineage_master_auto_refresh import (
    run,
    is_running_in_airflow,
    get_private_token,
)

# ---------------------------------------------------------------------------
# Airflow detection — tolerate environments where Airflow is not installed
# ---------------------------------------------------------------------------
try:
    from airflow.models import Variable  # type: ignore
    _HAS_AIRFLOW = True
except Exception:  # noqa: BLE001
    Variable = None  # type: ignore
    _HAS_AIRFLOW = False

logger = logging.getLogger("ikg_column_lineage_master_auto_refresh")
logger.setLevel(logging.INFO)


def run_ikg_column_lineage_job(**context) -> Dict[str, Any]:
    """
    Airflow callable:
      - Calls ``run()`` from ikg_column_lineage_master_auto_refresh.py
        (no logic change — all parsing/DB/Excel logic stays in that module).
      - Moves the produced Excel into a shared temp folder so EmailOperator
        can attach it across workers/pods.
      - Returns excel_path + temp_dir via XCom for the existing DAG
        (email attachment + cleanup task).

    Temp folder pattern matches all other metadata jobs:
        <scripts_dir>/temp_ikg_column_lineage_<YYYYMMDD_HHMMSS>
    """
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    # ------------------------------------------------------------------ #
    # 1. Build temp directory under scripts/ (shared storage, not /tmp)   #
    # ------------------------------------------------------------------ #
    base_dir = os.path.dirname(os.path.abspath(__file__))
    timestamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d_%H%M%S")
    temp_dir = Path(os.path.join(base_dir, f"temp_ikg_column_lineage_{timestamp}"))
    temp_dir.mkdir(parents=True, exist_ok=True)
    logger.info("[IKG Column Lineage] Temporary folder created: %s", temp_dir)

    try:
        # ------------------------------------------------------------------ #
        # 2. Change working directory so run() writes Excel into temp_dir     #
        #    (run() uses a plain filename — cwd determines placement).        #
        # ------------------------------------------------------------------ #
        original_cwd = Path.cwd()
        os.chdir(str(temp_dir))

        try:
            private_token = get_private_token(allow_prompt=not is_running_in_airflow())

            # ------------------------------------------------------------- #
            # 3. Delegate ALL logic to the existing run() function.          #
            #    No logic is duplicated here.                                #
            # ------------------------------------------------------------- #
            excel_filename = run(
                private_token=private_token,
                allow_prompt=False,
            )
        finally:
            os.chdir(str(original_cwd))

        # ------------------------------------------------------------------ #
        # 4. Resolve the Excel path produced by run().                        #
        # ------------------------------------------------------------------ #
        if excel_filename is None:
            # run() returns None when no rows were found; create a sentinel
            # file so EmailOperator does not fail with a missing attachment.
            logger.warning(
                "[IKG Column Lineage] run() returned None — no rows found. "
                "Creating empty placeholder excel."
            )
            import pandas as pd
            placeholder = temp_dir / "ikg_column_lineage_master_auto_refresh_empty.xlsx"
            pd.DataFrame().to_excel(str(placeholder), index=False)
            excel_path = str(placeholder)
            row_count = 0
            db_saved = False
            error_count = 0
        else:
            # run() returns just the filename (no directory component).
            # Since we chdir'd into temp_dir before calling run(), the file
            # already lives in temp_dir.
            excel_src = temp_dir / Path(excel_filename).name
            if not excel_src.exists():
                # Fallback: maybe run() used an absolute path
                excel_src = Path(excel_filename)

            excel_path = str(excel_src)
            # Row count is not returned by run() directly; derive from Excel
            try:
                import pandas as pd
                df_check = pd.read_excel(excel_path, sheet_name="Column_Lineage", nrows=0)
                # Count rows by reading just the index
                import openpyxl
                wb = openpyxl.load_workbook(excel_path, read_only=True)
                ws = wb.active
                row_count = ws.max_row - 1 if ws.max_row else 0  # subtract header
                wb.close()
            except Exception as e:
                logger.warning("[IKG Column Lineage] Could not count rows from Excel: %s", e)
                row_count = -1

            db_saved = True
            error_count = 0

        logger.info(
            "[IKG Column Lineage] Done. rows=%s, excel=%s, temp_dir=%s",
            row_count, excel_path, temp_dir,
        )

        return {
            "row_count":   row_count,
            "excel_path":  excel_path,
            "temp_dir":    str(temp_dir),
            "error_count": error_count,
            "db_saved":    db_saved,
        }

    except Exception:
        logger.exception("[IKG Column Lineage] Task failed.")
        raise


# =============================================================================
# LOCAL EXECUTION — ``python ikg_column_lineage_master_auto_refresh_task.py``
# =============================================================================

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
    result = run_ikg_column_lineage_job()
    logger.info("Result: %s", result)
