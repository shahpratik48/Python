# dags/odm_metadata_dag.py
# -*- coding: utf-8 -*-

from __future__ import annotations

from pathlib import Path
import sys
from datetime import datetime

from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.operators.email import EmailOperator
from airflow.operators.postgres_operator import PostgresOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook

from airflow.models import Variable, Connection
from airflow.configuration import conf

# ---------------------------------------------------------
# Load shared Airflow variables
# ---------------------------------------------------------
from ikg.scripts.python import props
props = props.get_airflow_variables()

postgres_conn_id = Variable.get("IKG_POSTGRES_CONN_ID")
con = Connection.get_connection_from_secrets(postgres_conn_id)

# ---------------------------------------------------------
# Resolve environment label (Dev / Prod) for email subjects
# ---------------------------------------------------------
_base_url = conf.get("webserver", "base_url")
_uat_url = Variable.get("AIRFLOW_UAT_URL", default_var="")
_prod_url = Variable.get("AIRFLOW_PROD_URL", default_var="")
if _base_url == _uat_url:
    _ENV_LABEL = "Dev"
elif _base_url == _prod_url:
    _ENV_LABEL = "Prod"
else:
    _ENV_LABEL = "Unknown"

# ---------------------------------------------------------
# Allow import from sibling "scripts" directory
# ---------------------------------------------------------
_THIS_DIR = Path(__file__).resolve().parent
_SCRIPTS_DIR = _THIS_DIR / "scripts"
if str(_SCRIPTS_DIR) not in sys.path:
    sys.path.append(str(_SCRIPTS_DIR))

# ---------------------------------------------------------
# Existing metadata jobs
# ---------------------------------------------------------
from odm_metadata_python_module import (
    run_odm_metadata_job,
    run_nlg_profile_columns_metadata_job,
    run_nlg_rules_metadata_job,
    run_cid_profile_columns_metadata_job,
    run_ikg_table_lineage_metadata_job,
    cleanup_temp_folder,
)

# ---------------------------------------------------------
# NEW: IKG Lineage SQL Stitcher (separate script in scripts/)
# ---------------------------------------------------------
from ikg_lineage_sql_stitcher_task import run_ikg_lineage_sql_stitcher_job

# ---------------------------------------------------------
# NEW: IKG Column Lineage Master Auto Refresh
# ---------------------------------------------------------
from ikg_column_lineage_master_auto_refresh_task import run_ikg_column_lineage_job

# ---------------------------------------------------------
# DAG ID
# ---------------------------------------------------------
DAG_ID = "STAAT_Insight_Metadata"

# ---------------------------------------------------------
# EMAIL CONFIG
# ---------------------------------------------------------
EMAIL_RECIPIENTS = [
    "pratik.shah.2@ubs.com",
    "chintan.gandhi.2@ubs.com"
]

default_args = {
    "owner": "STAAT",
    "email_on_failure": True,
    "email_on_retry": False,
}

# ---------------------------------------------------------
# DAG DEFINITION
# ---------------------------------------------------------
with DAG(
    dag_id=DAG_ID,
    description="ODM + NLG + CID + IKG metadata generation with final IKG lineage SQL stitching and column lineage",
    schedule_interval="0 23 * * 5",  # Friday 23:00 UTC
    start_date=datetime(2025, 12, 1),
    catchup=False,
    default_args=default_args,
    tags=["ODM", "Metadata", "GitLab", "GPDB", "IKG", "Lineage"],
    render_template_as_native_obj=True,
) as dag:

    # -----------------------------
    # START
    # -----------------------------
    start = DummyOperator(task_id="start")

    # -----------------------------
    # ODM METADATA
    # -----------------------------
    generate_and_refresh = PythonOperator(
        task_id="generate_odm_metadata_and_refresh_db",
        python_callable=run_odm_metadata_job,
        do_xcom_push=True,
    )

    # -----------------------------
    # NLG PROFILE COLUMNS METADATA
    # -----------------------------
    nlg_metadata = PythonOperator(
        task_id="nlg_input_config_sql_mapping_metadata",
        python_callable=run_nlg_profile_columns_metadata_job,
        do_xcom_push=True,
    )

    # -----------------------------
    # NLG RULES METADATA
    # -----------------------------
    nlg_rules_metadata = PythonOperator(
        task_id="nlg_rules_metadata",
        python_callable=run_nlg_rules_metadata_job,
        do_xcom_push=True,
    )

    # -----------------------------
    # CID PROFILE COLUMNS METADATA
    # -----------------------------
    cid_columns_metadata = PythonOperator(
        task_id="cid_profile_columns_metadata",
        python_callable=run_cid_profile_columns_metadata_job,
        do_xcom_push=True,
    )

    # -----------------------------
    # IKG TABLE LINEAGE METADATA
    # -----------------------------
    ikg_table_lineage_metadata = PythonOperator(
        task_id="ikg_table_lineage_metadata",
        python_callable=run_ikg_table_lineage_metadata_job,
        do_xcom_push=True,
    )

    # -----------------------------
    # POST-PROCESSING SQL STEPS
    # -----------------------------
    nlg_combined_metadata_auto_refresh = PostgresOperator(
        task_id="nlg_combined_metadata_auto_refresh",
        sql="scripts/nlg_combined_metadata_auto_refresh.sql",
        postgres_conn_id=postgres_conn_id,
        params=props,
    )

    ikg_dictionary_metadata_auto_refresh = PostgresOperator(
        task_id="ikg_dictionary_metadata_auto_refresh",
        sql="scripts/ikg_dictionary_metadata_auto_refresh.sql",
        postgres_conn_id=postgres_conn_id,
        params=props,
    )

    # -----------------------------
    # IKG LINEAGE SQL STITCH
    # Single task that processes all profile tables in one go.
    # -----------------------------
    ikg_lineage_sql_stitch = PythonOperator(
        task_id="ikg_lineage_sql_stitch",
        python_callable=run_ikg_lineage_sql_stitcher_job,
        do_xcom_push=True,
    )

    # -----------------------------
    # NEW: IKG COLUMN LINEAGE
    # Runs after ikg_lineage_sql_stitch.
    # Creates ikg_column_lineage_master_auto_refresh table in Greenplum.
    # -----------------------------
    ikg_column_lineage = PythonOperator(
        task_id="ikg_column_lineage",
        python_callable=run_ikg_column_lineage_job,
        do_xcom_push=True,
    )

    # -----------------------------
    # ARCHIVE TABLES
    # -----------------------------
    create_archive_tables = PostgresOperator(
        task_id="create_archive_tables",
        sql="scripts/create_archive_tables.sql",
        postgres_conn_id=postgres_conn_id,
        params=props,
    )

    # -----------------------------
    # EMAIL (SUCCESS)
    # -----------------------------
    send_email = EmailOperator(
        task_id="send_metadata_email",
        to=EMAIL_RECIPIENTS,
        subject=f"ODM + NLG + CID + IKG Lineage (Final SQL Stitch + Column Lineage) | Success | {_ENV_LABEL}",
        params=props,
        html_content="""
        <br>Hi Team,<br><br>

        {% set odm = ti.xcom_pull(task_ids='generate_odm_metadata_and_refresh_db') or {} %}
        {% set nlg = ti.xcom_pull(task_ids='nlg_input_config_sql_mapping_metadata') or {} %}
        {% set rules = ti.xcom_pull(task_ids='nlg_rules_metadata') or {} %}
        {% set cid = ti.xcom_pull(task_ids='cid_profile_columns_metadata') or {} %}
        {% set lineage = ti.xcom_pull(task_ids='ikg_table_lineage_metadata') or {} %}
        {% set stitch = ti.xcom_pull(task_ids='ikg_lineage_sql_stitch') or {} %}
        {% set col_lineage = ti.xcom_pull(task_ids='ikg_column_lineage') or {} %}

        <b>IKG Lineage SQL Stitch (FINAL):</b><br>
        Profiles processed: {{ stitch.get('profile_table_count', 0) }}<br>
        Total lineage rows: {{ stitch.get('row_count', 0) }}<br>
        SQL executed: {{ stitch.get('executed', False) }}<br><br>

        <b>IKG Column Lineage Master Auto Refresh:</b><br>
        Total column lineage rows: {{ col_lineage.get('row_count', 0) }}<br>
        Saved to DB: {{ col_lineage.get('db_saved', False) }}<br>
        Parse errors: {{ col_lineage.get('error_count', 0) }}<br><br>

        <b>Tables refreshed:</b><br>
        <code>{{params.IKG_SCHEMA}}.ikg_table_lineage_metadata_auto_refresh</code><br>
        <code>{{params.IKG_SCHEMA}}.ikg_dictionary_metadata_auto_refresh</code><br>
        <code>{{params.IKG_SCHEMA}}.ikg_column_lineage_master_auto_refresh</code><br><br>

        Regards,<br>
        STAAT Insights Team
        """,
        files=[
            "{{ ti.xcom_pull(task_ids='generate_odm_metadata_and_refresh_db')['excel_path'] }}",
            "{{ ti.xcom_pull(task_ids='nlg_input_config_sql_mapping_metadata')['excel_path'] }}",
            "{{ ti.xcom_pull(task_ids='nlg_rules_metadata')['excel_path'] }}",
            "{{ ti.xcom_pull(task_ids='cid_profile_columns_metadata')['excel_path'] }}",
            "{{ ti.xcom_pull(task_ids='ikg_table_lineage_metadata')['excel_path'] }}",
            # ZIP containing stitched lineage excels (one per profile table)
            "{{ ti.xcom_pull(task_ids='ikg_lineage_sql_stitch')['excel_path'] }}",
            # Column lineage Excel
            "{{ ti.xcom_pull(task_ids='ikg_column_lineage')['excel_path'] }}",
        ],
    )

    # -----------------------------
    # CLEANUP
    # -----------------------------
    cleanup = PythonOperator(
        task_id="cleanup_temp_folder",
        python_callable=cleanup_temp_folder,
        op_kwargs={
            "temp_dir": [
                "{{ ti.xcom_pull(task_ids='generate_odm_metadata_and_refresh_db')['temp_dir'] }}",
                "{{ ti.xcom_pull(task_ids='nlg_input_config_sql_mapping_metadata')['temp_dir'] }}",
                "{{ ti.xcom_pull(task_ids='nlg_rules_metadata')['temp_dir'] }}",
                "{{ ti.xcom_pull(task_ids='cid_profile_columns_metadata')['temp_dir'] }}",
                "{{ ti.xcom_pull(task_ids='ikg_table_lineage_metadata')['temp_dir'] }}",
                "{{ ti.xcom_pull(task_ids='ikg_lineage_sql_stitch')['temp_dir'] }}",
                "{{ ti.xcom_pull(task_ids='ikg_column_lineage')['temp_dir'] }}",
            ]
        },
    )

    # -----------------------------
    # END
    # -----------------------------
    end = DummyOperator(task_id="end")

    # -----------------------------
    # DAG FLOW (AUTHORITATIVE)
    # -----------------------------
    (
        start
        >> generate_and_refresh
        >> nlg_metadata
        >> nlg_rules_metadata
        >> cid_columns_metadata
        >> ikg_table_lineage_metadata
        >> nlg_combined_metadata_auto_refresh
        >> ikg_dictionary_metadata_auto_refresh
        >> ikg_lineage_sql_stitch
        >> ikg_column_lineage
        >> create_archive_tables
        >> send_email
        >> cleanup
        >> end
    )
