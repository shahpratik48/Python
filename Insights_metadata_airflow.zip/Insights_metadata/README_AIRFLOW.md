# Insights_metadata - Airflow edition

Same program as the notebook edition (`scripts/ikgmeta` is byte-identical): business metadata for the IKG profile
tables, the ODM tables and the NLG tables (delta against `core_ikg.ikg_attribute_business_description`), the
knowledge graph with the ODM / NLG diagrams, the `_v2` profile clones, the glossary and graph tables.

```
Insights_metadata/                    <- copy this folder into the Airflow dags folder
  Insights_metadata.py                DAG id Insights_metadata: start >> run_insights_metadata >> send_metadata_email >> end
  README_AIRFLOW.md
  scripts/
    ikgmeta/                          the package (identical to the notebook edition)
    config/ikg_metadata_config.yaml   same config file; the airflow: block names the Variables / Connection
    prompts/  skills/  samples/
    EDW Data Dictionary.xlsx          <- put the EDW data dictionary here (sources.edw_data_dictionary)
    requirements.txt
```

## Schedule and tasks
- `schedule_interval = "0 6 * * 1-5"` with `start_date = pendulum.datetime(2026, 1, 1, tz="America/New_York")`
  -> every Monday to Friday at 06:00 US Eastern (EST / EDT automatically), `catchup=False`, `max_active_runs=1`.
- `run_insights_metadata` (PythonOperator): builds the config from the Variables / Connection and runs
  `ikgmeta.airflow_runner.run_insights_metadata` = `agents.prepare` + `agents.run` (exactly the notebook steps:
  sources -> parse profile scripts + ODM / NLG tables -> evidence -> glossary -> skill / dictionary / code / author /
  reviewer / graph agents -> workbook, graph + diagrams, clones, Greenplum load). Pushes a summary to XCom.
- `send_metadata_email` (EmailOperator): subject `Insights metadata (IKG / ODM / NLG) | Success | <env> | <ds>`,
  HTML summary (environment / schema / roles, tables, delta, skipped ODM / NLG tables, High / Medium / Low, Greenplum
  load, every table refreshed incl. `_v2`, tokens), attachments = `Insights_attribute_metadata.xlsx`,
  `knowledge_graph.html`, `profile_table_clones.sql.txt`, `token_stats.txt`, `refreshed_tables.sql.txt`,
  `log_<timestamp>.txt`, `run_summary.json` (each when < 15 MB). Failures of the run task raise -> `email_on_failure` to the
  same recipients (`EMAIL_RECIPIENTS` at the top of the DAG file).

## Airflow Variables and Connection
| Name | Value | Used for |
|---|---|---|
| `ODM_ENV` | `PROD`, `UAT` or `TEST` | PROD -> IKG_SCHEMA `core_ikg`, NLG ini `[prod_active]` (`schema_nlg = core_nlg`), owner `erd_gpdb_prj_ikg` / reader `erd_gpdb_prj_ikg_ro`; UAT -> `sandbox_ikg_pre_prd`, `[dev_active]` (`schema_nlg = sandbox_prj_insights_nlg`), owner `erd_gpdb_prj_smart_insights` / reader `erd_gpdb_prj_smart_insights_ro`; TEST -> `sandbox_prj_smart_insights`, `[dev_review]` (`schema_nlg = sandbox_prj_insights_nlg`), same roles as UAT (`environments:` block of the config) |
| `IKG_SCHEMA` | optional, e.g. `core_ikg` | overrides the schema of the profile tables, ODM tables, metadata / graph / clone tables (`greenplum.schema`, `output.target_schema`, `domains.odm.schema`, lineage + description tables) |
| `IKG_TABLE_OWNER_GROUP` | optional, e.g. `erd_gpdb_prj_ikg` | `ALTER TABLE <IKG_SCHEMA>.<table> OWNER TO ...` for every table this program creates (metadata, glossary, graph tables, `_v2` clones) |
| `IKG_TABLE_READER_GROUP` | optional, e.g. `erd_gpdb_prj_ikg_ro` | `GRANT SELECT ON <IKG_SCHEMA>.<table> TO ...` for the same tables |
| `EDW_INPUT_SCHEMA` | `core_wma_shared` | EDW tables in Greenplum used for upstream hopping of ODM / NLG columns (`domains.edw_input_schema`) |
| `GENESIS_DDLC_IKG_GIT_SECRET` | GitLab token (read_api on ikg-dags, odm-dags, nlg-dags) | repository download |
| `IKG_AZURE_OPENAI_API_KEY` | Azure OpenAI key | model calls (create this Variable; it is never written to a file) |
| `INSIGHTS_METADATA_OUTPUT_DIR` | optional folder, e.g. `/opt/airflow/data/cid/insights_metadata` | output folder (workbook, graph + markdown pages, log, token stats, caches, generated skill files); default `/opt/airflow/data/insights_metadata` when writable, else `<tmp>/insights_metadata`. Keep it persistent: the repository and LLM caches make the daily delta run a 3-8 minute job |
| Connection `IKG_GP_GPRDSP` | type Postgres: host `greenplum-rdsp.zur.swissbank.com`, port 5432, schema (= database) `gprdsp`, login, password | Greenplum |

The names are configurable in `scripts/config/ikg_metadata_config.yaml` (`airflow:` block). Secrets are read
into memory for the run only (`ikgmeta.config.set_secret`); they never appear in XCom, logs, the summary or files.

## Scope and daily budget
The run covers the profile tables, the ODM tables, the NLG tables and every intermediate IKG table named by the
lineage query (`generation.ikg_lineage_tables_sql`). `generation.max_new_attributes_per_run` (400) and
`time_budget_minutes` (10) keep each daily run inside 5-10 minutes: new attributes beyond the budget are a backlog
for the next run (shown in the e-mail and in Delta_Summary). The workbook and the metadata table are written
first, then the graph / markdown pages, then the `_v2` clones.

The time budget counts from the start of the run (sources, evidence and glossary included); `min_tables_per_run` (8)
tables are always authored. The dictionary agent resolves only the tokens of the attributes authored this run, and
published intermediate (lineage-scope) attributes get no evidence pack, so a daily delta run stays inside the budget.

## Deployment
1. Unzip, put the folder `Insights_metadata/` into the dags folder (e.g. `/opt/airflow/dags/Insights_metadata/`).
2. Install the requirements in the Airflow workers / pod image: `pip install -r Insights_metadata/scripts/requirements.txt`
   (openai, sqlalchemy, psycopg2, pandas, openpyxl, sqlglot, pyyaml, networkx, matplotlib, requests).
3. Copy `EDW Data Dictionary.xlsx` to `Insights_metadata/scripts/` (or set `sources.edw_data_dictionary` to an absolute path).
4. Create the Variables / Connection above. Optional: `Insights_metadata/scripts/config/ikg_metadata_config.yaml`
   (model deployment, parallel calls, `domains.nlg.exclude_tables`, e-mail recipients in the DAG file).
5. Trigger the DAG once manually; check `run_insights_metadata` logs and the e-mail. The first run downloads the
   three repositories and authors everything that is not yet in the metadata table; later runs are deltas.

Notes: the DAG folder is usually read-only for the workers - generated skill files go to `<output>/skills/`
(`skills.generated_folder`), the LLM / repository caches to `<output>/cache/`. Keep the output folder between runs
to reuse the caches (set `INSIGHTS_METADATA_OUTPUT_DIR` to a persistent path).

## Backfill (draining the lineage-scope backlog)
Variable `INSIGHTS_METADATA_BACKFILL_RUNS` (default 1) = budgeted runs executed back to back inside ONE DAG run
(each ~10 min, each a complete run that re-reads the metadata table, so nothing is re-authored); optional
`INSIGHTS_METADATA_BACKFILL_MINUTES` stops it after that many minutes. Set it to e.g. 6 until the e-mail reports
backlog 0, then back to 1. The `Lineage_Scope` sheet of the workbook shows every table of the lineage query with
columns, published, missing and status.
