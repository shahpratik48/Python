# Insights_metadata - Airflow edition

Same program as the notebook edition (`scripts/ikgmeta` is byte-identical): business metadata for the IKG profile
tables, the ODM tables and the NLG tables (delta against `core_ikg.ikg_attribute_business_description`), the
knowledge graph with the ODM / NLG diagrams, the `_v2` profile clones, the glossary and graph tables.

```
Insights_metadata/                    <- copy this folder into the Airflow dags folder
  Insights_metadata.py                DAG id Insights_metadata: start >> run_insights_metadata >> send_metadata_email >> end
  README_AIRFLOW.md
  scripts/
    ikgmeta/                          the package (identical to the notebook edition)
    config/ikg_metadata_config.yaml   same config file; the airflow: block names the Variables / Connection
    prompts/  skills/  samples/
    EDW Data Dictionary.xlsx          <- put the EDW data dictionary here (sources.edw_data_dictionary)
    requirements.txt
```

## Schedule and tasks
- `schedule_interval = "0 6 * * 1-5"` with `start_date = pendulum.datetime(2026, 1, 1, tz="America/New_York")`
  -> every Monday to Friday at 06:00 US Eastern (EST / EDT automatically), `catchup=False`, `max_active_runs=1`.
- `run_insights_metadata` (PythonOperator): builds the config from the Variables / Connection and runs
  `ikgmeta.airflow_runner.run_insights_metadata` = `agents.prepare` + `agents.run` (exactly the notebook steps:
  sources -> parse profile scripts + ODM / NLG tables -> evidence -> glossary -> skill / dictionary / code / author /
  reviewer / graph agents -> workbook, graph + diagrams, clones, Greenplum load). Pushes a summary to XCom.
- `send_metadata_email` (EmailOperator): subject `Insights metadata (IKG / ODM / NLG) | Success | <env> | <ds>`,
  HTML summary (tables, delta, skipped ODM / NLG tables, High / Medium / Low, Greenplum load, paths), attachments
  = workbook (when < 15 MB) + `run_summary.json`. Failures of the run task raise -> `email_on_failure` to the
  same recipients (`EMAIL_RECIPIENTS` at the top of the DAG file).

## Airflow Variables and Connection
| Name | Value | Used for |
|---|---|---|
| `ODM_ENV` | `PROD`, `UAT` or `TEST` | PROD -> IKG_SCHEMA `core_ikg`, NLG ini `[prod_active]` (`schema_nlg = core_nlg`), owner `erd_gpdb_prj_ikg` / reader `erd_gpdb_prj_ikg_ro`; UAT -> `sandbox_ikg_pre_prd`, `[dev_active]` (`schema_nlg = sandbox_prj_insights_nlg`), owner `erd_gpdb_prj_smart_insights` / reader `erd_gpdb_prj_smart_insights_ro`; TEST -> `sandbox_prj_smart_insights`, `[dev_review]` (`schema_nlg = sandbox_prj_insights_nlg`), same roles as UAT (`environments:` block of the config) |
| `IKG_SCHEMA` | optional, e.g. `core_ikg` | overrides the schema of the profile tables, ODM tables, metadata / graph / clone tables (`greenplum.schema`, `output.target_schema`, `domains.odm.schema`, lineage + description tables) |
| `IKG_TABLE_OWNER_GROUP` | optional, e.g. `erd_gpdb_prj_ikg` | `ALTER TABLE <IKG_SCHEMA>.<table> OWNER TO ...` for every table this program creates (metadata, glossary, graph tables, `_v2` clones) |
| `IKG_TABLE_READER_GROUP` | optional, e.g. `erd_gpdb_prj_ikg_ro` | `GRANT SELECT ON <IKG_SCHEMA>.<table> TO ...` for the same tables |
| `EDW_INPUT_SCHEMA` | `core_wma_shared` | EDW tables in Greenplum used for upstream hopping of ODM / NLG columns (`domains.edw_input_schema`) |
| `GENESIS_DDLC_IKG_GIT_SECRET` | GitLab token (read_api on ikg-dags, odm-dags, nlg-dags) | repository download |
| `IKG_AZURE_OPENAI_API_KEY` | Azure OpenAI key | model calls (create this Variable; it is never written to a file) |
| `INSIGHTS_METADATA_OUTPUT_DIR` | optional folder, e.g. `/opt/airflow/data/cid/insights_metadata` | output folder (workbook, graph, diagrams, cache, generated skill files); default `<tmp>/insights_metadata` |
| Connection `IKG_GP_GPRDSP` | type Postgres: host `greenplum-rdsp.zur.swissbank.com`, port 5432, schema (= database) `gprdsp`, login, password | Greenplum |

The names are configurable in `scripts/config/ikg_metadata_config.yaml` (`airflow:` block). Secrets are read
into memory for the run only (`ikgmeta.config.set_secret`); they never appear in XCom, logs, the summary or files.

## Deployment
1. Unzip, put the folder `Insights_metadata/` into the dags folder (e.g. `/opt/airflow/dags/Insights_metadata/`).
2. Install the requirements in the Airflow workers / pod image: `pip install -r Insights_metadata/scripts/requirements.txt`
   (openai, sqlalchemy, psycopg2, pandas, openpyxl, sqlglot, pyyaml, networkx, matplotlib, requests).
3. Copy `EDW Data Dictionary.xlsx` to `Insights_metadata/scripts/` (or set `sources.edw_data_dictionary` to an absolute path).
4. Create the Variables / Connection above. Optional: `Insights_metadata/scripts/config/ikg_metadata_config.yaml`
   (model deployment, parallel calls, `domains.nlg.exclude_tables`, e-mail recipients in the DAG file).
5. Trigger the DAG once manually; check `run_insights_metadata` logs and the e-mail. The first run downloads the
   three repositories and authors everything that is not yet in the metadata table; later runs are deltas.

Notes: the DAG folder is usually read-only for the workers - generated skill files go to `<output>/skills/`
(`skills.generated_folder`), the LLM / repository caches to `<output>/cache/`. Keep the output folder between runs
to reuse the caches (set `INSIGHTS_METADATA_OUTPUT_DIR` to a persistent path).
