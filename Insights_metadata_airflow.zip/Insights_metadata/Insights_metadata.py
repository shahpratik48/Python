"""
Insights_metadata - Airflow DAG (one task + completion e-mail)

Generates business metadata for the IKG profile tables, the ODM tables and the NLG tables (delta only: attributes
not yet in core_ikg.ikg_attribute_business_description), the knowledge graph (+ ODM / NLG diagrams) and the _v2
profile clones - the same logic as the IKG_Metadata_Agents notebook (scripts/ikgmeta).

Schedule: Monday to Friday 06:00 US Eastern (America/New_York).

Airflow Variables                           Connection
  ODM_ENV                  PROD | UAT | TEST  IKG_GP_GPRDSP   Greenplum (host, port, schema = database, login, password)
      PROD -> IKG_SCHEMA core_ikg,                 NLG ini [prod_active], owner erd_gpdb_prj_ikg / reader erd_gpdb_prj_ikg_ro
      UAT  -> IKG_SCHEMA sandbox_ikg_pre_prd,      NLG ini [dev_active],  owner erd_gpdb_prj_smart_insights / reader ..._ro
      TEST -> IKG_SCHEMA sandbox_prj_smart_insights, NLG ini [dev_review], owner erd_gpdb_prj_smart_insights / reader ..._ro
  IKG_SCHEMA               optional override of the schema above
  IKG_TABLE_OWNER_GROUP    optional override: ALTER TABLE ... OWNER TO (every table this program creates in IKG_SCHEMA)
  IKG_TABLE_READER_GROUP   optional override: GRANT SELECT ... TO
  EDW_INPUT_SCHEMA         core_wma_shared
  GENESIS_DDLC_IKG_GIT_SECRET   GitLab token (read_api on ikg-dags, odm-dags, nlg-dags)
  IKG_AZURE_OPENAI_API_KEY      Azure OpenAI key
  INSIGHTS_METADATA_OUTPUT_DIR  optional output folder (default <tmp>/insights_metadata)
The Variable / Connection names can be changed in scripts/config/ikg_metadata_config.yaml (airflow:).
"""
import json
import os
import sys
from datetime import timedelta

import pendulum
from airflow import DAG
from airflow.configuration import conf
from airflow.models import Connection, Variable
from airflow.operators.email import EmailOperator
from airflow.operators.python import PythonOperator

try:
    from airflow.operators.empty import EmptyOperator
except ImportError:  # Airflow < 2.4
    from airflow.operators.dummy import DummyOperator as EmptyOperator

DAG_ID = "Insights_metadata"
DAG_DIR = os.path.dirname(os.path.abspath(__file__))
SCRIPTS_DIR = os.path.join(DAG_DIR, "scripts")
if SCRIPTS_DIR not in sys.path:
    sys.path.insert(0, SCRIPTS_DIR)

EMAIL_RECIPIENTS = ["pratik.shah.2@ubs.com", "chintan.gandhi.2@ubs.com"]

# environment label for the e-mail subject (same convention as odm_metadata_dag.py)
try:
    _base_url = conf.get("webserver", "base_url")
    if _base_url == Variable.get("AIRFLOW_UAT_URL", default_var="__none__"):
        _ENV_LABEL = "UAT"
    elif _base_url == Variable.get("AIRFLOW_PROD_URL", default_var="__none__"):
        _ENV_LABEL = "PROD"
    else:
        _ENV_LABEL = Variable.get("ODM_ENV", default_var="UAT")
except Exception:  # noqa: BLE001
    _ENV_LABEL = "DEV"


def _airflow_names():
    """Variable / Connection names from the package config (airflow: block), with the documented defaults."""
    try:
        import yaml
        with open(os.path.join(SCRIPTS_DIR, "config", "ikg_metadata_config.yaml"), encoding="utf-8") as fh:
            a = (yaml.safe_load(fh) or {}).get("airflow") or {}
    except Exception:  # noqa: BLE001
        a = {}
    v = a.get("variables") or {}
    return {"env": v.get("env", "ODM_ENV"), "ikg_schema": v.get("ikg_schema", "IKG_SCHEMA"),
            "table_owner_role": v.get("table_owner_role", "IKG_TABLE_OWNER_GROUP"),
            "table_reader_role": v.get("table_reader_role", "IKG_TABLE_READER_GROUP"),
            "edw_input_schema": v.get("edw_input_schema", "EDW_INPUT_SCHEMA"),
            "gitlab_token": v.get("gitlab_token", "GENESIS_DDLC_IKG_GIT_SECRET"),
            "azure_openai_key": v.get("azure_openai_key", "IKG_AZURE_OPENAI_API_KEY"),
            "output_dir": v.get("output_dir", "INSIGHTS_METADATA_OUTPUT_DIR"),
            "connection": a.get("connection", "IKG_GP_GPRDSP")}


def run_insights_metadata(**context):
    """The single task: builds the config from Airflow Variables / Connection and runs the whole program."""
    from ikgmeta import airflow_runner

    n = _airflow_names()
    env = Variable.get(n["env"], default_var="PROD")
    conn = Connection.get_connection_from_secrets(n["connection"])
    gp = {"host": conn.host, "port": conn.port or 5432, "database": conn.schema, "user": conn.login, "password": conn.password}
    summary = airflow_runner.run_insights_metadata(
        env=env,
        ikg_schema=Variable.get(n["ikg_schema"], default_var=None),
        owner_role=Variable.get(n["table_owner_role"], default_var=None),
        reader_role=Variable.get(n["table_reader_role"], default_var=None),
        edw_input_schema=Variable.get(n["edw_input_schema"], default_var=None),
        gitlab_token=Variable.get(n["gitlab_token"]),
        azure_key=Variable.get(n["azure_openai_key"]),
        gp=gp,
        output_dir=Variable.get(n["output_dir"], default_var=None),
        run_id=str(context.get("run_id", "")),
    )
    # secrets never go to XCom / logs; the summary holds paths and counts only
    print(json.dumps({k: v for k, v in summary.items() if k not in ("email_html",)}, indent=1, default=str))
    return summary


default_args = {
    "owner": "STAAT",
    "email": EMAIL_RECIPIENTS,
    "email_on_failure": True,
    "email_on_retry": False,
    "retries": 0,
    "retry_delay": timedelta(minutes=10),
}

with DAG(
    dag_id=DAG_ID,
    description="Business metadata for IKG profile, ODM and NLG tables + knowledge graph + _v2 clones (delta, daily)",
    schedule_interval="0 6 * * 1-5",                       # Monday - Friday 06:00 America/New_York (EST / EDT)
    start_date=pendulum.datetime(2026, 1, 1, tz="America/New_York"),
    catchup=False,
    max_active_runs=1,
    dagrun_timeout=timedelta(hours=12),
    default_args=default_args,
    tags=["IKG", "ODM", "NLG", "metadata", "STAAT"],
    render_template_as_native_obj=True,
) as dag:
    start = EmptyOperator(task_id="start")

    t_run = PythonOperator(
        task_id="run_insights_metadata",
        python_callable=run_insights_metadata,
        provide_context=True,
        do_xcom_push=True,
    )

    t_email = EmailOperator(
        task_id="send_metadata_email",
        to=EMAIL_RECIPIENTS,
        subject=f"Insights metadata (IKG / ODM / NLG) | Success | {_ENV_LABEL}" + " | {{ ds }}",
        html_content="{{ ti.xcom_pull(task_ids='run_insights_metadata')['email_html'] }}",
        files="{{ ti.xcom_pull(task_ids='run_insights_metadata')['attachments'] }}",
    )

    end = EmptyOperator(task_id="end")

    start >> t_run >> t_email >> end
