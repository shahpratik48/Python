"""Agent-based IKG metadata + knowledge graph generation."""
from __future__ import annotations

import logging

from ..pipeline import MetadataPipeline
from .context import AgentContext
from .master import MasterAgent, Orchestrator

log = logging.getLogger(__name__)


def prepare(cfg, llm, gp=None, refresh_code: bool = False):
    """Deterministic data layer every agent works on: sources, parsed code, evidence, base glossary."""
    import time
    p = MetadataPipeline(cfg, llm=None, gp=gp)
    p.started_at = time.time()                # the time budget counts from here (whole program, not only the agents)
    p.load_sources(refresh_code=refresh_code)
    p.parse_code()
    if gp is not None and cfg.output.get("load_to_greenplum", False):
        from ..db_sync import GreenplumSync
        p.prepare_evidence_skip(GreenplumSync(gp, cfg))
    p.build_evidence()
    p.build_glossary(use_llm=False)          # EDW / code / skill evidence first; agents resolve the rest
    p.active_tables = sorted(p.schemas)
    p.prefilled = {}
    p.delta_info = {"mode": "full"}
    if gp is not None and cfg.output.get("load_to_greenplum", False):
        from ..db_sync import GreenplumSync
        try:
            if str(cfg.generation.get("mode", "delta")) == "delta":
                p.restrict_to_delta(GreenplumSync(gp, cfg))
            else:
                p.apply_domain_skip_rules(GreenplumSync(gp, cfg))     # full mode: ODM / NLG skip rules still apply
        except Exception as e:  # noqa: BLE001
            log.warning("delta comparison against Greenplum failed (%s) - running in full mode", e)
    # ODM / NLG knowledge skill files: written ONCE from the repository when absent (never recreated)
    if (cfg.get("domains") or {}).get("generate_missing_skill_files", True) and llm is not None:
        from ..skill_writer import ensure_domain_skills
        try:
            ensure_domain_skills(cfg, llm, p)
        except Exception as e:  # noqa: BLE001
            log.warning("skill file generation failed (%s) - continuing with the skill files present", e)
    ctx = AgentContext(cfg, llm, p)
    log.info("Agent context ready: %d tables, %d attributes, %d skill files", len(p.schemas), len(p.ctx),
             len(ctx.skills.files))
    return ctx


def run(ctx: AgentContext, mode: str = None) -> dict:
    mode = mode or ctx.cfg.get("agents", {}).get("orchestration", "llm")
    orch = Orchestrator(ctx)
    if mode == "deterministic":
        out = orch.run_deterministic(int(ctx.cfg.get("agents", {}).get("escalation_rounds", 1)))
    else:
        summary = MasterAgent(ctx, orch).execute()
        out = {"master_summary": summary, **({"workbook": str(ctx.p.out / ctx.cfg.output["metadata_xlsx"])})}
        if not ctx.stage_done.get("outputs"):
            missing = [s for s in ("skills", "dictionary", "author", "review", "graph") if not ctx.stage_done.get(s)]
            log.warning("master agent finished without writing outputs (stages not done: %s) - "
                        "completing deterministically", missing)
            out.update(orch.complete())
    out["quality"] = orch.quality()
    out["refreshed_tables_list"] = getattr(orch, "refreshed_tables", [])
    return out


def backlog_of(ctx: AgentContext) -> dict:
    """What this run left for the next one: budget backlog + tables deferred by the time budget."""
    di = getattr(ctx.p, "delta_info", {}) or {}
    return {"attributes": int(di.get("backlog_attributes_for_next_runs", 0) or 0),
            "tables": list(di.get("backlog_tables_for_next_runs_all") or di.get("backlog_tables_for_next_runs") or []),
            "deferred_tables": list(di.get("deferred_by_time_budget") or [])}


def run_until_done(cfg, llm, gp=None, max_runs: int = 1, max_minutes: float = 0, mode: str = None,
                   refresh_code: bool = False):
    """Backfill: repeat prepare() + run() - each iteration is one budgeted run that writes the workbook, loads the
    metadata table and rebuilds the outputs - until nothing is left (backlog 0, nothing deferred), max_runs
    iterations or max_minutes are reached. Every iteration re-reads the metadata table, so it never re-authors what
    an earlier iteration published; interrupting between iterations loses nothing."""
    import time
    t0, runs = time.time(), []
    ctx = res = None
    for i in range(1, max(1, int(max_runs)) + 1):
        ctx = prepare(cfg, llm, gp, refresh_code=refresh_code and i == 1)
        res = run(ctx, mode)
        left = backlog_of(ctx)
        di = ctx.p.delta_info or {}
        runs.append({"run": i, "authored": int(di.get("to_author", 0) or 0), "new_pairs": int(di.get("new_pairs", 0) or 0),
                     "backlog_attributes": left["attributes"], "backlog_tables": len(left["tables"]),
                     "deferred_tables": len(left["deferred_tables"]), "minutes": round((time.time() - t0) / 60, 1)})
        log.info("backfill run %d/%d: %s", i, max_runs, runs[-1])
        if not left["attributes"] and not left["deferred_tables"]:
            log.info("backfill complete: nothing left for the next run")
            break
        if max_minutes and (time.time() - t0) / 60 >= float(max_minutes):
            log.info("backfill stopped after %.0f min (max_minutes); %d attributes in %d tables remain",
                     (time.time() - t0) / 60, left["attributes"], len(left["tables"]))
            break
    res = dict(res or {})
    res["backfill_runs"] = runs
    res["backlog"] = backlog_of(ctx) if ctx else {}
    return ctx, res
