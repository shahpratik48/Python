"""
IKG profile attribute metadata pipeline.

  step 1  load_sources()     GitLab code, Greenplum lineage + table descriptions + information_schema,
                             EDW data dictionary, business definitions, SME overrides, entity model
  step 2  parse_code()       exact column list / expression / type for every profile table (sqlglot)
                             + ODM / NLG tables (domains.py): columns from information_schema, code evidence
  step 3  build_evidence()   per column: lineage (lineage table + code), filters, EDW definitions,
                             python writers, glossary expansion
  step 4  build_glossary()   abbreviations: SME > EDW alignment > code aliases > LLM > NEEDS_INPUT
  step 5  analyze_tables()   LLM reads the COMPLETE create script of each profile table
  step 6  generate()         LLM column metadata (table SQL + analysis as cached prefix)
  step 7  verify()           LLM reviewer re-checks every non-High attribute against evidence
  step 8  score()            composite confidence (LLM rubric + deterministic evidence) + what is required
  step 9  write()            Excel workbook (+ optional Greenplum tables)
"""
from __future__ import annotations

import concurrent.futures as cf
import json
import logging
import re
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd
import yaml

from . import sources as src
from . import sql_parser as sqlp
from .domains import DomainLoader
from .code_lineage import LineageResolver
from .config import Config, PACKAGE_ROOT
from .glossary import Glossary, tokenize
from .lineage import EdwDictionary, LineageTableWalker, python_writers
from .llm import LLM
from .sql_parser import extract_table_schema

log = logging.getLogger(__name__)
PROMPTS = PACKAGE_ROOT / "prompts"
PRIMARY_TABLES = {"household_profile_curr_ikg", "client_profile_curr_ikg", "account_profile_curr_ikg"}

ATTRIBUTE_TYPES = {"identifier", "foreign_key", "name_text", "date", "amount", "quantity", "count", "percentage",
                   "ratio", "rate", "flag", "code", "category", "score", "rank", "text", "technical"}


def _prompt(name: str) -> str:
    return (PROMPTS / name).read_text(encoding="utf-8")


class MetadataPipeline:
    def __init__(self, cfg: Config, llm: Optional[LLM] = None, gp: Optional[src.Greenplum] = None):
        self.cfg = cfg
        self.out = cfg.path(cfg.output["folder"])
        self.out.mkdir(parents=True, exist_ok=True)
        self.cache = self.out / "cache"
        self.env = str(cfg.get("environment", "PROD") or "PROD").upper()
        self.gitlab = src.GitLabCode(cfg, self.cache, "ikg")
        self.repos: Dict[str, src.GitLabCode] = {"ikg": self.gitlab}
        for d in ("odm", "nlg"):
            dc = (cfg.get("domains") or {}).get(d) or {}
            if dc.get("enabled") and dc.get("gitlab"):
                self.repos[d] = src.GitLabCode(dc["gitlab"], self.cache, d)
        self.table_domain: Dict[str, str] = {}          # odm / nlg tables -> domain ("ikg" otherwise)
        self.table_schema_map: Dict[str, str] = {}
        self.domain_tables: Dict[str, object] = {}
        self.loader: Optional[DomainLoader] = None
        self.published_rows: Dict[tuple, dict] = {}     # rows already in output.metadata_table (upstream hopping)
        self.gp = gp if gp is not None else (src.Greenplum(cfg) if cfg.sources["mode"] == "db" else None)
        self.llm = llm
        self.gen = cfg.generation
        self.table_analysis: Dict[str, dict] = {}
        self.results: Optional[pd.DataFrame] = None

    # ------------------------------------------------------------------ step 1
    def load_sources(self, refresh_code: bool = False) -> None:
        # the three repositories are downloaded in parallel (each archive takes 1-3 minutes on the corporate network)
        def fetch(d):
            self.repos[d].fetch(refresh=refresh_code)
        with cf.ThreadPoolExecutor(len(self.repos)) as ex:
            futs = {ex.submit(fetch, d): d for d in self.repos}
            for f in cf.as_completed(futs):
                d = futs[f]
                try:
                    f.result()
                except Exception as e:  # noqa: BLE001
                    if d == "ikg":
                        raise
                    log.error("%s repository not available (%s) - %s tables are skipped this run", d, e, d.upper())
                    self.repos.pop(d, None)
        self.lineage_df = src.load_lineage(self.cfg, self.gp)
        self.descriptions = src.load_profile_descriptions(self.cfg, self.gp)
        self.edw_df = src.load_edw_dictionary(self.cfg.path(self.cfg.sources["edw_data_dictionary"]))
        self.edw = EdwDictionary(self.edw_df)
        self.business_defs = src.load_business_definitions(self.cfg)
        ov = self.cfg.path(self.cfg.sources["glossary_overrides"])
        self.overrides = yaml.safe_load(ov.read_text(encoding="utf-8")) if ov.exists() else {}
        self.skill_column_defs: Dict[str, str] = {str(k).lower(): f"{v} [config/glossary_overrides.yaml]"
                                                  for k, v in ((self.overrides or {}).get("column_definitions") or {}).items()}
        self.entity_model = yaml.safe_load(self.cfg.path(self.cfg.sources["entity_model"]).read_text(encoding="utf-8"))
        log.info("Sources loaded")

    # ------------------------------------------------------------------ step 2
    def parse_code(self) -> pd.DataFrame:
        pdir = self.gitlab.profile_dir()
        files = sorted(pdir.glob("*.sql"))
        wanted = {t.lower() for t in (self.gen.get("profile_tables") or [])}
        if wanted:
            files = [f for f in files if f.stem.lower() in wanted]
        self.schemas = {}
        for f in files:
            ts = extract_table_schema(f)
            self.schemas[ts.table] = ts
            if ts.warnings:
                log.info("%s: %s", ts.table, "; ".join(ts.warnings))
        self.sql_text = {t: Path(s.source_file).read_text(encoding="utf-8", errors="replace")
                         for t, s in self.schemas.items()}
        self.col_types = src.load_column_types(self.cfg, self.gp, list(self.schemas))
        missing = sorted(set(self.descriptions.table_name) - set(self.schemas)) if not wanted else []
        if missing:
            log.warning("Tables in profile descriptions without a create script in %s: %s", pdir, missing)
        log.info("Parsed %d profile tables, %d columns", len(self.schemas),
                 sum(len(s.columns) for s in self.schemas.values()))
        self.add_domain_tables()
        self.add_lineage_tables()
        return pd.DataFrame([{"table_name": t, "domain": self.domain_of(t), "schema": self.table_schema(t),
                              "columns": len(s.columns), "method": s.method,
                              "distribution_key": ",".join(s.distribution_key), "warnings": "; ".join(s.warnings)}
                             for t, s in self.schemas.items()])

    # ------------------------------------------------------------------ step 2b: ODM / NLG tables
    def add_domain_tables(self) -> None:
        """ODM + NLG tables (domains.py) join self.schemas / sql_text / descriptions / col_types."""
        dcfg = self.cfg.get("domains") or {}
        repos = {d: r for d, r in self.repos.items() if d != "ikg"}
        if not repos or not any((dcfg.get(d) or {}).get("enabled") for d in repos):
            return
        sqlp.set_param_tables((dcfg.get("odm") or {}).get("table_params") or {})
        pdir = self.gitlab.profile_dir()
        profile_names = {f.stem.lower() for f in pdir.glob("*.sql")} if pdir.exists() else set()
        self.loader = DomainLoader(self.cfg, self.gp, repos, self.env, ikg_profile_tables=profile_names | set(self.schemas))
        tables = self.loader.discover()
        wanted = {t.lower() for t in (self.gen.get("profile_tables") or [])}
        for name, dt in tables.items():
            if wanted and name not in wanted and not self.gen.get("domain_tables_always", True):
                continue
            if not dt.columns:
                log.warning("%s table %s.%s has no columns (not deployed?) - skipped", dt.domain.upper(), dt.schema, name)
                continue
            self.table_domain[name] = dt.domain
            self.table_schema_map[name] = dt.schema
            self.domain_tables[name] = dt
        schemas = self.loader.schemas_frame()
        for name in self.domain_tables:
            self.schemas[name] = schemas[name]
            self.sql_text[name] = tables[name].evidence_text
        desc = self.loader.descriptions_frame()
        desc = desc[desc.table_name.isin(self.domain_tables)]
        self.descriptions = pd.concat([self.descriptions[~self.descriptions.table_name.isin(desc.table_name)], desc],
                                      ignore_index=True)
        ct = self.loader.col_types_frame()
        ct = ct[ct.table_name.isin(self.domain_tables)]
        self.col_types = pd.concat([self.col_types, ct], ignore_index=True) if len(self.col_types) else ct
        log.info("Domain tables added: %s", {d: sorted(t for t, dd in self.table_domain.items() if dd == d) for d in ("odm", "nlg")})

    # ------------------------------------------------------------------ step 2c: IKG lineage (intermediate) tables
    def add_lineage_tables(self) -> None:
        """generation.ikg_table_scope = lineage: every table of the IKG schema named in the lineage table (target,
        sub-target or source) that is not a profile table. Columns from the create / insert script in the repository
        (any folder; the script whose stem is the table name) or from information_schema. Metadata only."""
        if str(self.gen.get("ikg_table_scope", "profile")).lower() != "lineage" or self.gp is None:
            return
        sql = str(self.gen.get("ikg_lineage_tables_sql") or "").strip()
        if not sql:
            return
        schema = self.cfg.greenplum["schema"]
        try:
            df = self.gp.read(sql.format(ikg_schema=schema, lineage_table=self.cfg.sources["lineage_table"]))
        except Exception as e:  # noqa: BLE001
            log.error("lineage table scope query failed (%s) - profile tables only", e)
            return
        names = [str(x).lower() for x in df.iloc[:, 0].tolist()]
        pdir = self.gitlab.profile_dir()
        profile_names = {f.stem.lower() for f in pdir.glob("*.sql")} if pdir.exists() else set()
        pat = re.compile("^" + re.escape(str(self.gen.get("profile_table_pattern", "%profile_curr_ikg")).lower()).replace("%", ".*") + "$")
        exclude = {t.lower() for t in (self.gen.get("exclude_tables") or [])}
        self.lineage_scope = {}                       # table -> how it entered (or did not enter) the scope
        wanted = []
        for n in dict.fromkeys(names):
            if not re.fullmatch(r"[a-z_][a-z0-9_]*", n):
                self.lineage_scope[n] = "ignored: not a plain table name"
            elif n in self.schemas:
                self.lineage_scope[n] = "profile table"
            elif n in profile_names or pat.match(n):
                self.lineage_scope[n] = "profile table (not in generation.profile_tables of this run)"
            elif n in exclude:
                self.lineage_scope[n] = "excluded by generation.exclude_tables"
            else:
                wanted.append(n)
        if not wanted:
            log.info("lineage scope: no intermediate tables beyond the profile tables")
            return
        # scripts by stem (any folder of the IKG repository)
        scripts: Dict[str, Path] = {}
        for f in self.gitlab.sql_root().rglob("*.sql"):
            scripts.setdefault(f.stem.lower(), f)
        ct = src.load_column_types_for(self.cfg, self.gp, [(schema, n) for n in wanted])
        by = defaultdict(list)
        for r in ct.itertuples(index=False):
            by[r.table_name].append(r)
        added, no_cols = 0, []
        for n in wanted:
            db_cols = sorted(by.get(n, []), key=lambda r: int(r.ordinal_position or 0))
            ts = None
            if n in scripts:
                try:
                    ts = extract_table_schema(scripts[n], target=n)
                except Exception as e:  # noqa: BLE001
                    log.debug("parse failed for %s: %s", n, e)
            if ts is None or not [c for c in ts.columns if c.name != "*"]:
                if not db_cols:
                    no_cols.append(n)
                    self.lineage_scope[n] = "skipped: no columns (not deployed in the schema and no create script)"
                    continue
                from .sql_parser import ColumnInfo
                ts = TableSchemaStub(n, str(scripts.get(n, f"{schema}.{n}")),
                                     [ColumnInfo(r.column_name, r.data_type, "", i) for i, r in enumerate(db_cols, 1)])
            self.schemas[n] = ts
            self.sql_text[n] = (scripts[n].read_text(encoding="utf-8", errors="replace") if n in scripts else
                                "-- no create script found in the repository; columns from information_schema\n" +
                                "\n".join(f"--   {r.column_name:40s} {r.data_type}" for r in db_cols))
            self.table_domain[n] = "ikg_lineage"
            self.table_schema_map[n] = schema
            self.lineage_scope[n] = "intermediate table" + (" (columns from information_schema)" if n not in scripts else "")
            added += 1
        if len(ct):
            self.col_types = pd.concat([self.col_types, ct[ct.table_name.isin(self.table_domain)].drop(columns=["table_schema"])],
                                       ignore_index=True) if len(self.col_types) else ct.drop(columns=["table_schema"])
        if no_cols:
            log.warning("lineage scope: %d table(s) without columns (not deployed / no script) skipped: %s", len(no_cols), no_cols[:20])
        log.info("Lineage scope: %d intermediate IKG tables added (of %d named by the lineage query); profile tables %d",
                 added, len(names), sum(1 for t in self.schemas if self.domain_of(t) == "ikg"))

    def lineage_scope_frame(self, results: Optional[pd.DataFrame] = None) -> pd.DataFrame:
        """One row per table named by the lineage query: how it entered the scope and where its metadata stands."""
        scope = getattr(self, "lineage_scope", None) or {}
        pub = getattr(self, "published_rows", {}) or {}
        pub_tables = defaultdict(int)
        for t, _ in pub:
            pub_tables[t] += 1
        done = defaultdict(int)
        if results is not None and len(results):
            for t in results.table_name:
                done[t] += 1
        backlog = set((self.delta_info or {}).get("backlog_tables_for_next_runs_all", []) or
                      (self.delta_info or {}).get("backlog_tables_for_next_runs", []))
        deferred = set((self.delta_info or {}).get("deferred_by_time_budget", []))
        rows = []
        for t in sorted(scope):
            cols = len([c for c in self.schemas[t].columns if c.name != "*"]) if t in self.schemas else 0
            n_pub, n_new = pub_tables.get(t, 0), done.get(t, 0)
            if t not in self.schemas:
                status = "not in scope"
            elif n_pub + n_new >= cols and cols:
                status = "complete"
            elif t in deferred:
                status = "deferred by the time budget - next run"
            elif t in backlog:
                status = "backlog (daily budget) - next runs"
            elif n_pub or n_new:
                status = "partially published"
            else:
                status = "pending"
            rows.append({"table_name": t, "scope": scope[t], "domain": self.table_domain.get(t, "ikg" if t in self.schemas else ""),
                         "columns": cols, "already_in_metadata_table": n_pub, "authored_this_run": n_new,
                         "missing": max(cols - n_pub - n_new, 0), "status": status})
        return pd.DataFrame(rows, columns=["table_name", "scope", "domain", "columns", "already_in_metadata_table",
                                           "authored_this_run", "missing", "status"])

    def domain_of(self, table: str) -> str:
        return self.table_domain.get(table, "ikg")

    def table_schema(self, table: str) -> str:
        return self.table_schema_map.get(table) or self.cfg.greenplum["schema"]

    def ikg_schemas(self) -> Dict[str, object]:
        """Profile tables only (knowledge graph + _v2 clones never include ODM / NLG tables)."""
        return {t: s for t, s in self.schemas.items() if self.domain_of(t) == "ikg"}

    def _repo_rel(self, file) -> str:
        try:
            return str(Path(file).resolve().relative_to(self.gitlab.root.resolve())).replace("\\", "/")
        except (ValueError, OSError):
            return f"{self.cfg.gitlab.get('profile_sql_folder', '')}/{Path(str(file)).name}"

    def rel_path(self, file) -> str:
        """'<repo>:dags/...' for any file of any repository."""
        for r in self.repos.values():
            try:
                return f"{r.name}:{Path(file).resolve().relative_to(r.root.resolve())}"
            except ValueError:
                continue
        return str(file)

    # ------------------------------------------------------------------ helpers
    def table_entity(self, table: str) -> str:
        em = self.entity_model
        if self.table_domain.get(table) in ("odm", "nlg"):
            return ((self.cfg.get("domains") or {}).get(self.table_domain[table]) or {}).get("entity") or self.table_domain[table].upper()
        if table in (em.get("table_overrides") or {}):
            return em["table_overrides"][table]
        d = self.descriptions[self.descriptions.table_name == table]
        if len(d):
            et = d.iloc[0]["entity_type"].lower()
            # "A x B" = one row per A per B: the attributes describe the finer grain B -> last matching part
            for part in reversed([p.strip() for p in re.split(r"\s+x\s+|/|,", et) if p.strip()]):
                for ent, spec in em["entities"].items():
                    if part == ent.lower() or part in [a.lower() for a in spec.get("aliases", [])]:
                        return ent
        for pre, ent in sorted((em.get("table_prefix_entity") or {}).items(), key=lambda kv: -len(kv[0])):
            if table.startswith(pre):
                return ent
        return ""

    def description_row(self, table: str) -> dict:
        d = self.descriptions[self.descriptions.table_name == table]
        return d.iloc[0].to_dict() if len(d) else {}

    # ------------------------------------------------------------------ step 3
    def build_evidence(self) -> pd.DataFrame:
        log.info("Indexing repository SQL for code lineage ...")
        self.code = MultiResolver(self, max_depth=self.gen["lineage_max_depth"], max_steps=self.gen["lineage_max_steps"])
        walker = LineageTableWalker(self.lineage_df, self.gen["lineage_max_depth"], self.gen["lineage_max_steps"],
                                    code_from_tables=self.code.from_tables)
        self._load_published_rows()
        upstream = self._upstream_index()
        edw_pairs = self.edw.pairs()
        types = {(r.table_name, r.column_name): r for r in self.col_types.itertuples(index=False)}
        db_cols = defaultdict(list)
        for r in self.col_types.itertuples(index=False):
            db_cols[r.table_name].append(r)
        technical = set(self.entity_model.get("technical_columns", []))
        code_values = (self.overrides or {}).get("code_values") or {}
        rows, stopped = [], set()
        skip = getattr(self, "evidence_skip", None) or set()      # published intermediate-table attributes (delta mode)
        n_skipped = 0
        for table, ts in self.schemas.items():
            if self.table_domain.get(table) in ("odm", "nlg"):
                rows += self._domain_rows(table, ts, walker, edw_pairs, upstream)
                continue
            code_cols = {c.name: c for c in ts.columns if c.name != "*"}
            names = list(code_cols)
            for r in sorted(db_cols.get(table, []), key=lambda r: int(r.ordinal_position or 0)):
                if r.column_name not in code_cols:
                    names.append(r.column_name)            # deployed but not visible in code (SELECT *)
            tent = self.table_entity(table)
            lineage_table = self.table_domain.get(table) == "ikg_lineage"
            for i, name in enumerate(names, 1):
                if lineage_table and (table, name) in skip:
                    n_skipped += 1
                    continue
                c = code_cols.get(name)
                t = types.get((table, name))
                db = walker.walk(table, name, edw_pairs)
                chain, code_src, _ = self.code.resolve(table, name)
                stopped.update(s.split(".")[0] for s in db.stopped_at)
                terminals = [f"{s}.{t_}.{col}" if s else f"{t_}.{col}" for s, t_, col in db.terminal_sources]
                terminals += [x for x in code_src if x not in terminals]
                defs, qual = [], []
                for term in terminals[:8]:
                    parts = term.split(".")
                    if len(parts) < 2:
                        continue
                    internal = len(parts) >= 3 and "ikg" in parts[0].lower()      # IKG-built table: exact match only
                    d, q = self.edw.describe(parts[-2], parts[-1], exact_only=internal)
                    if d:
                        defs.append(d)
                        qual.append(q)
                for (s_, t_, col) in db.terminal_sources:
                    if not s_.upper().startswith("EDW") and t_.endswith("_ikg"):
                        stopped.add(t_)
                rows.append({
                    "table_name": table, "column_name": name,
                    "ordinal": int(t.ordinal_position) if t is not None and str(t.ordinal_position).isdigit() else i,
                    "data_type": (t.data_type if t is not None else "") or (c.data_type if c else ""),
                    "in_database": t is not None if len(self.col_types) else None,
                    "in_code": c is not None,
                    "sql_expression": c.expression if c else "",
                    "select_alias": (c.select_alias if c and c.select_alias and c.select_alias != name else ""),
                    "lineage_db": db.chain_text(),
                    "lineage_code": "\n".join(s.as_text() for s in chain[1:]),
                    "filters": db.filters_text(),
                    "terminal_sources": "; ".join(terminals[:8]),
                    "source_definitions": "\n".join(defs),
                    "edw_match": "exact" if "exact" in qual else ("column_only" if qual else "none"),
                    "lineage_found": bool(db.found_in_lineage_table),
                    "lineage_reached_source": bool(terminals),
                    "lineage_ambiguous": db.ambiguous,
                    "lineage_stopped_at": "; ".join(db.stopped_at),
                    "code_values": json.dumps(code_values.get(name)) if name in code_values else "",
                    "table_entity": tent,
                    "is_technical": name in technical or name.endswith("_key"),
                    "source_file": Path(ts.source_file).name,
                    "web_url": self.gitlab.web_url(self._repo_rel(ts.source_file)),
                    "domain": self.domain_of(table), "schema_name": self.cfg.greenplum["schema"],
                    "code_mentions": "", "upstream_candidates": "", "published_definition": "",
                    "upstream": upstream_text(table, name, db, chain, code_src),
                })
        self.ctx = pd.DataFrame(rows)
        # python code that writes tables where SQL lineage stops
        self.py_snippets = python_writers(self.gitlab.python_root(), {s for s in stopped if s})
        for d, r in self.repos.items():
            if d != "ikg":
                for k, v in python_writers(r.python_root(), {s for s in stopped if s}).items():
                    self.py_snippets.setdefault(k, v)
        self.ctx["python_code"] = self.ctx.lineage_stopped_at.map(
            lambda s: "\n".join(self.py_snippets.get(x.split(".")[0], "")[:2500] for x in s.split("; ") if x)[:3000])
        if n_skipped:
            log.info("Evidence: %d published intermediate-table attribute(s) skipped (already in %s with upstream)", n_skipped, self.cfg.output["metadata_table"])
        log.info("Evidence: %d columns | lineage table hit %.0f%% | reached source %.0f%% | EDW definition %.0f%%",
                 len(self.ctx), 100 * self.ctx.lineage_found.mean(), 100 * self.ctx.lineage_reached_source.mean(),
                 100 * self.ctx.edw_match.ne("none").mean())
        return self.ctx

    def _load_published_rows(self) -> None:
        """Rows already in output.metadata_table: skip rules + 'same column name already described' evidence."""
        self.published_rows = {}
        if self.gp is None or not self.cfg.output.get("load_to_greenplum", False):
            return
        try:
            from .db_sync import GreenplumSync
            sync = GreenplumSync(self.gp, self.cfg)
            if sync.table_exists(self.cfg.output["metadata_table"]):
                df = self.gp.read(f"select * from {sync.schema}.{self.cfg.output['metadata_table']}").fillna("")
                for r in df.to_dict("records"):
                    self.published_rows[(str(r["table_name"]).lower(), str(r["column_name"]).lower())] = r
            log.info("Published metadata rows: %d", len(self.published_rows))
        except Exception as e:  # noqa: BLE001
            log.warning("could not read %s: %s", self.cfg.output["metadata_table"], e)

    def _upstream_index(self) -> Dict[str, List[str]]:
        """column name -> 'schema.table' list across domains.upstream_schemas (ODM / NLG upstream hopping)."""
        if not self.domain_tables:
            return {}
        names = sorted({c.name for t in self.domain_tables for c in self.schemas[t].columns})
        schemas = [self.cfg.greenplum["schema"]]                                  # IKG schema of the environment
        schemas += [v.lower() for k, v in (getattr(self.loader, "nlg_settings", {}) or {}).items() if k.startswith("schema_")]
        schemas += [str(x) for x in ((self.cfg.get("domains") or {}).get("upstream_schemas") or [])]
        edw_schema = (self.cfg.get("domains") or {}).get("edw_input_schema")
        if edw_schema:
            schemas.append(edw_schema)
        schemas = list(dict.fromkeys(s for s in schemas if s))
        df = src.columns_named(self.gp, names, schemas)
        out: Dict[str, List[str]] = defaultdict(list)
        for r in df.itertuples(index=False):
            out[r.column_name].append(f"{r.table_schema}.{r.table_name}")
        # the IKG profile tables of this run are upstream candidates even without a database
        for t in self.ikg_schemas():
            for c in self.schemas[t].columns:
                key = f"{self.cfg.greenplum['schema']}.{t}"
                if key not in out[c.name]:
                    out[c.name].append(key)
        return out

    def _domain_rows(self, table: str, ts, walker, edw_pairs, upstream) -> List[dict]:
        dt = self.domain_tables[table]
        dom = dt.domain
        schema = dt.schema
        technical = set(self.entity_model.get("technical_columns", []))
        code_values = (self.overrides or {}).get("code_values") or {}
        resolver = self.code.resolvers.get(dom)
        tent = self.table_entity(table)
        same_name_pub = {}
        for (t, c), r in sorted(self.published_rows.items(), key=lambda kv: (kv[0][0] in self.table_domain, kv[0][0])):
            if t != table:                                   # prefer the IKG profile tables, never the table itself
                same_name_pub.setdefault(c, (t, r))
        rows = []
        for c in ts.columns:
            name = c.name
            expr, chain_txt, sources = ("", "", [])
            if dom == "odm" and resolver is not None:
                expr, chain_txt, sources = self.loader.writer_expressions(dt, name, resolver)
            db = walker.walk(table, name, edw_pairs)
            terminals = [f"{s}.{t_}.{col}" if s else f"{t_}.{col}" for s, t_, col in db.terminal_sources]
            terminals += [x for x in sources if x not in terminals]
            defs, qual = [], []
            for term in terminals[:8]:
                parts = term.split(".")
                if len(parts) >= 2:
                    d, q = self.edw.describe(parts[-2], parts[-1])
                    if d:
                        defs.append(d)
                        qual.append(q)
            if not defs:                                       # column name alone against the EDW dictionary
                d, q = self.edw.describe("", name)
                if d and q in ("column_unique",):
                    defs.append(d)
                    qual.append(q)
            edw_schema = str((self.cfg.get("domains") or {}).get("edw_input_schema") or "")
            ups = sorted((u for u in upstream.get(name, []) if u != f"{schema}.{table}"),
                         key=lambda u: (0 if edw_schema and u.startswith(edw_schema + ".") else
                                        1 if u.split(".")[-1] not in self.table_domain else 2, u))
            pub = same_name_pub.get(name)
            pub_txt = ""
            if pub:
                pub_txt = (f"{pub[0]}.{name} (published {self.cfg.output['metadata_table']}): "
                           f"{pub[1].get('business_attribute_name', '')} - {str(pub[1].get('description', ''))[:400]}")
            mentions = self.loader.column_mentions(dt, name)
            rows.append({
                "table_name": table, "column_name": name, "ordinal": c.ordinal,
                "data_type": c.data_type, "in_database": dt.column_source == "information_schema", "in_code": bool(expr or mentions),
                "sql_expression": expr, "select_alias": "",
                "lineage_db": db.chain_text(), "lineage_code": chain_txt, "filters": db.filters_text(),
                "terminal_sources": "; ".join(terminals[:8]), "source_definitions": "\n".join(defs),
                "edw_match": "exact" if "exact" in qual else ("column_only" if qual else "none"),
                "lineage_found": bool(db.found_in_lineage_table), "lineage_reached_source": bool(terminals),
                "lineage_ambiguous": db.ambiguous, "lineage_stopped_at": "; ".join(db.stopped_at),
                "code_values": json.dumps(code_values.get(name)) if name in code_values else "",
                "table_entity": tent, "is_technical": name in technical or name.endswith("_key"),
                "source_file": Path(dt.ddl_file).name if dt.ddl_file else f"{dom}:{schema}.{table}",
                "web_url": self.repos[dom].web_url(f"{self.repos[dom].g.get('code_root', 'dags')}/{dt.ddl_file}") if dt.ddl_file and dom in self.repos else "",
                "domain": dom, "schema_name": schema, "code_mentions": mentions,
                "upstream_candidates": "; ".join(ups[:12]), "published_definition": pub_txt,
                "upstream": upstream_text(table, name, db, [], sources) or
                            (f"{table}.{name} <- candidates: " + "; ".join(ups[:6]) if ups else ""),
            })
        return rows

    # ------------------------------------------------------------------ step 4
    def build_glossary(self, use_llm: bool = True) -> pd.DataFrame:
        usage = defaultdict(list)
        for t, c in self.ctx[["table_name", "column_name"]].itertuples(index=False):
            for tok in dict.fromkeys(tokenize(c)):
                usage[tok].append(f"{t}.{c}")
        # also upstream / EDW column names contribute evidence via the EDW dictionary itself
        pairs = [(c.name, c.select_alias) for s in self.schemas.values() for c in s.columns]
        cat_text = " ".join(self.descriptions[["description", "additional_notes", "grain"]].astype(str)
                            .agg(" ".join, axis=1).tolist()) + " " + self.business_defs
        self.glossary = Glossary(self.overrides, self.edw_df, pairs, cat_text)
        self.glossary.build(usage)
        if use_llm and self.llm is not None:
            ctx_for = {}
            for tok in self.glossary.unresolved():
                ex = [u for u in usage[tok][:4]]
                bits = []
                for u in ex:
                    t, c = u.split(".", 1)
                    r = self.ctx[(self.ctx.table_name == t) & (self.ctx.column_name == c)]
                    if len(r):
                        r = r.iloc[0]
                        bits.append(f"{u} = {r.sql_expression[:150]} | src: {r.terminal_sources[:150]} | "
                                    f"{r.source_definitions[:200]}")
                ctx_for[tok] = " || ".join(bits)
            self.glossary.resolve_with_llm(self.llm, _prompt("glossary_prompt.txt"), ctx_for, self.business_defs)
        exp_unres = self.ctx.column_name.map(self.glossary.expand)
        self.ctx["abbreviations"] = exp_unres.map(lambda x: x[0])
        self.ctx["unresolved_tokens"] = exp_unres.map(lambda x: ", ".join(x[1]))
        g = self.glossary.frame()
        log.info("Glossary: %d tokens, %d abbreviations, %d need input", len(g), int(g.is_abbreviation.sum()),
                 int((g.status != "RESOLVED").sum()))
        return g

    # ------------------------------------------------------------------ prompts
    def _system(self, name: str) -> str:
        ents = "\n".join(f"- {k}: {v.get('description', '')}" for k, v in self.entity_model["entities"].items())
        return (f"{_prompt(name)}\n\nALLOWED ENTITIES:\n{ents}\n\nFIRM BUSINESS DEFINITIONS:\n"
                f"{self.business_defs or '(none supplied)'}")

    def _table_prefix(self, table: str, with_analysis: bool = True, max_chars: Optional[int] = None) -> str:
        desc = {k: v for k, v in self.description_row(table).items() if v and k != "table_name"}
        sql = self.sql_text.get(table, "")
        cap = int(max_chars if max_chars is not None else self.gen["max_sql_chars"])
        if len(sql) > cap:
            sql = (sql[:cap] + f"\n-- [script truncated at {cap} of {len(sql)} characters - the column SQL "
                   "expressions and lineage are in the evidence; use read_profile_sql(table, start_line, end_line) "
                   "to read any other part]")
        dom = self.domain_of(table)
        if dom == "ikg_lineage":
            parts = [f"IKG TABLE (intermediate / lineage table, NOT a profile table): {self.table_schema(table)}.{table}",
                     f"PRIMARY ENTITY (prefix rules): {self.table_entity(table)}",
                     "CATALOGUE DESCRIPTION: (none - intermediate table built by the script below; describe the columns from "
                     "the script, the lineage and the published definitions of the same column names in the profile tables)"]
        elif dom == "ikg":
            parts = [f"PROFILE TABLE: {table}", f"PRIMARY ENTITY (catalogue / model): {self.table_entity(table)}",
                     f"CATALOGUE DESCRIPTION ({self.cfg.sources.get('profile_descriptions_table', 'ikg_profile_table_descriptions')}):",
                     json.dumps(desc, ensure_ascii=False, indent=1) if desc else "(none)"]
        else:
            dt = self.domain_tables[table]
            parts = [f"{dom.upper()} TABLE: {self.table_schema(table)}.{table}  (domain {dom}; NOT an IKG profile table)",
                     f"ENTITY FOR THE METADATA ROWS: {self.table_entity(table)}",
                     "TABLE INFORMATION (from the ini / code / information_schema):",
                     json.dumps(desc, ensure_ascii=False, indent=1) if desc else "(none)",
                     "HOW TO WORK ON THIS TABLE: read skills/" + str(((self.cfg.get('domains') or {}).get(dom) or {}).get('skill_file', '')) +
                     " (search_skills / read_skill) for the business meaning; the evidence below contains the DDL, the "
                     "scripts that write the table and code excerpts" +
                     ("; NLG writes its tables from Python - use search_repo with file_glob '*.py' / '*.yml' and read_sql_file "
                      "for any repository file (paths are '<repo>:dags/...')." if dom == "nlg" else
                      "; every ODM rule script inserts into the insight table - the per-column 'sql_expression' lists the "
                      "distinct expressions used across the rules.") +
                     " Use published_definition / upstream_candidates of a column (same column name in the IKG / NLG / EDW "
                     "schemas) to keep names and descriptions consistent with the IKG profile metadata."]
        if with_analysis and table in self.table_analysis:
            parts += ["ANALYSIS OF THE TABLE CODE:", json.dumps(self.table_analysis[table], ensure_ascii=False, indent=1)]
        if self.gen.get("include_full_profile_sql", True):
            head = (f"COMPLETE CREATE SCRIPT ({self.schemas[table].source_file.split('/')[-1]}):" if dom in ("ikg", "ikg_lineage")
                    else "COMPLETE CREATE SCRIPT / CODE EVIDENCE (DDL, writer scripts, code excerpts):")
            parts += [head, sql]
        return "\n\n".join(parts)

    def _column_payload(self, rows: pd.DataFrame, extra: Optional[Dict[str, dict]] = None) -> str:
        cols = []
        for i, r in enumerate(rows.itertuples(index=False), 1):
            item = {"id": f"c{i:03d}", "column": r.column_name, "data_type": r.data_type,
                    "sql_expression": r.sql_expression or "(not visible in code - column comes from SELECT *)"}
            for k in ("select_alias", "lineage_db", "lineage_code", "filters", "source_definitions",
                      "abbreviations", "code_values", "python_code", "code_mentions", "upstream_candidates",
                      "published_definition"):
                v = getattr(r, k)
                if v:
                    item[k] = v
            if r.unresolved_tokens:
                item["unresolved_abbreviations"] = r.unresolved_tokens
            if extra and r.column_name in extra:
                item["draft"] = extra[r.column_name]
            cols.append(item)
        rel = {t: self.glossary.entries[t]["full_form"] for c in rows.column_name for t in tokenize(c)
               if t in self.glossary.entries and self.glossary.entries[t]["status"] == "RESOLVED"
               and self.glossary.entries[t]["is_abbreviation"]}
        return json.dumps({"glossary_for_these_columns": rel, "columns": cols}, ensure_ascii=False)

    def _batches(self):
        n = int(self.gen["columns_per_call"])
        for t, g in self.ctx.sort_values(["table_name", "ordinal"]).groupby("table_name", sort=True):
            for i in range(0, len(g), n):
                yield t, g.iloc[i:i + n]

    # ------------------------------------------------------------------ step 5
    def analyze_tables(self) -> pd.DataFrame:
        sysp = self._system("table_analysis_prompt.txt")

        def run(t):
            return t, self.llm.json_call(sysp, "Analyse this table.", prefix=self._table_prefix(t, False),
                                         cache_key=("table_analysis", t))
        with cf.ThreadPoolExecutor(int(self.cfg.llm["parallel_calls"])) as ex:
            for fut in cf.as_completed([ex.submit(run, t) for t in self.schemas]):
                try:
                    t, a = fut.result()
                    self.table_analysis[t] = a
                except Exception as e:  # noqa: BLE001
                    log.error("table analysis failed: %s", e)
        log.info("Table analysis done for %d tables", len(self.table_analysis))
        return pd.DataFrame([{"table_name": t, **{k: (json.dumps(v, ensure_ascii=False) if isinstance(v, (list, dict)) else v)
                                                   for k, v in a.items()}} for t, a in self.table_analysis.items()])

    # ------------------------------------------------------------------ step 6
    def generate(self) -> pd.DataFrame:
        sysp = self._system("column_metadata_prompt.txt")
        allowed = set(self.entity_model["entities"])
        out, failed = [], []

        def run(tb):
            t, rows = tb
            data = self.llm.json_call(sysp, self._column_payload(rows), prefix=self._table_prefix(t),
                                      cache_key=("columns", t))
            return self._map(rows, data.get("columns", []), allowed)

        batches = list(self._batches())
        log.info("Generating metadata: %d LLM calls", len(batches))
        with cf.ThreadPoolExecutor(int(self.cfg.llm["parallel_calls"])) as ex:
            futs = {ex.submit(run, b): b[0] for b in batches}
            for i, fut in enumerate(cf.as_completed(futs), 1):
                try:
                    out.extend(fut.result())
                except Exception as e:  # noqa: BLE001
                    failed.append(futs[fut])
                    log.error("batch failed for %s: %s", futs[fut], e)
                if i % 20 == 0:
                    log.info("  %d / %d batches", i, len(batches))
        if failed:
            log.error("Failed batches (re-run generate(); cached batches are skipped): %s", sorted(set(failed)))
        gen = pd.DataFrame(out)
        self.results = self.ctx.merge(gen, on=["table_name", "column_name"], how="left")
        return self.results

    @staticmethod
    def _map(rows: pd.DataFrame, items: list, allowed: set) -> List[dict]:
        by_id = {str(x.get("id")): x for x in items if isinstance(x, dict)}
        res = []
        for i, r in enumerate(rows.itertuples(index=False), 1):
            x = by_id.get(f"c{i:03d}", {})
            ent = x.get("entity", "")
            res.append({
                "table_name": r.table_name, "column_name": r.column_name,
                "functional_name": (x.get("functional_name") or "").strip(),
                "business_description": (x.get("business_description") or "").strip(),
                "entity": ent if ent in allowed else (r.table_entity or ent),
                "entity_llm_raw": ent,
                "attribute_type": x.get("attribute_type", "") if x.get("attribute_type") in ATTRIBUTE_TYPES else x.get("attribute_type", ""),
                "derivation_type": x.get("derivation_type", ""),
                "unit": x.get("unit", ""),
                "llm_confidence": _int(x.get("llm_confidence"), 0),
                "confidence_reason": x.get("confidence_reason", "") if x else "LLM returned no result",
                "difficult_to_generate": bool(x.get("difficult_to_generate", not x)),
                "what_is_required_llm": x.get("what_is_required", "") or "",
                "unresolved_abbreviations_llm": ", ".join(x.get("unresolved_abbreviations") or []),
                "verify_verdict": "", "verify_issues": "",
            })
        return res

    # ------------------------------------------------------------------ step 7
    def verify(self, only_below_band: str = "High") -> pd.DataFrame:
        if self.results is None:
            raise RuntimeError("run generate() first")
        self.score()
        todo = self.results[self.results.confidence_band != only_below_band] if only_below_band else self.results
        if todo.empty:
            return self.results
        sysp = self._system("verify_prompt.txt")
        n = int(self.gen["columns_per_call"])
        tasks = []
        for t, g in todo.groupby("table_name"):
            for i in range(0, len(g), n):
                tasks.append((t, g.iloc[i:i + n]))
        log.info("Verification pass: %d attributes in %d calls", len(todo), len(tasks))

        def run(tb):
            t, rows = tb
            drafts = {r.column_name: {"functional_name": r.functional_name, "business_description": r.business_description,
                                      "llm_confidence": r.llm_confidence, "what_is_required": r.what_is_required_llm}
                      for r in rows.itertuples(index=False)}
            ctx_rows = self.ctx.set_index(["table_name", "column_name"]).loc[[(t, c) for c in rows.column_name]].reset_index()
            data = self.llm.json_call(sysp, self._column_payload(ctx_rows, drafts), prefix=self._table_prefix(t),
                                      cache_key=("verify", t))
            by_id = {str(x.get("id")): x for x in data.get("columns", [])}
            return [(t, c, by_id.get(f"c{i:03d}")) for i, c in enumerate(rows.column_name, 1)]

        idx = {(r.table_name, r.column_name): i for i, r in enumerate(self.results.itertuples(index=False))}
        with cf.ThreadPoolExecutor(int(self.cfg.llm["parallel_calls"])) as ex:
            for fut in cf.as_completed([ex.submit(run, tb) for tb in tasks]):
                try:
                    for t, c, x in fut.result():
                        if not x:
                            continue
                        i = self.results.index[idx[(t, c)]]
                        self.results.at[i, "verify_verdict"] = x.get("verdict", "")
                        self.results.at[i, "verify_issues"] = x.get("issues", "")
                        if x.get("functional_name"):
                            self.results.at[i, "functional_name"] = x["functional_name"].strip()
                        if x.get("business_description"):
                            self.results.at[i, "business_description"] = x["business_description"].strip()
                        if x.get("llm_confidence") is not None:
                            self.results.at[i, "llm_confidence"] = _int(x["llm_confidence"], 0)
                        if x.get("what_is_required"):
                            self.results.at[i, "what_is_required_llm"] = x["what_is_required"]
                        if x.get("verdict") == "insufficient_evidence":
                            self.results.at[i, "difficult_to_generate"] = True
                except Exception as e:  # noqa: BLE001
                    log.error("verify batch failed: %s", e)
        return self.results

    # ------------------------------------------------------------------ step 8
    def score(self) -> pd.DataFrame:
        self.results = self.score_df(self.results)
        return self.results

    def score_df(self, r: pd.DataFrame) -> pd.DataFrame:
        """Composite confidence for any frame with the evidence + agent columns (thread-safe, no state)."""
        r = r.copy()
        bands = self.gen["confidence_bands"]
        ev, gaps = [], []
        for x in r.itertuples(index=False):
            s, g = 0, []
            if x.sql_expression:
                s += 15
            else:
                g.append("column not visible in the create script (SELECT *) - expression unknown")
            dom = str(getattr(x, "domain", "ikg") or "ikg")
            if x.lineage_reached_source:
                s += 25
            elif x.lineage_db or x.lineage_code:
                s += 12
                g.append("lineage incomplete" + (f" - no SQL lineage for {x.lineage_stopped_at}" if x.lineage_stopped_at else ""))
            elif dom != "ikg" and (getattr(x, "published_definition", "") or getattr(x, "code_mentions", "")):
                s += 18 if getattr(x, "published_definition", "") else 10     # same column described in IKG / seen in code
                if not getattr(x, "published_definition", ""):
                    g.append("meaning taken from code mentions only - no published definition of this column name")
            elif not x.is_technical:
                g.append("no lineage found in ikg_column_lineage_master_auto_refresh or code")
            if x.edw_match == "exact":
                s += 20
            elif x.edw_match == "column_only":
                s += 10
                g.append("EDW definition matched by column name only - confirm source table")
            elif x.lineage_reached_source and not x.is_technical:
                g.append(f"no EDW data dictionary definition for source column(s): {str(x.terminal_sources)[:200]}")
            unres = [t for t in str(x.unresolved_tokens or "").split(", ") if t]
            s += max(0, 20 - 7 * len(unres))
            if unres:
                g.append(f"meaning of abbreviation(s): {', '.join(unres)} (fill config/glossary_overrides.yaml)")
            if x.data_type:
                s += 5
            if self.description_row(x.table_name):
                s += 15
            if x.lineage_ambiguous:
                g.append("lineage ambiguous (unqualified column in multi-table query)")
            used = str(getattr(x, "evidence_used", "") or "")
            if "value_profile" in used:
                s += 5                       # agent verified meaning against actual values
            if "skill_file" in used:
                s += 5                       # firm documentation used
            if x.is_technical:
                s = max(s, 80)
            ev.append(min(100, s))
            gaps.append(g)
        r["evidence_score"] = ev
        llm_c = pd.to_numeric(r.get("llm_confidence", 0), errors="coerce").fillna(0)
        score = (0.6 * llm_c + 0.4 * r["evidence_score"]).round()
        has_unres = r["unresolved_tokens"].fillna("").ne("") | r.get("unresolved_abbreviations_llm", "").fillna("").ne("")
        score = score.where(~has_unres, score.clip(upper=bands["high"] - 1))
        no_basis = r["sql_expression"].eq("") & r["lineage_db"].eq("") & r["lineage_code"].eq("") & ~r["is_technical"]
        score = score.where(~no_basis, score.clip(upper=bands["medium"] - 10))
        empty = r["functional_name"].fillna("").eq("") | r["business_description"].fillna("").eq("")
        score = score.where(~empty, 0)
        r["confidence_score"] = score.astype(int)
        r["confidence_band"] = pd.cut(r["confidence_score"], [-1, bands["medium"] - 1, bands["high"] - 1, 101],
                                      labels=["Low", "Medium", "High"]).astype(str)
        dup = r.duplicated(["table_name", "functional_name"], keep=False) & r["functional_name"].fillna("").ne("")
        r["difficult_to_generate"] = r["difficult_to_generate"].fillna(True).astype(bool) | empty
        req = []
        for x, g, d in zip(r.itertuples(index=False), gaps, dup):
            items = []
            if getattr(x, "what_is_required_llm", ""):
                items.append(str(x.what_is_required_llm))
            if x.confidence_band != "High":
                items += [i for i in g if i not in items]
            if d:
                items.append("functional name duplicated within table - disambiguate")
            req.append(" | ".join(items))
        r["what_is_required"] = req
        r["needs_review"] = r["confidence_band"].ne("High") | r["difficult_to_generate"] | dup
        return r

    # ------------------------------------------------------------------ dry run
    def preview_prompts(self, path: Optional[Path] = None) -> Path:
        path = path or self.out / "prompts_preview.jsonl"
        sysp = self._system("column_metadata_prompt.txt")
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(json.dumps({"system": sysp}, ensure_ascii=False) + "\n")
            for t, rows in self._batches():
                fh.write(json.dumps({"table": t, "prefix_chars": len(self._table_prefix(t)),
                                     "user": json.loads(self._column_payload(rows))}, ensure_ascii=False) + "\n")
        n = sum(1 for _ in self._batches())
        log.info("Prompt preview: %d column calls (+%d table analyses, + verification) -> %s", n, len(self.schemas), path)
        return path

    def estimate_tokens(self) -> dict:
        pre = {t: len(self._table_prefix(t)) // 4 for t in self.schemas}
        calls = list(self._batches())
        inp = sum(pre[t] + len(self._column_payload(r)) // 4 + 3000 for t, r in calls) + sum(pre.values())
        return {"table_analysis_calls": len(self.schemas), "column_calls": len(calls),
                "approx_input_tokens": inp, "approx_output_tokens": len(self.ctx) * 450}

    # ------------------------------------------------------------------ step 9
    def write(self, relationships: Optional[pd.DataFrame] = None, agent_ctx=None) -> Path:
        from .report import write_workbook
        path = self.out / self.cfg.output["metadata_xlsx"]
        tbl = self.table_summary()
        extra = agent_sheets(agent_ctx) if agent_ctx is not None else {}
        info = self.run_info()
        if agent_ctx is not None:
            info["orchestration"] = self.cfg.get("agents", {}).get("orchestration", "llm")
            info["skill_files"] = ", ".join(agent_ctx.skills.files) or "(none)"
            info["agent_tool_calls"] = sum(1 for r in agent_ctx.trace.rows if r["kind"] == "tool")
        res = self.all_results_frame()
        if len(res):
            res["current_datetime"] = info["run_timestamp"]          # latest run date time for every record
            if "upstream" not in res.columns:
                res["upstream"] = ""
        self.final_results = res
        write_workbook(path, res, self.glossary.frame(), tbl, relationships, info, extra)
        if self.cfg.output.get("write_to_greenplum") and self.gp is not None:
            sch = self.cfg.output["target_schema"]
            cols = [c for c in REPORT_DB_COLUMNS if c in self.results.columns]
            self.gp.write(self.results[cols].astype(str), sch, self.cfg.output["metadata_table"])
            self.gp.write(self.glossary.frame().astype(str), sch, self.cfg.output["glossary_table"])
        log.info("Metadata workbook: %s", path)
        return path

    def table_summary(self) -> pd.DataFrame:
        rows = []
        r = self.all_results_frame()
        for t, s in self.schemas.items():
            g = r[r.table_name == t] if len(r) else r
            a = self.table_analysis.get(t, {})
            d = self.description_row(t)
            rows.append({
                "table_name": t, "domain": self.domain_of(t), "schema": self.table_schema(t),
                "entity": self.table_entity(t), "topic_area": d.get("topic_area", ""),
                "catalogue_description": d.get("description", ""), "grain (catalogue)": d.get("grain", ""),
                "table_purpose (LLM)": a.get("table_purpose", ""), "grain (LLM from code)": a.get("grain", ""),
                "population (LLM)": a.get("population", ""),
                "key_business_rules (LLM)": "\n".join(a.get("key_business_rules", []) or []),
                "caveats (LLM)": "\n".join(a.get("caveats", []) or []),
                "columns": len(g), "high": int((g.confidence_band == "High").sum()),
                "medium": int((g.confidence_band == "Medium").sum()), "low": int((g.confidence_band == "Low").sum()),
                "avg_confidence": round(float(g.confidence_score.mean()), 1) if len(g) else None,
                "parse_method": s.method, "distribution_key": ",".join(s.distribution_key),
                "parse_warnings": "; ".join(s.warnings), "source_file": Path(s.source_file).name,
            })
        return pd.DataFrame(rows)

    def run_info(self) -> dict:
        u = self.llm.usage if self.llm else {}
        return {"run_timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "model": f"{self.cfg.llm['model_name']} (deployment {self.cfg.llm['deployment']}, api {self.cfg.llm['api_version']})",
                "environment": self.env,
                "gitlab": f"{self.cfg.gitlab['project_path']}@{self.cfg.gitlab['ref']}",
                "repositories": "; ".join(f"{d}: {r.g.get('project_path', r.root)}@{r.g.get('ref', '')}" for d, r in self.repos.items()),
                "odm_tables": ", ".join(sorted(t for t, d in self.table_domain.items() if d == "odm")) or "(none)",
                "nlg_tables": f"{sum(1 for d in self.table_domain.values() if d == 'nlg')} tables from nlg_db_tables.ini "
                              f"[{getattr(self.loader, 'nlg_section', '')}]" if self.loader else "(none)",
                "lineage_source": self.cfg.sources["lineage_table"] if self.cfg.sources["mode"] == "db" else self.cfg.sources["lineage_file"],
                "profile_descriptions": self.cfg.sources["profile_descriptions_table"],
                "edw_dictionary": f"{self.cfg.sources['edw_data_dictionary']} ({len(self.edw_df)} column definitions)",
                "profile_tables": len(self.schemas), "attributes": len(self.results) if self.results is not None else 0,
                "llm_calls": u.get("calls"), "llm_cache_hits": u.get("cache_hits"),
                "prompt_tokens": u.get("prompt_tokens"), "completion_tokens": u.get("completion_tokens"),
                "cached_prompt_tokens": u.get("cached_tokens"),
                "confidence_formula": "0.6 x LLM rubric confidence + 0.4 x evidence score; capped below High when an "
                                      "abbreviation is unresolved; capped Low when no code/lineage evidence",
                "evidence_score": "expression in code 15 + lineage to source 25 (partial 12) + EDW definition 20 "
                                  "(column-only 10) + abbreviations resolved 20 (-7 each unresolved) + data type 5 + "
                                  "table catalogue description 15"}

    # ------------------------------------------------------------------ shared columns (consistency + speed)
    GENERIC_NAMES = {"value", "variable", "name", "category", "key", "type", "code", "status", "date", "count",
                     "amount", "description", "flag", "id", "rank", "score", "text", "title", "label", "src", "source"}

    def plan_shared_columns(self) -> Dict[str, int]:
        """A column name that appears in several profile tables is authored ONCE (at a representative table)
        and the metadata is copied to every other table, so acc_mhh_n, ip_cli_i, mhh_assets_curr ... read the
        same everywhere. generation.same_name_policy: always (default) | signature (share only when the
        derivation signature matches) | never."""
        policy = str(self.gen.get("same_name_policy", "always")).lower()
        self.rep_of: Dict[tuple, tuple] = {}
        self.members: Dict[tuple, List[tuple]] = {}
        if policy == "never":
            return {"groups": 0, "shared_columns": 0}
        size = {t: len(s.columns) for t, s in self.schemas.items()}
        pref = {}
        for ent, spec in self.entity_model["entities"].items():
            pref[ent] = None
        groups: Dict[str, List[tuple]] = defaultdict(list)
        for r in self.ctx.itertuples(index=False):
            name = r.column_name
            if policy == "always" and name not in self.GENERIC_NAMES:
                sig = name
            else:
                base = re.sub(r"^\w+\.", "", str(r.sql_expression or "")).strip().lower()
                sig = f"{name}|{r.terminal_sources or base}"
            groups[sig].append((r.table_name, name))
        shared = 0
        for sig, mem in groups.items():
            if len(mem) == 1:
                continue
            name = mem[0][1]
            # representative: the table whose entity owns the column prefix, else the biggest table
            prefix_ent = next((e for pfx, e in sorted((self.entity_model.get("attribute_prefix_entity") or {}).items(),
                                                      key=lambda kv: -len(kv[0])) if name.startswith(pfx)), None)
            cand = [m for m in mem if prefix_ent and self.table_entity(m[0]) == prefix_ent] or mem
            rep = max(cand, key=lambda m: size.get(m[0], 0))
            self.members[rep] = mem
            for m in mem:
                self.rep_of[m] = rep
                if m != rep:
                    shared += 1
        log.info("Shared columns: %d names authored once and copied to %d other table columns (policy=%s)",
                 len(self.members), shared, policy)
        return {"groups": len(self.members), "shared_columns": shared}

    def propagate_shared(self, results: Dict) -> int:
        n = 0
        for rep, mem in getattr(self, "members", {}).items():
            src = results.get(rep)
            if not src:
                continue
            for m in mem:
                if m == rep:
                    continue
                x = dict(src)
                x["table_name"], x["column_name"] = m
                x["shared_from"] = f"{rep[0]}.{rep[1]}"
                results[m] = x
                n += 1
        return n

    # ------------------------------------------------------------------ delta mode
    def restrict_to_delta(self, sync) -> dict:
        """Keep only (table, column) pairs not yet in output.metadata_table. Columns whose NAME already has a
        business description in that table (other profile tables) are prefilled from it, not re-authored."""
        existing_rows = self.read_published_rows(sync)
        existing = set(existing_rows)
        self.published_rows = existing_rows or self.published_rows
        code_pairs = {(t, c) for t, c in self.ctx[["table_name", "column_name"]].itertuples(index=False)}
        deployed = sync.deployed_profile_pairs()
        deployed_only = sorted(deployed - code_pairs - existing)
        delta = sorted(code_pairs - existing)
        skipped_tables = self._domain_table_skips(existing)
        delta = [(t, c) for t, c in delta if t not in skipped_tables]
        delta, backlog = self._apply_budget(delta)
        self.delta_info = {"mode": "delta" if existing else "full (metadata table empty / missing)",
                           "existing_in_db": len(existing), "deployed_pairs": len(deployed), "code_pairs": len(code_pairs),
                           "new_pairs": len(delta), "new_tables": sorted({t for t, _ in delta} - {t for t, _ in existing}),
                           "deployed_but_not_in_code": deployed_only[:200],
                           "odm_nlg_tables_skipped (already in metadata table)": sorted(skipped_tables),
                           "odm_nlg_attributes_to_add": sorted(f"{t}.{c}" for t, c in delta if self.table_domain.get(t) in ("odm", "nlg"))[:300],
                           "backlog_attributes_for_next_runs": backlog["attributes"],
                           "backlog_tables_for_next_runs": backlog["tables"][:100],
                           "backlog_tables_for_next_runs_all": backlog["tables"]}
        if not existing and not backlog["attributes"]:
            return self.delta_info
        dset = set(delta)
        self.ctx_full = self.ctx                       # full evidence (all tables) for graph / clone rules
        self.db_rows = existing_rows                   # published descriptions (all tables) for the graph
        keep = [(t, c) in dset for t, c in zip(self.ctx.table_name, self.ctx.column_name)]
        self.ctx = self.ctx[keep].reset_index(drop=True)
        self.active_tables = sorted(set(self.ctx.table_name))
        # prefill from DB rows with the same column name (consistency with what is already published)
        by_name = {}
        for (t, c), r in existing_rows.items():
            by_name.setdefault(c, r)
        self.prefilled = {}
        for t, c in delta:
            r = by_name.get(c)
            if r is None or c in self.GENERIC_NAMES or str(self.gen.get("same_name_policy", "always")).lower() == "never":
                continue
            self.prefilled[(t, c)] = {
                "table_name": t, "column_name": c, "functional_name": r.get("business_attribute_name", ""),
                "business_description": r.get("description", ""), "entity": r.get("entity", ""),
                "attribute_type": r.get("attribute_type", ""), "derivation_type": r.get("derivation_type", ""),
                "unit": r.get("unit", ""), "llm_confidence": int(r.get("confidence_score") or 0),
                "confidence_reason": f"copied from {r['table_name']}.{c} in {self.cfg.output['metadata_table']}",
                "difficult_to_generate": str(r.get("difficult_to_generate", "")).lower() == "true",
                "what_is_required_llm": r.get("what_is_required", ""), "unresolved_abbreviations_llm": "",
                "evidence_used": r.get("evidence_used", ""), "verify_verdict": r.get("verify_verdict", ""),
                "verify_issues": "", "shared_from": f"{r['table_name']}.{c} (db)"}
        self.delta_info["prefilled_from_db"] = len(self.prefilled)
        self.delta_info["to_author"] = len(delta) - len(self.prefilled)
        log.info("Delta mode: %d existing, %d new attribute(s) in %d table(s); %d prefilled from DB, %d to author",
                 len(existing), len(delta), len(self.active_tables), len(self.prefilled), len(delta) - len(self.prefilled))
        return self.delta_info

    def read_published_rows(self, sync) -> dict:
        """Rows of output.metadata_table keyed by (table, column); read once per run."""
        cached = getattr(self, "_published_rows_cache", None)
        if cached is not None:
            return cached
        rows = {}
        if sync.table_exists(self.cfg.output["metadata_table"]):
            df = sync.gp.read(f"select * from {sync.schema}.{self.cfg.output['metadata_table']}").fillna("")
            for r in df.to_dict("records"):
                rows[(str(r["table_name"]).lower(), str(r["column_name"]).lower())] = r
        self._published_rows_cache = rows
        return rows

    def prepare_evidence_skip(self, sync) -> int:
        """Delta mode: intermediate (lineage-scope) IKG attributes that are already published WITH an upstream value
        need no evidence pack this run - they are neither authored nor part of the graph / clone rules."""
        if str(self.gen.get("mode", "delta")) != "delta":
            return 0
        try:
            rows = self.read_published_rows(sync)
        except Exception as e:  # noqa: BLE001
            log.warning("could not read %s before the evidence build (%s)", self.cfg.output["metadata_table"], e)
            return 0
        self.evidence_skip = {k for k, r in rows.items() if str(r.get("upstream", "")).strip()
                              and self.table_domain.get(k[0]) == "ikg_lineage"}
        return len(self.evidence_skip)

    def _apply_budget(self, delta):
        """generation.max_new_attributes_per_run: whole tables in order until the cap is reached (at least one table)."""
        cap = int(self.gen.get("max_new_attributes_per_run", 0) or 0)
        if cap <= 0 or len(delta) <= cap:
            return delta, {"attributes": 0, "tables": []}
        # profile tables first, then ODM / NLG, then intermediate tables; inside a group in table order
        rank = {"ikg": 0, "odm": 1, "nlg": 1, "ikg_lineage": 2}
        tables = sorted({t for t, _ in delta}, key=lambda t: (rank.get(self.domain_of(t), 3), t))
        per = {t: [(a, c) for a, c in delta if a == t] for t in tables}
        keep, total = [], 0
        for t in tables:
            if total and total + len(per[t]) > cap:
                break
            keep += per[t]
            total += len(per[t])
        rest = [x for x in delta if x not in set(keep)]
        info = {"attributes": len(rest), "tables": sorted({t for t, _ in rest})}
        log.info("budget: %d of %d new attributes this run (max_new_attributes_per_run=%d); backlog %d attributes in %d tables",
                 len(keep), len(delta), cap, len(rest), len(info["tables"]))
        return keep, info

    def _domain_table_skips(self, existing: set) -> set:
        """domains.<d>.skip_rule = table: a table with ANY attribute already published is skipped completely
        (NLG); column: only the published attributes are skipped (ODM, same as the profile tables)."""
        skipped = set()
        pub_tables = {t for t, _ in existing}
        for t, d in self.table_domain.items():
            rule = str(((self.cfg.get("domains") or {}).get(d) or {}).get("skip_rule", "column")).lower()
            if rule == "table" and t in pub_tables:
                skipped.add(t)
        return skipped

    def apply_domain_skip_rules(self, sync) -> dict:
        """generation.mode = full: profile tables are regenerated, but the ODM / NLG skip rules still apply."""
        existing = sync.existing_pairs()
        skipped = self._domain_table_skips(existing)
        keep = [(t, c) not in existing or t not in self.table_domain for t, c in zip(self.ctx.table_name, self.ctx.column_name)]
        keep = [k and t not in skipped for k, t in zip(keep, self.ctx.table_name)]
        before = len(self.ctx)
        self.ctx_full = self.ctx
        self.db_rows = {k: v for k, v in self.published_rows.items()}
        self.ctx = self.ctx[keep].reset_index(drop=True)
        self.active_tables = sorted(set(self.ctx.table_name))
        self.delta_info = {"mode": "full (profile tables) + skip rules for ODM / NLG", "existing_in_db": len(existing),
                           "attributes": len(self.ctx), "removed_by_skip_rules": before - len(self.ctx),
                           "odm_nlg_tables_skipped (already in metadata table)": sorted(skipped)}
        return self.delta_info

    def all_results_frame(self) -> pd.DataFrame:
        """Current results + rows already published in the metadata table (delta mode) = every profile table."""
        cur = self.results if self.results is not None else pd.DataFrame(columns=["table_name", "column_name"])
        db = getattr(self, "db_rows", None)
        if not db:
            return cur
        have = set(zip(cur.table_name, cur.column_name)) if len(cur) else set()
        ctx_full = getattr(self, "ctx_full", self.ctx)
        ev = ctx_full.set_index(["table_name", "column_name"])
        rows = []
        for (t, c), r in db.items():
            if (t, c) in have or t not in self.schemas:
                continue
            e = ev.loc[(t, c)] if (t, c) in ev.index else None
            rows.append({"table_name": t, "column_name": c, "ordinal": int(e.ordinal) if e is not None else 0,
                         "entity": r.get("entity", ""), "functional_name": r.get("business_attribute_name", ""),
                         "business_description": r.get("description", ""), "attribute_type": r.get("attribute_type", ""),
                         "confidence_score": int(r.get("confidence_score") or 0), "confidence_band": r.get("confidence_band", ""),
                         "derivation_type": r.get("derivation_type", ""), "unit": r.get("unit", ""),
                         "confidence_reason": r.get("confidence_reason", ""),
                         "difficult_to_generate": str(r.get("difficult_to_generate", "")).lower() == "true",
                         "what_is_required": r.get("what_is_required", ""), "evidence_used": r.get("evidence_used", ""),
                         "verify_verdict": r.get("verify_verdict", ""), "shared_from": "published (db)",
                         "needs_review": False, "sql_expression": e.sql_expression if e is not None else "",
                         "data_type": e.data_type if e is not None else "", "table_entity": self.table_entity(t),
                         "is_technical": bool(e.is_technical) if e is not None else False,
                         "domain": self.domain_of(t), "schema_name": self.table_schema(t),
                         "upstream": r.get("upstream") or (e.upstream if e is not None and "upstream" in e else ""),
                         "current_datetime": r.get("current_datetime", "")})
        if not rows:
            return cur
        return pd.concat([cur, pd.DataFrame(rows)], ignore_index=True, sort=False)

    # ------------------------------------------------------------------ agent integration
    def apply_skill_knowledge(self, brief: dict) -> None:
        """Verified skill-file knowledge -> glossary (abbreviations, code values). SME overrides still win."""
        n = 0
        for a in brief.get("abbreviations", []):
            t = str(a.get("abbreviation", "")).lower().strip()
            e = self.glossary.entries.get(t)
            if not t or not a.get("full_form") or (e and e["source"] == "SME override"):
                continue
            if e is None:
                e = {"abbreviation": t, "occurrences": 0, "example_columns": "", "evidence": ""}
                self.glossary.entries[t] = e
            e.update(full_form=a["full_form"], is_abbreviation=True, status="RESOLVED", confidence=97,
                     source=f"skill file ({a['source_file']})", evidence=f"skill quote: {a.get('quote', '')[:150]}")
            n += 1
        for cv in brief.get("code_values", []):
            col = str(cv.get("column", "")).lower()
            self.glossary.code_values.setdefault(col, {})[str(cv.get("code"))] = cv.get("meaning")
        # authoritative column definitions: SME overrides + skill files
        for cd in brief.get("column_definitions", []):
            col = str(cd.get("column", "")).lower()
            if col and cd.get("definition"):
                self.skill_column_defs[col] = f"{cd['definition']} [{cd.get('source_file', 'skill')}]"
        # tokens resolved from EDW / code aliases that occur in a skill-defined column are re-checked by the
        # dictionary agent against that definition (e.g. mhh in acc_mhh_n)
        rechecked = 0
        for col, definition in self.skill_column_defs.items():
            for tok in tokenize(col):
                e = self.glossary.entries.get(tok)
                if not e or not e.get("is_abbreviation") or e["source"] in ("SME override",) or "skill" in e["source"]:
                    continue
                if e["status"] == "RESOLVED" and e["full_form"].lower() not in definition.lower():
                    e.update(status="RECHECK", full_form="", confidence=0,
                             recheck_reason=f"earlier guess '{e['full_form']}' ({e['source']}) is not consistent with the "
                                            f"skill definition of {col}: {definition[:200]}")
                    rechecked += 1
        if rechecked:
            log.info("Glossary: %d token(s) sent back for re-check against skill column definitions", rechecked)
        self.refresh_glossary_columns()
        log.info("Skill knowledge applied: %d abbreviations, %d code values", n, len(brief.get("code_values", [])))

    def refresh_glossary_columns(self) -> None:
        exp_unres = self.ctx.column_name.map(self.glossary.expand)
        self.ctx["abbreviations"] = exp_unres.map(lambda x: x[0])
        self.ctx["unresolved_tokens"] = exp_unres.map(lambda x: ", ".join(x[1]))
        self.ctx["skill_definition"] = self.ctx.column_name.map(lambda c: self.skill_column_defs.get(c, ""))
        cv = self.glossary.code_values
        self.ctx["code_values"] = self.ctx.column_name.map(lambda c: json.dumps(cv[c]) if c in cv else "")

    def results_from_agents(self, results: Dict) -> None:
        self.results = self.frame_from_agents(results or {})      # empty frame (never None) when nothing was authored
        for c, d in (("confidence_score", 0), ("confidence_band", ""), ("needs_review", False), ("what_is_required", "")):
            if c not in self.results.columns:
                self.results[c] = d

    def frame_from_agents(self, results: Dict, table: Optional[str] = None) -> pd.DataFrame:
        rows = [v for (t, _), v in results.items() if table is None or t == table]
        ctx = self.ctx if table is None else self.ctx[self.ctx.table_name == table]
        gen = pd.DataFrame(rows) if rows else pd.DataFrame(columns=["table_name", "column_name"])
        df = ctx.merge(gen, on=["table_name", "column_name"], how="left")
        for c, d in (("functional_name", ""), ("business_description", ""), ("llm_confidence", 0),
                     ("difficult_to_generate", True), ("what_is_required_llm", ""), ("verify_verdict", ""),
                     ("unresolved_abbreviations_llm", ""), ("evidence_used", "")):
            if c not in df:
                df[c] = d
            df[c] = df[c].fillna(d)
        return df

    # ------------------------------------------------------------------ all
    def run_all(self, use_llm: bool = True) -> Path:
        self.load_sources()
        self.parse_code()
        self.build_evidence()
        self.build_glossary(use_llm=use_llm)
        if not use_llm:
            self.preview_prompts()
            return self.out
        self.analyze_tables()
        self.generate()
        self.score()
        if self.gen.get("verify_pass", True):
            self.verify()
            self.score()
        from .knowledge_graph import KnowledgeGraph
        kg = KnowledgeGraph(self.cfg, self)
        kg.build()
        path = self.write(kg.relationships_frame())
        kg.export()
        return path


class TableSchemaStub:
    """TableSchema-like object for a table whose columns come from information_schema (no parsable script)."""

    def __init__(self, table: str, source_file: str, columns: list):
        self.table, self.source_file, self.columns = table, source_file, columns
        self.method, self.distribution_key, self.warnings = "information_schema", [], []


class MultiResolver:
    """One LineageResolver per repository; dispatches by the table's domain (ikg first for unknown tables)."""

    def __init__(self, p: "MetadataPipeline", max_depth: int, max_steps: int):
        self.p = p
        self.resolvers: Dict[str, LineageResolver] = {}
        for d, r in p.repos.items():
            root = r.sql_root()
            if root.exists():
                try:
                    self.resolvers[d] = LineageResolver(root, max_depth=max_depth, max_steps=max_steps)
                except Exception as e:  # noqa: BLE001
                    log.warning("%s: SQL index failed: %s", d, e)
        self.writers: Dict[str, list] = {}
        for d in ["ikg"] + [x for x in self.resolvers if x != "ikg"]:
            r = self.resolvers.get(d)
            if r is not None:
                for t, ws in r.writers.items():
                    self.writers.setdefault(t, ws)

    def _for(self, table: str) -> Optional[LineageResolver]:
        d = self.p.domain_of(table)
        if d in self.resolvers and table in self.resolvers[d].writers:
            return self.resolvers[d]
        for d2, r in self.resolvers.items():
            if table in r.writers:
                return r
        return self.resolvers.get("ikg")

    def from_tables(self, table: str):
        r = self._for(table)
        return r.from_tables(table) if r else set()

    def resolve(self, table: str, column: str):
        r = self._for(table)
        return r.resolve(table, column) if r else ([], [], "")


def agent_sheets(ctx) -> Dict[str, pd.DataFrame]:
    sb = ctx.skills_brief or {}
    rows = []
    for k in ("definitions", "abbreviations", "entity_definitions", "relationship_rules", "authoring_rules",
              "code_values", "table_notes"):
        for it in sb.get(k, []):
            rows.append({"kind": k, "item": " | ".join(str(it.get(x, "")) for x in it if x not in ("quote", "source_file")),
                         "source_file": it.get("source_file", ""), "quote": it.get("quote", "")})
    briefs = []
    for t, b in ctx.table_briefs.items():
        briefs.append({"table_name": t, "table_purpose": b.get("table_purpose", ""), "grain": b.get("grain", ""),
                       "population": b.get("population", ""),
                       "key_business_rules": "\n".join(f"- {x['rule']}  [SQL: {x['sql_quote'][:120]}]" for x in b.get("key_business_rules", [])),
                       "time_windows": "\n".join(f"{x['token']}: {x['meaning']}" for x in b.get("time_windows", [])),
                       "data_sources": "\n".join(b.get("data_sources", [])), "caveats": "\n".join(b.get("caveats", [])),
                       "catalog_notes": (ctx.catalog_notes.get(t) or {}).get("notes", ""),
                       "catalog_quality_flags": "\n".join((ctx.catalog_notes.get(t) or {}).get("data_quality_flags", []))})
    vp = [{"table_name": t, "column_name": c, "value_profile": v} for (t, c), v in ctx.value_profiles.items()]
    gr = ctx.graph_review or {}
    out = {"Skills_Knowledge": pd.DataFrame(rows), "Table_Briefs": pd.DataFrame(briefs),
           "Value_Profiles": pd.DataFrame(vp),
           "Graph_Review": pd.DataFrame(gr.get("relationship_changes", []))}
    for k in ("ODM_NLG_Tables", "Lineage_Scope", "Joining_Keys", "Clone_Summary", "Clone_Duplicates", "Clone_Report", "Delta_Summary", "Token_Stats", "Token_Stats_By_Table"):
        if getattr(ctx, "extra_sheets", {}).get(k) is not None:
            out[k] = ctx.extra_sheets[k]
    out["Agent_Trace"] = pd.DataFrame(ctx.trace.rows)
    return out


REPORT_DB_COLUMNS = ["table_name", "column_name", "ordinal", "entity", "functional_name", "business_description",
                     "attribute_type", "derivation_type", "unit", "confidence_score", "confidence_band",
                     "needs_review", "difficult_to_generate", "what_is_required", "confidence_reason",
                     "verify_verdict", "terminal_sources", "source_definitions", "sql_expression", "upstream", "current_datetime"]


def upstream_text(table: str, column: str, db, chain, code_src) -> str:
    """Upstream hops of one attribute: lineage-table hops first, else the code chain, ending in the source columns."""
    txt = db.hops_text(table, column) if db is not None else ""
    if txt:
        return txt[:1500]
    parts = [f"{table}.{column}"]
    for st in list(chain or [])[1:10]:
        lab = f"{st.obj}.{st.column}"
        if lab not in parts:
            parts.append(lab)
    for src in list(code_src or [])[:4]:
        if src not in parts:
            parts.append(src)
    return (" <- ".join(parts) if len(parts) > 1 else "")[:1500]


def _int(v, default=0) -> int:
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return default
