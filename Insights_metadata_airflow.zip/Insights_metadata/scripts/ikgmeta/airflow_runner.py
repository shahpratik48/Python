"""
Airflow entry point (DAG Insights_metadata) - same logic as the notebook, only the inputs differ:

    notebook : config/ikg_metadata_config.yaml + secrets asked at run time (or env variables)
    Airflow  : Variables ENV, IKG_SCHEMA, EDW_INPUT_SCHEMA, GENESIS_DDLC_IKG_GIT_SECRET, IKG_AZURE_OPENAI_API_KEY
               + Connection IKG_GP_GPRDSP  (names configurable in config: airflow.*)

`run_insights_metadata(...)` is Airflow-agnostic (plain arguments) so it can be unit-tested; the DAG file collects
the Variables / Connection and calls it. Secrets are put into the in-memory secret store only.
"""
from __future__ import annotations

import json
import logging
import os
import tempfile
import time
import traceback
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

log = logging.getLogger(__name__)


def build_config(env: str = "PROD", ikg_schema: Optional[str] = None, edw_input_schema: Optional[str] = None,
                 gp: Optional[dict] = None, output_dir: Optional[str] = None, config_path: Optional[str] = None,
                 owner_role: Optional[str] = None, reader_role: Optional[str] = None):
    """Config for one Airflow run: ODM_ENV (PROD | UAT | TEST) selects schema, NLG ini section and roles; the
    Variables IKG_SCHEMA / IKG_TABLE_OWNER_GROUP / IKG_TABLE_READER_GROUP override them when set."""
    from .config import apply_environment, load_config
    cfg = load_config(config_path, environment=env)
    apply_environment(cfg, env, ikg_schema=ikg_schema, owner_role=owner_role, reader_role=reader_role)
    if edw_input_schema:
        cfg["domains"]["edw_input_schema"] = edw_input_schema.strip().lower()
        ups = list(cfg["domains"].get("upstream_schemas") or [])
        if cfg["domains"]["edw_input_schema"] not in ups:
            ups.append(cfg["domains"]["edw_input_schema"])
        cfg["domains"]["upstream_schemas"] = ups
    if gp:
        for k in ("host", "port", "database", "user"):
            if gp.get(k):
                cfg["greenplum"][k] = gp[k]
    if output_dir:
        out = Path(output_dir)
    else:                                   # persistent folder when the Airflow data mount exists (keeps the repo / LLM caches)
        base = Path("/opt/airflow/data")
        out = (base / "insights_metadata") if base.is_dir() and os.access(base, os.W_OK) else Path(tempfile.gettempdir()) / "insights_metadata"
    cfg["output"]["folder"] = str(out)
    cfg["skills"]["generated_folder"] = str(out / "skills")       # DAG folder is usually read-only
    return cfg


def run_insights_metadata(env: str = "PROD", ikg_schema: Optional[str] = None, edw_input_schema: Optional[str] = None,
                          gitlab_token: Optional[str] = None, azure_key: Optional[str] = None,
                          gp: Optional[dict] = None, output_dir: Optional[str] = None, run_id: str = "",
                          config_path: Optional[str] = None, orchestration: Optional[str] = None,
                          selftest: bool = False, owner_role: Optional[str] = None, reader_role: Optional[str] = None,
                          backfill_runs: int = 1, backfill_minutes: float = 0) -> dict:
    """Whole pipeline (prepare -> agents -> outputs -> Greenplum load). Returns a JSON-serialisable summary that the
    DAG pushes to XCom and renders into the e-mail."""
    from . import agents
    from . import sources as src
    from .config import set_secret
    from .llm import LLM

    t0 = time.time()
    cfg = build_config(env, ikg_schema, edw_input_schema, gp, output_dir, config_path, owner_role, reader_role)
    out = Path(cfg["output"]["folder"])
    out.mkdir(parents=True, exist_ok=True)
    from .runlog import start_log_file
    log_path = start_log_file(out)
    log.info("Insights_metadata run %s | ODM_ENV=%s | IKG schema %s | EDW schema %s | owner %s | reader %s | output %s",
             run_id, cfg["environment"], cfg["greenplum"]["schema"], cfg["domains"].get("edw_input_schema"),
             cfg["greenplum"]["table_owner_role"], cfg["greenplum"]["table_reader_role"], out)
    if gitlab_token:
        set_secret("gitlab_token", gitlab_token)
    if azure_key:
        set_secret("llm_api_key", azure_key)
    if gp and gp.get("password"):
        set_secret("gp_password", gp["password"])
    summary: Dict[str, object] = {"run_id": run_id, "environment": cfg["environment"], "ikg_schema": cfg["greenplum"]["schema"],
                                  "table_owner_role": cfg["greenplum"]["table_owner_role"], "table_reader_role": cfg["greenplum"]["table_reader_role"],
                                  "nlg_ini_section": (cfg["domains"]["nlg"].get("ini_section") or {}).get(cfg["environment"], ""),
                                  "edw_input_schema": cfg["domains"].get("edw_input_schema"), "output_dir": str(out),
                                  "started": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "status": "running",
                                  "log_file": str(log_path)}
    try:
        gp_client = src.Greenplum(cfg) if cfg["sources"]["mode"] == "db" else None
        if selftest:
            from .agents.selftest import ScriptedLLM
            llm = ScriptedLLM(cfg, out / "cache")
        else:
            llm = LLM(cfg, out / "cache")
        n_runs = max(1, int(backfill_runs or 1))
        if n_runs > 1:
            ctx, res = agents.run_until_done(cfg, llm, gp_client, max_runs=n_runs, max_minutes=backfill_minutes,
                                             mode=orchestration or cfg.get("agents", {}).get("orchestration", "deterministic"))
            summary["backfill_runs"] = res.get("backfill_runs", [])
        else:
            ctx = agents.prepare(cfg, llm, gp_client)
        p = ctx.p
        summary["tables"] = {"ikg_profile": len(p.ikg_schemas()),
                             "odm": sorted(t for t, d in p.table_domain.items() if d == "odm"),
                             "nlg": sorted(t for t, d in p.table_domain.items() if d == "nlg"),
                             "nlg_ini_section": getattr(p.loader, "nlg_section", "") if p.loader else ""}
        summary["delta"] = {k: v for k, v in (p.delta_info or {}).items() if k not in ("deployed_but_not_in_code",) and not k.endswith("_all")}
        if n_runs <= 1:
            res = agents.run(ctx, orchestration or cfg.get("agents", {}).get("orchestration", "deterministic"))
        summary["backlog"] = agents.backlog_of(ctx)
        q = res.get("quality", {})
        summary.update({"status": "success", "quality": q, "greenplum": res.get("greenplum"),
                        "workbook": res.get("workbook") or str(out / cfg["output"]["metadata_xlsx"]),
                        "graph_html": res.get("graph_html") or str(out / "knowledge_graph" / "knowledge_graph.html"),
                        "graph_md": res.get("graph_md", ""), "skill_md": res.get("skill_md", ""),
                        "clone_sql": res.get("clone_sql", ""), "refreshed_tables": res.get("refreshed_tables", ""),
                        "token_stats": res.get("token_stats", ""),
                        "diagrams": str(out / "knowledge_graph" / "diagrams" / "index.html"),
                        "llm_usage": llm.token_stats()["total"] if hasattr(llm, "token_stats") else getattr(llm, "usage", {}),
                        "refreshed": res.get("refreshed_tables_list") or _read_refreshed(res.get("refreshed_tables", "")),
                        "errors": list(q.get("recent_errors") or [])[:20]})
    except Exception as e:  # noqa: BLE001
        log.exception("Insights_metadata failed")
        summary.update({"status": "failed", "error": f"{type(e).__name__}: {e}", "traceback": traceback.format_exc()[-4000:]})
    summary["duration_minutes"] = round((time.time() - t0) / 60, 1)
    summary["finished"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    summary["email_html"] = email_html(summary)
    (out / "run_summary.json").write_text(json.dumps(summary, indent=1, default=str), encoding="utf-8")
    summary["attachments"] = attachments(summary)          # workbook (if < 15 MB) + run_summary.json
    if summary["status"] != "success":
        raise RuntimeError(summary.get("error", "Insights_metadata failed"))
    return summary


# ----------------------------------------------------------------------------- helpers
def _read_refreshed(path: str) -> List[dict]:
    try:
        txt = Path(path).read_text(encoding="utf-8")
    except Exception:  # noqa: BLE001
        return []
    return [{"line": l[3:]} for l in txt.splitlines() if l.startswith("-- ") and ":" in l][1:]


def attachments(summary: dict, max_mb: float = 15.0) -> List[str]:
    """workbook, graph html, clone .sql.txt, token stats, refreshed-table queries, log file, run summary."""
    files = []
    for key in ("workbook", "graph_html", "clone_sql", "token_stats", "refreshed_tables", "log_file"):
        f = summary.get(key)
        if f and os.path.exists(str(f)) and os.path.getsize(str(f)) <= max_mb * 1024 * 1024:
            files.append(str(f))
    rs = os.path.join(str(summary.get("output_dir", "")), "run_summary.json")
    if os.path.exists(rs):
        files.append(rs)
    return files


def email_html(s: dict) -> str:
    import html as H
    ok = s.get("status") == "success"
    q = s.get("quality") or {}
    d = s.get("delta") or {}
    t = s.get("tables") or {}
    rows = [
        ("Status", "SUCCESS" if ok else f"FAILED - {s.get('error', '')}"),
        ("ODM_ENV / IKG schema / NLG ini section", f"{s.get('environment')} / {s.get('ikg_schema')} / [{s.get('nlg_ini_section', '')}]"),
        ("Table owner / reader role", f"{s.get('table_owner_role')} / {s.get('table_reader_role')}"),
        ("Started / finished / duration", f"{s.get('started')} / {s.get('finished')} / {s.get('duration_minutes')} min"),
        ("IKG profile tables in scope", t.get("ikg_profile", "")),
        ("ODM tables", ", ".join(t.get("odm", []) or []) or "(none)"),
        ("NLG tables", f"{len(t.get('nlg', []) or [])} from nlg_db_tables.ini [{t.get('nlg_ini_section', '')}]"),
        ("Delta", f"mode {d.get('mode', '')}; existing {d.get('existing_in_db', '')}; new attributes this run {d.get('new_pairs', d.get('attributes', ''))}; "
                  f"backlog for next runs {d.get('backlog_attributes_for_next_runs', 0)} attributes in {len(d.get('backlog_tables_for_next_runs', []) or [])} tables"
                  + (f"; backfill: {len(s['backfill_runs'])} run(s) in this DAG run" if s.get("backfill_runs") else "")
                  + (f"; deferred by time budget: {', '.join(d.get('deferred_by_time_budget', [])[:10])}" if d.get("deferred_by_time_budget") else "")),
        ("ODM / NLG tables skipped (already in metadata table)", ", ".join(d.get("odm_nlg_tables_skipped (already in metadata table)", []) or []) or "(none)"),
        ("Attributes authored", f"{q.get('attributes_done', 0)} (High {q.get('high', 0)}, Medium {q.get('medium', 0)}, Low {q.get('low', 0)}, difficult {q.get('difficult', 0)})"),
        ("Glossary needs input", q.get("glossary_needs_input", "")),
        ("Greenplum load", H.escape(json.dumps(s.get("greenplum"), default=str)) if s.get("greenplum") else "(not loaded)"),
        ("Errors", "<br>".join(H.escape(str(x)) for x in (s.get("errors") or [])) or str(q.get("errors", 0))),
        ("Tables refreshed", "<br>".join(H.escape(f"{r.get('table', '')}: {r.get('action', r.get('line', ''))}") for r in (s.get("refreshed") or [])) or "(none)"),
        ("Workbook", s.get("workbook", "")), ("Knowledge graph", f"{s.get('graph_html', '')} (markdown: {s.get('graph_md', '')}, index: {s.get('skill_md', '')})"),
        ("ODM / NLG diagrams", s.get("diagrams", "")), ("Clone script / refreshed-table queries", f"{s.get('clone_sql', '')} / {s.get('refreshed_tables', '')}"),
        ("Log file", s.get("log_file", "")),
        ("Tokens", _tokens_html(s.get("llm_usage") or {})),
    ]
    body = "".join(f"<tr><td style='padding:4px 10px;color:#555;white-space:nowrap'><b>{H.escape(str(k))}</b></td>"
                   f"<td style='padding:4px 10px'>{v if k in ('Greenplum load', 'Errors', 'Tokens', 'Tables refreshed') else H.escape(str(v))}</td></tr>" for k, v in rows)
    color = "#2e7d32" if ok else "#c62828"
    return (f"<div style='font-family:Segoe UI,Arial,sans-serif;font-size:13px'><h3 style='color:{color}'>Insights metadata "
            f"(IKG profiles + ODM + NLG) - {'Success' if ok else 'Failed'}</h3><table style='border-collapse:collapse'>{body}</table>"
            f"<p style='color:#777'>Generated by the Insights_metadata DAG (run {H.escape(str(s.get('run_id', '')))}).</p></div>")


def _tokens_html(u: dict) -> str:
    if not u:
        return ""
    return (f"total <b>{u.get('total_tokens', 0):,}</b> (prompt {u.get('prompt_tokens', 0):,}, completion {u.get('completion_tokens', 0):,}, "
            f"reasoning {u.get('reasoning_tokens', 0):,}, cached {u.get('cached_tokens', 0):,}); {u.get('calls', 0)} calls, "
            f"{u.get('cache_hits', 0)} cache hits, {u.get('rate_limit_hits', 0)} rate-limit hits; {u.get('tokens_per_minute_avg', 0):,} tokens/min - "
            f"per process in token_stats.txt (attached)")
