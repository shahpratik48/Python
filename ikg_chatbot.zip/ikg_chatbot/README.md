# IKG Chatbot (project 2)

Natural-language questions over the IKG profile tables, answered with grounded text-to-SQL.
Uses the outputs of project 1 (metadata & knowledge graph) to understand the data, GPT-5 (Azure OpenAI) to plan and
write SQL, and Greenplum to run it. Read-only, every query guarded and bounded.

```
python run_chatbot.py --selftest        # offline check: synthetic data + scripted model (no secrets)
python run_chatbot.py --check           # Greenplum / Azure OpenAI / GitLab connectivity + which sources exist
python run_chatbot.py --build-catalog   # (re)build output/catalog.json after project 1 re-runs
python run_chatbot.py --ask "households with assets over 100M and their accounts"
python run_chatbot.py                   # interactive chat
jupyter notebook IKG_Chatbot.ipynb      # notebook chat
streamlit run app_streamlit.py          # optional web UI (pip install streamlit)
```

## Sources the chatbot uses (make sure they exist)

| # | Source | Where | Required | Used for |
|---|---|---|---|---|
| 1 | `core_ikg.*_profile_curr_ikg_v2` (clones from project 1) | Greenplum | yes | the ONLY tables queried (`sources.profile_table_pattern`) |
| 2 | `core_ikg.ikg_attribute_business_description` | Greenplum | yes* | business name + description of every column -> picking the right column |
| 3 | `core_ikg.ikg_graph_joining_key` | Greenplum | recommended | how tables join (falls back to entity keys) |
| 4 | `core_ikg.ikg_graph_relationship` | Greenplum | optional | entity relationships for explanations |
| 5 | `core_ikg.ikg_metadata_glossary_llm` | Greenplum | recommended | abbreviation -> meaning (query expansion) |
| 6 | `core_ikg.ikg_profile_table_descriptions` | Greenplum | recommended | table grain / purpose / join keys |
| 7 | `information_schema` of the `_v2` tables | Greenplum | yes | real columns and types (the guard checks every column) |
| 8 | GitLab `ikg-dags` @ `main`, `dags/ikg/scripts/sql/ikg_create_profiles` | GitLab | optional | how a column is derived (tool `profile_sql`); `gitlab.enabled: false` to skip |
| 9 | `config/entity_model.yaml` | file (copied from project 1) | yes | entities and their keys |
| 10 | `config/concepts.yaml`, `config/question_bank.yaml` | files | yes | business synonyms, example questions with hints |
| 11 | `skills/*.md` (flat) | files | yes | authoritative business rules (household definition, query conventions) |
| 12 | project-1 workbook `IKG_Profile_Attribute_Metadata.xlsx` | file | fallback | only when table 2 is missing (`sources.metadata_workbook`) |
| 13 | Azure OpenAI deployment `gpt-5-pshah` | Azure | yes | query agent + answer agent |

\* without 2 the bot still runs but only knows column names.

Secrets: `IKG_AZURE_OPENAI_API_KEY`, `IKG_GP_PASSWORD`, `IKG_GITLAB_TOKEN` (env) or hidden prompts. Never stored.

## How a question is answered

1. **Query agent** (GPT-5, tool calling): searches the catalog (synonyms + glossary expanded), reads the business
   descriptions of the columns it wants to use, checks joining keys and sample values, writes PostgreSQL, previews it
   with LIMIT 5, submits SQL + assumptions. It asks ONE clarifying question when a value is missing (x%, $x, which FA).
2. **Guard** (`ikgchat/sqlguard.py`): parses the SQL (sqlglot), allows one SELECT only, only the `_v2` tables, every
   column must exist, no `SELECT *`, injects `LIMIT max_rows+1`.
3. **Execution**: EXPLAIN, then run under `statement_timeout`; database errors go back to the agent (2 repair rounds).
4. **Facts** are computed in pandas (row count, totals, min/max, top rows). The **answer agent** writes the reply from
   those facts only - a number not present in the facts is rejected.
5. Large result: preview rows + true count + options: export CSV, top N, add filter, summarise. `next` pages.

## Configuration (`config/chatbot_config.yaml`)
`llm`, `greenplum`, `gitlab`, `sources` (table names, pattern, cache), `query` (preview_rows, max_rows,
export_max_rows, placeholders, select-star policy, fix rounds), `answer` (show_sql, options), `agents`.

## Files
```
IKG_Chatbot.ipynb        notebook chat          run_chatbot.py   CLI / --selftest / --check
app_streamlit.py         optional web UI        config/          chatbot_config.yaml, concepts.yaml, question_bank.yaml, entity_model.yaml
skills/                  business rules (.md)   prompts/         query_agent.md, answer_agent.md
ikgchat/catalog.py       catalog from project-1 tables + information_schema, lexical search
ikgchat/sqlguard.py      SQL guard              ikgchat/session.py   conversation, execution, facts, options, export
ikgchat/agents/          base (agent loop), tools, specialists (QueryAgent, AnswerAgent), context
ikgchat/db.py            Greenplum read-only    ikgchat/code.py  GitLab profile SQL (optional)
ikgchat/selftest.py      offline self-test      output/          catalog.json, chat_history.jsonl, exports/
```
