"""
IKG Chatbot - ChatGPT-style web UI with no extra dependencies (Python standard library HTTP server).

  python app_web.py                 # asks for the secrets (hidden), then serves http://localhost:8765
  python app_web.py --port 9000 --host 0.0.0.0 --no-browser

Left: new chat, example questions, this session's questions. Centre: the conversation. Bottom: the question box.
Each answer shows the text, the result table, the options for large results, the SQL (collapsed) and assumptions.
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ikgchat  # noqa: E402
from ikgchat.config import load_config, get_secret  # noqa: E402

log = logging.getLogger("app_web")
HTML_PATH = Path(__file__).resolve().parent / "web" / "index.html"

STATE = {"ctx": None, "sessions": {}, "lock": threading.Lock(), "cfg": None}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):      # quieter log
        log.debug(fmt, *args)

    def _send(self, code: int, body: bytes, ctype: str = "application/json; charset=utf-8", extra=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj, ensure_ascii=False, default=str).encode("utf-8"))

    def do_GET(self):
        u = urlparse(self.path)
        if u.path in ("/", "/index.html"):
            self._send(200, HTML_PATH.read_bytes(), "text/html; charset=utf-8")
        elif u.path == "/api/status":
            ctx = STATE["ctx"]
            cat = ctx.cat
            self._json({"ready": True, "tables": len(cat.tables), "columns": sum(len(t.columns) for t in cat.tables.values()),
                        "schema": cat.schema, "model": STATE["cfg"].llm["deployment"], "notes": cat.notes,
                        "examples": [q["q"] for q in cat.question_bank[:12]]})
        elif u.path == "/api/chats":
            self._json({"chats": ikgchat.chat_store(STATE["ctx"]).list_chats()})
        elif u.path.startswith("/api/chats/"):
            cid = u.path.split("/")[3]
            sess = _session(cid)
            msgs = ikgchat.chat_store(STATE["ctx"]).messages(cid)
            self._json({"chat_id": cid, "title": sess.title, "messages": [
                {"role": m["role"], "text": m["text"], "ts": m.get("created_ts", ""), "payload": m.get("payload") or {}} for m in msgs]})
        elif u.path == "/api/download":
            f = parse_qs(u.query).get("file", [""])[0]
            p = Path(f)
            exports = STATE["cfg"].path(STATE["cfg"].output["exports_folder"]).resolve()
            if not p.exists() or exports not in p.resolve().parents:
                self._json({"error": "file not found"}, 404)
                return
            self._send(200, p.read_bytes(), "text/csv", {"Content-Disposition": f'attachment; filename="{p.name}"'})
        else:
            self._json({"error": "not found"}, 404)

    def do_POST(self):
        u = urlparse(self.path)
        n = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(n) or b"{}")
        if u.path == "/api/chats":                       # new chat
            with STATE["lock"]:
                s = ikgchat.new_session(STATE["ctx"])
                STATE["sessions"][s.chat_id] = s
            self._json({"chat_id": s.chat_id, "title": s.title})
            return
        if u.path == "/api/ask":
            q = (body.get("question") or "").strip()
            cid = body.get("chat_id") or ""
            s = _session(cid) if cid else None
            if s is None:
                with STATE["lock"]:
                    s = ikgchat.new_session(STATE["ctx"])
                    STATE["sessions"][s.chat_id] = s
            a = s.ask(q)
            d = a.to_dict()
            d["chat_id"], d["title"] = s.chat_id, s.title
            self._json(d)
            return
        if u.path == "/api/delete":
            cid = body.get("chat_id") or ""
            ikgchat.chat_store(STATE["ctx"]).delete_chat(cid)
            with STATE["lock"]:
                STATE["sessions"].pop(cid, None)
            self._json({"ok": True})
            return
        self._json({"error": "not found"}, 404)


def _session(chat_id: str):
    """Live session for a chat id; a saved chat is restored (messages + context) on first use."""
    with STATE["lock"]:
        s = STATE["sessions"].get(chat_id)
        if s is None:
            s = ikgchat.new_session(STATE["ctx"], chat_id=chat_id)
            STATE["sessions"][chat_id] = s
        return s


def main(argv=None):
    ap = argparse.ArgumentParser(description="IKG Chatbot web UI")
    ap.add_argument("--config", default=None)
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--rebuild-catalog", action="store_true")
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--selftest-data", action="store_true", help="serve the UI on the synthetic self-test data (no secrets)")
    a = ap.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    for n in ("sqlglot", "httpx", "httpx2", "openai", "urllib3"):
        logging.getLogger(n).setLevel(logging.ERROR)
    cfg = load_config(a.config)
    STATE["cfg"] = cfg
    if a.selftest_data:
        from ikgchat.selftest import FakeGreenplum, ScriptedLLM, make_fake_db
        out = cfg.path(cfg.output["folder"]) / "selftest"
        out.mkdir(parents=True, exist_ok=True)
        cfg["sources"]["catalog_cache"] = str(out / "catalog.json")
        cfg["gitlab"]["enabled"] = False
        cfg["storage"]["folder"] = str(out / "chats")
        db = out / "fake_gp.db"
        make_fake_db(db)
        STATE["ctx"] = ikgchat.prepare(cfg, llm=ScriptedLLM(cfg, out), gp=FakeGreenplum(cfg, db), rebuild_catalog=True, fetch_code=False)
    else:
        get_secret("llm_api_key")
        get_secret("gp_password")
        if cfg.gitlab.get("enabled", True) and not cfg.gitlab.get("local_repo_path"):
            get_secret("gitlab_token")
        STATE["ctx"] = ikgchat.prepare(cfg, rebuild_catalog=a.rebuild_catalog)
    srv = ThreadingHTTPServer((a.host, a.port), Handler)
    url = f"http://{'localhost' if a.host in ('127.0.0.1', '0.0.0.0') else a.host}:{a.port}"
    print(f"\nIKG Chatbot UI running at {url}  (Ctrl+C to stop)")
    if not a.no_browser:
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
