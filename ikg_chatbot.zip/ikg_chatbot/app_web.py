"""
IKG Chatbot - ChatGPT-style web UI with no extra dependencies (Python standard library HTTP server).

  python app_web.py                 # asks for the secrets (hidden), then serves http://localhost:8765
  python app_web.py --port 9000 --host 0.0.0.0 --no-browser

Left: new chat, example questions, this session's questions. Centre: the conversation. Bottom: the question box.
Each answer shows the text, the result table, the options for large results, the SQL (collapsed) and assumptions.
"""
from __future__ import annotations

import argparse
import logging
import sys
import threading
import webbrowser
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ikgchat  # noqa: E402
from ikgchat.config import load_config, get_secret  # noqa: E402
from ikgchat import webui  # noqa: E402

log = logging.getLogger("app_web")

def main(argv=None):
    ap = argparse.ArgumentParser(description="IKG Chatbot web UI")
    ap.add_argument("--config", default=None)
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--rebuild-catalog", action="store_true")
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--selftest-data", action="store_true", help="serve the UI on the synthetic self-test data (no secrets)")
    a = ap.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    for n in ("sqlglot", "httpx", "httpx2", "openai", "urllib3"):
        logging.getLogger(n).setLevel(logging.ERROR)
    cfg = load_config(a.config)
    ctx = None
    if a.selftest_data:
        from ikgchat.selftest import FakeGreenplum, ScriptedLLM, make_fake_db
        out = cfg.path(cfg.output["folder"]) / "selftest"
        out.mkdir(parents=True, exist_ok=True)
        cfg["sources"]["catalog_cache"] = str(out / "catalog.json")
        cfg["gitlab"]["enabled"] = False
        cfg["storage"]["folder"] = str(out / "chats")
        db = out / "fake_gp.db"
        make_fake_db(db)
        ctx = ikgchat.prepare(cfg, llm=ScriptedLLM(cfg, out), gp=FakeGreenplum(cfg, db), rebuild_catalog=True, fetch_code=False)
    else:
        get_secret("llm_api_key")
        get_secret("gp_password")
        if cfg.gitlab.get("enabled", True) and not cfg.gitlab.get("local_repo_path"):
            get_secret("gitlab_token")
        ctx = ikgchat.prepare(cfg, rebuild_catalog=a.rebuild_catalog)
    url = f"http://{'localhost' if a.host in ('127.0.0.1', '0.0.0.0') else a.host}:{a.port}/"
    print(f"\nIKG Chatbot UI running at {url}  (Ctrl+C to stop)")
    if not a.no_browser:
        threading.Timer(1.0, lambda: webbrowser.open_new(url)).start()
    webui.serve(ctx, host=a.host, port=a.port)


if __name__ == "__main__":
    main()
