"""
IKG Chatbot - command line.

  python run_chatbot.py --selftest                 # offline: synthetic data + scripted model, no secrets needed
  python run_chatbot.py --check                    # connectivity: Greenplum, Azure OpenAI, GitLab
  python run_chatbot.py --build-catalog            # (re)build the catalog from the project-1 tables
  python run_chatbot.py --ask "households with assets over 100M and their accounts"
  python run_chatbot.py                            # interactive chat (type 'exit' to quit)

Secrets are prompted (hidden) or read from IKG_AZURE_OPENAI_API_KEY / IKG_GP_PASSWORD / IKG_GITLAB_TOKEN.
"""
from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import ikgchat  # noqa: E402
from ikgchat.config import load_config  # noqa: E402


def main(argv=None):
    ap = argparse.ArgumentParser(description="IKG Chatbot")
    ap.add_argument("--config", default=None)
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--build-catalog", action="store_true", help="rebuild output/catalog.json")
    ap.add_argument("--ask", default=None, help="one question, then exit")
    ap.add_argument("--no-sql", action="store_true", help="do not print the SQL")
    ap.add_argument("--verbose", action="store_true")
    a = ap.parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if a.verbose else logging.INFO,
                        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    for n in ("sqlglot", "httpx", "httpx2", "openai", "urllib3"):
        logging.getLogger(n).setLevel(logging.ERROR)
    cfg = load_config(a.config)

    if a.selftest:
        from ikgchat.selftest import run_selftest
        r = run_selftest(cfg)
        sys.exit(1 if r["failed"] else 0)

    if a.check:
        gp = ikgchat.Greenplum(cfg)
        print("Greenplum   :", gp.test())
        pat = cfg.sources["profile_table_pattern"]
        tabs = gp.tables_like(cfg.greenplum["schema"], pat)
        print(f"Profile tables {pat}: {len(tabs)}", (tabs[:5] + ["..."]) if len(tabs) > 5 else tabs)
        for k in ("metadata_table", "glossary_table", "graph_relationship_table", "graph_joining_key_table", "profile_descriptions_table"):
            print(f"  {cfg.sources[k]:45s}", "present" if gp.table_exists(cfg.greenplum["schema"], cfg.sources[k]) else "MISSING")
        print("Azure OpenAI:", ikgchat.LLM(cfg, cfg.path(cfg.output["folder"]) / "cache").check())
        if cfg.gitlab.get("enabled", True):
            from ikgchat.code import ProfileCode
            print("GitLab code :", ProfileCode(cfg, cfg.path(cfg.output["folder"]) / "cache").fetch())
        return

    ctx = ikgchat.prepare(cfg, rebuild_catalog=a.build_catalog)
    if a.build_catalog and not a.ask:
        print(f"catalog: {len(ctx.cat.tables)} tables, {sum(len(t.columns) for t in ctx.cat.tables.values())} columns")
        return
    session = ikgchat.new_session(ctx)
    if a.ask:
        print(session.ask(a.ask).render(show_sql=not a.no_sql))
        return
    print("IKG Chatbot - ask about households, clients, accounts, holdings, cash, loans ... ('exit' to quit)")
    while True:
        try:
            q = input("\nyou> ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if q.lower() in ("exit", "quit", "q"):
            break
        ans = session.ask(q)
        print("\nbot> " + ans.render(show_sql=not a.no_sql))
        print(f"      [{ans.kind}, {ans.seconds}s]")


if __name__ == "__main__":
    main()
