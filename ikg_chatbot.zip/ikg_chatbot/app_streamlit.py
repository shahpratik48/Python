"""Optional web UI:  streamlit run app_streamlit.py   (pip install streamlit). Secrets are entered in the sidebar."""
from __future__ import annotations

import sys
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ikgchat  # noqa: E402
from ikgchat.config import load_config, set_secret  # noqa: E402

st.set_page_config(page_title="IKG Chatbot", layout="wide")
st.title("IKG Chatbot")

with st.sidebar:
    st.header("Connection")
    key = st.text_input("Azure OpenAI key", type="password")
    pwd = st.text_input("Greenplum password", type="password")
    tok = st.text_input("GitLab token (optional)", type="password")
    rebuild = st.checkbox("Rebuild catalog", value=False)
    if st.button("Connect") and key and pwd:
        set_secret("llm_api_key", key)
        set_secret("gp_password", pwd)
        if tok:
            set_secret("gitlab_token", tok)
        cfg = load_config()
        if not tok:
            cfg["gitlab"]["enabled"] = False
        with st.spinner("Building catalog ..."):
            st.session_state.ctx = ikgchat.prepare(cfg, rebuild_catalog=rebuild)
            st.session_state.session = ikgchat.new_session(st.session_state.ctx)
            st.session_state.msgs = []
        st.success(f"Ready: {len(st.session_state.ctx.cat.tables)} profile tables")

if "session" not in st.session_state:
    st.info("Enter the secrets in the sidebar and click Connect.")
    st.stop()

for m in st.session_state.msgs:
    with st.chat_message(m["role"]):
        st.markdown(m["text"])
        if m.get("df") is not None:
            st.dataframe(m["df"], use_container_width=True)
        if m.get("sql"):
            with st.expander("SQL"):
                st.code(m["sql"], language="sql")

q = st.chat_input("Ask about households, clients, accounts, holdings, cash, loans ...")
if q:
    st.session_state.msgs.append({"role": "user", "text": q})
    with st.chat_message("user"):
        st.markdown(q)
    with st.chat_message("assistant"):
        with st.spinner("Thinking ..."):
            a = st.session_state.session.ask(q)
        text = a.text
        if a.truncated:
            tr = f"{a.total_rows:,}" if a.total_rows is not None else f"{a.fetched_rows}+"
            text += f"\n\n*Showing {len(a.df)} of {tr} rows.* You can: " + "; ".join(f"**({i})** {o}" for i, o in enumerate(a.options, 1))
        if a.assumptions:
            text += "\n\n*Assumptions:* " + "; ".join(a.assumptions)
        if a.caveats:
            text += "\n\n*Caveats:* " + "; ".join(a.caveats)
        if a.file:
            text += f"\n\nFile: `{a.file}`"
        st.markdown(text)
        if a.df is not None and len(a.df):
            st.dataframe(a.df, use_container_width=True)
        if a.sql:
            with st.expander("SQL"):
                st.code(a.sql, language="sql")
        st.session_state.msgs.append({"role": "assistant", "text": text, "df": a.df, "sql": a.sql})
