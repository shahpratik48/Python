"""The two chatbot agents: QueryAgent (question -> SQL / clarification / metadata answer) and AnswerAgent."""
from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import List

from .base import Agent, obj, arr, S, B
from .tools import build_tools

log = logging.getLogger(__name__)
PROMPTS = Path(__file__).resolve().parent.parent.parent / "prompts"


def _prompt(name: str) -> str:
    return (PROMPTS / f"{name}.md").read_text(encoding="utf-8")


QUERY_SCHEMA = obj({
    "kind": {"type": "string", "enum": ["sql", "clarify", "metadata", "chat"]},
    "sql": S,
    "clarification": S,
    "answer": S,
    "tables_used": arr(S),
    "columns_used": arr(obj({"table": S, "column": S, "meaning": S})),
    "result_description": S,
    "assumptions": arr(S),
    "suggested_followups": arr(S),
}, ["kind", "sql", "clarification", "answer", "tables_used", "columns_used", "result_description", "assumptions",
    "suggested_followups"])


class QueryAgent(Agent):
    name = "query_agent"
    max_steps = 14
    max_fix_rounds = 2
    strict_grounding = True

    def __init__(self, ctx):
        self.max_steps = int(ctx.cfg.get("agents", {}).get("max_steps", 14))
        super().__init__(ctx, build_tools(ctx), QUERY_SCHEMA, _prompt("query_agent"))

    def ground(self, result: dict, task: dict):
        errs: List[str] = []
        kind = result.get("kind")
        if kind == "sql":
            g = self.ctx.guard.check(result.get("sql", ""))
            if not g.ok:
                errs += [f"SQL rejected: {e}" for e in g.errors]
            else:
                result["sql"] = g.sql
                result["tables_used"] = g.tables
                if not result.get("assumptions"):
                    result["assumptions"] = []
                if not result.get("result_description"):
                    errs.append("result_description is required: what one row is and what each column means")
        elif kind == "clarify":
            if not (result.get("clarification") or "").strip():
                errs.append("clarification text is empty")
        elif kind in ("metadata", "chat"):
            if not (result.get("answer") or "").strip():
                errs.append("answer text is empty")
        return result, errs

    def execute(self, question: str, history: list, extra: str = "") -> dict:
        task = {"question": question, "conversation_so_far": history, "note": extra,
                "placeholders_found": _placeholders(question, self.ctx.cat.concepts)}
        return self.run(task, task_label=question[:80], use_cache=bool(self.ctx.cfg.get("agents", {}).get("cache_results", False)))


ANSWER_SCHEMA = obj({"answer": S, "highlights": arr(S), "caveats": arr(S)}, ["answer", "highlights", "caveats"])


class AnswerAgent(Agent):
    name = "answer_agent"
    max_steps = 3
    max_fix_rounds = 1
    strict_grounding = False

    def __init__(self, ctx):
        super().__init__(ctx, [], ANSWER_SCHEMA, _prompt("answer_agent"))

    def system_prompt(self) -> str:          # no catalog dump needed: the task carries everything
        return self.prompt

    def ground(self, result: dict, task: dict):
        facts_txt = json.dumps(task.get("facts", {})) + json.dumps(task.get("preview_rows", []))
        nums_in_facts = set(re.findall(r"\d+(?:\.\d+)?", facts_txt.replace(",", "")))
        unknown = []
        for n in re.findall(r"\d[\d,]*(?:\.\d+)?", result.get("answer", "")):
            raw = n.replace(",", "")
            if float(raw) >= 1000 and raw not in nums_in_facts and raw.rstrip("0").rstrip(".") not in nums_in_facts:
                unknown.append(n)
        errs = [f"number {n} is not in the facts or preview rows - remove it or use a value from the facts" for n in unknown[:5]]
        return result, errs

    def execute(self, task: dict) -> dict:
        return self.run(task, task_label=task.get("question", "")[:80], use_cache=False)


def _placeholders(question: str, concepts: dict) -> list:
    out = []
    if "User's answer to" in question:          # the user already supplied the missing value(s)
        return out
    for p in (concepts.get("placeholders") or []):
        if p.get("ask") and re.search(p["pattern"], question, flags=re.I):
            out.append(p["ask"])
    return out
