"""Tools the query agent can call (function calling). Every tool is read-only and bounded."""
from __future__ import annotations

import json
import logging
from typing import List

import pandas as pd

from .base import Tool, obj, arr, S, I

log = logging.getLogger(__name__)


def build_tools(ctx) -> List[Tool]:
    cat, gp, guard = ctx.cat, ctx.gp, ctx.guard
    schema = cat.schema

    def search_catalog(query: str, tables: List[str] = None, limit: int = 25):
        cols = cat.search_columns(query, k=limit, tables=tables or None)
        tabs = cat.search_tables(query, k=6)
        return {"matched_concepts": cat.expand(query)[1],
                "tables": [{"table": t.name, "entity": t.entity, "grain": t.grain, "rows": t.row_estimate,
                            "description": t.description[:200]} for t, _ in tabs],
                "columns": [{"table": c.table, "column": c.name, "type": c.data_type, "business_name": c.business_name,
                             "description": c.description[:260], "entity": c.entity, "unit": c.unit,
                             "confidence": c.confidence} for c, _ in cols]}

    def describe_table(table: str, columns_filter: str = "", limit: int = 80):
        t = cat.tables.get(table.lower())
        if t is None:
            return {"error": f"unknown table {table}; queryable tables: {sorted(cat.tables)}"}
        cols = t.columns
        if columns_filter:
            toks = set(columns_filter.lower().replace(",", " ").split())
            cols = [c for c in cols if any(tk in c.name or tk in c.business_name.lower() or tk in c.description.lower() for tk in toks)]
        return {"table": t.name, "entity": t.entity, "grain": t.grain, "primary_key": t.primary_key,
                "join_keys": t.join_keys, "rows": t.row_estimate, "description": t.description,
                "key_columns": cat.key_columns(t.name), "n_columns": len(t.columns),
                "columns": [{"column": c.name, "type": c.data_type, "business_name": c.business_name,
                             "description": c.description[:200], "unit": c.unit} for c in cols[:limit]],
                "truncated": len(cols) > limit}

    def describe_columns(table: str, columns: List[str]):
        t = cat.tables.get(table.lower())
        if t is None:
            return {"error": f"unknown table {table}"}
        out = []
        for name in columns:
            c = t.column(name)
            out.append({"column": name, "exists": c is not None, **({"type": c.data_type, "business_name": c.business_name,
                        "description": c.description, "entity": c.entity, "attribute_type": c.attribute_type,
                        "unit": c.unit, "confidence": c.confidence} if c else {"similar": _similar(t, name)})})
        return out

    def joining_keys(table_a: str, table_b: str):
        path = cat.join_path(table_a.lower(), table_b.lower())
        return {"joins": path or [], "note": "" if path else "no direct joining key - join through the household (acc_mhh_n) or client (ip_cli_i) key if both tables carry it"}

    def glossary(term: str):
        t = term.lower().strip()
        hits = {k: v for k, v in cat.glossary.items() if t == k or t in k or t in v.lower()}
        return hits or {"note": f"'{term}' not in the glossary"}

    def sample_values(table: str, column: str, limit: int = 8):
        key = (table.lower(), column.lower())
        if key in ctx._sample_cache:
            return ctx._sample_cache[key]
        t = cat.tables.get(table.lower())
        if t is None or t.column(column.lower()) is None:
            return {"error": "unknown table/column"}
        n = min(int(limit or 8), int(ctx.cfg.sources.get("sample_values_per_column", 8)))
        try:
            df = gp.read(f'SELECT "{column.lower()}" AS v, COUNT(*) AS n FROM {schema}.{table.lower()} '
                         f'GROUP BY 1 ORDER BY 2 DESC LIMIT {n}')
            out = {"values": [{"value": None if pd.isna(r.v) else str(r.v), "rows": int(r.n)} for r in df.itertuples()]}
        except Exception as e:  # noqa: BLE001
            out = {"error": str(e)[:200]}
        ctx._sample_cache[key] = out
        return out

    def column_stats(table: str, column: str):
        t = cat.tables.get(table.lower())
        if t is None or t.column(column.lower()) is None:
            return {"error": "unknown table/column"}
        try:
            df = gp.read(f'SELECT COUNT(*) AS n, COUNT("{column.lower()}") AS non_null, MIN("{column.lower()}") AS mn, '
                         f'MAX("{column.lower()}") AS mx, AVG("{column.lower()}") AS avg FROM {schema}.{table.lower()}')
            r = df.iloc[0]
            return {"rows": int(r.n), "non_null": int(r.non_null), "min": str(r.mn), "max": str(r.mx), "avg": str(r.avg)}
        except Exception as e:  # noqa: BLE001
            return {"error": str(e)[:200]}

    def preview_sql(sql: str):
        """Guard + run with LIMIT 5: proves the SQL works and shows real values before submitting."""
        g = guard.check(sql, limit=5)
        if not g.ok:
            return {"ok": False, "errors": g.errors}
        try:
            df = gp.read(g.sql)
            return {"ok": True, "rows": df.head(5).astype(str).to_dict("records"), "columns": list(df.columns)}
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "errors": [str(e).split("\n")[0][:300]]}

    def profile_sql(table: str, column: str):
        """How the column is computed in the profile create script (from GitLab) - when available."""
        if ctx.code is None:
            return {"note": "profile SQL not loaded (gitlab.enabled false or download skipped)"}
        return ctx.code.expression(table.lower(), column.lower())

    def similar_questions(question: str):
        return cat.similar_questions(question)

    return [
        Tool("search_catalog", "Find tables and columns whose name / business name / description match a question "
             "(synonyms and abbreviations expanded). Start here.",
             obj({"query": S, "tables": arr(S), "limit": I}, ["query"]), search_catalog),
        Tool("describe_table", "Grain, keys, row count and columns of one table; columns_filter narrows to matching words.",
             obj({"table": S, "columns_filter": S, "limit": I}, ["table"]), describe_table),
        Tool("describe_columns", "Full business description of named columns in a table (and whether they exist).",
             obj({"table": S, "columns": arr(S)}, ["table", "columns"]), describe_columns),
        Tool("joining_keys", "Joining keys between two tables (from the knowledge graph).",
             obj({"table_a": S, "table_b": S}), joining_keys),
        Tool("glossary", "Meaning of an abbreviation or term.", obj({"term": S}), glossary),
        Tool("sample_values", "Most frequent distinct values of a column (codes, flags, categories) with row counts.",
             obj({"table": S, "column": S, "limit": I}, ["table", "column"]), sample_values),
        Tool("column_stats", "count / non-null / min / max / avg of a numeric or date column.",
             obj({"table": S, "column": S}), column_stats),
        Tool("preview_sql", "Validate SQL against the guard and run it with LIMIT 5. ALWAYS preview before submit_result.",
             obj({"sql": S}), preview_sql),
        Tool("profile_sql", "SQL expression that computes a column in the profile create script (derivation).",
             obj({"table": S, "column": S}), profile_sql),
        Tool("similar_questions", "Hints from the question bank for similar questions.", obj({"question": S}), similar_questions),
    ]


def _similar(t, name: str):
    import re
    toks = set(re.findall(r"[a-z0-9]+", name.lower()))
    cand = [(len(toks & set(re.findall(r"[a-z0-9]+", c.name))), c.name) for c in t.columns]
    return [n for s, n in sorted(cand, reverse=True)[:8] if s > 0]
