"""Shared context for the chatbot agents: catalog, database, guard, skills, LLM, trace."""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from .base import Trace
from ..catalog import Catalog
from ..skills import SkillLibrary
from ..sqlguard import SqlGuard

log = logging.getLogger(__name__)


class ChatContext:
    def __init__(self, cfg, llm, gp, catalog: Catalog, code=None):
        self.cfg = cfg
        self.llm = llm
        self.gp = gp
        self.cat = catalog
        self.code = code                         # ProfileCode (GitLab SQL) or None
        self.guard = SqlGuard(catalog, cfg)
        self.skills = SkillLibrary(cfg.path(cfg.skills["folder"]))
        self.trace = Trace()
        self.history = []                        # [{"question", "sql", "answer", "columns"}]
        self._sample_cache = {}

    def reasoning_effort(self, agent_name: str) -> Optional[str]:
        return (self.cfg.get("agents", {}).get("reasoning_effort") or {}).get(agent_name)

    def shared_context(self) -> str:
        s = self.cfg.sources
        lines = [
            "## ENVIRONMENT",
            f"Database: Greenplum (PostgreSQL dialect), schema {self.cat.schema}. Read-only.",
            f"Queryable tables: ONLY the profile clones matching {s['profile_table_pattern']} "
            f"({len(self.cat.tables)} tables). Every table is a CURRENT snapshot: one row per entity key, no date filter needed.",
            "Rows per table (estimate): " + ", ".join(f"{t.name}={t.row_estimate or '?'}" for t in list(self.cat.tables.values())[:60]),
            "",
            "## ENTITIES AND KEYS",
            self.cat.entity_overview(),
            "",
            "## SKILL FILES (business rules - authoritative)",
            self.skills.full_text()[:6000],
        ]
        if self.cat.notes:
            lines += ["", "## CATALOG NOTES", *self.cat.notes]
        return "\n".join(lines)

    def recent_history(self, n: int = 4) -> list:
        return [{"question": h["question"], "sql": h.get("sql", ""), "answer": (h.get("answer") or "")[:400]}
                for h in self.history[-n:]]
