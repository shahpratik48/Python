"""
ChatSession: one conversation. ask(question) -> Answer.

  question -> (follow-up command? export / next page / option number)
           -> QueryAgent  (plan + SQL with tools, or clarify / metadata answer)
           -> SqlGuard    (parse, allowed tables, columns exist, LIMIT injected)
           -> EXPLAIN     (optional) -> execute under statement timeout
           -> facts       (row count, totals, min/max computed in pandas - never by the model)
           -> AnswerAgent (precise prose from facts + preview rows)
           -> Answer      (text, SQL, preview frame, options when truncated)
"""
from __future__ import annotations

import json
import logging
import math
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

import pandas as pd

from .agents.specialists import AnswerAgent, QueryAgent

log = logging.getLogger(__name__)

OPTION_WORDS = {
    "export": ["export", "csv", "download", "full result", "all rows", "whole result"],
    "next": ["next", "more rows", "show more", "next page", "continue"],
    "sql": ["show sql", "show the sql", "what sql", "query used"],
}


@dataclass
class Answer:
    kind: str                                 # sql | clarify | metadata | chat | error | export
    text: str = ""
    sql: str = ""
    df: Optional[pd.DataFrame] = None         # preview rows (<= preview_rows)
    total_rows: Optional[int] = None
    fetched_rows: int = 0
    truncated: bool = False
    options: List[str] = field(default_factory=list)
    assumptions: List[str] = field(default_factory=list)
    highlights: List[str] = field(default_factory=list)
    caveats: List[str] = field(default_factory=list)
    followups: List[str] = field(default_factory=list)
    columns_used: List[dict] = field(default_factory=list)
    file: Optional[str] = None
    seconds: float = 0.0
    issues: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        """JSON-safe form (web UI, chat store)."""
        rows, cols = [], []
        if self.df is not None and len(self.df):
            cols = [str(c) for c in self.df.columns]
            clean = self.df.astype(object).where(pd.notna(self.df), None)
            for r in clean.itertuples(index=False):
                rows.append([None if (isinstance(v, float) and math.isnan(v)) else (v if isinstance(v, (int, float)) else str(v)) for v in r])
        return {"kind": self.kind, "text": self.text, "sql": self.sql, "columns": cols, "rows": rows,
                "total_rows": self.total_rows, "fetched_rows": self.fetched_rows, "truncated": self.truncated,
                "options": self.options, "assumptions": self.assumptions, "highlights": self.highlights,
                "caveats": self.caveats, "followups": self.followups, "file": self.file, "seconds": self.seconds,
                "issues": self.issues}

    def render(self, show_sql: bool = True) -> str:
        """Plain-text rendering (CLI / logs). Notebook and Streamlit render richer views."""
        out = [self.text]
        if self.highlights:
            out.append("Highlights: " + " | ".join(self.highlights))
        if self.df is not None and len(self.df):
            out.append("")
            out.append(self.df.to_string(index=False, max_colwidth=40))
            tr = f"{self.total_rows:,}" if self.total_rows is not None else f"{self.fetched_rows}+"
            out.append(f"({'first ' + str(len(self.df)) + ' of ' + tr if self.truncated else str(len(self.df))} rows)")
        if self.options:
            out.append("")
            out.append("The result is large. You can: " + "; ".join(f"({i}) {o}" for i, o in enumerate(self.options, 1)))
        if self.assumptions:
            out.append("Assumptions: " + "; ".join(self.assumptions))
        if self.caveats:
            out.append("Caveats: " + "; ".join(self.caveats))
        if show_sql and self.sql:
            out.append("\nSQL:\n" + self.sql)
        if self.file:
            out.append(f"File: {self.file}")
        if self.followups:
            out.append("You could also ask: " + " | ".join(self.followups))
        return "\n".join(out)


class ChatSession:
    """One chat. Keeps its own context (recent questions, SQL and answers are given to the agent) and saves every
    message through the ChatStore so the chat can be reopened later."""

    def __init__(self, ctx, store=None, chat_id: Optional[str] = None, title: str = ""):
        self.ctx = ctx
        self.cfg = ctx.cfg
        self.q = ctx.cfg.query
        self.store = store
        self.chat_id = chat_id or (store.new_chat() if store else "local")
        self.title = title
        self.seq = 0
        self.history: List[dict] = []               # [{"question", "sql", "answer", "columns"}] - the chat's context
        self.last: Optional[dict] = None            # {"question", "sql", "result": Answer, "page": n}
        self.pending_clarification: Optional[dict] = None
        self.exports = ctx.cfg.path(ctx.cfg.output["exports_folder"])
        self.exports.mkdir(parents=True, exist_ok=True)
        self.history_file = ctx.cfg.path(ctx.cfg.output["history_file"])
        self.history_file.parent.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------ restore / context
    def restore(self) -> List[dict]:
        """Reload a saved chat: messages for display + context for the agent."""
        msgs = self.store.messages(self.chat_id) if self.store else []
        self.seq = max((m["seq"] for m in msgs), default=0)
        self.title = next((m["chat_title"] for m in msgs if m.get("chat_title")), self.title)
        q_text = None
        for m in msgs:
            if m["role"] == "user":
                q_text = m["text"]
            elif m["role"] == "bot" and q_text is not None:
                pl = m.get("payload") or {}
                self.history.append({"question": q_text, "sql": pl.get("sql", ""), "answer": pl.get("text", ""),
                                     "columns": pl.get("columns", [])})
                q_text = None
        return msgs

    def recent_history(self, n: int = 5) -> list:
        return [{"question": h["question"], "sql": h.get("sql", ""), "answer": (h.get("answer") or "")[:400]}
                for h in self.history[-n:]]

    def _save(self, role: str, text_: str, sql: str = "", payload: Optional[dict] = None) -> None:
        if not self.store:
            return
        try:
            self.seq += 1
            self.store.add(self.chat_id, self.title, self.seq, role, text_, sql, payload)
        except Exception as e:  # noqa: BLE001
            log.warning("chat history not saved: %s", e)

    # ------------------------------------------------------------------ public
    def ask(self, question: str) -> Answer:
        t0 = time.time()
        q = (question or "").strip()
        if q and not self.title:
            self.title = q[:120]
        if q:
            self._save("user", q)
        if not q:
            return Answer("chat", "Ask me anything about the IKG profile data - households, clients, accounts, holdings, cash, loans ...")
        try:
            cmd = self._command(q)
            if cmd == "export":
                ans = self._export()
            elif cmd == "next":
                ans = self._next_page()
            elif cmd == "sql":
                ans = Answer("chat", "Here is the SQL of the last answer.", sql=self.last["sql"]) if self.last and self.last.get("sql") \
                    else Answer("chat", "There is no previous query yet.")
            elif cmd and cmd.startswith("option:"):
                ans = self._option(int(cmd.split(":")[1]), q)
            else:
                ans = self._answer_question(q)
        except Exception as e:  # noqa: BLE001
            log.exception("chat failure")
            ans = Answer("error", f"Sorry - I could not answer that: {str(e).split(chr(10))[0][:300]}")
        ans.seconds = round(time.time() - t0, 1)
        self._log(q, ans)
        if q:
            self._save("bot", ans.text, ans.sql, ans.to_dict())
        return ans

    # ------------------------------------------------------------------ question -> answer
    def _answer_question(self, q: str) -> Answer:
        if self.pending_clarification:
            if self._looks_like_answer(q):      # the user answered the clarifying question: merge with the original
                q = f"{self.pending_clarification['question']}\n(User's answer to '{self.pending_clarification['ask']}': {q})"
            self.pending_clarification = None   # otherwise it is a new question - drop the pending one
        res = QueryAgent(self.ctx).execute(q, self.recent_history())
        kind = res.get("kind")
        issues = res.get("_validation_issues", [])
        if kind == "clarify":
            self.pending_clarification = {"question": q, "ask": res["clarification"]}
            return Answer("clarify", res["clarification"], assumptions=res.get("assumptions", []), issues=issues)
        if kind in ("metadata", "chat"):
            self.history.append({"question": q, "sql": "", "answer": res.get("answer", "")})
            return Answer(kind, res.get("answer", ""), followups=res.get("suggested_followups", []), issues=issues)
        if kind != "sql" or not res.get("sql"):
            return Answer("error", "I could not build a reliable query for that question. " + "; ".join(issues[:3]),
                          issues=issues)
        return self._run_and_answer(q, res)

    def _run_and_answer(self, q: str, res: dict, page: int = 0) -> Answer:
        sql = res["sql"]
        max_rows, preview = int(self.q["max_rows"]), int(self.q["preview_rows"])
        g = self.ctx.guard.check(sql, limit=max_rows + 1, offset=page * max_rows)
        if not g.ok:
            return Answer("error", "The generated query did not pass the safety checks: " + "; ".join(g.errors[:3]), sql=sql)
        sql = g.sql
        fix_rounds = int(self.q.get("max_fix_rounds", 2))
        df, err = None, ""
        for attempt in range(fix_rounds + 1):
            try:
                if self.q.get("explain_before_run", True):
                    self.ctx.gp.explain(sql)
                df = self.ctx.gp.read(sql)
                break
            except Exception as e:  # noqa: BLE001
                err = str(e).split("\n")[0][:400]
                log.warning("query failed (attempt %d): %s", attempt + 1, err)
                if attempt >= fix_rounds:
                    return Answer("error", f"The database rejected the query and it could not be repaired: {err}", sql=sql)
                fixed = QueryAgent(self.ctx).execute(
                    q, self.recent_history(),
                    extra=f"Your previous SQL failed in the database with: {err}\nPrevious SQL:\n{sql}\nFix it and preview again.")
                if fixed.get("kind") != "sql" or not fixed.get("sql"):
                    return Answer("error", f"The query failed ({err}) and the repair did not produce SQL.", sql=sql)
                res = fixed
                g = self.ctx.guard.check(fixed["sql"], limit=max_rows + 1, offset=page * max_rows)
                if not g.ok:
                    return Answer("error", "Repaired query failed the safety checks: " + "; ".join(g.errors[:3]), sql=fixed["sql"])
                sql = g.sql
        truncated = len(df) > max_rows
        if truncated:
            df = df.iloc[:max_rows]
        total = len(df) if not truncated else None
        if truncated and self.q.get("count_total_when_truncated", True):
            try:
                total = int(self.ctx.gp.read(self.ctx.guard.wrap_count(sql)).iloc[0, 0])
            except Exception as e:  # noqa: BLE001
                log.warning("count failed: %s", e)
        facts = self._facts(df, total, truncated, max_rows)
        show = df.head(preview) if len(df) > preview else df
        large = len(df) > preview
        task = {"question": q, "sql": sql, "result_description": res.get("result_description", ""),
                "columns_used": res.get("columns_used", []), "assumptions": res.get("assumptions", []),
                "facts": facts, "preview_rows": self._json_rows(show), "shown_rows": len(show),
                "large_result": large, "page": page}
        a = AnswerAgent(self.ctx).execute(task)
        ans = Answer("sql", a.get("answer", ""), sql=sql, df=show, total_rows=total, fetched_rows=len(df),
                     truncated=large, assumptions=res.get("assumptions", []), highlights=a.get("highlights", []),
                     caveats=a.get("caveats", []), followups=res.get("suggested_followups", []),
                     columns_used=res.get("columns_used", []), issues=res.get("_validation_issues", []) + a.get("_validation_issues", []))
        if large:
            ans.options = list(self.cfg.answer.get("options_when_truncated", []))
        self.last = {"question": q, "sql": sql, "result": ans, "page": page, "res": res, "df": df}
        self.history.append({"question": q, "sql": sql, "answer": ans.text, "columns": list(df.columns)})
        return ans

    # ------------------------------------------------------------------ facts (computed, never by the model)
    def _facts(self, df: pd.DataFrame, total, truncated: bool, max_rows: int) -> dict:
        fmt = self.q.get("numeric_format", "{:,.2f}")
        f = {"rows_fetched": int(len(df)), "total_rows": total, "truncated_at": max_rows if truncated else None,
             "columns": list(df.columns)}
        num = df.select_dtypes("number")
        for c in num.columns[:12]:
            s = num[c].dropna()
            if len(s):
                f[f"{c}"] = {"sum": fmt.format(float(s.sum())), "min": fmt.format(float(s.min())),
                             "max": fmt.format(float(s.max())), "avg": fmt.format(float(s.mean())),
                             "non_null": int(len(s)), "nulls": int(num[c].isna().sum())}
        for c in df.columns[:12]:
            if c not in num.columns:
                try:
                    f[f"{c}_distinct"] = int(df[c].nunique())
                except Exception:  # noqa: BLE001
                    pass
        if len(df) and len(num.columns):
            first = num.columns[0]
            top = df.sort_values(first, ascending=False).head(3) if df[first].notna().any() else df.head(3)
            f["top_3_by_" + first] = self._json_rows(top)
        return f

    def _json_rows(self, df: pd.DataFrame) -> list:
        fmt = self.q.get("numeric_format", "{:,.2f}")
        out = []
        for r in df.to_dict("records"):
            row = {}
            for k, v in r.items():
                if isinstance(v, float):
                    row[k] = None if math.isnan(v) else (fmt.format(v) if abs(v) >= 1000 or v != int(v) else str(int(v)))
                else:
                    row[k] = None if (v is None or (isinstance(v, float) and math.isnan(v))) else str(v)[:120]
            out.append(row)
        return out

    @staticmethod
    def _looks_like_answer(q: str) -> bool:
        """Short replies, numbers, amounts, ids, 'use …' read as an answer to the pending question."""
        ql = q.lower()
        if re.search(r"\d|%|\$|\buse\b|\bdefault\b|\byes\b|\bno\b|\bok\b", ql) and len(ql.split()) <= 25:
            return True
        return len(ql.split()) <= 6 and not re.search(r"\b(what|which|who|where|how|show|list|give|find)\b", ql)

    # ------------------------------------------------------------------ follow-up commands
    def _command(self, q: str) -> Optional[str]:
        ql = q.lower().strip().rstrip(".!?")
        if self.last and self.last["result"].options:
            m = re.fullmatch(r"(?:option\s*)?(\d)", ql)
            if m and 1 <= int(m.group(1)) <= len(self.last["result"].options):
                return f"option:{m.group(1)}"
        if len(ql.split()) <= 6:
            for cmd, words in OPTION_WORDS.items():
                if any(w in ql for w in words):
                    return cmd
        return None

    def _option(self, n: int, q: str) -> Answer:
        opts = self.last["result"].options
        text = opts[n - 1].lower()
        if "export" in text or "csv" in text:
            return self._export()
        if "top n" in text or "sorted" in text:
            self.pending_clarification = {"question": self.last["question"], "ask": "How many rows and sorted by which column?"}
            return Answer("clarify", "How many rows do you want, and sorted by which column (largest first)?")
        if "filter" in text:
            self.pending_clarification = {"question": self.last["question"], "ask": "Which filter should I add?"}
            return Answer("clarify", "Which filter should I add (for example an FA, a region, a minimum amount)?")
        if "summar" in text:
            return self._answer_question(self.last["question"] + "\n(Follow-up: summarise instead - counts and totals grouped by the most useful dimension, not row-level.)")
        return self._answer_question(q)

    def _export(self) -> Answer:
        if not self.last:
            return Answer("chat", "There is no result to export yet - ask a question first.")
        limit = int(self.q.get("export_max_rows", 200000))
        sql = self.ctx.guard.without_limit(self.last["sql"], limit)
        df = self.ctx.gp.read(sql)
        name = re.sub(r"[^a-z0-9]+", "_", self.last["question"].lower())[:50].strip("_") or "result"
        path = self.exports / f"{name}_{time.strftime('%Y%m%d_%H%M%S')}.csv"
        df.to_csv(path, index=False)
        more = f" (capped at {limit:,} rows)" if len(df) >= limit else ""
        return Answer("export", f"Exported {len(df):,} rows{more} to {path}", file=str(path), sql=sql, df=df.head(5),
                      fetched_rows=len(df), total_rows=len(df))

    def _next_page(self) -> Answer:
        if not self.last:
            return Answer("chat", "There is no result to page through yet.")
        res, page = self.last["res"], self.last["page"]
        df = self.last["df"]
        preview = int(self.q["preview_rows"])
        start = self.last.get("preview_offset", preview)
        if start < len(df):
            show = df.iloc[start:start + preview]
            self.last["preview_offset"] = start + preview
            ans = Answer("sql", f"Rows {start + 1}-{start + len(show)} of the result.", sql=self.last["sql"], df=show,
                         total_rows=self.last["result"].total_rows, fetched_rows=len(df), truncated=True,
                         options=self.last["result"].options)
            return ans
        return self._run_and_answer(self.last["question"], res, page=page + 1)

    # ------------------------------------------------------------------ log
    def _log(self, q: str, ans: Answer) -> None:
        try:
            rec = {"time": time.strftime("%Y-%m-%d %H:%M:%S"), "question": q, "kind": ans.kind, "seconds": ans.seconds,
                   "answer": ans.text[:2000], "sql": ans.sql, "rows": ans.fetched_rows, "total_rows": ans.total_rows,
                   "assumptions": ans.assumptions, "issues": ans.issues}
            with self.history_file.open("a", encoding="utf-8") as f:
                f.write(json.dumps(rec, ensure_ascii=False, default=str) + "\n")
        except Exception:  # noqa: BLE001
            pass
