"""
Offline self-test: a SQLite stand-in for Greenplum with small synthetic *_v2 tables + project-1 metadata tables,
and a scripted stand-in for GPT-5 that drives the real agent loop (tools, guard, preview, submit, answer).
No network, no secrets:  python run_chatbot.py --selftest
"""
from __future__ import annotations

import json
import logging
import random
import re
import types
from pathlib import Path

import pandas as pd

from .config import Config
from .db import Greenplum

log = logging.getLogger(__name__)
SCHEMA = "core_ikg"


# =============================================================================
# fake Greenplum (SQLite)
# =============================================================================
class FakeGreenplum(Greenplum):
    def __init__(self, cfg: Config, path: Path):
        super().__init__(cfg)
        from sqlalchemy import create_engine
        self._engine = create_engine(f"sqlite:///{path}")

    def read(self, sql, params=None):
        return super().read(sql.replace(f"{SCHEMA}.", ""), params)

    def explain(self, sql):
        return "explain skipped (sqlite)"

    def tables_like(self, schema, pattern):
        df = self.read("select name from sqlite_master where type='table' and name like :p order by 1", {"p": pattern})
        return list(df.name)

    def columns_of(self, schema, pattern):
        rows = []
        for t in self.tables_like(schema, pattern):
            for r in self.read(f"pragma table_info({t})").itertuples():
                rows.append((t, r.name, r.type.lower() or "text", r.cid + 1))
        return pd.DataFrame(rows, columns=["table_name", "column_name", "data_type", "ordinal_position"])

    def table_exists(self, schema, table):
        return table in self.tables_like(schema, table)

    def row_count_estimate(self, schema, table):
        return int(self.read(f"select count(*) n from {table}").iloc[0].n)


def make_fake_db(path: Path, n_hh: int = 60) -> None:
    from sqlalchemy import create_engine
    if path.exists():
        path.unlink()
    eng = create_engine(f"sqlite:///{path}")
    rnd = random.Random(7)
    hh, acc, cli = [], [], []
    for h in range(1, n_hh + 1):
        hid = f"HH{h:05d}"
        assets = rnd.choice([2e6, 8e6, 3e7, 1.5e8, 4e8]) * rnd.uniform(0.5, 1.5)
        boy = assets * rnd.uniform(0.8, 1.1)
        cash = assets * rnd.uniform(0.0, 0.4)
        hh.append((hid, round(assets), round(boy), round(cash), rnd.randint(0, 3), rnd.choice(["NY", "CA", "TX", "FL"])))
        for a in range(rnd.randint(1, 4)):
            aid = f"{hid}A{a}"
            share = rnd.uniform(0.1, 0.9)
            acc.append((aid, hid, f"C{h:05d}", round(assets * share), round(boy * share), round(cash * share),
                        f"FA{rnd.randint(1, 5):02d}", rnd.choice([0, 1]), round(rnd.uniform(0, 60), 1)))
        cli.append((f"C{h:05d}", hid, f"Client {h}", round(cash / assets * 100, 1)))
    pd.DataFrame(hh, columns=["acc_mhh_n", "mhh_assets_curr", "mhh_brkg_assets_boy", "mhh_cash_a", "mhh_credit_cards_cnt",
                              "mhh_region_c"]).to_sql("household_profile_curr_ikg_v2", eng, index=False)
    pd.DataFrame(acc, columns=["acc_i", "acc_mhh_n", "ip_cli_i", "acc_assets_curr", "acc_brkg_assets_boy", "acc_cash_a",
                               "fa_i", "has_acc_credit_card", "acc_top_pos_pct"]).to_sql("account_profile_curr_ikg_v2", eng, index=False)
    pd.DataFrame(cli, columns=["ip_cli_i", "acc_mhh_n", "cli_name", "cli_cash_pct"]).to_sql("client_profile_curr_ikg_v2", eng, index=False)
    meta = [
        ("household_profile_curr_ikg", "acc_mhh_n", "Statement Household Identifier", "Identifier of the statement household (from household_plus); groups the accounts on one statement.", "Household", "identifier", "", 92),
        ("household_profile_curr_ikg", "mhh_assets_curr", "Household Total Assets", "Current total assets of the statement household across all UBS accounts, USD.", "Household", "amount", "USD", 90),
        ("household_profile_curr_ikg", "mhh_brkg_assets_boy", "Household Brokerage Assets, Beginning of Year", "Brokerage account assets of the household as of the first business day of the current year, USD.", "Household", "amount", "USD", 85),
        ("household_profile_curr_ikg", "mhh_cash_a", "Household Cash Balance", "Cash and sweep balances across the household's accounts, USD.", "Household", "amount", "USD", 88),
        ("household_profile_curr_ikg", "mhh_credit_cards_cnt", "Household Credit Card Accounts Count", "Number of accounts in the statement household that hold a credit card.", "Household", "count", "", 88),
        ("household_profile_curr_ikg", "mhh_region_c", "Household Region Code", "Region code of the household's primary branch.", "Household", "code", "", 80),
        ("account_profile_curr_ikg", "acc_i", "Account Identifier", "Account number.", "Account", "identifier", "", 95),
        ("account_profile_curr_ikg", "acc_mhh_n", "Statement Household Identifier", "Identifier of the statement household (from household_plus); groups the accounts on one statement.", "Household", "identifier", "", 92),
        ("account_profile_curr_ikg", "ip_cli_i", "Client Identifier", "Primary client of the account.", "Client", "identifier", "", 95),
        ("account_profile_curr_ikg", "acc_assets_curr", "Account Total Assets", "Current total assets of the account, USD.", "Account", "amount", "USD", 90),
        ("account_profile_curr_ikg", "acc_brkg_assets_boy", "Account Brokerage Assets, Beginning of Year", "Brokerage assets of the account as of the first business day of the year, USD.", "Account", "amount", "USD", 85),
        ("account_profile_curr_ikg", "acc_cash_a", "Account Cash Balance", "Cash and sweep balance of the account, USD.", "Account", "amount", "USD", 88),
        ("account_profile_curr_ikg", "fa_i", "Financial Advisor Identifier", "FA number of the account's primary advisor.", "Financial Advisor", "identifier", "", 95),
        ("account_profile_curr_ikg", "has_acc_credit_card", "Account Has Credit Card Indicator", "1 when the account has at least one credit card, else 0.", "Account", "flag", "", 93),
        ("account_profile_curr_ikg", "acc_top_pos_pct", "Account Largest Position Share", "Share of the account's assets held in its single largest security position, percent (0-100).", "Account", "percent", "%", 84),
        ("client_profile_curr_ikg", "ip_cli_i", "Client Identifier", "Client number.", "Client", "identifier", "", 95),
        ("client_profile_curr_ikg", "acc_mhh_n", "Statement Household Identifier", "Statement household of the client.", "Household", "identifier", "", 92),
        ("client_profile_curr_ikg", "cli_name", "Client Name", "Client display name.", "Client", "text", "", 90),
        ("client_profile_curr_ikg", "cli_cash_pct", "Client Cash Share of Assets", "Cash as a percentage (0-100) of the client's total assets.", "Client", "percent", "%", 86),
    ]
    pd.DataFrame(meta, columns=["table_name", "column_name", "business_attribute_name", "description", "entity",
                                "attribute_type", "unit", "confidence_score"]).to_sql("ikg_attribute_business_description", eng, index=False)
    pd.DataFrame([("mhh", "Statement Household"), ("brkg", "Brokerage"), ("boy", "Beginning of Year"), ("cli", "Client"),
                  ("fa", "Financial Advisor"), ("pos", "Position"), ("pct", "Percent")],
                 columns=["token", "meaning"]).to_sql("ikg_metadata_glossary_llm", eng, index=False)
    pd.DataFrame([("Household", "Account", "has accounts", "acc_mhh_n"), ("Household", "Client", "has clients", "acc_mhh_n"),
                  ("Account", "Client", "owned by", "ip_cli_i")],
                 columns=["from_entity", "to_entity", "label", "joining_key"]).to_sql("ikg_graph_relationship", eng, index=False)
    pd.DataFrame([("household_profile_curr_ikg", "account_profile_curr_ikg", "acc_mhh_n"),
                  ("household_profile_curr_ikg", "client_profile_curr_ikg", "acc_mhh_n"),
                  ("account_profile_curr_ikg", "client_profile_curr_ikg", "ip_cli_i")],
                 columns=["table_a", "table_b", "joining_key"]).to_sql("ikg_graph_joining_key", eng, index=False)
    pd.DataFrame([("household_profile_curr_ikg", "Household", "One row per statement household with assets, cash and counts.", "statement household", "acc_mhh_n", "acc_mhh_n"),
                  ("account_profile_curr_ikg", "Account", "One row per account with balances, flags and advisor.", "account", "acc_i", "acc_mhh_n, ip_cli_i"),
                  ("client_profile_curr_ikg", "Client", "One row per client.", "client", "ip_cli_i", "acc_mhh_n")],
                 columns=["table_name", "topic_area", "description", "grain", "primary_key", "join_keys"]).to_sql("ikg_profile_table_descriptions", eng, index=False)


# =============================================================================
# scripted model
# =============================================================================
CANNED = {
    "100m": ("SELECT h.acc_mhh_n, h.mhh_assets_curr AS household_assets, a.acc_i, a.acc_assets_curr AS account_assets "
             "FROM core_ikg.household_profile_curr_ikg_v2 h JOIN core_ikg.account_profile_curr_ikg_v2 a ON a.acc_mhh_n = h.acc_mhh_n "
             "WHERE h.mhh_assets_curr > 100000000 ORDER BY h.mhh_assets_curr DESC, a.acc_assets_curr DESC",
             "One row per account of a household with more than $100M total assets; household_assets is the household total, account_assets the account's own assets."),
    "credit card": ("SELECT acc_mhh_n, mhh_credit_cards_cnt FROM core_ikg.household_profile_curr_ikg_v2 "
                    "WHERE mhh_credit_cards_cnt >= 2 ORDER BY mhh_credit_cards_cnt DESC",
                    "One row per household with at least two accounts holding a credit card."),
    "all households": ("SELECT acc_mhh_n, mhh_assets_curr, mhh_cash_a FROM core_ikg.household_profile_curr_ikg_v2 ORDER BY mhh_assets_curr DESC",
                       "One row per household with total assets and cash."),
    "brokerage": ("SELECT h.acc_mhh_n, h.mhh_brkg_assets_boy AS household_brokerage_boy, a.acc_i, a.acc_brkg_assets_boy AS account_brokerage_boy "
                  "FROM core_ikg.household_profile_curr_ikg_v2 h JOIN core_ikg.account_profile_curr_ikg_v2 a ON a.acc_mhh_n = h.acc_mhh_n "
                  "WHERE h.acc_mhh_n = 'HH00001' ORDER BY a.acc_brkg_assets_boy DESC",
                  "One row per account of household HH00001 with the household's and the account's brokerage assets at the beginning of the year."),
    "bad": ("SELECT acc_mhh_n, mhh_market_value FROM core_ikg.household_profile_curr_ikg_v2", "wrong column on purpose"),
}


class _Msg:
    def __init__(self, content=None, tool_calls=None):
        self.content, self.tool_calls = content, tool_calls or []


class _Call:
    def __init__(self, i, name, args):
        self.id = f"call_{i}"
        self.function = types.SimpleNamespace(name=name, arguments=json.dumps(args))


class ScriptedLLM:
    """Drives the agents deterministically: search -> (preview -> submit) for the query agent; facts -> prose."""

    def __init__(self, cfg, cache_dir):
        self.c = cfg.llm
        self.usage = {"calls": 0, "cache_hits": 0, "prompt_tokens": 0, "completion_tokens": 0, "cached_tokens": 0}
        self.n = 0

    def check(self):
        return "OK (scripted self-test model)"

    def cache_get(self, key):
        return None

    def cache_put(self, key, value):
        pass

    def chat(self, messages, tools=None, tool_choice="auto", reasoning_effort=None):
        self.usage["calls"] += 1
        self.n += 1
        task = next(m["content"] for m in messages if m["role"] == "user" and m["content"].startswith("TASK:"))
        t = json.loads(task[5:])
        names = {x["function"]["name"] for x in (tools or [])}
        if "facts" in t:                                       # answer agent
            f = t["facts"]
            tot = f.get("total_rows") if f.get("total_rows") is not None else f.get("rows_fetched")
            cols = f.get("columns", [])
            num = next((c for c in cols if isinstance(f.get(c), dict)), None)
            txt = f"The query returns {tot} rows. " + (f"The largest {num} is {f[num]['max']} and the total is {f[num]['sum']}. " if num else "")
            if t.get("large_result"):
                txt += f"The table shows the first {t['shown_rows']} rows."
            if tot == 0:
                txt = "No rows match these criteria."
            return _Msg(tool_calls=[_Call(self.n, "submit_result", {"answer": txt, "highlights": [f"{num} max {f[num]['max']}"] if num else [],
                                                                  "caveats": []})])
        q = (t.get("question", "") + " " + t.get("note", "")).lower()
        if t.get("placeholders_found"):
            return _Msg(tool_calls=[_Call(self.n, "submit_result", {"kind": "clarify", "sql": "", "clarification": " ".join(t["placeholders_found"]),
                                                                  "answer": "", "tables_used": [], "columns_used": [], "result_description": "",
                                                                  "assumptions": [], "suggested_followups": []})])
        if "what does" in q or "mean" in q:
            return _Msg(tool_calls=[_Call(self.n, "submit_result", {"kind": "metadata", "sql": "", "clarification": "",
                                                                  "answer": "acc_mhh_n is the Statement Household Identifier (household_profile_curr_ikg_v2.acc_mhh_n).",
                                                                  "tables_used": [], "columns_used": [], "result_description": "", "assumptions": [], "suggested_followups": []})])
        key = next((k for k in CANNED if k in q), "all households")
        sql, desc = CANNED[key]
        seen = [m for m in messages if m["role"] == "tool"]
        rejected = any("REJECTED" in m["content"] for m in seen)
        if rejected and key == "bad":
            sql, desc = CANNED["all households"]
        if not seen:
            return _Msg(tool_calls=[_Call(self.n, "search_catalog", {"query": t.get("question", "")})])
        if len(seen) == 1 and "preview_sql" in names:
            return _Msg(tool_calls=[_Call(self.n, "preview_sql", {"sql": sql})])
        return _Msg(tool_calls=[_Call(self.n, "submit_result", {
            "kind": "sql", "sql": sql, "clarification": "", "answer": "", "tables_used": [],
            "columns_used": [{"table": "household_profile_curr_ikg_v2", "column": "mhh_assets_curr", "meaning": "household total assets"}],
            "result_description": desc, "assumptions": ["household = statement household (acc_mhh_n)"],
            "suggested_followups": ["break the result down by advisor"]})])


# =============================================================================
# run
# =============================================================================
def run_selftest(cfg: Config) -> dict:
    from . import prepare, new_session
    out = cfg.path(cfg.output["folder"]) / "selftest"
    out.mkdir(parents=True, exist_ok=True)
    cfg["output"]["folder"] = str(out)
    cfg["output"]["exports_folder"] = str(out / "exports")
    cfg["output"]["history_file"] = str(out / "chat_history.jsonl")
    cfg["sources"]["catalog_cache"] = str(out / "catalog.json")
    cfg["gitlab"]["enabled"] = False
    cfg["query"]["max_rows"] = 50
    cfg["query"]["preview_rows"] = 5
    db = out / "fake_gp.db"
    make_fake_db(db)
    gp = FakeGreenplum(cfg, db)
    ctx = prepare(cfg, llm=ScriptedLLM(cfg, out), gp=gp, rebuild_catalog=True, fetch_code=False)
    s = new_session(ctx)
    results = {}
    checks = []

    def check(name, cond, detail=""):
        checks.append((name, bool(cond), detail))
        log.info("%s %s %s", "PASS" if cond else "FAIL", name, detail)

    a = s.ask("give me households assets greater than 100M and provide all related accounts and asset value of each account")
    results["100m"] = a
    check("join query runs", a.kind == "sql" and a.df is not None and len(a.df) > 0, f"{a.fetched_rows} rows")
    check("answer cites real count", str(a.total_rows or a.fetched_rows) in a.text, a.text[:120])
    a2 = s.ask("list all households with their assets and cash")
    results["large"] = a2
    check("large result -> preview + options", a2.truncated and len(a2.options) == 4 and len(a2.df) == 5, f"total={a2.total_rows}")
    a3 = s.ask("1")
    check("option 1 exports csv", a3.kind == "export" and a3.file and Path(a3.file).exists(), a3.text[:100])
    a4 = s.ask("which clients have x% sitting in cash?")
    check("placeholder -> clarification", a4.kind == "clarify" and "percentage" in a4.text.lower(), a4.text)
    a5 = s.ask("what does acc_mhh_n mean?")
    check("metadata question answered without SQL", a5.kind == "metadata" and not a5.sql, a5.text[:80])
    a6 = s.ask("households with bad column")
    check("guard rejects unknown column, agent repairs", a6.kind == "sql" and "mhh_market_value" not in a6.sql, a6.sql[:80])
    g = ctx.guard.check("DELETE FROM core_ikg.household_profile_curr_ikg_v2")
    check("guard blocks DML", not g.ok, g.errors[:1])
    g = ctx.guard.check("SELECT * FROM core_ikg.household_profile_curr_ikg_v2")
    check("guard blocks SELECT *", not g.ok, g.errors[:1])
    g = ctx.guard.check("SELECT acc_mhh_n FROM core_ikg.ikg_column_lineage_master_auto_refresh")
    check("guard blocks non-profile tables", not g.ok, g.errors[:1])
    g = ctx.guard.check("SELECT acc_mhh_n FROM household_profile_curr_ikg_v2")
    check("guard injects schema + limit", g.ok and "core_ikg" in g.sql and "LIMIT" in g.sql.upper(), g.sql.replace("\n", " ")[:90])
    a7 = s.ask("brokerage assets at the start of the year for household HH00001 with account breakdown")
    check("household + account breakdown", a7.kind == "sql" and a7.df is not None and "household_brokerage_boy" in a7.df.columns, f"{a7.fetched_rows} rows")
    failed = [c for c in checks if not c[1]]
    print(f"\nSELF-TEST: {len(checks) - len(failed)}/{len(checks)} checks passed")
    for n, ok, d in checks:
        print(f"  [{'ok' if ok else 'FAIL'}] {n}  {d}")
    return {"checks": checks, "failed": len(failed), "answers": results}
