"""
Chat persistence: every chat (title, messages, answers with SQL and rows) is saved so it can be reopened later.

  backend "greenplum": one table  <schema>.<storage.table>  (created once; owner / grant from greenplum.table_*_role)
  backend "file":      output/chats/<chat_id>.jsonl
Both keep the same records: chat_id, chat_title, seq, role (user|bot), created_ts, text, sql, payload (JSON answer).
"""
from __future__ import annotations

import json
import logging
import re
import time
import uuid
from pathlib import Path
from typing import List, Optional

log = logging.getLogger(__name__)

COLUMNS = [("chat_id", "varchar(40)"), ("chat_title", "varchar(300)"), ("seq", "integer"), ("role", "varchar(10)"),
           ("created_ts", "timestamp"), ("user_name", "varchar(100)"), ("text", "text"), ("sql", "text"), ("payload", "text")]


def _ident(name: str) -> str:
    if not re.fullmatch(r"[a-z_][a-z0-9_]*", name):
        raise ValueError(f"invalid identifier: {name}")
    return name


class ChatStore:
    def __init__(self, cfg, gp=None):
        self.cfg = cfg
        st = cfg.get("storage", {}) or {}
        self.backend = str(st.get("backend", "file")).lower()
        self.user = str(st.get("user_name", "") or "")
        self.gp = gp
        self.schema = cfg.greenplum["schema"]
        self.table = _ident(st.get("table", "ikg_chatbot_history"))
        self.folder = cfg.path(st.get("folder", "output/chats"))
        self.folder.mkdir(parents=True, exist_ok=True)
        self._ready = False
        # qualified name (sqlite in the self-test has no schemas)
        self.t = f"{self.schema}.{self.table}" if gp is None or gp.dialect == "postgresql" else self.table
        if self.backend == "greenplum" and gp is None:
            log.warning("storage.backend=greenplum but no database - using files")
            self.backend = "file"

    # ------------------------------------------------------------------ setup
    def ensure(self) -> None:
        if self._ready or self.backend != "greenplum":
            self._ready = True
            return
        from sqlalchemy import text
        cols = ",\n  ".join(f"{c} {t}" for c, t in COLUMNS)
        t = self.t
        created = not self.gp.table_exists(self.schema, self.table)
        with self.gp.write_engine.begin() as con:
            if created:
                dist = " DISTRIBUTED BY (chat_id)" if self.gp.dialect == "postgresql" else ""
                con.execute(text(f"CREATE TABLE {t} (\n  {cols}\n){dist}"))
                owner = self.cfg.greenplum.get("table_owner_role", "")
                reader = self.cfg.greenplum.get("table_reader_role", "")
                if self.gp.dialect == "postgresql":
                    if owner:
                        con.execute(text(f"ALTER TABLE {t} OWNER TO {_ident(owner)}"))
                    if reader:
                        con.execute(text(f"GRANT SELECT ON {t} TO {_ident(reader)}"))
                log.info("created chat history table %s", t)
        self._ready = True

    # ------------------------------------------------------------------ chats
    def new_chat(self, title: str = "New chat") -> str:
        return uuid.uuid4().hex[:20]

    def list_chats(self, limit: int = 100) -> List[dict]:
        self.ensure()
        if self.backend == "greenplum":
            df = self.gp.read(
                f"select chat_id, max(chat_title) as title, max(created_ts) as updated, count(*) as n "
                f"from {self.t} where coalesce(user_name,'') = :u group by chat_id order by updated desc limit {int(limit)}",
                {"u": self.user})
            return [{"chat_id": r.chat_id, "title": r.title, "updated": str(r.updated), "messages": int(r.n)} for r in df.itertuples()]
        chats = []
        for p in self.folder.glob("*.jsonl"):
            try:
                lines = p.read_text(encoding="utf-8").splitlines()
                if not lines:
                    continue
                first, last = json.loads(lines[0]), json.loads(lines[-1])
                chats.append({"chat_id": p.stem, "title": first.get("chat_title", ""), "updated": last.get("created_ts", ""),
                              "messages": len(lines)})
            except Exception:  # noqa: BLE001
                continue
        chats.sort(key=lambda c: c["updated"], reverse=True)
        return chats[:limit]

    def messages(self, chat_id: str) -> List[dict]:
        self.ensure()
        if self.backend == "greenplum":
            df = self.gp.read(f"select * from {self.t} where chat_id = :c order by seq", {"c": chat_id})
            out = []
            for r in df.to_dict("records"):
                r["payload"] = json.loads(r["payload"]) if r.get("payload") else {}
                r["created_ts"] = str(r["created_ts"])
                out.append(r)
            return out
        p = self.folder / f"{chat_id}.jsonl"
        if not p.exists():
            return []
        out = []
        for line in p.read_text(encoding="utf-8").splitlines():
            r = json.loads(line)
            if isinstance(r.get("payload"), str):
                r["payload"] = json.loads(r["payload"]) if r["payload"] else {}
            out.append(r)
        return out

    def add(self, chat_id: str, title: str, seq: int, role: str, text_: str, sql: str = "", payload: Optional[dict] = None) -> None:
        self.ensure()
        rec = {"chat_id": chat_id, "chat_title": (title or "")[:300], "seq": seq, "role": role,
               "created_ts": time.strftime("%Y-%m-%d %H:%M:%S"), "user_name": self.user, "text": text_ or "",
               "sql": sql or "", "payload": json.dumps(payload or {}, ensure_ascii=False, default=str)}
        if self.backend == "greenplum":
            from sqlalchemy import text
            cols = [c for c, _ in COLUMNS]
            with self.gp.write_engine.begin() as con:
                con.execute(text(f"insert into {self.t} ({', '.join(cols)}) values ({', '.join(':' + c for c in cols)})"),
                            {**rec, "created_ts": rec["created_ts"]})
            return
        with (self.folder / f"{chat_id}.jsonl").open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")

    def delete_chat(self, chat_id: str) -> None:
        self.ensure()
        if self.backend == "greenplum":
            from sqlalchemy import text
            with self.gp.write_engine.begin() as con:
                con.execute(text(f"delete from {self.t} where chat_id = :c"), {"c": chat_id})
            return
        p = self.folder / f"{chat_id}.jsonl"
        if p.exists():
            p.unlink()
