"""
SQL guard: every statement the model writes is parsed and checked BEFORE it reaches Greenplum.

  * one SELECT (CTEs allowed) - no DML / DDL / multiple statements / comments tricks
  * only allowed tables (the *_v2 profile tables + the project-1 metadata tables), schema-qualified
  * every column reference must exist in the table it is read from (unknown -> error back to the agent)
  * SELECT * refused when allow_select_star is false
  * a LIMIT is injected (max_rows + 1) so the result can be detected as truncated
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set

import sqlglot
from sqlglot import exp

from .catalog import Catalog


@dataclass
class GuardResult:
    ok: bool
    sql: str = ""
    errors: List[str] = field(default_factory=list)
    tables: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


class SqlGuard:
    def __init__(self, catalog: Catalog, cfg):
        self.cat = catalog
        self.schema = catalog.schema
        self.dialect = cfg.query.get("dialect", "postgres")
        self.allow_star = bool(cfg.query.get("allow_select_star", False))
        self.max_rows = int(cfg.query.get("max_rows", 2000))
        extra = [cfg.sources[k] for k in ("metadata_table", "glossary_table", "graph_relationship_table",
                                          "graph_joining_key_table", "profile_descriptions_table") if cfg.sources.get(k)]
        self.allowed: Set[str] = set(catalog.tables) | set(extra)

    def check(self, sql: str, limit: Optional[int] = None, offset: int = 0) -> GuardResult:
        res = GuardResult(ok=False, sql=sql)
        s = sql.strip().rstrip(";").strip()
        if not s:
            res.errors.append("empty SQL")
            return res
        try:
            stmts = sqlglot.parse(s, read=self.dialect)
        except Exception as e:  # noqa: BLE001
            res.errors.append(f"SQL does not parse ({self.dialect}): {str(e)[:300]}")
            return res
        if len(stmts) != 1 or stmts[0] is None:
            res.errors.append("exactly one SELECT statement is allowed")
            return res
        tree = stmts[0]
        if not isinstance(tree, (exp.Select, exp.Union)) and not (isinstance(tree, exp.Query)):
            res.errors.append(f"only SELECT queries are allowed (got {type(tree).__name__})")
            return res
        forbidden = (exp.Insert, exp.Update, exp.Delete, exp.Drop, exp.Create, exp.Alter, exp.Command,
                     exp.TruncateTable, exp.Merge)
        for node in tree.walk():
            if isinstance(node, forbidden):
                res.errors.append(f"statement contains {type(node).__name__} - read-only queries only")
                return res
        # ---- tables
        cte_names = {c.alias_or_name.lower() for c in tree.find_all(exp.CTE)}
        alias_to_table: Dict[str, str] = {}
        for t in tree.find_all(exp.Table):
            name = t.name.lower()
            if name in cte_names:
                continue
            db = (t.db or "").lower()
            if name not in self.allowed:
                res.errors.append(f"table '{name}' is not allowed - query only the *_v2 profile tables: "
                                  + ", ".join(sorted(self.cat.tables))[:600])
                continue
            if db and db != self.schema:
                res.errors.append(f"table {db}.{name}: schema must be {self.schema}")
            if not db:
                t.set("db", exp.to_identifier(self.schema))
            alias = (t.alias or name).lower()
            alias_to_table[alias] = name
            if name not in res.tables:
                res.tables.append(name)
        if res.errors:
            return res
        if not res.tables:
            res.errors.append("no table referenced")
            return res
        # ---- select *
        if not self.allow_star:
            for st in tree.find_all(exp.Star):
                anc, in_count = st.parent, False
                while anc is not None:
                    if isinstance(anc, exp.Count):
                        in_count = True
                        break
                    anc = anc.parent
                if not in_count:
                    res.errors.append("SELECT * is not allowed on profile tables (hundreds of columns) - list the columns the user needs")
                    break
        # ---- columns exist
        known_tables = {t: self.cat.tables[t] for t in res.tables if t in self.cat.tables}
        for col in tree.find_all(exp.Column):
            cname = col.name.lower()
            if not cname or cname == "*":
                continue
            tref = (col.table or "").lower()
            if tref:
                tname = alias_to_table.get(tref)
                if tname is None:
                    continue                    # CTE / derived alias: cannot be checked statically
                tb = known_tables.get(tname)
                if tb and not tb.column(cname):
                    res.errors.append(f"column '{cname}' does not exist in {tname}" + self._hint(tb, cname))
            else:
                if known_tables and not any(tb.column(cname) for tb in known_tables.values()):
                    # might be an output alias (e.g. ORDER BY alias) - accept if defined as alias
                    aliases = {a.alias.lower() for a in tree.find_all(exp.Alias) if a.alias}
                    if cname not in aliases and not cte_names:
                        res.errors.append(f"column '{cname}' not found in {', '.join(known_tables)}"
                                          + self._hint(next(iter(known_tables.values())), cname))
        if res.errors:
            res.errors = sorted(set(res.errors))[:15]
            return res
        # ---- limit
        lim = int(limit if limit is not None else self.max_rows + 1)
        top = tree
        if isinstance(top, (exp.Select, exp.Union)):
            existing = top.args.get("limit")
            if existing is None or self._limit_value(existing) is None or self._limit_value(existing) > lim:
                top.set("limit", exp.Limit(expression=exp.Literal.number(lim)))
            if offset:
                top.set("offset", exp.Offset(expression=exp.Literal.number(offset)))
        res.sql = tree.sql(dialect=self.dialect, pretty=True)
        res.ok = True
        return res

    @staticmethod
    def _limit_value(node) -> Optional[int]:
        try:
            return int(node.expression.this)
        except Exception:  # noqa: BLE001
            return None

    def _hint(self, tb, cname: str) -> str:
        toks = set(re.findall(r"[a-z0-9]+", cname))
        cand = sorted(tb.columns, key=lambda c: -len(toks & set(re.findall(r"[a-z0-9]+", c.name))))[:6]
        cand = [c.name for c in cand if toks & set(re.findall(r"[a-z0-9]+", c.name))]
        return f" (similar: {', '.join(cand)})" if cand else ""

    def wrap_count(self, sql: str) -> str:
        inner = sqlglot.parse_one(sql, read=self.dialect)
        inner.set("limit", None)
        inner.set("offset", None)
        return f"SELECT COUNT(*) AS n FROM ({inner.sql(dialect=self.dialect)}) AS q"

    def without_limit(self, sql: str, limit: int) -> str:
        tree = sqlglot.parse_one(sql, read=self.dialect)
        tree.set("limit", exp.Limit(expression=exp.Literal.number(limit)))
        tree.set("offset", None)
        return tree.sql(dialect=self.dialect, pretty=True)
