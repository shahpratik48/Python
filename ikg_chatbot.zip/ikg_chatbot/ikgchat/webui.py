"""
ChatGPT-style web UI served by the Python standard library (no extra packages).

  from a notebook:   ikgchat.webui.launch(ctx)          -> starts the server in the background and opens a new
                                                           browser window / tab (works behind JupyterLab's proxy too)
  from a terminal:   python app_web.py                  -> see app_web.py
"""
from __future__ import annotations

import json
import logging
import socket
import threading
import time
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import ikgchat

log = logging.getLogger("ikgchat.webui")
HTML_PATH = Path(__file__).resolve().parent.parent / "web" / "index.html"

STATE = {"ctx": None, "sessions": {}, "lock": threading.Lock(), "cfg": None, "jobs": {}}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):      # quieter log
        log.debug(fmt, *args)

    def _send(self, code: int, body: bytes, ctype: str = "application/json; charset=utf-8", extra=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj, ensure_ascii=False, default=str).encode("utf-8"))

    def do_GET(self):
        u = urlparse(self.path)
        if u.path in ("/", "/index.html"):
            self._send(200, HTML_PATH.read_bytes(), "text/html; charset=utf-8")
        elif u.path == "/api/status":
            ctx = STATE["ctx"]
            cat = ctx.cat
            self._json({"ready": True, "tables": len(cat.tables), "columns": sum(len(t.columns) for t in cat.tables.values()),
                        "schema": cat.schema, "model": STATE["cfg"].llm["deployment"], "notes": cat.notes,
                        "examples": [q["q"] for q in cat.question_bank[:12]]})
        elif u.path == "/api/chats":
            self._json({"chats": ikgchat.chat_store(STATE["ctx"]).list_chats()})
        elif u.path.startswith("/api/chats/"):
            cid = u.path.split("/")[3]
            sess = _session(cid)
            msgs = ikgchat.chat_store(STATE["ctx"]).messages(cid)
            self._json({"chat_id": cid, "title": sess.title, "messages": [
                {"role": m["role"], "text": m["text"], "ts": m.get("created_ts", ""), "payload": m.get("payload") or {}} for m in msgs]})
        elif u.path == "/api/result":
            jid = parse_qs(u.query).get("job", [""])[0]
            j = STATE["jobs"].get(jid)
            if j is None:
                self._json({"status": "unknown"}, 404)
            elif j["status"] == "done":
                self._json({"status": "done", "answer": j["answer"]})
                # keep finished jobs for a while in case of a retry, then drop them
                STATE["jobs"] = {k: v for k, v in STATE["jobs"].items() if v["status"] != "done" or time.time() - v.get("started", 0) < 3600}
            else:
                self._json({"status": "running", "seconds": round(time.time() - j["started"])})
        elif u.path == "/api/download":
            f = parse_qs(u.query).get("file", [""])[0]
            p = Path(f)
            exports = STATE["cfg"].path(STATE["cfg"].output["exports_folder"]).resolve()
            if not p.exists() or exports not in p.resolve().parents:
                self._json({"error": "file not found"}, 404)
                return
            self._send(200, p.read_bytes(), "text/csv", {"Content-Disposition": f'attachment; filename="{p.name}"'})
        else:
            self._json({"error": "not found"}, 404)

    def do_POST(self):
        u = urlparse(self.path)
        n = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(n) or b"{}")
        if u.path == "/api/chats":                       # new chat
            with STATE["lock"]:
                s = ikgchat.new_session(STATE["ctx"])
                STATE["sessions"][s.chat_id] = s
            self._json({"chat_id": s.chat_id, "title": s.title})
            return
        if u.path == "/api/ask":
            q = (body.get("question") or "").strip()
            cid = body.get("chat_id") or ""
            s = _session(cid) if cid else None
            if s is None:
                with STATE["lock"]:
                    s = ikgchat.new_session(STATE["ctx"])
                    STATE["sessions"][s.chat_id] = s
            job = uuid.uuid4().hex[:12]
            STATE["jobs"][job] = {"status": "running", "started": time.time()}

            def work(sess=s, question=q, jid=job):
                try:
                    a = sess.ask(question)
                    d = a.to_dict()
                    d["chat_id"], d["title"] = sess.chat_id, sess.title
                except Exception as e:  # noqa: BLE001
                    log.exception("ask failed")
                    d = {"kind": "error", "text": f"Sorry - something went wrong: {str(e)[:300]}", "chat_id": sess.chat_id, "title": sess.title}
                STATE["jobs"][jid] = {"status": "done", "answer": d}

            threading.Thread(target=work, daemon=True).start()
            self._json({"job": job, "chat_id": s.chat_id})
            return
        if u.path == "/api/delete":
            cid = body.get("chat_id") or ""
            ikgchat.chat_store(STATE["ctx"]).delete_chat(cid)
            with STATE["lock"]:
                STATE["sessions"].pop(cid, None)
            self._json({"ok": True})
            return
        self._json({"error": "not found"}, 404)


def _session(chat_id: str):
    """Live session for a chat id; a saved chat is restored (messages + context) on first use."""
    with STATE["lock"]:
        s = STATE["sessions"].get(chat_id)
        if s is None:
            s = ikgchat.new_session(STATE["ctx"], chat_id=chat_id)
            STATE["sessions"][chat_id] = s
        return s




_SERVER = {"srv": None, "thread": None, "port": None}


def serve(ctx, host: str = "127.0.0.1", port: int = 8765, background: bool = False):
    """Start the HTTP server for a prepared ChatContext. background=True returns at once (daemon thread)."""
    STATE["ctx"], STATE["cfg"] = ctx, ctx.cfg
    if _SERVER["srv"] is not None:
        log.info("web UI already running on port %s", _SERVER["port"])
        return _SERVER["srv"]
    srv = ThreadingHTTPServer((host, port), Handler)
    _SERVER.update(srv=srv, port=port)
    if background:
        t = threading.Thread(target=srv.serve_forever, daemon=True, name="ikg-chatbot-web")
        t.start()
        _SERVER["thread"] = t
        return srv
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    return srv


def stop():
    if _SERVER["srv"] is not None:
        _SERVER["srv"].shutdown()
        _SERVER.update(srv=None, thread=None, port=None)


def launch(ctx, port: int = 8765, host: str = "0.0.0.0", open_window: bool = True):
    """Notebook helper: start the UI in the background and open it in a NEW browser window/tab.

    Works in three situations:
      * notebook on your own machine            -> opens http://localhost:<port>
      * JupyterLab / JupyterHub on a server with jupyter-server-proxy -> opens <jupyter base>/proxy/<port>/
      * JupyterLab on a server without the proxy -> shows the direct URL http://<server>:<port> to open yourself
    """
    serve(ctx, host=host, port=port, background=True)
    local = f"http://localhost:{port}/"
    try:
        ip = socket.gethostbyname(socket.gethostname())
    except Exception:  # noqa: BLE001
        ip = socket.gethostname()
    direct = f"http://{ip}:{port}/"
    try:
        from IPython.display import HTML, display
        js = rf"""
        <div style="font-family:sans-serif;font-size:14px">
          <button id="ikg-open" style="padding:8px 14px;border-radius:8px;border:1px solid #888;cursor:pointer;font-size:14px">
            Open IKG Chatbot in a new window</button>
          <span style="margin-left:10px;color:#666">direct links: <a href="{local}" target="_blank">{local}</a> &middot;
          <a href="{direct}" target="_blank">{direct}</a></span>
        </div>
        <script>
        (function(){{
          const btn = document.getElementById('ikg-open');
          function url(){{
            const p = location.pathname;
            const m = p.match(/^(.*?)\/(lab|notebooks|tree|voila|doc)(\/|$)/);   // JupyterLab / Hub base path
            if (m) return location.origin + m[1] + '/proxy/{port}/';            // jupyter-server-proxy
            if (location.hostname === 'localhost' || location.hostname === '127.0.0.1') return '{local}';
            return 'http://' + location.hostname + ':{port}/';
          }}
          btn.onclick = () => window.open(url(), '_blank', 'noopener,width=1280,height=860');
          if ({'true' if open_window else 'false'}) setTimeout(() => window.open(url(), '_blank', 'noopener,width=1280,height=860'), 300);
        }})();
        </script>"""
        display(HTML(js))
        print(f"IKG Chatbot UI is running (port {port}). If no window opened, click the button above or use a direct link.")
    except Exception:  # noqa: BLE001 - not in a notebook
        print(f"IKG Chatbot UI: {local}  (or {direct})")
        if open_window:
            webbrowser.open(local)
    return local
