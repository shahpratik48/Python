"""Greenplum access for the chatbot: read-only, every query under a statement timeout and a row cap."""
from __future__ import annotations

import logging
import time
from typing import List, Optional
from urllib.parse import quote_plus

import pandas as pd

from .config import Config, get_secret

log = logging.getLogger(__name__)


class Greenplum:
    def __init__(self, cfg: Config):
        self.c = cfg.greenplum
        self.timeout = int(self.c.get("statement_timeout_seconds", 120))
        self._engine = None

    @property
    def engine(self):
        if self._engine is None:
            from sqlalchemy import create_engine
            pwd = quote_plus(get_secret("gp_password"))
            url = (f"postgresql+psycopg2://{self.c['user']}:{pwd}@{self.c['host']}:{self.c['port']}"
                   f"/{self.c['database']}")
            self._engine = create_engine(
                url, pool_pre_ping=True,
                connect_args={"sslmode": self.c.get("sslmode", "prefer"), "connect_timeout": 30,
                              "options": f"-c statement_timeout={self.timeout * 1000} -c default_transaction_read_only=on"})
        return self._engine

    @property
    def write_engine(self):
        """Separate connection for the chat-history table only (the query engine stays read-only)."""
        if getattr(self, "_wengine", None) is None:
            from sqlalchemy import create_engine
            pwd = quote_plus(get_secret("gp_password"))
            url = (f"postgresql+psycopg2://{self.c['user']}:{pwd}@{self.c['host']}:{self.c['port']}"
                   f"/{self.c['database']}")
            self._wengine = create_engine(url, pool_pre_ping=True,
                                          connect_args={"sslmode": self.c.get("sslmode", "prefer"), "connect_timeout": 30})
        return self._wengine

    @property
    def dialect(self) -> str:
        return self.engine.dialect.name          # "postgresql" (or "sqlite" in the self-test)

    def test(self) -> str:
        from sqlalchemy import text
        with self.engine.connect() as con:
            return str(con.execute(text("select version()")).scalar())[:80]

    def read(self, sql: str, params: Optional[dict] = None) -> pd.DataFrame:
        from sqlalchemy import text
        t0 = time.time()
        with self.engine.connect() as con:
            df = pd.read_sql_query(text(sql), con, params=params)
        log.debug("query %.1fs %d rows", time.time() - t0, len(df))
        return df

    def explain(self, sql: str) -> str:
        """Plan the statement without running it (catches unknown columns, bad joins) - cheap."""
        from sqlalchemy import text
        if self.dialect != "postgresql":
            return "explain skipped (not postgres)"
        with self.engine.connect() as con:
            rows = con.execute(text("EXPLAIN " + sql)).fetchall()
        return "\n".join(str(r[0]) for r in rows[:30])

    # ------------------------------------------------------------------ catalog helpers
    def tables_like(self, schema: str, pattern: str) -> List[str]:
        df = self.read("select table_name from information_schema.tables where table_schema = :s and "
                       "table_name like :p order by 1", {"s": schema, "p": pattern})
        return [str(t) for t in df.table_name]

    def columns_of(self, schema: str, pattern: str) -> pd.DataFrame:
        return self.read("select table_name, column_name, data_type, ordinal_position from information_schema.columns "
                         "where table_schema = :s and table_name like :p order by table_name, ordinal_position",
                         {"s": schema, "p": pattern})

    def table_exists(self, schema: str, table: str) -> bool:
        return len(self.read("select 1 from information_schema.tables where table_schema = :s and table_name = :t",
                             {"s": schema, "t": table})) > 0

    def row_count_estimate(self, schema: str, table: str) -> Optional[int]:
        try:
            if self.dialect != "postgresql":
                return int(self.read(f"select count(*) n from {schema}.{table}").iloc[0].n)
            df = self.read("select reltuples::bigint n from pg_class c join pg_namespace n on n.oid = c.relnamespace "
                           "where n.nspname = :s and c.relname = :t", {"s": schema, "t": table})
            return int(df.iloc[0].n) if len(df) else None
        except Exception:  # noqa: BLE001
            return None
