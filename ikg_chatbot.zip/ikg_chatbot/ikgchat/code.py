"""Profile create scripts from GitLab (optional): lets the query agent read how a column is computed."""
from __future__ import annotations

import io
import logging
import re
import shutil
import zipfile
from pathlib import Path
from typing import Dict, Optional
from urllib.parse import quote

from .config import Config, get_secret, ssl_verify

log = logging.getLogger(__name__)


class ProfileCode:
    def __init__(self, cfg: Config, cache_dir: Path):
        self.g = cfg.gitlab
        self.cache = Path(cache_dir) / "repo"
        self._scripts: Dict[str, str] = {}

    @property
    def root(self) -> Path:
        return Path(self.g["local_repo_path"]) if self.g.get("local_repo_path") else self.cache

    def profile_dir(self) -> Path:
        return self.root / Path(self.g["code_root"])

    def fetch(self, refresh: bool = False) -> Optional[Path]:
        if self.g.get("local_repo_path"):
            if not self.profile_dir().exists():
                log.warning("profile folder not found under local_repo_path: %s", self.profile_dir())
                return None
            return self.root
        marker = self.cache / ".ref"
        cached_ref = marker.read_text(encoding="utf-8").strip() if marker.exists() else ""
        if self.profile_dir().exists() and not refresh and cached_ref == self.g["ref"]:
            log.info("Using cached profile SQL %s @%s", self.cache, cached_ref)
            return self.cache
        import requests
        token = get_secret("gitlab_token")
        verify = ssl_verify(self.g.get("ssl_verify", True))
        base = self.g["url"].rstrip("/") + "/api/v4/projects/" + quote(self.g["project_path"], safe="")
        hdr = {"PRIVATE-TOKEN": token}
        if self.cache.exists():
            shutil.rmtree(self.cache)
        self.cache.mkdir(parents=True)
        log.info("Downloading %s@%s:%s ...", self.g["project_path"], self.g["ref"], self.g["code_root"])
        r = requests.get(f"{base}/repository/archive.zip", headers=hdr, verify=verify, timeout=600,
                         params={"sha": self.g["ref"], "path": self.g["code_root"]})
        r.raise_for_status()
        with zipfile.ZipFile(io.BytesIO(r.content)) as z:
            for m in z.infolist():
                if m.is_dir() or not m.filename.endswith(".sql"):
                    continue
                rel = m.filename.split("/", 1)[-1]
                idx = rel.find("dags/")
                if idx < 0:
                    continue
                dst = self.cache / rel[idx:]
                dst.parent.mkdir(parents=True, exist_ok=True)
                dst.write_bytes(z.read(m))
        marker.write_text(self.g["ref"], encoding="utf-8")
        return self.cache

    # ------------------------------------------------------------------ lookup
    def script(self, base_table: str) -> str:
        if base_table not in self._scripts:
            p = self.profile_dir() / f"{base_table}.sql"
            self._scripts[base_table] = p.read_text(encoding="utf-8", errors="replace") if p.exists() else ""
        return self._scripts[base_table]

    def expression(self, table: str, column: str) -> dict:
        base = re.sub(r"_v\d+$", "", table)
        base = re.sub(r"(_profile_curr_ikg).*$", r"\1", base)
        txt = self.script(base)
        if not txt:
            return {"note": f"no create script found for {base}"}
        lines = txt.splitlines()
        hits = []
        pat = re.compile(rf"(?i)(\bAS\s+{re.escape(column)}\b|^\s*[a-z0-9_]+\.{re.escape(column)}\s*,|^\s*{re.escape(column)}\s*,|\b{re.escape(column)}\s*=)")
        for i, l in enumerate(lines):
            if pat.search(l):
                start = max(0, i - 3)
                hits.append({"line": i + 1, "snippet": "\n".join(lines[start:i + 1]).strip()[:600]})
            if len(hits) >= 4:
                break
        return {"script": f"{base}.sql", "matches": hits or [{"note": "column name not found in the script (may come from SELECT *)"}]}
