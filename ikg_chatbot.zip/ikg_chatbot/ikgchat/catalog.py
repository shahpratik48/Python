"""
Semantic catalog of what the chatbot may query.

Built from the IKG business metadata & knowledge-graph tables (all in greenplum.schema):
  ikg_attribute_business_description   business name + description per (table, column)
  ikg_metadata_glossary_llm            abbreviation -> meaning
  ikg_graph_relationship               entity -> entity relationships (label, joining key)
  ikg_graph_joining_key                joining keys between tables / entities
  ikg_profile_table_descriptions       table grain, purpose, join keys
+ information_schema of the *_v2 profile tables (the ONLY tables the bot queries: real columns and types)
+ config/entity_model.yaml, config/concepts.yaml, skills/*.md

The catalog is cached as JSON (sources.catalog_cache) and rebuilt on demand.
"""
from __future__ import annotations

import json
import logging
import re
from collections import defaultdict
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

import pandas as pd

from .config import Config, load_yaml

log = logging.getLogger(__name__)

TOKEN_RE = re.compile(r"[a-z0-9]+")


def tokens(s: str) -> List[str]:
    return TOKEN_RE.findall(str(s or "").lower())


@dataclass
class Column:
    table: str
    name: str
    data_type: str = ""
    business_name: str = ""
    description: str = ""
    entity: str = ""
    attribute_type: str = ""
    unit: str = ""
    confidence: int = 0
    ordinal: int = 0

    def brief(self) -> str:
        d = (self.description or "").strip()
        return f"{self.name} ({self.data_type}): {self.business_name or '?'} - {d[:220]}" + ("..." if len(d) > 220 else "")


@dataclass
class Table:
    name: str                     # physical table (…_v2)
    base_name: str                # metadata name (…_curr_ikg)
    entity: str = ""
    description: str = ""
    grain: str = ""
    primary_key: str = ""
    join_keys: str = ""
    topic_area: str = ""
    row_estimate: Optional[int] = None
    columns: List[Column] = field(default_factory=list)

    def column(self, name: str) -> Optional[Column]:
        n = name.lower()
        return next((c for c in self.columns if c.name == n), None)

    def brief(self) -> str:
        return (f"{self.name} [{self.entity or '?'}] grain: {self.grain or '?'}; keys: {self.primary_key or self.join_keys or '?'}; "
                f"{len(self.columns)} columns; {self.description[:200]}")


class Catalog:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.schema = cfg.greenplum["schema"]
        self.tables: Dict[str, Table] = {}
        self.glossary: Dict[str, str] = {}
        self.relationships: List[dict] = []
        self.joining_keys: List[dict] = []
        self.entity_model: dict = load_yaml(cfg, cfg.sources["entity_model"])
        self.concepts: dict = load_yaml(cfg, cfg.sources["concepts"])
        self.question_bank: List[dict] = (load_yaml(cfg, cfg.sources["question_bank"]) or {}).get("questions", [])
        self.notes: List[str] = []
        self._syn: Dict[str, Set[str]] = {}

    # ------------------------------------------------------------------ build
    def build(self, gp) -> "Catalog":
        s = self.cfg.sources
        pat = s["profile_table_pattern"]
        phys = gp.tables_like(self.schema, pat)
        if not phys:
            raise RuntimeError(f"no tables matching {pat} in schema {self.schema} - the profile clone tables must exist")
        suffix = self._suffix(pat)
        cols = gp.columns_of(self.schema, pat)
        meta = self._load_table(gp, s["metadata_table"])
        if meta.empty and s.get("metadata_workbook"):
            meta = self._metadata_from_workbook(self.cfg.path(s["metadata_workbook"]))
        if meta.empty:
            self.notes.append(f"{s['metadata_table']} not found - column meanings limited to names")
        desc = self._load_table(gp, s["profile_descriptions_table"])
        meta_idx = {(str(r.table_name).lower(), str(r.column_name).lower()): r for r in meta.itertuples()} if len(meta) else {}
        desc_idx = {str(r.table_name).lower(): r for r in desc.itertuples()} if len(desc) else {}
        for t in phys:
            base = t[:-len(suffix)] if suffix and t.endswith(suffix) else t
            d = desc_idx.get(base) or desc_idx.get(t)
            tb = Table(name=t, base_name=base,
                       entity=self._entity_for(base),
                       description=str(getattr(d, "description", "") or "") if d is not None else "",
                       grain=str(getattr(d, "grain", "") or "") if d is not None else "",
                       primary_key=str(getattr(d, "primary_key", "") or "") if d is not None else "",
                       join_keys=str(getattr(d, "join_keys", "") or "") if d is not None else "",
                       topic_area=str(getattr(d, "topic_area", "") or "") if d is not None else "",
                       row_estimate=gp.row_count_estimate(self.schema, t))
            for r in cols[cols.table_name == t].itertuples():
                m = meta_idx.get((base, str(r.column_name).lower())) or meta_idx.get((t, str(r.column_name).lower()))
                tb.columns.append(Column(
                    table=t, name=str(r.column_name).lower(), data_type=str(r.data_type), ordinal=int(r.ordinal_position),
                    business_name=str(getattr(m, "business_attribute_name", "") or "") if m is not None else "",
                    description=str(getattr(m, "description", "") or "") if m is not None else "",
                    entity=str(getattr(m, "entity", "") or "") if m is not None else "",
                    attribute_type=str(getattr(m, "attribute_type", "") or "") if m is not None else "",
                    unit=str(getattr(m, "unit", "") or "") if m is not None else "",
                    confidence=int(float(getattr(m, "confidence_score", 0) or 0)) if m is not None else 0))
            self.tables[t] = tb
        gl = self._load_table(gp, s["glossary_table"])
        if len(gl):
            tcol = next((c for c in gl.columns if c in ("token", "abbreviation", "term")), gl.columns[0])
            mcol = next((c for c in gl.columns if c in ("meaning", "full_form", "definition", "expansion")), gl.columns[1])
            for r in gl.itertuples():
                k, v = str(getattr(r, tcol)).lower().strip(), str(getattr(r, mcol) or "").strip()
                if k and v and v.lower() not in ("", "nan", "none") and "needs_input" not in v.lower():
                    self.glossary[k] = v
        rel = self._load_table(gp, s["graph_relationship_table"])
        self.relationships = rel.fillna("").astype(str).to_dict("records") if len(rel) else []
        jk = self._load_table(gp, s["graph_joining_key_table"])
        self.joining_keys = jk.fillna("").astype(str).to_dict("records") if len(jk) else []
        if not self.joining_keys:
            self.notes.append("joining-key table not found - joins derived from the entity model keys only")
        self._index()
        log.info("catalog: %d tables, %d columns, %d glossary terms, %d relationships, %d joining keys",
                 len(self.tables), sum(len(t.columns) for t in self.tables.values()), len(self.glossary),
                 len(self.relationships), len(self.joining_keys))
        return self

    @staticmethod
    def _suffix(pattern: str) -> str:
        m = re.search(r"profile_curr_ikg(.*)$", pattern)
        return m.group(1) if m else ""

    def _load_table(self, gp, table: str) -> pd.DataFrame:
        try:
            if not gp.table_exists(self.schema, table):
                return pd.DataFrame()
            return gp.read(f"select * from {self.schema}.{table}")
        except Exception as e:  # noqa: BLE001
            log.warning("could not read %s.%s: %s", self.schema, table, e)
            return pd.DataFrame()

    @staticmethod
    def _metadata_from_workbook(path: Path) -> pd.DataFrame:
        if not path.exists():
            return pd.DataFrame()
        return pd.read_excel(path, sheet_name="Metadata")

    def _entity_for(self, base: str) -> str:
        em = self.entity_model or {}
        for pre, ent in sorted((em.get("table_prefix_entity") or {}).items(), key=lambda kv: -len(kv[0])):
            if base.startswith(pre):
                return ent
        return ""

    # ------------------------------------------------------------------ cache
    def save(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        data = {"tables": {k: {**asdict(t), "columns": [asdict(c) for c in t.columns]} for k, t in self.tables.items()},
                "glossary": self.glossary, "relationships": self.relationships, "joining_keys": self.joining_keys,
                "notes": self.notes}
        path.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")

    def load(self, path: Path) -> "Catalog":
        data = json.loads(path.read_text(encoding="utf-8"))
        self.tables = {}
        for k, t in data["tables"].items():
            cols = [Column(**c) for c in t.pop("columns")]
            self.tables[k] = Table(**t, columns=cols)
        self.glossary = data.get("glossary", {})
        self.relationships = data.get("relationships", [])
        self.joining_keys = data.get("joining_keys", [])
        self.notes = data.get("notes", [])
        self._index()
        return self

    # ------------------------------------------------------------------ search
    def _index(self) -> None:
        self._syn = defaultdict(set)
        for name, c in (self.concepts.get("concepts") or {}).items():
            for w in c.get("says", []):
                for tk in tokens(w):
                    self._syn[tk].update(c.get("column_tokens", []))
        for abbr, meaning in self.glossary.items():
            for tk in tokens(meaning):
                if len(tk) > 2:
                    self._syn[tk].add(abbr)
        self.stop = set(self.concepts.get("stopwords") or [])

    def expand(self, question: str) -> Tuple[Set[str], List[str]]:
        """question -> (search tokens incl. synonyms, matched concept names)"""
        q = tokens(question)
        base = {t for t in q if t not in self.stop and len(t) > 1}
        out = set(base)
        for t in base:
            out |= self._syn.get(t, set())
        concepts = []
        ql = " " + " ".join(q) + " "
        for name, c in (self.concepts.get("concepts") or {}).items():
            if any(" " + " ".join(tokens(w)) + " " in ql for w in c.get("says", [])):
                concepts.append(name)
        return out, concepts

    def search_columns(self, question: str, k: int = 40, tables: Optional[List[str]] = None) -> List[Tuple[Column, float]]:
        q, _ = self.expand(question)
        scored = []
        for t in self.tables.values():
            if tables and t.name not in tables:
                continue
            for c in t.columns:
                nt = set(tokens(c.name))
                bt = set(tokens(c.business_name))
                dt = set(tokens(c.description))
                s = 3.0 * len(q & nt) + 2.0 * len(q & bt) + 0.6 * len(q & dt)
                if s > 0:
                    s += min(0.5, c.confidence / 200)
                    scored.append((c, s))
        scored.sort(key=lambda x: -x[1])
        return scored[:k]

    def search_tables(self, question: str, k: int = 6) -> List[Tuple[Table, float]]:
        cols = self.search_columns(question, k=200)
        agg: Dict[str, float] = defaultdict(float)
        for c, s in cols:
            agg[c.table] += s
        q, concepts = self.expand(question)
        for t in self.tables.values():
            tt = set(tokens(t.base_name)) | set(tokens(t.description)) | set(tokens(t.entity))
            agg[t.name] += 2.0 * len(q & tt)
            ents = {(self.concepts.get("concepts") or {}).get(cn, {}).get("entity", "") for cn in concepts}
            if t.entity and t.entity in ents:
                agg[t.name] += 3.0
        ranked = sorted(agg.items(), key=lambda kv: -kv[1])[:k]
        return [(self.tables[n], s) for n, s in ranked if s > 0]

    def similar_questions(self, question: str, k: int = 3) -> List[dict]:
        q = set(tokens(question)) - self.stop
        out = []
        for item in self.question_bank:
            s = len(q & (set(tokens(item.get("q", ""))) - self.stop))
            if s >= 2:
                out.append((s, item))
        out.sort(key=lambda x: -x[0])
        return [i for _, i in out[:k]]

    # ------------------------------------------------------------------ joins
    def join_path(self, a: str, b: str) -> List[dict]:
        """Joining keys between two physical tables (from the graph table, else shared entity keys)."""
        ta, tb = self.tables.get(a), self.tables.get(b)
        if not ta or not tb:
            return []
        out = []
        for r in self.joining_keys:
            vals = " ".join(str(v).lower() for v in r.values())
            if (ta.base_name in vals or a in vals) and (tb.base_name in vals or b in vals):
                out.append(r)
        if out:
            return out
        keys = {k for v in (self.entity_model.get("entities") or {}).values() for k in v.get("keys", [])}
        shared = [k for k in keys if ta.column(k) and tb.column(k)]
        return [{"table_a": a, "table_b": b, "joining_key": k, "source": "shared entity key"} for k in shared]

    def key_columns(self, table: str) -> List[str]:
        t = self.tables.get(table)
        if not t:
            return []
        keys = {k for v in (self.entity_model.get("entities") or {}).values() for k in v.get("keys", [])}
        return [c.name for c in t.columns if c.name in keys]

    def entity_overview(self) -> str:
        lines = []
        for name, e in (self.entity_model.get("entities") or {}).items():
            lines.append(f"- {name}: keys {', '.join(e.get('keys', []))}; {str(e.get('description', ''))[:120]}")
        return "\n".join(lines)
