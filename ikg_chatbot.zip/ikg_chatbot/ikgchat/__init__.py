"""IKG Chatbot - natural-language questions over the IKG profile tables (text-to-SQL with grounded agents)."""
from __future__ import annotations

import logging
from pathlib import Path

from .config import load_config, get_secret, set_secret
from .catalog import Catalog
from .db import Greenplum
from .llm import LLM

log = logging.getLogger(__name__)
__all__ = ["load_config", "get_secret", "set_secret", "prepare", "new_session", "Catalog", "Greenplum", "LLM"]


def prepare(cfg, llm=None, gp=None, rebuild_catalog: bool = False, fetch_code: bool = True):
    """Build (or load) the catalog, optionally fetch the profile SQL, and return the shared ChatContext."""
    from .agents.context import ChatContext
    from .code import ProfileCode
    out = cfg.path(cfg.output["folder"])
    out.mkdir(parents=True, exist_ok=True)
    gp = gp or Greenplum(cfg)
    llm = llm or LLM(cfg, out / "cache")
    cache = cfg.path(cfg.sources["catalog_cache"])
    cat = Catalog(cfg)
    if cache.exists() and not rebuild_catalog:
        cat.load(cache)
        log.info("catalog loaded from %s (%d tables) - use rebuild_catalog=True after project 1 re-runs", cache, len(cat.tables))
    else:
        cat.build(gp)
        cat.save(cache)
        log.info("catalog built and saved to %s", cache)
    code = None
    if fetch_code and cfg.gitlab.get("enabled", True):
        try:
            pc = ProfileCode(cfg, out / "cache")
            if pc.fetch() is not None:
                code = pc
        except Exception as e:  # noqa: BLE001
            log.warning("profile SQL not available (%s) - continuing without derivation lookups", e)
    return ChatContext(cfg, llm, gp, cat, code)


def new_session(ctx):
    from .session import ChatSession
    return ChatSession(ctx)
