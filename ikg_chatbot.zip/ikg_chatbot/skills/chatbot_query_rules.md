# Chatbot query rules (authoritative for the query agent)

## Definitions
- Household means the statement household: key `acc_mhh_n` (sourced from household_plus). The marketing household
  (`acc_market_hh_n`) is a different grouping and is used only when the user says "marketing household".
- Client key: `ip_cli_i`. Account key: `acc_i` (also `acc_n` in some tables). Financial advisor key: `fa_i`.
- "My clients" / "my book" refers to one financial advisor. Ask for the FA identifier (or name / wire code) when it is
  not given; never assume one.

## Amounts, percentages, windows
- Money columns are USD. "100M" = 100,000,000; "$50k" = 50,000.
- A percentage threshold compares against a percent column only after checking its scale (0-1 fraction vs 0-100).
- "Upcoming" / "in the next x days" without a number: ask; suggest 30 days for options, 90 days for maturities,
  12 months for mortgages.
- "Start of the year" means the beginning-of-year (BOY) snapshot columns; "year to date" means YTD columns.

## Output conventions
- Always return the identifying keys (household / client / account ids) and a name column when the table has one.
- "Top" / "greater than" questions are ordered largest first.
- One result set per question; household totals can be repeated per account row.
