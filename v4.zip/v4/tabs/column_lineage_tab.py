"""
column_lineage_tab.py
─────────────────────
Style: exact Insight_lineage.html (vis-network 9.1.9, pastel nodes, col-index pills,
       nrows multi-record right panel).

Payload variables (injected into lineage_template.html):
  ALL_GRAPHS  – [{profile_table, rule_column, insight_type:"",
                  nodes:[{id,tbl,col,schema,is_start,web_url}],
                  edges:[{from,to}],
                  nrows:{node_id:[{target_table,...,logic}]}}]
  RAW2COLOR   – {schema_lower: hex}
  LEGEND_DATA – [{label, color}]
"""
import json
import re
import urllib.parse
from pathlib import Path

import pandas as pd
from dash import Input, Output, dcc, html
from flask import request
from styles import metadata_dashboard_styles as mds
from utils.data import (
    get_all_target_columns,
    get_column_lineage_upstream,
    get_tables_for_column,
)

# ── Schema colors (matches Insight_lineage.html RAW2COLOR) ────────────────
RAW2COLOR = {
    "ikg_schema": "#1976d2", "sandbox_prj_smart_insights": "#1976d2",
    "sandbox_ikg_pre_prd": "#1976d2", "edw_input_schema": "#00897b",
    "core_wma_shared": "#00897b", "edw_view_input_schema": "#00897b",
    "ikg_vendor_schema": "#00897b", "core_wma_shared_masked": "#26a69a",
    "sandbox_wma_shared": "#388e3c", "sandbox_prj_ds_data": "#f4511e",
    "sandbox_prj_sbl": "#7b1fa2", "core_nlg": "#5c6bc0",
    "nlg_schema": "#5c6bc0", "core_model": "#6d4c41",
    "model_schema": "#6d4c41", "sandbox_prj_dsforoverdrive": "#0288d1",
    "core_in_shared": "#689f38", "ikg_clip_schema": "#689f38",
    "sandbox_prj_adhoc": "#e91e8c", "ikg_wealthx_schema": "#00838f",
    "sandbox_prj_rbat": "#9e7c0a", "_default": "#607d8b",
}
LEGEND_DATA = [
    {"label": "ikg",                "color": "#1976d2"},
    {"label": "core_wma_shared",    "color": "#00897b"},
    {"label": "sandbox_wma_shared", "color": "#388e3c"},
    {"label": "core_nlg",           "color": "#5c6bc0"},
    {"label": "core_model",         "color": "#6d4c41"},
    {"label": "edw / source",       "color": "#00897b"},
    {"label": "temp",               "color": "#607d8b"},
]


# ─────────────────────────────────────────────────────────────────────────────
def _s(v) -> str:
    if v is None: return ""
    try:
        if pd.isna(v): return ""
    except Exception: pass
    s = str(v).strip()
    return "" if s.lower() in ("none", "nan") else s


# ─────────────────────────────────────────────────────────────────────────────
# Payload builder — produces ALL_GRAPHS in exact Insight_lineage.html format
# ─────────────────────────────────────────────────────────────────────────────

def _build_all_graphs(target_column: str, target_table: str) -> list:
    """
    Single entry in ALL_GRAPHS for the upstream column lineage.
    Node format: {id:"tbl::col", tbl, col, schema, is_start, web_url}
    nrows: {node_id: [all rows where that node is the target]}
    """
    tc = _s(target_column)
    tt = _s(target_table)
    if not tc or not tt:
        return []

    df = get_column_lineage_upstream(tc, tt)

    nodes_dict: dict[str, dict] = {}
    edges_set:  set[tuple]      = set()
    edges_list: list[dict]      = []
    nrows:      dict[str, list] = {}    # accumulates ALL rows per target node

    focal_id = f"{tt}::{tc}"
    nodes_dict[focal_id] = {
        "id": focal_id, "tbl": tt, "col": tc,
        "schema": "", "is_start": True, "web_url": "",
    }
    nrows[focal_id] = []

    if not df.empty:
        for r in df.itertuples(index=False):
            tgt_t  = _s(getattr(r, "target_table",      None))
            tgt_s  = _s(getattr(r, "target_schema",     None))
            tgt_c  = _s(getattr(r, "target_column",     None))
            src_t  = _s(getattr(r, "source_table",      None))
            src_s  = _s(getattr(r, "source_schema",     None))
            src_c  = _s(getattr(r, "source_column",     None))
            logic  = _s(getattr(r, "logic",             None))
            proc   = _s(getattr(r, "process",           None))
            sqlp   = _s(getattr(r, "sql_process",       None))
            web_u  = _s(getattr(r, "web_url",           None))
            sub_tt = _s(getattr(r, "sub_target_table",  None))
            sub_ts = _s(getattr(r, "sub_target_schema", None))

            if not tgt_t or not src_t:
                continue

            tgt_id = f"{tgt_t}::{tgt_c}"
            src_id = f"{src_t}::{src_c}"

            # ── Target node ──
            if tgt_id not in nodes_dict:
                nodes_dict[tgt_id] = {
                    "id": tgt_id, "tbl": tgt_t, "col": tgt_c,
                    "schema": tgt_s, "is_start": (tgt_id == focal_id), "web_url": web_u,
                }
            else:
                nd = nodes_dict[tgt_id]
                if tgt_s and not nd["schema"]:  nd["schema"]  = tgt_s
                if web_u  and not nd["web_url"]: nd["web_url"] = web_u

            # ── Source node ──
            if src_id not in nodes_dict:
                nodes_dict[src_id] = {
                    "id": src_id, "tbl": src_t, "col": src_c,
                    "schema": src_s, "is_start": False, "web_url": "",
                }
            elif src_s and not nodes_dict[src_id]["schema"]:
                nodes_dict[src_id]["schema"] = src_s

            # ── Edge ──
            ek = (src_id, tgt_id)
            if ek not in edges_set:
                edges_set.add(ek)
                edges_list.append({"from": src_id, "to": tgt_id})

            # ── nrows: accumulate ALL rows per target (for right panel) ──
            row_dict = {
                "target_table":      tgt_t,   "target_schema":      tgt_s,
                "sub_target_table":  sub_tt,  "sub_target_schema":  sub_ts,
                "target_column":     tgt_c,
                "source_table":      src_t,   "source_schema":      src_s,
                "source_column":     src_c,
                "process":           proc,    "sql_process":        sqlp,
                "logic":             logic,
            }
            nrows.setdefault(tgt_id, []).append(row_dict)

    # Ensure every node has an nrows entry
    for nid in nodes_dict:
        nrows.setdefault(nid, [])

    return [{
        "profile_table": tt,
        "rule_column":   tc,
        "insight_type":  "",          # empty → no insight banner shown
        "nodes":         list(nodes_dict.values()),
        "edges":         edges_list,
        "nrows":         nrows,
    }]


# ─────────────────────────────────────────────────────────────────────────────
# Template rendering
# ─────────────────────────────────────────────────────────────────────────────

def _template_path() -> Path:
    return Path(__file__).resolve().parents[1] / "utils" / "lineage_template.html"


def _render(target_column: str, target_table: str) -> str:
    template   = _template_path().read_text(encoding="utf-8")
    all_graphs = _build_all_graphs(target_column, target_table)

    payload = (
        f"var ALL_GRAPHS  = {json.dumps(all_graphs)};\n"
        f"var RAW2COLOR   = {json.dumps(RAW2COLOR)};\n"
        f"var LEGEND_DATA = {json.dumps(LEGEND_DATA)};"
    )

    # Single re.sub with lambda prevents backslash interpretation
    template = re.sub(
        r"var ALL_GRAPHS\s*=\s*.*?;\s*var RAW2COLOR\s*=\s*.*?;\s*var LEGEND_DATA\s*=\s*.*?;",
        lambda _: payload,
        template,
        flags=re.DOTALL,
    )
    template = re.sub(
        r"<title>.*?</title>",
        f"<title>{target_column} in {target_table}</title>",
        template, count=1, flags=re.DOTALL,
    )
    return template


# ─────────────────────────────────────────────────────────────────────────────
# Dash layout
# ─────────────────────────────────────────────────────────────────────────────

def layout():
    try:
        df_cols  = get_all_target_columns()
        col_opts = [{"label": c, "value": c}
                    for c in df_cols["target_column"].dropna().astype(str).tolist()]
    except Exception:
        col_opts = []

    return dcc.Tab(
        label="Column Lineage",
        value="tab-column-lineage",
        children=html.Div([
            html.H3("Column Lineage", style=mds["section_header_style"]),
            html.Div([
                html.Div([
                    html.Span("Target Column", style=mds["dropdown_label_style"]),
                    dcc.Dropdown(id="cl-column-dd", options=col_opts,
                                 placeholder="Select a column …",
                                 clearable=True, searchable=True,
                                 style={**mds["dropdown_style"], "width": "380px"}),
                ], style={"minWidth": "400px"}),
                html.Div("→", style={
                    "fontSize": "1.4rem", "color": "#94a3b8",
                    "padding": "0 8px", "alignSelf": "center", "marginTop": "18px",
                }),
                html.Div([
                    html.Span("Target Table", style=mds["dropdown_label_style"]),
                    dcc.Dropdown(id="cl-table-dd", options=[],
                                 placeholder="Select a table …",
                                 clearable=True, disabled=True,
                                 style={**mds["dropdown_style"], "width": "380px"}),
                ], style={"minWidth": "400px"}),
                html.Div(id="cl-info-badge", style={
                    "marginLeft": "auto", "alignSelf": "center", "marginTop": "18px",
                    "fontSize": "11px", "color": "#1d4ed8", "fontWeight": "600",
                    "padding": "4px 12px", "background": "#dbeafe",
                    "border": "1px solid #93c5fd", "borderRadius": "20px",
                }),
            ], style={**mds["toolbar_style"], "display": "flex",
                      "alignItems": "flex-start", "gap": "0px",
                      "flexWrap": "wrap", "marginBottom": "10px"}),
            html.Iframe(id="cl-iframe", src="",
                        style={"width": "100%", "height": "88vh",
                               "border": "1px solid #e2e8f0", "borderRadius": "8px"}),
        ], style=mds["table_container_style"]),
    )


# ─────────────────────────────────────────────────────────────────────────────
# Callbacks
# ─────────────────────────────────────────────────────────────────────────────

def register_callbacks(app):
    @app.callback(
        Output("cl-table-dd",   "options"),
        Output("cl-table-dd",   "disabled"),
        Output("cl-table-dd",   "value"),
        Output("cl-info-badge", "children"),
        Input("cl-column-dd",   "value"),
    )
    def _populate_tables(selected_col):
        if not selected_col:
            return [], True, None, ""
        try:
            df = get_tables_for_column(str(selected_col))
            tables = df["target_table"].dropna().astype(str).tolist()
        except Exception:
            tables = []
        opts  = [{"label": t, "value": t} for t in sorted(tables)]
        badge = f"{len(opts)} table{'s' if len(opts) != 1 else ''}"
        return opts, len(opts) == 0, None, badge

    @app.callback(
        Output("cl-iframe", "src"),
        Input("cl-column-dd", "value"),
        Input("cl-table-dd",  "value"),
    )
    def _update_iframe(col, table):
        if not col or not table:
            return ""
        return app.get_relative_path(
            f"/column-lineage-view"
            f"?col={urllib.parse.quote(str(col), safe='')}"
            f"&table={urllib.parse.quote(str(table), safe='')}")


# ─────────────────────────────────────────────────────────────────────────────
# Server route
# ─────────────────────────────────────────────────────────────────────────────

def register_server_routes(server, routes_prefix="/"):
    def _handler():
        col   = request.args.get("col",   "").strip()
        table = request.args.get("table", "").strip()
        if not col or not table:
            return ("<html><body style='font-family:Arial;padding:20px'>"
                    "Select a column and table to view lineage.</body></html>")
        try:
            return _render(col, table)
        except Exception as exc:
            safe = str(exc).replace("<", "&lt;").replace(">", "&gt;")
            return (f"<html><body style='font-family:Arial;padding:20px'>"
                    f"<b>Error:</b> {safe}</body></html>")

    if not routes_prefix.startswith("/"): routes_prefix = "/" + routes_prefix
    if not routes_prefix.endswith("/"):   routes_prefix = routes_prefix + "/"
    base = "/column-lineage-view"
    pref = f"{routes_prefix.rstrip('/')}{base}"
    existing = {r.rule for r in server.url_map.iter_rules()}
    if base not in existing:
        server.add_url_rule(base, endpoint="column_lineage_view", view_func=_handler)
    if pref not in existing and pref != base:
        server.add_url_rule(pref, endpoint="column_lineage_view_prefixed", view_func=_handler)
