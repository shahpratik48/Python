"""
The dashboard figures.

TWO figures are produced per pod:

    build_monthly_figure()   every month, Nov 24 -> Jul 26
    build_window_figure()    consecutive 3-month averages
                             (Nov 24-Jan 25, Dec 24-Feb 25, Jan 25-Mar 25, ...)

Both carry the same panels: a wide **Overall Productivity Gain** across the
top, then the four metrics in a 2x2 grid.

Each panel plots one actual series split in two at the baseline month:

    Actual (Previous)   before the baseline      dotted, grey
    Actual (Current)    baseline onward          solid, blue
    Aspiration          the target ramp          dashed, grey

Layout rules that keep text from colliding, learned the hard way from the
first version:

* The progress figure lives **inside the panel title**, not in a floating
  badge that sat on top of the legend.
* Legends are drawn **inside** the axes with a solid background, so they
  can never overlap a title or another panel.
* The figure subtitle sits in its own reserved band above the first axes,
  with the grid's top margin set below it.

matplotlib rather than a JavaScript charting library: it is present in
essentially every Python environment, renders inline in Jupyter without a
widget extension, and exports to PNG for sharing.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Sequence

import matplotlib
matplotlib.use("Agg")                      # safe default; Jupyter overrides via %matplotlib inline
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator

from gl_settings import get_logger
from prod_metrics import LOWER_IS_BETTER, METRIC_DEFS, month_label

log = get_logger("prod.charts")

C_CURR = "#1f3f7a"      # actual, from baseline onward
C_PREV = "#8a94a6"      # actual, before baseline
C_ASP = "#b0392b"       # aspiration
C_GRID = "#e6e8eb"
C_GOOD = "#0b6b36"
C_BAD = "#9b1c1c"
C_MUTED = "#666666"

PANEL_ORDER = ["merged_per_author", "throughput", "lead_time", "cycle_time"]
LABELS = dict((a, l) for a, l, _x in METRIC_DEFS)


def _thin(n: int, max_ticks: int = 11) -> List[int]:
    step = max(1, n // max_ticks)
    return [i for i in range(n) if i % step == 0 or i == n - 1]


def _plot(ax, series, colour, style, label, width=2.0, marker=None):
    xs = [i for i, v in enumerate(series) if v is not None]
    ys = [v for v in series if v is not None]
    if not xs:
        return False
    ax.plot(xs, ys, style, color=colour, linewidth=width, label=label,
            marker=marker, markersize=3, solid_capstyle="round")
    return True


def _fmt_value(v: float) -> str:
    """Short but unambiguous: no decimals for large numbers, one or two for
    small ones, so a label never becomes wider than the gap between points."""
    a = abs(v)
    if a >= 100:
        return "%.0f" % v
    if a >= 10:
        return "%.1f" % v
    return "%.2f" % v


def _annotate_all(ax, series, colour, above=True, fontsize=6.2, every=1):
    """Labels EVERY plotted point so a value can be read straight off the
    chart without cross-referencing a table.

    Actual sits above its point and aspiration below, so the two never
    collide where the lines cross. Labels get a translucent white background
    to stay legible over gridlines and other series.
    """
    dy = 7 if above else -11
    for i, v in enumerate(series):
        if v is None or (i % every):
            continue
        ax.annotate(_fmt_value(v), (i, v), textcoords="offset points",
                    xytext=(0, dy), ha="center", fontsize=fontsize, color=colour,
                    fontweight="bold", zorder=6,
                    bbox=dict(boxstyle="round,pad=0.12", facecolor="white",
                              edgecolor="none", alpha=0.72))


def _style(ax, xlabels, ticks, rotation=45):
    ax.grid(True, axis="y", color=C_GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_color(C_GRID)
    ax.set_xticks(ticks)
    ax.set_xticklabels(xlabels, rotation=rotation, ha="right", fontsize=7)
    ax.tick_params(labelsize=7.5, colors="#555")
    ax.yaxis.set_major_locator(MaxNLocator(nbins=5))


def _title(ax, main: str, sub: str, pct: Optional[float]):
    """Panel heading with the progress figure folded into the title.

    Keeping it here rather than in a separate badge is what removes the
    overlap: there is only ever one text object above the axes.
    """
    if pct is None:
        ax.set_title("%s\n%s" % (main, sub), fontsize=10.5, fontweight="bold",
                     pad=10, color="#1a1a1a")
        return
    ax.set_title("%s   %+.2f%%\n%s" % (main, pct, sub), fontsize=10.5, fontweight="bold",
                 pad=10, color=(C_GOOD if pct >= 0 else C_BAD))


def _legend(ax):
    if ax.get_legend_handles_labels()[0]:
        ax.legend(loc="best", fontsize=7, frameon=True, framealpha=0.92,
                  edgecolor=C_GRID, borderpad=0.4)


def _figure(ds, xlabels, baseline_idx, gain_prev, gain_curr, gain_asp,
            get_prev, get_curr, get_asp, view_label, pod_label, figsize,
            show_values=True, label_every=1, headline=None, overall_headline=None):
    ticks = _thin(len(xlabels))
    shown = [xlabels[i] for i in ticks]

    fig = plt.figure(figsize=figsize, facecolor="white")
    gs = fig.add_gridspec(3, 2, height_ratios=[1.15, 1, 1], hspace=0.95, wspace=0.18,
                          left=0.06, right=0.98, top=0.855, bottom=0.085)

    # ---------------- overall gain ----------------
    ax0 = fig.add_subplot(gs[0, :])
    _plot(ax0, gain_prev, C_PREV, ":", "Actual (Previous)", 2.0)
    _plot(ax0, gain_curr, C_CURR, "-", "Actual (Current)", 2.4, "o")
    _plot(ax0, gain_asp, C_ASP, "--", "Aspiration", 1.8)
    ax0.axhline(0, color="#c8ccd4", linewidth=1)
    if baseline_idx is not None:
        ax0.axvline(baseline_idx, color="#c8ccd4", linewidth=1, linestyle=":")
    _title(ax0, "Overall Productivity Gain", "%% vs baseline  (%s)" % view_label,
           overall_headline if overall_headline is not None else ds.latest_gain)
    ax0.set_ylabel("% vs baseline", fontsize=8.5)
    ax0.set_xlim(-0.5, len(xlabels) - 0.5)
    ax0.margins(y=0.20)
    _style(ax0, shown, ticks)
    _legend(ax0)
    if show_values:
        _annotate_all(ax0, gain_prev, C_PREV, above=True, every=label_every)
        _annotate_all(ax0, gain_curr, C_CURR, above=True, every=label_every)
        _annotate_all(ax0, gain_asp, C_ASP, above=False, every=label_every)

    # ---------------- four metric panels ----------------
    for (r, c), metric in zip([(1, 0), (1, 1), (2, 0), (2, 1)], PANEL_ORDER):
        ax = fig.add_subplot(gs[r, c])
        drew = False
        drew |= _plot(ax, get_prev(metric), C_PREV, ":", "Actual (Previous)", 1.8)
        drew |= _plot(ax, get_curr(metric), C_CURR, "-", "Actual (Current)", 2.2)
        drew |= _plot(ax, get_asp(metric), C_ASP, "--", "Aspiration", 1.6)
        if baseline_idx is not None:
            ax.axvline(baseline_idx, color="#dfe3e8", linewidth=1, linestyle=":")

        direction = "lower is better" if LOWER_IS_BETTER[metric] else "higher is better"
        pct = (headline or ds.progress_pct).get(metric)
        _title(ax, LABELS[metric], "%s  (%s)" % (direction, view_label), pct)
        ax.set_xlim(-0.5, len(xlabels) - 0.5)
        ax.margins(y=0.20)                 # room for the value labels
        _style(ax, shown, ticks)
        _legend(ax)
        if show_values:
            _annotate_all(ax, get_prev(metric), C_PREV, above=True, every=label_every)
            _annotate_all(ax, get_curr(metric), C_CURR, above=True, every=label_every)
            _annotate_all(ax, get_asp(metric), C_ASP, above=False, every=label_every)
        if not drew:
            ax.text(0.5, 0.5, "No data for this selection", transform=ax.transAxes,
                    ha="center", va="center", fontsize=10, color="#999")

    fig.suptitle("Productivity Dashboard  \u2014  %s" % pod_label,
                 fontsize=15, fontweight="bold", y=0.985)
    fig.text(0.06, 0.945,
             "%s   |   baseline %s   |   %s to %s"
             % (view_label, month_label(ds.baseline_month) if ds.baseline_month else "n/a",
                xlabels[0], xlabels[-1]),
             fontsize=9, color=C_MUTED)
    fig.text(0.06, 0.917,
             "Actual (Previous) = before the baseline    "
             "Actual (Current) = baseline onward    Aspiration = target ramp",
             fontsize=8, color=C_MUTED, style="italic")
    return fig


def build_monthly_figure(ds, pod_label: str = "", figsize=(20.0, 13.0),
                         show_values: bool = True, label_every: int = 1):
    """Every month individually, Nov 24 -> Jul 26, with every value labelled."""
    xlabels = [month_label(m) for m in ds.months]
    fig = _figure(ds, xlabels, ds.baseline_index,
                  ds.gain_actual_prev, ds.gain_actual_curr, ds.gain_aspiration,
                  lambda k: ds.actual_prev.get(k, []),
                  lambda k: ds.actual_curr.get(k, []),
                  lambda k: ds.aspiration.get(k, []),
                  "monthly", pod_label, figsize, show_values, label_every,
                  headline=ds.progress_pct, overall_headline=ds.latest_gain)
    log.info("Monthly figure built (%d month(s)) for %s.", len(ds.months), pod_label or "selection")
    return fig


def build_window_figure(ds, pod_label: str = "", figsize=(20.0, 13.0),
                        show_values: bool = True, label_every: int = 1):
    """Consecutive 3-month averages of both actual and aspiration, every
    value labelled."""
    xlabels = ds.window_labels or [month_label(m) for m in ds.months]
    fig = _figure(ds, xlabels, ds.baseline_window_index,
                  ds.w_gain_actual_prev, ds.w_gain_actual_curr, ds.w_gain_aspiration,
                  lambda k: ds.w_actual_prev.get(k, []),
                  lambda k: ds.w_actual_curr.get(k, []),
                  lambda k: ds.w_aspiration.get(k, []),
                  "3-month averages", pod_label, figsize, show_values, label_every,
                  headline=ds.w_progress_pct, overall_headline=ds.w_latest_gain)
    log.info("Window figure built (%d window(s)) for %s.", len(xlabels), pod_label or "selection")
    return fig


def save_figure(fig, output_dir: str, name: str) -> str:
    import datetime as _dt
    import os
    os.makedirs(output_dir, exist_ok=True)
    safe = "".join(ch if (ch.isalnum() or ch in "._-") else "_" for ch in name).strip("_")
    path = os.path.join(output_dir, "%s_%s.png"
                        % (safe, _dt.datetime.now().strftime("%Y%m%d_%H%M%S")))
    fig.savefig(path, dpi=130, bbox_inches="tight", facecolor="white")
    log.info("Figure written: %s", path)
    return path
