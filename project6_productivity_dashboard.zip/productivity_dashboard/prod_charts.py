"""
The dashboard figure.

Layout mirrors the agreed design: one wide **Overall Productivity Gain**
panel across the top, then the four metrics in a 2x2 grid beneath it.

Every metric panel carries three series and two badges:

    Actual (Current)    solid  -- 3-month rolling average
    Actual (Previous)   dotted -- the same rolling average a year earlier
    Aspiration          dashed -- the baseline improved along the target ramp

    top-left badge      progress against baseline, coloured by direction
    top-right badge     data confidence for the panel

matplotlib rather than a JavaScript charting library: it is present in
essentially every Python environment, renders inline in Jupyter without a
widget extension, and exports to PNG for sharing. The figure is returned
rather than shown, so the caller decides what to do with it.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Sequence

import matplotlib
matplotlib.use("Agg")                      # safe default; Jupyter overrides via %matplotlib inline
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator

from gl_settings import get_logger
from prod_metrics import METRIC_DEFS, LOWER_IS_BETTER

log = get_logger("prod.charts")

# palette shared with the report stylesheet
C_ACTUAL = "#1f3f7a"
C_PREV = "#8a94a6"
C_ASP = "#9aa5b1"
C_GAIN = "#1f3f7a"
C_GAIN_ASP = "#8a94a6"
C_GOOD_BG = "#e6f5ec"
C_GOOD_TX = "#0b6b36"
C_BAD_BG = "#fdecec"
C_BAD_TX = "#9b1c1c"
C_NEUTRAL_BG = "#eef1f5"
C_NEUTRAL_TX = "#33415c"
C_GRID = "#e6e8eb"

METRIC_UNITS = {"throughput": "", "cycle_time": " d",
                "merged_per_author": "", "lead_time": " h"}


def _fmt_month(mkey: str) -> str:
    y, m = mkey.split("-")
    return "%s %s" % (["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul",
                       "Aug", "Sep", "Oct", "Nov", "Dec"][int(m) - 1], y[2:])


def _badge(ax, text: str, good: Optional[bool], loc: str = "left"):
    bg, tx = ((C_GOOD_BG, C_GOOD_TX) if good else
              (C_BAD_BG, C_BAD_TX) if good is False else
              (C_NEUTRAL_BG, C_NEUTRAL_TX))
    ax.text(0.01 if loc == "left" else 0.99, 1.16, text,
            transform=ax.transAxes, ha="left" if loc == "left" else "right", va="top",
            fontsize=9, fontweight="bold", color=tx,
            bbox=dict(boxstyle="round,pad=0.35", facecolor=bg, edgecolor="none"))


def _thin_labels(months: Sequence[str], max_ticks: int = 12):
    step = max(1, len(months) // max_ticks)
    return [i for i in range(len(months)) if i % step == 0 or i == len(months) - 1]


def _plot_series(ax, months, series, colour, style, label, width=1.8, marker=None):
    xs = [i for i, v in enumerate(series) if v is not None]
    ys = [v for v in series if v is not None]
    if xs:
        ax.plot(xs, ys, style, color=colour, linewidth=width, label=label,
                marker=marker, markersize=3)
    return bool(xs)


def _annotate_last(ax, series, colour):
    for i in range(len(series) - 1, -1, -1):
        if series[i] is not None:
            ax.annotate("%.4g" % series[i], (i, series[i]), textcoords="offset points",
                        xytext=(4, 4), fontsize=8, color=colour, fontweight="bold")
            return


def _style(ax):
    ax.grid(True, axis="y", color=C_GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    for spine in ("top", "right"):
        ax.spines[spine].set_visible(False)
    for spine in ("left", "bottom"):
        ax.spines[spine].set_color(C_GRID)
    ax.tick_params(labelsize=7.5, colors="#555")


def build_dashboard_figure(ds, title_suffix: str = "", baseline_month: str = "",
                           figsize=(15.5, 9.5)):
    """Returns the full dashboard as a matplotlib Figure."""
    months = ds.months
    ticks = _thin_labels(months)
    labels = [_fmt_month(months[i]) for i in ticks]

    fig = plt.figure(figsize=figsize, facecolor="white")
    gs = fig.add_gridspec(3, 2, height_ratios=[1.25, 1, 1], hspace=0.72, wspace=0.16,
                          left=0.055, right=0.985, top=0.90, bottom=0.07)

    # ---------------- overall productivity gain ----------------
    ax0 = fig.add_subplot(gs[0, :])
    _plot_series(ax0, months, ds.gain_actual, C_GAIN, "-", "Productivity Gain Actual", 2.2, "o")
    _plot_series(ax0, months, ds.gain_aspiration, C_GAIN_ASP, "--", "Productivity Gain Aspiration", 1.6)
    ax0.axhline(0, color="#c8ccd4", linewidth=1)
    if baseline_month in months:
        bi = months.index(baseline_month)
        ax0.axvline(bi, color="#c8ccd4", linewidth=1, linestyle=":")
        ax0.annotate("baseline\n%s" % _fmt_month(baseline_month), (bi, 0),
                     textcoords="offset points", xytext=(6, -28), fontsize=7.5, color="#777")
    ax0.set_title("Overall Productivity Gain", fontsize=13, fontweight="bold", pad=26)
    ax0.set_ylabel("% vs baseline", fontsize=8.5)
    ax0.set_xticks(ticks); ax0.set_xticklabels(labels, rotation=45, ha="right")
    ax0.set_xlim(-0.5, len(months) - 0.5)
    if ax0.get_legend_handles_labels()[0]:      # nothing plotted -> no legend to draw
        ax0.legend(loc="upper left", fontsize=8, frameon=False, ncol=2,
                   bbox_to_anchor=(0.0, 1.19))
    _style(ax0)
    _annotate_last(ax0, ds.gain_actual, C_GAIN)

    gain = ds.latest_gain
    _badge(ax0, ("%.2f%%" % gain) if gain is not None else "n/a",
           (gain is not None and gain >= 0), loc="right")

    # ---------------- four metric panels ----------------
    positions = [(1, 0), (1, 1), (2, 0), (2, 1)]
    order = ["merged_per_author", "throughput", "lead_time", "cycle_time"]
    for (r, c), metric in zip(positions, order):
        label = dict((a, l) for a, l, _x in METRIC_DEFS)[metric]
        ax = fig.add_subplot(gs[r, c])
        drew = False
        drew |= _plot_series(ax, months, ds.actual_rolling.get(metric, []),
                             C_ACTUAL, "-", "Actual (Current)", 2.0)
        drew |= _plot_series(ax, months, ds.previous_rolling.get(metric, []),
                             C_PREV, ":", "Actual (Previous)", 1.5)
        drew |= _plot_series(ax, months, ds.aspiration.get(metric, []),
                             C_ASP, "--", "Aspiration", 1.4)

        unit = METRIC_UNITS.get(metric, "")
        sub = "lower is better" if LOWER_IS_BETTER[metric] else "higher is better"
        ax.set_title("%s\n%s (3-month rolling average)" % (label, sub),
                     fontsize=10.5, fontweight="bold", pad=24)
        ax.set_xticks(ticks); ax.set_xticklabels(labels, rotation=45, ha="right")
        ax.set_xlim(-0.5, len(months) - 0.5)
        ax.yaxis.set_major_locator(MaxNLocator(nbins=5))
        if drew:
            ax.legend(loc="upper left", fontsize=7, frameon=False, ncol=3,
                      bbox_to_anchor=(0.0, 1.20))
        _style(ax)
        _annotate_last(ax, ds.actual_rolling.get(metric, []), C_ACTUAL)

        prog = ds.progress_pct.get(metric)
        _badge(ax, ("%.2f%%" % prog) if prog is not None else "n/a",
               (prog is not None and prog >= 0), loc="left")
        _badge(ax, "%.0f%% data" % ds.data_confidence, None, loc="right")

        if not drew:
            ax.text(0.5, 0.5, "No data for this selection", transform=ax.transAxes,
                    ha="center", va="center", fontsize=10, color="#999")

    head = "Productivity Dashboard"
    if title_suffix:
        head += "  \u2014  " + title_suffix
    fig.suptitle(head, fontsize=15, fontweight="bold", y=0.975)
    fig.text(0.055, 0.925,
             "Baseline %s   |   %d month(s) %s to %s   |   Pods: %s"
             % (_fmt_month(baseline_month) if baseline_month else "n/a",
                len(months), _fmt_month(months[0]), _fmt_month(months[-1]),
                ", ".join(ds.pods) if ds.pods else "none"),
             fontsize=8.5, color="#666")
    log.info("Dashboard figure built for %d month(s), %d pod(s).", len(months), len(ds.pods))
    return fig


def save_dashboard(fig, output_dir: str, name: str = "productivity_dashboard") -> str:
    import datetime as _dt
    import os
    os.makedirs(output_dir, exist_ok=True)
    safe = "".join(ch if (ch.isalnum() or ch in "._-") else "_" for ch in name).strip("_")
    path = os.path.join(output_dir, "%s_%s.png"
                        % (safe, _dt.datetime.now().strftime("%Y%m%d_%H%M%S")))
    fig.savefig(path, dpi=130, bbox_inches="tight", facecolor="white")
    log.info("Dashboard image written: %s", path)
    return path
