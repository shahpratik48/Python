"""
The dashboard UI: cascading multi-select filters beside the charts.

Two design points worth knowing:

**Fetch once, filter many.** Pulling ~21 months of issues and merge requests
for every pod takes real time against GitLab. `DashboardApp.fetch()` does
that ONCE and caches the per-pod series; every filter change afterwards is
arithmetic over cached numbers, so the charts redraw instantly. Without that
split the dropdowns would be unusable.

**Widgets are optional.** If `ipywidgets` is available you get the live
cascading UI. If it is not -- a locked-down kernel, a plain console -- the
same object still works through `render(...)`, so the dashboard degrades to
a scripted call instead of failing outright.

Filters cascade downward only: choosing a division narrows the subdivisions
below it, and so on. Selecting nothing at a level means "all", which is what
a dashboard filter is normally expected to do.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Sequence

from gl_settings import get_logger
from prod_charts import build_dashboard_figure, save_dashboard
from prod_metrics import PodSeries, build_dashboard_series, collect_pod_series, month_range
from prod_org import LEVELS, Org, load_org

log = get_logger("prod.ui")

try:
    import ipywidgets as widgets
    from IPython.display import clear_output, display
    HAVE_WIDGETS = True
except ImportError:                                   # pragma: no cover
    widgets = None
    HAVE_WIDGETS = False


class DashboardApp:
    def __init__(self, settings, org: Optional[Org] = None,
                 start_month: str = "2024-11", end_month: str = "2026-07",
                 rolling_window: int = 3, output_dir: str = "."):
        self.settings = settings
        self.org = org or load_org()
        self.months = month_range(start_month, end_month)
        self.window = rolling_window
        self.output_dir = output_dir
        self.cache: Dict[str, PodSeries] = {}
        self.last_figure = None
        self.last_series = None
        log.info("Dashboard covering %d month(s), %s to %s; baseline %s.",
                 len(self.months), self.months[0], self.months[-1],
                 self.org.aspiration.baseline_month)

    # ------------------------------------------------------------- data
    def fetch(self, pod_keys: Optional[Sequence[str]] = None, force: bool = False,
              progress=None) -> Dict[str, PodSeries]:
        """Pulls and caches the monthly series per pod. Safe to call again --
        already-cached pods are skipped unless `force`."""
        keys = list(pod_keys or self.org.all_pod_keys)
        todo = [k for k in keys if force or k not in self.cache]
        if not todo:
            log.info("All %d pod(s) already cached -- nothing to fetch.", len(keys))
            return self.cache

        for i, key in enumerate(todo, start=1):
            msg = "Fetching %d/%d: %s" % (i, len(todo), key)
            log.info(msg)
            if progress:
                progress(msg)
            try:
                self.cache[key] = collect_pod_series(self.settings, key, self.months)
            except Exception as e:
                # one unreachable pod must not cost the others their data
                log.exception("Fetch FAILED for pod '%s' -- it will be missing from the "
                              "dashboard until the problem is fixed.", key)
                if progress:
                    progress("  FAILED %s: %s" % (key, e))
        log.info("Cache now holds %d pod(s).", len(self.cache))
        return self.cache

    # ------------------------------------------------------------- render
    def render(self, selection: Optional[Dict[str, Sequence[str]]] = None,
               save: bool = False, show: bool = True):
        """Builds the figure for a filter selection, entirely from cache."""
        selection = selection or {}
        pod_keys = self.org.resolve_pods(selection)
        series = [self.cache[k] for k in pod_keys if k in self.cache]
        missing = [k for k in pod_keys if k not in self.cache]
        if missing:
            log.warning("Not cached (call fetch() first): %s", ", ".join(missing))

        ds = build_dashboard_series(series, self.months,
                                    self.org.aspiration.baseline_month,
                                    self.org.aspiration.target_gain_pct,
                                    self.org.aspiration.target_months,
                                    window=self.window)
        pods_label = ", ".join(ds.pods) if ds.pods else "no pods selected"
        fig = build_dashboard_figure(ds, pods_label, self.org.aspiration.baseline_month)
        self.last_figure, self.last_series = fig, ds

        path = save_dashboard(fig, self.output_dir,
                              "productivity_dashboard") if save else None
        if show:
            try:
                from IPython.display import display as _d
                _d(fig)
            except Exception:
                pass
        return fig, ds, path

    # ------------------------------------------------------------- widgets
    def show(self, width: str = "320px"):
        """The interactive UI: filters on the left, charts on the right."""
        if not HAVE_WIDGETS:
            raise RuntimeError(
                "ipywidgets is not installed, so the interactive filters are unavailable. "
                "The dashboard still works without them -- call "
                "app.render({'pod': ['Insights']}) with whatever selection you want, or "
                "install ipywidgets to get the dropdowns.")

        titles = {"division": "Select Division", "subdivision": "Select Subdivision",
                  "stream": "Select Stream", "crew": "Select Crew", "pod": "Select Pod"}
        self._boxes = {}
        rows = []
        for lv in LEVELS:
            box = widgets.SelectMultiple(
                options=self.org.options(lv), value=(), rows=4,
                layout=widgets.Layout(width=width))
            box.observe(self._on_change, names="value")
            self._boxes[lv] = box
            rows.append(widgets.VBox([
                widgets.HTML("<b style='font-size:13px'>%s</b>"
                             "<div style='color:#777;font-size:11px'>none selected = all</div>"
                             % titles[lv]),
                box]))

        self._status = widgets.HTML("")
        refetch = widgets.Button(description="Re-fetch data", icon="refresh",
                                 layout=widgets.Layout(width=width))
        refetch.on_click(self._on_refetch)
        save_btn = widgets.Button(description="Save PNG", icon="download",
                                  layout=widgets.Layout(width=width))
        save_btn.on_click(self._on_save)

        left = widgets.VBox(rows + [refetch, save_btn, self._status],
                            layout=widgets.Layout(padding="6px", border="1px solid #e6e8eb"))
        self._out = widgets.Output()
        display(widgets.HBox([left, self._out]))
        self._redraw()

    # ------------------------------------------------------------- internals
    def _selection(self) -> Dict[str, List[str]]:
        return {lv: list(self._boxes[lv].value) for lv in LEVELS}

    def _on_change(self, change):
        """Repopulates the levels BELOW the one that changed, then redraws.

        Options are recomputed downward only, and any selection that is no
        longer valid is dropped -- otherwise a stale choice from a previous
        division would silently filter everything out.
        """
        changed = next((lv for lv in LEVELS if self._boxes[lv] is change["owner"]), None)
        if changed is None:
            return
        sel = self._selection()
        for lv in LEVELS[LEVELS.index(changed) + 1:]:
            box = self._boxes[lv]
            opts = self.org.options(lv, sel)
            keep = tuple(v for v in box.value if v in opts)
            box.unobserve(self._on_change, names="value")
            box.options = opts
            box.value = keep
            box.observe(self._on_change, names="value")
            sel[lv] = list(keep)
        self._redraw()

    def _redraw(self):
        sel = self._selection()
        pods = self.org.resolve_pods(sel)
        uncached = [p for p in pods if p not in self.cache]
        self._status.value = (
            "<div style='font-size:11px;color:#555;padding-top:6px'>%d pod(s) selected%s</div>"
            % (len(pods), (" &mdash; %d not fetched yet" % len(uncached)) if uncached else ""))
        with self._out:
            clear_output(wait=True)
            if not pods:
                print("No pods match this selection.")
                return
            self.render(sel, save=False, show=True)

    def _on_refetch(self, _btn):
        with self._out:
            clear_output(wait=True)
            print("Fetching from GitLab...")
            self.fetch(self.org.resolve_pods(self._selection()), force=True, progress=print)
        self._redraw()

    def _on_save(self, _btn):
        if self.last_figure is None:
            return
        path = save_dashboard(self.last_figure, self.output_dir, "productivity_dashboard")
        self._status.value = ("<div style='font-size:11px;color:#0b6b36;padding-top:6px'>"
                              "Saved %s</div>" % path.split("/")[-1])
