"""
The time series behind the dashboard.

Four metrics per pod per month, computed exactly as in the monthly report
project -- the same collectors, so the dashboard and the reports can never
disagree:

    Issue Throughput          closed issues
    Issue Cycle Time (Days)   avg elapsed business days, in progress -> closed
    Merged MRs per Author     merged MRs / distinct authors
    Lead Time (Hrs.)          avg elapsed hours, first file touched -> merged

On top of that, three things the dashboard needs:

* **3-month rolling average.** The charts plot a rolling mean rather than
  raw monthly points. Monthly figures for a single pod are small enough to
  swing wildly on one late ticket, and a trend line is what is being read
  here, not any individual month.

* **Actual (Previous).** The same metric twelve months earlier, drawn as the
  dotted comparison series. This is why history has to start in Nov 2024:
  the earliest month on the chart (Nov 2025, the baseline) needs Nov 2024 to
  compare against.

* **Productivity gain.** One number combining all four metrics against the
  baseline month. Throughput and MRs-per-author are higher-is-better; Cycle
  Time and Lead Time are lower-is-better, so their sign is flipped before
  averaging. Without that inversion a slowdown would read as an improvement.

Fetching is deliberately separated from filtering: `collect_pod_series`
hits GitLab once per pod and everything after that is arithmetic on cached
numbers, so moving the dropdowns re-renders instantly instead of re-querying.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Sequence, Tuple

from gl_metrics import collect_issue_metrics, collect_mr_metrics, month_key
from gl_settings import GitLabSettings, PODS_BY_KEY, get_logger

log = get_logger("prod.metrics")

# (attribute, label, lower_is_better)
METRIC_DEFS = [
    ("throughput", "GitLab Issue Throughput", False),
    ("cycle_time", "GitLab Issue Cycle Time", True),
    ("merged_per_author", "Merge requests", False),
    ("lead_time", "Merge request Lead Time", True),
]
METRIC_KEYS = [m[0] for m in METRIC_DEFS]
LOWER_IS_BETTER = {a: low for a, _l, low in METRIC_DEFS}


# ------------------------------------------------------------------ months
def month_range(start: str, end: str) -> List[str]:
    """Inclusive list of YYYY-MM from `start` to `end`."""
    y, m = (int(x) for x in start.split("-"))
    ey, em = (int(x) for x in end.split("-"))
    out = []
    while (y, m) <= (ey, em):
        out.append("%04d-%02d" % (y, m))
        m += 1
        if m > 12:
            y, m = y + 1, 1
    return out


def month_start(mkey: str) -> datetime:
    return datetime.strptime(mkey + "-01", "%Y-%m-%d").replace(tzinfo=timezone.utc)


def shift_months(mkey: str, delta: int) -> str:
    y, m = (int(x) for x in mkey.split("-"))
    total = y * 12 + (m - 1) + delta
    return "%04d-%02d" % (total // 12, total % 12 + 1)


# ------------------------------------------------------------------ models
@dataclass
class PodSeries:
    """Raw monthly values for one pod, before any aggregation."""
    pod_key: str
    pod_name: str
    months: List[str]
    throughput: Dict[str, float] = field(default_factory=dict)
    cycle_time: Dict[str, Optional[float]] = field(default_factory=dict)
    merged_per_author: Dict[str, Optional[float]] = field(default_factory=dict)
    lead_time: Dict[str, Optional[float]] = field(default_factory=dict)
    # kept so aggregation across pods can weight correctly
    merged_count: Dict[str, float] = field(default_factory=dict)
    author_count: Dict[str, float] = field(default_factory=dict)
    measured_issues: Dict[str, float] = field(default_factory=dict)
    measured_mrs: Dict[str, float] = field(default_factory=dict)

    def get(self, metric: str) -> Dict[str, Optional[float]]:
        return getattr(self, metric)


@dataclass
class DashboardSeries:
    """Everything the charts draw, for the current filter selection."""
    months: List[str]
    actual: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    actual_rolling: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    previous_rolling: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    aspiration: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    baseline: Dict[str, Optional[float]] = field(default_factory=dict)
    progress_pct: Dict[str, Optional[float]] = field(default_factory=dict)
    gain_actual: List[Optional[float]] = field(default_factory=list)
    gain_aspiration: List[Optional[float]] = field(default_factory=list)
    latest_gain: Optional[float] = None
    data_confidence: float = 0.0
    pods: List[str] = field(default_factory=list)


# ------------------------------------------------------------------ fetch
def collect_pod_series(settings_template, pod_key: str, months: List[str], client=None) -> PodSeries:
    """One GitLab pass for one pod over the whole history window."""
    pod = PODS_BY_KEY[pod_key]
    s = GitLabSettings(pod=pod)
    s.gitlab_token = settings_template.gitlab_token
    s.gitlab_url = settings_template.gitlab_url
    s.in_progress_labels = settings_template.in_progress_labels

    if client is None:
        from gl_client import GitLabClient
        client = GitLabClient(s)

    earliest = month_start(months[0])
    log.info("Collecting %s: %d month(s) from %s", pod.name, len(months), months[0])
    _im, isum = collect_issue_metrics(client, s, months, earliest)
    _mm, msum = collect_mr_metrics(client, s, months, earliest)

    ps = PodSeries(pod_key=pod_key, pod_name=pod.name, months=list(months))
    for m in months:
        i = isum.get(m)
        r = msum.get(m)
        merged = float(r.merged_count) if r else 0.0
        authors = float(len(r.per_author)) if r else 0.0
        ps.throughput[m] = float(i.closed_count) if i else 0.0
        ps.cycle_time[m] = i.avg_business_days if i else None
        ps.lead_time[m] = r.avg_hours if r else None
        ps.merged_per_author[m] = (round(merged / authors, 2) if authors else None)
        ps.merged_count[m] = merged
        ps.author_count[m] = authors
        ps.measured_issues[m] = float(i.measured_count) if i else 0.0
        ps.measured_mrs[m] = float(r.measured_count) if r else 0.0
    return ps


# ------------------------------------------------------------------ maths
def rolling_average(values: Sequence[Optional[float]], window: int = 3) -> List[Optional[float]]:
    """Trailing mean over `window` months, ignoring gaps.

    A month with no data contributes nothing rather than counting as zero --
    treating an unreported month as a zero would drag the average down and
    invent a decline that never happened.
    """
    out: List[Optional[float]] = []
    for i in range(len(values)):
        window_vals = [v for v in values[max(0, i - window + 1): i + 1] if v is not None]
        out.append(round(sum(window_vals) / len(window_vals), 2) if window_vals else None)
    return out


def _aggregate(pod_series: List[PodSeries], months: List[str]) -> Dict[str, List[Optional[float]]]:
    """Combines pods into one series per metric.

    Counts add up. Averages must NOT be averaged again -- a pod that closed
    two issues would otherwise pull the mean as hard as one that closed
    fifty. Cycle time and lead time are therefore weighted by how many items
    each pod actually measured, and merged-MRs-per-author is recomputed from
    total merges over total authors.
    """
    agg: Dict[str, List[Optional[float]]] = {k: [] for k in METRIC_KEYS}
    for m in months:
        agg["throughput"].append(sum(p.throughput.get(m, 0.0) for p in pod_series))

        num = sum((p.cycle_time.get(m) or 0.0) * p.measured_issues.get(m, 0.0)
                  for p in pod_series if p.cycle_time.get(m) is not None)
        den = sum(p.measured_issues.get(m, 0.0) for p in pod_series if p.cycle_time.get(m) is not None)
        agg["cycle_time"].append(round(num / den, 2) if den else None)

        num = sum((p.lead_time.get(m) or 0.0) * p.measured_mrs.get(m, 0.0)
                  for p in pod_series if p.lead_time.get(m) is not None)
        den = sum(p.measured_mrs.get(m, 0.0) for p in pod_series if p.lead_time.get(m) is not None)
        agg["lead_time"].append(round(num / den, 2) if den else None)

        merged = sum(p.merged_count.get(m, 0.0) for p in pod_series)
        authors = sum(p.author_count.get(m, 0.0) for p in pod_series)
        agg["merged_per_author"].append(round(merged / authors, 2) if authors else None)
    return agg


def _gain(metric: str, value: Optional[float], baseline: Optional[float]) -> Optional[float]:
    """Percentage improvement against baseline, sign-corrected per metric."""
    if value is None or baseline in (None, 0):
        return None
    raw = (value - baseline) / abs(baseline) * 100.0
    return round(-raw if LOWER_IS_BETTER[metric] else raw, 2)


def build_dashboard_series(pod_series: List[PodSeries], months: List[str],
                           baseline_month: str, target_gain_pct: float = 20.0,
                           target_months: int = 14, window: int = 3) -> DashboardSeries:
    ds = DashboardSeries(months=list(months), pods=[p.pod_name for p in pod_series])
    if not pod_series:
        log.warning("No pods selected -- nothing to plot.")
        return ds

    agg = _aggregate(pod_series, months)
    idx = {m: i for i, m in enumerate(months)}

    for metric in METRIC_KEYS:
        vals = agg[metric]
        ds.actual[metric] = vals
        roll = rolling_average(vals, window)
        ds.actual_rolling[metric] = roll

        # previous = the rolling value twelve months earlier
        prev = []
        for m in months:
            src = shift_months(m, -12)
            prev.append(roll[idx[src]] if src in idx else None)
        ds.previous_rolling[metric] = prev

        base = roll[idx[baseline_month]] if baseline_month in idx else None
        ds.baseline[metric] = base

        # aspiration: the baseline improved by the target ramp, expressed in
        # the metric's own units so it can be drawn on the same axis
        asp = []
        for m in months:
            step = _ramp_pct(m, baseline_month, target_gain_pct, target_months)
            # no baseline, or a month before the baseline -> no aspiration to draw
            if base is None or step is None:
                asp.append(None)
                continue
            factor = (1 - step / 100.0) if LOWER_IS_BETTER[metric] else (1 + step / 100.0)
            asp.append(round(base * factor, 2))
        ds.aspiration[metric] = asp

        latest = next((v for v in reversed(roll) if v is not None), None)
        ds.progress_pct[metric] = _gain(metric, latest, base)

    # overall productivity gain: mean of the four metric gains, per month
    for i, m in enumerate(months):
        gains = [_gain(k, ds.actual_rolling[k][i], ds.baseline[k]) for k in METRIC_KEYS]
        gains = [g for g in gains if g is not None]
        ds.gain_actual.append(round(sum(gains) / len(gains), 2) if gains else None)
        ds.gain_aspiration.append(_ramp_pct(m, baseline_month, target_gain_pct, target_months))
    ds.latest_gain = next((g for g in reversed(ds.gain_actual) if g is not None), None)

    # data confidence: share of month/metric cells that actually have a value
    cells = [v for k in METRIC_KEYS for v in ds.actual[k]]
    ds.data_confidence = round(100.0 * sum(1 for v in cells if v is not None) / len(cells), 1) \
        if cells else 0.0

    log.info("Series built for %d pod(s): latest gain %s%%, data confidence %.1f%%",
             len(pod_series), ds.latest_gain, ds.data_confidence)
    return ds


def _ramp_pct(mkey: str, baseline_month: str, target_gain_pct: float,
              target_months: int) -> Optional[float]:
    """The aspiration curve: 0% at the baseline, rising linearly to the
    target. Months before the baseline have no aspiration -- the ambition
    only starts once the reference point exists."""
    if target_months <= 0:
        return None
    y, m = (int(x) for x in mkey.split("-"))
    by, bm = (int(x) for x in baseline_month.split("-"))
    delta = (y * 12 + m) - (by * 12 + bm)
    if delta < 0:
        return None
    return round(min(delta / float(target_months), 1.0) * target_gain_pct, 2)
