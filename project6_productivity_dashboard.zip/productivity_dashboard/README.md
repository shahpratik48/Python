# Productivity Dashboard

Trend charts for four delivery metrics plus a combined productivity gain, with cascading
**Division → Subdivision → Stream → Crew → Pod** filters. Runs in Jupyter.

| | |
|---|---|
| **History** | Nov 2024 → Jul 2026 |
| **Baseline** | Nov 2025 |
| **Figures** | **two per pod** — monthly, and 3-month averages |

## Two figures per pod

| Figure | X axis | Series |
|---|---|---|
| **Monthly** | every month, Nov 24 → Jul 26 | actual + aspiration, per month |
| **3-month averages** | Nov 24–Jan 25, Dec 24–Feb 25, Jan 25–Mar 25, … | actual + aspiration, **both** averaged over each window |

Windows step one month at a time, so 21 months produce 19 windows. The aspiration is averaged over
the same window as the actual — smoothing only one of them would make the comparison meaningless.

Each pod is charted **on its own** by default. Pods differ enough in size that a blended line hides
what either is doing. Pass `per_pod=False` to combine a selection into one pair of figures.

## Series in every panel

| Series | Meaning | Style |
|---|---|---|
| **Actual (Previous)** | actual, **before** the baseline month | dotted, grey |
| **Actual (Current)** | actual, **from** the baseline onward | solid, blue |
| **Aspiration** | the target ramp from the baseline | dashed, red |

One actual series, drawn in two segments. The baseline month belongs to both so the segments join
rather than showing a break. This is why history starts in Nov 2024 — it is the *previous* run-up to
the Nov 2025 baseline.

## Layout

```
┌────────────────────────────────────────────────────────────┐
│              Overall Productivity Gain                     │
├──────────────────────────┬─────────────────────────────────┤
│  Merge requests          │  GitLab Issue Throughput        │
│  (merged MRs per author) │                                 │
├──────────────────────────┼─────────────────────────────────┤
│  Merge request Lead Time │  GitLab Issue Cycle Time        │
└──────────────────────────┴─────────────────────────────────┘
```

Filters sit to the left of the charts. The progress figure against baseline is folded **into each
panel title** rather than shown as a floating badge — that is what keeps it from colliding with the
legend, which an earlier version did.

## The four metrics

Computed by the **same collectors as the reporting project**, so the dashboard and the reports can
never disagree:

| Metric | Meaning | Direction |
|---|---|---|
| Issue Throughput | closed issues | higher is better |
| Issue Cycle Time | avg elapsed business days, in progress → closed | **lower** is better |
| Merged MRs per Author | merged MRs ÷ distinct authors | higher is better |
| Lead Time | avg elapsed hours, first file touched → merged | **lower** is better |

Cycle Time and Lead Time have their sign inverted before display and before being folded into the
overall gain — a falling cycle time reads as a **gain**. Without that inversion a slowdown would
show up as an improvement.

## Files

| File | Purpose |
|---|---|
| `org_config.json` | **Org hierarchy** — division/subdivision/stream/crew, and which pods sit under each crew. |
| `pods.json` | **Pod definitions** — each pod's issue URLs and MR URLs. Shared with the reporting project. |
| `prod_org.py` | Loads the hierarchy; cascading multi-select logic. |
| `prod_metrics.py` | Monthly series, 3-month rolling averages, baseline, aspiration, productivity gain. |
| `prod_charts.py` | The matplotlib dashboard figure. |
| `prod_ui.py` | Cascading filter UI, data cache, PNG export. |
| `run_productivity_dashboard.ipynb` | The notebook. |
| `gl_settings.py`, `gl_client.py`, `gl_metrics.py`, `gl_summary.py` | Reused unchanged from the reporting project — GitLab access and the metric calculations. |

---

# Configuration

Two files, with a deliberate split:

* **`pods.json`** — *what a pod is*: its issue URLs and MR URLs.
* **`org_config.json`** — *where a pod sits*: division → subdivision → stream → crew.

A pod's URLs therefore live in exactly one place. Attaching it to the org tree never means repeating
them.

## Step 1 — define the pod in `pods.json`

```json
{
  "pods": [
    {
      "name": "Data Platform",
      "key": "data_platform",
      "issue_projects": [
        "ubs/gwma/.../dp-board",
        "ubs/gwma/.../dp-intake"
      ],
      "mr_repos": {
        "ingest": "ubs/gwma/.../dp-ingest",
        "api":    "ubs/gwma/.../dp-api"
      }
    }
  ]
}
```

| Field | Required | Notes |
|---|---|---|
| `name` | yes | Display name, shown in the Pod filter. |
| `key` | no | Id used by `org_config.json`. Auto-derived from `name` if omitted (`Data Platform` → `data_platform`). Must be unique. |
| `issue_projects` | yes | **One or more** projects whose issues belong to the pod. Pooled across all of them. Accepts a string or a list. |
| `mr_repos` | yes | **One or more** repositories whose merge requests belong to the pod. Accepts `{"Label": "path"}` or a bare list (label taken from the last path segment). |

Full `https://` URLs are accepted anywhere a path is and are normalised automatically, so you can
paste straight from the browser address bar.

## Step 2 — place the pod in `org_config.json`

Add its **key** to the `pods` list of the crew it belongs to:

```json
{
  "aspiration": {
    "baseline_month": "2025-11",
    "target_gain_pct": 20.0,
    "target_months": 14
  },
  "divisions": [
    {
      "name": "Global Wealth Management Americas",
      "subdivisions": [
        {
          "name": "Global Wealth Management Americas",
          "streams": [
            {
              "name": "Data Analytics and Foundational Platforms",
              "crews": [
                { "name": "STAAT Data Science", "pods": ["insights", "conv_insights"] },
                { "name": "Data Engineering",   "pods": ["data_platform"] }
              ]
            }
          ]
        }
      ]
    }
  ]
}
```

Every level accepts multiple children — add divisions, subdivisions, streams and crews the same way.

## Step 3 — re-run the notebook

Cell 1 (*Check the org configuration*) prints the resulting hierarchy. A pod key referenced in
`org_config.json` with no entry in `pods.json` is reported there and skipped, rather than surfacing
later as a mysteriously empty chart.

## Adding a whole new branch of the org

```json
{
  "name": "Another Division",
  "subdivisions": [
    { "name": "Sub A",
      "streams": [
        { "name": "Stream A",
          "crews": [ { "name": "Crew A", "pods": ["some_pod_key"] } ] } ] }
  ]
}
```

The filters populate themselves from whatever is in the file — nothing in the Python names a
division, stream or crew.

## Tuning the aspiration line

In `org_config.json`:

| Setting | Meaning |
|---|---|
| `baseline_month` | The reference month everything is measured against (`YYYY-MM`). |
| `target_gain_pct` | Where the aspiration line should reach. |
| `target_months` | How many months it takes to get there. |

The line ramps linearly from 0% at `baseline_month` to `target_gain_pct` after `target_months`, then
flattens. Months before the baseline have no aspiration drawn.

## Changing the history window

In the notebook's `DashboardApp(...)` call:

```python
app = DashboardApp(settings, org=org,
                   start_month="2024-11",   # keep >= 12 months before the baseline
                   end_month="2026-07",
                   rolling_window=3)
```

`rolling_window` sets the span used by the 3-month-average figure. `start_month` should sit before
`baseline_month`, since everything before the baseline is what the *Actual (Previous)* segment draws.

---

## Things worth knowing

**Fetch once, filter many.** Pulling 21 months for every pod takes real time. `app.fetch()` does it
once and caches per pod; every filter change afterwards is arithmetic over cached numbers, so the
charts redraw instantly. `Re-fetch data` forces a refresh when you want current numbers.

**Aggregating pods** (only when `per_pod=False`). Counts are summed. Averages are **not** averaged again — cycle time and lead
time are weighted by how many items each pod actually measured, and merged-MRs-per-author is
recomputed as total merges ÷ total authors. Otherwise a pod that closed two issues would sway the
mean as much as one that closed fifty.

**Empty filter = all.** Selecting nothing at a level means "all of them", which is what a dashboard
filter is normally expected to do.

**Gaps are not zeros.** A month with no data is skipped in the rolling average rather than counted as
zero, which would invent a decline that never happened.

**Widgets are optional.** With `ipywidgets` you get the live cascading filters. Without it,
`app.render({...})` produces exactly the same chart from a scripted selection, so the dashboard
degrades rather than failing.

**One pod failing doesn't stop the rest.** A pod that can't be fetched is logged and skipped; the
others still load.

## Validation performed

Tested with synthetic 21-month trends across two pods:

- **Window boundaries** — 21 months produce 19 windows, the first three being `Nov 24-Jan 25`,
  `Dec 24-Feb 25`, `Jan 25-Mar 25`, exactly as specified.
- **Window averages ignore gaps** — a missing month is skipped, not counted as zero.
- **Baseline split** — before the baseline only *Previous* carries values, after it only *Current*,
  and the baseline month itself is present in both so the lines join.
- **No overlapping text** — every figure-level text, panel title and legend was measured after render
  and checked pairwise for intersecting bounding boxes: 13 elements per figure, **0 overlaps**.
- **Two figures per pod** — two pods produced four PNGs, named `<Pod>_monthly_*` and
  `<Pod>_3month_avg_*`.
- **Sign inversion** — cycle time 10 → 8 reads `+20%` (a gain); throughput 100 → 80 reads `-20%` (a loss).
- **Aspiration** — blank before the baseline, `0%` at it, `+1.43%` one month later, capping at `+20%`
  after 14 months.
- **Weighted aggregation** — two pods with cycle times 8.31 and 9.02 combined to 8.60, not the
  mean-of-means 8.66, confirming volume weighting.
- **Filters** — pod, division and combined selections each charted the expected pods; a non-existent
  division produced an empty chart with a clear message and no warnings.
