"""
Organisation hierarchy and the cascading filters that sit beside the charts.

    Division > Subdivision > Stream > Crew > Pod

Pods are referenced by their key from `pods.json`, so a pod's issue URLs and
MR URLs are defined in exactly one place and merely attached to the tree
here. Adding a pod to the dashboard never means repeating its URLs.

Every level supports MULTI-SELECT, and each level narrows the ones below it:
choosing a division populates only the subdivisions under it, and so on down
to pods. Selecting nothing at a level means "all of them" rather than "none",
which is what people expect from a dashboard filter -- an empty filter should
show everything, not an empty chart.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence

from gl_settings import PODS_BY_KEY, get_logger

log = get_logger("prod.org")

LEVELS = ["division", "subdivision", "stream", "crew", "pod"]
ORG_FILE = os.getenv("PROD_ORG_FILE",
                     os.path.join(os.path.dirname(os.path.abspath(__file__)), "org_config.json"))


@dataclass
class OrgNode:
    """One leaf path through the hierarchy: a pod in its full org context."""
    division: str
    subdivision: str
    stream: str
    crew: str
    pod_key: str
    pod_name: str = ""

    def value(self, level: str) -> str:
        return {"division": self.division, "subdivision": self.subdivision,
                "stream": self.stream, "crew": self.crew, "pod": self.pod_name}[level]


@dataclass
class Aspiration:
    baseline_month: str = "2025-11"
    target_gain_pct: float = 20.0
    target_months: int = 14


@dataclass
class Org:
    nodes: List[OrgNode] = field(default_factory=list)
    aspiration: Aspiration = field(default_factory=Aspiration)
    missing_pods: List[str] = field(default_factory=list)

    # ---------------------------------------------------------------- options
    def options(self, level: str, selection: Optional[Dict[str, Sequence[str]]] = None) -> List[str]:
        """Distinct values available at `level`, narrowed by whatever is
        selected at the levels ABOVE it. Levels below have no effect, so the
        dropdowns cascade downward only."""
        selection = selection or {}
        idx = LEVELS.index(level)
        out = []
        for n in self.nodes:
            if all(self._matches(n, lv, selection.get(lv)) for lv in LEVELS[:idx]):
                v = n.value(level)
                if v not in out:
                    out.append(v)
        return out

    @staticmethod
    def _matches(node: OrgNode, level: str, chosen: Optional[Sequence[str]]) -> bool:
        # empty selection means "all", not "none"
        return True if not chosen else node.value(level) in set(chosen)

    def resolve_pods(self, selection: Optional[Dict[str, Sequence[str]]] = None) -> List[str]:
        """Pod keys matching the current selection, in configuration order."""
        selection = selection or {}
        keys = []
        for n in self.nodes:
            if all(self._matches(n, lv, selection.get(lv)) for lv in LEVELS):
                if n.pod_key not in keys:
                    keys.append(n.pod_key)
        return keys

    def describe(self, selection: Optional[Dict[str, Sequence[str]]] = None) -> str:
        selection = selection or {}
        parts = []
        for lv in LEVELS:
            chosen = selection.get(lv)
            parts.append("%s: %s" % (lv.capitalize(), ", ".join(chosen) if chosen else "All"))
        return " | ".join(parts)

    @property
    def all_pod_keys(self) -> List[str]:
        out = []
        for n in self.nodes:
            if n.pod_key not in out:
                out.append(n.pod_key)
        return out


def load_org(path: Optional[str] = None) -> Org:
    """Flattens the nested org config into leaf paths.

    A pod key that has no matching entry in pods.json is recorded in
    `missing_pods` and skipped rather than crashing -- the rest of the
    dashboard still works, and the gap is reported plainly instead of
    surfacing later as a mysteriously empty chart.
    """
    target = path or ORG_FILE
    if not os.path.exists(target):
        raise FileNotFoundError(
            "Org config not found at %s. Copy org_config.json next to these scripts, or point "
            "PROD_ORG_FILE at it." % target)

    with open(target, encoding="utf-8") as fh:
        raw = json.load(fh)

    asp_raw = raw.get("aspiration") or {}
    asp = Aspiration(
        baseline_month=str(asp_raw.get("baseline_month", "2025-11")),
        target_gain_pct=float(asp_raw.get("target_gain_pct", 20.0)),
        target_months=int(asp_raw.get("target_months", 14)))

    nodes, missing = [], []
    for div in raw.get("divisions", []):
        dname = str(div.get("name", "")).strip()
        for sub in div.get("subdivisions", []):
            sname = str(sub.get("name", "")).strip()
            for st in sub.get("streams", []):
                stname = str(st.get("name", "")).strip()
                for crew in st.get("crews", []):
                    cname = str(crew.get("name", "")).strip()
                    for key in crew.get("pods", []):
                        pod = PODS_BY_KEY.get(str(key))
                        if pod is None:
                            missing.append(str(key))
                            continue
                        nodes.append(OrgNode(division=dname, subdivision=sname, stream=stname,
                                             crew=cname, pod_key=pod.key, pod_name=pod.name))

    if not nodes:
        raise ValueError(
            "No usable pods in %s. Every pod key listed there must also exist in pods.json "
            "(found keys: %s)." % (target, ", ".join(sorted(PODS_BY_KEY)) or "none"))
    if missing:
        log.warning("Pod key(s) %s appear in %s but not in pods.json -- skipped. Define them in "
                    "pods.json or remove them from the org config.", sorted(set(missing)), target)

    log.info("Org loaded: %d leaf path(s), %d distinct pod(s) -- %s",
             len(nodes), len({n.pod_key for n in nodes}),
             ", ".join(sorted({n.pod_name for n in nodes})))
    return Org(nodes=nodes, aspiration=asp, missing_pods=sorted(set(missing)))
