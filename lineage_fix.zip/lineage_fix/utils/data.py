from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.models import Variable
import pandas as pd

connect = Variable.get("GP_Dash_connect")
pg_hook = PostgresHook.get_hook(connect)
ikg_schema_name = Variable.get("IKG_DASHBOARD_SCHEMA")


# ─────────────────────────────────────────────────────────────────────────────
# Existing functions (unchanged)
# ─────────────────────────────────────────────────────────────────────────────

def get_metadata() -> pd.DataFrame:
    sql = f"select * from {ikg_schema_name}.ikg_dictionary_metadata_auto_refresh;"
    return pg_hook.get_pandas_df(sql)


def get_metadata_rules() -> pd.DataFrame:
    sql = f"""select r.*, a.time_horizon_in_weeks, a.insight_eval_type, a.metric_1
            from {ikg_schema_name}.odm_rule_metadata_auto_refresh r
            left join {ikg_schema_name}.attribution_insights_metrics_metadata_ikg a
            on r.insight_type = a.insight_type;"""
    return pg_hook.get_pandas_df(sql)


def get_business_descriptions() -> pd.DataFrame:
    sql = f"select * from {ikg_schema_name}.ikg_attribute_description;"
    return pg_hook.get_pandas_df(sql)


def get_profile_tables() -> pd.DataFrame:
    sql = f"select distinct target_table from {ikg_schema_name}.ikg_table_lineage_metadata_auto_refresh where target_table like '%_profile_curr_ikg';"
    return pg_hook.get_pandas_df(sql)


def get_profile_table_lineage(profile_table) -> pd.DataFrame:
    sql = f"select * from {ikg_schema_name}.ikg_lineage_{profile_table} order by order_index desc;"
    return pg_hook.get_pandas_df(sql)


def get_insight_details() -> pd.DataFrame:
    sql = f"select insight_type, target_type, profile_table, insight_type_label, description, sample_narrative from {ikg_schema_name}.insights_dashboard_details;"
    return pg_hook.get_pandas_df(sql)


def get_metadata_transformed() -> pd.DataFrame:
    df_metadata = get_metadata()
    df2_descriptions = get_business_descriptions()
    df = pd.merge(df_metadata, df2_descriptions, on=["table_name", "column_name"], how="left")
    df.rename(columns={
        "is_cid": "Contains CID", "column_name": "Column Name", "table_name": "Table Name",
        "data_type": "Data Type", "is_odm": "ODM Rule Impact", "is_nlg": "Narrative Impact",
        "description": "Description", "business_attribute_name": "Business Attribute Name",
    }, inplace=True)
    df["ODM Rule Impact"] = df["ODM Rule Impact"].map({"Y": "Yes", "N": "No"})
    df["Narrative Impact"] = df["Narrative Impact"].map({"Y": "Yes", "N": "No"})
    df["Contains CID"] = df["Contains CID"].map({"Y": "Yes", "": "No"})
    df["odm_insight_types"] = df["odm_insight_types"].fillna("None")
    df["nlg_insight_types"] = df["nlg_insight_types"].fillna("None")
    df["nlg_target_type"] = df["nlg_target_type"].fillna(df["odm_target_type"])
    df["nlg_target_type"] = df["nlg_target_type"].fillna("None")
    df["odm_target_type"] = df["odm_target_type"].fillna("None")
    return df


def get_rules_transformed() -> pd.DataFrame:
    df = get_metadata_rules()
    for c in ['metric_name', 'metric_type']:
        if c in df.columns:
            df[c] = df[c].astype(str).str.strip().str.strip("'").str.strip('"')
    df['is_active'] = df['is_active'].map({'Y': 'Yes', 'N': 'No'})
    df["time_horizon_in_weeks"] = df["time_horizon_in_weeks"].fillna("None").apply(
        lambda x: str(int(x)) if isinstance(x, (int, float)) and not pd.isna(x) else "None"
    )
    vary_cols = [c for c in ['rule_column', 'metric_1'] if c in df.columns]
    group_cols = [c for c in df.columns if c not in vary_cols]
    agg_dict = {c: lambda s: ', '.join(sorted(set(s.dropna().astype(str)))) for c in vary_cols}
    grouped = df.groupby(group_cols, dropna=False).agg(agg_dict).reset_index()
    return grouped


# ─────────────────────────────────────────────────────────────────────────────
# New: Column Lineage
# ─────────────────────────────────────────────────────────────────────────────

def get_all_target_columns() -> pd.DataFrame:
    sql = f"""
        SELECT DISTINCT target_column
        FROM {ikg_schema_name}.ikg_column_lineage_master_auto_refresh
        WHERE target_column IS NOT NULL AND TRIM(target_column) <> ''
        ORDER BY target_column;
    """
    return pg_hook.get_pandas_df(sql)


def get_tables_for_column(target_column: str) -> pd.DataFrame:
    safe = str(target_column).replace("'", "''")
    sql = f"""
        SELECT DISTINCT target_table
        FROM {ikg_schema_name}.ikg_column_lineage_master_auto_refresh
        WHERE target_column = '{safe}'
          AND target_table IS NOT NULL AND TRIM(target_table) <> ''
        ORDER BY target_table;
    """
    return pg_hook.get_pandas_df(sql)


def get_column_lineage_upstream(target_column: str, target_table: str) -> pd.DataFrame:
    """
    Upstream lineage using a single WITH RECURSIVE (required by Greenplum).
    Walks backwards: source → target, up to 6 hops.
    """
    sc = str(target_column).replace("'", "''")
    st = str(target_table).replace("'", "''")
    sql = f"""
        WITH RECURSIVE upstream AS (
            SELECT
                target_table, target_schema, target_column,
                source_table, source_schema, source_column,
                logic, process, path, web_url,
                sub_target_table, sub_target_schema, sql_process,
                0 AS depth
            FROM {ikg_schema_name}.ikg_column_lineage_master_auto_refresh
            WHERE target_table  = '{st}'
              AND target_column = '{sc}'

            UNION ALL

            SELECT
                cl.target_table, cl.target_schema, cl.target_column,
                cl.source_table, cl.source_schema, cl.source_column,
                cl.logic, cl.process, cl.path, cl.web_url,
                cl.sub_target_table, cl.sub_target_schema, cl.sql_process,
                u.depth + 1
            FROM {ikg_schema_name}.ikg_column_lineage_master_auto_refresh cl
            JOIN upstream u
              ON cl.target_table  = u.source_table
             AND cl.target_column = u.source_column
            WHERE u.depth < 6
        )
        SELECT DISTINCT * FROM upstream;
    """
    return pg_hook.get_pandas_df(sql)


def get_column_lineage_downstream(target_column: str, target_table: str) -> pd.DataFrame:
    """
    Downstream lineage using a single WITH RECURSIVE (required by Greenplum).
    Walks forwards: target → downstream consumers, up to 4 hops.
    """
    sc = str(target_column).replace("'", "''")
    st = str(target_table).replace("'", "''")
    sql = f"""
        WITH RECURSIVE downstream AS (
            SELECT
                target_table, target_schema, target_column,
                source_table, source_schema, source_column,
                logic, process, path, web_url,
                sub_target_table, sub_target_schema, sql_process,
                0 AS depth
            FROM {ikg_schema_name}.ikg_column_lineage_master_auto_refresh
            WHERE source_table  = '{st}'
              AND source_column = '{sc}'

            UNION ALL

            SELECT
                cl.target_table, cl.target_schema, cl.target_column,
                cl.source_table, cl.source_schema, cl.source_column,
                cl.logic, cl.process, cl.path, cl.web_url,
                cl.sub_target_table, cl.sub_target_schema, cl.sql_process,
                d.depth + 1
            FROM {ikg_schema_name}.ikg_column_lineage_master_auto_refresh cl
            JOIN downstream d
              ON cl.source_table  = d.target_table
             AND cl.source_column = d.target_column
            WHERE d.depth < 4
        )
        SELECT DISTINCT * FROM downstream;
    """
    return pg_hook.get_pandas_df(sql)


# ─────────────────────────────────────────────────────────────────────────────
# New: Insight Lineage
# ─────────────────────────────────────────────────────────────────────────────

def get_all_insight_types() -> pd.DataFrame:
    sql = f"""
        SELECT DISTINCT insight_type
        FROM {ikg_schema_name}.odm_rule_metadata_auto_refresh
        WHERE insight_type IS NOT NULL AND TRIM(insight_type) <> ''
        ORDER BY insight_type;
    """
    return pg_hook.get_pandas_df(sql)


def get_insight_rule_meta(insight_type: str) -> pd.DataFrame:
    safe = str(insight_type).replace("'", "''")
    sql = f"""
        SELECT *
        FROM {ikg_schema_name}.odm_rule_metadata_auto_refresh
        WHERE insight_type = '{safe}';
    """
    return pg_hook.get_pandas_df(sql)


def get_insight_column_lineage(insight_type: str) -> pd.DataFrame:
    """
    Upstream lineage for ALL rule_columns of an insight_type.

    Uses a SINGLE WITH RECURSIVE (Greenplum requirement — multi-CTE recursion
    with forward references is not supported).  The rule_cols subquery is
    inlined directly inside the anchor SELECT so no forward reference occurs.
    """
    safe = str(insight_type).replace("'", "''")
    sql = f"""
        WITH RECURSIVE upstream AS (

            -- ── Anchor: rows where the target column is a rule column ──────
            SELECT
                cl.target_table,
                cl.target_schema,
                cl.target_column,
                cl.source_table,
                cl.source_schema,
                cl.source_column,
                cl.logic,
                cl.process,
                cl.path,
                cl.web_url,
                cl.sub_target_table,
                cl.sub_target_schema,
                cl.sql_process,
                0 AS depth
            FROM {ikg_schema_name}.ikg_column_lineage_master_auto_refresh cl
            WHERE cl.target_column IN (
                SELECT DISTINCT rule_column
                FROM {ikg_schema_name}.odm_rule_metadata_auto_refresh
                WHERE insight_type = '{safe}'
                  AND rule_column IS NOT NULL
                  AND TRIM(rule_column) <> ''
            )

            UNION ALL

            -- ── Recursive: walk upstream ────────────────────────────────────
            SELECT
                cl.target_table,
                cl.target_schema,
                cl.target_column,
                cl.source_table,
                cl.source_schema,
                cl.source_column,
                cl.logic,
                cl.process,
                cl.path,
                cl.web_url,
                cl.sub_target_table,
                cl.sub_target_schema,
                cl.sql_process,
                u.depth + 1
            FROM {ikg_schema_name}.ikg_column_lineage_master_auto_refresh cl
            JOIN upstream u
              ON cl.target_table  = u.source_table
             AND cl.target_column = u.source_column
            WHERE u.depth < 5
        )
        SELECT DISTINCT
            u.*,
            CASE
                WHEN u.target_column IN (
                    SELECT DISTINCT rule_column
                    FROM {ikg_schema_name}.odm_rule_metadata_auto_refresh
                    WHERE insight_type = '{safe}'
                )
                THEN 'Y' ELSE 'N'
            END AS is_rule_col
        FROM upstream u;
    """
    return pg_hook.get_pandas_df(sql)
