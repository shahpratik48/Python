"""
insight_lineage_tab.py
──────────────────────
Dash tab: dropdown of insight_type values from ODM metadata, renders
per-rule-column upstream lineage graphs using vis-network style matching
the uploaded IKG Lineage Explorer HTML files.

Architecture mirrors table_lineage_er_tab.py:
  layout()               → dcc.Tab
  register_callbacks()   → Dash callbacks
  register_server_routes() → Flask route serving rendered HTML
"""
import json
import re
import urllib.parse
from pathlib import Path

import pandas as pd
from dash import Input, Output, dcc, html
from flask import request
from styles import metadata_dashboard_styles as mds
from utils.data import (
    get_all_insight_types,
    get_insight_column_lineage,
    get_insight_rule_meta,
)

# ── Schema → colour map ────────────────────────────────────────────────────
_RAW2COLOR = {
    "ikg_schema": "#1976d2", "sandbox_prj_smart_insights": "#1976d2",
    "sandbox_ikg_pre_prd": "#1976d2", "edw_input_schema": "#00897b",
    "core_wma_shared": "#00897b", "edw_view_input_schema": "#00897b",
    "ikg_vendor_schema": "#00897b", "core_wma_shared_masked": "#26a69a",
    "sandbox_wma_shared": "#388e3c", "sandbox_prj_ds_data": "#f4511e",
    "sandbox_prj_sbl": "#7b1fa2", "core_nlg": "#5c6bc0",
    "nlg_schema": "#5c6bc0", "core_model": "#6d4c41",
    "model_schema": "#6d4c41", "sandbox_prj_dsforoverdrive": "#0288d1",
    "core_in_shared": "#689f38", "ikg_clip_schema": "#689f38",
    "sandbox_prj_adhoc": "#e91e8c", "ikg_wealthx_schema": "#00838f",
    "sandbox_prj_rbat": "#9e7c0a", "_default": "#607d8b",
}
_LEGEND_DATA = [
    {"label": "ikg / sandbox",       "color": "#1976d2"},
    {"label": "core_wma_shared",     "color": "#00897b"},
    {"label": "sandbox_wma_shared",  "color": "#388e3c"},
    {"label": "core_nlg",            "color": "#5c6bc0"},
    {"label": "core_model",          "color": "#6d4c41"},
    {"label": "edw / source / temp", "color": "#607d8b"},
]


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _s(v) -> str:
    if v is None:
        return ""
    try:
        if pd.isna(v):
            return ""
    except Exception:
        pass
    s = str(v).strip()
    return "" if s.lower() in ("none", "nan") else s


# ─────────────────────────────────────────────────────────────────────────────
# Graph builder → ALL_GRAPHS format (one section per rule_column)
# ─────────────────────────────────────────────────────────────────────────────

def _build_all_graphs(insight_type: str) -> list:
    """
    Returns ALL_GRAPHS list with one entry per ODM rule_column.
    Each entry shows the full upstream lineage for that column.

    Uses BFS on the in-memory dataframe so each rule_column gets only its
    own relevant lineage chain (not all columns mixed together).
    """
    insight_type = _s(insight_type)
    if not insight_type:
        return []

    df      = get_insight_column_lineage(insight_type)
    df_meta = get_insight_rule_meta(insight_type)

    # ── Collect rule columns ───────────────────────────────────────────────
    rule_cols: list[str] = []
    if not df_meta.empty and "rule_column" in df_meta.columns:
        rule_cols = (
            df_meta["rule_column"].dropna().astype(str)
            .str.strip().unique().tolist()
        )
    rule_cols = [c for c in rule_cols if c]

    if df.empty or not rule_cols:
        return []

    # ── Build adjacency map from the full df ───────────────────────────────
    # key = (target_table, target_column) → list of row dicts for that target
    adj: dict[tuple, list] = {}
    for r in df.itertuples(index=False):
        tgt_t  = _s(getattr(r, "target_table",      None))
        tgt_s  = _s(getattr(r, "target_schema",     None))
        tgt_c  = _s(getattr(r, "target_column",     None))
        src_t  = _s(getattr(r, "source_table",      None))
        src_s  = _s(getattr(r, "source_schema",     None))
        src_c  = _s(getattr(r, "source_column",     None))
        logic  = _s(getattr(r, "logic",             None))
        proc   = _s(getattr(r, "process",           None))
        sqlp   = _s(getattr(r, "sql_process",       None))
        web_u  = _s(getattr(r, "web_url",           None))
        sub_tt = _s(getattr(r, "sub_target_table",  None))
        sub_ts = _s(getattr(r, "sub_target_schema", None))
        if not tgt_t or not src_t:
            continue
        row_dict = {
            "target_table": tgt_t, "target_schema": tgt_s,
            "sub_target_table": sub_tt, "sub_target_schema": sub_ts,
            "target_column": tgt_c,
            "source_table": src_t, "source_schema": src_s, "source_column": src_c,
            "process": proc, "sql_process": sqlp, "logic": logic,
            "_src_web_url": web_u, "_tgt_web_url": web_u,
            "_src_schema": src_s, "_tgt_schema": tgt_s,
        }
        adj.setdefault((tgt_t, tgt_c), []).append(row_dict)

    # ── Build one section per rule_column via BFS ──────────────────────────
    all_graphs = []

    for rc in rule_cols:
        rc_lower = rc.lower()

        # The profile table is the target_table in anchor rows (depth=0 rows
        # where target_column == rc).  Use the most common one.
        anchor_rows = [
            row for key, rows in adj.items()
            if key[1].lower() == rc_lower
            for row in rows
            if row["target_column"].lower() == rc_lower
        ]
        if not anchor_rows:
            continue

        from collections import Counter
        profile_table = Counter(r["target_table"] for r in anchor_rows).most_common(1)[0][0]
        profile_schema = next((r["target_schema"] for r in anchor_rows if r["target_table"] == profile_table), "")
        profile_web_url = next((r["_tgt_web_url"] for r in anchor_rows if r["target_table"] == profile_table), "")

        focal_id = f"{profile_table}::{rc}"

        nodes_dict: dict[str, dict] = {
            focal_id: {
                "id": focal_id, "tbl": profile_table, "col": rc,
                "schema": profile_schema, "is_start": True, "web_url": profile_web_url,
            }
        }
        edges_set:  set[tuple] = set()
        edges_list: list[dict] = []
        nrows_dict: dict[str, list] = {focal_id: []}

        # BFS from focal node outward (upstream)
        queue   = [(profile_table, rc)]
        visited: set[tuple] = {(profile_table, rc)}

        while queue:
            cur_t, cur_c = queue.pop(0)
            cur_id = f"{cur_t}::{cur_c}"

            for row in adj.get((cur_t, cur_c), []):
                src_t  = row["source_table"]
                src_s  = row["_src_schema"]
                src_c  = row["source_column"]
                src_id = f"{src_t}::{src_c}"

                # Source node
                if src_id not in nodes_dict:
                    nodes_dict[src_id] = {
                        "id": src_id, "tbl": src_t, "col": src_c,
                        "schema": src_s, "is_start": False, "web_url": "",
                    }
                elif src_s and not nodes_dict[src_id]["schema"]:
                    nodes_dict[src_id]["schema"] = src_s

                # Edge
                edge_key = (src_id, cur_id)
                if edge_key not in edges_set:
                    edges_set.add(edge_key)
                    edges_list.append({"from": src_id, "to": cur_id})

                # nrows for current target node
                clean_row = {k: v for k, v in row.items() if not k.startswith("_")}
                nrows_dict.setdefault(cur_id, []).append(clean_row)

                # Recurse
                if (src_t, src_c) not in visited:
                    visited.add((src_t, src_c))
                    queue.append((src_t, src_c))

        # Fill missing nrows entries
        for nid in nodes_dict:
            nrows_dict.setdefault(nid, [])

        if len(nodes_dict) > 1:
            all_graphs.append({
                "profile_table": profile_table,
                "rule_column":   rc,
                "insight_type":  insight_type,
                "nodes":         list(nodes_dict.values()),
                "edges":         edges_list,
                "nrows":         nrows_dict,
            })

    return all_graphs


# ─────────────────────────────────────────────────────────────────────────────
# Template rendering
# ─────────────────────────────────────────────────────────────────────────────

def _template_path() -> Path:
    return Path(__file__).resolve().parents[1] / "utils" / "insight_lineage_template.html"


def _render(insight_type: str) -> str:
    template   = _template_path().read_text(encoding="utf-8")
    all_graphs = _build_all_graphs(insight_type)

    payload = (
        f"var ALL_GRAPHS  = {json.dumps(all_graphs)};\n"
        f"var RAW2COLOR   = {json.dumps(_RAW2COLOR)};\n"
        f"var LEGEND_DATA = {json.dumps(_LEGEND_DATA)};\n"
        f"var INSIGHT_TYPE = {json.dumps(insight_type)};"
    )
    template = re.sub(
        r"var ALL_GRAPHS\s*=\s*\[\s*\];\s*"
        r"var RAW2COLOR\s*=\s*\{.*?\};\s*"
        r"var LEGEND_DATA\s*=\s*\[\s*\];\s*"
        r"var INSIGHT_TYPE\s*=\s*\".*?\";",
        payload, template, flags=re.DOTALL,
    )
    template = re.sub(
        r"<title>.*?</title>",
        f"<title>{insight_type} — Insight Lineage</title>",
        template, count=1, flags=re.DOTALL,
    )
    return template


# ─────────────────────────────────────────────────────────────────────────────
# Dash layout
# ─────────────────────────────────────────────────────────────────────────────

def layout():
    try:
        df_it = get_all_insight_types()
        opts  = [
            {"label": v, "value": v}
            for v in df_it["insight_type"].dropna().astype(str).tolist()
        ]
    except Exception:
        opts = []

    return dcc.Tab(
        label="Insight Lineage",
        value="tab-insight-lineage",
        children=html.Div(
            [
                html.H3("Insight Lineage", style=mds["section_header_style"]),
                html.Div(
                    [
                        html.Div(
                            [
                                html.Span("Insight Type", style=mds["dropdown_label_style"]),
                                dcc.Dropdown(
                                    id="il-insight-dd",
                                    options=opts,
                                    placeholder="Select an insight type …",
                                    clearable=True, searchable=True,
                                    style={**mds["dropdown_style"], "width": "520px"},
                                ),
                            ],
                            style={"minWidth": "560px"},
                        ),
                        html.Div(id="il-rule-badge", style={
                            "marginLeft": "auto", "alignSelf": "center", "marginTop": "18px",
                            "fontSize": "11px", "color": "#1d4ed8", "fontWeight": "600",
                            "padding": "4px 12px", "background": "#dbeafe",
                            "border": "1px solid #93c5fd", "borderRadius": "20px",
                        }),
                    ],
                    style={
                        **mds["toolbar_style"],
                        "display": "flex", "alignItems": "flex-start",
                        "gap": "16px", "flexWrap": "wrap", "marginBottom": "10px",
                    },
                ),
                # Rule-column chip bar
                html.Div(id="il-meta-card", style={"display": "none"},
                    children=[
                        html.Div(id="il-meta-content", style={
                            **mds["content_card_style"],
                            "marginBottom": "10px",
                            "display": "flex", "flexWrap": "wrap",
                            "gap": "8px", "alignItems": "center",
                            "padding": "10px 16px",
                        })
                    ],
                ),
                html.Iframe(
                    id="il-iframe", src="",
                    style={
                        "width": "100%", "height": "85vh",
                        "border": "1px solid #e2e8f0", "borderRadius": "8px",
                        "background": "#ffffff",
                    },
                ),
            ],
            style=mds["table_container_style"],
        ),
    )


# ─────────────────────────────────────────────────────────────────────────────
# Callbacks
# ─────────────────────────────────────────────────────────────────────────────

def register_callbacks(app):

    @app.callback(
        Output("il-rule-badge",   "children"),
        Output("il-meta-card",    "style"),
        Output("il-meta-content", "children"),
        Input("il-insight-dd", "value"),
    )
    def _update_meta(selected_insight):
        hidden  = {"display": "none"}
        visible = {"display": "block"}
        if not selected_insight:
            return "", hidden, []
        try:
            df_m = get_insight_rule_meta(str(selected_insight))
        except Exception:
            return "⚠ could not load metadata", hidden, []

        rule_cols = []
        if not df_m.empty and "rule_column" in df_m.columns:
            rule_cols = (
                df_m["rule_column"].dropna().astype(str).str.strip().unique().tolist()
            )

        badge = f"{len(rule_cols)} rule column{'s' if len(rule_cols) != 1 else ''}"

        chips = [
            html.Span("◈ ODM Rule Columns:", style={
                "fontSize": "11px", "fontWeight": "700", "color": "#1d4ed8",
                "marginRight": "8px", "textTransform": "uppercase", "letterSpacing": "0.06em",
            })
        ]
        for rc in sorted(rule_cols):
            chips.append(html.Span(rc, style={
                "display": "inline-block",
                "background": "#dbeafe", "border": "1px solid #93c5fd",
                "borderRadius": "4px", "padding": "2px 8px",
                "fontSize": "12px", "fontFamily": '"JetBrains Mono", monospace',
                "color": "#1d4ed8",
            }))
        return badge, visible, chips

    @app.callback(
        Output("il-iframe", "src"),
        Input("il-insight-dd", "value"),
    )
    def _update_iframe(selected_insight):
        if not selected_insight:
            return ""
        enc = urllib.parse.quote(str(selected_insight), safe="")
        return app.get_relative_path(f"/insight-lineage-view?insight={enc}")


# ─────────────────────────────────────────────────────────────────────────────
# Server route
# ─────────────────────────────────────────────────────────────────────────────

def register_server_routes(server, routes_prefix="/"):
    def _handler():
        insight = request.args.get("insight", "").strip()
        if not insight:
            return ("<html><body style='font-family:Arial;padding:20px'>"
                    "Select an insight type to view lineage.</body></html>")
        try:
            return _render(insight)
        except Exception as exc:
            safe = str(exc).replace("<", "&lt;").replace(">", "&gt;")
            return (f"<html><body style='font-family:Arial;padding:20px'>"
                    f"<b>Error:</b> {safe}</body></html>")

    if not routes_prefix.startswith("/"):  routes_prefix = "/" + routes_prefix
    if not routes_prefix.endswith("/"):    routes_prefix = routes_prefix + "/"

    base = "/insight-lineage-view"
    pref = f"{routes_prefix.rstrip('/')}{base}"
    existing = {r.rule for r in server.url_map.iter_rules()}
    if base not in existing:
        server.add_url_rule(base, endpoint="insight_lineage_view", view_func=_handler)
    if pref not in existing and pref != base:
        server.add_url_rule(pref, endpoint="insight_lineage_view_prefixed", view_func=_handler)
