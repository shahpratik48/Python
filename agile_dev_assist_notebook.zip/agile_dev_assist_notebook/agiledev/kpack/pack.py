"""Consumer API (copied from the Knowledge Pack builder, project 6): open a built pack (folder or zip) and ask it things. This is what Agile Dev Assist, the STAAT Insights
chatbot and any other use case import instead of re-reading the repository and Greenplum.

    from kpack.pack import Pack
    p = Pack.latest("odm")                      # output/odm/odm_pack.zip   (or Pack("/anywhere/odm_pack.zip") / Pack("output/odm/<version>"))
    p.search("how is a new client insight registered", k=8)
    p.table("core_odm.odm_client_profile")      # columns + semantics + lineage
    p.folder("dags/odm/script/sql/ds_client_insights")
    p.registration("dags/odm/script/sql/odm_process")
    p.companions("dags/odm/script/sql/ds_client_insights/x.sql")
    p.rules(); p.conventions(); p.definitions(); p.read("dags/odm/script/python/props.py")
    p.context("add a new wealthx insight")       # prompt-ready block (cards + chunks)   p.card("folder", f)   p.exemplar(f)
    p.impact("core_ikg.client_profile_curr_ikg") # graph walk: readers, downstream tables, DAGs
"""
from __future__ import annotations

import json
import re
import zipfile
from pathlib import Path
from typing import Dict, List, Optional

from .index import PackIndex


def _unzip_cache() -> Path:
    """Where zips are unpacked for reading: KPACK_UNZIP_DIR, else the OS temp dir (local disk: fast for thousands of small files)."""
    import os, tempfile
    for cand in (os.environ.get("KPACK_UNZIP_DIR"),):
        if cand:
            try:
                Path(cand).mkdir(parents=True, exist_ok=True)
                return Path(cand)
            except OSError:
                continue
    return Path(tempfile.gettempdir()) / "kpack_unzipped"


_unzip_locks: Dict[str, "object"] = {}


def _extract_fast(zip_path: Path, target: Path, workers: int = 8) -> None:
    """Extracts every file of the zip into `target`: folders created once, files written by a thread pool (on a network
    or slow disk each file create costs a round trip; parallel writes hide most of it). Paths are checked to stay inside."""
    import zipfile
    from concurrent.futures import ThreadPoolExecutor
    root = target.resolve()
    with zipfile.ZipFile(zip_path) as z:
        infos = [i for i in z.infolist() if not i.is_dir()]
        dirs = set()
        for i in infos:
            out = (root / i.filename).resolve()
            if root not in out.parents:
                raise ValueError(f"unsafe path in pack zip: {i.filename}")
            dirs.add(out.parent)
        for d in sorted(dirs, key=lambda x: len(x.parts)):
            d.mkdir(parents=True, exist_ok=True)

    def work(chunk):
        with zipfile.ZipFile(zip_path) as zz:                # one handle per worker: ZipFile reads are not thread safe
            for i in chunk:
                with zz.open(i) as src, open(root / i.filename, "wb") as dst:
                    dst.write(src.read())
    n = max(1, min(workers, len(infos) // 50 or 1))
    chunks = [infos[k::n] for k in range(n)]
    with ThreadPoolExecutor(n) as ex:
        list(ex.map(work, chunks))


class Pack:
    def __init__(self, path, llm=None, emb_cfg: Optional[dict] = None):
        path = Path(path)
        if path.suffix == ".zip":
            path = self._unzip(path)
        self.dir = path
        self.manifest = self._json("manifest.json")
        self.structure = self._json("facts/structure.json")
        self.tables_ = self._json("facts/tables.json")
        self.skills = self._json("facts/skills.json")
        self.derived = self._json("derived/derived.json")
        self.system = self.manifest.get("system", "")
        self.version = self.manifest.get("version", "")
        self.index = PackIndex(self.dir, emb_cfg or {}, llm=llm)
        self.index.load()
        self.synonyms = self._json("synonyms.json")
        self.exemplars_ = self._json("exemplars.json")
        self._graph = None
        self._business = None

    @staticmethod
    def _unzip(zip_path: Path, into: Optional[Path] = None) -> Path:
        """Extracts <sys>_pack.zip (into `into`, else the unzip cache) and returns the pack folder; re-extracts when the zip changed.
        Extraction goes to a temporary folder that is renamed at the end, so a half-written pack is never used and two chats
        opening the same pack at once do not step on each other."""
        import shutil, threading, zipfile, os
        with zipfile.ZipFile(zip_path) as z:
            names = z.namelist()
        root = names[0].split("/", 1)[0] if names and "/" in names[0] else ""
        base = into or _unzip_cache() / zip_path.stem           # never next to the zip: output/ stays zips only
        dest = base / root if root else base
        st = zip_path.stat()
        sig = f"{st.st_size}|{st.st_mtime}"

        def ready() -> bool:
            stamp = base / ".zip_stamp"
            return (dest / "manifest.json").exists() and stamp.exists() and stamp.read_text() == sig
        if ready():
            return dest
        lock = _unzip_locks.setdefault(str(base), threading.Lock())
        with lock:
            if ready():
                return dest
            tmp = base.with_name(f"{base.name}.part{os.getpid()}_{threading.get_ident()}")
            shutil.rmtree(tmp, ignore_errors=True)
            tmp.mkdir(parents=True, exist_ok=True)
            try:
                _extract_fast(zip_path, tmp)
                (tmp / ".zip_stamp").write_text(sig)
                if base.exists():
                    old = base.with_name(f"{base.name}.old{os.getpid()}")
                    shutil.rmtree(old, ignore_errors=True)
                    try:
                        base.rename(old)
                    except OSError:
                        pass
                    shutil.rmtree(old, ignore_errors=True)
                try:
                    tmp.rename(base)
                except OSError:                                 # another process finished first: use its copy
                    if not ready():
                        raise
            finally:
                shutil.rmtree(tmp, ignore_errors=True)
        return dest

    def _json(self, rel: str):
        p = self.dir / rel
        return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}

    # ------------------------------------------------------------------ queries
    def search(self, query: str, k: int = 10, kinds: Optional[List[str]] = None, expand: bool = True) -> List[dict]:
        """Hybrid search (BM25 + vectors, RRF) over all items incl. code chunks; `expand` adds glossary / bridge synonyms to the query."""
        from .enrich import expand_query
        q = expand_query(query, self.synonyms) if expand and self.synonyms else query
        return self.index.search(q, k=k, kinds=kinds)

    def context(self, query: str, k: int = 8, max_chars: int = 12000) -> str:
        """One prompt-ready block for a question: the best cards + chunks, deduplicated and capped - what a consumer agent
        puts in its prompt instead of calling tools."""
        parts, used, size = [], set(), 0
        for h in self.search(query, k=k * 2):
            key = h["ref"] if h["kind"] != "chunk" else h["ref"].split("#")[0]
            if key in used:
                continue
            txt = None
            if h["kind"] == "folder":
                txt = self.card("folder", h["ref"])
            elif h["kind"] == "table":
                txt = self.card("table", h["ref"])
            elif h["kind"] == "dag":
                txt = self.card("dag", Path(h["ref"]).stem)
            elif h["kind"] == "business_rule":
                txt = self.card("rule", h["ref"])
            elif h["kind"] == "domain":
                txt = self.card("domain", re.sub(r"[^a-z0-9_]+", "_", h["ref"].lower()))
            if not txt:
                txt = f"### {h['title']} ({h['kind']})\n{h['text']}"
            if size + len(txt) > max_chars:
                continue
            used.add(key); parts.append(txt); size += len(txt)
            if len(parts) >= k:
                break
        return "\n\n".join(parts)

    def card(self, kind: str, name: str) -> str:
        if kind == "rule" and not (self.dir / "cards" / "rule" / f"{name}.md").exists():
            return self._rule_cards().get(name.lower().strip(), "")
        n = name.replace("/", "__").replace(".", "__") if kind in ("folder", "table") else name
        p = self.dir / "cards" / kind / f"{n or 'root'}.md"
        return p.read_text(encoding="utf-8") if p.exists() else ""

    def exemplar(self, folder: str) -> dict:
        return self.exemplars_.get(folder, {})

    def graph(self) -> dict:
        if self._graph is None:
            g = self._json("graph.json")
            adj = {}
            for e in g.get("edges", []):
                adj.setdefault(e["from"], []).append((e["rel"], e["to"], e))
                adj.setdefault(e["to"], []).append(("<" + e["rel"], e["from"], e))
            self._graph = {"nodes": {n["id"]: n for n in g.get("nodes", [])}, "adj": adj, "counts": g.get("counts", {})}
        return self._graph

    def neighbours(self, node_id: str, hops: int = 1, rels: Optional[List[str]] = None, limit: int = 200) -> List[dict]:
        """Walk the knowledge graph: node ids are 'table:core_ikg.x', 'script:dags/..sql', 'folder:dags/..', 'dag:..', 'param:X', 'term:..', 'column:t.c'."""
        g = self.graph()
        seen, frontier, out = {node_id}, [node_id], []
        for _ in range(hops):
            nxt = []
            for n in frontier:
                for rel, other, e in g["adj"].get(n, []):
                    if rels and rel.lstrip("<") not in rels:
                        continue
                    if other in seen:
                        continue
                    seen.add(other); nxt.append(other)
                    out.append({"from": n, "rel": rel, "to": other, "node": g["nodes"].get(other, {}), "edge": {k: v for k, v in e.items() if k not in ("from", "to", "rel")}})
                    if len(out) >= limit:
                        return out
            frontier = nxt
        return out

    def impact(self, table: str, hops: int = 2) -> dict:
        """What depends on a table: scripts reading it, tables those scripts build, DAGs registering them - no model call."""
        t = f"table:{table.lower()}"
        readers = [n["to"] for n in self.neighbours(t, 1, rels=["reads"])]
        downstream = sorted({n["to"] for r in readers for n in self.neighbours(r, 1, rels=["builds"])})
        dags = sorted({n["to"] for r in readers for f in [self.graph()["nodes"].get(r, {})] for n in self.neighbours("folder:" + (r.split(":", 1)[1].rsplit("/", 1)[0] if "/" in r else "/"), 1, rels=["registered_by"])})
        return {"table": table, "read_by": readers, "downstream_tables": downstream, "dags": dags, "built_by": [n["to"] for n in self.neighbours(t, 1, rels=["builds"])]}

    def read(self, rel: str, max_chars: int = 60000) -> str:
        p = self.dir / "raw" / "repo" / rel
        return p.read_text(encoding="utf-8", errors="replace")[:max_chars] if p.exists() else ""

    def files(self, folder: str = "", language: str = "") -> List[str]:
        fl = self.structure.get("file_list", {})
        return sorted(r for r, f in fl.items() if (not folder or r.startswith(folder.rstrip("/") + "/")) and (not language or f["language"] == language))

    def table(self, name: str) -> dict:
        name = name.lower()
        info = dict(self.tables_.get(name) or {})
        info["semantics"] = (self.derived.get("data", {}).get("tables", {}) or {}).get(name, {})
        info["lineage"] = self.structure.get("tables", {}).get(name) or self.structure.get("tables", {}).get(info.get("code_name", ""), {})
        return info

    def tables(self, like: str = "") -> List[str]:
        names = set(self.tables_) | set(self.structure.get("tables", {}))
        return sorted(n for n in names if not like or re.search(like, n, re.I))

    def folder(self, folder: str) -> dict:
        f = dict(self.structure.get("folders", {}).get(folder) or {})
        f["derived"] = (self.derived.get("repo", {}).get("folders") or {}).get(folder, {})
        f["companions"] = [c for c in self.structure.get("companion_patterns", []) if c["folder"] == folder]
        return f

    def folders(self) -> List[str]:
        return sorted(self.structure.get("folders", {}))

    def registration(self, folder: str) -> dict:
        return self.structure.get("registration", {}).get(folder, {"rule": "folder not in pack"})

    def companions(self, path: str) -> List[dict]:
        folder = path.rsplit("/", 1)[0] if "/" in path else ""
        stem = Path(path).stem
        out = []
        for c in self.structure.get("companion_patterns", []):
            if c["folder"] != folder:
                continue
            out.append(dict(c, expected=_apply_stem_rule(stem, c.get("stem_rule", ""), c["example"])))
        return out

    def standards_text(self) -> str:
        """The generated `<sys>_standards.md` of the pack (raw/skills/<sys>/), else the pack's cards/standards.md."""
        if getattr(self, "_standards", None) is None:
            txt = ""
            for rel in (f"raw/skills/{self.system}/{self.system}_standards.md", f"raw/skills/{self.system}/{self.system}_standards_generated.md", "cards/standards.md"):
                f = self.dir / rel
                if f.exists():
                    txt = f.read_text(encoding="utf-8", errors="replace"); break
            self._standards = txt
        return self._standards

    def recipe(self, folder: str) -> str:
        """The per-folder recipe of the generated standards: numbered steps (name pattern, sibling, registration line) and
        the skeleton of the folder's typical file - exactly what a new file in that folder must follow. '' if none."""
        folder = folder.strip("/")
        txt = self.standards_text()
        if not txt or not folder:
            return ""
        m = re.search(r"^### `" + re.escape(folder) + r"` \(\d+ files\)\n(.*?)(?=^### `|^## |\Z)", txt, flags=re.M | re.S)
        if not m:
            parent = folder.rsplit("/", 1)[0] if "/" in folder else ""
            m = re.search(r"^### `" + re.escape(parent) + r"` \(\d+ files\)\n(.*?)(?=^### `|^## |\Z)", txt, flags=re.M | re.S) if parent else None
            if not m:
                return ""
        return (f"recipe for `{folder}` (from the repository facts):\n" + m.group(1).strip())[:3000]

    def dags(self) -> List[dict]:
        return self.structure.get("dags", [])

    def rules(self) -> List[dict]:
        return self.derived.get("knowledge", {}).get("rules", []) or []

    def conventions(self) -> List[dict]:
        return self.derived.get("knowledge", {}).get("conventions", []) or []

    def definitions(self) -> List[dict]:
        return self.derived.get("knowledge", {}).get("definitions", []) or []

    def bridge(self, term: str = "") -> List[dict]:
        b = self.derived.get("bridge", {}).get("bridge", []) or []
        return [x for x in b if not term or term.lower() in json.dumps(x).lower()]

    # ------------------------------------------------------------------ business rules (insights) across IKG / ODM / NLG (pack format 2)
    def _rule_cards(self) -> Dict[str, str]:
        if getattr(self, "_rcards", None) is None:
            self._rcards = {}
            p = self.dir / "cards" / "rules.md"
            if p.exists():
                for sec in re.split(r"(?m)^(?=# si_)", p.read_text(encoding="utf-8")):
                    m = re.match(r"# (si_[a-z0-9_]+)", sec)
                    if m:
                        self._rcards[m.group(1)] = sec.strip() + "\n"
        return self._rcards

    def business(self) -> dict:
        if self._business is None:
            self._business = self._json("facts/business.json") or {"rules": {}, "features": {}, "domains": {}, "entities": {}, "stats": {}}
        return self._business

    def insight(self, insight_id: str) -> dict:
        return self.business()["rules"].get(insight_id.lower().strip(), {})

    def insights(self, query: str = "", k: int = 10, target: str = "", domain: str = "") -> List[dict]:
        b = self.business()["rules"]
        hits = [b[h["ref"]] for h in self.search(query, k=k * 3, kinds=["business_rule"]) if h["ref"] in b] if query else list(b.values())
        hits = [r for r in hits if (not target or r.get("target") == target) and (not domain or r.get("domain") == domain)]
        hits.sort(key=lambda r: str(r.get("status", "")).startswith("narrative only"))     # live rules first; narrative-only ones are mostly retired
        return [{"id": r["id"], "title": r["title"], "target": r.get("target", ""), "domain": r.get("domain", ""), "status": r.get("status", ""),
                 "description": r.get("description", "")} for r in hits[:k]]

    def feature(self, column: str) -> dict:
        return self.business()["features"].get(column.lower().strip(), {})

    def trace(self, insight_id: str) -> dict:
        r = self.insight(insight_id)
        if not r:
            return {}
        return {"rule": r, "features": {c: self.feature(c) for c in r.get("features", [])},
                "depends_on": {d: (self.insight(d) or {}).get("title", "") for d in (r.get("odm") or {}).get("depends_on", [])},
                "card": self.card("rule", r["id"])}

    def overview(self) -> str:
        p = self.dir / "pack.md"
        return p.read_text(encoding="utf-8") if p.exists() else ""

    def summary(self) -> dict:
        return {"system": self.system, "version": self.version, "built_at": self.manifest.get("built_at"), "counts": self.manifest.get("counts"),
                "health": self.manifest.get("health"), "dense_index": self.index.status.get("dense"), "path": str(self.dir)}


def _apply_stem_rule(stem: str, rule: str, example: dict) -> str:
    """Turn the learnt stem rule ('same stem', 'drop curr', 'add hist', 'drop curr add hist') into the expected companion stem."""
    if not rule or rule == "same stem":
        return stem
    toks = stem.split("_")
    m = re.search(r"drop (\S+)", rule)
    if m:
        drop = m.group(1).split("_")
        toks = [t for t in toks if t not in drop]
    m = re.search(r"add (\S+)", rule)
    if m:
        add = m.group(1).split("_")
        ex_c = Path(example.get("companion", "")).stem.split("_")
        # place the added tokens where the example puts them (end by default)
        if ex_c and ex_c[0] in add:
            toks = add + toks
        else:
            toks = toks + add
    return "_".join(toks)
