"""Launch the full web UI from the notebook with one button (dev login, no SSO), on this machine.

    from agiledev.notebook_ui import launch_button
    launch_button(cfg, llm=llm, port=8780, selftest=SELFTEST)

The server runs in a background thread of the kernel; the button shows the links to open. When JupyterLab itself
runs on a remote server, the browser cannot reach localhost there - use the jupyter-server-proxy link shown
(.../proxy/<port>/) or open http://<that server's host>:<port>/ if the port is reachable."""
from __future__ import annotations

import os
import threading
import time
import webbrowser
from typing import Optional

_servers = {}


def start_server(cfg, llm=None, port: int = 8780, selftest: bool = False, host: str = "127.0.0.1"):
    from .server import create_app
    import uvicorn
    key = port
    if key in _servers:
        return _servers[key]
    cfg = _local_cfg(cfg)
    app = create_app(cfg, llm, selftest)
    config = uvicorn.Config(app, host=host, port=port, log_level="warning")
    server = uvicorn.Server(config)
    t = threading.Thread(target=server.run, daemon=True)
    t.start()
    time.sleep(1.2)
    _servers[key] = server
    return server


def stop_server(port: int = 8780):
    s = _servers.pop(port, None)
    if s is not None:
        s.should_exit = True


def _local_cfg(cfg):
    from .config import Config
    c = Config(dict(cfg))
    c["auth"] = dict(cfg.get("auth") or {}, mode="dev", dev_allow_any_user=True)
    c["inputs"] = dict(cfg.get("inputs") or {})
    c["inputs"]["greenplum"] = dict(c["inputs"].get("greenplum") or {}, allow_sqlite=True)   # local test: a sqlite file may play Greenplum
    return c


def links(port: int) -> dict:
    out = {"local": f"http://localhost:{port}/"}
    base = os.environ.get("JUPYTERHUB_SERVICE_PREFIX") or os.environ.get("JUPYTER_SERVER_ROOT_URL") or ""
    if base:
        out["jupyter proxy"] = base.rstrip("/") + f"/proxy/{port}/"
    else:
        out["jupyter proxy (if jupyter-server-proxy is installed)"] = f"/proxy/{port}/"
    return out


def launch_button(cfg, llm=None, port: int = 8780, selftest: bool = False, open_browser: bool = True):
    """Shows a button; clicking it starts the UI (once) and prints the links. Falls back to plain output when
    ipywidgets is not available."""
    try:
        import ipywidgets as w
        from IPython.display import HTML, display
    except ImportError:
        start_server(cfg, llm, port, selftest)
        print("Agile Dev Assist UI started:", links(port))
        return None
    btn = w.Button(description="Launch Agile Dev Assist UI", button_style="primary", icon="rocket",
                   layout=w.Layout(width="260px", height="40px"))
    stop = w.Button(description="Stop", icon="stop", layout=w.Layout(width="90px", height="40px"))
    out = w.Output()

    def on_click(_):
        with out:
            out.clear_output()
            try:
                start_server(cfg, llm, port, selftest)
                ls = links(port)
                html = "<div style='font-family:sans-serif'><b>Agile Dev Assist UI is running.</b> Sign in with any user id (dev login).<ul>"
                for k, v in ls.items():
                    html += f"<li>{k}: <a href='{v}' target='_blank'>{v}</a></li>"
                html += "</ul><small>Remote JupyterLab? localhost is the notebook server's machine - use the proxy link or the server's host name.</small></div>"
                display(HTML(html))
                if open_browser:
                    try:
                        webbrowser.open(ls["local"])
                    except Exception:  # noqa: BLE001
                        pass
            except Exception as e:  # noqa: BLE001
                print(f"could not start the UI: {type(e).__name__}: {e}")

    def on_stop(_):
        stop_server(port)
        with out:
            out.clear_output()
            print("UI stopped")
    btn.on_click(on_click)
    stop.on_click(on_stop)
    display(w.HBox([btn, stop]), out)
    return btn
