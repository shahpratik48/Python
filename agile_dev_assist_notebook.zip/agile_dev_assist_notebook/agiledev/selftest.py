"""Offline self-test: a scripted model that answers every agent with plausible, schema-valid JSON so the whole
plumbing (inputs -> pack -> agents -> validation -> review -> fix -> outputs -> zip) runs without Azure, Greenplum
or GitLab. Also builds the sample inputs (story, skills, glossary, standards, sqlite 'Greenplum', local repo)."""
from __future__ import annotations

import json
import sqlite3
import time
import uuid
from pathlib import Path
from types import SimpleNamespace

from .llm import LLM, EMPTY

SAMPLES = Path(__file__).resolve().parent.parent / "samples"


class ScriptedLLM(LLM):
    """Same interface as LLM; never calls the network."""

    def __init__(self, cfg, cache_dir):
        super().__init__(cfg, cache_dir, client=object())
        self.calls = 0
        self.review_round = {}

    def check(self):
        return "OK (scripted)"

    def chat(self, messages, tools=None, tool_choice="auto", reasoning_effort=None):
        self.calls += 1
        system = messages[0]["content"]
        task = {}
        for m in messages:
            if m["role"] == "user" and str(m.get("content", "")).startswith("TASK:"):
                task = json.loads(m["content"][5:])
        names = {"story_agent": "STORY AGENT", "knowledge_agent": "KNOWLEDGE AGENT", "data_agent": "DATA AGENT",
                 "repo_agent": "REPOSITORY AGENT", "planner_agent": "PLANNER AGENT", "coder_agent": "CODER AGENT",
                 "reviewer_agent": "REVIEWER AGENT", "change_agent": "CHANGE AGENT"}
        agent = next((a for a, tag in names.items() if tag in system), "unknown")
        fn = getattr(self, f"_{agent}", None)
        result = fn(task) if fn else {"error": "unknown agent"}
        # fake usage accounting
        r = SimpleNamespace(usage=SimpleNamespace(prompt_tokens=1200, completion_tokens=300, total_tokens=1500,
                                                  prompt_tokens_details=SimpleNamespace(cached_tokens=200),
                                                  completion_tokens_details=SimpleNamespace(reasoning_tokens=50)))
        self._account(r, 0.01)
        call = SimpleNamespace(id=f"call_{uuid.uuid4().hex[:8]}", function=SimpleNamespace(name="submit_result", arguments=json.dumps(result)))
        return SimpleNamespace(content="", tool_calls=[call])

    # ---------------------------------------------------------------- scripted answers
    def _story_agent(self, t):
        s = t.get("story", {})
        return {"summary": f"Implement '{s.get('title')}': build the client activity summary table from the account facts and expose it to Airflow.",
                "goal": "A daily client activity summary table with one row per client.",
                "feature_name": "client activity summary",
                "functional_requirements": ["1. Create table client_activity_summary with one row per client_id",
                                            "2. total_balance = sum of balance over active accounts", "3. Register the job as an Airflow task",
                                            "4. Provide a notebook that validates the row count against the source"],
                "inputs": ["account_fact", "client_dim"], "outputs": ["client_activity_summary"],
                "business_rules": ["active account = status_cd = 'A'", "statement household key is acc_mhh_n"],
                "acceptance_criteria": s.get("acceptance_criteria") or ["row count equals distinct clients with active accounts"],
                "non_functional": ["idempotent daily load", "no hardcoded schema names"], "open_questions": [],
                "target_languages": ["sql", "airflow_dag", "ipynb"],
                "code_in_story": [{"index": i + 1, "language": b.get("language", "sql"), "what_it_does": "aggregates active balances per client",
                                   "how_to_use": "reuse as the core query", "tables": ["account_fact"], "columns": ["client_id", "balance"]}
                                  for i, b in enumerate(s.get("code_blocks") or [])],
                "tables_mentioned": ["account_fact", "client_dim"], "columns_mentioned": ["client_id", "balance", "status_cd", "acc_mhh_n"]}

    def _knowledge_agent(self, t):
        return {"definitions": [{"term": "acc_mhh_n", "definition": "statement household number", "source": "glossary.csv"},
                                {"term": "active account", "definition": "status_cd = 'A'", "source": "skills.md"}],
                "conventions": [{"rule": "schema names are parameters, never literals", "source": "standards.yaml", "applies_to": "sql"},
                                {"rule": "every SQL file starts with a header comment naming the story", "source": "standards.yaml", "applies_to": "sql"}],
                "rules": [{"id": "no-literal-schema", "pattern": r"\bcore_ikg\.", "must_match": False, "severity": "high",
                           "message": "use the schema parameter {{params.IKG_SCHEMA}} instead of the literal schema", "languages": ["sql", "python", "airflow_dag"]},
                          {"id": "sql-header", "pattern": r"\A\s*--", "must_match": True, "severity": "low", "message": "start SQL files with a header comment", "languages": ["sql"]}],
                "notes_for_coder": ["use {{params.IKG_SCHEMA}} for the schema", "distribute summary tables by client_id"]}

    def _data_agent(self, t):
        return {"tables": [{"table": "account_fact", "role": "source", "grain": "one row per account per day", "keys": ["account_id", "as_of_date"],
                            "columns_needed": ["account_id", "client_id", "balance", "status_cd", "as_of_date"], "notes": "balance numeric"},
                           {"table": "client_dim", "role": "lookup", "grain": "one row per client", "keys": ["client_id"],
                            "columns_needed": ["client_id", "client_name", "acc_mhh_n"], "notes": ""}],
                "joins": ["account_fact.client_id = client_dim.client_id"], "data_rules": ["filter status_cd = 'A'"], "sql_dialect": "greenplum"}

    def _repo_agent(self, t):
        repos = t.get("repos", [])
        files = [f["path"] for r in repos for f in r.get("relevant_files", [])]
        sql = [f for f in files if f.endswith(".sql")][:1]
        reg = [{"path": f, "what_to_add": "a PostgresOperator task for client_activity_summary_ikg.sql", "example_line": "household_profile_curr_ikg"}
               for f in files if f.endswith("ikg_data_refresh.py")]
        return {"where_the_change_belongs": [{"repo": repos[0]["name"] if repos else "repo", "folder": "dags/ikg/scripts/sql/ikg_create_profiles", "reason": "profile tables live here"}],
                "patterns_to_imitate": [{"path": p, "why": "same kind of table"} for p in sql],
                "conventions_observed": ["schema via {{params.IKG_SCHEMA}}", "tables suffixed _ikg"],
                "existing_files_to_modify": [], "registration_points": reg, "companion_files": [],
                "impact": [{"name": "account_fact", "used_in": ["dags/ikg/scripts/sql/ikg_create_profiles/household_profile_curr_ikg.sql"], "risk": "none - read only"}],
                "reusable_functions": []}

    def _planner_agent(self, t):
        reg = [r["path"] for r in (t.get("repo") or {}).get("registration_points", [])]
        n_blocks = len(t.get("story_code_blocks") or [])
        files = [{"path": "dags/ikg/scripts/sql/ikg_create_profiles/client_activity_summary_ikg.sql", "action": "create", "language": "sql",
                  "purpose": "build the summary table", "outline": ["drop if exists", "temp table of active accounts", "create table as select", "grants"],
                  "depends_on": [], "repo": "", "requirements_covered": ["1", "2"]},
                 {"path": "notebooks/validate_client_activity_summary.ipynb", "action": "create", "language": "ipynb",
                  "purpose": "row count validation", "outline": ["connect", "count", "compare"], "depends_on": [], "repo": "", "requirements_covered": ["4"]}]
        for p in reg:
            files.append({"path": p, "action": "modify", "language": "airflow_dag", "purpose": "register the new SQL as a task",
                          "outline": ["add PostgresOperator task after household_profile"], "depends_on": [files[0]["path"]], "repo": "", "requirements_covered": ["3"]})
        if not reg:
            files.append({"path": "dags/ikg/dags/client_activity_summary_dag.py", "action": "create", "language": "airflow_dag",
                          "purpose": "daily schedule", "outline": ["DAG", "task running the SQL"], "depends_on": [files[0]["path"]], "repo": "", "requirements_covered": ["3"]})
        return {"approach": "One SQL script builds the summary table from the account facts (active accounts staged in a temp table); the existing refresh DAG registers it; a notebook validates it.",
                "design": {"modules": [{"name": "active_accounts", "purpose": "filter status_cd = 'A' once", "kind": "temp_table"},
                                       {"name": "client_activity_summary_ikg", "purpose": "aggregate per client", "kind": "intermediate_table"}],
                           "intermediate_tables": [{"name": "tmp_active_accounts", "grain": "one row per active account", "purpose": "filter early (temp table inside client_activity_summary_ikg.sql)", "distribution_key": "client_id"}],
                           "performance": ["filter status before the join", "distribute by client_id"],
                           "story_code_usage": [{"index": i + 1, "used_in": files[0]["path"], "how": "core aggregation kept as given"} for i in range(n_blocks)]},
                "files": files, "registration_changes": [{"path": p, "what": "add task build_client_activity_summary"} for p in reg],
                "impact": ["new table only; no consumer changes"],
                "steps": ["write SQL", "register in DAG", "write notebook"], "test_plan": ["row count check", "DAG import"], "risks": [], "questions": []}

    def _coder_agent(self, t):
        path, lang, mode = t["path"], t.get("language", ""), t.get("mode")
        if mode == "modify" and t.get("existing_content") is not None:
            content = t["existing_content"].rstrip("\n") + "\n    build_client_activity_summary = None  # task registered for client_activity_summary_ikg.sql\n"
            return {"path": path, "language": lang, "content": content, "edits": [], "explanation": "registered the new task", "assumptions": [], "confidence": 88}
        if mode == "fix" and t.get("existing_content"):
            content = t["existing_content"].replace("core_ikg.", "{{params.IKG_SCHEMA}}.").replace("select * from", "select client_id, total_balance from")
            if "sql" in lang and not content.lstrip().startswith("--"):
                content = "-- story: client activity summary\n" + content
            if "balance > 0" in str(t.get("change_request", "")) and "a.balance > 0" not in content:
                content = content.replace("where a.status_cd = 'A'", "where a.status_cd = 'A' and a.balance > 0")
            return {"path": path, "language": lang, "content": content, "edits": [], "explanation": "applied the findings", "assumptions": [], "confidence": 90}
        if lang == "sql":
            content = ("-- story: client activity summary\n"
                       "drop table if exists {{params.IKG_SCHEMA}}.client_activity_summary_ikg;\n"
                       "create table {{params.IKG_SCHEMA}}.client_activity_summary_ikg as\n"
                       "select c.client_id, c.acc_mhh_n, sum(a.balance) as total_balance, count(*) as active_accounts\n"
                       "from core_ikg.account_fact a join {{params.IKG_SCHEMA}}.client_dim c on c.client_id = a.client_id\n"
                       "where a.status_cd = 'A' group by c.client_id, c.acc_mhh_n\n"
                       "distributed by (client_id);\n")
        elif lang in ("python", "airflow_dag"):
            content = ('"""Daily client activity summary DAG."""\nfrom datetime import datetime\n\nfrom airflow import DAG\n'
                       "from airflow.providers.postgres.operators.postgres import PostgresOperator\n\n"
                       "with DAG(dag_id='client_activity_summary', schedule='0 6 * * 1-5', start_date=datetime(2026, 1, 1), catchup=False,\n"
                       "         params={'IKG_SCHEMA': 'core_ikg'}) as dag:\n"
                       "    build = PostgresOperator(task_id='build_client_activity_summary', postgres_conn_id='IKG_GP',\n"
                       "                             sql='scripts/sql/ikg_create_profiles/client_activity_summary_ikg.sql')\n")
        elif lang == "ipynb":
            content = json.dumps({"nbformat": 4, "nbformat_minor": 5, "metadata": {}, "cells": [
                {"cell_type": "markdown", "metadata": {}, "source": ["# Validate client_activity_summary"]},
                {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": ["import pandas as pd\n", "print('row count check')\n"]}]}, indent=1)
        else:
            content = f"# {path}\n"
        return {"path": path, "language": lang, "content": content, "edits": [], "explanation": f"{path} implements its part of the plan",
                "assumptions": [], "confidence": 85}

    def _reviewer_agent(self, t):
        key = tuple(sorted(t.get("files", {})))
        n = self.review_round.get(key, 0)
        self.review_round[key] = n + 1
        bad = [p for p, c in t.get("files", {}).items() if "core_ikg." in c]
        extra = {"story_code_check": [{"index": i + 1, "respected": True, "note": "logic kept"} for i in range(len(t.get("story_code_blocks") or []))],
                 "registration_check": {"ok": any("ikg_data_refresh" in p for p in t.get("files", {})), "note": "task registered in the refresh DAG"},
                 "impact_assessment": [{"change": "new table client_activity_summary_ikg", "affects": "none", "risk": "low", "mitigation": "n/a"}],
                 "performance_notes": ["filter before join"], "standards_check": [{"rule": "no literal schema", "ok": not bad, "where": "sql"}]}
        if bad:
            return {"findings": [{"path": p, "severity": "high", "kind": "convention", "message": "literal schema core_ikg used",
                                  "suggestion": "use {{params.IKG_SCHEMA}}"} for p in bad],
                    "requirements_coverage": [{"requirement": "summary table", "covered": True, "where": "sql"}],
                    "score": 70, "verdict": "fix_required", "summary": "fix the literal schema", **extra}
        return {"findings": [{"path": next(iter(t.get("files", {})), ""), "severity": "low", "kind": "style", "message": "add a comment on the distribution key", "suggestion": ""}],
                "requirements_coverage": [{"requirement": "summary table", "covered": True, "where": "sql"}],
                "score": 92, "verdict": "approve", "summary": "requirements covered, conventions respected", **extra}

    def _change_agent(self, t):
        files = list(t.get("current_files", {}))
        sql = next((f for f in files if f.endswith(".sql")), files[0] if files else "new.sql")
        return {"understanding": "add a filter on balance > 0", "reply": "I will add the balance filter to the SQL.",
                "changes": [{"path": sql, "action": "modify", "language": "sql", "purpose": "summary", "instructions": ["add 'and a.balance > 0' to the where clause"]}],
                "needs_clarification": False, "question": ""}


# ----------------------------------------------------------------------------- sample inputs
def make_sample_inputs(folder: Path) -> dict:
    """Writes the sample story, knowledge files, a sqlite database and a tiny repository; returns their paths."""
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "story.md").write_text("# Story 1234: Client activity summary\n\nAs an analyst I need a daily table "
                                     "`client_activity_summary` with one row per client and the total balance of active accounts "
                                     "(status_cd = 'A'), keyed by the statement household acc_mhh_n.\n\nAcceptance criteria:\n"
                                     "- row count equals distinct clients with active accounts\n- scheduled daily in Airflow\n\n"
                                     "Query given by the analyst:\n```sql\nselect client_id, sum(balance) as total_balance from account_fact "
                                     "where status_cd = 'A' group by client_id\n```\n", encoding="utf-8")
    (folder / "skills.md").write_text("# Skills\n\n## Active account\nAn account is active when status_cd = 'A'.\n\n## Statement household\n"
                                      "acc_mhh_n = statement household number, sourced from household_plus.\n", encoding="utf-8")
    (folder / "glossary.csv").write_text("term,definition\nacc_mhh_n,statement household number\nbalance,end of day balance in USD\n", encoding="utf-8")
    (folder / "standards.yaml").write_text("rules:\n  - schema names must be parameters ({{params.IKG_SCHEMA}}), never literals such as core_ikg\n"
                                           "  - every SQL file starts with a header comment\n  - tables are suffixed _ikg\n", encoding="utf-8")
    db = folder / "sample_gp.db"
    if not db.exists():
        con = sqlite3.connect(db)
        con.executescript("""create table account_fact(account_id integer, client_id integer, balance real, status_cd text, as_of_date text);
                             create table client_dim(client_id integer, client_name text, acc_mhh_n text);
                             insert into account_fact values (1,10,100.5,'A','2026-10-01'),(2,10,50,'C','2026-10-01'),(3,11,20,'A','2026-10-01');
                             insert into client_dim values (10,'Ann','H1'),(11,'Bob','H2');""")
        con.commit()
        con.close()
    repo = folder / "repo"
    (repo / "dags/ikg/scripts/sql/ikg_create_profiles").mkdir(parents=True, exist_ok=True)
    (repo / "dags/ikg/dags").mkdir(parents=True, exist_ok=True)
    (repo / "dags/ikg/scripts/sql/ikg_create_profiles/household_profile_curr_ikg.sql").write_text(
        "-- story: household profile\ndrop table if exists {{params.IKG_SCHEMA}}.household_profile_curr_ikg;\n"
        "create table {{params.IKG_SCHEMA}}.household_profile_curr_ikg as select acc_mhh_n, count(*) as accounts from "
        "{{params.IKG_SCHEMA}}.account_fact group by acc_mhh_n distributed by (acc_mhh_n);\n", encoding="utf-8")
    (repo / "dags/ikg/scripts/sql/ikg_create_profiles/account_profile_curr_ikg.sql").write_text(
        "-- story: account profile\ncreate table {{params.IKG_SCHEMA}}.account_profile_curr_ikg as select account_id from {{params.IKG_SCHEMA}}.account_fact;\n", encoding="utf-8")
    (repo / "dags/ikg/dags/ikg_data_refresh.py").write_text(
        "from airflow import DAG\nfrom datetime import datetime\nfrom airflow.providers.postgres.operators.postgres import PostgresOperator\n"
        "with DAG(dag_id='ikg_data_refresh', schedule='0 5 * * *', start_date=datetime(2026,1,1), catchup=False) as dag:\n"
        "    household_profile = PostgresOperator(task_id='household_profile_curr_ikg', sql='scripts/sql/ikg_create_profiles/household_profile_curr_ikg.sql')\n"
        "    account_profile = PostgresOperator(task_id='account_profile_curr_ikg', sql='scripts/sql/ikg_create_profiles/account_profile_curr_ikg.sql')\n", encoding="utf-8")
    return {"story": folder / "story.md", "skills": folder / "skills.md", "glossary": folder / "glossary.csv",
            "standards": folder / "standards.yaml", "db": db, "repo": repo}


def run_selftest(cfg, out: Path, verbose: bool = True) -> dict:
    from .engine import ChatSession
    from .greenplum import GreenplumInput
    from .inputs import SessionInputs
    out = Path(out)
    paths = make_sample_inputs(out / "samples")
    llm = ScriptedLLM(cfg, out / "cache")
    chat = ChatSession(cfg, llm, out / "chat", "tester", "selftest", on_event=(lambda e: print(f"  {e['ts']} [{e['type']}] {e['title']}")) if verbose else None)
    chat.set_story_from_file("story.md", paths["story"].read_bytes())
    chat.add_documents("skills", [("skills.md", paths["skills"].read_bytes())])
    chat.add_documents("glossary", [("glossary.csv", paths["glossary"].read_bytes())])
    chat.add_documents("standards", [("standards.yaml", paths["standards"].read_bytes())])
    gp = GreenplumInput("", 0, "", "", "", sqlite_path=str(paths["db"]))
    chat.add_tables(gp, "main", ["account_fact", "client_dim"])
    chat.add_query(gp, "select client_id, sum(balance) as bal from account_fact group by client_id", "balances")
    rec = chat.inputs.add_repo("ikg-dags", "https://example.local/ikg/ikg-dags", "ikg-master", paths["repo"], cfg.inputs.repo)
    chat.event("input", f"repository ikg-dags: {rec['files']} files", kind="repo")
    t0 = time.time()
    summary = chat.run("use Greenplum SQL; one row per client")
    assert chat.files, "no files generated"
    assert all("core_ikg." not in f["content"] for f in chat.files.values()), "the fix round did not remove the literal schema"
    assert chat.review.get("verdict") in ("approve", "fix_required"), chat.review
    assert (chat.folder / f"agiledev_{chat.inputs.story['id']}.zip").exists()
    ch = chat.change("also filter balance > 0")
    assert ch["changed"], ch
    br = chat.suggest_branch("https://example.local/ikg/ikg-dags")
    stats = llm.token_stats()
    res = {"files": list(chat.files), "quality": summary["quality_score"], "review": chat.review.get("verdict"), "branch": br,
           "seconds": round(time.time() - t0, 1), "llm_calls": llm.calls, "tokens_total": stats["total"]["total_tokens"],
           "agents": sorted(stats["by_agent"]), "zip": str(chat.folder / f"agiledev_{chat.inputs.story['id']}.zip")}
    if verbose:
        print(json.dumps(res, indent=1))
        print(llm.token_stats_text())
    return res
