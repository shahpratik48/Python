"""The specialist agents. Every one gets the SAME standard context pack and returns a JSON result that code validates.

  story_agent      story -> structured requirement (what, inputs, outputs, rules, acceptance, open questions)
  knowledge_agent  skills + glossary + standards -> definitions that matter here + machine-checkable rules
  data_agent       tables -> how each is used (grain, keys, joins, columns needed)
  repo_agent       repository -> where the change belongs, patterns to imitate, conventions observed
  planner_agent    -> the plan: files to create / modify (language, purpose, outline), steps
  coder_agent      one file (full content or edits for a large existing file)
  reviewer_agent   all files vs story + standards -> findings (severity) + score
  change_agent     a follow-up request in the chat -> which files change and how (then coder in fix mode)
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import List

from .base import Agent, obj, arr, S, I, B
from . import tools as T

PROMPTS = Path(__file__).resolve().parent.parent.parent / "prompts"


def _prompt(name: str) -> str:
    p = PROMPTS / f"{name}.md"
    return p.read_text(encoding="utf-8") if p.exists() else f"You are the {name}. Answer with JSON via submit_result."


SEVERITY = {"type": "string", "enum": ["critical", "high", "medium", "low", "info"]}


class StoryAgent(Agent):
    name = "story_agent"
    SCHEMA = obj({"summary": S, "goal": S, "functional_requirements": arr(S), "inputs": arr(S), "outputs": arr(S),
                  "business_rules": arr(S), "acceptance_criteria": arr(S), "non_functional": arr(S),
                  "open_questions": arr(S), "feature_name": S, "target_languages": arr(S)},
                 ["summary", "goal", "functional_requirements", "acceptance_criteria", "feature_name"])

    def __init__(self, ctx):
        super().__init__(ctx, T.knowledge_tools(ctx) + T.data_tools(ctx), self.SCHEMA, _prompt("story_agent"))

    def execute(self) -> dict:
        p = self.ctx.pack
        task = {"story": p["story"], "user_instructions": p.get("instructions", []), "inventory": p.get("inventory", {})}
        res = self.run(task, task_label="story")
        self.ctx.story = res
        return res


class KnowledgeAgent(Agent):
    name = "knowledge_agent"
    strict = False
    SCHEMA = obj({"definitions": arr(obj({"term": S, "definition": S, "source": S})),
                  "conventions": arr(obj({"rule": S, "source": S, "applies_to": S})),
                  "rules": arr(obj({"id": S, "pattern": S, "must_match": B, "severity": SEVERITY, "message": S, "languages": arr(S)})),
                  "notes_for_coder": arr(S)}, ["definitions", "conventions", "rules"])

    def __init__(self, ctx):
        super().__init__(ctx, T.knowledge_tools(ctx), self.SCHEMA, _prompt("knowledge_agent"))

    def ground(self, r, task):
        ok = []
        for rule in r.get("rules", []):
            try:
                re.compile(rule.get("pattern", ""))
                ok.append(rule)
            except re.error:
                continue
        r["rules"] = ok
        return r, []

    def execute(self) -> dict:
        p = self.ctx.pack
        if not (p.get("skills") or p.get("glossary") or p.get("standards")):
            self.ctx.knowledge = {"definitions": [], "conventions": [], "rules": [], "notes_for_coder": [], "skipped": "no knowledge documents"}
            return self.ctx.knowledge
        task = {"story_summary": self.ctx.story.get("summary", ""), "feature": self.ctx.story.get("feature_name", ""),
                "requirements": self.ctx.story.get("functional_requirements", []),
                "target_languages": self.ctx.story.get("target_languages", []),
                "skills_excerpt": p.get("skills", "")[:30000], "glossary_excerpt": p.get("glossary", "")[:20000],
                "standards_excerpt": p.get("standards", "")[:30000]}
        res = self.run(task, task_label="knowledge")
        self.ctx.knowledge = res
        self.ctx.rules = res.get("rules", [])
        return res


class DataAgent(Agent):
    name = "data_agent"
    strict = False
    SCHEMA = obj({"tables": arr(obj({"table": S, "role": S, "grain": S, "keys": arr(S), "columns_needed": arr(S), "notes": S})),
                  "joins": arr(S), "data_rules": arr(S), "sql_dialect": S}, ["tables"])

    def __init__(self, ctx):
        super().__init__(ctx, T.data_tools(ctx) + T.knowledge_tools(ctx), self.SCHEMA, _prompt("data_agent"))

    def execute(self) -> dict:
        if not self.ctx.inputs.tables and not self.ctx.inputs.queries:
            self.ctx.data = {"tables": [], "joins": [], "data_rules": [], "skipped": "no tables"}
            return self.ctx.data
        task = {"story_summary": self.ctx.story.get("summary", ""), "requirements": self.ctx.story.get("functional_requirements", []),
                "tables": self.ctx.pack.get("tables", "")[:30000]}
        self.ctx.data = self.run(task, task_label="data")
        return self.ctx.data


class RepoAgent(Agent):
    name = "repo_agent"
    strict = False
    SCHEMA = obj({"where_the_change_belongs": arr(obj({"repo": S, "folder": S, "reason": S})),
                  "patterns_to_imitate": arr(obj({"path": S, "why": S})),
                  "conventions_observed": arr(S), "existing_files_to_modify": arr(obj({"path": S, "why": S})),
                  "reusable_functions": arr(S)}, ["where_the_change_belongs", "patterns_to_imitate", "conventions_observed"])

    def __init__(self, ctx):
        super().__init__(ctx, T.repo_tools(ctx) + T.knowledge_tools(ctx), self.SCHEMA, _prompt("repo_agent"))

    def ground(self, r, task):
        known = {f["path"] for rp in self.ctx.pack.get("repos", []) for f in rp.get("relevant_files", [])}
        for idx in self.ctx.inputs.indexes():
            known |= set(idx.files)
        for k in ("patterns_to_imitate", "existing_files_to_modify"):
            r[k] = [x for x in r.get(k, []) if x.get("path") in known]
        return r, []

    def execute(self) -> dict:
        if not self.ctx.inputs.repos:
            self.ctx.repo = {"where_the_change_belongs": [], "patterns_to_imitate": [], "conventions_observed": [],
                             "existing_files_to_modify": [], "skipped": "no repository"}
            return self.ctx.repo
        repos = [{"name": rp["name"], "summary": rp["summary"], "relevant_files": [{"path": f["path"], "language": f["language"],
                  "excerpt": f["content"][:2500]} for f in rp["relevant_files"]]} for rp in self.ctx.pack.get("repos", [])]
        task = {"story_summary": self.ctx.story.get("summary", ""), "feature": self.ctx.story.get("feature_name", ""),
                "requirements": self.ctx.story.get("functional_requirements", []), "repos": repos}
        self.ctx.repo = self.run(task, task_label="repo")
        return self.ctx.repo


class PlannerAgent(Agent):
    name = "planner_agent"
    SCHEMA = obj({"approach": S,
                  "files": arr(obj({"path": S, "action": {"type": "string", "enum": ["create", "modify"]}, "language": S,
                                    "purpose": S, "outline": arr(S), "depends_on": arr(S), "repo": S}, ["path", "action", "language", "purpose", "outline"])),
                  "steps": arr(S), "test_plan": arr(S), "risks": arr(S), "questions": arr(S)},
                 ["approach", "files", "steps"])

    def __init__(self, ctx):
        super().__init__(ctx, T.all_tools(ctx), self.SCHEMA, _prompt("planner_agent"))

    def ground(self, r, task):
        errs = []
        langs = {l.lower() for l in (self.ctx.cfg.get("generation", {}).get("languages") or [])}
        max_files = int(self.ctx.cfg.get("generation", {}).get("max_files", 30))
        seen = set()
        files = []
        for f in r.get("files", []):
            if f["path"] in seen:
                continue
            seen.add(f["path"])
            f["language"] = f.get("language", "").lower()
            if langs and f["language"] not in langs:
                f["language"] = _guess_lang(f["path"]) or f["language"]
            if f["action"] == "modify":
                exists = any(f["path"] in idx.files for idx in self.ctx.inputs.indexes())
                if not exists:
                    errs.append(f"{f['path']}: action modify but the file does not exist in the repository - use create or an existing path")
                    continue
            files.append(f)
        if not files:
            errs.append("the plan has no files")
        if len(files) > max_files:
            errs.append(f"too many files ({len(files)} > {max_files}) - merge or drop the least important")
        r["files"] = files[:max_files]
        return r, errs

    def execute(self) -> dict:
        task = {"story": self.ctx.story, "knowledge": _trim(self.ctx.knowledge), "data": _trim(self.ctx.data),
                "repo": _trim(self.ctx.repo), "user_instructions": self.ctx.pack.get("instructions", []),
                "allowed_languages": self.ctx.cfg.get("generation", {}).get("languages", [])}
        self.ctx.plan = self.run(task, task_label="plan")
        return self.ctx.plan


class CoderAgent(Agent):
    name = "coder_agent"
    SCHEMA = obj({"path": S, "language": S, "content": S, "edits": arr(obj({"find": S, "replace": S}, ["find", "replace"])),
                  "explanation": S, "assumptions": arr(S), "confidence": I}, ["path", "language", "explanation"])

    def __init__(self, ctx):
        super().__init__(ctx, T.all_tools(ctx), self.SCHEMA, _prompt("coder_agent"))

    def ground(self, r, task):
        errs = []
        mode = task.get("mode")
        existing = task.get("existing_content")
        if r.get("edits"):
            if existing is None:
                errs.append("edits given but there is no existing file - return full content")
            else:
                new = existing
                for e in r["edits"]:
                    if e["find"] not in new:
                        errs.append(f"edit anchor not found verbatim in the file: {e['find'][:80]!r}")
                        continue
                    new = new.replace(e["find"], e["replace"], 1)
                if not errs:
                    r["content"] = new
        if not r.get("content", "").strip():
            errs.append("content is empty")
        if r.get("content") and task.get("path") and r.get("path") != task.get("path"):
            r["path"] = task["path"]
        from ..validators import validate_file
        if r.get("content") and not errs:
            fnd = [f for f in validate_file(r["path"], r["content"], r.get("language", ""), self.ctx.rules)
                   if f["severity"] in ("critical", "high") and f["kind"] in ("syntax",)]
            errs += [f"{f['kind']}: {f['message']}" + (f" (line {f['line']})" if f.get("line") else "") for f in fnd[:8]]
        if mode == "fix" and r.get("content") == existing:
            errs.append("fix mode: the content is unchanged - apply the findings")
        return r, errs

    def write(self, spec: dict, existing_content=None, mode: str = "create", findings: List[dict] = None, request: str = "") -> dict:
        big = existing_content is not None and len(existing_content) > int(self.ctx.cfg.get("generation", {}).get("edits_above_chars", 40000))
        task = {"mode": mode, "path": spec["path"], "language": spec.get("language", ""), "purpose": spec.get("purpose", ""),
                "outline": spec.get("outline", []), "repo": spec.get("repo", ""),
                "story": {k: self.ctx.story.get(k) for k in ("summary", "goal", "functional_requirements", "business_rules", "acceptance_criteria")},
                "knowledge": _trim(self.ctx.knowledge), "data": _trim(self.ctx.data), "repo_guidance": _trim(self.ctx.repo),
                "plan_files": [{"path": f["path"], "purpose": f["purpose"]} for f in self.ctx.plan.get("files", [])],
                "user_instructions": self.ctx.pack.get("instructions", []),
                "other_generated_files": {p: v["content"][:3000] for p, v in self.ctx.files.items() if p != spec["path"]},
                "existing_content": existing_content if (existing_content is not None and not big) else None,
                "existing_file_is_large": big, "existing_head": existing_content[:6000] if big else None,
                "findings_to_fix": findings or [], "change_request": request,
                "output_rule": ("return `edits` [{find, replace}] with small UNIQUE anchors copied verbatim" if big else "return the complete file in `content`")}
        if mode == "fix" and big:
            task["existing_content"] = None
        r = self.run(task, task_label=f"{mode} {spec['path']}")
        if big and existing_content is not None and r.get("edits") and not r.get("content"):
            new = existing_content
            for e in r["edits"]:
                new = new.replace(e["find"], e["replace"], 1)
            r["content"] = new
        return r


class ReviewerAgent(Agent):
    name = "reviewer_agent"
    strict = False
    SCHEMA = obj({"findings": arr(obj({"path": S, "severity": SEVERITY, "kind": S, "message": S, "suggestion": S}, ["path", "severity", "message"])),
                  "requirements_coverage": arr(obj({"requirement": S, "covered": B, "where": S})),
                  "score": I, "verdict": {"type": "string", "enum": ["approve", "fix_required", "reject"]}, "summary": S},
                 ["findings", "score", "verdict", "summary"])

    def __init__(self, ctx):
        super().__init__(ctx, T.all_tools(ctx), self.SCHEMA, _prompt("reviewer_agent"))

    def execute(self, validator_findings: List[dict]) -> dict:
        files = {p: v["content"][:25000] for p, v in self.ctx.files.items()}
        task = {"story": self.ctx.story, "knowledge": _trim(self.ctx.knowledge), "data": _trim(self.ctx.data),
                "plan": {"approach": self.ctx.plan.get("approach"), "files": [{"path": f["path"], "purpose": f["purpose"]} for f in self.ctx.plan.get("files", [])]},
                "files": files, "validator_findings": validator_findings[:60],
                "user_instructions": self.ctx.pack.get("instructions", [])}
        self.ctx.review = self.run(task, task_label="review", use_cache=False)
        return self.ctx.review


class ChangeAgent(Agent):
    name = "change_agent"
    SCHEMA = obj({"understanding": S, "changes": arr(obj({"path": S, "action": {"type": "string", "enum": ["create", "modify", "delete"]},
                                                        "language": S, "purpose": S, "instructions": arr(S)}, ["path", "action", "instructions"])),
                  "reply": S, "needs_clarification": B, "question": S}, ["understanding", "changes", "reply"])

    def __init__(self, ctx):
        super().__init__(ctx, T.all_tools(ctx), self.SCHEMA, _prompt("change_agent"))

    def execute(self, request: str, history: List[dict]) -> dict:
        task = {"request": request, "recent_conversation": history[-8:],
                "story": {k: self.ctx.story.get(k) for k in ("summary", "goal")},
                "current_files": {p: {"language": v.get("language"), "purpose": v.get("purpose"), "head": v["content"][:1500]} for p, v in self.ctx.files.items()},
                "plan_files": [{"path": f["path"], "purpose": f["purpose"], "language": f.get("language")} for f in self.ctx.plan.get("files", [])]}
        return self.run(task, task_label="change", use_cache=False)


def _trim(d: dict, n: int = 12000) -> dict:
    s = json.dumps(d, ensure_ascii=False, default=str)
    if len(s) <= n:
        return d
    return json.loads(s[:n].rsplit(",", 1)[0] + "}") if s[:n].rstrip().endswith("}") else {"_truncated": s[:n]}


def _guess_lang(path: str) -> str:
    from ..validators import language_of
    return language_of(path)
