"""Change-impact analysis - deterministic (no model call), scoped to the systems whose knowledge packs are attached.

For every file the plan creates / modifies (and, after generation, for the generated code itself):
  * what it WRITES and READS: tables (SQL parsed by pattern), SQL files a DAG / Python file runs, columns added / removed
  * UPSTREAM  - for each table it reads: the script that builds it and the DAG that runs that script (the new task must run
                after it)
  * DOWNSTREAM - for each table it writes: the scripts reading it (2 hops) - a removed / renamed column is checked against
                each reader's text; a dropped table against every reader
  * NEW TABLES - who will read it: if nothing in the plan or the repository reads a new (non-temp) table it is an ORPHAN and
                the candidate consumers are proposed (profile tables at the same grain + the script that builds each)
  * CROSS-SYSTEM (only when that system's pack is attached): IKG feature -> ODM rules using it (ODM pack attached) ->
                NLG narratives using it (NLG pack attached); an ODM rule -> its NLG narrative (NLG pack attached)
Tables that are not in any attached pack are reported as outside the analysed scope, not guessed.
Every item says whether the plan already covers it (the affected file is part of the change set)."""
from __future__ import annotations

import re
from typing import Dict, List, Optional, Set

_NAME = r'([A-Za-z_{}\[\]"][\w{}\[\]".$]*)'
_WRITE = [(re.compile(r"(?is)\bcreate\s+(?:or\s+replace\s+)?(?:(temp|temporary|unlogged)\s+)?(?:table|view)\s+(?:if\s+not\s+exists\s+)?" + _NAME), "create"),
          (re.compile(r"(?is)\binsert\s+into\s+" + _NAME), "insert"),
          (re.compile(r"(?is)\balter\s+table\s+(?:if\s+exists\s+)?(?:only\s+)?" + _NAME), "alter"),
          (re.compile(r"(?is)\btruncate\s+(?:table\s+)?" + _NAME), "truncate"),
          (re.compile(r"(?is)\bdrop\s+(?:table|view)\s+(?:if\s+exists\s+)?" + _NAME), "drop")]
_READ = re.compile(r"(?is)\b(?:from|join)\s+" + _NAME)
_CTE = re.compile(r"(?is)(?:\bwith|,)\s*(?:recursive\s+)?(\w+)\s+as\s*\(")
_ALIAS = re.compile(r"(?is)\bas\s+\"?([a-z_][a-z0-9_]*)\"?\s*(?:,|\n|$|from\b)")
_SQLFILE = re.compile(r"""['"]([\w./{}-]+\.sql)['"]""")
_SKIP = {"select", "lateral", "unnest", "generate_series", "dual", "information_schema", "pg_catalog", "values", "the", "a", "each", "only"}
GRAIN_KEYS = [("acc_mhh_n", "household"), ("household_plus", "household"), ("ip_cli_i", "client"), ("client_id", "client"),
              ("acc_i", "account"), ("acc_n", "account"), ("account_id", "account")]


def short(name: str) -> str:
    n = re.sub(r'[{}"\[\]]', "", str(name or "")).strip().lower().rstrip(";,)")
    return n.rsplit(".", 1)[-1]


def sql_tables(text: str) -> dict:
    """{'writes': {short: kind}, 'reads': set(short), 'temp': set(short)} of a SQL text (CTE names left out)."""
    text = re.sub(r"--[^\n]*", " ", text or "")
    text = re.sub(r"(?s)/\*.*?\*/", " ", text)
    ctes = {m.group(1).lower() for m in _CTE.finditer(text)}
    writes, temp = {}, set()
    for rx, kind in _WRITE:
        for m in rx.finditer(text):
            nm = short(m.groups()[-1])
            if not nm or nm in _SKIP or nm in ctes:
                continue
            if kind == "create" and m.group(1):
                temp.add(nm)
            if kind == "drop" and nm in writes:          # drop-and-recreate is a rebuild, not a delete
                continue
            writes.setdefault(nm, kind)
    reads = {short(m.group(1)) for m in _READ.finditer(text)}
    reads = {r for r in reads if r and r not in ctes and r not in _SKIP and not r.startswith("(") and len(r) > 2}
    return {"writes": writes, "reads": reads - set(writes), "temp": temp}


def aliases(text: str) -> Set[str]:
    return {m.group(1).lower() for m in _ALIAS.finditer(re.sub(r"--[^\n]*", " ", text or ""))}


def grain_of(text: str) -> str:
    low = (text or "").lower()
    m = re.search(r"distributed\s+by\s*\(\s*\"?(\w+)", low)
    if m:
        for k, g in GRAIN_KEYS:
            if m.group(1) == k:
                return g
    for k, g in GRAIN_KEYS:
        if re.search(r"\b" + k + r"\b", low):
            return g
    for g in ("household", "client", "account"):
        if re.search(r"\b" + g, low):
            return g
    return ""


class _Scope:
    """The attached packs as one lookup: short table name -> (pack, full key, lineage)."""

    def __init__(self, packs):
        self.packs = list(packs)
        self.systems = sorted({p.system for p in self.packs})
        self.tables: Dict[str, list] = {}
        self.dag_of_sql: Dict[str, List[str]] = {}
        for pk in self.packs:
            for full, lin in (pk.structure.get("tables") or {}).items():
                self.tables.setdefault(short(full), []).append((pk, full, lin))
            for d in pk.dags():
                for s in d.get("sql_files_referenced") or []:
                    self.dag_of_sql.setdefault(s.strip("/"), []).append(d["path"])
                for f in d.get("folders_referenced") or []:
                    self.dag_of_sql.setdefault("folder:" + f.strip("/"), []).append(d["path"])

    def lineage(self, t: str):
        hits = self.tables.get(t) or []
        return hits[0] if hits else None

    def pack_of(self, path: str):
        for pk in self.packs:
            if path in (pk.structure.get("file_list") or {}):
                return pk
        return self.packs[0] if self.packs else None

    def dags_running(self, script: str) -> List[str]:
        out = list(self.dag_of_sql.get(script, []))
        folder = script.rsplit("/", 1)[0] if "/" in script else ""
        while folder and not out:
            out = list(self.dag_of_sql.get("folder:" + folder, []))
            folder = folder.rsplit("/", 1)[0] if "/" in folder else ""
        if not out:
            for pk in self.packs:
                reg = pk.registration(script.rsplit("/", 1)[0] if "/" in script else "")
                if reg.get("rule") and reg.get("rule") != "folder not in pack":
                    out.append(reg["rule"][:160])
                    break
        return sorted(set(out))[:3]

    def read(self, path: str) -> str:
        pk = self.pack_of(path)
        return pk.read(path) if pk is not None else ""

    def business(self):
        for pk in self.packs:
            try:
                b = pk.business()
            except Exception:  # noqa: BLE001
                continue
            if b.get("features") or b.get("rules"):
                return b
        return {}


def analyze(inputs, plan: dict, files: Optional[Dict[str, dict]] = None, story: Optional[dict] = None) -> dict:
    """Impact of the planned change (files=None: from the plan text) or of the generated code (files = path -> {content})."""
    packs = inputs.pack_objects() if inputs is not None else []
    if not packs:
        return {"scope": [], "items": [], "orphans": [], "note": "no knowledge pack attached: impact comes only from the repo agent's look-ups"}
    sc = _Scope(packs)
    plan_files = list((plan or {}).get("files") or [])
    planned = {f["path"] for f in plan_files} | {x.get("path") for x in (plan or {}).get("registration_changes") or [] if x.get("path")}
    story_txt = " ".join(str((story or {}).get(k, "")) for k in ("summary", "feature_name"))
    items: List[dict] = []
    orphans: List[dict] = []
    seen: Set[tuple] = set()

    def add(**kw):
        key = (kw.get("direction"), kw.get("table", ""), kw.get("affected", ""), kw.get("change", ""))
        if key not in seen:
            seen.add(key)
            kw.setdefault("covered", kw.get("affected") in planned if kw.get("affected") else None)
            items.append(kw)

    # ---- what each file writes / reads
    per_file = {}
    for f in plan_files:
        path = f["path"]
        content = ((files or {}).get(path) or {}).get("content")
        plan_text = " ".join([f.get("purpose", ""), f.get("where", ""), " ".join(f.get("outline") or [])])
        text = content if content is not None else plan_text
        lang = (f.get("language") or path.rsplit(".", 1)[-1]).lower()
        info = sql_tables(text) if (lang == "sql" or path.endswith(".sql")) else {"writes": {}, "reads": set(), "temp": set()}
        if f.get("action") == "modify":
            old = sc.read(path)
            if old and (lang == "sql" or path.endswith(".sql")):
                o = sql_tables(old)
                for t, k in o["writes"].items():
                    info["writes"].setdefault(t, k)
                if content is None:
                    info["reads"] |= o["reads"]
            info["old"] = old
        if content is None and not info["writes"] and f.get("action") == "create" and path.endswith(".sql"):
            info["writes"][path.rsplit("/", 1)[-1][:-4].lower()] = "create"       # a new SQL file builds the table it is named after
        info["text"], info["content"] = text, content
        info["sql_runs"] = set(_SQLFILE.findall(content or "")) if not path.endswith(".sql") else set()
        per_file[path] = info
    written_in_change = {t for i in per_file.values() for t in i["writes"]}
    mentioned_anywhere = " ".join((i["text"] or "") for i in per_file.values()).lower()

    for path, info in per_file.items():
        # ---- upstream: producers of what this file reads
        for t in sorted(info["reads"]):
            if t in written_in_change or t in info["temp"]:
                continue
            hit = sc.lineage(t)
            if hit is None:
                continue
            pk, full, lin = hit
            for prod in (lin.get("written_by") or [])[:2]:
                if prod == path:
                    continue
                dags = sc.dags_running(prod)
                add(direction="upstream", table=full, file=path, affected=prod, change="reads",
                    detail=f"{path} reads {full}, built by {prod}" + (f" (run by {', '.join(dags)})" if dags else "")
                           + " - the new / changed task must run after it", risk="info", covered=True, system=pk.system)
        # ---- downstream: readers of what this file writes
        for t, kind in sorted(info["writes"].items()):
            if t in info["temp"]:
                continue
            hit = sc.lineage(t)
            if hit is None:
                # a NEW table: who reads it?
                readers_in_plan = [p for p, i in per_file.items() if p != path and (t in i["reads"] or re.search(r"\b" + re.escape(t) + r"\b", (i["text"] or "").lower()))]
                if kind == "create" and not readers_in_plan:
                    orphans.append({"table": t, "file": path, "grain": grain_of(info["text"] + " " + story_txt),
                                    "candidates": _consumers(sc, t, grain_of(info["text"] + " " + story_txt), story_txt)})
                for r in readers_in_plan:
                    add(direction="downstream", table=t, file=path, affected=r, change="new table", covered=True, risk="info",
                        detail=f"new table {t} is read by {r} (part of this change)", system=sc.pack_of(path).system if sc.pack_of(path) else "")
                continue
            pk, full, lin = hit
            readers = [r for r in (lin.get("read_by") or []) if r != path]
            removed: Set[str] = set()
            added: Set[str] = set()
            if info.get("old") is not None and info.get("content") is not None:
                a_old, a_new = aliases(info["old"]), aliases(info["content"])
                removed = a_old - a_new                       # output columns (AS aliases) the new version no longer produces
                added = a_new - a_old
            if kind == "drop" and "create" not in (info["content"] or "").lower():
                for r in readers:
                    add(direction="downstream", table=full, file=path, affected=r, change="table dropped", risk="high", system=pk.system,
                        detail=f"{path} drops {full} which {r} reads")
                continue
            for r in readers[:12]:
                txt = sc.read(r).lower() if removed else ""
                hit_cols = sorted(c for c in removed if re.search(r"\b" + re.escape(c) + r"\b", txt))
                if hit_cols:
                    add(direction="downstream", table=full, file=path, affected=r, change="columns removed / renamed", risk="high", system=pk.system,
                        detail=f"{r} reads {', '.join(hit_cols)} of {full}, which {path} no longer produces")
                else:
                    star = bool(re.search(r"select\s+\*|\.\*", sc.read(r).lower())) if (added or removed) else False
                    add(direction="downstream", table=full, file=path, affected=r, system=pk.system,
                        change="schema extended" if added else "columns removed" if removed else "content changed",
                        risk="medium" if star else ("low" if (added or removed) else "info"),
                        detail=f"{r} reads {full}" + (f"; new column(s) {', '.join(sorted(added)[:8])} - " + ("it selects * so its own schema changes (history / archive copy?)" if star else "additive, not affected unless it should carry them")
                                                         if added else (f"; column(s) {', '.join(sorted(removed)[:8])} removed - " + ("it selects * so its own table loses them" if star else "it does not name them"))
                                                         if removed else " - check the result it reads still has the same grain / meaning"))
                    # second hop: tables built by that reader
                    for t2 in (pk.structure.get("script_tables") or {}).get(r, [])[:3]:
                        l2 = (pk.structure.get("tables") or {}).get(t2) or {}
                        if r in (l2.get("written_by") or []):
                            for r2 in (l2.get("read_by") or [])[:4]:
                                add(direction="downstream (2nd hop)", table=t2, file=r, affected=r2, change="via " + r, risk="info", system=pk.system,
                                    detail=f"{r2} reads {t2}, built by {r} (a reader of {full})")
            # ---- cross-system, only inside the attached packs
            if removed:
                _business_impact(sc, removed, path, add)
        # ---- a DAG / Python file that runs SQL files: they must exist
        for s in info["sql_runs"]:
            s2 = s.strip("/")
            if s2 not in planned and not any(s2 in (pk.structure.get("file_list") or {}) for pk in sc.packs) and not any(s2.endswith(p) for p in planned):
                add(direction="downstream", table="", file=path, affected=s2, change="runs a SQL file", risk="medium",
                    detail=f"{path} runs {s2}, which is neither in the repository nor in the plan", covered=False)
        # ---- ODM rule changed: its NLG narrative (only when the NLG pack is attached)
        m = re.search(r"/(si_[\w]+)\.sql$", path)
        if m and "nlg" in sc.systems:
            r = (sc.business().get("rules") or {}).get(m.group(1).lower()) or {}
            nf = (r.get("nlg") or {}).get("file")
            if nf:
                add(direction="downstream (NLG)", table=m.group(1), file=path, affected=nf, change="ODM rule changed", risk="medium", system="nlg",
                    detail=f"narrative {nf} renders {m.group(1)}: its placeholders must still be produced")

    out_scope = sorted({t for i in per_file.values() for t in list(i["reads"]) + list(i["writes"])
                        if sc.lineage(t) is None and t not in written_in_change and t not in i["temp"]})[:30]
    order = {"high": 0, "medium": 1, "low": 2, "info": 3}
    items.sort(key=lambda x: (x.get("covered") is True, order.get(x.get("risk"), 4), x.get("direction", ""), x.get("table", "")))
    open_items = [x for x in items if x.get("risk") in ("high", "medium") and x.get("covered") is False]
    return {"scope": sc.systems, "items": items[:120], "orphans": orphans, "outside_scope": out_scope,
            "summary": {"upstream": sum(1 for x in items if x["direction"] == "upstream"),
                        "downstream": sum(1 for x in items if x["direction"].startswith("downstream")),
                        "not_covered": len(open_items), "orphans": len(orphans)},
            "note": f"impact inside the attached pack(s) {', '.join(s.upper() for s in sc.systems)} only"
                    + ("" if {"odm", "nlg"} <= set(sc.systems) else
                       "; " + " and ".join(s.upper() for s in ("odm", "nlg") if s not in sc.systems) + " not attached: their rules / narratives are not checked")}


def _consumers(sc: _Scope, table: str, grain: str, story_txt: str) -> List[dict]:
    """Where a new table is normally used: the profile tables at its grain, closest by name / story words first."""
    words = set(re.findall(r"[a-z]{3,}", (table + " " + story_txt).lower())) - {"profile", "curr", "ikg", "table", "new"}
    out = []
    for t, hits in sc.tables.items():
        if "profile_curr" not in t:
            continue
        if grain and not t.startswith(grain):
            continue
        pk, full, lin = hits[0]
        score = len(words & set(re.findall(r"[a-z]{3,}", t))) * 3 + (2 if t == f"{grain}_profile_curr_ikg" else 0) + min(len(lin.get("read_by") or []), 3)
        out.append((score, t, full, (lin.get("written_by") or [""])[0]))
    out.sort(key=lambda x: (-x[0], x[1]))
    return [{"table": full, "built_by": by, "how": f"LEFT JOIN {table} on the {grain or 'grain'} key in {by or 'its script'} and add the new columns"}
            for _, _, full, by in out[:3]]


def _business_impact(sc: _Scope, columns: Set[str], path: str, add) -> None:
    b = sc.business()
    if not b:
        return
    feats, rules = b.get("features") or {}, b.get("rules") or {}
    for c in sorted(columns):
        f = feats.get(c)
        if not f:
            continue
        for rid in (f.get("used_by") or [])[:15]:
            r = rules.get(rid) or {}
            if "odm" in sc.systems and (r.get("odm") or {}).get("file"):
                add(direction="downstream (ODM)", table=c, file=path, affected=r["odm"]["file"], change="feature removed / renamed", risk="high", system="odm",
                    detail=f"business rule {rid} uses feature {c}")
            if "nlg" in sc.systems and (r.get("nlg") or {}).get("file") and c in ((r.get("nlg") or {}).get("placeholders") or []):
                add(direction="downstream (NLG)", table=c, file=path, affected=r["nlg"]["file"], change="feature removed / renamed", risk="high", system="nlg",
                    detail=f"narrative of {rid} shows <{c}>")


def for_reviewer(result: dict, k: int = 10) -> dict:
    """Only what still needs a decision: open high / medium items and orphans (short) - the rest stays in impact.json / the UI."""
    open_items = [{x_k: x.get(x_k) for x_k in ("direction", "affected", "risk", "detail")} for x in (result.get("items") or [])
                  if x.get("covered") is False and x.get("risk") in ("high", "medium")][:k]
    orph = [{"table": o["table"], "file": o["file"], "usual_consumers": [c["table"] for c in o.get("candidates") or []][:3]} for o in (result.get("orphans") or [])[:3]]
    return {"scope": result.get("scope"), "open_items": open_items, "new_tables_nobody_reads": orph}


def plan_errors(result: dict) -> List[str]:
    """What the planner must still decide (one fix round): orphan tables and uncovered high-risk consumers."""
    errs = []
    for o in result.get("orphans") or []:
        cands = "; ".join(f"{c['table']} (built by {c['built_by']})" for c in o.get("candidates") or []) or "none found at this grain"
        errs.append(f"IMPACT: new table {o['table']} ({o['file']}) is read by no file of the plan and nothing in the repository - a feature "
                    f"table nobody joins never reaches a profile / rule. Grain {o.get('grain') or 'unknown'}; usual consumers: {cands}. "
                    "Plan the modify of the consumer's script (LEFT JOIN + the new columns, its history companion too), or put the "
                    "choice in questions with your default.")
    for x in result.get("items") or []:
        if x.get("risk") == "high" and x.get("covered") is False:
            errs.append(f"IMPACT: {x['detail']} - add {x['affected']} to the plan (modify) or keep the column / table")
    return errs[:4]
