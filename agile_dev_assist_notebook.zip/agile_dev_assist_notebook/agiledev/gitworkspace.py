"""Real git for every chat: a feature branch checked out from the base branch, local commits per run, rebase + push + MR.

Layout
  data/cache/git/<project>.git                 ONE bare mirror per repository, shared by every user and chat (fetched with the
                                               read token; only the branches that are needed, full history for rebases)
  data/users/<user>/chats/<chat>/repos/<slug>  a `git worktree` of that mirror on the chat's feature branch (shares the object
                                               store: ~1 s and a few MB per branch, not a clone)
Rules
  * the feature branch is created LOCALLY from origin/<base> when the user declares it (that is the checkout); it is created on
    GitLab at the first push - no empty remote branches for abandoned chats
  * every run commits the generated files on the branch (the savepoint IS a commit: diff / history / revert)
  * push = fetch base -> rebase the branch on it -> re-author every commit to the token owner -> push -> merge request to the
    target branch via the API, under the same token. Nothing on GitLab is ever anonymous or attributed to a service account
  * the token is passed per git command (http.extraHeader) and never written to .git/config or disk
  * a mirror is updated under a lock; two chats never fetch the same mirror at once
"""
from __future__ import annotations

import base64
import logging
import os
import re
import shutil
import subprocess
import threading
import time
from pathlib import Path
from typing import Dict, List, Optional

from .gitclient import parse_project_url

log = logging.getLogger("agiledev.gitws")
_LOCKS: Dict[str, threading.Lock] = {}
_LOCKS_GUARD = threading.Lock()


def _lock(key: str) -> threading.Lock:
    with _LOCKS_GUARD:
        return _LOCKS.setdefault(key, threading.Lock())


def slug_of(project_url: str) -> str:
    info = parse_project_url(project_url)
    return re.sub(r"[^a-z0-9._-]+", "-", (info.get("project") or project_url).lower()).strip("-")[:100]


class GitWorkspace:
    def __init__(self, cfg, mirrors_dir: Path):
        self.cfg = cfg
        self.mirrors = Path(mirrors_dir).resolve()
        self.mirrors.mkdir(parents=True, exist_ok=True)
        self.git = shutil.which("git")
        if not self.git:
            raise RuntimeError("git is not installed on this host - feature branches need the git command")
        g = cfg.get("git", {}) if hasattr(cfg, "get") else {}
        self.verify = g.get("ssl_verify", True)
        self.provider = g.get("default_provider", "gitlab")
        self.depth = int(g.get("mirror_depth", 0) or 0)                 # 0 = full history of the fetched branches

    # ------------------------------------------------------------------ plumbing
    def _args(self, token: str) -> List[str]:
        args = ["-c", "credential.helper=", "-c", "core.quotepath=false"]
        if token:
            who = "x-access-token" if self.provider == "github" else "oauth2"
            args += ["-c", "http.extraHeader=Authorization: Basic " + base64.b64encode(f"{who}:{token}".encode()).decode()]
        if self.verify is False:
            args += ["-c", "http.sslVerify=false"]
        elif isinstance(self.verify, str):
            args += ["-c", f"http.sslCAInfo={self.verify}"]
        return args

    def _run(self, *cmd, cwd: Optional[Path] = None, token: str = "", author: Optional[dict] = None, timeout: int = 600, ok_codes=(0,)) -> subprocess.CompletedProcess:
        env = dict(os.environ, GIT_TERMINAL_PROMPT="0", GIT_ASKPASS="", GIT_EDITOR="true", GIT_PAGER="cat", LC_ALL="C.UTF-8")
        if author:
            for k in ("AUTHOR", "COMMITTER"):
                env[f"GIT_{k}_NAME"] = str(author.get("name") or author.get("email") or "agile-dev-assist")
                env[f"GIT_{k}_EMAIL"] = str(author.get("email") or "noreply@invalid")
        r = subprocess.run([self.git, *self._args(token), *cmd], cwd=str(cwd) if cwd else None, env=env, capture_output=True, text=True, timeout=timeout)
        if r.returncode not in ok_codes:
            err = (r.stderr or r.stdout).strip()
            err = re.sub(r"Authorization: Basic \S+", "Authorization: Basic ***", err)
            raise RuntimeError(f"git {cmd[0]} failed: {err[-500:]}")
        return r

    def _remote_url(self, project_url: str) -> str:
        info = parse_project_url(project_url)
        return f"{info['web']}/{info['project']}.git"

    def mirror_path(self, project_url: str) -> Path:
        return self.mirrors / f"{slug_of(project_url)}.git"

    # ------------------------------------------------------------------ mirror
    def fetch(self, project_url: str, token: str, branches: List[str], progress=None) -> Path:
        """Bare mirror with the given branches up to date (origin/<branch> refs). Shared, locked, incremental."""
        say = progress or (lambda m: None)
        m = self.mirror_path(project_url)
        url = self._remote_url(project_url)
        with _lock(str(m)):
            if not (m / "HEAD").exists():
                if m.exists():
                    shutil.rmtree(m)
                say(f"git init mirror {m.name} ...")
                self._run("init", "--bare", str(m))
                self._run("remote", "add", "origin", url, cwd=m)
            refspecs = [f"+refs/heads/{b}:refs/remotes/origin/{b}" for b in dict.fromkeys(b for b in branches if b)]
            if refspecs:
                t0 = time.time()
                say(f"git fetch {', '.join(dict.fromkeys(b for b in branches if b))} ...")
                cmd = ["fetch", "--no-tags", "--prune"]
                if self.depth:
                    cmd += ["--depth", str(self.depth)]
                self._run(*cmd, "origin", *refspecs, cwd=m, token=token, timeout=1800)
                say(f"fetched in {time.time() - t0:.0f}s")
        return m

    def remote_branch_exists(self, project_url: str, token: str, branch: str) -> bool:
        r = self._run("ls-remote", "--heads", self._remote_url(project_url), f"refs/heads/{branch}", token=token, timeout=120)
        return bool(r.stdout.strip())

    # ------------------------------------------------------------------ worktree = the chat's checkout
    def checkout(self, project_url: str, token: str, base: str, feature: str, dest: Path, progress=None) -> dict:
        """Feature branch created locally from origin/<base> (or checked out from origin/<feature> when it already exists on
        the remote - resuming a branch), as a worktree at `dest`."""
        say = progress or (lambda m: None)
        m = self.fetch(project_url, token, [base], progress)
        dest = Path(dest).resolve()
        dest.parent.mkdir(parents=True, exist_ok=True)
        resumed = False
        if self.remote_branch_exists(project_url, token, feature):
            self.fetch(project_url, token, [feature], progress)
            resumed = True
        with _lock(str(m)):
            if dest.exists():
                self._run("worktree", "remove", "--force", str(dest), cwd=m, ok_codes=(0, 128))
                shutil.rmtree(dest, ignore_errors=True)
            self._run("worktree", "prune", cwd=m)
            start = f"refs/remotes/origin/{feature}" if resumed else f"refs/remotes/origin/{base}"
            say(f"git worktree add {feature} from {'origin/' + feature if resumed else 'origin/' + base} ...")
            # -B: (re)create the local branch at the start point - a stale local branch of a deleted chat is overwritten
            self._run("worktree", "add", "-B", feature, str(dest), start, cwd=m, token=token, timeout=1800)
        base_sha = self._run("rev-parse", f"refs/remotes/origin/{base}", cwd=m).stdout.strip()
        return {"path": str(dest), "mirror": str(m), "base_sha": base_sha[:12], "resumed": resumed, "head": self.head(dest)}

    def head(self, wt: Path) -> str:
        return self._run("rev-parse", "HEAD", cwd=wt).stdout.strip()[:12]

    def commit(self, wt: Path, files: Dict[str, str], message: str, author: dict) -> Optional[dict]:
        """Write the files into the worktree and commit them (author = the chat's user). None when nothing changed."""
        wt = Path(wt)
        for rel, content in files.items():
            p = wt / rel
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(content, encoding="utf-8")
        self._run("add", "-A", "--", *files.keys(), cwd=wt)
        st = self._run("status", "--porcelain", "--", *files.keys(), cwd=wt).stdout.strip()
        if not st:
            return None
        self._run("commit", "-q", "-m", message, cwd=wt, author=author)
        sha = self.head(wt)
        return {"sha": sha, "message": message.splitlines()[0][:120], "files": sorted(files), "at": time.strftime("%Y-%m-%d %H:%M:%S")}

    def log(self, wt: Path, base: str) -> dict:
        """Commits of the branch that are not on origin/<base> + the changed files."""
        wt = Path(wt)
        rng = f"refs/remotes/origin/{base}..HEAD"
        out = self._run("log", "--format=%h%x09%an%x09%ae%x09%ad%x09%s", "--date=short", rng, cwd=wt).stdout.strip().splitlines()
        commits = [dict(zip(("sha", "author", "email", "date", "message"), ln.split("\t", 4))) for ln in out if ln]
        files = self._run("diff", "--name-status", f"refs/remotes/origin/{base}...HEAD", cwd=wt).stdout.strip().splitlines()
        changed = [{"status": ln.split("\t")[0], "path": ln.split("\t")[-1]} for ln in files if ln]
        return {"commits": commits, "changed": changed, "head": self.head(wt)}

    def diff(self, wt: Path, base: str, path: str = "") -> str:
        args = ["diff", f"refs/remotes/origin/{base}...HEAD"]
        if path:
            args += ["--", path]
        return self._run(*args, cwd=Path(wt)).stdout

    def rebase(self, wt: Path, project_url: str, token: str, base: str, progress=None) -> dict:
        """Fetch base and rebase the branch on it. On conflict: abort, report the files - nothing is pushed."""
        self.fetch(project_url, token, [base], progress)
        wt = Path(wt)
        before = self.head(wt)
        r = self._run("rebase", f"refs/remotes/origin/{base}", cwd=wt, ok_codes=(0, 1, 128), timeout=900)
        if r.returncode != 0:
            conflicts = [ln[3:] for ln in self._run("status", "--porcelain", cwd=wt).stdout.splitlines() if ln[:2] in ("UU", "AA", "DU", "UD", "AU", "UA")]
            self._run("rebase", "--abort", cwd=wt, ok_codes=(0, 128))
            return {"ok": False, "conflicts": conflicts, "detail": (r.stderr or r.stdout).strip()[-400:]}
        return {"ok": True, "before": before, "after": self.head(wt)}

    def reauthor(self, wt: Path, base: str, author: dict) -> int:
        """Every commit of the branch gets the token owner as author AND committer - the push is never anonymous."""
        wt = Path(wt)
        n = len(self.log(wt, base)["commits"])
        if n:
            self._run("rebase", f"refs/remotes/origin/{base}", "--exec", "git commit --amend --no-edit --reset-author -q", cwd=wt, author=author, timeout=900)
        return n

    def push(self, wt: Path, project_url: str, token: str, feature: str) -> dict:
        wt = Path(wt)
        self._run("push", "--force-with-lease", "-u", self._remote_url(project_url), f"HEAD:refs/heads/{feature}", cwd=wt, token=token, timeout=900)
        return {"head": self.head(wt), "branch": feature}

    def conflict_preview(self, wt: Path, project_url: str, token: str, target: str, progress=None) -> dict:
        """Would the merge request into `target` conflict? (git merge-tree, no checkout)."""
        try:
            self.fetch(project_url, token, [target], progress)
            r = self._run("merge-tree", "--write-tree", "--name-only", f"refs/remotes/origin/{target}", "HEAD", cwd=Path(wt), ok_codes=(0, 1), timeout=300)
            if r.returncode == 1:
                files = [ln for ln in r.stdout.strip().splitlines()[1:] if ln.strip()]
                return {"conflicts": True, "files": files[:30]}
            return {"conflicts": False}
        except Exception as e:  # noqa: BLE001
            return {"conflicts": None, "detail": str(e)[:200]}

    def remove(self, wt: Path, mirror: Path, feature: str) -> None:
        wt, mirror = Path(wt), Path(mirror)
        with _lock(str(mirror)):
            try:
                self._run("worktree", "remove", "--force", str(wt), cwd=mirror, ok_codes=(0, 128))
                self._run("branch", "-D", feature, cwd=mirror, ok_codes=(0, 1, 128))
                self._run("worktree", "prune", cwd=mirror, ok_codes=(0, 128))
            except Exception as e:  # noqa: BLE001
                log.warning("worktree cleanup failed: %s", e)
        shutil.rmtree(wt, ignore_errors=True)
