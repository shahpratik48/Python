"""Dynamic inputs of one chat session, standardised to JSON.

    story      : one story (git issue, git file, uploaded file or pasted text)
    skills     : documents dragged onto the Skills icon
    glossary   : documents dragged onto the Glossary / data dictionary icon
    standards  : documents dragged onto the Standards & conventions icon
    tables     : Greenplum tables (introspected) + saved query results
    repos      : git repositories (downloaded with the user's token, indexed)

Everything here is serialisable (`to_json`) and saved in the chat folder; connection secrets are NOT part of it.
"""
from __future__ import annotations

import json
import logging
import re
import time
from pathlib import Path
from typing import Dict, List, Optional

from .readers import read_document, doc_summary
from .repoindex import RepoIndex

log = logging.getLogger(__name__)

KINDS = ("skills", "glossary", "standards")


def normalise_story(text: str, title: str = "", story_id: str = "", source: Optional[dict] = None,
                    extra: Optional[dict] = None) -> dict:
    text = (text or "").replace("\r\n", "\n").strip()
    if not title:
        first = next((l.strip("# ").strip() for l in text.splitlines() if l.strip()), "")
        title = first[:120] or "story"
    if not story_id:
        m = re.search(r"(?i)\b(?:story|issue|ticket|jira|#)\s*[-:#]?\s*([A-Z]{1,8}-\d{1,6}|\d{1,7})\b", title + " " + text[:500])
        story_id = m.group(1) if m else f"s{int(time.time()) % 1000000}"
    acc = []
    m = re.search(r"(?is)acceptance criteria\s*:?\s*\n(.*?)(?:\n#{1,6}\s|\n\n\n|$)", text)
    if m:
        acc = [re.sub(r"^[-*\d.)\s]+", "", l).strip() for l in m.group(1).splitlines() if l.strip()][:30]
    from .gitclient import extract_code_blocks
    s = {"id": str(story_id), "title": title, "text": text, "acceptance_criteria": acc,
         "code_blocks": extract_code_blocks(text, "story"), "source": source or {"type": "text"}, "chars": len(text)}
    if extra:
        s.update({k: v for k, v in extra.items() if k not in s})
    return s


class SessionInputs:
    def __init__(self, folder: Path):
        self.folder = Path(folder)
        self.folder.mkdir(parents=True, exist_ok=True)
        self.story: Optional[dict] = None
        self.docs: Dict[str, List[dict]] = {k: [] for k in KINDS}
        self.tables: List[dict] = []
        self.queries: List[dict] = []
        self.repos: List[dict] = []
        self.instructions: List[str] = []          # free-text instructions the user typed for the generation
        self._indexes: Dict[str, RepoIndex] = {}

    # ------------------------------------------------------------------ add
    def set_story(self, story: dict) -> dict:
        self.story = story
        self._save()
        return story

    def add_document(self, kind: str, name: str, data: bytes, max_chars: int = 120000) -> dict:
        if kind not in KINDS:
            raise ValueError(f"unknown document kind {kind}")
        doc = read_document(name, data, kind, max_chars)
        (self.folder / "inputs" / kind).mkdir(parents=True, exist_ok=True)
        (self.folder / "inputs" / kind / doc["name"]).write_bytes(data)
        self.docs[kind] = [d for d in self.docs[kind] if d["name"] != doc["name"]] + [doc]
        self._save()
        return doc_summary(doc)

    def remove_document(self, kind: str, name: str) -> None:
        self.docs[kind] = [d for d in self.docs.get(kind, []) if d["name"] != name]
        self._save()

    def add_table(self, t: dict) -> dict:
        self.tables = [x for x in self.tables if (x["schema"], x["table"]) != (t["schema"], t["table"])] + [t]
        self._save()
        return {"schema": t["schema"], "table": t["table"], "columns": len(t["columns"])}

    def add_query(self, q: dict) -> dict:
        q = dict(q, name=q.get("name") or f"query{len(self.queries) + 1}")
        self.queries.append(q)
        self._save()
        return {"name": q["name"], "columns": q["columns"], "row_count": q["row_count"]}

    def add_repo(self, name: str, url: str, branch: str, local_path: Path, cfg_repo: dict, info: Optional[dict] = None) -> dict:
        idx = RepoIndex(local_path, name, int(cfg_repo.get("max_files", 6000)))
        self._indexes[name] = idx
        rec = {"name": name, "url": url, "branch": branch, "path": str(local_path), "summary": idx.summary(),
               "info": info or {}}
        self.repos = [r for r in self.repos if r["name"] != name] + [rec]
        self._save()
        return {"name": name, "url": url, "branch": branch, "files": rec["summary"]["files"],
                "languages": rec["summary"]["languages"]}

    def index(self, name: str) -> Optional[RepoIndex]:
        if name not in self._indexes:
            rec = next((r for r in self.repos if r["name"] == name), None)
            if rec and Path(rec["path"]).exists():
                self._indexes[name] = RepoIndex(Path(rec["path"]), name)
        return self._indexes.get(name)

    def indexes(self) -> List[RepoIndex]:
        return [i for i in (self.index(r["name"]) for r in self.repos) if i is not None]

    def add_instruction(self, text: str) -> None:
        if text and text.strip():
            self.instructions.append(text.strip())
            self._save()

    # ------------------------------------------------------------------ persistence
    def to_json(self) -> dict:
        return {"story": self.story, "docs": self.docs, "tables": self.tables, "queries": self.queries,
                "repos": self.repos, "instructions": self.instructions}

    def _save(self) -> None:
        try:
            (self.folder / "inputs.json").write_text(json.dumps(self.to_json(), ensure_ascii=False, indent=1, default=str), encoding="utf-8")
        except Exception as e:  # noqa: BLE001
            log.warning("inputs not saved: %s", e)

    @classmethod
    def load(cls, folder: Path) -> "SessionInputs":
        s = cls(folder)
        f = Path(folder) / "inputs.json"
        if f.exists():
            try:
                d = json.loads(f.read_text(encoding="utf-8"))
                s.story = d.get("story")
                s.docs = {k: d.get("docs", {}).get(k, []) for k in KINDS}
                s.tables, s.queries, s.repos = d.get("tables", []), d.get("queries", []), d.get("repos", [])
                s.instructions = d.get("instructions", [])
            except Exception as e:  # noqa: BLE001
                log.warning("inputs.json unreadable: %s", e)
        return s

    def overview(self) -> dict:
        return {"story": ({"id": self.story["id"], "title": self.story["title"], "chars": self.story["chars"],
                           "source": self.story.get("source", {})} if self.story else None),
                "skills": [doc_summary(d) for d in self.docs["skills"]],
                "glossary": [doc_summary(d) for d in self.docs["glossary"]],
                "standards": [doc_summary(d) for d in self.docs["standards"]],
                "tables": [{"schema": t["schema"], "table": t["table"], "columns": len(t["columns"]), "kind": t.get("kind", "table")} for t in self.tables],
                "queries": [{"name": q["name"], "row_count": q["row_count"], "columns": q["columns"][:20]} for q in self.queries],
                "repos": [{"name": r["name"], "url": r["url"], "branch": r["branch"], "files": r["summary"]["files"],
                           "languages": r["summary"]["languages"]} for r in self.repos],
                "instructions": self.instructions}
