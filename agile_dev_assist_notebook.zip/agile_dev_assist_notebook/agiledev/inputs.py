"""Dynamic inputs of one chat session, standardised to JSON.

    story      : one story (git issue, git file, uploaded file or pasted text)
    knowledge  : documents dragged onto the Knowledge icon (skills, how-tos, standards & conventions - one kind)
                 - glossary / data dictionary files are knowledge too (detected by name: *gloss*, *dictionary*)
    packs      : System Knowledge Packs (<system>_pack.zip built nightly by the Knowledge Pack builder): pre-analysed, indexed
                 repository + tables + conventions of IKG / ODM / NLG. A pack brings its own repository copy and its tables.
    tables     : Greenplum tables (introspected) + saved query results (+ the pack's described tables)
    repos      : git repositories (downloaded with the user's token, indexed) (+ the pack's repository copy)

Everything here is serialisable (`to_json`) and saved in the chat folder; connection secrets are NOT part of it.
"""
from __future__ import annotations

import json
import logging
import re
import time
from pathlib import Path
from typing import Dict, List, Optional

from .readers import read_document, doc_summary
from .repoindex import RepoIndex

log = logging.getLogger(__name__)

KINDS = ("knowledge",)
_OLD_KINDS = {"skills": "knowledge", "standards": "knowledge", "glossary": "knowledge"}       # inputs saved by earlier versions
_GLOSS = re.compile(r"gloss|dictionary|data_dict|datadict|lexicon|abbrev", re.I)


def normalise_story(text: str, title: str = "", story_id: str = "", source: Optional[dict] = None,
                    extra: Optional[dict] = None) -> dict:
    text = (text or "").replace("\r\n", "\n").strip()
    if not title:
        first = next((l.strip("# ").strip() for l in text.splitlines() if l.strip()), "")
        title = first[:120] or "story"
    if not story_id:
        m = re.search(r"(?i)\b(?:story|issue|ticket|jira|#)\s*[-:#]?\s*([A-Z]{1,8}-\d{1,6}|\d{1,7})\b", title + " " + text[:500])
        story_id = m.group(1) if m else f"s{int(time.time()) % 1000000}"
    acc = []
    m = re.search(r"(?is)acceptance criteria\s*:?\s*\n(.*?)(?:\n#{1,6}\s|\n\n\n|$)", text)
    if m:
        acc = [re.sub(r"^[-*\d.)\s]+", "", l).strip() for l in m.group(1).splitlines() if l.strip()][:30]
    from .gitclient import extract_code_blocks
    s = {"id": str(story_id), "title": title, "text": text, "acceptance_criteria": acc,
         "code_blocks": extract_code_blocks(text, "story"), "source": source or {"type": "text"}, "chars": len(text)}
    if extra:
        s.update({k: v for k, v in extra.items() if k not in s})
    return s


class SessionInputs:
    def __init__(self, folder: Path):
        self.folder = Path(folder)
        self.folder.mkdir(parents=True, exist_ok=True)
        self.story: Optional[dict] = None
        self.docs: Dict[str, List[dict]] = {k: [] for k in KINDS}
        self.tables: List[dict] = []
        self.queries: List[dict] = []
        self.repos: List[dict] = []
        self.instructions: List[str] = []          # free-text instructions the user typed for the generation
        self.pipeline: List[str] = []              # agent order for the run (empty = default); edited in the UI
        self.packs: List[dict] = []                # knowledge packs: {name, system, version, built_at, path, counts, health, repo_name}
        self.git_defaults: Dict[str, str] = {}     # per-chat git conventions from the template: base_branch, mr_target, branch_template
        self.branches: List[dict] = []             # feature branches of this chat: {slug, system, repo_url, project, base, feature, target, path, mirror, commits, pushed}
        self._indexes: Dict[str, RepoIndex] = {}
        self._packs: Dict[str, object] = {}

    # ------------------------------------------------------------------ add
    def set_story(self, story: dict) -> dict:
        self.story = story
        self._save()
        return story

    def add_document(self, kind: str, name: str, data: bytes, max_chars: int = 120000) -> dict:
        kind = _OLD_KINDS.get(kind, kind)
        if kind not in KINDS:
            raise ValueError(f"unknown document kind {kind}")
        doc = read_document(name, data, "glossary" if _GLOSS.search(Path(name).name) else kind, max_chars)   # a glossary file is read row-wise
        (self.folder / "inputs" / kind).mkdir(parents=True, exist_ok=True)
        (self.folder / "inputs" / kind / doc["name"]).write_bytes(data)
        self.docs[kind] = [d for d in self.docs[kind] if d["name"] != doc["name"]] + [doc]
        self._save()
        return doc_summary(doc)

    def remove_document(self, kind: str, name: str) -> None:
        kind = _OLD_KINDS.get(kind, kind)
        self.docs[kind] = [d for d in self.docs.get(kind, []) if d["name"] != name]
        self._save()

    # ------------------------------------------------------------------ knowledge packs
    def add_pack(self, name: str, data: bytes, shared_dir: Path, emb_cfg: Optional[dict] = None, cfg_repo: Optional[dict] = None, progress=None) -> dict:
        """Attach a System Knowledge Pack zip. The zip is stored once under shared_dir (same content = same folder, so every
        chat / user shares one unpacked copy) and the chat keeps a reference. The pack's repository copy becomes a repository
        input (name = its repo_name, source 'pack') and its described tables become table inputs (source 'pack')."""
        import hashlib
        from .kpack.pack import Pack
        shared_dir = Path(shared_dir)
        shared_dir.mkdir(parents=True, exist_ok=True)
        digest = hashlib.sha256(data).hexdigest()[:16]
        zpath = shared_dir / f"{Path(name).stem}_{digest}.zip"
        if not zpath.exists():
            zpath.write_bytes(data)
        import os
        os.environ.setdefault("KPACK_UNZIP_DIR", str(shared_dir / "unzipped"))     # packs unpack under data/packs, shared by every chat
        say = progress or (lambda m: None)
        say(f"unpacking {name} ...")
        pk = Pack(zpath, emb_cfg=emb_cfg or {"enabled": False})
        pack_dir = pk.dir
        say(f"{pk.system} pack {pk.version}: {pk.manifest.get('counts', {}).get('items', 0)} indexed items loaded - indexing the repository copy ...")
        bc = {}
        try:
            import yaml
            bc = yaml.safe_load((pack_dir / "build_config.yaml").read_text(encoding="utf-8")) or {}
        except Exception:  # noqa: BLE001
            pass
        src = (bc.get("source") or {})
        repo_name = src.get("repo_name") or f"{pk.system}-repo"
        rec = {"name": Path(name).name, "system": pk.system, "version": pk.version, "built_at": pk.manifest.get("built_at"), "path": str(pack_dir),
               "zip": str(zpath), "counts": pk.manifest.get("counts", {}), "health": pk.manifest.get("health"), "repo_name": repo_name,
               "repo_url": (f"{src.get('gitlab_url', '').rstrip('/')}/{src.get('project_path', '')}" if src.get("project_path") else ""),
               "branch": pk.manifest.get("repo", {}).get("ref", ""), "dense_index": bool(pk.index.status.get("dense")),
               "model_layer": bool(pk.manifest.get("model_layer"))}
        self.packs = [x for x in self.packs if x["system"] != pk.system] + [rec]
        self._packs[pk.system] = pk
        # the pack's repository copy as a repository input (skipped in retrieval when a live clone of the same repo is added)
        raw = pack_dir / "raw" / "repo"
        if raw.is_dir():
            from .kpack.repo import PackRepoIndex
            br = self.branch_for_system(pk.system)
            root = Path(br["path"]) if br and Path(br["path"]).exists() else raw           # a checked-out feature branch is the live code; the pack keeps the facts
            idx = PackRepoIndex(pk, root, repo_name, int((cfg_repo or {}).get("max_files", 12000)))     # cached next to the copy: fast for the next chat / user
            say(f"repository copy {repo_name}: {len(idx.files)} files indexed - adding the described tables ...")
            self._indexes[repo_name] = idx
            self.repos = [r for r in self.repos if r["name"] != repo_name or not r.get("from_pack")] + \
                         [{"name": repo_name, "url": rec["repo_url"] or f"pack://{pk.system}", "branch": rec["branch"], "path": str(raw), "summary": idx.summary(),
                           "info": {"provider": "pack", "project": src.get("project_path", ""), "pack": pk.system, "version": pk.version}, "from_pack": pk.system}]
        # the pack's described tables as table inputs
        n_tables = 0
        for full, t in pk.tables_.items():
            if not t.get("described") or not t.get("columns"):
                continue
            sem = (pk.derived.get("data", {}).get("tables", {}) or {}).get(full, {})
            rec_t = {"schema": t.get("schema", ""), "table": t.get("table", ""), "columns": t.get("columns", []), "keys": t.get("keys", []),
                     "distribution": t.get("distribution", []), "comment": (sem.get("purpose") or t.get("description") or t.get("comment", "")),
                     "kind": t.get("kind", "table"), "row_estimate": t.get("row_estimate"),
                     "sample": t.get("sample") if isinstance(t.get("sample"), dict) else {"columns": [], "rows": []}, "source": "pack", "pack": pk.system,
                     "semantics": {k: sem.get(k) for k in ("purpose", "grain", "key_columns", "column_notes", "used_for") if sem.get(k)}}
            if not any((x["schema"], x["table"]) == (rec_t["schema"], rec_t["table"]) and x.get("source") != "pack" for x in self.tables):
                self.tables = [x for x in self.tables if (x["schema"], x["table"]) != (rec_t["schema"], rec_t["table"])] + [rec_t]
                n_tables += 1
        rec["tables_added"] = n_tables
        self._save()
        return rec

    def remove_pack(self, system: str) -> None:
        self.packs = [x for x in self.packs if x["system"] != system]
        self._packs.pop(system, None)
        self.repos = [r for r in self.repos if r.get("from_pack") != system]
        self.tables = [t for t in self.tables if t.get("pack") != system]
        for k, idx in list(self._indexes.items()):
            if not any(r["name"] == k for r in self.repos):
                self._indexes.pop(k, None)
        self._save()

    def pack_objects(self, emb_cfg: Optional[dict] = None, llm=None) -> list:
        """The loaded Pack objects (cached per session)."""
        from .kpack.pack import Pack
        out = []
        for rec in self.packs:
            pk = self._packs.get(rec["system"])
            if pk is None:
                try:
                    pk = Pack(rec["zip"] if Path(rec.get("zip", "")).exists() else rec["path"], llm=llm, emb_cfg=emb_cfg or {"enabled": False})
                    self._packs[rec["system"]] = pk
                except Exception as e:  # noqa: BLE001
                    log.warning("knowledge pack %s not loadable: %s", rec.get("name"), e)
                    continue
            out.append(pk)
        return out

    def pack_for_path(self, path: str):
        """The pack whose repository copy contains `path` (or None)."""
        for pk in self.pack_objects():
            if path in pk.structure.get("file_list", {}):
                return pk
        return None

    # ------------------------------------------------------------------ feature branches
    def branch_for_system(self, system: str) -> Optional[dict]:
        return next((b for b in self.branches if b.get("system") == system), None)

    def branch_for_repo(self, repo_name: str) -> Optional[dict]:
        """The branch a generated file belongs to: by repo name (pack repo_name / clone name) else by system."""
        rec = next((r for r in self.repos if r["name"] == repo_name), None)
        if rec is not None:
            if rec.get("from_pack"):
                b = self.branch_for_system(rec["from_pack"])
                if b:
                    return b
            b = next((b for b in self.branches if b.get("project", "").rsplit("/", 1)[-1] == repo_name or b.get("slug") == repo_name), None)
            if b:
                return b
        return self.branches[0] if len(self.branches) == 1 else None

    def add_branch(self, rec: dict) -> dict:
        self.branches = [b for b in self.branches if b["slug"] != rec["slug"]] + [rec]
        # without a pack for this system the worktree itself is the repository input (a live clone on the feature branch)
        if not (rec.get("system") and any(p["system"] == rec["system"] for p in self.packs)):
            name = rec.get("project", "").rsplit("/", 1)[-1] or rec["slug"]
            idx = RepoIndex(Path(rec["path"]), name)
            self._indexes[name] = idx
            self.repos = [r for r in self.repos if r["name"] != name] + [{"name": name, "url": rec.get("repo_url", ""), "branch": rec["feature"], "path": rec["path"],
                                                                          "summary": idx.summary(), "info": {"provider": "worktree"}, "from_branch": rec["slug"]}]
        for name, idx in list(self._indexes.items()):          # indexes over the pack copy of this system are rebuilt over the worktree
            r = next((x for x in self.repos if x["name"] == name), None)
            if r and r.get("from_pack") == rec.get("system"):
                self._indexes.pop(name, None)
        if rec.get("system"):
            self.git_defaults.update({"system": rec["system"], "base_branch": rec["base"], "mr_target": rec["target"]})
        self._save()
        return rec

    def remove_branch(self, slug: str) -> Optional[dict]:
        b = next((x for x in self.branches if x["slug"] == slug), None)
        self.branches = [x for x in self.branches if x["slug"] != slug]
        if b:
            for name, r in [(x["name"], x) for x in self.repos]:
                if r.get("from_pack") == b.get("system") or r.get("from_branch") == slug:
                    self._indexes.pop(name, None)
            self.repos = [r for r in self.repos if r.get("from_branch") != slug]
        self._save()
        return b

    def set_git_defaults(self, **kw) -> dict:
        self.git_defaults.update({k: v for k, v in kw.items() if v is not None})
        self._save()
        return self.git_defaults

    def add_table(self, t: dict) -> dict:
        self.tables = [x for x in self.tables if (x["schema"], x["table"]) != (t["schema"], t["table"])] + [t]
        self._save()
        return {"schema": t["schema"], "table": t["table"], "columns": len(t["columns"])}

    def add_query(self, q: dict) -> dict:
        q = dict(q, name=q.get("name") or f"query{len(self.queries) + 1}")
        self.queries.append(q)
        self._save()
        return {"name": q["name"], "columns": q["columns"], "row_count": q["row_count"]}

    def add_repo(self, name: str, url: str, branch: str, local_path: Path, cfg_repo: dict, info: Optional[dict] = None) -> dict:
        idx = RepoIndex(local_path, name, int(cfg_repo.get("max_files", 6000)))
        self._indexes[name] = idx
        rec = {"name": name, "url": url, "branch": branch, "path": str(local_path), "summary": idx.summary(),
               "info": info or {}}
        self.repos = [r for r in self.repos if r["name"] != name] + [rec]
        self._save()
        return {"name": name, "url": url, "branch": branch, "files": rec["summary"]["files"],
                "languages": rec["summary"]["languages"]}

    def index(self, name: str) -> Optional[RepoIndex]:
        if name not in self._indexes:
            rec = next((r for r in self.repos if r["name"] == name), None)
            if rec and Path(rec["path"]).exists():
                if rec.get("from_pack"):
                    pk = next((p for p in self.pack_objects() if p.system == rec["from_pack"]), None)
                    if pk is not None:
                        from .kpack.repo import PackRepoIndex
                        br = self.branch_for_system(rec["from_pack"])
                        root = Path(br["path"]) if br and Path(br["path"]).exists() else Path(rec["path"])   # live feature branch wins over the pack copy
                        self._indexes[name] = PackRepoIndex(pk, root, name)
                        return self._indexes[name]
                self._indexes[name] = RepoIndex(Path(rec["path"]), name)
        return self._indexes.get(name)

    def indexes(self) -> List[RepoIndex]:
        """Every repository index; a pack's repository copy is left out when a live clone of the same repository was added."""
        live = {r["name"] for r in self.repos if not r.get("from_pack")}
        recs = [r for r in self.repos if not (r.get("from_pack") and r["name"] in live)]
        return [i for i in (self.index(r["name"]) for r in recs) if i is not None]

    def set_pipeline(self, agents: List[str]) -> List[str]:
        self.pipeline = [a for a in agents if isinstance(a, str)]
        self._save()
        return self.pipeline

    def remove_story(self) -> None:
        self.story = None
        self._save()

    def remove_table(self, schema: str, table: str) -> None:
        self.tables = [t for t in self.tables if (t["schema"], t["table"]) != (schema, table)]
        self._save()

    def remove_query(self, name: str) -> None:
        self.queries = [q for q in self.queries if q["name"] != name]
        self._save()

    def remove_repo(self, name: str) -> None:
        self.repos = [r for r in self.repos if r["name"] != name or r.get("from_pack")]
        self._indexes.pop(name, None)
        self._save()

    def add_instruction(self, text: str) -> None:
        if text and text.strip():
            self.instructions.append(text.strip())
            self._save()

    # ------------------------------------------------------------------ persistence
    def to_json(self) -> dict:
        return {"story": self.story, "docs": self.docs, "tables": self.tables, "queries": self.queries,
                "repos": self.repos, "instructions": self.instructions, "pipeline": self.pipeline, "packs": self.packs, "git_defaults": self.git_defaults, "branches": self.branches}

    def _save(self) -> None:
        try:
            (self.folder / "inputs.json").write_text(json.dumps(self.to_json(), ensure_ascii=False, indent=1, default=str), encoding="utf-8")
        except Exception as e:  # noqa: BLE001
            log.warning("inputs not saved: %s", e)

    @classmethod
    def load(cls, folder: Path) -> "SessionInputs":
        s = cls(folder)
        f = Path(folder) / "inputs.json"
        if f.exists():
            try:
                d = json.loads(f.read_text(encoding="utf-8"))
                s.story = d.get("story")
                docs = d.get("docs", {}) or {}
                s.docs = {k: list(docs.get(k, [])) for k in KINDS}
                for old_kind, new_kind in _OLD_KINDS.items():           # earlier versions: skills + standards -> knowledge
                    s.docs[new_kind] += [x for x in docs.get(old_kind, []) if x["name"] not in {y["name"] for y in s.docs[new_kind]}]
                s.tables, s.queries, s.repos = d.get("tables", []), d.get("queries", []), d.get("repos", [])
                s.instructions = d.get("instructions", [])
                s.pipeline = d.get("pipeline", [])
                s.packs = d.get("packs", [])
                s.git_defaults = d.get("git_defaults", {}) or {}
                s.branches = d.get("branches", []) or []
            except Exception as e:  # noqa: BLE001
                log.warning("inputs.json unreadable: %s", e)
        return s

    def overview(self) -> dict:
        return {"story": ({"id": self.story["id"], "title": self.story["title"], "chars": self.story["chars"],
                           "source": self.story.get("source", {})} if self.story else None),
                "knowledge": [doc_summary(d) for d in self.docs["knowledge"]],
                "packs": [{k: v for k, v in p.items() if k not in ("path", "zip")} for p in self.packs],
                "tables": [{"schema": t["schema"], "table": t["table"], "columns": len(t["columns"]), "kind": t.get("kind", "table"), "source": t.get("source", "greenplum")} for t in self.tables],
                "queries": [{"name": q["name"], "row_count": q["row_count"], "columns": q["columns"][:20]} for q in self.queries],
                "repos": [{"name": r["name"], "url": r["url"], "branch": r["branch"], "files": r["summary"]["files"],
                           "languages": r["summary"]["languages"], "from_pack": r.get("from_pack", "")} for r in self.repos],
                "git_defaults": self.git_defaults,
                "branches": [{k: v for k, v in b.items() if k not in ("path", "mirror")} for b in self.branches],
                "instructions": self.instructions}
