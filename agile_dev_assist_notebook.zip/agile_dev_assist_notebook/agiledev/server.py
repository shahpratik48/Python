"""Agile Dev Assist web app (FastAPI): SSO, per-user chats, inputs, generation jobs, outputs, git push.
Secrets: the Azure key comes from the environment variable named in the config; user tokens / passwords are posted
by the UI and kept in the in-memory Vault for that user only."""
from __future__ import annotations

import concurrent.futures as cf
import json
import logging
import mimetypes
import secrets as pysecrets
import threading
import time
from pathlib import Path
from typing import Dict, List, Optional

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, PlainTextResponse, RedirectResponse, Response
from fastapi.staticfiles import StaticFiles

from .auth import COOKIE, Auth, Vault
from .config import Config, get_secret, load_config
from .engine import ChatSession
from .greenplum import GreenplumInput
from .llm import LLM
from .store import Store

log = logging.getLogger(__name__)
WEB = Path(__file__).resolve().parent.parent / "web"


class App:
    def __init__(self, cfg: Config, llm=None, selftest: bool = False):
        self.cfg = cfg
        self.selftest = selftest
        st = cfg.storage
        self.store = Store(cfg.path(st["db_file"]), cfg.path(st["data_dir"]))
        self.store.purge_old(int(st.get("keep_days", 0) or 0))
        if llm is None:
            if selftest:
                from .selftest import ScriptedLLM
                llm = ScriptedLLM(cfg, cfg.path(st["llm_cache_dir"]))
            else:
                llm = LLM(cfg, cfg.path(st["llm_cache_dir"]))
        self.llm = llm
        self.auth = Auth(cfg, get_secret(cfg, "server_secret", allow_prompt=False, required=False))
        self.vault = Vault()
        self.sessions: Dict[str, ChatSession] = {}
        self.jobs: Dict[str, cf.Future] = {}
        self.pool = cf.ThreadPoolExecutor(int(cfg.server.get("workers_threads", 8)))
        self._lock = threading.Lock()

    # ------------------------------------------------------------------ sessions
    def session(self, user: str, chat_id: str) -> ChatSession:
        key = f"{user}/{chat_id}"
        with self._lock:
            s = self.sessions.get(key)
            if s is None:
                if not self.store.chat(user, chat_id):
                    raise HTTPException(404, "chat not found")
                s = ChatSession(self.cfg, self.llm, self.store.chat_folder(user, chat_id), user, chat_id)
                self.sessions[key] = s
            return s

    def drop(self, user: str, chat_id: str) -> None:
        with self._lock:
            self.sessions.pop(f"{user}/{chat_id}", None)

    def submit(self, user: str, chat_id: str, fn, *args) -> str:
        key = f"{user}/{chat_id}"
        j = self.jobs.get(key)
        if j is not None and not j.done():
            raise HTTPException(409, "this chat is busy - wait for the current step to finish")
        self.jobs[key] = self.pool.submit(fn, *args)
        return key

    def busy(self, user: str, chat_id: str) -> bool:
        j = self.jobs.get(f"{user}/{chat_id}")
        return j is not None and not j.done()


def create_app(cfg: Optional[Config] = None, llm=None, selftest: bool = False) -> FastAPI:
    cfg = cfg or load_config()
    core = App(cfg, llm, selftest)
    app = FastAPI(title=cfg.product.get("name", "Agile Dev Assist"), docs_url=None, redoc_url=None)
    app.state.core = core
    app.mount("/static", StaticFiles(directory=str(WEB)), name="static")
    secure = bool(cfg.auth.get("secure_cookies", False))

    # ------------------------------------------------------------------ auth helpers
    def current_user(request: Request) -> dict:
        u = core.auth.user_from_request(request.headers, request.cookies)
        if not u:
            raise HTTPException(401, "not signed in")
        if not core.auth.allowed(u["user_id"]):
            raise HTTPException(403, "user not allowed")
        core.store.touch_user(u["user_id"], u.get("display_name", ""), u.get("email", ""))
        return u

    def set_cookie(resp: Response, user: dict, request: Request):
        sec = secure or request.headers.get("x-forwarded-proto", "") == "https"
        resp.set_cookie(COOKIE, core.auth.sign(user), max_age=int(core.auth.ttl), httponly=True, samesite="lax", secure=sec, path="/")

    @app.get("/", response_class=HTMLResponse)
    def index(request: Request):
        u = core.auth.user_from_request(request.headers, request.cookies)
        if not u:
            if core.auth.mode == "oidc":
                return RedirectResponse("/auth/login")
            if core.auth.mode == "header":
                return HTMLResponse(_page("Not signed in", f"The SSO header <code>{cfg.auth.get('header_name')}</code> is missing. "
                                          "Open this application through the corporate single sign-on URL."), status_code=401)
            return HTMLResponse((WEB / "login.html").read_text(encoding="utf-8"))
        if not core.auth.allowed(u["user_id"]):
            return HTMLResponse(_page("Not allowed", f"User <b>{u['user_id']}</b> is not in the allowed list."), status_code=403)
        return HTMLResponse((WEB / "index.html").read_text(encoding="utf-8"))

    @app.get("/auth/login")
    def login(request: Request):
        if core.auth.mode != "oidc":
            return RedirectResponse("/")
        state = pysecrets.token_urlsafe(16)
        resp = RedirectResponse(core.auth.oidc_login_url(str(request.url_for("callback")), state))
        resp.set_cookie("agiledev_oidc_state", state, httponly=True, max_age=600, path="/")
        return resp

    @app.post("/auth/dev-login")
    def dev_login(request: Request, user: str = Form(...), name: str = Form("")):
        if core.auth.mode != "dev":
            raise HTTPException(404)
        if not core.auth.a.get("dev_allow_any_user", True) and not core.auth.allowed(user):
            raise HTTPException(403, "user not allowed")
        u = {"user_id": user.strip(), "display_name": name.strip() or user.strip(), "email": user.strip() if "@" in user else ""}
        resp = RedirectResponse("/", status_code=303)
        set_cookie(resp, u, request)
        return resp

    @app.get("/auth/callback", name="callback")
    def callback(request: Request, code: str = "", state: str = ""):
        if request.cookies.get("agiledev_oidc_state") != state:
            raise HTTPException(400, "state mismatch")
        u = core.auth.oidc_exchange(code, str(request.url_for("callback")), get_secret(cfg, "oidc_client_secret", allow_prompt=False, required=False))
        resp = RedirectResponse("/", status_code=303)
        set_cookie(resp, u, request)
        return resp

    @app.post("/auth/logout")
    def logout(request: Request):
        u = core.auth.user_from_request(request.headers, request.cookies)
        if u:
            core.vault.clear(u["user_id"])
        resp = JSONResponse({"ok": True})
        resp.delete_cookie(COOKIE, path="/")
        return resp

    @app.get("/api/health")
    def health():
        return {"ok": True, "product": cfg.product.get("name"), "mode": core.auth.mode, "selftest": core.selftest}

    @app.get("/api/me")
    def me(request: Request):
        u = current_user(request)
        return {**u, "admin": core.auth.is_admin(u["user_id"]), "vault": core.vault.keys(u["user_id"]),
                "product": cfg.product, "auth_mode": core.auth.mode, "docs_enabled": bool(cfg.generation.get("docs", False)),
                "local_test": bool(core.selftest or cfg.inputs.greenplum.get("allow_sqlite", False))}

    @app.post("/api/vault")
    async def vault_set(request: Request):
        u = current_user(request)
        body = await request.json()
        for k, v in (body or {}).items():
            if v:
                core.vault.set(u["user_id"], k, str(v))
        return {"keys": core.vault.keys(u["user_id"])}

    # ------------------------------------------------------------------ chats
    @app.get("/api/chats")
    def chats(request: Request):
        u = current_user(request)
        return core.store.chats(u["user_id"])

    @app.post("/api/chats")
    async def new_chat(request: Request):
        u = current_user(request)
        body = await request.json() if request.headers.get("content-type", "").startswith("application/json") else {}
        return core.store.new_chat(u["user_id"], (body or {}).get("title") or "New chat")

    @app.get("/api/chats/{chat_id}")
    def chat_state(request: Request, chat_id: str):
        u = current_user(request)
        s = core.session(u["user_id"], chat_id)
        st = s.state()
        st["messages"] = core.store.messages(u["user_id"], chat_id)
        st["busy"] = core.busy(u["user_id"], chat_id)
        st["chat"] = core.store.chat(u["user_id"], chat_id)
        return st

    @app.patch("/api/chats/{chat_id}")
    async def rename(request: Request, chat_id: str):
        u = current_user(request)
        body = await request.json()
        core.store.update_chat(u["user_id"], chat_id, title=str(body.get("title", ""))[:120])
        return {"ok": True}

    @app.delete("/api/chats/{chat_id}")
    def delete_chat(request: Request, chat_id: str):
        u = current_user(request)
        if core.busy(u["user_id"], chat_id):
            raise HTTPException(409, "chat is busy")
        core.drop(u["user_id"], chat_id)
        return {"deleted": core.store.delete_chat(u["user_id"], chat_id)}

    @app.get("/api/chats/{chat_id}/events")
    def events(request: Request, chat_id: str, since: int = 0):
        u = current_user(request)
        s = core.session(u["user_id"], chat_id)
        return {"events": s.events[since:since + 500], "next": min(len(s.events), since + 500), "busy": core.busy(u["user_id"], chat_id),
                "running": s.running}

    # ------------------------------------------------------------------ inputs
    @app.post("/api/chats/{chat_id}/inputs/story")
    async def story(request: Request, chat_id: str, mode: str = Form("text"), text: str = Form(""), title: str = Form(""),
                    story_id: str = Form(""), url: str = Form(""), token: str = Form(""), issue: str = Form(""), path: str = Form(""),
                    ref: str = Form(""), file: Optional[UploadFile] = File(None)):
        u = current_user(request)
        s = core.session(u["user_id"], chat_id)
        if mode == "git":
            tok = _token(core, u, token, "git_token")
            st = s.set_story_from_git(url, tok, issue, path, ref)
        elif mode == "file" and file is not None:
            st = s.set_story_from_file(file.filename, await file.read())
        else:
            if not text.strip():
                raise HTTPException(400, "empty story")
            st = s.set_story_text(text, title, story_id)
        core.store.update_chat(u["user_id"], chat_id, story_id=st["id"], story_title=st["title"], title=f"{st['id']} {st['title']}"[:120])
        core.store.add_message(u["user_id"], chat_id, "system", f"Story added: {st['id']} - {st['title']}", {"kind": "story"})
        return {"id": st["id"], "title": st["title"], "chars": st["chars"], "acceptance_criteria": st["acceptance_criteria"]}

    @app.post("/api/chats/{chat_id}/inputs/docs")
    async def docs(request: Request, chat_id: str, kind: str = Form(...), files: List[UploadFile] = File(...)):
        u = current_user(request)
        s = core.session(u["user_id"], chat_id)
        maxb = int(cfg.inputs.get("max_file_mb", 25)) * 1024 * 1024
        allowed = set(cfg.inputs.get("accepted_extensions", []))
        items = []
        for f in files:
            ext = Path(f.filename).suffix.lower().lstrip(".")
            if allowed and ext not in allowed:
                raise HTTPException(400, f"{f.filename}: extension .{ext} not accepted")
            data = await f.read()
            if len(data) > maxb:
                raise HTTPException(400, f"{f.filename}: larger than {maxb // 1024 // 1024} MB")
            items.append((f.filename, data))
        out = s.add_documents(kind, items)
        core.store.add_message(u["user_id"], chat_id, "system", f"{kind}: " + ", ".join(x["name"] for x in out), {"kind": kind})
        return out

    @app.delete("/api/chats/{chat_id}/inputs/docs/{kind}/{name}")
    def doc_delete(request: Request, chat_id: str, kind: str, name: str):
        u = current_user(request)
        core.session(u["user_id"], chat_id).inputs.remove_document(kind, name)
        return {"ok": True}

    @app.post("/api/chats/{chat_id}/inputs/repo")
    async def repo(request: Request, chat_id: str):
        u = current_user(request)
        body = await request.json()
        s = core.session(u["user_id"], chat_id)
        tok = _token(core, u, body.get("token", ""), "git_token")
        try:
            rec = s.add_repo(body["url"], tok, body.get("branch", ""), body.get("name", ""), body.get("subpath", ""), bool(body.get("refresh")))
        except Exception as e:  # noqa: BLE001
            raise HTTPException(400, f"repository: {type(e).__name__}: {str(e)[:300]}")
        core.store.add_message(u["user_id"], chat_id, "system", f"Repository {rec['name']}@{rec['branch']}: {rec['files']} files", {"kind": "repo"})
        return rec

    @app.post("/api/chats/{chat_id}/inputs/greenplum")
    async def greenplum(request: Request, chat_id: str):
        u = current_user(request)
        body = await request.json()
        s = core.session(u["user_id"], chat_id)
        pw = _token(core, u, body.get("password", ""), "gp_password")
        gcfg = cfg.inputs.greenplum
        sqlite_path = body.get("sqlite_path") if (core.selftest or gcfg.get("allow_sqlite", False)) else None   # local testing only
        gp = GreenplumInput(body.get("host", ""), body.get("port", 5432), body.get("database", ""), body.get("user", ""), pw,
                            body.get("sslmode", "prefer"), int(gcfg.get("statement_timeout_seconds", 60)), sqlite_path=sqlite_path)
        try:
            if body.get("action") == "list":
                return {"tables": gp.list_tables(body.get("schema", ""), body.get("like", ""))}
            if body.get("action") == "test":
                return {"ok": True, "version": gp.test()}
            out = {"tables": [], "query": None}
            tables = [t.strip() for t in (body.get("tables") or []) if t.strip()]
            if tables:
                out["tables"] = s.add_tables(gp, body.get("schema", ""), tables)
            if body.get("query") and gcfg.get("allow_queries", True):
                out["query"] = s.add_query(gp, body["query"], body.get("query_name", ""))
            core.store.add_message(u["user_id"], chat_id, "system", "Greenplum: " + ", ".join(f"{t['schema']}.{t['table']}" for t in out["tables"])
                                   + (f"; query {out['query']['name']}" if out["query"] else ""), {"kind": "greenplum"})
            return out
        except Exception as e:  # noqa: BLE001
            raise HTTPException(400, f"Greenplum: {type(e).__name__}: {str(e)[:300]}")
        finally:
            gp.close()

    # ------------------------------------------------------------------ generation
    @app.post("/api/chats/{chat_id}/message")
    async def message(request: Request, chat_id: str):
        u = current_user(request)
        body = await request.json()
        text = str(body.get("text", "")).strip()
        s = core.session(u["user_id"], chat_id)
        if not text:
            raise HTTPException(400, "empty message")
        core.store.add_message(u["user_id"], chat_id, "user", text)
        s.add_history("user", text)
        if s.files and s.summary and not body.get("rerun"):
            core.submit(u["user_id"], chat_id, _job_change, core, u, chat_id, s, text)
            return {"started": "change"}
        if s.inputs.story is None:
            # no story yet: the text itself is the story when it looks like one
            if len(text) > 80:
                st = s.set_story_text(text)
                core.store.update_chat(u["user_id"], chat_id, story_id=st["id"], story_title=st["title"], title=f"{st['id']} {st['title']}"[:120])
                core.submit(u["user_id"], chat_id, _job_run, core, u, chat_id, s, "")
                return {"started": "run", "story": st["id"]}
            reply = "Drag the Story icon into the chat (or paste the story text here) - then I can start."
            core.store.add_message(u["user_id"], chat_id, "assistant", reply)
            return {"reply": reply}
        core.submit(u["user_id"], chat_id, _job_run, core, u, chat_id, s, text if text.lower() not in ("run", "go", "generate", "start") else "")
        return {"started": "run"}

    @app.post("/api/chats/{chat_id}/docs")
    async def docs_toggle(request: Request, chat_id: str):
        u = current_user(request)
        body = await request.json()
        s = core.session(u["user_id"], chat_id)
        s.docs_wanted = bool(body.get("enabled", True))
        made = []
        if s.docs_wanted and s.files:
            from .docgen import write_docs
            made = write_docs(s)
            s.docs = made
            s.make_zip()
        return {"enabled": s.docs_wanted, "files": [Path(m).name for m in made]}

    @app.get("/api/chats/{chat_id}/docfile/{name}")
    def docfile(request: Request, chat_id: str, name: str):
        u = current_user(request)
        s = core.session(u["user_id"], chat_id)
        p = s.folder / Path(name).name
        if not p.exists() or not p.suffix in (".docx", ".pptx"):
            raise HTTPException(404)
        return FileResponse(str(p), filename=p.name)

    @app.post("/api/chats/{chat_id}/run")
    async def run(request: Request, chat_id: str):
        u = current_user(request)
        body = await request.json() if request.headers.get("content-type", "").startswith("application/json") else {}
        s = core.session(u["user_id"], chat_id)
        if s.inputs.story is None:
            raise HTTPException(400, "add a story first")
        instr = str((body or {}).get("instructions", "")).strip()
        if instr:
            core.store.add_message(u["user_id"], chat_id, "user", instr)
        core.submit(u["user_id"], chat_id, _job_run, core, u, chat_id, s, instr)
        return {"started": "run"}

    # ------------------------------------------------------------------ files + outputs
    @app.get("/api/chats/{chat_id}/files/{path:path}")
    def file_get(request: Request, chat_id: str, path: str):
        u = current_user(request)
        s = core.session(u["user_id"], chat_id)
        f = s.files.get(path)
        if not f:
            raise HTTPException(404, "file not found")
        return f

    @app.put("/api/chats/{chat_id}/files/{path:path}")
    async def file_put(request: Request, chat_id: str, path: str):
        u = current_user(request)
        body = await request.json()
        s = core.session(u["user_id"], chat_id)
        return s.update_file(path, str(body.get("content", "")))

    @app.get("/api/chats/{chat_id}/download/{what}")
    def download(request: Request, chat_id: str, what: str):
        u = current_user(request)
        s = core.session(u["user_id"], chat_id)
        names = {"zip": None, "log": "log.txt", "plan": "plan.json", "tokens": "tokens.txt", "pack": "pack.json", "review": "review.json",
                 "findings": "findings.json", "summary": "run_summary.json", "inputs": "inputs.json", "events": "events.jsonl"}
        if what not in names:
            raise HTTPException(404)
        if what == "zip":
            p = s.make_zip()
        else:
            p = s.folder / names[what]
        if not p.exists():
            raise HTTPException(404, f"{what} not available yet")
        return FileResponse(str(p), filename=p.name, media_type=mimetypes.guess_type(p.name)[0] or "application/octet-stream")

    @app.get("/api/chats/{chat_id}/text/{what}")
    def text_get(request: Request, chat_id: str, what: str):
        u = current_user(request)
        s = core.session(u["user_id"], chat_id)
        p = s.folder / {"log": "log.txt", "tokens": "tokens.txt"}.get(what, "x")
        return PlainTextResponse(p.read_text(encoding="utf-8")[-200000:] if p.exists() else "")

    # ------------------------------------------------------------------ git push
    @app.get("/api/chats/{chat_id}/branch-suggestion")
    def branch(request: Request, chat_id: str, url: str = ""):
        u = current_user(request)
        s = core.session(u["user_id"], chat_id)
        repos = s.inputs.repos
        return {"branch": s.suggest_branch(url), "repo_url": url or (repos[0]["url"] if repos else ""),
                "base_branch": (repos[0]["branch"] if repos else ""), "files": list(s.files)}

    @app.post("/api/chats/{chat_id}/push")
    async def push(request: Request, chat_id: str):
        u = current_user(request)
        body = await request.json()
        s = core.session(u["user_id"], chat_id)
        tok = body.get("token", "")
        if cfg.git.get("push_requires_user_token", True) and not tok and not core.vault.get(u["user_id"], "git_token"):
            raise HTTPException(400, "your git token is required to push under your name")
        tok = _token(core, u, tok, "git_token")
        try:
            r = s.publish(body["url"], tok, body["branch"], body["base_branch"], body.get("message", ""), None, body.get("paths"))
        except Exception as e:  # noqa: BLE001
            raise HTTPException(400, f"push failed: {type(e).__name__}: {str(e)[:300]}")
        core.store.add_message(u["user_id"], chat_id, "assistant", f"Pushed {r['files']} file(s) to branch {r['branch']} (from {r['base_branch']}) as {r.get('pushed_as')}: {r.get('branch_url')}", {"kind": "publish", **r})
        core.store.update_chat(u["user_id"], chat_id, status="pushed")
        return r

    return app


# ----------------------------------------------------------------------------- jobs
def _token(core: App, u: dict, given: str, key: str) -> str:
    if given:
        core.vault.set(u["user_id"], key, given)
        return given
    return core.vault.get(u["user_id"], key) or ""


def _job_run(core: App, u: dict, chat_id: str, s: ChatSession, instructions: str):
    uid = u["user_id"]
    try:
        core.store.update_chat(uid, chat_id, status="running")
        summary = s.run(instructions)
        files = "\n".join(f"- `{f['path']}` ({f['language']}, {f['action']})" for f in summary["files"])
        rev = summary.get("review") or {}
        reply = (f"Done in {summary['duration_seconds']}s - {len(summary['files'])} file(s), quality {summary['quality_score']}/100"
                 + (f", review {rev.get('verdict')} ({rev.get('score')})" if rev.get("verdict") else "") + f", {summary['tokens'].get('total_tokens', 0)} tokens.\n\n"
                 f"**Approach:** {s.plan.get('approach', '')}\n\n{files}\n\nOpen the Files tab to read or edit, ask for changes here, "
                 "download the zip, or push a branch.")
        if s.plan.get("questions"):
            reply += "\n\n**Open questions:** " + "; ".join(s.plan["questions"][:5])
        core.store.add_message(uid, chat_id, "assistant", reply, {"kind": "run", "summary": summary})
        s.add_history("assistant", reply)
        core.store.update_chat(uid, chat_id, status="done")
    except Exception as e:  # noqa: BLE001
        log.exception("run job failed")
        core.store.add_message(uid, chat_id, "assistant", f"The run failed: {type(e).__name__}: {str(e)[:400]}", {"kind": "error"})
        core.store.update_chat(uid, chat_id, status="failed")


def _job_change(core: App, u: dict, chat_id: str, s: ChatSession, text: str):
    uid = u["user_id"]
    try:
        core.store.update_chat(uid, chat_id, status="running")
        r = s.change(text)
        reply = r.get("reply", "")
        if r.get("changed"):
            reply += "\n\nChanged: " + ", ".join(f"`{p}`" for p in r["changed"]) + f". Quality now {s.summary.get('quality_score')}/100."
        core.store.add_message(uid, chat_id, "assistant", reply, {"kind": "change", "changed": r.get("changed", [])})
        s.add_history("assistant", reply)
        core.store.update_chat(uid, chat_id, status="done")
    except Exception as e:  # noqa: BLE001
        log.exception("change job failed")
        core.store.add_message(uid, chat_id, "assistant", f"The change failed: {type(e).__name__}: {str(e)[:400]}", {"kind": "error"})
        core.store.update_chat(uid, chat_id, status="done")


def _page(title: str, body: str) -> str:
    return f"<!doctype html><html><head><meta charset='utf-8'><title>{title}</title><link rel='stylesheet' href='/static/style.css'></head>" \
           f"<body class='plain'><div class='card'><h1>{title}</h1><p>{body}</p></div></body></html>"


def serve(cfg: Optional[Config] = None, host: Optional[str] = None, port: Optional[int] = None, selftest: bool = False,
          llm=None, open_browser: bool = False, background: bool = False):
    """Start the server (used by app_server.py and by the notebook edition)."""
    import uvicorn
    cfg = cfg or load_config()
    app = create_app(cfg, llm, selftest)
    host = host or cfg.server.get("host", "0.0.0.0")
    port = int(port or cfg.server.get("port", 8780))
    if open_browser:
        import webbrowser
        threading.Timer(1.5, lambda: webbrowser.open(f"http://{'localhost' if host in ('0.0.0.0', '') else host}:{port}/")).start()
    config = uvicorn.Config(app, host=host, port=port, log_level="info")
    server = uvicorn.Server(config)
    if background:
        t = threading.Thread(target=server.run, daemon=True)
        t.start()
        time.sleep(1.0)
        return server
    server.run()
    return server
