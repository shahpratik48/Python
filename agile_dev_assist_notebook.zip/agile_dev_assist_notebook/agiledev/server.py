"""Agile Dev Assist web app - standard-library HTTP server (no FastAPI / uvicorn needed), so the same server runs
from the notebook button, on a laptop and behind nginx on a VM.

SSO (auth.mode header | oidc | dev), per-user chats, inputs, generation jobs, outputs, git push.
Secrets: the Azure key comes from the environment variable named in the config; user tokens / passwords are posted
by the UI and kept in the in-memory Vault for that user only."""
from __future__ import annotations

import concurrent.futures as cf
import json
import logging
import mimetypes
import re
import secrets as pysecrets
import threading
import time
import traceback
from http import cookies as http_cookies
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from urllib.parse import parse_qs, unquote, urlparse

from .auth import COOKIE, Auth, Vault
from .config import Config, get_secret, load_config
from .engine import ChatSession
from .greenplum import GreenplumInput
from .llm import LLM
from .store import Store

log = logging.getLogger(__name__)
WEB = Path(__file__).resolve().parent.parent / "web"


class HTTPError(Exception):
    def __init__(self, code: int, detail: str):
        super().__init__(detail)
        self.code, self.detail = code, detail


# ----------------------------------------------------------------------------- core (shared state)
class App:
    def __init__(self, cfg: Config, llm=None, selftest: bool = False):
        self.cfg = cfg
        self.selftest = selftest
        st = cfg.storage
        self.store = Store(cfg.path(st["db_file"]), cfg.path(st["data_dir"]))
        self.store.purge_old(int(st.get("keep_days", 0) or 0))
        if llm is None:
            if selftest:
                from .selftest import ScriptedLLM
                llm = ScriptedLLM(cfg, cfg.path(st["llm_cache_dir"]))
            else:
                llm = LLM(cfg, cfg.path(st["llm_cache_dir"]))
        self.llm = llm
        self.auth = Auth(cfg, get_secret(cfg, "server_secret", allow_prompt=False, required=False))
        self.vault = Vault()
        self.sessions: Dict[str, ChatSession] = {}
        self.jobs: Dict[str, cf.Future] = {}
        self.tasks: Dict[str, dict] = {}            # short input jobs (repo download, table introspection) with progress
        self.pool = cf.ThreadPoolExecutor(int(cfg.server.get("workers_threads", 8)))
        self._lock = threading.Lock()

    def session(self, user: str, chat_id: str) -> ChatSession:
        key = f"{user}/{chat_id}"
        with self._lock:
            s = self.sessions.get(key)
            if s is None:
                if not self.store.chat(user, chat_id):
                    raise HTTPError(404, "chat not found")
                s = ChatSession(self.cfg, self.llm, self.store.chat_folder(user, chat_id), user, chat_id)
                self.sessions[key] = s
            return s

    def drop(self, user: str, chat_id: str) -> None:
        with self._lock:
            self.sessions.pop(f"{user}/{chat_id}", None)

    def submit(self, user: str, chat_id: str, fn, *args) -> None:
        key = f"{user}/{chat_id}"
        j = self.jobs.get(key)
        if j is not None and not j.done():
            raise HTTPError(409, "this chat is busy - wait for the current step to finish")
        self.jobs[key] = self.pool.submit(fn, *args)

    def busy(self, user: str, chat_id: str) -> bool:
        j = self.jobs.get(f"{user}/{chat_id}")
        return j is not None and not j.done()

    def start_task(self, user: str, fn, *args) -> str:
        """Run an input job in the background; the UI polls /api/tasks/<id> for progress (proxies time out long requests)."""
        tid = pysecrets.token_urlsafe(8)
        task = {"id": tid, "user": user, "status": "running", "progress": "starting ...", "result": None, "error": "", "started": time.time()}
        self.tasks[tid] = task

        def say(msg):
            task["progress"] = str(msg)[:300]

        def run():
            try:
                task["result"] = fn(say, *args)
                task["status"] = "done"
            except HTTPError as e:
                task["error"], task["status"] = e.detail, "failed"
            except Exception as e:  # noqa: BLE001
                log.exception("task failed")
                task["error"], task["status"] = f"{type(e).__name__}: {str(e)[:300]}", "failed"
            for k in [k for k, t in self.tasks.items() if time.time() - t["started"] > 3600]:
                self.tasks.pop(k, None)
        self.pool.submit(run)
        return tid

    def token(self, u: dict, given: str, key: str) -> str:
        if given:
            self.vault.set(u["user_id"], key, given)
            return given
        return self.vault.get(u["user_id"], key) or ""

    def read_token(self, u: dict, given: str) -> str:
        """Token for READING git (stories, code): the user's own if given / remembered, else the server's read-only token
        (environment variable from secrets.git_read_token, or the one entered in the notebook before the launch)."""
        if given:
            self.vault.set(u["user_id"], "git_token", given)
            return given
        return self.vault.get(u["user_id"], "git_token") or getattr(self, "git_read_token", "") or \
            get_secret(self.cfg, "git_read_token", allow_prompt=False, required=False)


# ----------------------------------------------------------------------------- request helpers
def parse_multipart(body: bytes, content_type: str) -> Tuple[Dict[str, str], Dict[str, List[Tuple[str, bytes]]]]:
    """Minimal multipart/form-data parser: fields {name: value}, files {name: [(filename, bytes), ...]}."""
    m = re.search(r'boundary="?([^";]+)"?', content_type)
    if not m:
        raise HTTPError(400, "multipart boundary missing")
    boundary = m.group(1).encode()
    fields, files = {}, {}
    for part in body.split(b"--" + boundary):
        part = part.strip(b"\r\n")
        if not part or part == b"--":
            continue
        if b"\r\n\r\n" not in part:
            continue
        head, data = part.split(b"\r\n\r\n", 1)
        if data.endswith(b"\r\n"):
            data = data[:-2]
        headers = head.decode("utf-8", "replace")
        cd = re.search(r'name="([^"]*)"', headers)
        if not cd:
            continue
        name = cd.group(1)
        fn = re.search(r'filename="([^"]*)"', headers)
        if fn:
            files.setdefault(name, []).append((unquote(Path(fn.group(1).replace("\\", "/")).name), data))
        else:
            fields[name] = data.decode("utf-8", "replace")
    return fields, files


def _page(title: str, body: str) -> str:
    return (f"<!doctype html><html><head><meta charset='utf-8'><title>{title}</title><link rel='stylesheet' href='static/style.css'></head>"
            f"<body class='plain'><div class='card'><h1>{title}</h1><p>{body}</p></div></body></html>")


class Request:
    def __init__(self, handler: "Handler"):
        self.h = handler
        u = urlparse(handler.path)
        self.path = u.path
        self.query = {k: v[0] for k, v in parse_qs(u.query).items()}
        self.headers = {k.lower(): v for k, v in handler.headers.items()}
        self.cookies = {}
        if handler.headers.get("Cookie"):
            c = http_cookies.SimpleCookie()
            try:
                c.load(handler.headers.get("Cookie"))
                self.cookies = {k: v.value for k, v in c.items()}
            except Exception:  # noqa: BLE001
                pass
        n = int(handler.headers.get("Content-Length", 0) or 0)
        self.body = handler.rfile.read(n) if n else b""
        self.ctype = handler.headers.get("Content-Type", "")
        self._json = None
        self.fields, self.files = {}, {}
        if self.ctype.startswith("multipart/form-data"):
            self.fields, self.files = parse_multipart(self.body, self.ctype)
        elif self.ctype.startswith("application/x-www-form-urlencoded"):
            self.fields = {k: v[0] for k, v in parse_qs(self.body.decode("utf-8", "replace")).items()}

    def json(self) -> dict:
        if self._json is None:
            try:
                self._json = json.loads(self.body or b"{}") if self.body else {}
            except json.JSONDecodeError:
                raise HTTPError(400, "invalid JSON body")
        return self._json

    def header(self, name: str, default: str = "") -> str:
        return self.headers.get(name.lower(), default)


class Response:
    def __init__(self, code: int = 200, body=b"", ctype: str = "application/json", headers: Optional[list] = None):
        self.code, self.body, self.ctype, self.headers = code, body, ctype, headers or []

    @classmethod
    def json(cls, obj, code: int = 200):
        return cls(code, json.dumps(obj, ensure_ascii=False, default=str).encode("utf-8"))

    @classmethod
    def html(cls, text: str, code: int = 200):
        return cls(code, text.encode("utf-8"), "text/html; charset=utf-8")

    @classmethod
    def text(cls, text: str, code: int = 200):
        return cls(code, text.encode("utf-8"), "text/plain; charset=utf-8")

    @classmethod
    def redirect(cls, url: str, code: int = 303):
        return cls(code, b"", "text/plain", [("Location", url)])

    @classmethod
    def file(cls, path: Path, download_name: str = ""):
        ctype = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        hdr = [("Content-Disposition", f'attachment; filename="{download_name or path.name}"')] if download_name else []
        return cls(200, path.read_bytes(), ctype, hdr)


# ----------------------------------------------------------------------------- routes
ROUTES: List[Tuple[str, re.Pattern, callable]] = []


def route(method: str, pattern: str):
    def deco(fn):
        ROUTES.append((method, re.compile("^" + pattern + "$"), fn))
        return fn
    return deco


def current_user(core: App, r: Request) -> dict:
    u = core.auth.user_from_request(r.headers, r.cookies)
    if not u:
        raise HTTPError(401, "not signed in")
    if not core.auth.allowed(u["user_id"]):
        raise HTTPError(403, "user not allowed")
    core.store.touch_user(u["user_id"], u.get("display_name", ""), u.get("email", ""))
    return u


def set_cookie(core: App, resp: Response, user: dict, r: Request) -> None:
    secure = bool(core.cfg.auth.get("secure_cookies", False)) or r.header("x-forwarded-proto") == "https"
    c = f"{COOKIE}={core.auth.sign(user)}; Max-Age={int(core.auth.ttl)}; Path=/; HttpOnly; SameSite=Lax" + ("; Secure" if secure else "")
    resp.headers.append(("Set-Cookie", c))


@route("GET", "/")
def index(core: App, r: Request):
    u = core.auth.user_from_request(r.headers, r.cookies)
    if not u:
        if core.auth.mode == "oidc":
            return Response.redirect("auth/login", 302)
        if core.auth.mode == "header":
            return Response.html(_page("Not signed in", f"The SSO header <code>{core.cfg.auth.get('header_name')}</code> is missing. "
                                                        "Open this application through the corporate single sign-on URL."), 401)
        return Response.html((WEB / "login.html").read_text(encoding="utf-8"))
    if not core.auth.allowed(u["user_id"]):
        return Response.html(_page("Not allowed", f"User <b>{u['user_id']}</b> is not in the allowed list."), 403)
    return Response.html((WEB / "index.html").read_text(encoding="utf-8"))


@route("GET", "/static/(?P<name>[A-Za-z0-9_.-]+)")
def static(core: App, r: Request, name: str):
    p = WEB / name
    if not p.is_file():
        raise HTTPError(404, "not found")
    return Response(200, p.read_bytes(), mimetypes.guess_type(name)[0] or "application/octet-stream", [("Cache-Control", "no-cache")])


@route("GET", "/auth/login")
def login(core: App, r: Request):
    if core.auth.mode != "oidc":
        return Response.redirect("../", 302)
    state = pysecrets.token_urlsafe(16)
    cb = f"{'https' if r.header('x-forwarded-proto') == 'https' else 'http'}://{r.header('host')}/auth/callback"
    resp = Response.redirect(core.auth.oidc_login_url(cb, state), 302)
    resp.headers.append(("Set-Cookie", f"agiledev_oidc_state={state}; Max-Age=600; Path=/; HttpOnly"))
    return resp


@route("POST", "/auth/dev-login")
def dev_login(core: App, r: Request):
    if core.auth.mode != "dev":
        raise HTTPError(404, "not found")
    user = r.fields.get("user", "").strip()
    if not user:
        raise HTTPError(400, "user id required")
    if not core.auth.a.get("dev_allow_any_user", True) and not core.auth.allowed(user):
        raise HTTPError(403, "user not allowed")
    u = {"user_id": user, "display_name": r.fields.get("name", "").strip() or user, "email": user if "@" in user else ""}
    resp = Response.redirect("../", 303)            # relative: works at the root and behind jupyter-server-proxy
    set_cookie(core, resp, u, r)
    return resp


@route("GET", "/auth/callback")
def callback(core: App, r: Request):
    if r.cookies.get("agiledev_oidc_state") != r.query.get("state", ""):
        raise HTTPError(400, "state mismatch")
    cb = f"{'https' if r.header('x-forwarded-proto') == 'https' else 'http'}://{r.header('host')}/auth/callback"
    u = core.auth.oidc_exchange(r.query.get("code", ""), cb, get_secret(core.cfg, "oidc_client_secret", allow_prompt=False, required=False))
    resp = Response.redirect("../", 303)
    set_cookie(core, resp, u, r)
    return resp


@route("POST", "/auth/logout")
def logout(core: App, r: Request):
    u = core.auth.user_from_request(r.headers, r.cookies)
    if u:
        core.vault.clear(u["user_id"])
    resp = Response.json({"ok": True})
    resp.headers.append(("Set-Cookie", f"{COOKIE}=; Max-Age=0; Path=/"))
    return resp


@route("GET", "/api/health")
def health(core: App, r: Request):
    return Response.json({"ok": True, "product": core.cfg.product.get("name"), "mode": core.auth.mode, "selftest": core.selftest})


@route("GET", "/api/me")
def me(core: App, r: Request):
    u = current_user(core, r)
    return Response.json({**u, "admin": core.auth.is_admin(u["user_id"]), "vault": core.vault.keys(u["user_id"]),
                          "product": core.cfg.product, "auth_mode": core.auth.mode, "docs_enabled": bool(core.cfg.generation.get("docs", False)),
                          "local_test": bool(core.selftest or core.cfg.inputs.greenplum.get("allow_sqlite", False)),
                          "greenplum_defaults": dict(core.cfg.inputs.greenplum.get("defaults") or {}),
                          "git_read_token": bool(getattr(core, "git_read_token", "") or get_secret(core.cfg, "git_read_token", allow_prompt=False, required=False)
                                                 or core.vault.get(u["user_id"], "git_token"))})


@route("POST", "/api/vault")
def vault_set(core: App, r: Request):
    u = current_user(core, r)
    for k, v in (r.json() or {}).items():
        if v:
            core.vault.set(u["user_id"], k, str(v))
    return Response.json({"keys": core.vault.keys(u["user_id"])})


@route("GET", "/api/tasks/(?P<tid>[A-Za-z0-9_-]+)")
def task_status(core: App, r: Request, tid: str):
    u = current_user(core, r)
    t = core.tasks.get(tid)
    if not t or t["user"] != u["user_id"]:
        raise HTTPError(404, "task not found")
    return Response.json({k: t[k] for k in ("id", "status", "progress", "result", "error")})


# ---- chats
@route("GET", "/api/chats")
def chats(core: App, r: Request):
    u = current_user(core, r)
    return Response.json(core.store.chats(u["user_id"]))


@route("POST", "/api/chats")
def new_chat(core: App, r: Request):
    u = current_user(core, r)
    body = r.json() if r.ctype.startswith("application/json") else {}
    return Response.json(core.store.new_chat(u["user_id"], (body or {}).get("title") or "New chat"))


@route("GET", "/api/chats/(?P<chat_id>[^/]+)")
def chat_state(core: App, r: Request, chat_id: str):
    u = current_user(core, r)
    s = core.session(u["user_id"], chat_id)
    st = s.state()
    st["messages"] = core.store.messages(u["user_id"], chat_id)
    st["busy"] = core.busy(u["user_id"], chat_id)
    st["chat"] = core.store.chat(u["user_id"], chat_id)
    return Response.json(st)


@route("PATCH", "/api/chats/(?P<chat_id>[^/]+)")
def rename(core: App, r: Request, chat_id: str):
    u = current_user(core, r)
    core.store.update_chat(u["user_id"], chat_id, title=str(r.json().get("title", ""))[:120])
    return Response.json({"ok": True})


@route("DELETE", "/api/chats/(?P<chat_id>[^/]+)")
def delete_chat(core: App, r: Request, chat_id: str):
    u = current_user(core, r)
    if core.busy(u["user_id"], chat_id):
        raise HTTPError(409, "chat is busy")
    core.drop(u["user_id"], chat_id)
    return Response.json({"deleted": core.store.delete_chat(u["user_id"], chat_id)})


@route("GET", "/api/chats/(?P<chat_id>[^/]+)/events")
def events(core: App, r: Request, chat_id: str):
    u = current_user(core, r)
    s = core.session(u["user_id"], chat_id)
    since = int(r.query.get("since", 0) or 0)
    return Response.json({"events": s.events[since:since + 500], "next": min(len(s.events), since + 500),
                          "busy": core.busy(u["user_id"], chat_id), "running": s.running})


# ---- inputs
@route("POST", "/api/chats/(?P<chat_id>[^/]+)/inputs/story")
def story(core: App, r: Request, chat_id: str):
    u = current_user(core, r)
    s = core.session(u["user_id"], chat_id)
    f = r.fields
    mode = f.get("mode", "text")
    if mode == "git":
        tok = core.read_token(u, f.get("token", ""))
        if not tok:
            raise HTTPError(400, "no git token: enter yours in the form, or give the read token in the notebook / AGILEDEV_GIT_READ_TOKEN")

        def job(say):
            say("reading the story from git ...")
            st = s.set_story_from_git(f.get("url", ""), tok, f.get("issue", ""), f.get("path", ""), f.get("ref", ""))
            core.store.update_chat(u["user_id"], chat_id, story_id=st["id"], story_title=st["title"], title=f"{st['id']} {st['title']}"[:120])
            v = _story_view(st)
            core.store.add_message(u["user_id"], chat_id, "assistant", v["summary_text"], {"kind": "story", "card": True})
            return v
        return Response.json({"task": core.start_task(u["user_id"], job)})
    elif mode == "file" and r.files.get("file"):
        name, data = r.files["file"][0]
        st = s.set_story_from_file(name, data)
    else:
        if not f.get("text", "").strip():
            raise HTTPError(400, "empty story")
        st = s.set_story_text(f["text"], f.get("title", ""), f.get("story_id", ""))
    core.store.update_chat(u["user_id"], chat_id, story_id=st["id"], story_title=st["title"], title=f"{st['id']} {st['title']}"[:120])
    v = _story_view(st)
    core.store.add_message(u["user_id"], chat_id, "assistant", v["summary_text"], {"kind": "story", "card": True})
    return Response.json(v)


def _story_view(st: dict) -> dict:
    """What the chat shows right after a story is added (no model call: a deterministic summary)."""
    text = st.get("text", "")
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    body = [l for l in lines if not l.startswith("#")]
    v = {"id": st["id"], "title": st["title"], "chars": st["chars"], "source": st.get("source", {}),
         "acceptance_criteria": st.get("acceptance_criteria", []), "code_blocks": len(st.get("code_blocks", [])),
         "preview": " ".join(body)[:600], "lines": len(lines)}
    ac = "\n".join(f"• {a}" for a in v["acceptance_criteria"])
    v["summary_text"] = (f"**Story {v['id']} - {v['title']}**\n{v['preview']}\n\n{v['chars']} chars, {v['lines']} lines, "
                         f"{v['code_blocks']} code block(s), source {v['source'].get('type', 'text')}"
                         + (f"\n\n**Acceptance criteria**\n{ac}" if ac else "\n\n(no explicit acceptance criteria found - the story agent will derive them)")
                         + "\n\nAdd skills / glossary / standards / tables / a repository if you have them, then press Run or type instructions.")
    return v


@route("POST", "/api/chats/(?P<chat_id>[^/]+)/inputs/docs")
def docs(core: App, r: Request, chat_id: str):
    u = current_user(core, r)
    s = core.session(u["user_id"], chat_id)
    kind = r.fields.get("kind", "")
    maxb = int(core.cfg.inputs.get("max_file_mb", 25)) * 1024 * 1024
    allowed = set(core.cfg.inputs.get("accepted_extensions", []))
    items = []
    for name, data in r.files.get("files", []):
        ext = Path(name).suffix.lower().lstrip(".")
        if allowed and ext not in allowed:
            raise HTTPError(400, f"{name}: extension .{ext} not accepted")
        if len(data) > maxb:
            raise HTTPError(400, f"{name}: larger than {maxb // 1024 // 1024} MB")
        items.append((name, data))
    if not items:
        raise HTTPError(400, "no files received")
    out = s.add_documents(kind, items)
    label = {"skills": "Skills", "glossary": "Glossary / data dictionary", "standards": "Standards & conventions"}.get(kind, kind)
    lines = []
    for d in out:
        extra = (f"{len(d['tables'])} table(s)" if d.get("tables") else f"{len(d.get('sections') or [])} section(s)")
        lines.append(f"• `{d['name']}` - {d['chars']} chars, {extra}" + (f" ⚠ {d['parse_error']}" if d.get("parse_error") else ""))
    core.store.add_message(u["user_id"], chat_id, "assistant", f"**{label}: {len(out)} file(s) added**\n" + "\n".join(lines), {"kind": kind, "card": True})
    return Response.json(out)


@route("DELETE", "/api/chats/(?P<chat_id>[^/]+)/inputs/docs/(?P<kind>[a-z]+)/(?P<name>.+)")
def doc_delete(core: App, r: Request, chat_id: str, kind: str, name: str):
    u = current_user(core, r)
    core.session(u["user_id"], chat_id).inputs.remove_document(kind, unquote(name))
    return Response.json({"ok": True})


@route("DELETE", "/api/chats/(?P<chat_id>[^/]+)/inputs/story")
def story_delete(core: App, r: Request, chat_id: str):
    u = current_user(core, r)
    core.session(u["user_id"], chat_id).inputs.remove_story()
    core.store.update_chat(u["user_id"], chat_id, story_id="", story_title="")
    return Response.json({"ok": True})


@route("DELETE", "/api/chats/(?P<chat_id>[^/]+)/inputs/table/(?P<schema>[^/]+)/(?P<table>[^/]+)")
def table_delete(core: App, r: Request, chat_id: str, schema: str, table: str):
    u = current_user(core, r)
    core.session(u["user_id"], chat_id).inputs.remove_table(unquote(schema), unquote(table))
    return Response.json({"ok": True})


@route("DELETE", "/api/chats/(?P<chat_id>[^/]+)/inputs/query/(?P<name>[^/]+)")
def query_delete(core: App, r: Request, chat_id: str, name: str):
    u = current_user(core, r)
    core.session(u["user_id"], chat_id).inputs.remove_query(unquote(name))
    return Response.json({"ok": True})


@route("DELETE", "/api/chats/(?P<chat_id>[^/]+)/inputs/repo/(?P<name>[^/]+)")
def repo_delete(core: App, r: Request, chat_id: str, name: str):
    u = current_user(core, r)
    core.session(u["user_id"], chat_id).inputs.remove_repo(unquote(name))
    return Response.json({"ok": True})


@route("PUT", "/api/chats/(?P<chat_id>[^/]+)/pipeline")
def pipeline_put(core: App, r: Request, chat_id: str):
    u = current_user(core, r)
    s = core.session(u["user_id"], chat_id)
    from .engine import DEFAULT_PIPELINE
    agents = [a for a in (r.json().get("pipeline") or []) if a in DEFAULT_PIPELINE]
    return Response.json({"pipeline": s.inputs.set_pipeline(agents), "default": DEFAULT_PIPELINE})


@route("POST", "/api/chats/(?P<chat_id>[^/]+)/inputs/repo")
def repo(core: App, r: Request, chat_id: str):
    u = current_user(core, r)
    body = r.json()
    s = core.session(u["user_id"], chat_id)
    tok = core.read_token(u, body.get("token", ""))
    url = body.get("url", "")
    if not tok and url.startswith("http"):
        raise HTTPError(400, "no git token: enter yours in the form, or give the read token in the notebook / AGILEDEV_GIT_READ_TOKEN")

    def job(say):
        try:
            rec = s.add_repo(body.get("url", ""), tok, body.get("branch", ""), body.get("name", ""), body.get("subpath", ""),
                             bool(body.get("refresh")), progress=say)
        except Exception as e:  # noqa: BLE001
            raise HTTPError(400, f"repository: {type(e).__name__}: {str(e)[:300]}")
        langs = ", ".join(f"{k} {v}" for k, v in (rec.get("languages") or {}).items())
        core.store.add_message(u["user_id"], chat_id, "assistant", f"**Repository {rec['name']}@{rec['branch']}: {rec['files']} files indexed**\n"
                               f"{rec['url']}\nlanguages: {langs}\nThe repo agent will use it for folder conventions, patterns to imitate and files to modify.",
                               {"kind": "repo", "card": True})
        return rec
    return Response.json({"task": core.start_task(u["user_id"], job)})


@route("POST", "/api/chats/(?P<chat_id>[^/]+)/inputs/greenplum")
def greenplum(core: App, r: Request, chat_id: str):
    u = current_user(core, r)
    body = r.json()
    s = core.session(u["user_id"], chat_id)
    pw = core.token(u, body.get("password", ""), "gp_password")
    gcfg = core.cfg.inputs.greenplum
    sqlite_path = body.get("sqlite_path") if (core.selftest or gcfg.get("allow_sqlite", False)) else None   # local testing only
    gp = GreenplumInput(body.get("host", ""), body.get("port", 5432) or 5432, body.get("database", ""), body.get("user", ""), pw,
                        body.get("sslmode", "prefer"), int(gcfg.get("statement_timeout_seconds", 60)), sqlite_path=sqlite_path or None)
    if body.get("action") in ("list", "test"):
        try:
            if body.get("action") == "list":
                return Response.json({"tables": gp.list_tables(body.get("schema", ""), body.get("like", ""))})
            return Response.json({"ok": True, "version": gp.test()})
        except Exception as e:  # noqa: BLE001
            raise HTTPError(400, f"Greenplum: {type(e).__name__}: {str(e)[:300]}")
        finally:
            gp.close()

    def job(say):
        try:
            say("connecting ...")
            out = {"tables": [], "query": None}
            tables = [t.strip() for t in (body.get("tables") or []) if t.strip()]
            if tables:
                out["tables"] = s.add_tables(gp, body.get("schema", ""), tables, progress=say, refresh=bool(body.get("refresh")))
            if body.get("query") and gcfg.get("allow_queries", True):
                say("running the query ...")
                out["query"] = s.add_query(gp, body["query"], body.get("query_name", ""))
            lines = [f"• `{t['schema']}.{t['table']}` - {t['columns']} columns" for t in out["tables"]]
            if out["query"]:
                lines.append(f"• query `{out['query']['name']}` - {out['query']['row_count']} rows, columns: " + ", ".join(out["query"]["columns"][:12]))
            core.store.add_message(u["user_id"], chat_id, "assistant", f"**Greenplum: {len(out['tables'])} table(s)" + (" + 1 query" if out["query"] else "") + " added**\n"
                                   + "\n".join(lines) + "\nColumns, types, keys, comments and sample rows go to the data agent.", {"kind": "greenplum", "card": True})
            return out
        except Exception as e:  # noqa: BLE001
            raise HTTPError(400, f"Greenplum: {type(e).__name__}: {str(e)[:300]}")
        finally:
            gp.close()
    return Response.json({"task": core.start_task(u["user_id"], job)})


# ---- generation
@route("POST", "/api/chats/(?P<chat_id>[^/]+)/message")
def message(core: App, r: Request, chat_id: str):
    u = current_user(core, r)
    body = r.json()
    text = str(body.get("text", "")).strip()
    s = core.session(u["user_id"], chat_id)
    if not text:
        raise HTTPError(400, "empty message")
    core.store.add_message(u["user_id"], chat_id, "user", text)
    s.add_history("user", text)
    if s.files and s.summary and not body.get("rerun"):
        core.submit(u["user_id"], chat_id, _job_change, core, u, chat_id, s, text)
        return Response.json({"started": "change"})
    if s.inputs.story is None:
        if len(text) > 80:
            st = s.set_story_text(text)
            core.store.update_chat(u["user_id"], chat_id, story_id=st["id"], story_title=st["title"], title=f"{st['id']} {st['title']}"[:120])
            core.submit(u["user_id"], chat_id, _job_run, core, u, chat_id, s, "")
            return Response.json({"started": "run", "story": st["id"]})
        reply = "Drag the Story icon into the chat (or paste the story text here) - then I can start."
        core.store.add_message(u["user_id"], chat_id, "assistant", reply)
        return Response.json({"reply": reply})
    core.submit(u["user_id"], chat_id, _job_run, core, u, chat_id, s, text if text.lower() not in ("run", "go", "generate", "start") else "")
    return Response.json({"started": "run"})


@route("POST", "/api/chats/(?P<chat_id>[^/]+)/run")
def run(core: App, r: Request, chat_id: str):
    u = current_user(core, r)
    body = r.json() if r.ctype.startswith("application/json") else {}
    s = core.session(u["user_id"], chat_id)
    if s.inputs.story is None:
        raise HTTPError(400, "add a story first")
    instr = str((body or {}).get("instructions", "")).strip()
    if instr:
        core.store.add_message(u["user_id"], chat_id, "user", instr)
    core.submit(u["user_id"], chat_id, _job_run, core, u, chat_id, s, instr)
    return Response.json({"started": "run"})


@route("POST", "/api/chats/(?P<chat_id>[^/]+)/docs")
def docs_toggle(core: App, r: Request, chat_id: str):
    u = current_user(core, r)
    body = r.json()
    s = core.session(u["user_id"], chat_id)
    s.docs_wanted = bool(body.get("enabled", True))
    made = []
    if s.docs_wanted and s.files:
        from .docgen import write_docs
        made = write_docs(s)
        s.docs = made
        s.make_zip()
    return Response.json({"enabled": s.docs_wanted, "files": [Path(m).name for m in made]})


@route("GET", "/api/chats/(?P<chat_id>[^/]+)/docfile/(?P<name>[^/]+)")
def docfile(core: App, r: Request, chat_id: str, name: str):
    u = current_user(core, r)
    s = core.session(u["user_id"], chat_id)
    p = s.folder / Path(unquote(name)).name
    if not p.exists() or p.suffix not in (".docx", ".pptx"):
        raise HTTPError(404, "not found")
    return Response.file(p, p.name)


# ---- files + outputs
@route("GET", "/api/chats/(?P<chat_id>[^/]+)/files/(?P<path>.+)")
def file_get(core: App, r: Request, chat_id: str, path: str):
    u = current_user(core, r)
    s = core.session(u["user_id"], chat_id)
    f = s.files.get(unquote(path))
    if not f:
        raise HTTPError(404, "file not found")
    return Response.json(f)


@route("GET", "/api/chats/(?P<chat_id>[^/]+)/diff/(?P<path>.+)")
def file_diff(core: App, r: Request, chat_id: str, path: str):
    """Unified diff of a generated file against the repository version (empty 'before' for a new file)."""
    import difflib
    u = current_user(core, r)
    s = core.session(u["user_id"], chat_id)
    path = unquote(path)
    f = s.files.get(path)
    if not f:
        raise HTTPError(404, "file not found")
    before = s._existing(path, f.get("repo", "")) or ""
    diff = "".join(difflib.unified_diff(before.splitlines(True), f["content"].splitlines(True), f"a/{path}", f"b/{path}", n=3))
    added = sum(1 for l in diff.splitlines() if l.startswith("+") and not l.startswith("+++"))
    removed = sum(1 for l in diff.splitlines() if l.startswith("-") and not l.startswith("---"))
    return Response.json({"path": path, "action": f.get("action"), "diff": diff, "added": added, "removed": removed, "new_file": not before})


@route("PUT", "/api/chats/(?P<chat_id>[^/]+)/files/(?P<path>.+)")
def file_put(core: App, r: Request, chat_id: str, path: str):
    u = current_user(core, r)
    s = core.session(u["user_id"], chat_id)
    return Response.json(s.update_file(unquote(path), str(r.json().get("content", ""))))


@route("GET", "/api/chats/(?P<chat_id>[^/]+)/download/(?P<what>[a-z]+)")
def download(core: App, r: Request, chat_id: str, what: str):
    u = current_user(core, r)
    s = core.session(u["user_id"], chat_id)
    names = {"zip": None, "log": "log.txt", "plan": "plan.json", "tokens": "tokens.txt", "pack": "pack.json", "review": "review.json",
             "findings": "findings.json", "summary": "run_summary.json", "inputs": "inputs.json", "events": "events.jsonl"}
    if what not in names:
        raise HTTPError(404, "not found")
    p = s.make_zip() if what == "zip" else s.folder / names[what]
    if not p.exists():
        raise HTTPError(404, f"{what} not available yet")
    return Response.file(p, p.name)


@route("GET", "/api/chats/(?P<chat_id>[^/]+)/text/(?P<what>[a-z]+)")
def text_get(core: App, r: Request, chat_id: str, what: str):
    u = current_user(core, r)
    s = core.session(u["user_id"], chat_id)
    p = s.folder / {"log": "log.txt", "tokens": "tokens.txt"}.get(what, "x")
    return Response.text(p.read_text(encoding="utf-8")[-200000:] if p.exists() else "")


# ---- git push
@route("GET", "/api/chats/(?P<chat_id>[^/]+)/branch-suggestion")
def branch(core: App, r: Request, chat_id: str):
    u = current_user(core, r)
    s = core.session(u["user_id"], chat_id)
    url = r.query.get("url", "")
    repos = s.inputs.repos
    return Response.json({"branch": s.suggest_branch(url), "repo_url": url or (repos[0]["url"] if repos else ""),
                          "base_branch": (repos[0]["branch"] if repos else ""), "files": list(s.files)})


@route("POST", "/api/chats/(?P<chat_id>[^/]+)/push")
def push(core: App, r: Request, chat_id: str):
    u = current_user(core, r)
    body = r.json()
    s = core.session(u["user_id"], chat_id)
    tok = body.get("token", "")
    if not tok:                      # a push is made ONLY with the token typed in the push form: the branch carries that user's identity
        raise HTTPError(400, "your personal git token is required to push: the branch and commit are created under your name")
    try:
        res = s.publish(body["url"], tok, body["branch"], body["base_branch"], body.get("message", ""), None, body.get("paths"))
    except Exception as e:  # noqa: BLE001
        raise HTTPError(400, f"push failed: {type(e).__name__}: {str(e)[:300]}")
    core.store.add_message(u["user_id"], chat_id, "assistant", f"Pushed {res['files']} file(s) to branch {res['branch']} (from {res['base_branch']}) "
                           f"as {res.get('pushed_as')}: {res.get('branch_url')}", {"kind": "publish", **res})
    core.store.update_chat(u["user_id"], chat_id, status="pushed")
    return Response.json(res)


# ----------------------------------------------------------------------------- jobs
def _job_run(core: App, u: dict, chat_id: str, s: ChatSession, instructions: str):
    uid = u["user_id"]
    try:
        core.store.update_chat(uid, chat_id, status="running")
        summary = s.run(instructions)
        files = "\n".join(f"- `{f['path']}` ({f['language']}, {f['action']})" for f in summary["files"])
        rev = summary.get("review") or {}
        reply = (f"Done in {summary['duration_seconds']}s - {len(summary['files'])} file(s), quality {summary['quality_score']}/100"
                 + (f", review {rev.get('verdict')} ({rev.get('score')})" if rev.get("verdict") else "")
                 + f", {summary['tokens'].get('total_tokens', 0)} tokens.\n\n**Approach:** {s.plan.get('approach', '')}\n\n{files}\n\n"
                 "Open the Files tab to read or edit, ask for changes here, download the zip, or push a branch.")
        if s.plan.get("questions"):
            reply += "\n\n**Open questions:** " + "; ".join(s.plan["questions"][:5])
        core.store.add_message(uid, chat_id, "assistant", reply, {"kind": "run", "summary": summary})
        s.add_history("assistant", reply)
        core.store.update_chat(uid, chat_id, status="done")
    except Exception as e:  # noqa: BLE001
        log.exception("run job failed")
        core.store.add_message(uid, chat_id, "assistant", f"The run failed: {type(e).__name__}: {str(e)[:400]}", {"kind": "error"})
        core.store.update_chat(uid, chat_id, status="failed")


def _job_change(core: App, u: dict, chat_id: str, s: ChatSession, text: str):
    uid = u["user_id"]
    try:
        core.store.update_chat(uid, chat_id, status="running")
        res = s.change(text)
        reply = res.get("reply", "")
        if res.get("changed"):
            reply += "\n\nChanged: " + ", ".join(f"`{p}`" for p in res["changed"]) + f". Quality now {s.summary.get('quality_score')}/100."
        core.store.add_message(uid, chat_id, "assistant", reply, {"kind": "change", "changed": res.get("changed", [])})
        s.add_history("assistant", reply)
        core.store.update_chat(uid, chat_id, status="done")
    except Exception as e:  # noqa: BLE001
        log.exception("change job failed")
        core.store.add_message(uid, chat_id, "assistant", f"The change failed: {type(e).__name__}: {str(e)[:400]}", {"kind": "error"})
        core.store.update_chat(uid, chat_id, status="done")


# ----------------------------------------------------------------------------- HTTP plumbing
class Handler(BaseHTTPRequestHandler):
    core: App = None
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):      # quiet access log (paths only, never bodies)
        log.debug("%s %s", self.address_string(), fmt % args)

    def _dispatch(self, method: str):
        try:
            r = Request(self)
            for m, rx, fn in ROUTES:
                if m != method:
                    continue
                mm = rx.match(r.path)
                if mm:
                    resp = fn(self.core, r, **mm.groupdict())
                    break
            else:
                raise HTTPError(404, "not found")
        except HTTPError as e:
            resp = Response.json({"detail": e.detail}, e.code)
        except Exception as e:  # noqa: BLE001
            log.error("request failed: %s\n%s", e, traceback.format_exc())
            resp = Response.json({"detail": f"{type(e).__name__}: {e}"}, 500)
        self.send_response(resp.code)
        self.send_header("Content-Type", resp.ctype)
        self.send_header("Content-Length", str(len(resp.body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in resp.headers:
            self.send_header(k, v)
        self.end_headers()
        if method != "HEAD":
            self.wfile.write(resp.body)

    def do_GET(self):
        self._dispatch("GET")

    def do_POST(self):
        self._dispatch("POST")

    def do_PUT(self):
        self._dispatch("PUT")

    def do_PATCH(self):
        self._dispatch("PATCH")

    def do_DELETE(self):
        self._dispatch("DELETE")

    def do_HEAD(self):
        self._dispatch("HEAD")


class Server:
    def __init__(self, core: App, host: str, port: int):
        handler = type("BoundHandler", (Handler,), {"core": core})
        self.httpd = ThreadingHTTPServer((host, port), handler)
        self.httpd.daemon_threads = True
        self.core, self.host, self.port = core, host, port
        self.thread: Optional[threading.Thread] = None

    def run(self):
        try:
            self.httpd.serve_forever()
        except KeyboardInterrupt:
            pass

    def start_background(self):
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True, name="agiledev-web")
        self.thread.start()
        return self

    def stop(self):
        self.httpd.shutdown()
        self.httpd.server_close()


def create_app(cfg: Optional[Config] = None, llm=None, selftest: bool = False) -> App:
    return App(cfg or load_config(), llm, selftest)


def serve(cfg: Optional[Config] = None, host: Optional[str] = None, port: Optional[int] = None, selftest: bool = False,
          llm=None, open_browser: bool = False, background: bool = False, git_read_token: str = "") -> Server:
    cfg = cfg or load_config()
    core = create_app(cfg, llm, selftest)
    core.git_read_token = git_read_token or ""          # memory only
    host = host or cfg.server.get("host", "0.0.0.0")
    port = int(port or cfg.server.get("port", 8780))
    srv = Server(core, host, port)
    log.info("%s listening on http://%s:%d/ (auth %s%s)", cfg.product.get("name"), host, port, core.auth.mode, ", self-test" if selftest else "")
    if open_browser:
        import webbrowser
        threading.Timer(1.0, lambda: webbrowser.open(f"http://{'localhost' if host in ('0.0.0.0', '') else host}:{port}/")).start()
    if background:
        return srv.start_background()
    srv.run()
    return srv
