"""Daily client activity summary DAG."""
from datetime import datetime

from airflow import DAG
from airflow.providers.postgres.operators.postgres import PostgresOperator

with DAG(dag_id='client_activity_summary', schedule='0 6 * * 1-5', start_date=datetime(2026, 1, 1), catchup=False,
         params={'IKG_SCHEMA': 'core_ikg'}) as dag:
    build = PostgresOperator(task_id='build_client_activity_summary', postgres_conn_id='IKG_GP',
                             sql='scripts/sql/ikg_create_profiles/client_activity_summary_ikg.sql')
