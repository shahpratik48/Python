-- story: client activity summary
drop table if exists {{params.IKG_SCHEMA}}.client_activity_summary_ikg;
create table {{params.IKG_SCHEMA}}.client_activity_summary_ikg as
select c.client_id, c.acc_mhh_n, sum(a.balance) as total_balance, count(*) as active_accounts
from {{params.IKG_SCHEMA}}.account_fact a join {{params.IKG_SCHEMA}}.client_dim c on c.client_id = a.client_id
where a.status_cd = 'A' group by c.client_id, c.acc_mhh_n
distributed by (client_id);
