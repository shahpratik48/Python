profile_history_delta=[
        #'transaction_recipient_profile_ikg',
        'household_wire_transaction_profile_ikg',
        'mtp_profile_ikg',
        'mtg_client_profile_ikg',
        ### 'client_mtg_profile_ikg',
        'household_profile_ikg',
        'household_holdings_profile_ikg',
        'client_wealthx_profile_ikg',        
        'client_wealthx_delta_profile_ikg',
        'client_profile_ikg',
        'client_medallia_profile_ikg',
        'speedeon_life_events_profile_ikg',
        #'client_jornaya_activate_profile_ikg', 
        'zoominfo_scoops_profile_ikg',
        'zoominfo_intents_profile_ikg',
        'zoominfo_firmographic_profile_ikg',
        'fl_rec_profile_ikg',
        'fl_fa_profile_ikg',
        # 'benchmark_profile_ikg', not needed anymore
        'account_profile_ikg'
]
    build_client_activity_summary = None  # task registered for client_activity_summary_ikg.sql
