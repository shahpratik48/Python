TABLE_CONFIG = {
    'account_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'mtg_client_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'client_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'mtp_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'household_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'household_holdings_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'household_wire_transaction_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'client_medallia_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'client_wealthx_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'client_wealthx_delta_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'client_wealthx_attributes_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'client_fga_goal_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'account_sbl_contract_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'account_holdings_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'speedeon_life_events_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'bknight_assmt_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'bknight_mls_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'asset_allocation_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'zoominfo_intents_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'zoominfo_scoops_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'zoominfo_firmographic_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'account_holdings_mat_sec_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'yodlee_mtp_acc_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'yodlee_mtp_transaction_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'yodlee_mtp_account_holding_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'household_optimus_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'client_brightscope_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'household_art_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'account_insurance_policy_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'account_market_events_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'account_ext_mkt_events_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'bknight_assmt_prospect_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'account_mmf_to_core_svngs_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'client_windfall_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'fl_fa_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'fl_rec_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },'prospect_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'prospect_windfall_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'prospects_wealthx_delta_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'speedeon_prospect_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'client_newsedge_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },
    'deceased_client_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    },    
    'household_bill_payment_spending_profile_curr_ikg': {
        'partition_column': 'index',
        'filter_column': 'profile_date'
    }
}
    build_client_activity_summary = None  # task registered for client_activity_summary_ikg.sql
