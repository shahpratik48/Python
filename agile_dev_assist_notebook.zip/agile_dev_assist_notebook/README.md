# Agile Dev Assist - story in, reviewed code out

An enterprise code-generation studio any team can use: start from a system template (IKG / ODM / NLG - the nightly
**System Knowledge Pack**: pre-analysed, indexed repository, tables, conventions, rules and git branch conventions), drag the
story in, optionally add knowledge documents, a glossary, Greenplum tables or a live repository clone, press Run, and get planned,
generated, validated and reviewed code (Python, SQL, R, notebooks, Airflow DAGs, YAML, shell ...) with a plan,
a log, token statistics, a zip and a git branch pushed under your own name.

Two editions, one engine (`agiledev/` is identical):

| | **Web app** (`agiledev_webapp.zip`) | **Notebook** (`agiledev_notebook.zip`) |
|---|---|---|
| start | `python app_server.py` (systemd / Docker) | `Agile_Dev_Assist.ipynb` |
| users | single sign-on, one session + history per user | you (`USER` env) |
| UI | drag-and-drop icons, chat, resizable panels | notebook cells (+ optional local web UI) |
| secrets | env variables named in the config; user tokens entered in the UI | hidden prompts (`getpass`) |

## How it works

```
inputs (dynamic)                     standard JSON                 agents (GPT-5, tool calling)              outputs
story: git issue / file / text ─┐                              story_agent ──┐
skills  (md yml txt csv xlsx    ├─► readers ─► inputs.json ─► knowledge_agent ├─► planner_agent ─► coder_agent (parallel, per file)
         doc docx html ...)     │              pack.json       data_agent      │        │                 │
glossary / data dictionary      │  (char budgets per section,  repo_agent ────┘        ▼                 ▼
standards & conventions         │   relevant files retrieved)                  validators (syntax, DAG, rules from the standards)
Greenplum tables / query ───────┤                                                       │ findings -> coder fix mode (2 rounds)
git repository (code) ──────────┘                                               reviewer_agent (independent) -> critical/high -> fix
                                                                                        ▼
                                             files · plan.json · review.json · findings.json · log.txt · tokens.txt · zip · docx/pptx · git branch
```

* Every input becomes a **standard document** (`{"name","format","kind","text","sections","tables","data"}`),
  a **table description** (columns, types, keys, distribution, comments, sample rows) or an **indexed repository**
  (language, symbols, BM25 retrieval). The agents only ever see `pack.json`.
* **Knowledge packs** (project 6, `packs/<system>_pack.zip`): a pack attached to a chat supplies, with no model call, the
  system's conventions / definitions / checkable rules, the repository copy with its folder guide (purpose, registration rule
  AUTOMATIC / STATIC, companion rules, exemplar file), the described tables with their semantics, a lineage graph (impact) and a
  hybrid index (BM25 + vectors) - so the knowledge / data / repo agents mostly skip the model, the planner gets exact facts,
  the validator gets the rules, and the reviewer the conventions. The prebuilt templates IKG / ODM / NLG (config
  `knowledge_packs.templates`) attach the pack plus the system's git conventions (base branch, MR target, branch name pattern).
* The **knowledge agent** turns the standards into regex rules the validator checks mechanically
  (`"schema names must never be literal"` -> a rule); the reviewer builds on the validator's findings.
* The whole generate -> validate -> review -> regenerate loop runs under `product.max_run_minutes` (5): files are
  written in parallel, agents get prefetched context so they need few tool calls, results are cached by input.
* Follow-up requests in the chat ("add a filter on active clients", "also write a test") go through the
  change agent and the coder in fix mode; the files can also be edited by hand in the Files tab.
* **Push**: branch `storyid-projectreponame-feature` (template in `git.branch_template`) created from the base
  branch you name, every file committed with YOUR token - the commit and branch carry your identity.

## How accuracy is enforced (what the agents must do, checked by code)
* **Story code is a specification**: the story agent must describe every code block (`code_in_story`), the planner
  must say where each block is used (`design.story_code_usage`), the coder receives the blocks verbatim, the
  reviewer reports `story_code_check` per block. A plan that ignores a block is rejected and redone.
* **Registration points**: `registration_points(folder)` finds the files that register the scripts of a folder (the
  Airflow DAG task list, task-name files, config lists). The repo agent must list them, the planner must modify
  them (or decline each one explicitly), the reviewer flags a missing registration as critical. A new script that
  never runs is the most common defect - it is now caught three times.
* **Impact**: `references(name)` lists every use of a table / column / function; the repo agent reports the impact,
  the reviewer writes an `impact_assessment` per change (consumers, grain, runtime, grants, history tables).
* **Design before code**: the planner produces `design` - small single-purpose modules, temp / intermediate tables
  with grain and distribution key, explicit performance decisions (filter early, one pass over the fact, distribute
  by the join key) - and the coder follows it; expressions are simplified only when provably identical.
* **Standards**: rules from the standards documents are checked mechanically by the validator and reported per
  rule by the reviewer (`standards_check`); critical / high findings trigger a regeneration.

## Web app

```bash
unzip agiledev_webapp.zip && cd agiledev_webapp
python -m venv .venv && .venv/bin/pip install -r requirements.txt
export AGILEDEV_AZURE_OPENAI_API_KEY=...   AGILEDEV_AZURE_EMBEDDINGS_API_KEY=...   AGILEDEV_SERVER_SECRET=$(openssl rand -hex 32)
.venv/bin/python app_server.py --check      # model reachable?
.venv/bin/python app_server.py              # http://<server>:8780
```
systemd unit, nginx example and Docker files are in `deploy/`, `Dockerfile`, `docker-compose.yml`.
Demo without any secret: `python app_server.py --selftest` (scripted model, sample inputs under `data_selftest/samples`,
dev login) - use it to show the UI. Offline engine test: `python app_server.py --run-selftest`.

### Single sign-on (`auth:` in `config/agiledev_config.yaml`)
| mode | what happens |
|---|---|
| `header` (default) | the corporate SSO (reverse proxy / IdP agent) authenticates and forwards the user id in `auth.header_name` (`X-Remote-User`); no login page |
| `oidc` | OpenID Connect code flow against `auth.oidc.issuer` (Entra ID / Okta / Keycloak); set `client_id`, and `AGILEDEV_OIDC_CLIENT_SECRET` |
| `dev` | a login form asking only for a user id - local runs and demos |

Whatever the mode, the app issues its own signed HttpOnly cookie (`AGILEDEV_SERVER_SECRET`, `auth.session_hours`).
`allowed_users` restricts access; `admins` is reserved for future admin actions.

### Per-user sessions
* Chats: SQLite `data/agiledev.db` (users, chats, messages) + `data/users/<user>/chats/<chat>/` with every input
  (`inputs.json`, the uploaded files), the context pack, plan, generated files, review, findings, log, tokens, zip,
  docs. A user lists, reopens and deletes only their own chats; **New chat** starts an empty chat with empty panels.
* In one chat the user can add another story (or more skills / tables / repos) and run again; the inputs stay.
* Git tokens and Greenplum passwords are posted by the UI into an in-memory vault for that user (never written),
  reused for the rest of the session, gone on restart or sign-out.
* The Azure key is server-wide (environment variable from `secrets.llm_api_key`); the LLM response cache is shared.

### UI
Left panel: input icons (drag into the chat or click), agent icons (state + token count on click), tools (Run,
Push branch, Download zip, Log / plan, Tokens, Docs), my chats. Centre: the chat with milestones and a live
mini-log. Right panel: Inputs, Plan, Files (editor with save / download), Review (validator + reviewer findings,
requirement coverage), Log, Tokens (per agent + total), Outputs (downloads, push, documentation).
Both side panels are resizable (drag the separators; widths are remembered).

## Testing everything locally
* `python app_server.py --selftest` (web zip) or `SELFTEST = True` + the **Launch UI** button (notebook): scripted
  model, dev login, sample story / skills / glossary / standards, a sqlite file playing Greenplum
  (`data_selftest/samples/sample_gp.db`, enter it in the Greenplum form's *Local test* field) and a sample
  repository folder (`data_selftest/samples/repo`, enter the folder path in the Git repo form). Every input, agent,
  tool and chat feature works without any corporate service; only *Push branch* needs a real git host.
* With the real model (`SELFTEST = False`, key from the environment variable or the hidden prompt) the same local UI
  runs the real agents; a local folder can still replace the git repository and your own Greenplum connection
  details go into the form.

## Notebook edition
`Agile_Dev_Assist.ipynb`: the same calls as the API (`ChatSession.set_story_*`, `add_documents`, `add_tables`,
`add_query`, `add_repo`, `run`, `change`, `make_zip`, `publish`) - secrets via `getpass`. `SELFTEST = True`
runs everything with the scripted model and the sample inputs. The last cell starts the web UI locally.

## Configuration (`config/agiledev_config.yaml`)
`llm` (deployment, pacing), `secrets` (secret name -> environment variable), `inputs` (accepted extensions,
repository download limits, Greenplum sampling), `context` (character budgets per section), `generation`
(languages, parallel files, fix / review rounds, docs), `agents` (reasoning effort per agent), `git`
(branch template, push with the user's token), `auth`, `storage`, `server`. No secret is ever in this file.

## Token statistics
`tokens.txt` / `tokens.json` per chat and the Tokens tab: calls, cache hits, prompt / completion / reasoning /
cached tokens, seconds in calls - per agent and in total; also appended to `log.txt` after every run.

## Regression bench (team standards + 5 real stories)

```
python app_server.py --bench bench/ikg.yaml              # every story: planned files vs the files the merged MR touched
python app_server.py --bench bench/ikg.yaml --scripted   # offline smoke run (no key)
python app_server.py --bench-compare bench/results/<before>.json bench/results/<after>.json
```
`bench/ikg.yaml` lists the stories (`stories/<id>.md` or inline text), the pack (`prebuilt:ikg` or a zip) and, per story,
`expected_files` = `git diff --name-only ikg-master...<mr branch>` of the merged MR. The report gives precision / recall of
the plan, delivered files, quality, review verdict, seconds and cost per story and writes `bench/results/<name>_<time>.json`.
With a knowledge pack attached the planner is COMPLETED by code from the pack's proven rules only (sibling by stem rule,
registries that list >= 60 % of a folder's scripts, positive `registration_changes` entries) - loose name mentions are
left to the planner.

## Feature branches (real git)

`Feature branch` tool = checkout: for every repository the story touches (IKG / ODM / NLG rows prefilled from the templates -
repository URL, base branch `*-master`, suggested feature branch `<story>-<system>-<feature>`, merge target `*-dev`; all editable)
the branch is created locally from the base as a `git worktree` of a shared bare mirror (`data/cache/git/<repo>.git`, read token,
locked; a worktree costs ~1 s). The worktree is the chat's live repository: agents read and edit it (pack facts stay on top).
Every run commits the generated files on the branch as the chat's user. `Push & MR`: rebase on the base branch, re-author every
commit to the owner of the personal token, push, open the merge request to the target - branch, commits and MR all carry that
user's name; a rebase conflict aborts and is reported; a conflict preview against the target is added to the MR. Deleting a
chat removes its worktrees; the remote branch stays. The API-commit push remains for chats without a branch.
