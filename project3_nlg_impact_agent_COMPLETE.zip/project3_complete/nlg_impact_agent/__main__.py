"""
Command-line entry point for the branch impact agent.

    python -m nlg_impact_agent analyze --branch feature/my-change --xlsx impact.xlsx
    python -m nlg_impact_agent analyze --branch feature/my-change --base-branch release/2026.3 --xlsx impact.xlsx
"""
from __future__ import annotations

import argparse

from .config import ImpactSettings
from .agent import analyze_branch_impact
from .xlsx_report import export_xlsx


def main(argv=None):
    parser = argparse.ArgumentParser(prog="nlg_impact_agent")
    parser.add_argument("--non-interactive", action="store_true")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("analyze", help="Analyze a branch's change impact against a base branch.")
    p.add_argument("--branch", required=True, help="The developer's branch to analyze.")
    p.add_argument("--base-branch", default="develop", help="What to diff against (default: develop).")
    p.add_argument("--provider", choices=["azure_openai", "azure_gateway"], default="azure_openai",
                    help="The agent requires an LLM -- 'none' is not valid here.")
    p.add_argument("--max-iterations", type=int, default=40)
    p.add_argument("--xlsx", required=True, help="Output xlsx path.")

    args = parser.parse_args(argv)

    settings = ImpactSettings(branch=args.branch, base_branch=args.base_branch,
                                llm_provider=args.provider, max_agent_iterations=args.max_iterations)
    settings.resolve_secrets(interactive=not args.non_interactive)
    if not settings.llm_enabled:
        parser.error("This agent requires a working LLM key -- resolve_secrets() did not find one.")

    report = analyze_branch_impact(settings, progress=print)
    out_path = export_xlsx(report, args.xlsx)

    n_impact = sum(1 for c in report.changes if c.get("has_impact"))
    print(f"\nWrote impact report to {out_path}: {len(report.changes)} change(s) assessed, "
          f"{n_impact} with impact.")
    print("\nOverall summary:", report.overall_summary)


if __name__ == "__main__":
    main()
