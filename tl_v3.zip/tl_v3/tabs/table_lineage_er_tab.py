"""
table_lineage_er_tab.py
───────────────────────
Table Lineage tab — uses the same vis-network style as column_lineage_template.html.

Routing logic:
  • table ends with _profile_curr_ikg  → query ikg_lineage_<table> (pre-built)
  • any other table                     → query ikg_table_lineage_metadata_auto_refresh
                                         for BOTH upstream (sources) AND downstream
                                         (consumers) in the same graph

Right panel per node:
  Source table  |  Target table  |  Process  |  SQL file name  |  GitLab link
"""
import json
import re
import urllib.parse
from pathlib import Path

import pandas as pd
from dash import Input, Output, dcc, html
from flask import request
from styles import metadata_dashboard_styles as mds
from utils.data import (
    get_all_lineage_tables,
    get_table_lineage_downstream,
    get_table_lineage_for_profile,
    get_table_lineage_upstream,
    is_profile_table,
)

# ── GitLab base URL (same project path as used by ikg_lineage_sql_stitcher) ─
GITLAB_BASE = (
    "https://devcloud.ubs.net/"
    "ubs/gwma/smart-technology-and-analytics/staat-data-science/"
    "staat-ds-genesis/genesis-platform/ikg-dags/-/blob/ikg-master/"
)

# ── Schema → colour (matches column_lineage_template.html RAW2COLOR) ─────────
RAW2COLOR = {
    "ikg_schema": "#1976d2", "sandbox_prj_smart_insights": "#1976d2",
    "sandbox_ikg_pre_prd": "#1976d2", "edw_input_schema": "#00897b",
    "core_wma_shared": "#00897b", "edw_view_input_schema": "#00897b",
    "ikg_vendor_schema": "#00897b", "core_wma_shared_masked": "#26a69a",
    "sandbox_wma_shared": "#388e3c", "sandbox_prj_ds_data": "#f4511e",
    "sandbox_prj_sbl": "#7b1fa2", "core_nlg": "#5c6bc0",
    "nlg_schema": "#5c6bc0", "core_model": "#6d4c41",
    "model_schema": "#6d4c41", "sandbox_prj_dsforoverdrive": "#0288d1",
    "core_in_shared": "#689f38", "ikg_clip_schema": "#689f38",
    "sandbox_prj_adhoc": "#e91e8c", "ikg_wealthx_schema": "#00838f",
    "sandbox_prj_rbat": "#9e7c0a", "_default": "#607d8b",
}
LEGEND_DATA = [
    {"label": "ikg",                               "color": "#1976d2"},
    {"label": "core_wma_shared",    "color": "#00897b"},
    {"label": "core_nlg",                          "color": "#5c6bc0"},
    {"label": "core_model",                        "color": "#6d4c41"},
    {"label": "temp",                              "color": "#607d8b"},
]


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _s(v) -> str:
    if v is None:
        return ""
    try:
        if pd.isna(v):
            return ""
    except Exception:
        pass
    s = str(v).strip()
    return "" if s.lower() in ("none", "nan") else s


def _schema_for_table(table: str, df: pd.DataFrame) -> str:
    """Derive schema from source_schema column in lineage df."""
    # Try as source table first, then as target
    for col in ("source_table", "target_table"):
        if col in df.columns:
            mask = df[col].astype(str).str.lower().str.strip() == table.lower().strip()
            sub = df[mask]
            if not sub.empty:
                sc = _s(sub.iloc[0].get("source_schema", ""))
                if sc:
                    return sc
    return ""


def _gitlab_url(filepath: str) -> str:
    fp = _s(filepath)
    if not fp or fp.lower() in ("none", "nan", ""):
        return ""
    return GITLAB_BASE + fp.lstrip("/")


# ─────────────────────────────────────────────────────────────────────────────
# Graph builder → ALL_GRAPHS format (same as column_lineage_template.html)
#
# Node format  : {id, tbl, col, schema, is_start, web_url}
#   id  = table name (unique)
#   tbl = table name
#   col = SQL filename (short, shown below table name in node box)
#   web_url = GitLab URL for the SQL file
#
# nrows format : {node_id: [{target_table, source_table, process,
#                             sql_process, logic, target_schema,
#                             source_schema, web_url}]}
#   nrows[node_id] = rows where THIS node is the target
#   Shown in right panel as: source, destination, process, file, link
# ─────────────────────────────────────────────────────────────────────────────

def _build_all_graphs(table_name: str) -> list:
    table_name = _s(table_name)
    if not table_name:
        return []

    if is_profile_table(table_name):
        return _build_profile_graph(table_name)
    else:
        return _build_combined_graph(table_name)


def _rows_to_graph_section(
    df: pd.DataFrame,
    focal_table: str,
    section_label: str,
    insight_type: str = "",
) -> dict | None:
    """
    Build one ALL_GRAPHS section dict from a lineage DataFrame.
    DataFrame columns: target_table, source_table, source_schema,
                       process, filename, filepath  [+ optionally depth]
    """
    if df.empty:
        return None

    nodes_dict: dict[str, dict] = {}
    edges_set:  set[tuple]      = set()
    edges_list: list[dict]      = []
    nrows:      dict[str, list] = {}

    focal_id = focal_table

    def _ensure_node(table: str, schema: str, filename: str, filepath: str, is_start: bool = False):
        if table not in nodes_dict:
            nodes_dict[table] = {
                "id":       table,
                "tbl":      table,
                "col":      Path(filename).stem if filename else "",
                "schema":   schema,
                "is_start": is_start,
                "web_url":  _gitlab_url(filepath),
            }
        else:
            nd = nodes_dict[table]
            if schema and not nd["schema"]:      nd["schema"]  = schema
            if filename and not nd["col"]:       nd["col"]     = Path(filename).stem
            if filepath and not nd["web_url"]:   nd["web_url"] = _gitlab_url(filepath)

    # Pre-seed focal node
    _ensure_node(focal_table, "", "", "", is_start=True)
    nrows[focal_id] = []

    for r in df.itertuples(index=False):
        tgt   = _s(getattr(r, "target_table",  None))
        src   = _s(getattr(r, "source_table",  None))
        sch   = _s(getattr(r, "source_schema", None))
        proc  = _s(getattr(r, "process",       None))
        fname = _s(getattr(r, "filename",      None))
        fpath = _s(getattr(r, "filepath",      None))

        if not tgt or not src:
            continue

        _ensure_node(tgt, sch, fname, fpath, is_start=(tgt == focal_table))
        _ensure_node(src, sch, fname, fpath)

        ek = (src, tgt)
        if ek not in edges_set:
            edges_set.add(ek)
            edges_list.append({"from": src, "to": tgt})

        # nrows for target node (shown in right panel when node clicked)
        row_dict = {
            "target_table":  tgt,
            "target_schema": sch,
            "sub_target_table": tgt,
            "sub_target_schema": sch,
            "target_column": "",
            "source_table":  src,
            "source_schema": sch,
            "source_column": "",
            "process":       proc,
            "sql_process":   "sql",
            "logic":         fname,   # SQL filename shown in monospace
        }
        nrows.setdefault(tgt, []).append(row_dict)

    # Ensure every node has nrows entry
    for nid in nodes_dict:
        nrows.setdefault(nid, [])

    if len(nodes_dict) <= 1:
        return None

    return {
        "profile_table": focal_table,
        "rule_column":   focal_table,
        "insight_type":  insight_type,
        "section_label": section_label,
        "nodes":         list(nodes_dict.values()),
        "edges":         edges_list,
        "nrows":         nrows,
    }


def _build_profile_graph(table_name: str) -> list:
    """
    Profile tables use the pre-built ikg_lineage_<table> table.
    Columns: order_index, root_profile_table, target_table, source_schema,
             source_table, process, filename, filepath.
    Shows complete upstream lineage (sources → profile_table).
    """
    try:
        df = get_table_lineage_for_profile(table_name)
    except Exception:
        return []

    if df.empty:
        return []

    sec = _rows_to_graph_section(df, table_name, "upstream lineage")
    return [sec] if sec else []


def _build_combined_graph(table_name: str) -> list:
    """
    Non-profile tables: combine upstream (sources) and downstream (consumers)
    into a single graph. The focal table sits in the centre; edges flow left → right.
    Returns up to two sections: Upstream and Downstream.
    """
    sections = []

    # ── Upstream section ─────────────────────────────────────────────────────
    try:
        df_up = get_table_lineage_upstream(table_name)
    except Exception:
        df_up = pd.DataFrame()

    if not df_up.empty:
        sec_up = _rows_to_graph_section(df_up, table_name, "upstream (sources)")
        if sec_up:
            sections.append(sec_up)

    # ── Downstream section ───────────────────────────────────────────────────
    try:
        df_down = get_table_lineage_downstream(table_name)
    except Exception:
        df_down = pd.DataFrame()

    if not df_down.empty:
        sec_down = _rows_to_graph_section(df_down, table_name, "downstream (consumers)")
        if sec_down:
            sections.append(sec_down)

    return sections


# ─────────────────────────────────────────────────────────────────────────────
# Template rendering — reuses column_lineage_template.html exactly
# ─────────────────────────────────────────────────────────────────────────────

def _template_path() -> Path:
    return Path(__file__).resolve().parents[1] / "utils" / "table_lineage_template.html"


def _render(table_name: str) -> str:
    template   = _template_path().read_text(encoding="utf-8")
    all_graphs = _build_all_graphs(table_name)

    payload = (
        f"var ALL_GRAPHS  = {json.dumps(all_graphs)};\n"
        f"var RAW2COLOR   = {json.dumps(RAW2COLOR)};\n"
        f"var LEGEND_DATA = {json.dumps(LEGEND_DATA)};"
    )
    template = re.sub(
        r"var ALL_GRAPHS\s*=\s*.*?;\s*var RAW2COLOR\s*=\s*.*?;\s*var LEGEND_DATA\s*=\s*.*?;",
        lambda _: payload,
        template,
        flags=re.DOTALL,
    )
    template = re.sub(
        r"<title>.*?</title>",
        f"<title>{table_name} — Table Lineage</title>",
        template, count=1, flags=re.DOTALL,
    )
    return template


# ─────────────────────────────────────────────────────────────────────────────
# Dash layout
# ─────────────────────────────────────────────────────────────────────────────

def layout(df_profile_tables: pd.DataFrame):
    """
    df_profile_tables is passed in from the dashboard (existing pattern).
    We load all tables from the master lineage table for the dropdown.
    """
    try:
        df_all = get_all_lineage_tables()
        table_opts = [
            {"label": t, "value": t}
            for t in df_all["table_name"].dropna().astype(str).tolist()
            if t.strip()
        ]
    except Exception:
        # Fallback to profile tables only
        table_opts = [
            {"label": t, "value": t}
            for t in df_profile_tables.iloc[:, 0].dropna().astype(str).tolist()
        ] if not df_profile_tables.empty else []

    return dcc.Tab(
        label="Table Lineage",
        value="tab-table-lineage-er",
        children=html.Div(
            [
                html.H3("Table Lineage", style=mds["section_header_style"]),
                html.Div(
                    [
                        html.Div(
                            [
                                html.Span("Table", style=mds["dropdown_label_style"]),
                                dcc.Dropdown(
                                    id="tl-er-profile",
                                    options=table_opts,
                                    placeholder="Search any table …",
                                    clearable=True,
                                    searchable=True,
                                    style={**mds["dropdown_style"], "width": "520px"},
                                ),
                            ],
                            style={"minWidth": "560px"},
                        ),
                        html.Div(id="tl-er-badge", style={
                            "marginLeft": "auto", "alignSelf": "center", "marginTop": "18px",
                            "fontSize": "11px", "color": "#1d4ed8", "fontWeight": "600",
                            "padding": "4px 12px", "background": "#dbeafe",
                            "border": "1px solid #93c5fd", "borderRadius": "20px",
                        }),
                    ],
                    style={
                        **mds["toolbar_style"],
                        "display": "flex", "alignItems": "flex-start",
                        "gap": "16px", "flexWrap": "wrap", "marginBottom": "10px",
                    },
                ),
                # Info card: shows whether profile table (specific) or general (upstream+downstream)
                html.Div(id="tl-er-info", style={
                    "display": "none",
                    "padding": "8px 14px",
                    "background": "#f0f4ff",
                    "border": "1px solid #c7d7f0",
                    "borderRadius": "8px",
                    "fontSize": "12px",
                    "color": "#334155",
                    "marginBottom": "10px",
                }),
                html.Iframe(
                    id="tl-er-iframe",
                    src="",
                    style={
                        "width": "100%",
                        "height": "88vh",
                        "border": "1px solid #e2e8f0",
                        "borderRadius": "8px",
                        "background": "#ffffff",
                    },
                ),
            ],
            style=mds["table_container_style"],
        ),
    )


# ─────────────────────────────────────────────────────────────────────────────
# Callbacks
# ─────────────────────────────────────────────────────────────────────────────

def register_callbacks(app):

    @app.callback(
        Output("tl-er-badge", "children"),
        Output("tl-er-info",  "children"),
        Output("tl-er-info",  "style"),
        Input("tl-er-profile", "value"),
    )
    def _update_info(selected_table):
        hidden  = {"display": "none"}
        visible = {
            "display": "block", "padding": "8px 14px",
            "background": "#f0f4ff", "border": "1px solid #c7d7f0",
            "borderRadius": "8px", "fontSize": "12px",
            "color": "#334155", "marginBottom": "10px",
        }
        if not selected_table:
            return "", "", hidden

        if is_profile_table(selected_table):
            badge = "Profile Table"
            info  = (
                f"📋 Profile table detected — using pre-built lineage table: "
                f"ikg_lineage_{selected_table.lower().strip()}.  "
                f"Shows upstream sources → {selected_table}."
            )
        else:
            badge = "General Table"
            info  = (
                f"🔍 General table — querying ikg_table_lineage_metadata_auto_refresh.  "
                f"Section 1: upstream sources → {selected_table}.  "
                f"Section 2: {selected_table} → downstream consumers."
            )
        return badge, info, visible

    @app.callback(
        Output("tl-er-iframe", "src"),
        Input("tl-er-profile", "value"),
    )
    def _update_iframe(selected_table):
        if not selected_table:
            return ""
        encoded = urllib.parse.quote(str(selected_table), safe="")
        return app.get_relative_path(f"/table-lineage-er-view?table={encoded}")


# ─────────────────────────────────────────────────────────────────────────────
# Server route
# ─────────────────────────────────────────────────────────────────────────────

def register_server_routes(server, routes_prefix="/"):
    def _handler():
        table = request.args.get("table", "").strip()
        if not table:
            return ("<html><body style='font-family:Arial;padding:20px'>"
                    "Select a table to view lineage.</body></html>")
        try:
            return _render(table)
        except Exception as exc:
            safe = str(exc).replace("<", "&lt;").replace(">", "&gt;")
            return (f"<html><body style='font-family:Arial;padding:20px'>"
                    f"<b>Error:</b> {safe}</body></html>")

    if not routes_prefix.startswith("/"): routes_prefix = "/" + routes_prefix
    if not routes_prefix.endswith("/"):   routes_prefix = routes_prefix + "/"
    base = "/table-lineage-er-view"
    pref = f"{routes_prefix.rstrip('/')}{base}"
    existing = {r.rule for r in server.url_map.iter_rules()}
    if base not in existing:
        server.add_url_rule(base, endpoint="table_lineage_er_view", view_func=_handler)
    if pref not in existing and pref != base:
        server.add_url_rule(pref, endpoint="table_lineage_er_view_prefixed", view_func=_handler)
