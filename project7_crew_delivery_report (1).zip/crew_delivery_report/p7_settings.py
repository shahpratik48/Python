"""
Configuration for the crew-level delivery report.

Reports at CREW level: every project under the crew's issue group and MR
group is discovered by scanning those group trees recursively, so new
sub-groups and repositories are picked up automatically without anyone
maintaining a list.

Secrets are never hard-coded:
  - GitLab token     env -> Airflow Variable -> prompt (notebook only)
  - Greenplum passwd env -> Airflow Variable -> prompt (notebook only)
"""
from __future__ import annotations

import getpass
import logging
import os
import sys
from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional

_LOG_FMT = "%(asctime)s | %(levelname)-7s | %(name)-20s | %(message)s"
_configured = False


def setup_logging(level: str = "INFO", log_dir: Optional[str] = None,
                  log_to_file: bool = True) -> str:
    global _configured
    root = logging.getLogger()
    if _configured:
        return getattr(root, "_p7_log", "")
    root.setLevel(getattr(logging, str(level).upper(), logging.INFO))
    for h in list(root.handlers):
        root.removeHandler(h)
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(logging.Formatter(_LOG_FMT))
    root.addHandler(sh)
    path = ""
    if log_to_file:
        log_dir = log_dir or os.path.dirname(os.path.abspath(__file__))
        os.makedirs(log_dir, exist_ok=True)
        path = os.path.join(log_dir, "crew_report_%s.log"
                            % datetime.now().strftime("%Y%m%d_%H%M%S"))
        fh = logging.FileHandler(path, encoding="utf-8")
        fh.setFormatter(logging.Formatter(_LOG_FMT))
        root.addHandler(fh)
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    root._p7_log = path
    _configured = True
    return path


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)


def _env(k, d=None):
    return os.getenv(k, d)


@dataclass
class CrewSettings:
    crew_name: str = field(default_factory=lambda: _env("P7_CREW_NAME", "STAAT Data Science"))

    gitlab_url: str = field(default_factory=lambda: _env("GITLAB_URL", "https://devcloud.ubs.net"))
    gitlab_token: Optional[str] = field(default_factory=lambda: _env("GITLAB_TOKEN", ""))
    gitlab_token_var: str = field(default_factory=lambda: _env(
        "GITLAB_TOKEN_VAR", "GENESIS_DDLC_IKG_GIT_SECRET"))

    # Scanned recursively -- every project beneath these groups is included.
    issue_group: str = field(default_factory=lambda: _env(
        "P7_ISSUE_GROUP",
        "ubs/gwma/smart-technology-and-analytics/staat-data-science"))
    mr_group: str = field(default_factory=lambda: _env(
        "P7_MR_GROUP",
        "ubs/gwma/smart-technology-and-analytics/staat-data-science/staat-ds-genesis/"
        "genesis-platform"))

    start_month: str = field(default_factory=lambda: _env("P7_START_MONTH", "2024-11"))
    end_month: str = field(default_factory=lambda: _env("P7_END_MONTH", "2026-07"))
    baseline_month: str = field(default_factory=lambda: _env("P7_BASELINE_MONTH", "2025-11"))

    issue_sla_days: float = field(default_factory=lambda: float(_env("P7_ISSUE_SLA_DAYS", "5")))
    mr_sla_hours: float = field(default_factory=lambda: float(_env("P7_MR_SLA_HOURS", "72")))
    target_gain_pct: float = field(default_factory=lambda: float(_env("P7_TARGET_GAIN_PCT", "20")))
    target_months: int = field(default_factory=lambda: int(_env("P7_TARGET_MONTHS", "14")))

    in_progress_labels: List[str] = field(default_factory=lambda: [
        s.strip() for s in _env("P7_IN_PROGRESS_LABELS",
                                "in progress,in-progress,doing,wip").split(",") if s.strip()])

    # ---------------- Greenplum ----------------
    gp_host: str = field(default_factory=lambda: _env("GREENPLUM_HOST",
                                                      "greenplum-rdsp.zur.swissbank.com"))
    gp_port: int = field(default_factory=lambda: int(_env("GREENPLUM_PORT", "5432")))
    gp_db: str = field(default_factory=lambda: _env("GREENPLUM_DB", "gprdsp"))
    gp_user: str = field(default_factory=lambda: _env("GREENPLUM_USER", "ds_rdsp_dev"))
    gp_password: Optional[str] = field(default_factory=lambda: _env("GREENPLUM_PASSWORD", ""))
    gp_password_var: str = field(default_factory=lambda: _env("GP_PASSWORD_VAR",
                                                              "GREENPLUM_PASSWORD"))
    gp_schema: str = field(default_factory=lambda: _env("P7_GP_SCHEMA",
                                                        "sandbox_prj_smart_insights"))
    load_to_greenplum: bool = field(
        default_factory=lambda: _env("P7_LOAD_GP", "true").lower() == "true")

    output_dir: str = field(default_factory=lambda: _env(
        "P7_OUTPUT_DIR", os.path.dirname(os.path.abspath(__file__))))
    log_level: str = field(default_factory=lambda: _env("P7_LOG_LEVEL", "INFO"))

    # ---------------- table names (all lower_snake_case) ----------------
    tbl_issue_detail: str = "crew_issue_detail"
    tbl_mr_detail: str = "crew_mr_detail"
    tbl_issue_summary: str = "crew_issue_monthly_summary"
    tbl_mr_summary: str = "crew_mr_monthly_summary"

    def _airflow_var(self, key):
        try:
            from airflow.models import Variable  # type: ignore
            return Variable.get(key, default_var=None)
        except Exception:
            return None

    def resolve_secrets(self, interactive: bool = True) -> "CrewSettings":
        log = get_logger("p7.settings")
        if not self.gitlab_token:
            self.gitlab_token = self._airflow_var(self.gitlab_token_var)
        if not self.gitlab_token and interactive:
            self.gitlab_token = getpass.getpass("GitLab personal access token: ").strip() or None
        if not self.gitlab_token:
            raise RuntimeError("No GitLab token. Set GITLAB_TOKEN or the Airflow Variable '%s'."
                               % self.gitlab_token_var)
        log.info("GitLab token resolved.")

        if self.load_to_greenplum:
            if not self.gp_password:
                self.gp_password = self._airflow_var(self.gp_password_var)
            if not self.gp_password and interactive:
                self.gp_password = getpass.getpass(
                    "Greenplum password for %s@%s: " % (self.gp_user, self.gp_host)).strip() or None
            if not self.gp_password:
                raise RuntimeError(
                    "No Greenplum password. Set GREENPLUM_PASSWORD or the Airflow Variable '%s', "
                    "or set load_to_greenplum=False to skip the database load."
                    % self.gp_password_var)
            log.info("Greenplum password resolved for %s@%s/%s.",
                     self.gp_user, self.gp_host, self.gp_db)
        return self
