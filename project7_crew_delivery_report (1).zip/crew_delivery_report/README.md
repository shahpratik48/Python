# Crew Delivery Report — STAAT Data Science

Crew-level delivery metrics as **XLSX and HTML**, each with the dashboard chart embedded, plus a
**Greenplum** load. Runs from a notebook locally, or on a schedule via Airflow.

| | |
|---|---|
| **Window** | Nov 2024 → Jul 2026 |
| **Baseline** | Nov 2025 |
| **Issue scope** | every project beneath `…/staat-data-science` |
| **MR scope** | every project beneath `…/staat-ds-genesis/genesis-platform` |

## Projects are discovered, not configured

Both groups are scanned **recursively** (`include_subgroups`), so every project in every sub-group is
found automatically. A new repository appears in the next run with no config change. Archived
projects are excluded — they are not active work, and including them would inflate history with
repositories the crew no longer runs.

## The four parameters

| Parameter | Definition | Direction |
|---|---|---|
| **Issue Throughput** | issues closed in the month | higher is better |
| **Cycle Time (Days)** | average elapsed days per closed issue | **lower** is better |
| **Merged MR per Author** | merged MRs ÷ distinct authors | higher is better |
| **Lead Time (Hrs)** | average elapsed hours, first file check-in → merged | **lower** is better |

### Cycle Time start point

In priority order — this is the crew's definition and it is **not** issue creation:

1. the first time the issue moved to **in progress** (from label history)
2. otherwise, the day an **iteration was assigned** (from iteration history) — the crew treats that
   as the issue being opened for delivery, since a backlog item with no iteration has not been
   committed to
3. otherwise, the **creation date**, recorded as a last resort so the issue still appears

Which of the three was used is carried on every issue row (`measured_from`) and counted per month. An
iteration-based figure reads differently from an in-progress one, and a reader should be able to see
which they are looking at.

### Merge requests

Only **merged** MRs are considered. Opened, closed-without-merging and locked ones never enter the
data at all — the lead-time measure is about delivered code, and an abandoned branch delivered
nothing.

## Percentages

```
shift = (value − baseline) / |baseline| × 100
```

sign-flipped for Cycle Time and Lead Time, so **positive always means better**. **Overall** is the
plain mean of the four. The shift block runs from the baseline month to the current month.

## The chart

One wide **Overall Productivity Gain** panel, then the four parameters in a 2×2 grid. Three series
each:

| Series | Meaning | Style |
|---|---|---|
| **Actual (Previous)** | before the baseline | dotted, grey |
| **Actual (Current)** | baseline onward | solid, blue |
| **Aspiration** | target ramp | dashed, red |

The aspiration **starts exactly on the actual at the baseline** and ramps to the target from there.
Nothing is drawn before the baseline. Every point is labelled — actual above, aspiration below — so
values can be read straight off.

The **same PNG** is embedded in both deliverables: as a drawing on the workbook's *Dashboard* sheet,
and base64-inlined in the HTML so the page stays a single self-contained file that survives being
emailed.

## Outputs

| File | Contents |
|---|---|
| `<Crew>_crew_report_<ts>.xlsx` | **Summary** (monthly table with the baseline row highlighted, plus the shift block), **Dashboard** (chart), **Issue List**, **MR List** |
| `<Crew>_crew_report_<ts>.html` | the same content in one page, with sortable and filterable tables |
| `crew_dashboard.png` | the chart on its own |

Both detail tables list **every** closed issue and merged MR in the window, newest first, **flagged
or not**, with the iteration, epic, folder trail and a direct link.

## Files

| File | Purpose |
|---|---|
| `p7_settings.py` | Configuration, secrets, logging. |
| `p7_gitlab.py` | Recursive project discovery, issue/MR retrieval, folder trail. |
| `p7_metrics.py` | The four parameters, baseline, aspiration, shift. |
| `p7_charts.py` | The dashboard figure. |
| `p7_output.py` | XLSX and HTML generation. |
| `p7_greenplum.py` | Table creation and the incremental load. |
| `p7_main.py` | `run_crew_report()` — the single entry point. |
| `airflow_dag_p7_crew_report.py` | Airflow DAG (19:00 EST, Mon–Fri). |
| `run_crew_report.ipynb` | Notebook. |

---

# Greenplum

**Schema:** `sandbox_prj_smart_insights` (`P7_GP_SCHEMA` to change)

## Tables

### `crew_issue_detail` — one row per closed issue

`month_key`, `issue_iid`, `project_path`, `folders`, `title`, `author_name`, `assignee_name`,
`measured_from`, `start_at`, `closed_at`, `cycle_time_days`, `is_flagged`, `iteration_name`,
`iteration_start_date`, `iteration_end_date`, `epic_id`, `epic_name`, `web_url`, `load_timestamp`

### `crew_mr_detail` — one row per merged MR

`month_key`, `mr_iid`, `project_path`, `folders`, `title`, `author_name`, `first_commit_at`,
`merged_at`, `lead_time_hours`, `is_flagged`, `web_url`, `load_timestamp`

### `crew_issue_monthly_summary`

`month_key`, `is_baseline_month`, `issue_throughput`, `cycle_time_days`, `issues_flagged`,
`measured_from_in_progress`, `measured_from_iteration`, `measured_from_created`,
`throughput_shift_pct`, `cycle_time_shift_pct`, `load_timestamp`

### `crew_mr_monthly_summary`

`month_key`, `is_baseline_month`, `merged_mr_count`, `author_count`, `merged_mr_per_author`,
`lead_time_hours`, `mrs_flagged`, `mr_per_author_shift_pct`, `lead_time_shift_pct`,
`load_timestamp`

## Load strategy — the database is the system of record for history

History does not change; the current month does. So the run is incremental at the **fetch** level,
not just the write level:

| Run | GitLab scan | Database |
|---|---|---|
| **First** | all months in the window | tables created, every month written |
| **Every run after** | **the current month only** | current month deleted and rewritten; settled months **read back** |

Settled months are never re-scanned. Walking every project under the crew for twenty-one months is
by far the most expensive part of the job, and once a month has closed its numbers cannot change —
so the report rebuilds the full Nov-24 → Jul-26 window by **reading settled months back out of these
tables** and fetching only what is still moving.

The `updated_after` sent to GitLab moves with it: `2024-11-01` on the first run, `2026-07-01` on
every run afterwards.

`crew_issue_monthly_summary` is the authority on what has been loaded — **not** the detail tables. A
month in which the crew closed nothing still gets a summary row, whereas it would leave no detail
rows and would otherwise be re-fetched forever.

The decision comes from the table itself, not a marker file or a run log, so it stays correct if a
run is interrupted or the tables are truncated by hand. If Greenplum is unreachable, or the tables do
not exist yet, the run falls back to fetching the full history rather than failing.

Inserts use `COPY` — one round trip rather than one per row — inside a transaction that rolls back on
failure, so a failed load never leaves partial data.

### Forcing a full refresh

After changing a metric definition, stored history is no longer comparable with newly collected
months. Re-fetch and rewrite everything with:

```python
run_crew_report(settings, force_full_refresh=True)
```

**Verified:** run 1 fetched 21 months from GitLab and wrote all of them. Run 2 asked GitLab only for
`2026-07`, read the other 20 back from the database, produced the **identical** full-window report
(same issue and MR totals), and rewrote only the current month.

---

# Configuration

Everything is an environment variable or an Airflow Variable.

| Setting | Default |
|---|---|
| `P7_CREW_NAME` | STAAT Data Science |
| `P7_ISSUE_GROUP` | `ubs/…/staat-data-science` |
| `P7_MR_GROUP` | `ubs/…/staat-ds-genesis/genesis-platform` |
| `P7_START_MONTH` / `P7_END_MONTH` | 2024-11 / 2026-07 |
| `P7_BASELINE_MONTH` | 2025-11 |
| `P7_ISSUE_SLA_DAYS` / `P7_MR_SLA_HOURS` | 5 / 72 |
| `P7_TARGET_GAIN_PCT` / `P7_TARGET_MONTHS` | 20 / 14 |
| `P7_IN_PROGRESS_LABELS` | `in progress,in-progress,doing,wip` |
| `P7_GP_SCHEMA` | sandbox_prj_smart_insights |
| `P7_LOAD_GP` | true |

**Secrets** — never hard-coded, resolved as env → Airflow Variable → prompt (notebook only):

| | Airflow Variable |
|---|---|
| GitLab token | `GENESIS_DDLC_IKG_GIT_SECRET` |
| Greenplum password | `GREENPLUM_PASSWORD` |

## Running it

**Notebook** — open `run_crew_report.ipynb`, run the cells; it prompts for both credentials.

**Airflow** — deploy the DAG beside the `p7_*.py` files. Three tasks:
`collect_and_report → load_greenplum → summarise`. Reporting is separated from the database load so a
Greenplum outage still leaves the XLSX and HTML on disk rather than losing the run.

To skip the database entirely: `settings.load_to_greenplum = False`, or `P7_LOAD_GP=false`.

## Adjusting the in-progress labels

`Cycle Time` depends on recognising the in-progress transition. The defaults match
`in progress`, `in-progress`, `doing`, `wip` — case-insensitive, and scoped forms like
`workflow::In progress` work too. If the crew's board uses different names, set
`P7_IN_PROGRESS_LABELS`. The `measured_from_in_progress` / `measured_from_iteration` counts in the
monthly summary tell you how well the match is working: if almost everything is falling through to
`iteration`, the labels are probably wrong.

## Validation performed

Tested end-to-end with a mocked GitLab across 21 months and multiple projects:

- **Recursive discovery** — projects from several sub-group depths were scanned, and the folder trail
  rendered as `staat-ds-genesis | genesis-platform | nlg-dags` relative to the crew group.
- **Cycle-time priority** — in-progress used where present; iteration-assigned where not; creation as
  the last resort, with the basis recorded per row.
- **Baseline anchoring** — aspiration equals actual at the baseline for all four parameters, is blank
  before it, and the shift at the baseline is exactly 0%.
- **Overall gain** — equals the plain mean of the four parameter shifts.
- **Outputs** — workbook with 4 sheets and the chart embedded on *Dashboard*; baseline row
  highlighted; HTML with the chart base64-inlined, 4 sortable/filterable tables and working links.
- **Greenplum incremental load** — first run 21 months, second run only the current month.
