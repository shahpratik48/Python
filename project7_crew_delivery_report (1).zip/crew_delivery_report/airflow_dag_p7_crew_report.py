"""
airflow_dag_p7_crew_report.py
------------------------------
Crew-level delivery report: XLSX + HTML (each with the dashboard embedded),
plus a Greenplum load.

Three tasks, run in order:

    collect_and_report  ->  load_greenplum  ->  summarise

Collection and reporting are separated from the database load so that a
Greenplum outage still leaves you the XLSX and HTML on disk, rather than
losing the whole run.

Secrets come from Airflow Variables:
    GENESIS_DDLC_IKG_GIT_SECRET   GitLab token
    GREENPLUM_PASSWORD            Greenplum password

Deploy alongside the p7_*.py modules in the SAME folder.
"""
from __future__ import annotations

import os
import sys
from datetime import datetime, timedelta

import pendulum
from airflow import DAG
from airflow.models import Variable
from airflow.operators.python import PythonOperator

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from p7_main import run_crew_report
from p7_settings import CrewSettings, get_logger, setup_logging

HERE = os.path.dirname(os.path.abspath(__file__))
EST = pendulum.timezone("America/New_York")


def _var(k, d=None):
    try:
        return Variable.get(k, default_var=d)
    except Exception:
        return d


def _settings(load_gp=True) -> CrewSettings:
    s = CrewSettings()
    s.output_dir = HERE
    s.crew_name = _var("P7_CREW_NAME", s.crew_name)
    s.start_month = _var("P7_START_MONTH", s.start_month)
    s.end_month = _var("P7_END_MONTH", s.end_month)
    s.baseline_month = _var("P7_BASELINE_MONTH", s.baseline_month)
    s.gp_schema = _var("P7_GP_SCHEMA", s.gp_schema)
    s.load_to_greenplum = load_gp
    s.resolve_secrets(interactive=False)
    return s


def task_collect_and_report(**kwargs):
    log_path = setup_logging("INFO", log_dir=HERE)
    log = get_logger("p7.dag.report")
    # reports first, database second -- so an outage downstream cannot cost
    # us the deliverables
    s = _settings(load_gp=False)
    res = run_crew_report(s, progress=print)

    ti = kwargs["ti"]
    ti.xcom_push(key="xlsx_path", value=res.xlsx_path)
    ti.xcom_push(key="html_path", value=res.html_path)
    ti.xcom_push(key="current_month", value=res.current_month)
    ti.xcom_push(key="issue_count", value=len(res.issues))
    ti.xcom_push(key="mr_count", value=len(res.mrs))
    ti.xcom_push(key="overall_gain", value=res.series.overall_gain)
    ti.xcom_push(key="log_path", value=log_path)
    log.info("Reports written: %s | %s", res.xlsx_path, res.html_path)


def task_load_greenplum(**kwargs):
    setup_logging("INFO", log_dir=HERE)
    log = get_logger("p7.dag.greenplum")
    s = _settings(load_gp=True)
    # recollected rather than passed through XCom: the detail rows run to
    # thousands and XCom is not the right place for that volume
    res = run_crew_report(s, progress=print)
    ti = kwargs["ti"]
    ti.xcom_push(key="greenplum", value=res.greenplum)
    log.info("Greenplum: %s", res.greenplum)


def task_summarise(**kwargs):
    ti = kwargs["ti"]
    gp = ti.xcom_pull(task_ids="load_greenplum", key="greenplum") or {}
    print("=" * 68)
    print("Crew report complete")
    print("  XLSX          :", ti.xcom_pull(task_ids="collect_and_report", key="xlsx_path"))
    print("  HTML          :", ti.xcom_pull(task_ids="collect_and_report", key="html_path"))
    print("  issues        :", ti.xcom_pull(task_ids="collect_and_report", key="issue_count"))
    print("  merged MRs    :", ti.xcom_pull(task_ids="collect_and_report", key="mr_count"))
    print("  overall gain  :", ti.xcom_pull(task_ids="collect_and_report", key="overall_gain"), "%")
    if gp:
        print("  schema        :", gp.get("schema"))
        print("  months loaded :", len(gp.get("months_loaded") or []))
        print("  months skipped:", len(gp.get("months_skipped") or []), "(already settled)")
        for t, n in (gp.get("tables") or {}).items():
            print("     %-32s %d row(s)" % (t, n))
    print("=" * 68)


default_args = {
    "owner": "STAAT-DS",
    "retries": 1,
    "retry_delay": timedelta(minutes=10),
    "email_on_failure": True,
}

with DAG(
    dag_id="crew_delivery_report",
    default_args=default_args,
    description="Crew-level issue and merge request metrics: XLSX + HTML with embedded "
                "dashboard, and a Greenplum load.",
    start_date=datetime(2026, 1, 1, tzinfo=EST),
    schedule_interval="0 19 * * 1-5",     # 19:00 EST, Monday-Friday
    catchup=False,
    max_active_runs=1,
    tags=["gitlab", "crew", "metrics", "greenplum"],
) as dag:

    t1 = PythonOperator(task_id="collect_and_report", python_callable=task_collect_and_report)
    t2 = PythonOperator(task_id="load_greenplum", python_callable=task_load_greenplum)
    t3 = PythonOperator(task_id="summarise", python_callable=task_summarise,
                        trigger_rule="all_done")

    t1 >> t2 >> t3
