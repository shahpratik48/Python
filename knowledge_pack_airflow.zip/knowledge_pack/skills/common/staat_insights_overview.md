# STAAT Insights - how the platform works

_source: STAAT Insights slides (overview, architecture, data flow, household mapping, Aladdin risk outlier use case)_

## What STAAT Insights does
STAAT Insights provides **timely insights** on clients to FAs (financial advisors), sales consultants and branch managers so
they can hold in-depth conversations, increasing client satisfaction. It gives a **360° view** of clients by combining UBS
data with public external data from vendors, and highlights significant revenue opportunities to FAs.

End users: FAs, TAs, FLs (field leaders), bankers, banking / business-owner teams.

## Architecture (layers, bottom to top)

| layer | component | what it is | technology |
|---|---|---|---|
| Data ingestion | internal data | EDW, SDP, FGA (and ADW, mainframe) | Greenplum |
| Data ingestion | external data | Demyst, Black Knight, Speedeon, Jornaya, BrightScope, WealthX, ZoomInfo ... | Greenplum |
| Insights generation | **IKG** - Insight Knowledge Graph, the insights **feature store** | complex data pipelines that build features aggregated at account (`acc_i`), client (`ip_cli_i`) and household (`acc_mhh_n` / household_plus) level - the `*_profile_curr_ikg` tables | Python, R, SQL on Greenplum, Airflow |
| Insights generation | **ODM** - Insights **business rules engine** | rules on top of the feature store; each rule (`si_*`) writes one insight row per target that meets its conditions | SQL rules (origin: IBM ODM, Java) |
| Insights generation | **NLG** - Natural Language Generation (narrative generation) | turns triggered rules + IKG features into English: rule narratives, then insight products (client briefings and summaries, FA alerts, market events, banker alerts, FL talent reports) | Python, yml templates |
| Distribution | channels | STAAT Email, Adobe Campaign, Tableau, Insights API (Java) | |
| Distribution | delivery / UI | e-mails to FAs, FLs, TAs, bankers; dashboards for banking, BO; STAAT Portal, STAAT Panels, ACE | |
| Platform | | Genesis, Airflow, Superset, MLflow, Jupyter, VS Code | |

## Data flow
1. **Ingestion** - data lands from internal (ADW / EDW, mainframe) and external sources (Speedeon, WealthX, Jornaya, ZoomInfo ...).
2. **Feature generation (IKG)** - pipelines build the feature store; the final features are aggregated at household, client
   and account level (profile tables `account_profile_curr_ikg`, `client_profile_curr_ikg`, `household_profile_curr_ikg`, ...).
3. **ODM (business rules)** - a set of rules runs on top of the feature store and outputs every rule that triggered:
   `insight_type` (rule id `si_*`), `target_type` (account / household / client / prospect / FA ...), `target_key`, metric, attributes.
4. **NLG** - textual insights with proper language are generated from the ODM output and the IKG features; insight products
   are assembled from the individual business-rule narratives.
5. **Distribution** - products go out through e-mails, the portal, panels and Tableau dashboards to FAs, TAs, FLs and bankers.

The rule id `si_*` is the thread through the systems: ODM file `.../<domain>/si_x.sql` -> NLG narrative `src/rules/<target>/.../si_x.yml`
(+ optional `src/ref_table_columns/<target>/si_x.yml` for extra NLG columns, and `src/insight_group_layout/*.yml` for product,
category, label and suppression).

## How accounts map to clients and households
Every account carries one client id and three source household ids; IKG adds a fourth, unified id.

| object | source column -> IKG name | meaning |
|---|---|---|
| Account | `acc_i` / `acc_n` | the account |
| Client | `ip_cli_i` -> client_id | the individual who owns the account; a client can hold many accounts |
| Relationship (ACE / ConsultWorks) | `cw_rel_i` -> relationship_id | legal / regulatory grouping; drives tax reporting and compliance (e.g. a joint account) |
| Statement household | `acc_hh_n` -> statement_id | accounts that appear on the same statement; the original account-dimension grouping |
| Marketing household | `acc_mhh_n` (EDW) -> marketing_hh_id | CRM grouping that links related statement households, e.g. spouses, trusts, family |
| **Statement Household Plus** | household_plus | IKG's unified household id: one id per client, stamped on all of that client's accounts |

Each account maps many-to-one into all four. In the IKG profile tables the household key used by rules is `acc_mhh_n`
carrying the household_plus value, and `mhh_*` attributes are aggregated at that household level (see the IKG skill
document; the marketing household is kept separately as `acc_market_hh_n`).

Which id to use: compliance / legal ownership -> relationship id (`cw_rel_i`); statement servicing -> statement id (`acc_hh_n`);
marketing segmentation / prospecting -> marketing household; advisor analytics and aggregate insights -> household_plus;
all constructs in one row -> statement_plus.

### How the Statement Household Plus id is created
**Stage 1 - pick a candidate id (per marketing household).** Inputs per account: ACE relationship id `cw_rel_i`, statement
household id `acc_hh_n`, marketing household id `acc_mhh_n`, client id + assets `ip_cli_i`. Inspect the marketing household:
how many distinct ACE relationship ids does it contain?
- more than one -> use the ACE relationship id (if `cw_rel_i = 0`: fallback `acc_hh_n || ip_cli_i`);
- only one -> use the statement household id (statement_id, `acc_hh_n`).
The result is a candidate SHH+ id on every account; a client may still carry several.

**Stage 2 - resolve to one id per client (highest assets wins).**
1. multiple statement household ids? keep the one with the highest total assets;
2. multiple ACE relationships? keep the relationship with the highest assets;
3. multiple marketing households? keep the marketing household with the highest assets.
Final `household_plus`: one id per client, stamped on all of that client's accounts.
Tie-breaks: highest assets -> most accounts -> largest id. The source ids (relationship, statement, marketing) remain on
every row for traceability. (Source: Understanding Household IDs, STAAT Confluence + SHH+ assignment logic.)

## Worked example - Aladdin risk outliers (from story to narrative)
**Business context.** Aladdin data indicates when PMP accounts fall outside their risk band range. The insight alerts the FA
about accounts that have been failing for the last few quarters and could be removed from PMP (account closed).

**Features generated (IKG):** risk status 3 quarters back, 2 quarters back, 1 quarter back, risk status of the current
quarter, current risk score, higher (upper) band risk score, lower band risk score.

**Ingestion table** (EDW `aladdin_account_analytics_daily`): analysis_date, account_number, strategy_start_date, market_value,
risk_outlier_status (PASSED / FAILED), account_risk, benchmark_risk, tracking_error.

**IKG** `scripts/sql/ikg_aladdin_insights/aladdin_accounts_risk_alert_ikg.sql` takes the most recent analysis date and the last
quarter-end statuses per account; risk values are scaled x100; the band is
upper = max(benchmark x 1.25, benchmark + 0.03), lower = min(benchmark x 0.5, benchmark - 0.03) floored at 0.
`account_profile_curr_ikg` exposes them as `aldn_acc_risk`, `aldn_upper_bound_bmrk_risk`, `aldn_lower_bound_bmrk_risk`,
`aldn_status_curr`, `aldn_status_prev_qtr`, `aldn_status_prev_qtr2`, `aldn_status_end_d_prev_qtr`, `aldn_qtr_end_d_next`
(IKG output columns: acc_i, profile_date, num_accounts, aldn_status_end_d_prev_qtr, aldn_acc_risk, aldn_lower_bound_bmrk_risk,
aldn_upper_bound_bmrk_risk, aldn_qtr_end_d_next).

**ODM** `ds_client_insights/account_rules/account_aladdin/si_aladdin_fail_high_1q.sql` (also `_2q`, `_3q`): target account,
household assets >= 10,000, account active, current risk >= upper band, failed this quarter and the previous quarter, and the
quarter before that empty or passed (2q / 3q extend the run of failed quarters).

**NLG** `src/rules/account/aladdin/si_aladdin_fail_high_1q.yml` - title "Aladdin risk alert (over)":
"As of <aldn_status_end_d_prev_qtr>, <client first name>'s PMP portfolio (<account link>) was flagged as an over-risk outlier
in Aladdin. The current risk of the portfolio is <aldn_acc_risk>, <above/below> their <aldn_benchmark_risk> limit. If the
outlier is not addressed, the account may be subject to removal from PMP. To address this, click here (Aladdin)."
The slide's sample adds the deadline: "If this is not addressed by <next quarter end + 1> the account may be subject to
removal from PMP" (`aldn_qtr_end_d_next`). The under-risk variant reads "... flagged as an under-risk outlier ... below
their <limit> limit." Sample from the slide: risk 18.19 above a 17.92 limit (over); 6.54 below a 7.17 limit (under).

## How to use a pack for a story written in plain English
1. Search the business rules: `Pack.insights("<story words>")` (or items of kind `business_rule`) - titles, narratives and
   conditions are all in English.
2. Open the trace: `Pack.trace("si_x")` / `cards/rule/si_x.md` - ODM file and every condition (SQL + English), the profile
   table, each feature with the IKG script that computes it (column lineage), the NLG yml and its placeholders, the layout.
3. Change in this order: IKG feature (new column in the sub-table script, then the profile table) -> ODM rule (copy the
   closest sibling in the same domain folder) -> NLG yml (copy the sibling's narrative, add placeholders) -> layout / products.
4. Check impact: `Pack.feature(col)["used_by"]` lists every insight using a feature; `Pack.impact(table)` the scripts reading a table.
