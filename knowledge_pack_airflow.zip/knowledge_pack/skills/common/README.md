# Common skills folder

Bank-wide / platform-wide standards shared by IKG, ODM and NLG (SQL conventions, Airflow conventions, review checklist,
security rules). Everything here is included in every system's pack.
