# IKG skills folder

Put the IKG knowledge documents here (any of: .md, .txt, .docx, .xlsx, .html, .yaml):

- **skills** - how the system works, how to add a script / table / DAG task, runbooks
- **standards / conventions** - naming, structure, parameterisation, review rules (file name containing *standard*, *convention*, *rule* or *guideline*)
- **glossary / data dictionary** - business terms, columns, abbreviations (file name containing *gloss* or *dictionary*)

Every file here (and in `skills/common`) goes into the IKG pack: as searchable sections, and - with the model layer on - as
definitions, conventions and checkable rules. README.md files are ignored.
