"""Greenplum / PostgreSQL input: connection details entered in the UI (held in memory), tables introspected into a
standard JSON shape (columns, types, comments, keys, distribution, sample rows), optional read-only query."""
from __future__ import annotations

import logging
import re
from typing import List, Optional

log = logging.getLogger(__name__)

READ_ONLY = re.compile(r"(?is)^\s*(with\b.*?\bselect\b|select\b|explain\b|show\b)")
FORBIDDEN = re.compile(r"(?i)\b(insert|update|delete|drop|alter|create|truncate|grant|revoke|copy|vacuum|analyze)\b")


class GreenplumInput:
    def __init__(self, host: str, port: int, database: str, user: str, password: str, sslmode: str = "prefer",
                 statement_timeout_seconds: int = 60, sqlite_path: Optional[str] = None):
        self.conn_info = {"host": host, "port": int(port or 5432), "database": database, "user": user, "sslmode": sslmode}
        self._password = password
        self.timeout = int(statement_timeout_seconds)
        self.sqlite_path = sqlite_path            # self-test: a sqlite file plays the database
        self._conn = None

    # ------------------------------------------------------------------ connection
    def connect(self):
        if self._conn is not None:
            return self._conn
        if self.sqlite_path:
            import sqlite3
            self._conn = sqlite3.connect(self.sqlite_path, check_same_thread=False)
            return self._conn
        import psycopg2
        self._conn = psycopg2.connect(host=self.conn_info["host"], port=self.conn_info["port"], dbname=self.conn_info["database"],
                                      user=self.conn_info["user"], password=self._password, sslmode=self.conn_info["sslmode"],
                                      connect_timeout=20, options=f"-c statement_timeout={self.timeout * 1000}")
        self._conn.set_session(readonly=True, autocommit=True)
        return self._conn

    def close(self):
        try:
            if self._conn is not None:
                self._conn.close()
        finally:
            self._conn = None

    def test(self) -> str:
        rows = self.query("select version()" if not self.sqlite_path else "select sqlite_version()")
        return str(rows["rows"][0][0])[:80] if rows["rows"] else "connected"

    def query(self, sql: str, limit: int = 200) -> dict:
        """Read-only SELECT with a row cap."""
        if not READ_ONLY.match(sql) or FORBIDDEN.search(sql):
            raise ValueError("only read-only SELECT / WITH / EXPLAIN queries are allowed")
        s = sql.strip().rstrip(";")
        if not re.search(r"(?i)\blimit\s+\d+\s*$", s) and not s.lower().startswith("explain"):
            s = f"select * from ({s}) _q limit {int(limit)}"
        cur = self.connect().cursor()
        cur.execute(s)
        cols = [d[0] for d in cur.description] if cur.description else []
        rows = [[_cell(c) for c in r] for r in cur.fetchall()]
        return {"sql": sql, "columns": cols, "rows": rows, "row_count": len(rows)}

    # ------------------------------------------------------------------ introspection
    def describe_many(self, pairs, sample_rows: int = 5, progress=None, sample_timeout_s: int = 15, strict: bool = False) -> list:
        """All tables in 3 catalog round trips (pg_catalog, not the slow information_schema views), then the sample rows
        in parallel on separate connections with a short statement timeout (a slow sample is skipped, never waited for)."""
        pairs = [(s, t) for s, t in pairs]
        if self.sqlite_path:
            return [self._describe_sqlite(t, sample_rows) for _, t in pairs]
        say = progress or (lambda m: None)
        cur = self.connect().cursor()
        say(f"reading the catalog of {len(pairs)} table(s) ...")
        keys = [f"{s}.{t}" for s, t in pairs]
        cur.execute("""select n.nspname, c.relname, c.relkind, obj_description(c.oid), c.reltuples, c.oid
                       from pg_class c join pg_namespace n on n.oid = c.relnamespace
                       where n.nspname || '.' || c.relname = any(%s)""", (keys,))
        meta = {}
        for ns, rel, kind, comment, tuples, oid in cur.fetchall():
            meta[f"{ns}.{rel}"] = {"kind": {"v": "view", "m": "materialized view"}.get(kind, "table"), "comment": comment or "",
                                   "row_estimate": int(tuples or 0), "oid": oid}
        missing = [k for k in keys if k not in meta]
        if missing and strict:
            raise ValueError("table(s) not found or not visible: " + ", ".join(missing))
        if missing:
            say(f"{len(missing)} of {len(keys)} table(s) not found or not visible - described as missing")
        oids = [m["oid"] for m in meta.values()]
        if not oids:
            return [{"schema": s_, "table": t_, "columns": [], "error": "not found or not visible", "sample": {"columns": [], "rows": []}} for s_, t_ in pairs]
        cur.execute("""select a.attrelid, a.attname, pg_catalog.format_type(a.atttypid, a.atttypmod), a.attnotnull, a.attnum,
                              pg_catalog.col_description(a.attrelid, a.attnum),
                              pg_get_expr(d.adbin, d.adrelid)
                       from pg_attribute a left join pg_attrdef d on d.adrelid = a.attrelid and d.adnum = a.attnum
                       where a.attrelid = any(%s) and a.attnum > 0 and not a.attisdropped order by a.attrelid, a.attnum""", (oids,))
        cols = {}
        for oid, name, typ, notnull, num, comment, default in cur.fetchall():
            cols.setdefault(oid, []).append({"name": name, "type": typ, "nullable": not notnull, "default": default, "position": num,
                                             "comment": comment or ""})
        keycols, dist = {}, {}
        try:
            cur.execute("""select i.indrelid, a.attname from pg_index i join pg_attribute a on a.attrelid = i.indrelid and a.attnum = any(i.indkey)
                           where i.indrelid = any(%s) and (i.indisprimary or i.indisunique)""", (oids,))
            for oid, name in cur.fetchall():
                keycols.setdefault(oid, []).append(name)
        except Exception:  # noqa: BLE001
            self._rollback()
        try:
            cur.execute("""select p.localoid, a.attname from gp_distribution_policy p
                           join pg_attribute a on a.attrelid = p.localoid and a.attnum = any(p.distkey) where p.localoid = any(%s)""", (oids,))
            for oid, name in cur.fetchall():
                dist.setdefault(oid, []).append(name)
        except Exception:  # noqa: BLE001  (PostgreSQL, older Greenplum)
            self._rollback()
        out = []
        for s_, t_ in pairs:
            m = meta.get(f"{s_}.{t_}")
            if m is None:
                out.append({"schema": s_, "table": t_, "columns": [], "error": "not found or not visible", "sample": {"columns": [], "rows": []}})
                continue
            out.append({"schema": s_, "table": t_, "columns": cols.get(m["oid"], []), "comment": m["comment"], "kind": m["kind"],
                        "keys": keycols.get(m["oid"], []), "distribution": dist.get(m["oid"], []), "row_estimate": m["row_estimate"],
                        "sample": {"columns": [], "rows": []}})
        found = [t for t in out if not t.get("error")]
        if sample_rows and found:
            say(f"sampling {sample_rows} row(s) of each table in parallel ...")
            import concurrent.futures as cf

            def one(t):
                g = GreenplumInput(self.conn_info["host"], self.conn_info["port"], self.conn_info["database"], self.conn_info["user"],
                                   self._password, self.conn_info["sslmode"], sample_timeout_s)
                try:
                    q = g.query(f'select * from "{t["schema"]}"."{t["table"]}" limit {int(sample_rows)}', limit=sample_rows)
                    t["sample"] = {"columns": q["columns"], "rows": q["rows"]}
                except Exception as e:  # noqa: BLE001
                    t["sample_error"] = str(e)[:160]
                finally:
                    g.close()
            with cf.ThreadPoolExecutor(min(8, len(found))) as ex:
                list(ex.map(one, found))
        return out

    def _rollback(self):
        try:
            self._conn.rollback()
        except Exception:  # noqa: BLE001
            pass

    def describe(self, schema: str, table: str, sample_rows: int = 5) -> dict:
        if self.sqlite_path:
            return self._describe_sqlite(table, sample_rows)
        return self.describe_many([(schema, table)], sample_rows)[0]

    def _describe_old(self, schema: str, table: str, sample_rows: int = 5) -> dict:
        cur = self.connect().cursor()
        cur.execute("""select c.column_name, c.data_type, c.character_maximum_length, c.numeric_precision, c.numeric_scale,
                              c.is_nullable, c.column_default, c.ordinal_position,
                              pg_catalog.col_description((quote_ident(c.table_schema) || '.' || quote_ident(c.table_name))::regclass::oid,
                                                         c.ordinal_position::int)
                       from information_schema.columns c
                       where c.table_schema = %s and c.table_name = %s order by c.ordinal_position""", (schema, table))
        cols = [{"name": r[0], "type": _type(r[1], r[2], r[3], r[4]), "nullable": r[5] == "YES", "default": r[6],
                 "position": r[7], "comment": r[8] or ""} for r in cur.fetchall()]
        if not cols:
            raise ValueError(f"table {schema}.{table} not found or no columns visible")
        out = {"schema": schema, "table": table, "columns": cols, "comment": "", "kind": "table", "keys": [],
               "distribution": [], "row_estimate": None, "sample": {"columns": [], "rows": []}}
        try:
            cur.execute("""select case c.relkind when 'v' then 'view' when 'm' then 'materialized view' else 'table' end,
                                  obj_description(c.oid), c.reltuples
                           from pg_class c join pg_namespace n on n.oid = c.relnamespace
                           where n.nspname = %s and c.relname = %s""", (schema, table))
            r = cur.fetchone()
            if r:
                out["kind"], out["comment"], out["row_estimate"] = r[0], r[1] or "", int(r[2] or 0)
        except Exception as e:  # noqa: BLE001
            log.debug("pg_class lookup failed: %s", e)
        try:
            cur.execute("""select kcu.column_name from information_schema.table_constraints tc
                           join information_schema.key_column_usage kcu on kcu.constraint_name = tc.constraint_name
                           where tc.table_schema = %s and tc.table_name = %s and tc.constraint_type in ('PRIMARY KEY','UNIQUE')""", (schema, table))
            out["keys"] = [r[0] for r in cur.fetchall()]
        except Exception:  # noqa: BLE001
            pass
        try:
            cur.execute("""select a.attname from gp_distribution_policy p
                           join pg_class c on c.oid = p.localoid join pg_namespace n on n.oid = c.relnamespace
                           join pg_attribute a on a.attrelid = c.oid and a.attnum = any(p.distkey)
                           where n.nspname = %s and c.relname = %s""", (schema, table))
            out["distribution"] = [r[0] for r in cur.fetchall()]
        except Exception:  # noqa: BLE001  (not Greenplum)
            pass
        if sample_rows:
            try:
                q = self.query(f'select * from "{schema}"."{table}" limit {int(sample_rows)}', limit=sample_rows)
                out["sample"] = {"columns": q["columns"], "rows": q["rows"]}
            except Exception as e:  # noqa: BLE001
                out["sample_error"] = str(e)[:200]
        return out

    def _describe_sqlite(self, table: str, sample_rows: int) -> dict:
        cur = self.connect().cursor()
        cur.execute(f"pragma table_info('{table}')")
        cols = [{"name": r[1], "type": r[2] or "text", "nullable": not r[3], "default": r[4], "position": r[0] + 1,
                 "comment": ""} for r in cur.fetchall()]
        if not cols:
            raise ValueError(f"table {table} not found")
        out = {"schema": "main", "table": table, "columns": cols, "comment": "", "kind": "table",
               "keys": [c["name"] for c in cols if c["position"] == 1], "distribution": [], "row_estimate": None}
        q = self.query(f"select * from {table} limit {int(sample_rows)}", limit=sample_rows)
        out["sample"] = {"columns": q["columns"], "rows": q["rows"]}
        return out

    def list_tables(self, schema: str, like: str = "", limit: int = 200) -> List[str]:
        if self.sqlite_path:
            cur = self.connect().cursor()
            cur.execute("select name from sqlite_master where type in ('table','view') order by name")
            return [r[0] for r in cur.fetchall() if not like or like.replace("%", "") in r[0]][:limit]
        cur = self.connect().cursor()
        cur.execute("""select c.relname from pg_class c join pg_namespace n on n.oid = c.relnamespace
                       where n.nspname = %s and c.relkind in ('r', 'v', 'm', 'p') and c.relname like %s and c.relname not like '%%_prt_%%'
                       order by c.relname limit %s""", (schema, like or "%", int(limit)))
        return [r[0] for r in cur.fetchall()]


def _type(dt, ln, prec, scale) -> str:
    if dt in ("character varying", "character", "varchar") and ln:
        return f"{dt}({ln})"
    if dt == "numeric" and prec:
        return f"numeric({prec},{scale or 0})"
    return dt or ""


def _cell(c):
    if c is None or isinstance(c, (int, float, str, bool)):
        return c
    return str(c)


def table_text(t: dict) -> str:
    lines = [f"### {t['schema']}.{t['table']} ({t.get('kind', 'table')}" + (f", ~{t['row_estimate']} rows" if t.get("row_estimate") else "") + ")"]
    if t.get("comment"):
        lines.append(f"comment: {t['comment']}")
    if t.get("keys"):
        lines.append(f"keys: {', '.join(t['keys'])}")
    if t.get("distribution"):
        lines.append(f"distributed by: {', '.join(t['distribution'])}")
    for c in t["columns"]:
        lines.append(f"  - {c['name']} {c['type']}" + ("" if c.get("nullable", True) else " not null") + (f"  -- {c['comment']}" if c.get("comment") else ""))
    s = t.get("sample") or {}
    if s.get("rows"):
        lines.append("sample rows: " + " | ".join(s["columns"]))
        for r in s["rows"]:
            lines.append("  " + " | ".join(str(x)[:60] for x in r))
    return "\n".join(lines)
