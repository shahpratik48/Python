"""Readers: any accepted file -> one standard Document (JSON-serialisable).

    {"name": "glossary.xlsx", "format": "xlsx", "kind": "glossary", "chars": 1234, "sha": "...",
     "text": "...plain text rendering...", "sections": [{"title": "...", "text": "..."}],
     "tables": [{"name": "Sheet1", "columns": [...], "rows": [[...], ...]}], "data": {...parsed yaml/json...}}

`kind` is what the user dragged the file onto (skills, glossary, standards, story); the agents only ever see this
standard shape, never the original binary.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import logging
import re
import subprocess
import tempfile
from pathlib import Path
from typing import List, Optional

import yaml

log = logging.getLogger(__name__)

TEXT_EXT = {"md", "txt", "sql", "py", "r", "sh", "cfg", "ini", "toml", "log"}
MAX_TABLE_ROWS = 2000


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()[:16]


def read_document(name: str, data: bytes, kind: str = "document", max_chars: int = 120000) -> dict:
    ext = (Path(name).suffix.lower().lstrip(".") or "txt")
    doc = {"name": Path(name).name, "format": ext, "kind": kind, "sha": sha(data), "bytes": len(data),
           "text": "", "sections": [], "tables": [], "data": None, "truncated": False}
    try:
        if ext in ("yml", "yaml"):
            txt = _decode(data)
            doc["text"] = txt
            try:
                doc["data"] = yaml.safe_load(txt)
            except Exception as e:  # noqa: BLE001
                doc["parse_error"] = f"yaml: {e}"
        elif ext == "json":
            txt = _decode(data)
            doc["text"] = txt
            try:
                doc["data"] = json.loads(txt)
            except Exception as e:  # noqa: BLE001
                doc["parse_error"] = f"json: {e}"
        elif ext == "csv":
            rows = list(csv.reader(io.StringIO(_decode(data))))
            doc["tables"] = [_table(Path(name).stem, rows)]
            doc["text"] = _table_text(doc["tables"][0])
        elif ext in ("xlsx", "xlsm"):
            doc["tables"] = _read_xlsx(data)
            doc["text"] = "\n\n".join(_table_text(t) for t in doc["tables"])
        elif ext == "xls":
            doc["tables"] = _read_xls(data)
            doc["text"] = "\n\n".join(_table_text(t) for t in doc["tables"])
        elif ext == "docx":
            txt, tables = _read_docx(data)
            doc["text"], doc["tables"] = txt, tables
        elif ext == "doc":
            doc["text"] = _read_doc(data, name)
        elif ext in ("html", "htm"):
            doc["text"] = _html_text(_decode(data))
        elif ext == "ipynb":
            doc["text"] = _ipynb_text(_decode(data))
        else:
            doc["text"] = _decode(data)
    except Exception as e:  # noqa: BLE001
        log.warning("reader failed for %s: %s", name, e)
        doc["parse_error"] = f"{type(e).__name__}: {e}"
        doc["text"] = doc["text"] or _decode(data, lenient=True)
    doc["text"] = (doc["text"] or "").replace("\r\n", "\n").strip()
    if len(doc["text"]) > max_chars:
        doc["text"] = doc["text"][:max_chars] + f"\n...[truncated: {len(doc['text']) - max_chars} more characters]"
        doc["truncated"] = True
    doc["chars"] = len(doc["text"])
    doc["sections"] = split_sections(doc["text"]) if ext in ("md", "txt", "docx", "doc", "html", "htm") else []
    return doc


# ----------------------------------------------------------------------------- helpers
def _decode(data: bytes, lenient: bool = False) -> str:
    for enc in ("utf-8-sig", "utf-8", "cp1252", "latin-1"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace") if lenient else data.decode("latin-1")


def _table(name: str, rows: List[list]) -> dict:
    rows = [[("" if c is None else str(c)) for c in r] for r in rows if any(str(c).strip() for c in r if c is not None)]
    if not rows:
        return {"name": name, "columns": [], "rows": [], "row_count": 0}
    cols = [c.strip() or f"col{i + 1}" for i, c in enumerate(rows[0])]
    body = rows[1:]
    return {"name": name, "columns": cols, "rows": body[:MAX_TABLE_ROWS], "row_count": len(body),
            "truncated": len(body) > MAX_TABLE_ROWS}


def _table_text(t: dict) -> str:
    if not t.get("columns"):
        return f"[{t.get('name', 'table')}: empty]"
    lines = [f"## {t['name']} ({t['row_count']} rows)", " | ".join(t["columns"])]
    for r in t["rows"][:400]:
        lines.append(" | ".join(str(c)[:200] for c in r))
    if t["row_count"] > 400:
        lines.append(f"... ({t['row_count'] - 400} more rows)")
    return "\n".join(lines)


def _read_xlsx(data: bytes) -> List[dict]:
    import openpyxl
    wb = openpyxl.load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    out = []
    for ws in wb.worksheets:
        rows = []
        for i, r in enumerate(ws.iter_rows(values_only=True)):
            rows.append(list(r))
            if i > MAX_TABLE_ROWS + 1:
                break
        out.append(_table(ws.title, rows))
    return out


def _read_xls(data: bytes) -> List[dict]:
    import xlrd
    wb = xlrd.open_workbook(file_contents=data)
    out = []
    for sh in wb.sheets():
        rows = [[sh.cell_value(r, c) for c in range(sh.ncols)] for r in range(min(sh.nrows, MAX_TABLE_ROWS + 1))]
        out.append(_table(sh.name, rows))
    return out


def _read_docx(data: bytes):
    import docx
    d = docx.Document(io.BytesIO(data))
    lines = []
    for p in d.paragraphs:
        st = (p.style.name or "") if p.style is not None else ""
        txt = p.text.strip()
        if not txt:
            continue
        m = re.match(r"Heading (\d)", st)
        lines.append(("#" * int(m.group(1)) + " " + txt) if m else txt)
    tables = []
    for i, t in enumerate(d.tables, 1):
        rows = [[c.text.strip() for c in r.cells] for r in t.rows]
        tb = _table(f"table{i}", rows)
        tables.append(tb)
        lines.append(_table_text(tb))
    return "\n".join(lines), tables


def _read_doc(data: bytes, name: str) -> str:
    """Legacy .doc: LibreOffice conversion when available, else printable text extraction."""
    try:
        with tempfile.TemporaryDirectory() as td:
            src = Path(td) / "in.doc"
            src.write_bytes(data)
            subprocess.run(["soffice", "--headless", "--convert-to", "txt:Text", "--outdir", td, str(src)],
                           check=True, capture_output=True, timeout=120)
            out = Path(td) / "in.txt"
            if out.exists():
                return _decode(out.read_bytes(), lenient=True)
    except Exception as e:  # noqa: BLE001
        log.info("soffice conversion unavailable for %s (%s) - extracting text", name, e)
    txt = data.decode("latin-1", errors="ignore")
    chunks = re.findall(r"[\x20-\x7e\t\r\n]{12,}", txt)
    return "\n".join(c.strip() for c in chunks)


def _html_text(html: str) -> str:
    html = re.sub(r"(?is)<(script|style).*?</\1>", " ", html)
    html = re.sub(r"(?i)<br\s*/?>|</p>|</div>|</tr>|</h\d>|</li>", "\n", html)
    html = re.sub(r"(?i)<h(\d)[^>]*>", lambda m: "\n" + "#" * int(m.group(1)) + " ", html)
    html = re.sub(r"(?i)</t[dh]>", " | ", html)
    txt = re.sub(r"<[^>]+>", " ", html)
    import html as h
    txt = h.unescape(txt)
    txt = re.sub(r"[ \t]+", " ", txt)
    return re.sub(r"\n\s*\n+", "\n\n", txt).strip()


def _ipynb_text(txt: str) -> str:
    nb = json.loads(txt)
    out = []
    for i, c in enumerate(nb.get("cells", []), 1):
        src = "".join(c.get("source", []))
        out.append(f"### cell {i} ({c.get('cell_type')})\n{src}")
    return "\n\n".join(out)


def split_sections(text: str, max_sections: int = 200) -> List[dict]:
    parts = re.split(r"(?m)^(#{1,6}\s+.*)$", text or "")
    if len(parts) <= 1:
        return [{"title": "", "text": text}] if text else []
    out = []
    if parts[0].strip():
        out.append({"title": "", "text": parts[0].strip()})
    for i in range(1, len(parts) - 1, 2):
        out.append({"title": parts[i].lstrip("# ").strip(), "text": parts[i + 1].strip()})
    return out[:max_sections]


def doc_summary(doc: dict) -> dict:
    """Light shape for listings (no text)."""
    out = {k: doc.get(k) for k in ("name", "format", "kind", "chars", "sha", "truncated", "parse_error")}
    out["tables"] = [{"name": t["name"], "columns": t["columns"][:30], "row_count": t["row_count"]} for t in doc.get("tables", [])]
    out["sections"] = [s["title"] for s in doc.get("sections", []) if s["title"]][:50]
    return out
