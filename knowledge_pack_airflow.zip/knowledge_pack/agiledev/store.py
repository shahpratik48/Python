"""Per-user persistence: SQLite (users, chats, messages) + one folder per chat with every input and output.
A user only ever sees their own rows: every query is filtered by user_id."""
from __future__ import annotations

import json
import shutil
import sqlite3
import threading
import time
import uuid
from pathlib import Path
from typing import List, Optional

SCHEMA = """
create table if not exists users (user_id text primary key, display_name text, email text, first_seen real, last_seen real);
create table if not exists chats (chat_id text primary key, user_id text not null, title text, created real, updated real,
                                  story_id text, story_title text, status text, deleted integer default 0);
create index if not exists chats_user on chats(user_id, updated);
create table if not exists messages (id integer primary key autoincrement, chat_id text not null, user_id text not null,
                                     role text, text text, meta text, ts real);
create index if not exists messages_chat on messages(chat_id, id);
"""


class Store:
    def __init__(self, db_file: Path, data_dir: Path):
        self.db_file = Path(db_file)
        self.data_dir = Path(data_dir)
        self.db_file.parent.mkdir(parents=True, exist_ok=True)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(self.db_file, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(SCHEMA)
        self._conn.commit()

    def _run(self, sql, args=(), fetch=False):
        with self._lock:
            cur = self._conn.execute(sql, args)
            rows = [dict(r) for r in cur.fetchall()] if fetch else None
            self._conn.commit()
            return rows

    # ------------------------------------------------------------------ users
    def touch_user(self, user_id: str, display_name: str = "", email: str = "") -> dict:
        now = time.time()
        row = self._run("select * from users where user_id = ?", (user_id,), True)
        if row:
            self._run("update users set last_seen = ?, display_name = coalesce(nullif(?, ''), display_name), email = coalesce(nullif(?, ''), email) where user_id = ?",
                      (now, display_name, email, user_id))
        else:
            self._run("insert into users values (?, ?, ?, ?, ?)", (user_id, display_name, email, now, now))
        return self._run("select * from users where user_id = ?", (user_id,), True)[0]

    # ------------------------------------------------------------------ chats
    def chat_folder(self, user_id: str, chat_id: str) -> Path:
        return self.data_dir / "users" / _safe(user_id) / "chats" / _safe(chat_id)

    def new_chat(self, user_id: str, title: str = "New chat") -> dict:
        cid = time.strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:6]
        now = time.time()
        self._run("insert into chats (chat_id, user_id, title, created, updated, status) values (?, ?, ?, ?, ?, 'new')", (cid, user_id, title, now, now))
        self.chat_folder(user_id, cid).mkdir(parents=True, exist_ok=True)
        return self.chat(user_id, cid)

    def chat(self, user_id: str, chat_id: str) -> Optional[dict]:
        rows = self._run("select * from chats where chat_id = ? and user_id = ? and deleted = 0", (chat_id, user_id), True)
        return rows[0] if rows else None

    def chats(self, user_id: str, limit: int = 200) -> List[dict]:
        return self._run("select * from chats where user_id = ? and deleted = 0 order by updated desc limit ?", (user_id, limit), True)

    def update_chat(self, user_id: str, chat_id: str, **fields) -> None:
        if not fields:
            return
        fields["updated"] = time.time()
        cols = ", ".join(f"{k} = ?" for k in fields)
        self._run(f"update chats set {cols} where chat_id = ? and user_id = ?", (*fields.values(), chat_id, user_id))

    def delete_chat(self, user_id: str, chat_id: str, purge_files: bool = True) -> bool:
        if not self.chat(user_id, chat_id):
            return False
        self._run("update chats set deleted = 1, updated = ? where chat_id = ? and user_id = ?", (time.time(), chat_id, user_id))
        self._run("delete from messages where chat_id = ? and user_id = ?", (chat_id, user_id))
        if purge_files:
            shutil.rmtree(self.chat_folder(user_id, chat_id), ignore_errors=True)
        return True

    # ------------------------------------------------------------------ messages
    def add_message(self, user_id: str, chat_id: str, role: str, text: str, meta: Optional[dict] = None) -> dict:
        now = time.time()
        self._run("insert into messages (chat_id, user_id, role, text, meta, ts) values (?, ?, ?, ?, ?, ?)",
                  (chat_id, user_id, role, text, json.dumps(meta or {}, default=str), now))
        self._run("update chats set updated = ? where chat_id = ? and user_id = ?", (now, chat_id, user_id))
        return {"role": role, "text": text, "meta": meta or {}, "ts": now}

    def messages(self, user_id: str, chat_id: str, limit: int = 500) -> List[dict]:
        rows = self._run("select role, text, meta, ts from messages where chat_id = ? and user_id = ? order by id limit ?", (chat_id, user_id, limit), True)
        for r in rows:
            try:
                r["meta"] = json.loads(r["meta"] or "{}")
            except Exception:  # noqa: BLE001
                r["meta"] = {}
        return rows

    def purge_old(self, keep_days: int) -> int:
        if keep_days <= 0:
            return 0
        cutoff = time.time() - keep_days * 86400
        rows = self._run("select chat_id, user_id from chats where updated < ?", (cutoff,), True)
        for r in rows:
            self.delete_chat(r["user_id"], r["chat_id"])
        return len(rows)


def _safe(s: str) -> str:
    import re
    return re.sub(r"[^A-Za-z0-9._@-]+", "_", str(s))[:120] or "x"
