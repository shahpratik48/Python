"""Optional second retriever: search by MEANING over the session inputs (embeddings).

BM25 (repoindex.py) finds exact names - tables, folders, keywords - and is always on. This index finds what a plain-English
story means when its words and the repository's words share nothing ("advisor's book of business" -> fa_client_rel_fact):
repository files, input tables and their columns, glossary rows and paragraphs of the skills / standards are embedded with an
Azure OpenAI embeddings deployment and ranked by cosine similarity.

- Off by default (`embeddings.enabled: false`); when off, the tool explains how to enable it and the agents fall back to BM25.
- No vector database: vectors live in one numpy array in memory; embeddings are cached on disk by text hash, so a second run
  (or a second story on the same repository) embeds only what changed. No secret is stored; the Azure key comes from the
  same place as the chat model's.
- Every hit is a CANDIDATE: the agents are told to confirm it with read_file / describe_table, and the planner's grounding
  still checks every file against the exact repository index. A near miss cannot silently become a wrong file.
"""
from __future__ import annotations

import hashlib
import json
import logging
import math
import re
import threading
import time
from pathlib import Path
from typing import Dict, List, Optional

log = logging.getLogger("agiledev.semantic")

DEFAULTS = {"enabled": False, "deployment": "text-embedding-3-small", "api_version": "2024-02-01", "dimensions": 512,
            "max_items": 4000, "chunk_chars": 1200, "min_score": 0.22, "batch_size": 64, "file_languages": ["sql", "python", "airflow_dag", "r", "ipynb", "yaml", "json", "config", "shell", "markdown", "text"]}


def settings(cfg) -> dict:
    s = dict(DEFAULTS)
    s.update((cfg.get("embeddings") or {}) if hasattr(cfg, "get") else {})
    return s


def _h(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8", "replace")).hexdigest()[:32]


def _cos(a: List[float], b: List[float]) -> float:
    num = sum(x * y for x, y in zip(a, b))
    da = math.sqrt(sum(x * x for x in a)) or 1.0
    db = math.sqrt(sum(y * y for y in b)) or 1.0
    return num / (da * db)


class SemanticIndex:
    """Items of every input, embedded once, searched by cosine similarity. Built lazily on the first search."""

    def __init__(self, cfg, llm, inputs, cache_dir: Path):
        self.cfg, self.llm, self.inputs = cfg, llm, inputs
        self.s = settings(cfg)
        self.cache_dir = Path(cache_dir) / "embeddings"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.items: List[dict] = []
        self.vecs: List[List[float]] = []
        self._fingerprint = ""
        self._lock = threading.Lock()
        self.stats = {"items": 0, "embedded_now": 0, "from_cache": 0, "seconds": 0.0, "error": ""}

    # ------------------------------------------------------------------ what gets embedded
    def _collect(self) -> List[dict]:
        out: List[dict] = []
        chunk = int(self.s["chunk_chars"])
        # glossary: one item per row / line (a definition is the bridge between business words and column names)
        for kind in ("glossary", "skills", "standards"):
            for d in self.inputs.docs.get(kind, []) or []:
                text = d.get("text") or ""
                if kind == "glossary":
                    parts = [ln.strip() for ln in text.splitlines() if len(ln.strip()) > 12]
                else:
                    parts = [p.strip() for p in re.split(r"\n\s*\n", text) if len(p.strip()) > 40]
                for i, p in enumerate(parts):
                    for j in range(0, len(p), chunk):
                        out.append({"kind": kind, "ref": d["name"], "title": f"{d['name']} §{i + 1}", "text": p[j:j + chunk]})
        # tables: the table as a whole and every column with its comment
        for t in self.inputs.tables:
            name = f"{t['schema']}.{t['table']}"
            head = f"table {name}" + (f": {t['comment']}" if t.get("comment") else "") + " columns: " + \
                   ", ".join(c["name"] for c in t.get("columns", [])[:80])
            out.append({"kind": "table", "ref": name, "schema": t["schema"], "title": name, "text": head[:chunk]})
            for c in t.get("columns", []):
                out.append({"kind": "column", "ref": f"{name}.{c['name']}", "schema": t["schema"], "title": f"{name}.{c['name']}",
                            "text": f"column {c['name']} ({c.get('type', '')}) of {name}" + (f": {c['comment']}" if c.get("comment") else "")})
        # repository files: path, symbols and the head of the file (the header comment usually says what it computes)
        langs = set(self.s["file_languages"])
        for idx in self.inputs.indexes():
            files = [f for f in idx.files.values() if f["language"] in langs]
            files.sort(key=lambda f: (0 if f["language"] in ("sql", "python", "airflow_dag") else 1, f["path"]))
            for f in files:
                text = f"{f['path']} ({f['language']}) symbols: {', '.join(f.get('symbols', [])[:30])}\n{f.get('head', '')}"
                out.append({"kind": "file", "ref": f["path"], "repo": idx.name, "title": f["path"], "text": text[:chunk]})
        return out[: int(self.s["max_items"])]

    # ------------------------------------------------------------------ build (cached by text hash)
    def _cache_file(self) -> Path:
        return self.cache_dir / f"{re.sub(r'[^a-z0-9_-]', '_', str(self.s['deployment']).lower())}_{self.s['dimensions']}.jsonl"

    def _load_cache(self) -> Dict[str, List[float]]:
        out: Dict[str, List[float]] = {}
        f = self._cache_file()
        if f.exists():
            for ln in f.read_text(encoding="utf-8").splitlines():
                try:
                    h, v = ln.split("\t", 1)
                    out[h] = json.loads(v)
                except ValueError:
                    continue
        return out

    def ensure(self) -> None:
        items = self._collect()
        fp = _h("|".join(_h(i["text"]) for i in items))
        with self._lock:
            if fp == self._fingerprint and self.vecs:
                return
            t0 = time.time()
            cache = self._load_cache()
            todo = [i for i in items if _h(i["text"]) not in cache]
            new: Dict[str, List[float]] = {}
            try:
                bs = int(self.s["batch_size"])
                for k in range(0, len(todo), bs):
                    batch = todo[k:k + bs]
                    vs = self.llm.embed([i["text"] for i in batch], self.s)
                    for i, v in zip(batch, vs):
                        new[_h(i["text"])] = v
                self.stats["error"] = ""
            except Exception as e:  # noqa: BLE001
                self.stats["error"] = f"{type(e).__name__}: {str(e)[:200]}"
                log.warning("embedding failed: %s", self.stats["error"])
            if new:
                with self._cache_file().open("a", encoding="utf-8") as fh:
                    for h, v in new.items():
                        fh.write(h + "\t" + json.dumps([round(x, 6) for x in v]) + "\n")
                cache.update(new)
            self.items, self.vecs = [], []
            for i in items:
                v = cache.get(_h(i["text"]))
                if v is not None:
                    self.items.append(i)
                    self.vecs.append(v)
            self._fingerprint = fp
            self.stats.update({"items": len(self.items), "embedded_now": len(new), "from_cache": len(self.items) - len(new),
                               "seconds": round(time.time() - t0, 1)})

    # ------------------------------------------------------------------ search
    def search(self, query: str, k: int = 8, kinds: Optional[List[str]] = None) -> List[dict]:
        self.ensure()
        if not self.vecs:
            return []
        qv = self.llm.embed([query], self.s)[0]
        scored = []
        for it, v in zip(self.items, self.vecs):
            if kinds and it["kind"] not in kinds:
                continue
            scored.append((_cos(qv, v), it))
        scored.sort(key=lambda x: -x[0])
        out, seen = [], set()
        for sc, it in scored:
            if sc < float(self.s["min_score"]):
                break
            key = (it["kind"], it["ref"])
            if key in seen:
                continue
            seen.add(key)
            out.append(dict(it, score=round(sc, 3), via="semantic"))
            if len(out) >= k:
                break
        return out


def fake_embedding(text: str, dims: int = 512) -> List[float]:
    """Deterministic bag-of-words vector for the self-test (no model): similar words -> similar vectors."""
    v = [0.0] * dims
    for tok in re.findall(r"[a-z0-9]+", text.lower()):
        for g in (tok, tok[:4], tok[:6]):
            j = int(hashlib.md5(g.encode()).hexdigest(), 16) % dims
            v[j] += 1.0
    n = math.sqrt(sum(x * x for x in v)) or 1.0
    return [x / n for x in v]
