# ODM tables to describe from Greenplum

One table per line (`schema.table` or a markdown table with a description column). Tables created by the repository's SQL
are added automatically (`build.describe_tables_from_code`). Lines starting with # are ignored.

| table | description |
|---|---|
| core_ikg.odm_rule_metadata_auto_refresh | insight rule metadata used by the ODM process |
| core_ikg.ikg_profile_table_descriptions | profile table descriptions ODM scripts read from |
