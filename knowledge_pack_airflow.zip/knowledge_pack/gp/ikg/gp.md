# IKG tables to describe from Greenplum

One table per line (`schema.table` or a markdown table with a description column). Tables created by the repository's SQL
are added automatically (`build.describe_tables_from_code`). Lines starting with # are ignored.

| table | description |
|---|---|
| core_ikg.ikg_column_lineage_master_auto_refresh | column level lineage (source table/column -> target table/column) |
| core_ikg.ikg_profile_table_descriptions | one row per profile / presentation table with its business description |
| core_ikg.ikg_attribute_business_description | business description of every attribute (column) |
| core_ikg.ikg_metadata_glossary_llm | business glossary generated and curated for IKG |
| core_ikg.ikg_graph_relationship | table-to-table relationships of the knowledge graph |
| core_ikg.ikg_graph_joining_key | joining keys between tables |
| core_ikg.insights_dashboard_details | dashboards and the insights they show |
| core_ikg.odm_rule_metadata_auto_refresh | insight rule metadata (one row per rule / insight) |
