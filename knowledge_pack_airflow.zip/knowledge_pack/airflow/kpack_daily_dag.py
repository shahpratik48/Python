"""Knowledge Pack DAG - one DAG, one task per system (build_ikg, build_odm, build_nlg) + send_report.
Schedule from the config: Monday-Friday 19:00 America/New_York. Each task writes ONE file: output/<system>/<system>_pack.zip
(the complete, self-contained pack; replaced only by a good build). History under <KPACK_HOME>/data/versions/.

Uses the EXISTING Airflow objects of the IKG DAGs (names in config/kpack_config.yaml -> airflow:):
  Variable   GENESIS_DDLC_IKG_GIT_SECRET      GitLab private token
  Variable   IKG_POSTGRES_CONN_ID             -> Connection id INSIGHT_PIPELINE_RUNNER_DB_CONNECTOR (Greenplum host / db / login / password)
  Variable   KPACK_AZURE_OPENAI_API_KEY       NEW - the Azure OpenAI key (create once; without it the pack is facts-only, BM25 index)
  Variables  AIRFLOW_UAT_URL / AIRFLOW_PROD_URL   " - Dev" / " - Prod" suffix of the e-mail subject
  e-mail     airflow.utils.email.send_email(to, subject, html, files) to email.to (pratik.shah.2@ubs.com, dl-staat-ds-ikg@ubs.com)

Deploy: copy the whole knowledge_pack folder to the scheduler (or set KPACK_HOME to it) so kpack/, agiledev/, config/,
skills/, gp/ are importable; put this file in the DAG folder. No secret is in this file, in XCom or in the logs.
"""
from __future__ import annotations

import os
import sys
from datetime import timedelta
from pathlib import Path

import pendulum
import yaml
from airflow import DAG
from airflow.operators.python import PythonOperator

KPACK_HOME = Path(os.environ.get("KPACK_HOME") or Path(__file__).resolve().parent.parent)
if str(KPACK_HOME) not in sys.path:
    sys.path.insert(0, str(KPACK_HOME))
CONFIG_PATH = KPACK_HOME / "config" / "kpack_config.yaml"
_CFG = yaml.safe_load(CONFIG_PATH.read_text(encoding="utf-8")) or {}
_AF = _CFG.get("airflow") or {}
SYSTEMS = list(_AF.get("systems") or list((_CFG.get("systems") or {}).keys()))


def build_system(system: str, **context):
    from kpack.airflow_runtime import load_airflow_secrets
    from kpack.builder import PackBuilder
    from kpack.config import load_config
    log = context["ti"].log
    cfg = load_config(str(CONFIG_PATH))
    found = load_airflow_secrets(cfg)                        # Variables + Connection -> memory; never logged as values
    log.info("credentials resolved from Airflow: %s", ", ".join(f"{k}: {v}" for k, v in found.items()) or "none")
    b = PackBuilder(cfg, system, progress=log.info, use_llm=bool(cfg["build"].get("derived_layer", True)))
    r = b.build()
    # XCom carries only the summary (paths, counts, health) - never content, never secrets
    return {"system": system, "path": r["path"], "zip": r.get("zip", ""), "promoted": r.get("promoted", True),
            "manifest": {k: r["manifest"].get(k) for k in ("system", "version", "built_at", "counts", "repo", "zip_mb", "diff", "cost", "promoted")},
            "health": r["health"]}


def send_report(**context):
    from kpack.airflow_runtime import load_airflow_secrets
    from kpack.config import load_config
    from kpack.mailer import send_report as _send
    ti = context["ti"]
    cfg = load_config(str(CONFIG_PATH))
    load_airflow_secrets(cfg)
    results = []
    for s in SYSTEMS:
        r = ti.xcom_pull(task_ids=f"build_{s}")
        results.append(r or {"system": s, "error": "task failed or produced no result"})
    out = _send(cfg, results)
    ti.log.info("e-mail: %s", out)
    if not out.get("sent") and out.get("reason", "").startswith(("SMTP", "Exception", "RuntimeError", "OSError")):
        raise RuntimeError(f"failed to send report email: {out.get('reason')}")
    return out


default_args = {"owner": _AF.get("owner", "staat-insights"), "retries": int(_AF.get("retries", 1)),
                "retry_delay": timedelta(minutes=int(_AF.get("retry_delay_minutes", 15))),
                "execution_timeout": timedelta(minutes=int(_AF.get("execution_timeout_minutes", 120)))}
if _AF.get("pool"):
    default_args["pool"] = _AF["pool"]

with DAG(dag_id=_AF.get("dag_id", "knowledge_pack_daily"),
         description="Daily (Mon-Fri) IKG / ODM / NLG system knowledge packs (repo + tables + skills -> indexed pack zip + e-mail)",
         schedule=_AF.get("schedule", "0 19 * * 1-5"), start_date=pendulum.datetime(2025, 1, 3, tz=_AF.get("timezone", "America/New_York")),
         catchup=False, max_active_runs=1, default_args=default_args, tags=["knowledge-pack", "staat-insights"] + SYSTEMS) as dag:
    builds = [PythonOperator(task_id=f"build_{s}", python_callable=build_system, op_kwargs={"system": s}) for s in SYSTEMS]
    report = PythonOperator(task_id="send_report", python_callable=send_report, trigger_rule="all_done")
    builds >> report
