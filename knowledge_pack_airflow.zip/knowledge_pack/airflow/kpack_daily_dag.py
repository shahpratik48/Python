"""Knowledge Pack DAG - one DAG, one task per system (build_ikg, build_odm, build_nlg) + one report task.
Schedule from the config: Monday-Monday-Friday 19:00 America/New_York. Each task writes ONE file: output/<system>/<system>_pack.zip - the complete, self-contained pack (replaced only by a good build).

Schedule, timezone, systems, owner, retries and the Airflow Variable NAMES all come from config/kpack_config.yaml
(`airflow:` block) - nothing is hard-coded here and no secret is ever in this file, in XCom or in the logs.

Deploy: copy the whole knowledge_pack folder next to this DAG (or set KPACK_HOME to it) so `kpack/`, `agiledev/`,
`config/`, `skills/`, `gp/` are importable; the packs land in <KPACK_HOME>/output/<system>/<system>_pack.zip (only file there); history under <KPACK_HOME>/data/versions/.

Secrets (Airflow Variables, created once in the UI / CLI, names from the config):
  KPACK_AZURE_OPENAI_API_KEY, KPACK_GIT_READ_TOKEN, KPACK_GREENPLUM_PASSWORD, KPACK_EMAIL_PASSWORD (only if smtp_user is set)
Optionally an Airflow Connection (airflow.connections.greenplum_conn_id) carries the Greenplum host / user / password instead.
"""
from __future__ import annotations

import os
import sys
from datetime import datetime, timedelta
from pathlib import Path

import pendulum
import yaml
from airflow import DAG
from airflow.models import Variable
from airflow.operators.python import PythonOperator

KPACK_HOME = Path(os.environ.get("KPACK_HOME") or Path(__file__).resolve().parent.parent)
if str(KPACK_HOME) not in sys.path:
    sys.path.insert(0, str(KPACK_HOME))
CONFIG_PATH = KPACK_HOME / "config" / "kpack_config.yaml"
_CFG = yaml.safe_load(CONFIG_PATH.read_text(encoding="utf-8")) or {}
_AF = _CFG.get("airflow") or {}
_VARS = _AF.get("variables") or {}
SYSTEMS = list(_AF.get("systems") or list((_CFG.get("systems") or {}).keys()))


def _load_secrets(cfg):
    """Airflow Variables -> process memory (kpack.config secret store). Missing ones degrade the build instead of failing it."""
    from kpack.config import put_secret
    for name, var in (("llm_api_key", _VARS.get("azure_openai_api_key")), ("git_read_token", _VARS.get("git_read_token")),
                      ("greenplum_password", _VARS.get("greenplum_password")), ("email_password", _VARS.get("email_password"))):
        if var:
            put_secret(name, Variable.get(var, default_var="") or "")
    conn_id = (_AF.get("connections") or {}).get("greenplum_conn_id")
    if conn_id:
        from airflow.hooks.base import BaseHook
        c = BaseHook.get_connection(conn_id)
        cfg["greenplum"].update({"host": c.host, "port": c.port or 5432, "database": c.schema, "user": c.login})
        put_secret("greenplum_password", c.password or "")


def build_system(system: str, **context):
    from kpack.config import load_config
    from kpack.builder import PackBuilder
    cfg = load_config(str(CONFIG_PATH))
    _load_secrets(cfg)
    log = context["ti"].log
    b = PackBuilder(cfg, system, progress=log.info, use_llm=bool(cfg["build"].get("derived_layer", True)))
    r = b.build()
    # XCom carries only the summary (paths, counts, health) - never content, never secrets
    return {"system": system, "path": r["path"], "zip": r.get("zip", ""), "promoted": r.get("promoted", True), "manifest": {k: r["manifest"].get(k) for k in ("system", "version", "built_at", "counts", "repo", "zip_mb", "diff", "cost")},
            "health": r["health"]}


def send_report(**context):
    from kpack.config import load_config
    from kpack.mailer import send_report as _send
    cfg = load_config(str(CONFIG_PATH))
    _load_secrets(cfg)
    ti = context["ti"]
    results = []
    for s in SYSTEMS:
        r = ti.xcom_pull(task_ids=f"build_{s}")
        results.append(r or {"system": s, "error": "task failed or produced no result"})
    out = _send(cfg, results)
    ti.log.info("e-mail: %s", out)
    return out


default_args = {"owner": _AF.get("owner", "staat-insights"), "retries": int(_AF.get("retries", 1)),
                "retry_delay": timedelta(minutes=int(_AF.get("retry_delay_minutes", 15))),
                "execution_timeout": timedelta(minutes=int(_AF.get("execution_timeout_minutes", 120)))}
if _AF.get("pool"):
    default_args["pool"] = _AF["pool"]

with DAG(dag_id=_AF.get("dag_id", "knowledge_pack_daily"), description="Daily (Mon-Fri) IKG / ODM / NLG system knowledge packs (repo + tables + skills -> indexed pack + e-mail)",
         schedule=_AF.get("schedule", "0 19 * * 1-5"), start_date=pendulum.datetime(2025, 1, 3, tz=_AF.get("timezone", "America/New_York")),
         catchup=False, max_active_runs=1, default_args=default_args, tags=["knowledge-pack", "staat-insights"] + SYSTEMS) as dag:
    builds = [PythonOperator(task_id=f"build_{s}", python_callable=build_system, op_kwargs={"system": s}) for s in SYSTEMS]
    report = PythonOperator(task_id="send_report", python_callable=send_report, trigger_rule="all_done")
    builds >> report
