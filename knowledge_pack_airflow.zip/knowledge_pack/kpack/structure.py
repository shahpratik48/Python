"""Deterministic analysis of a code repository - everything a reader agent would otherwise discover with tool calls,
computed by code, once per pack: folder map, symbol index, DAGs and their tasks, how scripts are registered (static
task lists or dynamic folder walks), table <-> script map, companion patterns, Jinja parameters, dependencies.
No model is involved; the output is exact and the same on every build."""
from __future__ import annotations

import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, List

from agiledev.repoindex import RepoIndex

_JINJA = re.compile(r"\{\{\s*params\.(\w+)\s*\}\}")
_PROPS = re.compile(r"props\[['\"](\w+)['\"]\]")
_VAR = re.compile(r"Variable\.get\(\s*['\"](\w+)['\"]")
_TASK = re.compile(r"task_id\s*=\s*['\"]([\w.-]+)['\"]")
_SQLREF = re.compile(r"sql\s*=\s*['\"]([^'\"]+\.sql)['\"]")
_DAGID = re.compile(r"dag_id\s*=\s*['\"]([\w.-]+)['\"]")
_GROUP = re.compile(r"TaskGroup\(\s*(?:group_id\s*=\s*)?['\"]([\w.-]+)['\"]")
_FOLDER_REF = re.compile(r"['\"]((?:/opt/airflow/)?dags/[\w/.-]+)['\"]")
_PREFIX_REF = re.compile(r"sql_path_prefix\s*=\s*['\"]/?([\w/.-]+)['\"]")
_DYN = re.compile(r"\b(build_sql_taskgroups?_recursive|build_taskgroups?|os\.walk|rglob|glob\.glob|listdir)\b")
_CHAIN = re.compile(r"^\s*([\w\[\], ]+?)\s*(>>.*)$", re.M)
_TBL = re.compile(r"(?is)\b(create\s+(?:temp(?:orary)?\s+)?table\s+(?:if\s+not\s+exists\s+)?|insert\s+into\s+|truncate\s+(?:table\s+)?|delete\s+from\s+|update\s+)([\w{}.'\"]+)")
_READ = re.compile(r"(?is)\b(?:from|join)\s+([\w{}.'\"]+)")
_DROP = re.compile(r"(?is)\bdrop\s+table\s+(?:if\s+exists\s+)?([\w{}.'\"]+)")
_KW = {"select", "values", "dual", "lateral", "unnest", "generate_series", "(", "("}


_NOT_TABLE_FIRST = {"self", "args", "os", "sys", "re", "np", "pd", "df", "logging", "log", "json", "datetime", "time", "pathlib", "typing", "airflow",
                    "odm", "ikg", "nlg", "props", "config", "settings", "cfg", "utils", "util", "helper", "helpers", "math", "random", "str", "list", "dict",
                    "subprocess", "shutil", "requests", "yaml", "psycopg2", "pandas", "numpy", "spark", "pyspark", "fields_and_values", "kwargs", "context"}
_NOT_TABLE_LAST = {"append", "info", "debug", "warning", "error", "get", "format", "join", "split", "strip", "lower", "upper", "replace", "items",
                   "keys", "values", "read", "write", "close", "open", "path", "py", "sql", "txt", "csv", "json", "yml", "yaml", "exists", "copy",
                   "table", "name", "schema", "extend", "update", "pop", "sort", "sql_files", "sqlfiles", "run", "execute"}
_NOT_TABLE_BARE = {"and", "or", "has", "the", "where", "this", "that", "with", "table", "into", "only", "not", "all", "each", "when", "then",
                   "from", "join", "select", "true", "false", "null", "none"}


def _norm_table(t: str) -> str:
    t = t.strip("'\"")
    t = re.sub(r"\{\{\s*params\.(\w+)\s*\}\}", r"{\1}", t)
    t = re.sub(r"\{\s*props\[['\"](\w+)['\"]\]\s*\}", r"{\1}", t)
    t = t.lower().strip(".")
    if not t or t in _NOT_TABLE_BARE or t.endswith((".", "(")) or t.count(".") > 1 and "{" not in t:
        return ""
    if t.count("{") != t.count("}"):
        return ""
    if "." in t:
        first, _, last = t.rpartition(".")
        if first.split(".")[0] in _NOT_TABLE_FIRST or last in _NOT_TABLE_LAST or len(last) < 3 or (len(first) <= 2 and "{" not in first):
            return ""                                  # a.col / t1.col are aliases (extract(... from a.d)), not tables
    elif len(t) < 4 or not re.match(r"^[a-z_{][a-z0-9_{}]+$", t):
        return ""
    return t


def _purpose_from_name(folder: str) -> str:
    n = folder.rsplit("/", 1)[-1].lower()
    hints = [("history", "history / archive versions of the tables of the sibling folder"), ("archive", "archive scripts"),
             ("valid", "validation / data-quality checks"), ("dq", "data-quality checks"), ("test", "tests"),
             ("rule", "rule definitions (insight / business rules)"), ("insight", "insight computations"),
             ("profile", "profile tables (one row per subject)"), ("base", "base loads / ingestion"), ("ingest", "ingestion"),
             ("feature", "feature tables"), ("prospect", "prospect-related tables"), ("config", "configuration / registries"),
             ("util", "shared helpers"), ("dag", "Airflow DAG definitions"), ("python", "python scripts"), ("sql", "SQL scripts"),
             ("process", "process / housekeeping steps"), ("post", "post-processing"), ("lineage", "lineage"), ("report", "reports")]
    return "; ".join(h for k, h in hints if k in n) or ""


class RepoStructure:
    def __init__(self, idx: RepoIndex, system: str):
        self.idx, self.system = idx, system
        self.files = idx.files
        self._text: Dict[str, str] = {}

    # ------------------------------------------------------------------ token index (one pass; makes companions / registration lookups O(1))
    _REG_LANGS = ("python", "yaml", "json", "config", "text", "shell", "toml", "airflow_dag", "markdown", "md")
    _IDENT = re.compile(r"[A-Za-z_][A-Za-z0-9_]{3,}")

    def _tokens(self) -> Dict[str, set]:
        if getattr(self, "_tok", None) is None:
            tok: Dict[str, set] = defaultdict(set)
            for rel in self.files:
                for w in set(self._IDENT.findall(self.text(rel)[:400000])):
                    tok[w.lower()].add(rel)
            self._tok = tok
        return self._tok

    def _line_with(self, rel: str, word: str) -> str:
        rx = re.compile(r"\b" + re.escape(word) + r"\b", re.I)
        for ln in self.text(rel).splitlines():
            if rx.search(ln):
                return ln.strip()[:200]
        return ""

    def _reg_candidates(self, folder: str, k: int = 3) -> List[dict]:
        """Files outside `folder` that list its scripts (same scoring as RepoIndex.registration_candidates, via the token index)."""
        tok = self._tokens()
        sibs = [r for r, f in self.files.items() if f["folder"] == folder]
        stems = {Path(r).stem.lower() for r in sibs if len(Path(r).stem) > 3}
        fname = folder.rsplit("/", 1)[-1].lower()
        score: Counter = Counter()
        for st in stems:
            for rel in tok.get(st, ()):
                if self.files[rel]["folder"] != folder and self.files[rel]["language"] in self._REG_LANGS and not rel.startswith(("release_audit/", "logs/")):
                    score[rel] += 1
        if len(fname) > 3:
            for rel in tok.get(fname, ()):
                if self.files[rel]["folder"] != folder and self.files[rel]["language"] in self._REG_LANGS and not rel.startswith(folder + "/"):
                    score[rel] += 3
        need = max(2, min(3, len(stems) // 4)) if len(stems) > 1 else 1
        out = []
        for rel, sc in score.most_common(12):
            hits = sc - (3 if fname in tok and rel in tok.get(fname, ()) else 0)
            if hits < need and sc < 3:
                continue
            key = next((st for st in stems if rel in tok.get(st, ())), fname)
            out.append({"path": rel, "mentions": sc, "of": len(stems), "example_line": self._line_with(rel, key),
                        "reason": (f"names the folder {fname}/ " if sc - hits else "") + (f"mentions {hits} of its {len(stems)} script(s)" if hits else "")
                                  + f" - new scripts in {folder or '/'} must be registered here"})
            if len(out) >= k:
                break
        return out

    def _companions(self, path: str, k: int = 6) -> List[dict]:
        """Sibling files (same stem +- one token in another folder) and configuration files mentioning the stem - via the token index."""
        tok = self._tokens()
        stem = Path(path).stem
        folder = self.files[path]["folder"]
        toks = stem.split("_")
        variants = {stem}
        if len(toks) > 2:
            for i in range(len(toks)):
                variants.add("_".join(toks[:i] + toks[i + 1:]))
        hits, seen = [], {path}
        if getattr(self, "_by_stem", None) is None:          # stem -> files, built once (was a scan of every file per file)
            self._by_stem = {}
            for r in self.files:
                self._by_stem.setdefault(Path(r).stem, []).append(r)
        for v in variants:
            for rel in self._by_stem.get(v, ()):
                if rel not in seen and self.files[rel]["folder"] != folder:
                    seen.add(rel)
                    hits.append({"path": rel, "relation": "sibling", "example_line": ""})
        for w in [stem] + [Path(h["path"]).stem for h in hits]:
            if len(w) <= 4:
                continue
            for rel in sorted(tok.get(w.lower(), ())):
                if rel in seen or self.files[rel]["folder"] == folder or self.files[rel]["language"] not in self._REG_LANGS + ("sql", "r"):
                    continue
                seen.add(rel)
                kind = "configuration" if self.files[rel]["language"] in self._REG_LANGS else "consumer"
                hits.append({"path": rel, "relation": kind, "example_line": self._line_with(rel, w) if kind == "configuration" else ""})
                if len(hits) >= 3 * k:
                    break
        hits.sort(key=lambda h: {"sibling": 0, "configuration": 1}.get(h["relation"], 2))
        return hits[:k]

    def text(self, rel: str) -> str:
        if rel not in self._text:
            try:
                self._text[rel] = (self.idx.root / rel).read_text(encoding="utf-8", errors="replace")
            except Exception:  # noqa: BLE001
                self._text[rel] = ""
        return self._text[rel]

    # ------------------------------------------------------------------ DAGs and registration
    def dags(self) -> List[dict]:
        out = []
        for rel, f in self.files.items():
            if f["language"] not in ("python", "airflow_dag"):
                continue
            t = self.text(rel)
            if "airflow" not in t or ("DAG(" not in t and "dag_id" not in t):
                continue
            tasks = _TASK.findall(t)
            sqls = _SQLREF.findall(t)
            groups = _GROUP.findall(t)
            folders = sorted({m.replace("/opt/airflow/", "").rstrip("/") for m in _FOLDER_REF.findall(t)} |
                             {m.strip("/") for m in _PREFIX_REF.findall(t)})
            dynamic = _DYN.findall(t)
            chains = [m.group(0).strip() for m in _CHAIN.finditer(t) if ">>" in m.group(0)][:40]
            out.append({"path": rel, "dag_ids": sorted(set(_DAGID.findall(t))), "task_ids": tasks[:400], "task_groups": groups[:100],
                        "sql_files_referenced": sqls[:400], "folders_referenced": folders, "dynamic_registration": sorted(set(dynamic)),
                        "variables": sorted(set(_VAR.findall(t)))[:60], "props": sorted(set(_PROPS.findall(t)))[:60], "dependency_chains": chains,
                        "imports": sorted(set(re.findall(r"^\s*(?:from|import)\s+([\w.]+)", t, re.M)))[:40]})
        return out

    def registration_map(self, dags: List[dict]) -> Dict[str, dict]:
        """folder -> how its scripts get registered: static (a DAG / config lists them by name) or dynamic (a DAG walks the folder)."""
        folders = sorted({f["folder"] for f in self.files.values() if f["language"] in ("sql", "python", "r")})
        out = {}
        for folder in folders:
            entry = {"folder": folder, "static": [], "dynamic": [], "rule": ""}
            for d in dags:
                hit_static = [s for s in d["sql_files_referenced"] if s.strip("/").startswith(folder.split("/")[-1]) or folder in s]
                if hit_static:
                    entry["static"].append({"path": d["path"], "example_line": f"sql='{hit_static[0]}'", "count": len(hit_static)})
                for fr in d["folders_referenced"]:
                    fr_n = fr.strip("/")
                    if d["dynamic_registration"] and (folder.startswith(fr_n) or fr_n.endswith(folder.rsplit("/", 1)[-1]) or folder.split("/")[-2:] == fr_n.split("/")[-2:]):
                        entry["dynamic"].append({"path": d["path"], "root": fr_n, "via": ", ".join(d["dynamic_registration"])})
            cands = self._reg_candidates(folder, 3)
            entry["candidates"] = [{"path": c["path"], "reason": c["reason"][:160], "example_line": c.get("example_line", "")[:160]} for c in cands]
            if entry["dynamic"]:
                entry["rule"] = (f"AUTOMATIC: {entry['dynamic'][0]['path']} walks {entry['dynamic'][0]['root']} ({entry['dynamic'][0]['via']}) - a new "
                                 "script in this folder runs without any registration; folder = task group, file stem = task id")
            elif entry["static"]:
                entry["rule"] = f"STATIC: add a task in {entry['static'][0]['path']} like {entry['static'][0]['example_line']}"
            elif cands:
                entry["rule"] = f"LIKELY: {cands[0]['path']} - {cands[0]['reason'][:120]}"
            else:
                entry["rule"] = "none found - scripts here may be called directly or are not orchestrated"
            out[folder] = entry
        return out

    # ------------------------------------------------------------------ tables
    def table_map(self) -> dict:
        """table -> scripts that create / write it and scripts that read it (parsed from the SQL and the SQL inside python)."""
        writes, reads, creates_in = defaultdict(set), defaultdict(set), defaultdict(list)
        for rel, f in self.files.items():
            if f["language"] not in ("sql", "python", "airflow_dag", "r"):
                continue
            t = self.text(rel)
            if f["language"] in ("python", "airflow_dag") and not re.search(r"(?i)\b(select|insert|create)\b", t):
                continue
            for kind, tbl in _TBL.findall(t):
                n = _norm_table(tbl)
                if n and n not in _KW and len(n) > 2 and not n.startswith("("):
                    writes[n].add(rel)
                    creates_in[rel].append(n)
            imports = set(re.findall(r"^\s*from\s+([\w.]+)\s+import", t, re.M)) if f["language"] in ("python", "airflow_dag") else set()
            for tbl in _READ.findall(t):
                n = _norm_table(tbl)
                if not n or n in _KW or len(n) < 3 or n.startswith("(") or n in imports or n.split(".")[0] in ("airflow", "odm", "ikg", "nlg", "datetime", "pathlib", "typing"):
                    continue
                if "." in n or "{" in n or re.search(r"_(ikg|odm|nlg)$", n):
                    reads[n].add(rel)
        tables = sorted(set(writes) | set(reads))
        return {"tables": {t: {"written_by": sorted(writes.get(t, [])), "read_by": sorted(reads.get(t, []))[:60]} for t in tables},
                "script_tables": {rel: sorted(set(v)) for rel, v in creates_in.items()}}

    # ------------------------------------------------------------------ params, symbols
    def params(self) -> dict:
        used = Counter()
        where = defaultdict(set)
        for rel, f in self.files.items():
            t = self.text(rel)
            for p in _JINJA.findall(t) + _PROPS.findall(t):
                used[p] += 1
                if len(where[p]) < 5:
                    where[p].add(rel)
        return {p: {"uses": n, "examples": sorted(where[p])} for p, n in used.most_common(200)}

    def symbols(self) -> Dict[str, dict]:
        out = {}
        for rel, f in self.files.items():
            if f["language"] in ("python", "airflow_dag"):
                t = self.text(rel)
                out[rel] = {"defs": sorted(set(re.findall(r"^\s*(?:def|class)\s+(\w+)", t, re.M)))[:60],
                            "header": "\n".join(l for l in t.splitlines()[:8] if l.strip().startswith(("#", '"""', "'''")))[:400]}
            elif f["language"] == "sql":
                t = self.text(rel)
                out[rel] = {"header": "\n".join(l for l in t.splitlines()[:8] if l.strip().startswith("--"))[:400],
                            "statements": len([s for s in re.split(r";\s*\n", t) if s.strip()])}
        return out

    # ------------------------------------------------------------------ folders and companions
    def folder_map(self, reg: Dict[str, dict], tmap: dict) -> Dict[str, dict]:
        out = {}
        by_folder = defaultdict(list)
        for rel, f in self.files.items():
            by_folder[f["folder"]].append(rel)
        for folder, rels in sorted(by_folder.items()):
            langs = Counter(self.files[r]["language"] for r in rels)
            main_lang = langs.most_common(1)[0][0]
            ex = self.idx.examples(main_lang, folder + "/" if folder else "", k=2)
            readme = next((r for r in rels if Path(r).name.lower().startswith("readme")), None)
            heads = []
            for r in rels[:40]:
                if self.files[r]["language"] in ("sql", "python"):
                    h = next((l.strip("-# ").strip() for l in self.text(r).splitlines()[:6] if l.strip().startswith(("--", "#")) and len(l.strip()) > 12), "")
                    if h:
                        heads.append(h[:120])
            stems = [Path(r).stem for r in rels]
            suffix = Counter(s.rsplit("_", 1)[-1] for s in stems if "_" in s).most_common(3)
            tables_here = sorted({t for r in rels for t in tmap.get("script_tables", {}).get(r, [])})[:40]
            out[folder] = {"folder": folder, "files": len(rels), "languages": dict(langs), "typical_files": ex,
                           "purpose_hint": _purpose_from_name(folder), "readme": readme, "header_samples": heads[:5],
                           "common_name_suffixes": [s for s, _ in suffix], "tables_built_here": tables_here,
                           "registration": reg.get(folder, {}).get("rule", ""), "size_chars": sum(self.files[r]["chars"] for r in rels)}
        return out

    def companion_patterns(self, folders: Dict[str, dict]) -> List[dict]:
        """Folder-to-folder stem transformations that recur (x_curr_ikg.sql in A <-> x_ikg.sql in B = history pattern),
        and config / registry files that list the scripts of a folder - learnt by sampling files, stated as rules."""
        pats = Counter()
        examples = {}
        for folder, info in folders.items():
            if info["languages"].get("sql", 0) + info["languages"].get("python", 0) == 0:
                continue
            rels = [r for r, f in self.files.items() if f["folder"] == folder][:12]
            for r in rels:
                for c in self._companions(r, k=6):
                    if c["relation"] == "consumer":
                        continue
                    other = c["path"].rsplit("/", 1)[0] if "/" in c["path"] else ""
                    a, b = Path(r).stem, Path(c["path"]).stem
                    key = (folder, other, c["relation"], _stem_rule(a, b))
                    pats[key] += 1
                    examples.setdefault(key, (r, c["path"], c.get("example_line", "")[:120]))
        out = []
        for (folder, other, rel, rule), n in pats.most_common(200):
            if n < 2:
                continue
            ex = examples[(folder, other, rel, rule)]
            out.append({"folder": folder, "companion_folder_or_file": other if rel == "sibling" else ex[1], "relation": rel, "stem_rule": rule,
                        "occurrences": n, "example": {"file": ex[0], "companion": ex[1], "line": ex[2]},
                        "rule": (f"a script in {folder} has a sibling in {other} named by {rule}" if rel == "sibling" else
                                 f"{ex[1]} lists the scripts of {folder} (one entry per script; copy the neighbouring entry)")})
        return out

    # ------------------------------------------------------------------ all together
    def analyse(self) -> dict:
        dags = self.dags()
        reg = self.registration_map(dags)
        tmap = self.table_map()
        folders = self.folder_map(reg, tmap)
        return {"system": self.system, "repo": self.idx.name, "files": len(self.files),
                "languages": dict(Counter(f["language"] for f in self.files.values())),
                "tree": self.idx.tree(depth=4, max_entries=400), "dags": dags, "registration": reg, "tables": tmap["tables"],
                "script_tables": tmap["script_tables"], "params": self.params(), "symbols": self.symbols(), "folders": folders,
                "companion_patterns": self.companion_patterns(folders),
                "file_list": {rel: {"language": f["language"], "chars": f["chars"], "lines": f["lines"]} for rel, f in self.files.items()}}


def _stem_rule(a: str, b: str) -> str:
    ta, tb = a.split("_"), b.split("_")
    removed = [t for t in ta if t not in tb]
    added = [t for t in tb if t not in ta]
    if not removed and not added:
        return "same stem"
    return ("drop " + "_".join(removed) if removed else "") + (" add " + "_".join(added) if added else "")
