"""Retrieval-quality layer of the pack (all deterministic, built once per pack):

  chunks       code split into retrieval-sized units (SQL statements / python functions & classes / yaml top-level keys),
               each prefixed with a CONTEXT HEADER (system, file, folder purpose, registration, tables) - "contextual
               retrieval": a chunk is found even when the words that identify it are only in its surroundings
  graph        a knowledge graph: nodes = tables, scripts, folders, DAGs, parameters, skills, terms; edges = builds, reads,
               registered_by, companion_of, in_folder, uses_param, defines - consumers walk 1-2 hops for impact analysis
               ("what breaks if this column changes") without any model call
  cards        pre-rendered context cards (markdown, prompt-sized) per folder / table / DAG / how-to - what an agent pastes
               into its prompt; assembled once here instead of per question in every use case
  exemplars    one canonical file per folder (the most typical sibling) - the coder's few-shot example
  synonyms     query-expansion table from the glossary / bridge / parameter names (business word -> technical tokens)
"""
from __future__ import annotations

import json
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, List, Tuple

_SQL_STMT = re.compile(r";\s*\n")
_PY_DEF = re.compile(r"^(?=(?:async\s+)?(?:def|class)\s+\w+)", re.M)
_YAML_TOP = re.compile(r"^(?=[A-Za-z_][\w.-]*\s*:)", re.M)
_MD_HEAD = re.compile(r"^(?=#{1,3}\s)", re.M)
MAX_CHUNK = 2400
MIN_CHUNK = 120


def _split(text: str, language: str) -> List[Tuple[str, str]]:
    """-> [(label, chunk_text)] - semantic units, merged when tiny, cut when huge."""
    if language == "sql":
        parts = _SQL_STMT.split(text)
        labels = []
        for p in parts:
            m = re.search(r"(?is)\b(create\s+(?:temp\w*\s+)?table|insert\s+into|update|delete\s+from|truncate|drop\s+table|select|with|grant|analyze|vacuum)\b\s*(?:if\s+not\s+exists\s+)?([\w{}.]+)?", p)
            labels.append((m.group(1).lower() + " " + (m.group(2) or "")).strip() if m else "statement")
        units = list(zip(labels, parts))
    elif language in ("python", "airflow_dag"):
        pos = [m.start() for m in _PY_DEF.finditer(text)]
        if not pos or pos[0] > 0:
            pos = [0] + pos
        units = []
        for a, b in zip(pos, pos[1:] + [len(text)]):
            seg = text[a:b]
            m = re.match(r"(?:async\s+)?(def|class)\s+(\w+)", seg)
            units.append((f"{m.group(1)} {m.group(2)}" if m else "module header", seg))
    elif language in ("yaml", "yml", "json", "config"):
        pos = [m.start() for m in _YAML_TOP.finditer(text)] or [0]
        units = [(text[a:b].split(":", 1)[0].strip()[:60], text[a:b]) for a, b in zip(pos, pos[1:] + [len(text)])]
    elif language in ("markdown", "md", "text"):
        pos = [m.start() for m in _MD_HEAD.finditer(text)] or [0]
        units = [(text[a:b].splitlines()[0].strip("# ")[:60] if text[a:b].strip() else "", text[a:b]) for a, b in zip(pos, pos[1:] + [len(text)])]
    else:
        units = [("file", text)]
    out: List[Tuple[str, str]] = []
    buf_label, buf = "", ""
    for label, seg in units:
        if not seg.strip():
            continue
        if len(buf) + len(seg) < MIN_CHUNK * 3 and buf:
            buf += seg; continue
        if buf:
            out.append((buf_label, buf))
        buf_label, buf = label, seg
    if buf:
        out.append((buf_label, buf))
    final = []
    for label, seg in out:
        if len(seg) <= MAX_CHUNK:
            final.append((label, seg))
        else:
            for i in range(0, len(seg), MAX_CHUNK - 200):      # overlap 200 chars so a split statement is still findable
                final.append((f"{label} (part {i // (MAX_CHUNK - 200) + 1})", seg[i:i + MAX_CHUNK]))
    return final


def chunks(structure: dict, derived: dict, read, system: str, max_chunks_per_file: int = 40) -> List[dict]:
    reg = structure.get("registration", {})
    folders = structure.get("folders", {})
    d_f = (derived.get("repo", {}).get("folders") or {})
    out = []
    for rel, f in structure.get("file_list", {}).items():
        if f["language"] not in ("sql", "python", "airflow_dag", "yaml", "yml", "json", "r", "shell", "markdown", "md", "text"):
            continue
        text = read(rel)
        if not text or len(text) < MIN_CHUNK:
            continue
        folder = rel.rsplit("/", 1)[0] if "/" in rel else ""
        purpose = (d_f.get(folder) or {}).get("purpose") or folders.get(folder, {}).get("purpose_hint", "")
        tables = ", ".join(structure.get("script_tables", {}).get(rel, [])[:6])
        header = (f"[{system}] file {rel} | folder {folder or '/'} ({purpose[:100]}) | registration: {reg.get(folder, {}).get('rule', '')[:90]}"
                  + (f" | builds: {tables}" if tables else ""))
        for i, (label, seg) in enumerate(_split(text, f["language"])[:max_chunks_per_file]):
            out.append({"kind": "chunk", "ref": f"{rel}#{i}", "title": f"{Path(rel).name}: {label}", "file": rel, "language": f["language"],
                        "text": header + "\n" + seg.strip()})
    return out


def graph(structure: dict, tables: dict, derived: dict, skills: dict) -> dict:
    nodes: Dict[str, dict] = {}
    edges: List[dict] = []

    def node(kind, key, **attrs):
        k = f"{kind}:{key}"
        if k not in nodes:
            nodes[k] = {"id": k, "kind": kind, "name": key, **attrs}
        return k

    def edge(a, rel, b, **attrs):
        edges.append({"from": a, "rel": rel, "to": b, **attrs})

    folders = structure.get("folders", {})
    for f, v in folders.items():
        node("folder", f or "/", files=v["files"], registration=v.get("registration", "")[:120])
    for rel, f in structure.get("file_list", {}).items():
        s = node("script", rel, language=f["language"], lines=f["lines"])
        edge(s, "in_folder", node("folder", (rel.rsplit("/", 1)[0] if "/" in rel else "/")))
    for t, lin in structure.get("tables", {}).items():
        tn = node("table", t, described=t in tables)
        for w in lin.get("written_by", []):
            edge(node("script", w), "builds", tn)
        for r in lin.get("read_by", []):
            edge(node("script", r), "reads", tn)
    for t, info in tables.items():
        tn = node("table", t, described=bool(info.get("described")))
        for c in info.get("columns", [])[:200]:
            edge(tn, "has_column", node("column", f"{t}.{c.get('name')}", type=c.get("type", "")))
    for d in structure.get("dags", []):
        dn = node("dag", d["path"], dag_ids=d.get("dag_ids", []), tasks=len(d.get("task_ids", [])))
        for fr in d.get("folders_referenced", []):
            fr = fr.strip("/")
            for f in folders:
                if f == fr or f.startswith(fr + "/"):
                    edge(node("folder", f), "registered_by", dn, via=", ".join(d.get("dynamic_registration", [])) or "static")
        for sref in d.get("sql_files_referenced", []):
            for rel in structure.get("file_list", {}):
                if rel.endswith(sref.strip("/")):
                    edge(node("script", rel), "registered_by", dn, via="static")
        for v in d.get("variables", []):
            edge(dn, "uses_variable", node("param", v))
    for p, v in structure.get("params", {}).items():
        pn = node("param", p, uses=v["uses"])
        for rel in v.get("examples", []):
            edge(node("script", rel), "uses_param", pn)
    for c in structure.get("companion_patterns", []):
        a = node("folder", c["folder"] or "/")
        b = node("folder", c["companion_folder_or_file"]) if c["relation"] == "sibling" else node("script", c["companion_folder_or_file"])
        edge(a, "companion_of" if c["relation"] == "sibling" else "listed_in", b, rule=c["rule"][:160], stem_rule=c.get("stem_rule", ""))
    for name, doc in skills.items():
        node("document", name, kind_of_doc=doc.get("kind"), chars=doc.get("chars", 0))
    kn = derived.get("knowledge", {})
    for dfn in kn.get("definitions", []) or []:
        tn = node("term", str(dfn.get("term", ""))[:80], definition=str(dfn.get("definition", ""))[:300])
        if dfn.get("source"):
            edge(tn, "defined_in", node("document", str(dfn["source"])))
    for b in derived.get("bridge", {}).get("bridge", []) or []:
        tn = node("term", str(b.get("term", ""))[:80], synonyms=b.get("synonyms", []))
        for t in b.get("tables", []) or []:
            edge(tn, "refers_to", node("table", str(t).lower()))
        for s in b.get("scripts_or_folders", []) or []:
            edge(tn, "refers_to", node("folder" if s in folders else "script", s))
    deg = Counter()
    for e in edges:
        deg[e["from"]] += 1; deg[e["to"]] += 1
    for k, n in nodes.items():
        n["degree"] = deg.get(k, 0)
    return {"nodes": list(nodes.values()), "edges": edges, "counts": {"nodes": len(nodes), "edges": len(edges), "by_kind": dict(Counter(n["kind"] for n in nodes.values()))}}


def cards(structure: dict, tables: dict, derived: dict, system: str) -> Dict[str, str]:
    """{relative path under cards/: markdown} - prompt-ready context."""
    out = {}
    d_repo, d_data = derived.get("repo", {}), derived.get("data", {}).get("tables", {})
    reg = structure.get("registration", {})
    comp = defaultdict(list)
    for c in structure.get("companion_patterns", []):
        comp[c["folder"]].append(c)
    for f, v in structure.get("folders", {}).items():
        d = (d_repo.get("folders") or {}).get(f, {})
        L = [f"# Folder `{f or '/'}` ({system})", "", f"**Purpose:** {d.get('purpose') or v.get('purpose_hint') or 'n/a'}",
             f"**Files:** {v['files']} {v.get('languages')}", f"**Registration of a new script:** {v.get('registration') or 'n/a'}"]
        if d.get("how_to_add"):
            L.append(f"**How to add:** {d['how_to_add']}")
        if d.get("watch_out"):
            L.append(f"**Watch out:** {d['watch_out']}")
        if comp.get(f):
            L.append("**Companion files (must change together):**")
            L += [f"- {c['rule']} (e.g. `{c['example']['file']}` <-> `{c['example']['companion']}`)" for c in comp[f]]
        if v.get("tables_built_here"):
            L.append("**Tables built here:** " + ", ".join(f"`{t}`" for t in v["tables_built_here"][:20]))
        if v.get("typical_files"):
            L.append("**Typical files:** " + ", ".join(f"`{t}`" for t in v["typical_files"]))
        if v.get("header_samples"):
            L.append("**Header comments seen:** " + " | ".join(v["header_samples"][:3]))
        out[f"folder/{(f or 'root').replace('/', '__')}.md"] = "\n".join(L) + "\n"
    for t, info in tables.items():
        sem = d_data.get(t, {})
        lin = structure.get("tables", {}).get(t, {})
        L = [f"# Table `{t}` ({system})", "", f"**Purpose:** {sem.get('purpose') or info.get('description') or 'n/a'}",
             f"**Grain:** {sem.get('grain', 'n/a')}  **Key columns:** {', '.join(sem.get('key_columns', []) or []) or 'n/a'}",
             f"**Built by:** {', '.join(f'`{x}`' for x in lin.get('written_by', [])[:8]) or 'not in this repo'}",
             f"**Read by ({len(lin.get('read_by', []))}):** {', '.join(f'`{x}`' for x in lin.get('read_by', [])[:12])}", "", "| column | type | note |", "|---|---|---|"]
        notes = sem.get("column_notes", {}) or {}
        for c in info.get("columns", [])[:150]:
            L.append(f"| {c.get('name')} | {c.get('type', '')} | {notes.get(c.get('name'), c.get('comment', '') or '')} |")
        if not info.get("columns"):
            L.append("| (not described - no Greenplum access at build time) | | |")
        out[f"table/{t.replace('.', '__')}.md"] = "\n".join(L) + "\n"
    for d in structure.get("dags", []):
        L = [f"# DAG `{d['path']}` ({system})", "", f"**dag ids:** {', '.join(d.get('dag_ids', []))}", f"**tasks:** {len(d.get('task_ids', []))} - {', '.join(d.get('task_ids', [])[:30])}",
             f"**task groups:** {', '.join(d.get('task_groups', [])[:20])}", f"**registration:** {'dynamic (' + ', '.join(d['dynamic_registration']) + ') over ' + ', '.join(d.get('folders_referenced', [])) if d.get('dynamic_registration') else 'static task list'}",
             f"**variables:** {', '.join(d.get('variables', []))}", "**dependencies:** " + " ; ".join(d.get("dependency_chains", [])[:10])]
        out[f"dag/{Path(d['path']).stem}.md"] = "\n".join(L) + "\n"
    for h in d_repo.get("how_to", []) or []:
        out[f"howto/{re.sub(r'[^a-z0-9]+', '_', str(h.get('task', '')).lower())[:60]}.md"] = f"# How to: {h.get('task')}\n\n" + "\n".join(f"{i + 1}. {s}" for i, s in enumerate(h.get("steps", []))) + "\n"
    if d_repo.get("system_summary"):
        out["system.md"] = f"# {system.upper()} - system overview\n\n{d_repo['system_summary']}\n"
    return out


def exemplars(structure: dict, read) -> Dict[str, dict]:
    """One canonical file per folder: the file whose name tokens are most shared with its siblings (the 'most typical'),
    smallest among ties - the few-shot example a coder copies the shape of."""
    by_folder = defaultdict(list)
    for rel, f in structure.get("file_list", {}).items():
        if f["language"] in ("sql", "python", "airflow_dag", "yaml", "r"):
            by_folder[rel.rsplit("/", 1)[0] if "/" in rel else ""].append((rel, f))
    out = {}
    for folder, files in by_folder.items():
        if len(files) < 2:
            continue
        tok = Counter(t for rel, _ in files for t in set(Path(rel).stem.split("_")))
        best = max(files, key=lambda rf: (sum(tok[t] for t in set(Path(rf[0]).stem.split("_"))), -rf[1]["chars"]))
        rel = best[0]
        out[folder] = {"file": rel, "language": best[1]["language"], "lines": best[1]["lines"], "text": read(rel)[:12000]}
    return out


def synonyms(structure: dict, derived: dict, tables: dict) -> Dict[str, List[str]]:
    """business / spoken word -> technical tokens, used for query expansion at search time."""
    syn: Dict[str, set] = defaultdict(set)
    for b in derived.get("bridge", {}).get("bridge", []) or []:
        term = str(b.get("term", "")).lower().strip()
        if not term:
            continue
        for s in b.get("synonyms", []) or []:
            syn[str(s).lower()].add(term)
        for t in (b.get("tables", []) or []) + (b.get("columns", []) or []) + (b.get("scripts_or_folders", []) or []):
            syn[term].add(str(t).lower().rsplit("/", 1)[-1])
    for g in derived.get("repo", {}).get("glossary", []) or []:
        if g.get("term") and g.get("meaning"):
            for w in re.findall(r"[a-z][a-z0-9_]{3,}", str(g["meaning"]).lower())[:6]:
                syn[w].add(str(g["term"]).lower())
    # table name tokens: 'household' -> household_profile_curr_ikg etc. (top tables only, by degree)
    tok_tables: Dict[str, Counter] = defaultdict(Counter)
    generic = {"table", "tables", "data", "curr", "hist", "history", "temp", "tmp", "prev", "list", "detail", "details", "date", "flag", "flags",
               "type", "name", "load", "master", "auto", "refresh", "current", "daily", "weekly", "monthly", "final", "stage", "staging"}
    for t in list(tables) + list(structure.get("tables", {}))[:800]:
        name = t.split(".")[-1].strip("{}")
        for w in set(name.split("_")):
            if len(w) > 4 and w not in generic and not w.isdigit():
                tok_tables[w][name] += 1
    for w, c in tok_tables.items():
        if 1 < len(c) <= 6:
            syn[w].update(c)
    return {k: sorted(v)[:8] for k, v in syn.items() if v and k not in v}


def expand_query(q: str, syn: Dict[str, List[str]], max_add: int = 6) -> str:
    words = re.findall(r"[a-z0-9_]+", q.lower())
    add = []
    for w in words:
        for s in syn.get(w, []):
            if s not in words and s not in add:
                add.append(s)
    return q + (" " + " ".join(add[:max_add]) if add else "")


def write_all(out_dir: Path, structure, tables, derived, skills, read, system) -> dict:
    out_dir = Path(out_dir)
    g = graph(structure, tables, derived, skills)
    (out_dir / "graph.json").write_text(json.dumps(g, ensure_ascii=False), encoding="utf-8")
    cs = cards(structure, tables, derived, system)
    for rel, md in cs.items():
        p = out_dir / "cards" / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(md, encoding="utf-8")
    ex = exemplars(structure, read)
    (out_dir / "exemplars.json").write_text(json.dumps(ex, ensure_ascii=False), encoding="utf-8")
    syn = synonyms(structure, derived, tables)
    (out_dir / "synonyms.json").write_text(json.dumps(syn, ensure_ascii=False, indent=0), encoding="utf-8")
    return {"graph": g["counts"], "cards": len(cs), "exemplars": len(ex), "synonyms": len(syn)}
