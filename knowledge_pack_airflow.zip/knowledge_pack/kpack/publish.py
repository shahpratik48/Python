"""Deliver the finished packs to the Agile Dev Assist host.

After a build, output/<system>/<system>_pack.zip is uploaded to the folder the Dev Assist web app reads its packs from
(its config: knowledge_packs.dir, default `packs/`). Two transports:

  sftp   paramiko over SSH - the usual case: the scheduler and the web host are different machines
  copy   a plain file copy - when the web host's packs folder is mounted on the scheduler (NFS / shared disk)

Both are ATOMIC for the reader: the zip is written as `<name>.zip.part` and renamed to `<name>.zip` only after the size
matches, so the web app (which reloads a pack by its content hash) never sees a half-written file. A small
`<system>_pack.manifest.json` (version, sha256, size, built_at, counts) is written next to it for the hosting team's checks.

Credentials (never in this file, the config, XCom or the logs):
  inside Airflow   Connection `airflow.connections.sftp_conn_id` (type SSH/SFTP): host, port, login, password or extra.key_file;
                   extra.host_key = the server's public host key (recommended) - config host / port / username are the fallback
  notebook / CLI   env KPACK_SFTP_PASSWORD, or KPACK_SFTP_PRIVATE_KEY_PATH (file) / KPACK_SFTP_PRIVATE_KEY (PEM text)
"""
from __future__ import annotations

import hashlib
import io
import json
import logging
import os
import shutil
import time
from pathlib import Path
from typing import Dict, List, Optional

log = logging.getLogger("kpack.publish")


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _manifest_for(zip_path: Path, result: dict) -> dict:
    m = result.get("manifest") or {}
    return {"system": m.get("system") or result.get("system"), "version": m.get("version"), "built_at": m.get("built_at"),
            "file": zip_path.name, "bytes": zip_path.stat().st_size, "sha256": _sha256(zip_path),
            "counts": m.get("counts"), "health": (result.get("health") or {}).get("status"),
            "published_at": time.strftime("%Y-%m-%dT%H:%M:%S%z")}


# ----------------------------------------------------------------------------- credentials
def sftp_credentials(cfg) -> dict:
    """host / port / username / password / pkey / host_key - from the Airflow Connection when inside Airflow, else from the
    config block + environment variables. Values stay in memory."""
    p = cfg.get("publish") or {}
    creds = {"host": str(p.get("host") or ""), "port": int(p.get("port") or 22), "username": str(p.get("username") or ""),
             "password": "", "pkey": None, "host_key": "", "source": "config"}
    from .airflow_runtime import is_running_in_airflow
    conn_id = str(((cfg.get("airflow") or {}).get("connections") or {}).get("sftp_conn_id") or "")
    if is_running_in_airflow() and conn_id:
        try:
            from airflow.hooks.base import BaseHook  # type: ignore
            c = BaseHook.get_connection(conn_id)
            extra = c.extra_dejson if hasattr(c, "extra_dejson") else {}
            creds.update({"host": c.host or creds["host"], "port": int(c.port) if c.port else creds["port"],
                          "username": c.login or creds["username"], "password": c.password or "", "source": f"Connection {conn_id}"})
            key_file = extra.get("key_file") or extra.get("private_key_file") or ""
            if key_file:
                creds["pkey"] = _load_pkey(path=key_file, passphrase=extra.get("private_key_passphrase") or None)
            elif extra.get("private_key"):
                creds["pkey"] = _load_pkey(text=extra["private_key"], passphrase=extra.get("private_key_passphrase") or None)
            creds["host_key"] = str(extra.get("host_key") or "")
        except Exception as e:  # noqa: BLE001
            log.warning("could not read Airflow connection %s: %s", conn_id, type(e).__name__)
    if not creds["password"] and creds["pkey"] is None:
        sec = cfg.get("secrets") or {}
        pw = os.environ.get(str(sec.get("sftp_password") or "KPACK_SFTP_PASSWORD"), "")
        key_path = os.environ.get(str(sec.get("sftp_private_key_path") or "KPACK_SFTP_PRIVATE_KEY_PATH"), "")
        key_text = os.environ.get(str(sec.get("sftp_private_key") or "KPACK_SFTP_PRIVATE_KEY"), "")
        if key_path:
            creds["pkey"] = _load_pkey(path=key_path); creds["source"] = "env (private key file)"
        elif key_text:
            creds["pkey"] = _load_pkey(text=key_text); creds["source"] = "env (private key)"
        elif pw:
            creds["password"] = pw; creds["source"] = "env (password)"
    if not creds["host_key"] and p.get("host_key"):
        creds["host_key"] = str(p["host_key"])
    return creds


def _load_pkey(path: str = "", text: str = "", passphrase: Optional[str] = None):
    import paramiko
    src = open(path, "r", encoding="utf-8") if path else io.StringIO(text)
    try:
        for cls in (paramiko.Ed25519Key, paramiko.RSAKey, paramiko.ECDSAKey):
            try:
                src.seek(0)
                return cls.from_private_key(src, password=passphrase)
            except Exception:  # noqa: BLE001
                continue
    finally:
        src.close()
    raise ValueError("private key format not recognised (ed25519 / rsa / ecdsa expected)")


# ----------------------------------------------------------------------------- transports
class _Sftp:
    def __init__(self, cfg, creds: dict):
        import paramiko
        p = cfg.get("publish") or {}
        if not creds["host"] or not creds["username"]:
            raise ValueError("publish.host and publish.username (or the Airflow SFTP connection) are required")
        if not creds["password"] and creds["pkey"] is None:
            raise ValueError("no SFTP credential: password or private key (Airflow Connection, or KPACK_SFTP_PASSWORD / KPACK_SFTP_PRIVATE_KEY_PATH)")
        self.client = paramiko.SSHClient()
        policy = str(p.get("host_key_policy") or "reject").lower()
        known = str(p.get("known_hosts") or "")
        if creds.get("host_key"):                                     # pinned host key ("ssh-ed25519 AAAA..."): the safest option, no file needed
            from paramiko.hostkeys import HostKeyEntry
            hostname = creds["host"] if creds["port"] == 22 else f"[{creds['host']}]:{creds['port']}"
            entry = HostKeyEntry.from_line(f"{hostname} {creds['host_key'].strip()}")
            if entry is None or entry.key is None:
                raise ValueError("publish host_key is not a valid 'type base64' public key line")
            self.client.get_host_keys().add(hostname, entry.key.get_name(), entry.key)
        elif known:
            self.client.load_host_keys(known)
        if policy == "auto_add":
            self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        else:
            self.client.set_missing_host_key_policy(paramiko.RejectPolicy())
        self.client.connect(creds["host"], port=creds["port"], username=creds["username"], password=creds["password"] or None,
                            pkey=creds["pkey"], timeout=int(p.get("timeout_seconds", 120)), banner_timeout=60, auth_timeout=60,
                            allow_agent=False, look_for_keys=False)
        self.sftp = self.client.open_sftp()
        self.sftp.get_channel().settimeout(int(p.get("timeout_seconds", 120)))

    def ensure_dir(self, remote: str):
        parts, cur = [x for x in remote.split("/") if x], "/" if remote.startswith("/") else ""
        for x in parts:
            cur = (cur + "/" + x) if cur not in ("", "/") else cur + x
            try:
                self.sftp.stat(cur)
            except IOError:
                self.sftp.mkdir(cur)

    def put_atomic(self, local: Path, remote_dir: str, name: str) -> dict:
        tmp, final = f"{remote_dir}/.{name}.part", f"{remote_dir}/{name}"
        size = local.stat().st_size
        self.sftp.put(str(local), tmp, confirm=True)
        got = self.sftp.stat(tmp).st_size
        if got != size:
            try:
                self.sftp.remove(tmp)
            finally:
                raise IOError(f"size mismatch after upload of {name}: local {size}, remote {got}")
        try:
            self.sftp.remove(final)                                   # some SFTP servers refuse rename over an existing file
        except IOError:
            pass
        self.sftp.posix_rename(tmp, final) if hasattr(self.sftp, "posix_rename") else self.sftp.rename(tmp, final)
        return {"remote": final, "bytes": size}

    def put_text(self, text: str, remote_dir: str, name: str):
        with self.sftp.open(f"{remote_dir}/.{name}.part", "w") as f:
            f.write(text)
        try:
            self.sftp.remove(f"{remote_dir}/{name}")
        except IOError:
            pass
        self.sftp.posix_rename(f"{remote_dir}/.{name}.part", f"{remote_dir}/{name}") if hasattr(self.sftp, "posix_rename") else self.sftp.rename(f"{remote_dir}/.{name}.part", f"{remote_dir}/{name}")

    def close(self):
        try:
            self.sftp.close()
        finally:
            self.client.close()


class _Copy:
    def __init__(self, cfg):
        p = cfg.get("publish") or {}
        self.root = Path(str(p.get("copy_dir") or p.get("remote_dir") or ""))
        if not str(self.root):
            raise ValueError("publish.copy_dir (or remote_dir) is required for transport copy")

    def ensure_dir(self, remote: str):
        Path(remote).mkdir(parents=True, exist_ok=True)

    def put_atomic(self, local: Path, remote_dir: str, name: str) -> dict:
        tmp, final = Path(remote_dir) / f".{name}.part", Path(remote_dir) / name
        shutil.copyfile(local, tmp)
        if tmp.stat().st_size != local.stat().st_size:
            tmp.unlink(missing_ok=True)
            raise IOError(f"size mismatch after copy of {name}")
        tmp.replace(final)
        return {"remote": str(final), "bytes": final.stat().st_size}

    def put_text(self, text: str, remote_dir: str, name: str):
        tmp = Path(remote_dir) / f".{name}.part"
        tmp.write_text(text, encoding="utf-8")
        tmp.replace(Path(remote_dir) / name)

    def close(self):
        pass


# ----------------------------------------------------------------------------- entry point
def publish_packs(cfg, results: List[dict], progress=None) -> List[dict]:
    """Upload every built pack of `results` (the list build_systems / the DAG tasks produce). Returns one record per system:
    {system, published, remote, bytes, sha256, version, reason}. Never raises for one system's failure; the caller decides."""
    say = progress or log.info
    p = cfg.get("publish") or {}
    out = []
    if not p.get("enabled"):
        return [{"system": r.get("system") or (r.get("manifest") or {}).get("system"), "published": False, "reason": "publish.enabled is false"} for r in results]
    transport = str(p.get("transport") or "sftp").lower()
    remote_dir = str(p.get("remote_dir") or "").rstrip("/")
    only_promoted = bool(p.get("only_promoted", True))
    retries = int(p.get("retries", 2))
    todo = []
    for r in results:
        sysname = r.get("system") or (r.get("manifest") or {}).get("system")
        zp = r.get("zip") or (r.get("manifest") or {}).get("zip") or ""
        if r.get("error") or not zp or not Path(zp).is_file():
            out.append({"system": sysname, "published": False, "reason": "no pack built"}); continue
        if only_promoted and not r.get("promoted", True):
            out.append({"system": sysname, "published": False, "reason": "build not promoted (previous good pack kept) - not published"}); continue
        todo.append((sysname, Path(zp), r))
    if not todo:
        return out
    conn, creds = None, None
    last_err = None
    for attempt in range(retries + 1):
        try:
            if transport == "copy":
                conn = _Copy(cfg)
                remote_dir = str(conn.root)
            else:
                creds = creds or sftp_credentials(cfg)
                conn = _Sftp(cfg, creds)
            say(f"publish: connected ({transport}{' ' + creds['host'] if creds else ''}, credentials from {creds['source'] if creds else 'config'}) -> {remote_dir}")
            conn.ensure_dir(remote_dir)
            for sysname, zp, r in todo:
                if any(o.get("system") == sysname and o.get("published") for o in out):
                    continue
                t0 = time.time()
                rec = conn.put_atomic(zp, remote_dir, zp.name)
                man = _manifest_for(zp, r)
                if p.get("manifest", True):
                    conn.put_text(json.dumps(man, indent=1), remote_dir, f"{sysname}_pack.manifest.json")
                out.append({"system": sysname, "published": True, "remote": rec["remote"], "bytes": rec["bytes"], "sha256": man["sha256"],
                            "version": man.get("version"), "seconds": round(time.time() - t0, 1)})
                say(f"publish: {sysname} -> {rec['remote']} ({rec['bytes'] // 1024 // 1024} MB, {round(time.time() - t0, 1)}s)")
            last_err = None
            break
        except Exception as e:  # noqa: BLE001
            last_err = f"{type(e).__name__}: {str(e)[:200]}"
            say(f"publish: attempt {attempt + 1} failed - {last_err}")
            time.sleep(min(30, 5 * (attempt + 1)))
        finally:
            if conn is not None:
                try:
                    conn.close()
                except Exception:  # noqa: BLE001
                    pass
                conn = None
    if last_err:
        for sysname, _, _ in todo:
            if not any(o.get("system") == sysname and o.get("published") for o in out):
                out.append({"system": sysname, "published": False, "reason": last_err})
    return out


def check_connection(cfg) -> dict:
    """`kpack publish --check`: connect, list the remote folder, write + delete a probe file. Nothing else."""
    p = cfg.get("publish") or {}
    transport = str(p.get("transport") or "sftp").lower()
    remote_dir = str(p.get("remote_dir") or "").rstrip("/")
    try:
        if transport == "copy":
            c = _Copy(cfg); remote_dir = str(c.root)
        else:
            c = _Sftp(cfg, sftp_credentials(cfg))
        c.ensure_dir(remote_dir)
        c.put_text("probe", remote_dir, ".kpack_probe")
        if transport == "copy":
            (Path(remote_dir) / ".kpack_probe").unlink(missing_ok=True)
            listing = sorted(x.name for x in Path(remote_dir).iterdir())
        else:
            c.sftp.remove(f"{remote_dir}/.kpack_probe")
            listing = sorted(c.sftp.listdir(remote_dir))
        c.close()
        return {"ok": True, "transport": transport, "remote_dir": remote_dir, "files": listing[:50]}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "transport": transport, "remote_dir": remote_dir, "error": f"{type(e).__name__}: {str(e)[:300]}"}
