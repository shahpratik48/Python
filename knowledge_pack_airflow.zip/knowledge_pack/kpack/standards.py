"""`<system>_standards.md` TEMPLATE generator - the starting point for the team's own standards page (#5).

Everything the pack could PROVE from the repository is pre-filled (folder purposes, registration points, companion rules,
naming suffixes, DAG parameters, conventions the model extracted from the skills documents) with the evidence next to it,
and every section ends with a short TODO list of what only the team can answer. The team edits the file, drops it in
`skills/<system>/` (it becomes an input of the next pack build) and the same file is a `knowledge` input of Agile Dev Assist.

    python app_kpack.py standards-template --system ikg            # -> skills/ikg/ikg_standards_TEMPLATE.md
"""
from __future__ import annotations

import re
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from .pack import Pack


def _md_escape(s: str) -> str:
    return str(s or "").replace("|", "\\|").replace("\n", " ").strip()


def _top(items: List[str], n: int) -> List[str]:
    return [k for k, _ in Counter(items).most_common(n)]


class BuildView:
    """What build_template needs, taken from the in-memory build (structure / derived / manifest) instead of a Pack."""
    def __init__(self, structure: dict, derived: dict, manifest: dict):
        self.structure, self.derived, self.manifest = structure or {}, derived or {}, manifest or {}
        self.version = self.manifest.get("version", "")

    def conventions(self): return (self.derived.get("knowledge") or {}).get("conventions", []) or []
    def rules(self): return (self.derived.get("knowledge") or {}).get("rules", []) or []
    def definitions(self): return (self.derived.get("knowledge") or {}).get("definitions", []) or []


def drift(structure: dict, previous_structure: dict) -> dict:
    """Structural changes between two packs that may make a human-written statement stale: folders, registration
    points, companion rules, DAG files, parameters. Empty dict = nothing changed."""
    if not previous_structure:
        return {}
    out = {}
    f0, f1 = set(previous_structure.get("folders") or {}), set(structure.get("folders") or {})
    if f1 - f0: out["new_folders"] = sorted(f1 - f0)
    if f0 - f1: out["removed_folders"] = sorted(f0 - f1)

    def reg_sig(reg):
        return {k: tuple(sorted(x["path"] for x in (v.get("static") or []) + (v.get("dynamic") or []))) for k, v in (reg or {}).items()}
    r0, r1 = reg_sig(previous_structure.get("registration")), reg_sig(structure.get("registration"))
    ch = sorted(k for k in set(r0) & set(r1) if r0[k] != r1[k])
    if ch: out["registration_changed"] = ch

    def comp_sig(cp):
        return {(c["folder"], c["relation"], c["companion_folder_or_file"]) for c in (cp or [])}
    c0, c1 = comp_sig(previous_structure.get("companion_patterns")), comp_sig(structure.get("companion_patterns"))
    if c1 - c0: out["new_companion_rules"] = sorted(" -> ".join(x) for x in c1 - c0)
    if c0 - c1: out["gone_companion_rules"] = sorted(" -> ".join(x) for x in c0 - c1)
    d0, d1 = {d.get("file") or d.get("path") for d in previous_structure.get("dags") or []}, {d.get("file") or d.get("path") for d in structure.get("dags") or []}
    if d1 - d0: out["new_dags"] = sorted(x for x in d1 - d0 if x)
    if d0 - d1: out["removed_dags"] = sorted(x for x in d0 - d1 if x)
    p0, p1 = set(previous_structure.get("params") or {}), set(structure.get("params") or {})
    if p1 - p0: out["new_params"] = sorted(p1 - p0)
    if p0 - p1: out["removed_params"] = sorted(p0 - p1)
    return out


def build_generated(view, system: str, policy_text: str = "", changes: Optional[dict] = None) -> str:
    """The nightly `standards.md` of the pack: the fact sections of the template (always fresh, no TODO lines) + the
    team's hand-written policy file verbatim + what changed since the previous build (so the team knows when a policy
    statement may be stale). 100 % automatic for the facts; the policy part changes only when the team edits it."""
    body = build_template(view, system)
    lines = []
    for ln in body.splitlines():
        if "**TODO (team)**" in ln and ln.lstrip().startswith("- "):
            continue                                    # the questions live in the template, not in the nightly document
        lines.append(ln.replace(" | **TODO (team)**", " | ").replace("**TODO (team)** confirm", "unconfirmed").replace("**TODO (team)**", ""))
    body = "\n".join(lines)
    body = re.sub(r"^> TEMPLATE generated[^\n]*\n", f"> Generated automatically from the repository on every pack build (pack `{view.version}`). "
                  "Facts below are re-derived nightly; the team policy section is the hand-written file `skills/" + system + "/" + system + "_policy.md` "
                  "and is included verbatim.\n", body, flags=re.M)
    body = body.replace("# " + system.upper() + " development standards", "# " + system.upper() + " development standards (generated)", 1)
    if changes:
        L = ["", "## 0. Changed since the previous build - review the team policy for these", ""]
        for k, v in changes.items():
            L.append(f"- **{k.replace('_', ' ')}**: " + ", ".join(f"`{x}`" for x in v[:25]) + (f" (+{len(v) - 25} more)" if len(v) > 25 else ""))
        body = body.replace("\n## 1. Purpose and scope", "\n".join(L) + "\n\n## 1. Purpose and scope", 1)
    if policy_text.strip():
        body += "\n\n---\n\n# Team policy (hand-written, `" + system + "_policy.md`)\n\n" + policy_text.strip() + "\n"
    else:
        body += ("\n\n---\n\n# Team policy\n\n_No `skills/" + system + "/" + system + "_policy.md` yet. Run `python app_kpack.py standards-template --system "
                 + system + "`, answer the TODO lines, save the answers as that file; they are appended here on every build._\n")
    return body


GENERATED_MARK = "<!-- GENERATED by the Knowledge Pack builder - do not edit; write your decisions in {system}_policy.md -->"


def build_facts_doc(structure: dict, system: str, tables: Optional[dict] = None, version: str = "") -> str:
    """`skills/<sys>/<sys>_standards.md` - 100 % automatic, written at the START of every build (before the skills
    documents are read, so the same build consumes it): folder map with registration points, companion rules, naming,
    parameters / Variables, validation folders - everything the repository proves. No model, no TODO lines, no
    policy. The team's decisions live next to it in `<sys>_policy.md` (hand-written, optional)."""
    view = BuildView(structure, {}, {"version": version, "repo": {"name": structure.get("repo", "")}})
    body = build_template(view, system)
    out = []
    skip_section = False
    for ln in body.splitlines():
        if ln.startswith("## "):
            # sections that only make sense with a model layer or a human: 6 conventions, 8 rules, 9 glossary, 10 DoD
            skip_section = any(ln.startswith(f"## {n}.") for n in (6, 8, 9, 10))
        if skip_section:
            continue
        if ln.lstrip().startswith("- **TODO (team)**"):
            continue                                                            # a pure question: not a fact
        ln = re.sub(r"\s*\*\*TODO \(team\)\*\*:?.*$", "", ln) if "**TODO (team)**" in ln and not ln.startswith("|") else ln
        ln = re.sub(r"\s*\*\*Confirm\*\*:?.*$", "", ln)                        # "Confirm: is the sibling mandatory?" is the policy file's job
        ln = ln.replace(" | **TODO (team)**", " | ").replace(" - **TODO (team)** confirm", " (unconfirmed)").replace("(**TODO team**)", "").replace("**TODO (team)**", "")
        out.append(ln.rstrip())
    body = "\n".join(out)
    body = re.sub(r"^> TEMPLATE generated[^\n]*\n", "", body, flags=re.M)
    naming = naming_facts(structure)
    if naming:
        body = body.replace("## 4. Naming\n", "## 4. Naming\n\n" + "\n".join(naming) + "\n", 1)
    body = re.sub(r"\n{3,}", "\n\n", body)
    head = (f"# {system.upper()} standards - repository facts (generated)\n\n{GENERATED_MARK.format(system=system)}\n\n"
            "_Regenerated from the repository on every pack build (the text changes only when the repository facts change, so "
            "an unchanged repository gives a byte-identical file). These are the "
            "conventions the code itself proves: where each kind of file lives, how a new file is registered, which files change "
            f"together, naming, parameters. Team decisions (what is mandatory, frozen folders, review rules, definition of done) "
            f"belong in `{system}_policy.md` in this folder._\n")
    body = re.sub(r"\A# [^\n]*\n", head, body, count=1)
    return body


def naming_facts(structure: dict, min_files: int = 5, share: float = 0.7) -> List[str]:
    """Per folder: the file-name prefix / suffix that >= 70 % of its files share (e.g. 46/46 files in ikg_create_profiles end
    with `_profile_curr_ikg.sql`) - the naming rule the repository itself follows."""
    files = structure.get("file_list") or []
    if not files:
        return []
    by_folder = {}
    for f in files:
        folder = f.rsplit("/", 1)[0] if "/" in f else ""
        by_folder.setdefault(folder, []).append(f.rsplit("/", 1)[-1])
    out = []
    for folder, names in sorted(by_folder.items(), key=lambda kv: -len(kv[1])):
        if len(names) < min_files:
            continue
        stems = [re.sub(r"\.[^.]+$", "", n) for n in names]
        exts = Counter(n.rsplit(".", 1)[-1] for n in names if "." in n)
        ext = exts.most_common(1)[0][0] if exts else ""
        best_suf, best_pre = "", ""
        for k in (3, 2, 1):                                   # longest common suffix / prefix of >= share of the stems, by `_` tokens
            suf = Counter("_".join(st.split("_")[-k:]) for st in stems if len(st.split("_")) > k)
            if suf and suf.most_common(1)[0][1] >= share * len(stems):
                best_suf = suf.most_common(1)[0][0]; break
        for k in (2, 1):
            pre = Counter("_".join(st.split("_")[:k]) for st in stems if len(st.split("_")) > k)
            if pre and pre.most_common(1)[0][1] >= share * len(stems):
                best_pre = pre.most_common(1)[0][0]; break
        if best_suf or best_pre:
            n_suf = sum(1 for st in stems if best_suf and st.endswith("_" + best_suf))
            n_pre = sum(1 for st in stems if best_pre and st.startswith(best_pre + "_"))
            parts = []
            if best_suf: parts.append(f"{n_suf}/{len(stems)} end with `_{best_suf}.{ext}`")
            if best_pre: parts.append(f"{n_pre}/{len(stems)} start with `{best_pre}_`")
            out.append(f"- `{folder or '.'}`: " + ", ".join(parts))
    return out[:40]


def write_facts_doc(cfg, system: str, structure: dict, version: str = "", say=print) -> Path:
    """Writes the generated standards file into skills/<sys>/ (fallback: data/generated/<sys>/ when that folder is not
    writable, e.g. a read-only deployment) and returns the path; the skills stage reads it either way."""
    root = Path(cfg.get("_root", "."))
    sc = (cfg.get("systems") or {}).get(system) or {}
    text = build_facts_doc(structure, system, version=version)
    folder = Path(sc.get("skills_folder") or f"skills/{system}")
    folder = folder if folder.is_absolute() else root / folder
    for dest in (folder / f"{system}_standards.md", root / "data" / "generated" / system / f"{system}_standards.md"):
        try:
            dest.parent.mkdir(parents=True, exist_ok=True)
            if dest.exists() and "GENERATED by the Knowledge Pack builder" not in dest.read_text(encoding="utf-8", errors="replace")[:600]:
                alt = dest.with_name(f"{system}_standards_generated.md")   # a hand-written file of that name is never overwritten
                say(f"{dest.name} exists and is hand-written - generated file goes to {alt.name}")
                dest = alt
            if dest.exists() and dest.read_text(encoding="utf-8", errors="replace") == text:
                return dest                                                 # unchanged: keep mtime / hash stable
            dest.write_text(text, encoding="utf-8")
            return dest
        except OSError as e:  # noqa: PERF203
            say(f"cannot write {dest}: {e} - trying the fallback location")
    raise RuntimeError("generated standards file could not be written")


def build_template(pack, system: str) -> str:
    st = pack.structure
    folders = st.get("folders", {}) or {}
    repo_layer = (pack.derived.get("repo") or {})
    model_folders = repo_layer.get("folders") or {}
    reg = st.get("registration", {}) or {}
    comp = st.get("companion_patterns", []) or []
    params = st.get("params", {}) or {}
    dags = st.get("dags", []) or []
    conventions = pack.conventions()
    rules = pack.rules()
    definitions = pack.definitions()
    sysu = system.upper()
    L: List[str] = []
    w = L.append

    w(f"# {sysu} development standards")
    w("")
    w(f"> TEMPLATE generated from knowledge pack `{pack.version}` on {datetime.now():%Y-%m-%d}. Lines marked **TODO (team)** need a human answer; "
      "everything else was read from the repository and only needs a yes / correction. Delete this note when done, save as "
      f"`skills/{system}/{system}_standards.md` (knowledge pack input) - the same file is the `knowledge` input of Agile Dev Assist.")
    w("")
    w("## 1. Purpose and scope")
    w("")
    w(f"- System: **{sysu}** - repository `{st.get('repo') or pack.manifest.get('repo', {}).get('name', '')}`, {st.get('files', 0)} files, "
      f"languages {', '.join(f'{k} ({v})' for k, v in sorted((st.get('languages') or {}).items(), key=lambda x: -x[1])[:5])}.")
    summary = repo_layer.get("system_summary") or ""
    if summary:
        w(f"- What the system does (model summary - confirm): {summary}")
    w("- **TODO (team)**: one paragraph - what the system delivers, to whom, how often (schedule / SLA), and which environments exist (dev / uat / prod).")
    w("")

    w("## 2. Where things live (folder map)")
    w("")
    w("| folder | files | purpose | typical file | how a new file gets registered |")
    w("|---|---|---|---|---|")
    main = sorted(folders.items(), key=lambda kv: -int(kv[1].get("files", 0) or 0))[:40]
    for f, v in main:
        purpose = (model_folders.get(f) or {}).get("purpose") or v.get("purpose_hint") or ""
        r = reg.get(f) or {}
        how = ""
        if r.get("dynamic"):
            how = f"automatic - {r['dynamic'][0]['path'].rsplit('/', 1)[-1]} walks the folder"
        elif r.get("static"):
            how = f"add an entry in {r['static'][0]['path'].rsplit('/', 1)[-1]} ({r['static'][0].get('count', '?')} entries)"
        elif r.get("candidates"):
            how = f"probably {r['candidates'][0]['path'].rsplit('/', 1)[-1]} - **TODO (team)** confirm"
        typical = (v.get("typical_files") or [""])[0].rsplit("/", 1)[-1]
        w(f"| `{f}` | {v.get('files', 0)} | {_md_escape(purpose)[:140] or '**TODO (team)**'} | `{typical}` | {_md_escape(how) or '**TODO (team)**'} |")
    w("")
    w("- **TODO (team)**: folders that must NOT receive new files (frozen / deprecated), and the folder for a brand-new kind of job.")
    w("")

    w("## 3. Files that change together (companion rules)")
    w("")
    if comp:
        for c in comp:
            ex = c.get("example") or {}
            if c.get("relation") == "sibling":
                w(f"- A script in `{c['folder']}` has its sibling in `{c['companion_folder_or_file']}` (name rule: {c.get('stem_rule') or 'same name'}; "
                  f"{c.get('occurrences')} existing pairs, e.g. `{ex.get('file', '').rsplit('/', 1)[-1]}` <-> `{ex.get('companion', '').rsplit('/', 1)[-1]}`). "
                  "**Confirm**: is the sibling mandatory for every new script?")
            else:
                w(f"- `{c['companion_folder_or_file']}` lists the scripts of `{c['folder']}` (e.g. `{_md_escape(ex.get('line', ''))[:90]}`) - every new script needs an entry. **Confirm.**")
    else:
        w("- (no companion rule could be proven from the repository)")
    w("- **TODO (team)**: the pairs the repository does not show - e.g. 'every new profile table needs a row in the metadata glossary table', "
      "'every new DAG needs a line in the on-call runbook', 'every schema change needs a migration script'.")
    w("")

    w("## 4. Naming")
    w("")
    suffixes = _top([s for v in folders.values() for s in (v.get("common_name_suffixes") or [])], 12)
    if suffixes:
        w(f"- Common file-name suffixes seen: {', '.join(f'`_{s}`' for s in suffixes)}. **TODO (team)**: what each suffix means and when it is mandatory.")
    task_ids = [t for d in dags for t in (d.get("task_ids") or [])]
    if task_ids:
        pat = Counter(re.sub(r"[a-z0-9]+", "x", t) for t in task_ids).most_common(3)
        w(f"- DAG task ids: {len(task_ids)} seen, dominant shapes {', '.join(f'`{p}`' for p, _ in pat)}; examples `{task_ids[0]}`, `{task_ids[len(task_ids) // 2]}`. "
          "**TODO (team)**: the rule (e.g. `<table>_<curr|hist>_<system>`).")
    w("- **TODO (team)**: table naming (`<subject>_<grain>_<system>`? suffix `_curr` / `_hist` / `_ikg`?), column naming (snake_case, date columns end with `_dt`?), "
      "DAG id naming, branch naming (`{story_id}-" + system + "-{feature}`), SQL file naming.")
    w("")

    w("## 5. Parameters, variables and environments")
    w("")
    top_params = sorted(params.items(), key=lambda kv: -int(kv[1].get("uses", 0) or 0))[:15]
    if top_params:
        w("| parameter | uses | example file | meaning (**TODO team**) |")
        w("|---|---|---|---|")
        for k, v in top_params:
            w(f"| `{{{{params.{k}}}}}` | {v.get('uses', 0)} | `{(v.get('examples') or [''])[0]}` | |")
        w("")
    variables = _top([v for d in dags for v in (d.get("variables") or [])], 12)
    if variables:
        w(f"- Airflow Variables used by the DAGs: {', '.join(f'`{v}`' for v in variables)}. **TODO (team)**: which may a developer add, who creates them in Airflow.")
    w("- **TODO (team)**: never hard-code a schema name - use which parameter? Which parameters differ between dev / uat / prod?")
    w("")

    w("## 6. SQL and Python conventions")
    w("")
    if conventions:
        w("Extracted from the current skills documents (model layer) - keep, fix or delete:")
        for c in conventions[:40]:
            w(f"- {_md_escape(c.get('rule', ''))} _(applies to: {_md_escape(c.get('applies_to', '') or 'all')}; source: {_md_escape(c.get('source', ''))})_")
    else:
        w("- (no skills document was available to the pack - this section is all TODO)")
    w("- **TODO (team)**: header comment block (what / author / story / date)? CTE style? `CREATE TABLE ... AS` vs `INSERT`? distribution key rule for Greenplum? "
      "`ANALYZE` after load? logging / error handling in python? forbidden constructs (`SELECT *`, `DELETE` without `WHERE`, cross-schema writes)?")
    w("")

    w("## 7. Validation and testing")
    w("")
    val_folders = [f for f in folders if re.search(r"valid|check|test|qa", f, re.I)]
    if val_folders:
        w(f"- Validation folders found: {', '.join(f'`{f}`' for f in val_folders[:8])}.")
    w("- **TODO (team)**: what every story must deliver as a check (row counts, null rates, min / max, reconciliation vs source, duplicate keys) and where it lives "
      "(validation folder vs notebook), and what 'done' means (MR approved by whom, uat run, sign-off).")
    w("")

    w("## 8. Checkable rules (machine-verifiable)")
    w("")
    w("Rules in this table are enforced automatically by the validator of Agile Dev Assist (regex on the generated file). `must_match` = the file MUST contain the pattern; "
      "otherwise the pattern is FORBIDDEN.")
    w("")
    w("| id | pattern (regex) | must_match | severity | languages | message |")
    w("|---|---|---|---|---|---|")
    for r in rules[:30]:
        w(f"| {r.get('id', '')} | `{_md_escape(r.get('pattern', ''))}` | {r.get('must_match', False)} | {r.get('severity', 'warn')} | {', '.join(r.get('languages') or [])} | {_md_escape(r.get('message', ''))} |")
    if not rules:
        w("| (none yet) | | | | | |")
    w("")
    w("- **TODO (team)**: add 5-10 rules you really want enforced, e.g. `no_select_star` (`SELECT\\s+\\*` forbidden, sql), `schema_param` (`{{params." + sysu + "_SCHEMA}}` must_match, sql).")
    w("")

    w("## 9. Glossary")
    w("")
    if definitions:
        for d in definitions[:60]:
            w(f"- **{_md_escape(d.get('term', ''))}**: {_md_escape(d.get('definition', ''))[:200]}")
    w("- **TODO (team)**: business terms a new developer will not know (profile, household, prospect, attribution, ...) and the table / column where each lives.")
    w("")

    w("## 10. Definition of done for a story")
    w("")
    w("- **TODO (team)**: the checklist an MR must satisfy - e.g. 1) script + history sibling, 2) registration entry, 3) validation artifact, "
      "4) uat run proof, 5) MR description with story id, 6) reviewer from the DL.")
    w("")
    return "\n".join(L) + "\n"


def write_template(cfg, system: str, out: str = "") -> Path:
    pack = Pack.latest(system, cfg)
    text = build_template(pack, system)
    root = Path(cfg.get("_root", "."))
    sc = (cfg.get("systems") or {}).get(system) or {}
    dest = Path(out) if out else root / str(sc.get("skills_folder") or f"skills/{system}") / f"{system}_standards_TEMPLATE.md"
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(text, encoding="utf-8")
    return dest


# ---------------------------------------------------------------------- merge the team's markdown files into one skill file
def merge_skills(cfg, system: str, name: str = "") -> dict:
    """skills/<system>/*.md (except README / *_TEMPLATE) -> ONE skills/<system>/<system>_skill.md, one `##` section per source file
    in alphabetical order (original heading levels shifted down one), with a table of contents. The originals are MOVED to
    skills/<system>/_merged/ (folders starting with `_` are not pack inputs) so nothing is read twice; yaml / other files stay as
    they are. Re-running merges the current .md files again (the merged file itself is skipped)."""
    import shutil
    root = Path(cfg.get("_root", "."))
    sc = (cfg.get("systems") or {}).get(system) or {}
    folder = root / str(sc.get("skills_folder") or f"skills/{system}")
    target = folder / (name or f"{system}_skill.md")
    srcs = [p for p in sorted(folder.glob("*.md"))
            if p.name.lower() != "readme.md" and p != target and not p.name.upper().endswith("_TEMPLATE.MD")]
    if not srcs:
        return {"merged": 0, "file": str(target), "note": "no .md files to merge"}
    parts, toc = [], []
    for p in srcs:
        text = p.read_text(encoding="utf-8", errors="replace").strip()
        sec = re.sub(r"[_\-]+", " ", p.stem).strip().title()
        toc.append(f"- [{sec}](#{re.sub(r'[^a-z0-9]+', '-', sec.lower()).strip('-')}) - `{p.name}`")
        fm = re.match(r"\A---\n(.*?)\n---\n", text, flags=re.S)                                      # yaml front matter -> one italic line
        if fm:
            meta = dict(re.findall(r"^(\w+):\s*(.+)$", fm.group(1), flags=re.M))
            text = text[fm.end():].lstrip()
            text = (f"_skill: `{meta.get('name', '')}` - {meta.get('description', '')}_\n\n" if meta else "") + text
        text = re.sub(r"\A(?:_skill:[^\n]*\n\n)?# [^\n]*\n+", lambda m: m.group(0).split("# ")[0], text)   # the file's own title: the section heading replaces it
        body = re.sub(r"^(#{1,5}) ", lambda m: "#" * (len(m.group(1)) + 1) + " ", text, flags=re.M)   # shift headings under the file section
        parts.append(f"## {sec}\n\n_source: `{p.name}`_\n\n{body}\n")
    out = [f"# {system.upper()} skills and standards", "",
           f"_Merged from {len(srcs)} files on {datetime.now():%Y-%m-%d}; the originals are kept in `_merged/`. Edit THIS file from now on, "
           "or edit the originals and re-run `python app_kpack.py merge-skills --system " + system + "`._", "", "## Contents", ""] + toc + [""] + parts
    merged_dir = folder / "_merged"
    merged_dir.mkdir(exist_ok=True)
    for p in srcs:
        shutil.move(str(p), str(merged_dir / p.name))
    target.write_text("\n".join(out), encoding="utf-8")
    return {"merged": len(srcs), "file": str(target), "sources": [p.name for p in srcs], "originals_moved_to": str(merged_dir)}
