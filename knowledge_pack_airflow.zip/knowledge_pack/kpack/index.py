"""The pack's search indexes: BM25 (exact) over every knowledge item + a dense vector store (Azure embeddings, one numpy
matrix) fused by reciprocal rank at query time. Built once per pack; embeddings are cached by text hash across builds
so a weekly rebuild embeds only what changed. Used by the builder (to write index/) and by consumers (Pack.search)."""
from __future__ import annotations

import hashlib
import json
import logging
import math
import pickle
import re
import threading
import time
from collections import Counter, OrderedDict
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np

from agiledev.repoindex import tokenize

log = logging.getLogger("kpack.index")
_IDENT = re.compile(r"\b(si_[a-z0-9_]+|[a-z][a-z0-9]*(?:_[a-z0-9]+){1,})\b", re.I)


def _h(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8", "replace")).hexdigest()[:32]


class BM25:
    def __init__(self):
        self.items: List[dict] = []
        self.tf: List[Counter] = []
        self.df: Counter = Counter()
        self.avgdl = 1.0

    def add(self, item: dict) -> None:
        toks = Counter(tokenize(item.get("title", "") * 2 + " " + item.get("text", "")))
        self.items.append(item); self.tf.append(toks); self.df.update(toks.keys())

    def finish(self) -> None:
        self.avgdl = (sum(sum(t.values()) for t in self.tf) / len(self.tf)) if self.tf else 1.0

    def search(self, query: str, k: int = 12, kinds: Optional[List[str]] = None, k1: float = 1.4, b: float = 0.7) -> List[dict]:
        q = tokenize(query)
        if not q or not self.items:
            return []
        n = len(self.items)
        idf = {t: math.log(1 + (n - self.df.get(t, 0) + 0.5) / (self.df.get(t, 0) + 0.5)) for t in set(q)}
        scored = []
        for i, tf in enumerate(self.tf):
            if kinds and self.items[i]["kind"] not in kinds:
                continue
            dl = sum(tf.values()) or 1
            s = 0.0
            for t in q:
                f = tf.get(t)
                if f:
                    s += idf[t] * f * (k1 + 1) / (f + k1 * (1 - b + b * dl / self.avgdl))
            if s > 0:
                scored.append((s, i))
        scored.sort(key=lambda x: -x[0])
        return [dict(self.items[i], score=round(s, 2)) for s, i in scored[:k]]


class PackIndex:
    """index/bm25.pkl + index/vectors.npy + index/vector_ids.json inside a pack folder; embedding cache shared across packs."""

    def __init__(self, pack_dir: Path, emb_cfg: dict, llm=None, cache_dir: Optional[Path] = None):
        self.dir = Path(pack_dir) / "index"
        self.dir.mkdir(parents=True, exist_ok=True)
        self._explicit = set((emb_cfg or {}).keys())
        self.s = dict({"enabled": True, "deployment": "text-embedding-3-small", "dimensions": 512, "batch_size": 64, "min_score": 0.2,
                       "rrf_k": 60, "bm25_candidates": 40, "dense_candidates": 40}, **(emb_cfg or {}))
        self.llm = llm
        self.cache_dir = Path(cache_dir) if cache_dir else self.dir
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.bm25: Optional[BM25] = None
        self.ids: List[str] = []
        self.M: Optional[np.ndarray] = None
        self.by_key: Dict[str, dict] = {}
        self._qcache: Dict[str, List[float]] = {}
        self._rcache: "OrderedDict[str, List[dict]]" = OrderedDict()
        self.status = {"items": 0, "dense": False, "embedded_now": 0, "from_cache": 0, "error": "", "seconds": 0.0}

    # ------------------------------------------------------------------ build
    def build(self, items: List[dict], progress=None) -> dict:
        say = progress or (lambda m: None)
        t0 = time.time()
        bm = BM25()
        for it in items:
            bm.add(it)
        bm.finish()
        self.bm25 = bm
        (self.dir / "bm25.pkl").write_bytes(pickle.dumps(bm))
        self.by_key = {f"{it['kind']}|{it['ref']}": it for it in items}
        self.status.update({"items": len(items)})
        if not self.s.get("enabled") or self.llm is None:
            self.status.update({"dense": False, "error": "embeddings disabled" if not self.s.get("enabled") else "no model client"})
            return self._done(t0)
        if not self._resolve_deployment(say):
            return self._done(t0)
        cache = self._load_cache()
        texts = {k: (it.get("title", "") + "\n" + it.get("text", ""))[:2000] for k, it in self.by_key.items()}
        todo = [k for k in self.by_key if _h(texts[k]) not in cache]
        new = {}
        try:
            bs = int(self.s["batch_size"])
            batches = [todo[i:i + bs] for i in range(0, len(todo), bs)]
            say(f"embedding {len(todo)} new items in {len(batches)} batches ({len(self.by_key) - len(todo)} from cache) ...")
            import concurrent.futures as cf
            lock = threading.Lock()
            done = [0]

            def one(batch):
                vecs = self.llm.embed([texts[k] for k in batch], self.s)
                with lock:
                    for k, v in zip(batch, vecs):
                        new[_h(texts[k])] = v
                    done[0] += len(batch)
                    if done[0] % (bs * 10) < bs:
                        say(f"embedded {done[0]}/{len(todo)} ...")
            with cf.ThreadPoolExecutor(int(self.s.get("parallel", 4))) as ex:
                for f in cf.as_completed([ex.submit(one, b) for b in batches]):
                    f.result()
        except Exception as e:  # noqa: BLE001
            self.status["error"] = f"{type(e).__name__}: {str(e)[:200]} - BM25 only"
            log.warning("embedding failed: %s", self.status["error"])
        if new:
            with self._cache_file().open("a", encoding="utf-8") as fh:
                for h, v in new.items():
                    fh.write(h + "\t" + json.dumps([round(x, 6) for x in v]) + "\n")
            cache.update(new)
        rows, ids = [], []
        for k in self.by_key:
            v = cache.get(_h(texts[k]))
            if v is not None:
                rows.append(v); ids.append(k)
        if rows:
            M = np.asarray(rows, dtype=np.float32)
            M /= (np.linalg.norm(M, axis=1, keepdims=True) + 1e-9)
            self.M, self.ids = M, ids
            np.save(self.dir / "vectors.npy", M)
            (self.dir / "vector_ids.json").write_text(json.dumps(ids), encoding="utf-8")
            self.status.update({"dense": True, "embedded_now": len(new), "from_cache": len(ids) - len(new)})
        return self._done(t0)

    def _resolve_deployment(self, say) -> bool:
        """Probes the configured embeddings deployment with one tiny call; on 404 DeploymentNotFound tries `deployment_candidates`
        in order and remembers the first that answers (data/cache/embeddings/deployment.txt)."""
        probe = self.cache_dir / "deployment.txt"
        tried = []
        cands = [self.s.get("deployment")] + [c for c in (self.s.get("deployment_candidates") or []) if c != self.s.get("deployment")]
        if probe.exists():
            known = probe.read_text(encoding="utf-8").strip()
            if known in cands:
                cands = [known] + [c for c in cands if c != known]
        for c in cands:
            if not c:
                continue
            self.s["deployment"] = c
            try:
                self.llm.embed(["probe"], self.s)
                probe.write_text(c, encoding="utf-8")
                if tried:
                    say(f"embeddings deployment {tried[-1]!r} not found - using {c!r}")
                return True
            except Exception as e:  # noqa: BLE001
                msg = str(e)
                tried.append(c)
                if "DeploymentNotFound" in msg or "404" in msg:
                    continue
                self.status["error"] = f"{type(e).__name__}: {msg[:200]} - BM25 only"
                log.warning("embedding failed: %s", self.status["error"])
                return False
        self.status["error"] = f"no embeddings deployment found (tried {', '.join(tried)}) - set embeddings.deployment to your Azure embeddings deployment name - BM25 only"
        log.warning(self.status["error"])
        return False

    def _done(self, t0):
        self.status["seconds"] = round(time.time() - t0, 1)
        self.status["embeddings"] = {k: self.s.get(k) for k in ("deployment", "dimensions", "api_version", "endpoint", "min_score", "rrf_k", "bm25_candidates", "dense_candidates")}
        (self.dir / "status.json").write_text(json.dumps(self.status, indent=1), encoding="utf-8")
        return self.status

    def _cache_file(self) -> Path:
        return self.cache_dir / f"emb_{re.sub(r'[^a-z0-9_-]', '_', str(self.s['deployment']).lower())}_{self.s['dimensions']}.jsonl"

    def _load_cache(self) -> Dict[str, List[float]]:
        out = {}
        f = self._cache_file()
        if f.exists():
            for ln in f.read_text(encoding="utf-8").splitlines():
                try:
                    h, v = ln.split("\t", 1); out[h] = json.loads(v)
                except ValueError:
                    continue
        return out

    # ------------------------------------------------------------------ load (consumers)
    def load(self) -> bool:
        p = self.dir / "bm25.pkl"
        if not p.exists():
            return False
        self.bm25 = pickle.loads(p.read_bytes())
        self.by_key = {f"{it['kind']}|{it['ref']}": it for it in self.bm25.items}
        v, i = self.dir / "vectors.npy", self.dir / "vector_ids.json"
        if v.exists() and i.exists() and self.s.get("enabled"):
            try:
                self.M = np.load(v); self.ids = json.loads(i.read_text(encoding="utf-8"))
                self.status["dense"] = len(self.ids) == self.M.shape[0]
            except Exception as e:  # noqa: BLE001
                log.warning("vector store not loadable: %s", e)
        st = self.dir / "status.json"
        if st.exists():
            try:
                saved = json.loads(st.read_text(encoding="utf-8"))
                self.status.update(saved)
                for k, v in (saved.get("embeddings") or {}).items():      # the pack knows its own embedding settings
                    if v not in (None, "") and k not in self._explicit:
                        self.s[k] = v
            except Exception:  # noqa: BLE001
                pass
        self.status["items"] = len(self.by_key)
        return True

    # ------------------------------------------------------------------ query
    def _embed_query(self, q: str):
        if self.llm is None:
            return None
        h = _h(q.strip().lower())
        v = self._qcache.get(h)
        if v is None:
            try:
                v = self.llm.embed([q[:2000]], self.s)[0]
            except Exception as e:  # noqa: BLE001
                log.warning("query embedding failed: %s", e)
                return None
            self._qcache[h] = v
        a = np.asarray(v, dtype=np.float32)
        return a / (np.linalg.norm(a) + 1e-9)

    def search(self, query: str, k: int = 12, kinds: Optional[List[str]] = None) -> List[dict]:
        if self.bm25 is None:
            return []
        ck = json.dumps([query.strip().lower(), sorted(kinds or []), int(k)])
        if ck in self._rcache:
            self._rcache.move_to_end(ck)
            return [dict(x) for x in self._rcache[ck]]
        n_b, n_d, rrf_k = int(self.s["bm25_candidates"]), int(self.s["dense_candidates"]), float(self.s["rrf_k"])
        ranks: Dict[str, dict] = {}
        for r, h in enumerate(self.bm25.search(query, k=n_b, kinds=kinds)):
            key = f"{h['kind']}|{h['ref']}"
            ranks[key] = {"item": h, "bm25_rank": r + 1, "score": 1.0 / (rrf_k + r + 1)}
        if self.M is not None and self.ids:
            qv = self._embed_query(query)
            if qv is not None:
                sims = self.M @ qv
                r = 0
                for j in np.argsort(-sims)[: n_d * 3]:
                    key = self.ids[int(j)]
                    it = self.by_key.get(key)
                    if it is None or (kinds and it["kind"] not in kinds) or float(sims[j]) < float(self.s["min_score"]):
                        continue
                    r += 1
                    e = ranks.setdefault(key, {"item": dict(it, score=0.0), "score": 0.0})
                    e["dense_rank"], e["dense"] = r, round(float(sims[j]), 3)
                    e["score"] += 1.0 / (rrf_k + r)
                    if r >= n_d:
                        break
        idents = {m.lower() for m in _IDENT.findall(query)}
        for e in ranks.values():
            ref, title = str(e["item"].get("ref", "")).lower(), str(e["item"].get("title", "")).lower()
            if any(i == ref or ref.endswith("." + i) or ref.endswith("/" + i) or i == title for i in idents):
                e["score"] += 0.02
        ordered = sorted(ranks.values(), key=lambda e: -e["score"])
        out, per_kind = [], Counter()
        for e in ordered:
            kind = e["item"]["kind"]
            if per_kind[kind] >= (max(4, (2 * k) // 3) if kind in ("chunk", "file") else max(3, k // 2)) and len(ordered) > k:
                continue
            per_kind[kind] += 1
            via = "both" if "bm25_rank" in e and "dense_rank" in e else ("dense" if "dense_rank" in e else "bm25")
            out.append(dict(e["item"], score=round(e["score"] * 100, 2), via=via, dense=e.get("dense")))
            if len(out) >= k:
                break
        self._rcache[ck] = [dict(x) for x in out]
        while len(self._rcache) > 500:
            self._rcache.popitem(last=False)
        return out
