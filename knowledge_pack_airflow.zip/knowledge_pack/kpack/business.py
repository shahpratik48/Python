"""Business-rule layer of a pack: the insight catalogue traced across the three STAAT Insights systems.

    IKG  (feature store)      builds the profile tables and their columns (features) from EDW / vendor data
    ODM  (business rules)     one SQL rule per insight id (`si_*`): WHEN the features meet the conditions, an insight row
                              is written for a target (account / household / client / prospect / FA ...)
    NLG  (narratives)         one yml per insight id: the English sentence an advisor reads, filled from the features

The insight id is the join key. For every rule this module records, without any model call:
  * the English description: NLG title + narrative, the documented business description, the ODM conditions rendered
    as English ("household assets (current) `mhh_assets_curr` is at least 10,000"),
  * the exact ODM SQL facts: target, key, metric, attributes, source tables, every condition (SQL + English), the other
    insights it depends on,
  * the features (columns) it uses, with their meaning (name decoding, IKG code comments, the NLG sentence that prints
    them) and the IKG scripts that compute them (expression + source tables),
  * NLG presentation: product / category / label / suppression from the insight group layout, extra NLG columns and
    the files that mention the id.
So a story written in plain English ("alert the FA when a PMP account fails the Aladdin risk test two quarters in a
row") finds the rule by its words, and the trace answers "which table / column / script / narrative changes".

Output: facts/business.json + cards/rule/<id>.md + cards/domain/<name>.md + cards/business_rules.md + retrieval items
(kinds business_rule, feature, domain, entity) + graph nodes / edges.
"""
from __future__ import annotations

import json
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

try:                                   # sqlglot makes the SQL facts exact; without it a regex fallback still works
    import logging as _logging
    import sqlglot
    from sqlglot import exp
    _logging.getLogger("sqlglot").setLevel(_logging.ERROR)
except Exception:  # noqa: BLE001
    sqlglot = None
    exp = None

ID_RE = re.compile(r"\bsi_[a-z0-9_]+\b", re.I)
IDENT_RE = re.compile(r"[a-z_][a-z0-9_]*|\*")
PARAM_RE = re.compile(r"\{\{\s*params\.([A-Za-z0-9_]+)\s*\}\}")
JINJA_RE = re.compile(r"\{%.*?%\}", re.S)
LINE_COMMENT_RE = re.compile(r"--[^\n]*")
BLOCK_COMMENT_RE = re.compile(r"/\*.*?\*/", re.S)
TAG_RE = re.compile(r"<[^>]+>")

# --------------------------------------------------------------------------------------------- names -> words
# Only expansions that are certain. Unknown tokens stay as they are (upper case) - a wrong expansion is worse than none.
TOKENS = {
    "acc": "account", "accs": "accounts", "acct": "account", "mhh": "household", "hh": "household", "shh": "statement household",
    "shhp": "statement household plus", "hhp": "household plus", "cli": "client", "clnt": "client", "ip": "client", "gndr": "gender", "znfo": "ZoomInfo", "cntry": "country", "st": "state", "frst": "first",
    "lst": "last", "nm": "name", "amt": "amount", "val": "value", "qty": "quantity", "cnt": "count", "num": "number of",
    "pct": "percent", "perc": "percent", "curr": "current", "prev": "previous", "prv": "previous", "qtr": "quarter",
    "qtr2": "two quarters back", "qtr3": "three quarters back", "yr": "year", "ytd": "year to date", "mtd": "month to date",
    "yoy": "year over year", "stat": "status", "aldn": "Aladdin", "bmrk": "benchmark", "rev": "revenue", "roa": "return on assets",
    "brkg": "brokerage", "brk": "brokerage", "adv": "advisory", "fa": "FA", "fas": "FAs", "fl": "field leader",
    "sbl": "securities-based lending", "rmd": "required minimum distribution", "ira": "IRA", "nnm": "net new money",
    "aum": "assets under management", "mkt": "market", "bal": "balance", "txn": "transaction", "trx": "transaction",
    "dep": "deposit", "wdrw": "withdrawal", "ins": "insurance", "pol": "policy", "ben": "beneficiary", "benef": "beneficiary",
    "mat": "maturity", "sec": "security", "scty": "security", "xsale": "cross-sale", "mtg": "mortgage", "prop": "property",
    "addr": "address", "dob": "date of birth", "bday": "birthday", "ann": "anniversary", "flg": "flag", "ind": "indicator",
    "min": "minimum", "max": "maximum", "avg": "average", "tot": "total", "chg": "change", "diff": "difference",
    "incr": "increase", "decr": "decrease", "eff": "effective", "dt": "date", "d": "date", "fga": "FGA (financial goal analysis)", "sma": "SMA (separately managed account)",
    "eft": "EFT (electronic funds transfer)", "mls": "MLS (property listing)", "saa": "strategic asset allocation",
    "bknight": "Black Knight", "blacknight": "Black Knight", "zoominfo": "ZoomInfo", "wealthx": "WealthX", "speedeon": "Speedeon",
    "medallia": "Medallia", "yodlee": "Yodlee", "brightscope": "BrightScope", "windfall": "Windfall", "jornaya": "Jornaya",
    "demyst": "Demyst", "assets": "assets", "liab": "liabilities", "inc": "income", "exp": "expense", "cash": "cash",
    "12m": "12 months", "6m": "6 months", "3m": "3 months", "1m": "1 month", "4w": "4 weeks", "1y": "1 year", "2y": "2 years",
    "3y": "3 years", "5y": "5 years", "1q": "1 quarter", "2q": "2 quarters", "3q": "3 quarters", "hist": "history",
    "is": "is", "has": "has", "lead": "lead", "pos": "positions", "prod": "products", "rec": "received", "cust": "custodian",
}
ENTITY_KEYS = {          # target type -> what the key means (from the account / client / household mapping)
    "account": "acc_i - the account id",
    "household": "acc_mhh_n - the household key of the IKG profiles (statement household plus / household_plus)",
    "client": "ip_cli_i - the client id (the individual who owns accounts)",
    "prospect": "the prospect id (not yet a client)",
    "fl_ubs_fa": "the FA as seen by a field leader",
    "fl_recruitment": "a recruiting target FA for a field leader",
}


KNOWN_COLUMNS = {        # the identifiers every story mentions (account / client / household mapping, IKG conventions)
    "acc_i": "account id", "acc_n": "account number", "ip_cli_i": "client id", "cw_rel_i": "relationship id (ACE / ConsultWorks)",
    "acc_hh_n": "statement household id", "acc_mhh_n": "household key (household_plus)", "acc_market_hh_n": "marketing household id",
    "household_plus": "statement household plus id", "ip_frst_x": "client first name", "ip_last_x": "client last name",
    "ip_midl_x": "client middle name", "ip_dob_d": "client date of birth", "acc_stat_c": "account status code",
    "profile_date_d": "profile (snapshot) date", "profile_date": "profile (snapshot) date", "mhh_assets_curr": "household assets (current)",
    "acc_assets_curr": "account assets (current)", "imr_foa_code": "FA code (FOA)", "foa_code": "FA code (FOA)", "fa_i": "FA id",
}
SUFFIX = {"c": "code", "d": "date", "dt": "date", "x": "name/text", "i": "id", "n": "number", "t": "type", "a": "amount", "f": "flag", "q": "quantity"}
WORDS = {"risk", "home", "loss", "gain", "rate", "plan", "card", "goal", "life", "high", "low", "fail", "pass", "over", "open", "sale", "move",
         "list", "flag", "date", "name", "type", "year", "week", "days", "user", "firm", "team", "news", "time", "paid", "term", "fund", "debt",
         "loan", "real", "tax", "net", "new", "old", "age", "pay", "bill", "gift", "best", "top", "key", "job", "law", "art", "car", "end",
         "in", "on", "of", "to", "at", "by", "and", "or", "not", "any", "all", "no", "yes", "per", "out", "up", "down", "last", "next", "first",
         "one", "two", "due", "fee", "fees", "cost", "size", "zip", "city", "state", "role", "rank", "score", "model", "level", "value", "total"}


# plain-English words of stories -> the technical words of rules, features and domains (query expansion; single tokens)
BUSINESS_SYNONYMS = {
    "held": ["external", "mtp", "yodlee"], "away": ["external", "mtp"], "outside": ["external", "mtp"], "external": ["mtp", "yodlee", "ext"],
    "stock": ["holding", "scty", "security"], "stocks": ["holding", "scty"], "equity": ["holding", "scty"], "shares": ["holding", "scty"],
    "concentration": ["concentrated", "holding"], "married": ["speedeon", "marriage"], "engaged": ["speedeon"], "divorce": ["speedeon", "single"],
    "life": ["speedeon"], "mortgage": ["mtg", "bknight"], "house": ["bknight", "property", "real_estate"], "property": ["bknight", "mls", "real_estate"],
    "realestate": ["bknight", "mls"], "listing": ["mls", "bknight"], "trust": ["estate", "trust"], "will": ["estate"], "401k": ["brightscope", "retirement"],
    "birthday": ["bday", "birthday"], "complaint": ["medallia"], "survey": ["medallia"], "feedback": ["medallia"], "nps": ["medallia"],
    "news": ["newsedge"], "company": ["zoominfo", "firmographic"], "owner": ["zoominfo", "business_owner"], "wealthy": ["wealthx", "assets"],
    "rich": ["wealthx", "assets"], "goal": ["fga", "goal"], "goals": ["fga", "goal"], "lending": ["sbl", "loan"], "pledged": ["sbl"],
    "risk": ["aladdin", "aldn"], "outlier": ["aladdin", "aldn"], "recruit": ["fl_recruitment", "recruits"], "hire": ["fl_recruitment", "recruits"],
    "attrition": ["attrition", "red_flag"], "leaving": ["attrition"], "cash": ["cash", "txn"], "deposit": ["dep", "cash"], "withdrawal": ["wdrw", "cash"],
    "card": ["credit_card", "card"], "insurance": ["ins", "insurance", "policy"], "annuity": ["annuity", "ins"], "bond": ["mat", "maturity", "fixed"],
    "maturing": ["maturity", "mat"], "retire": ["retirement", "epas", "rmd"], "retirement": ["retirement", "rmd", "ira"], "inheritance": ["windfall", "beneficiary"],
    "windfall": ["windfall"], "beneficiary": ["beneficiary", "ben"], "spending": ["spending", "card_txn"], "prospect": ["prospect", "prospects"],
    "advisor": ["fa"], "advisors": ["fa"], "household": ["mhh", "household"], "client": ["cli", "client"], "account": ["acc", "account"],
}


def humanize(col: str) -> str:
    """mhh_assets_curr -> 'household assets (current)'; acc_stat_c -> 'account status code'. Certain expansions only:
    unknown abbreviations without vowels are shown in capitals (MTP, PKR), others as written."""
    c = col.lower()
    if c in KNOWN_COLUMNS:
        return KNOWN_COLUMNS[c]
    parts = [p for p in re.split(r"[_\W]+", c) if p]
    suffix = ""
    if len(parts) > 1 and parts[-1] in SUFFIX:
        suffix = SUFFIX[parts.pop()]
    out = []
    for p in parts:
        w = TOKENS.get(p)
        if w is None:
            if p in WORDS or p.isdigit():
                w = p
            elif len(p) <= 4 and not re.search(r"[aeiouy]", p):
                w = p.upper()
            else:
                w = p
        out.append(w)
    text = " ".join(out)
    if suffix and not text.endswith(suffix) and not (suffix == "date" and "date" in text):
        text += f" ({suffix})"
    return text


def _strip_sql(text: str) -> str:
    return LINE_COMMENT_RE.sub("", BLOCK_COMMENT_RE.sub(" ", text))


def _mask(sql: str) -> str:
    """Jinja params -> parseable identifiers; {% %} blocks dropped."""
    sql = JINJA_RE.sub(" ", sql)
    return PARAM_RE.sub(lambda m: f"P__{m.group(1)}", sql)


def _unmask(s: str) -> str:
    return re.sub(r"P__([A-Za-z0-9_]+)", r"{{params.\1}}", s)


def _short(t: str) -> str:
    """{{params.IKG_SCHEMA}}.account_profile_curr_ikg -> account_profile_curr_ikg; {{params.ODM_TABLE}} -> odm_table."""
    return PARAM_RE.sub(lambda m: m.group(1), t).split(".")[-1].lower()


def _fmt_num(v: str) -> str:
    try:
        f = float(v)
        if f.is_integer() and abs(f) >= 1000:
            return f"{int(f):,}"
        return v
    except ValueError:
        return v


# --------------------------------------------------------------------------------------------- SQL -> English
class English:
    """Renders a sqlglot expression (a WHERE predicate) as an English phrase. Unknown shapes fall back to the SQL."""

    OPS = {"GTE": "is at least", "GT": "is more than", "LTE": "is at most", "LT": "is less than", "EQ": "is", "NEQ": "is not"}

    def __init__(self, glossary: Dict[str, str]):
        self.g = glossary

    def col(self, name: str) -> str:
        name = name.lower()
        return f"{self.g.get(name) or humanize(name)} (`{name}`)"

    def val(self, e) -> str:  # noqa: C901
        if e is None:
            return ""
        if isinstance(e, exp.Paren):
            return self.val(e.this)
        if isinstance(e, exp.Column):
            return self.col(e.name)
        if isinstance(e, exp.Literal):
            return _fmt_num(e.this) if not e.is_string else f"'{e.this}'"
        if isinstance(e, exp.Null):
            return "empty"
        if isinstance(e, exp.Boolean):
            return "true" if e.this else "false"
        if isinstance(e, (exp.Cast, exp.TryCast)):
            return self.val(e.this)
        if isinstance(e, exp.Coalesce):
            return self.val(e.this)
        if isinstance(e, exp.Neg):
            return "-" + self.val(e.this)
        for cls, sym in ((exp.Div, "÷"), (exp.Mul, "×"), (exp.Add, "+"), (exp.Sub, "-")):
            if isinstance(e, cls):
                return f"({self.val(e.left)} {sym} {self.val(e.right)})"
        if isinstance(e, (exp.CurrentDate, exp.CurrentTimestamp)):
            return "today"
        if isinstance(e, exp.Interval):
            unit = e.args.get("unit")
            return f"{self.val(e.this).strip(chr(39))} {unit.name.lower() if unit is not None and hasattr(unit, 'name') else ''}".strip()
        if isinstance(e, exp.Subquery) or isinstance(e, exp.Select):
            tabs = sorted({t.name for t in e.find_all(exp.Table)})
            return f"(a sub-query on {', '.join(tabs) or 'a table'})"
        if isinstance(e, exp.Anonymous) or isinstance(e, exp.Func):
            name = (e.name if isinstance(e, exp.Anonymous) else e.sql_name()).lower()
            args = [self.val(a) for a in e.args.values() if isinstance(a, exp.Expression)][:3]
            return f"{name}({', '.join(args)})"
        return f"`{_unmask(e.sql(dialect='postgres'))}`"

    def pred(self, e) -> str:  # noqa: C901
        if isinstance(e, exp.Paren):
            return self.pred(e.this)
        if isinstance(e, exp.And):
            return " and ".join(self.pred(x) for x in e.flatten())
        if isinstance(e, exp.Or):
            return "either " + " or ".join(f"({self.pred(x)})" for x in e.flatten())
        if isinstance(e, exp.Not):
            inner = e.this
            if isinstance(inner, exp.Is):
                return f"{self.val(inner.this)} is present" if isinstance(inner.expression, exp.Null) else f"{self.val(inner.this)} is not {self.val(inner.expression)}"
            if isinstance(inner, exp.In):
                return self._in(inner, neg=True)
            if isinstance(inner, exp.Exists):
                return f"there is no matching row in {self.val(inner.this)}"
            if isinstance(inner, (exp.Like, exp.ILike)):
                return f"{self.val(inner.this)} does not match {self.val(inner.expression)}"
            return f"not ({self.pred(inner)})"
        if isinstance(e, exp.Is):
            return f"{self.val(e.this)} is empty" if isinstance(e.expression, exp.Null) else f"{self.val(e.this)} is {self.val(e.expression)}"
        if isinstance(e, exp.In):
            return self._in(e)
        if isinstance(e, exp.Between):
            return f"{self.val(e.this)} is between {self.val(e.args.get('low'))} and {self.val(e.args.get('high'))}"
        if isinstance(e, (exp.Like, exp.ILike)):
            return f"{self.val(e.this)} matches {self.val(e.expression)}"
        if isinstance(e, exp.Exists):
            return f"there is a matching row in {self.val(e.this)}"
        for name, words in self.OPS.items():
            cls = getattr(exp, name)
            if isinstance(e, cls):
                left, right = e.left, e.right
                # COALESCE(x, '') = ''  ->  x is empty
                if isinstance(left, exp.Coalesce) and isinstance(right, exp.Literal) and right.this == "" and name in ("EQ", "NEQ"):
                    return f"{self.val(left.this)} is {'empty' if name == 'EQ' else 'present'}"
                return f"{self.val(left)} {words} {self.val(right)}"
        return f"`{_unmask(e.sql(dialect='postgres'))}`"

    def _in(self, e, neg: bool = False) -> str:
        q = e.args.get("query")
        if q is not None:
            return f"{self.val(e.this)} is {'not ' if neg else ''}in {self.val(q)}"
        vals = [self.val(x) for x in e.expressions][:12]
        more = " ..." if len(e.expressions) > 12 else ""
        return f"{self.val(e.this)} is {'not ' if neg else ''}one of {{{', '.join(vals)}{more}}}"


def _top_ands(where) -> list:
    w = where.this if hasattr(where, "this") else where
    while isinstance(w, exp.Paren):
        w = w.this
    return list(w.flatten()) if isinstance(w, exp.And) else [w]


# --------------------------------------------------------------------------------------------- ODM rules
ODM_COLS = ["insight_type", "target_type", "target_key", "metric_name", "metric_type", "metric_val", "run_id",
            "insight_date_time", "insight_category", "insight_att_name", "insight_att_val"]


def _first_select(node):
    """The SELECT that produces the rows of an INSERT (through UNION: the first branch)."""
    s = node
    while s is not None and not isinstance(s, exp.Select):
        s = s.args.get("this") or s.args.get("expression")
    return s


def parse_odm_file(rel: str, text: str) -> List[dict]:
    """Every insight a rule file writes: {id, target, key, metric, attributes, tables, conditions, columns, depends_on}."""
    clean = _strip_sql(text)
    out: List[dict] = []
    if sqlglot is not None:
        try:
            stmts = sqlglot.parse(_mask(clean), read="postgres", error_level=sqlglot.ErrorLevel.IGNORE)
        except Exception:  # noqa: BLE001
            stmts = []
        for st in stmts:
            if not isinstance(st, exp.Insert):
                continue
            cols = [c.name.lower() for c in st.this.expressions] if isinstance(st.this, exp.Schema) else []
            sel = _first_select(st.expression)
            if sel is None:
                continue
            ctes = {c.alias_or_name.lower() for c in st.find_all(exp.CTE)}
            projections = sel.expressions
            if not cols:
                cols = ODM_COLS[: len(projections)]
            m = {c: projections[i] for i, c in enumerate(cols) if i < len(projections)}
            ins = m.get("insight_type")
            if ins is None:
                continue
            ids = [ins.this] if isinstance(ins, exp.Literal) else [x for x in ID_RE.findall(ins.sql()) if x]
            if not ids:
                continue
            tgt = m.get("target_type")
            tables = []
            for t in st.expression.find_all(exp.Table):
                name = _unmask(t.name) if t.name.startswith("P__") else t.name.lower()     # {{params.ODM_TABLE}} stays a parameter
                if not name or name in ctes:
                    continue
                db = _unmask(t.db) if t.db else ""
                full = f"{db}.{name}" if db else name
                if full not in tables:
                    tables.append(full)
            where = sel.args.get("where")
            preds = _top_ands(where) if where is not None else []
            depends = sorted({x.lower() for x in ID_RE.findall(_unmask(st.expression.sql())) if x.lower() not in {i.lower() for i in ids}})
            columns = sorted({c.name.lower() for c in st.expression.find_all(exp.Column)})

            def lit(k):
                v = m.get(k)
                if v is None:
                    return ""
                if isinstance(v, exp.Literal):
                    return v.this
                if isinstance(v, exp.Alias):
                    v = v.this
                return _unmask(v.sql(dialect="postgres"))
            for iid in ids:
                out.append({"id": iid.lower(), "file": rel, "target": lit("target_type").lower(), "key": lit("target_key"),
                            "metric": {"name": lit("metric_name"), "type": lit("metric_type"), "value": lit("metric_val")},
                            "category": lit("insight_category"), "attribute": {"name": lit("insight_att_name"), "value": lit("insight_att_val")},
                            "tables": tables, "_preds": preds, "columns": columns, "depends_on": depends,
                            "union_branches": len(list(st.expression.find_all(exp.Union))) + 1 if st.expression.find(exp.Union) else 1,
                            "parser": "sqlglot"})
    if not out:                                           # regex fallback: SELECT 'si_x', 'target', key ... FROM t WHERE ...;
        for mm in re.finditer(r"select\s+'(si_[a-z0-9_]+)'\s*,\s*'([a-z_]+)'\s*,\s*([^,]+),(.*?)(?:;|$)", clean, re.I | re.S):
            body = mm.group(4)
            fr = re.findall(r"\b(?:from|join)\s+([\w{}.]+)", body, re.I)
            wh = re.search(r"\bwhere\b(.*)", body, re.I | re.S)
            conds = [c.strip() for c in re.split(r"\s+and\s+", wh.group(1), flags=re.I)] if wh else []
            out.append({"id": mm.group(1).lower(), "file": rel, "target": mm.group(2).lower(), "key": mm.group(3).strip(), "metric": {},
                        "category": "", "attribute": {}, "tables": sorted(set(fr)), "_preds": [], "_raw_conditions": conds,
                        "columns": sorted(set(re.findall(r"\b[a-z][a-z0-9_]{2,}\b", wh.group(1).lower()))) if wh else [],
                        "depends_on": sorted({x.lower() for x in ID_RE.findall(body) if x.lower() != mm.group(1).lower()}), "parser": "regex"})
    return out


# --------------------------------------------------------------------------------------------- NLG
def _yaml(text: str):
    try:
        import yaml
        loader = getattr(yaml, "CSafeLoader", yaml.SafeLoader)      # libyaml when installed: ~10x faster
        return yaml.load(text, Loader=loader)
    except Exception:  # noqa: BLE001
        return None


def _plain(s: str) -> str:
    s = TAG_RE.sub(" ", str(s))
    s = re.sub(r"&nbsp;|&[a-z]+;|&#\d+;", " ", s)
    s = re.sub(r"#([a-z0-9_]+)(?:\.[^#]*)?#", r"<\1>", s, flags=re.I)      # #col.format(...)# -> <col>
    return re.sub(r"\s+", " ", s).strip()


def parse_nlg_rule(rel: str, text: str) -> dict:
    y = _yaml(text)
    rid = Path(rel).stem.lower()
    rec = {"id": rid, "file": rel, "title": "", "narrative": "", "placeholders": [], "narratives": {}}
    if not isinstance(y, dict):
        m = re.search(r"<b>(.*?)</b>", text)
        rec["title"] = _plain(m.group(1)) if m else ""
        rec["placeholders"] = sorted(set(re.findall(r"^([a-z][a-z0-9_]*):\s*\n\s*-\s*\"\{\1\}\"", text, re.M)))
        return rec
    ph, narr = [], {}
    for k, v in y.items():
        vals = v if isinstance(v, list) else [v]
        vals = [str(x) for x in vals if x is not None]
        if any(x.strip() == "{" + str(k) + "}" for x in vals):
            ph.append(str(k))
        elif any("#" in x or len(x) > 40 for x in vals):
            narr[str(k)] = vals[:2]
    rec["placeholders"] = ph
    rec["narratives"] = {k: [_plain(x)[:900] for x in v] for k, v in narr.items()}
    for key in ("rule_narrative_single", "rule_narrative", "rule_narrative_compound"):
        for x in narr.get(key, []):
            m = re.search(r"<b>(.*?)</b>", x)
            if m and not rec["title"]:
                rec["title"] = _plain(m.group(1))
    # the advisor-facing sentence: the narrative the single rule narrative points to (#xxx_narrative#), else the longest
    single = " ".join(narr.get("rule_narrative_single", []) + narr.get("rule_narrative", []))
    refs = re.findall(r"#([a-z0-9_]+)#", single)
    body = ""
    for r in refs:
        if r in narr and r not in ("link_narrative",):
            body = _plain(narr[r][0]); break
    if not body and narr:
        cand = [k for k in narr if k.endswith("narrative") and not k.startswith("link")]
        body = _plain(narr[cand[0]][0]) if cand else _plain(next(iter(narr.values()))[0])
    rec["narrative"] = re.sub(r"^\s*-\s*", "", body)[:900]
    return rec


def _sentences_with(text: str, col: str) -> List[str]:
    out = []
    for s in re.split(r"(?<=[.!?])\s+", text):
        if f"<{col}>" in s:
            out.append(s.strip()[:240])
    return out


# --------------------------------------------------------------------------------------------- IKG producers
AS_RE = re.compile(r"(?im)^(?P<line>[^\n]*?)\bas\s+\"?(?P<col>[a-z_][a-z0-9_]*)\"?\s*,?\s*(?:--(?P<note>[^\n]*))?$")


def ikg_producers(root: Path, files: Iterable[str], wanted: set) -> Dict[str, List[dict]]:
    """column -> [{file, line, expr, note, sources}] for every `<expr> AS <column>` in the IKG SQL (computed columns first;
    plain pass-through `x.col AS col` / `col AS col` kept only if nothing better exists)."""
    found: Dict[str, List[dict]] = defaultdict(list)
    src_cache: Dict[str, List[str]] = {}
    for rel in files:
        if not rel.lower().endswith(".sql"):
            continue
        try:
            text = (root / rel).read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        lines = text.splitlines()
        for i, ln in enumerate(lines):
            m = re.search(r"\bas\s+\"?([a-z_][a-z0-9_]*)\"?\s*,?\s*(--.*)?$", ln, re.I)
            if not m:
                continue
            col = m.group(1).lower()
            if col not in wanted:
                continue
            expr = ln[: m.start()].strip().rstrip(",")
            j = i
            while (not expr or expr.lower() in ("end", ")")) and j > 0 and i - j < 12:     # CASE ... END AS col: take the block
                j -= 1
                expr = (lines[j].strip() + " " + expr).strip()
                if re.match(r"(?i)^(case|coalesce|sum|max|min|count|round|avg)\b", lines[j].strip()):
                    break
            note = (m.group(2) or "").lstrip("-").strip()
            k = j - 1
            while not note and k >= 0 and j - k <= 3 and lines[k].strip().startswith("--"):
                note = lines[k].strip().lstrip("-").strip(); k -= 1
            passthrough = bool(re.fullmatch(r"(?:[a-z_][a-z0-9_]*\.)?" + re.escape(col), expr.lower().strip()))
            if rel not in src_cache:
                src_cache[rel] = sorted({_unmask(x).lower() for x in re.findall(r"\b(?:from|join)\s+((?:\{\{\s*params\.[A-Za-z0-9_]+\s*\}\}\.)?[a-z_][a-z0-9_.]*)", text, re.I)
                                         if not x.lower().endswith("_tmp") and x.lower() not in ("select", "lateral", "unnest")})[:12]
            found[col].append({"file": rel, "line": i + 1, "expr": re.sub(r"\s+", " ", expr)[:300], "note": note[:200],
                               "passthrough": passthrough, "sources": src_cache[rel]})
    out = {}
    for col, lst in found.items():
        lst.sort(key=lambda d: (d["passthrough"], "profile" in d["file"], d["file"]))
        seen, keep = set(), []
        for d in lst:
            if (d["file"], d["expr"]) in seen:
                continue
            seen.add((d["file"], d["expr"])); keep.append(d)
        out[col] = keep[:4]
    return out


class Lineage:
    """Column lineage inside the IKG repository, by table name: the script that writes a table, how a column of it is
    produced there - computed (`expr AS col`), passed through from a joined table (`alias.col`, `alias.*`, bare `col`) -
    followed until the computing expression, at most `max_hops` tables deep.
        account_profile_curr_ikg.aldn_acc_risk  <- aladdin_accounts_risk_alert_ikg: round(MAX(account_risk),2)
                                                <- edw aladdin_account_analytics_daily (account_risk*100)"""
    WRITE_RE = re.compile(r"(?is)\b(?:create\s+(?:(?:local\s+)?(?:temp|temporary)\s+|unlogged\s+)?table\s+(?:if\s+not\s+exists\s+)?|insert\s+into\s+|create\s+(?:or\s+replace\s+)?(?:materialized\s+)?view\s+)([\w{}.\"]+)")
    ALIAS_RE = re.compile(r"(?is)\b(?:from|join)\s+((?:\{\{\s*params\.[A-Za-z0-9_]+\s*\}\}\.)?[a-z_][\w.\"]*)\s+(?:as\s+)?([a-z_][a-z0-9_]*)")
    KW = {"where", "on", "left", "right", "inner", "outer", "full", "cross", "join", "group", "order", "limit", "union", "using", "lateral", "natural", "and", "having", "window", "select", "as"}

    def __init__(self, root: Path, files: Iterable[str], max_hops: int = 5):
        self.root, self.max_hops = root, max_hops
        self._cache: Dict[str, tuple] = {}
        self.text: Dict[str, str] = {}
        self.writers: Dict[str, List[str]] = defaultdict(list)
        for rel in files:
            if not rel.lower().endswith(".sql") or "_history" in rel.lower() or "/archive" in rel.lower():
                continue
            try:
                t = (root / rel).read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            t = BLOCK_COMMENT_RE.sub(" ", t)
            self.text[rel] = t
            for m in self.WRITE_RE.finditer(t):
                name = self.base(m.group(1))
                if name and rel not in self.writers[name]:
                    self.writers[name].append(rel)
        for name, lst in self.writers.items():          # the script named after the table first (the IKG convention)
            lst.sort(key=lambda r: (Path(r).stem.lower() != name, len(lst)))

    @staticmethod
    def base(name: str) -> str:
        return PARAM_RE.sub("", name).strip('".').split(".")[-1].strip('"').lower()

    def aliases(self, text: str) -> Dict[str, str]:
        out = {}
        for m in self.ALIAS_RE.finditer(LINE_COMMENT_RE.sub("", text)):
            a = m.group(2).lower()
            if a not in self.KW:
                out.setdefault(a, self.base(m.group(1)))
        return out

    def _file(self, rel: str):
        """Per script, once: its lines without comments, identifier -> line numbers, alias -> table."""
        c = self._cache.get(rel)
        if c is None:
            t = self.text[rel]
            lines = t.splitlines()
            code = [LINE_COMMENT_RE.sub("", ln) for ln in lines]
            where: Dict[str, List[int]] = defaultdict(list)
            for i, ln in enumerate(code):
                for w in set(IDENT_RE.findall(ln.lower())):
                    where[w].append(i)
            c = self._cache[rel] = (lines, code, where, self.aliases(t))
        return c

    def resolve(self, col: str, table: str, _depth: int = 0, _seen=None, _prefer: str = "") -> List[dict]:
        """[{table, file, line, expr, kind}] from `table` down to the computing step ([] when not found)."""
        _seen = _seen if _seen is not None else set()
        table = self.base(table)
        if _depth > self.max_hops or (table, col) in _seen:
            return []
        _seen.add((table, col))
        files = list(self.writers.get(table, []))
        if _prefer and _prefer in files:
            files.remove(_prefer); files.insert(0, _prefer)     # a temp table is written in the same file
        as_re = re.compile(r"(?i)\bas\s+\"?" + re.escape(col) + r"\"?\s*,?\s*$")
        ref_re = re.compile(r"(?i)(?:^|[\s,(])(?:([a-z_][a-z0-9_]*)\.)?\"?" + re.escape(col) + r"\"?\b(?!\s*\()")
        cond_re = re.compile(r"(?i)\b(where|and|or|on|when|then|else|case|group by|order by)\b[^,]*" + re.escape(col))
        ddl_re = re.compile(r"(?i)\b" + re.escape(col) + r"\s+(numeric|integer|int|bigint|varchar|character|text|date|timestamp|double|boolean|float|decimal|smallint|real)")
        for rel in files[:3]:
            lines, code_lines, where, al = self._file(rel)
            cand = sorted(set(where.get(col, [])) | set(where.get("*", [])))
            computed, passes, stars = None, [], []
            for i in cand:
                code = code_lines[i]
                if code.rstrip().endswith(".*") or re.match(r"(?i)^\s*,?\s*([a-z_][a-z0-9_]*)\.\*\s*,?\s*$", code):
                    m0 = re.match(r"(?i)^\s*,?\s*([a-z_][a-z0-9_]*)\.\*", code)
                    if m0:
                        stars.append(m0.group(1).lower())
                    continue
                if col not in code.lower():
                    continue
                m = as_re.search(code)
                if m:
                    expr = code[: m.start()].strip().rstrip(",")
                    j = i
                    while (not expr or expr.lower() in ("end", ")")) and j > 0 and i - j < 15:
                        j -= 1
                        expr = (code_lines[j].strip() + " " + expr).strip()
                        if re.match(r"(?i)^,?\s*(case|coalesce|sum|max|min|count|round|avg)\b", lines[j].strip()):
                            break
                    src = re.fullmatch(r"(?i)\s*(?:([a-z_][a-z0-9_]*)\.)?\"?([a-z_][a-z0-9_]*)\"?\s*", expr)
                    if src and src.group(2).lower() == col:
                        passes.append((src.group(1), i)); continue
                    if src:                                  # renamed pass-through: other_col AS col
                        passes.append((src.group(1), i, src.group(2).lower())); continue
                    note = ""
                    nm = re.search(r"--\s*(.+)$", lines[i])
                    if nm:
                        note = nm.group(1).strip()
                    k = j - 1
                    while not note and k >= 0 and j - k <= 3 and lines[k].strip().startswith("--"):
                        note = lines[k].strip().lstrip("-").strip(); k -= 1
                    computed = {"table": table, "file": rel, "line": i + 1, "expr": re.sub(r"\s+", " ", expr)[:300], "note": note[:200], "kind": "computed"}
                    break
                if re.search(r"(?i)\b(create|alter|drop)\b", code) or ddl_re.search(code):
                    continue                                 # a column definition, not a select
                mm = ref_re.search(code)
                if mm and not cond_re.search(code):
                    passes.append((mm.group(1), i))
            if computed:
                t = self.text[rel]
                src_tabs = sorted({self.base(x) for x in re.findall(r"(?i)\b(?:from|join)\s+((?:\{\{\s*params\.[A-Za-z0-9_]+\s*\}\}\.)?[a-z_][\w.]*)", t)
                                   if "." in x or "{{" in x})[:8]
                computed["sources"] = src_tabs
                return [computed]
            for p in passes[:4]:
                alias, i = p[0], p[1]
                newcol = p[2] if len(p) > 2 else col
                nxt = al.get((alias or "").lower()) if alias else None
                cands = [nxt] if nxt else [x for x in dict.fromkeys(al.values()) if x != table][:4]
                for tb in cands:
                    if not tb or tb == table:
                        continue
                    chain = self.resolve(newcol, tb, _depth + 1, _seen, _prefer=rel)
                    if chain:
                        return [{"table": table, "file": rel, "line": i + 1, "expr": f"{(alias + '.') if alias else ''}{newcol}", "kind": "from " + tb}] + chain
            for a in stars[:4]:
                tb = al.get(a)
                if tb and tb != table:
                    chain = self.resolve(col, tb, _depth + 1, _seen, _prefer=rel)
                    if chain:
                        return [{"table": table, "file": rel, "line": 0, "expr": f"{a}.*", "kind": "from " + tb}] + chain
        return []


def ikg_comments(root: Path, files: Iterable[str], wanted: set) -> Dict[str, str]:
    """column -> the comment written next to its definition in a CREATE TABLE / select list (`col type, -- meaning`)."""
    out = {}
    for rel in files:
        if not rel.lower().endswith(".sql"):
            continue
        try:
            text = (root / rel).read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for m in re.finditer(r"(?im)^\s*,?\s*([a-z_][a-z0-9_]*)\b[^\n]*?--\s*([^\n]{6,160})$", text):
            c = m.group(1).lower()
            if c in wanted and c not in out and not m.group(2).strip().lower().startswith(("and ", "or ", "select", "from", "where")):
                out[c] = m.group(2).strip()
    return out


# --------------------------------------------------------------------------------------------- columns from DDL in code
DDL_RE = re.compile(r"(?is)\bcreate\s+(?:unlogged\s+)?table\s+(?:if\s+not\s+exists\s+)?([\w{}.\"]+)\s*\(")
CONSTRAINT_RE = re.compile(r"(?i)^\s*(constraint|primary\s+key|foreign\s+key|unique|check|like|distributed|partition)\b")


def ddl_tables(root: Path, files: Iterable[str]) -> Dict[str, dict]:
    """Persistent tables with an explicit column list in a CREATE TABLE of the repository:
    {schema-qualified name as written (params -> {x}): {table, file, columns: [{name, type, comment}]}}. Temp tables and
    CREATE TABLE ... AS SELECT are skipped. Lets a pack know the columns of its tables without Greenplum access."""
    out: Dict[str, dict] = {}
    for rel in files:
        if not rel.lower().endswith(".sql"):
            continue
        try:
            t = BLOCK_COMMENT_RE.sub(" ", (root / rel).read_text(encoding="utf-8", errors="replace"))
        except OSError:
            continue
        for m in DDL_RE.finditer(t):
            pre = t[max(0, m.start() - 40): m.start()].lower()
            if "temp" in t[m.start(): m.end()].lower() or "temporary" in pre:
                continue
            i, depth, j = m.end(), 1, m.end()
            while j < len(t) and depth:
                ch = t[j]
                if ch == "(":
                    depth += 1
                elif ch == ")":
                    depth -= 1
                j += 1
            body = t[i: j - 1]
            if re.match(r"(?is)\s*select\b", body):
                continue
            cols, buf, d = [], "", 0
            lines = body.splitlines()
            for ln in lines:                                # split on top-level commas, keep the trailing comment of each column
                code, _, com = ln.partition("--")
                for ch in code:
                    if ch == "(":
                        d += 1
                    elif ch == ")":
                        d -= 1
                    if ch == "," and d == 0:
                        cols.append((buf, "")); buf = ""
                    else:
                        buf += ch
                if com.strip() and cols and not buf.strip():
                    cols[-1] = (cols[-1][0], com.strip(" -"))
                elif com.strip():
                    buf += f" --{com}"
                buf += " "
            if buf.strip():
                cols.append((buf, ""))
            parsed = []
            for c, com in cols:
                c, _, inline_com = c.partition("--")
                c = c.strip()
                if not c or CONSTRAINT_RE.match(c):
                    continue
                mm = re.match(r"\"?([A-Za-z_][A-Za-z0-9_]*)\"?\s+(.+)$", c, re.S)
                if not mm:
                    continue
                parsed.append({"name": mm.group(1).lower(), "type": re.sub(r"\s+", " ", mm.group(2)).strip()[:60],
                               "comment": (com or inline_com).strip(" -")[:200]})
            if len(parsed) < 2:
                continue
            name = re.sub(r"\{\{\s*params\.([A-Za-z0-9_]+)\s*\}\}", lambda x: "{" + x.group(1).lower() + "}", m.group(1)).strip('"').lower()
            out.setdefault(name, {"table": name.split(".")[-1], "file": rel, "columns": parsed})
    return out


# --------------------------------------------------------------------------------------------- docs
def doc_descriptions(root: Path, files: Iterable[str]) -> Dict[str, List[dict]]:
    """insight id -> business descriptions found in documents (tables of `si_x ... description`, md files about one id)."""
    out: Dict[str, List[dict]] = defaultdict(list)
    for rel in files:
        low = rel.lower()
        if not (low.endswith((".md", ".txt")) or "/docs/" in low or "business_description" in low):
            continue
        try:
            text = (root / rel).read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if len(text) > 400000:
            continue
        for ln in text.splitlines():
            m = re.match(r"^\s*\d*\s*(si_[a-z0-9_]+)\s+(\d+)?\s+(.{12,240})$", ln.strip(), re.I)
            if m:
                out[m.group(1).lower()].append({"file": rel, "text": m.group(3).strip(), "suppression_weeks": m.group(2) or ""})
        stem = Path(rel).stem.lower()
        if stem.startswith("si_"):
            body = re.sub(r"\s+", " ", text)[:1500]
            out[stem].append({"file": rel, "text": body})
    return out


# --------------------------------------------------------------------------------------------- the catalogue
class Catalogue:
    def __init__(self, roots: Dict[str, Path], files: Dict[str, List[str]], say=print, registration: Optional[dict] = None):
        self.roots, self.files, self.say = roots, files, say
        self.registration = registration or {}

    def build(self) -> dict:  # noqa: C901
        rules: Dict[str, dict] = {}
        odm_files = [f for f in self.files.get("odm", []) if f.lower().endswith(".sql")]
        odm_root = self.roots.get("odm")
        n_parsed = Counter()
        for rel in odm_files:
            try:
                text = (odm_root / rel).read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            if "insight_type" not in text.lower() and not ID_RE.search(text):
                continue
            for r in parse_odm_file(rel, text):
                n_parsed[r["parser"]] += 1
                if r["id"] in rules:                       # the same id written by two files / statements: keep both files
                    rules[r["id"]].setdefault("also_in", []).append(rel)
                    continue
                rules[r["id"]] = r

        # NLG: rule yml (narratives), ref_table_columns (extra NLG columns + SQL), group layout (product / label), mentions
        nlg_root = self.roots.get("nlg")
        nlg = {}
        refcols, layout, mentions = {}, {}, defaultdict(list)
        for rel in self.files.get("nlg", []):
            low = rel.lower()
            if not low.endswith((".yml", ".yaml")):
                continue
            try:
                text = (nlg_root / rel).read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            if "/rules/" in low and Path(rel).stem.lower().startswith("si_"):
                rec = parse_nlg_rule(rel, text)
                nlg.setdefault(rec["id"], rec)
            elif "/ref_table_columns/" in low and Path(rel).stem.lower().startswith("si_"):
                y = _yaml(text) or {}
                if isinstance(y, dict):
                    refcols[Path(rel).stem.lower()] = {"file": rel, "columns": [str(c) for c in (y.get("columns") or [])],
                                                       "join_keys": [str(c) for c in (y.get("join_keys") or [])],
                                                       "sql": re.sub(r"\s+", " ", str(y.get("sql") or ""))[:900]}
            elif "insight_group_layout" in low:
                y = _yaml(text) or {}
                if isinstance(y, dict) and isinstance(y.get("insight_types"), dict):
                    for iid, cfg in y["insight_types"].items():
                        cfg = cfg if isinstance(cfg, dict) else {}
                        layout[str(iid).lower()] = {"file": rel, "products": y.get("products") or [], "category": y.get("category", ""),
                                                    "sub_category": y.get("sub_category", ""), "group": y.get("group_name_label", ""),
                                                    "section": y.get("insight_section", ""), "label": cfg.get("insight_type_label", ""),
                                                    "materiality": cfg.get("materiality"), "suppression_weeks": cfg.get("suppression_weeks") or {}}
        all_ids = set(rules) | set(nlg)
        for sysname in ("nlg", "ikg"):
            root = self.roots.get(sysname)
            if root is None:
                continue
            for rel in self.files.get(sysname, []):
                low = rel.lower()
                if "/rules/" in low or "/ref_table_columns/" in low or "insight_group_layout" in low or not low.endswith((".py", ".sql", ".yml", ".yaml", ".json", ".md")):
                    continue
                try:
                    text = (root / rel).read_text(encoding="utf-8", errors="replace").lower()
                except OSError:
                    continue
                for iid in set(ID_RE.findall(text)) & all_ids:
                    if len(mentions[iid]) < 8:
                        mentions[iid].append(f"{sysname}:{rel}")

        docs: Dict[str, List[dict]] = defaultdict(list)
        for sysname in ("nlg", "odm", "ikg"):
            root = self.roots.get(sysname)
            if root is not None:
                for k, v in doc_descriptions(root, self.files.get(sysname, [])).items():
                    docs[k].extend({**d, "file": f"{sysname}:{d['file']}"} for d in v)

        # every column any rule touches (ODM + NLG placeholders + NLG extra columns) -> meaning + IKG producers
        wanted = set()
        for r in rules.values():
            wanted.update(r.get("columns", []))
            k = r.get("key", "")
            if re.fullmatch(r"[a-z_][a-z0-9_]*", k or ""):
                wanted.add(k)
        for r in nlg.values():
            wanted.update(p.lower() for p in r.get("placeholders", []))
        for r in refcols.values():
            wanted.update(c.lower() for c in r.get("columns", []))
        wanted = {w for w in wanted if len(w) > 2 and not w.startswith("p__")}
        ikg_root = self.roots.get("ikg")
        producers, comments = {}, {}
        lineage: Dict[str, dict] = {}
        if ikg_root is not None:
            producers = ikg_producers(ikg_root, self.files.get("ikg", []), wanted)
            comments = ikg_comments(ikg_root, self.files.get("ikg", []), wanted)
            for tinfo in ddl_tables(ikg_root, self.files.get("ikg", [])).values():
                for col in tinfo["columns"]:
                    if col["name"] in wanted and col["comment"] and col["name"] not in comments and len(col["comment"]) > 8:
                        comments[col["name"]] = col["comment"]
            lin = Lineage(ikg_root, self.files.get("ikg", []))
            homes: Dict[str, Counter] = defaultdict(Counter)
            for r in rules.values():
                for c in set(r.get("columns", [])) | ({r["key"]} if r.get("key") else set()):
                    for t in r.get("tables", []):
                        homes[c][Lineage.base(t)] += 1
                for c in (nlg.get(r["id"]) or {}).get("placeholders", []):
                    for t in r.get("tables", []):
                        homes[c.lower()][Lineage.base(t)] += 1
            for c, tabs in homes.items():
                if c not in wanted:
                    continue
                for t, _ in tabs.most_common(2):
                    chain = lin.resolve(c, t)
                    if chain:
                        lineage[c] = {"table": t, "chain": chain}
                        break
            self.say(f"column lineage: {len(lineage)} of {len(homes)} rule columns traced from their profile table to the computing script")

        # feature meanings: IKG comment > NLG sentence > decoded name
        usage: Dict[str, List[str]] = defaultdict(list)
        for r in nlg.values():
            for col in r.get("placeholders", []):
                for k, vals in r.get("narratives", {}).items():
                    for v in vals:
                        for s in _sentences_with(v, col):
                            if s not in usage[col.lower()] and len(usage[col.lower()]) < 3:
                                usage[col.lower()].append(s)
        glossary = {c: humanize(c) for c in wanted}
        eng = English(glossary) if exp is not None else None

        # assemble the rules
        out_rules: Dict[str, dict] = {}
        for iid in sorted(all_ids):
            o = rules.get(iid)
            n = nlg.get(iid)
            rec = {"id": iid}
            if o:
                conds = []
                for p in o.get("_preds", []):
                    try:
                        conds.append({"sql": _unmask(p.sql(dialect="postgres")), "text": eng.pred(p) if eng else ""})
                    except Exception:  # noqa: BLE001
                        conds.append({"sql": _unmask(p.sql()), "text": ""})
                for c in o.get("_raw_conditions", []):
                    conds.append({"sql": c, "text": ""})
                folder = o["file"].rsplit("/", 1)[0]
                rec["odm"] = {"file": o["file"], "folder": folder, "target": o["target"], "key": o["key"], "metric": o["metric"],
                              "attribute": o["attribute"], "category": o["category"], "tables": o["tables"], "conditions": conds,
                              "depends_on": o["depends_on"], "also_in": o.get("also_in", []), "union_branches": o.get("union_branches", 1),
                              "registration": (self.registration.get(folder) or {}).get("rule", "")[:300]}
                rec["target"] = o["target"]
                rec["domain"] = folder.split("/")[-1]
            if n:
                rec["nlg"] = {"file": n["file"], "title": n["title"], "narrative": n["narrative"], "placeholders": n["placeholders"]}
                rec.setdefault("target", n["file"].split("/rules/")[-1].split("/")[0] if "/rules/" in n["file"] else "")
                rec.setdefault("domain", n["file"].rsplit("/", 1)[0].split("/rules/")[-1].replace("/", "_"))
            if iid in refcols:
                rec.setdefault("nlg", {})["extra_columns"] = refcols[iid]
            if iid in layout:
                rec.setdefault("nlg", {})["layout"] = layout[iid]
            if mentions.get(iid):
                rec["mentioned_in"] = mentions[iid]
            if docs.get(iid):
                rec["docs"] = docs[iid][:3]
            title = (n or {}).get("title") or (layout.get(iid) or {}).get("label") or humanize(iid[3:] if iid.startswith("si_") else iid).capitalize()
            rec["title"] = title
            cols = set((o or {}).get("columns", [])) | {p.lower() for p in (n or {}).get("placeholders", [])} | {c.lower() for c in (refcols.get(iid) or {}).get("columns", [])}
            cols = sorted(c for c in cols if c in wanted)
            rec["features"] = cols
            rec["description"] = self._describe(rec)
            rec["status"] = "rule+narrative" if o and n else ("rule only (no NLG yml found)" if o else "narrative only (no ODM rule found)")
            out_rules[iid] = rec

        features = {}
        used_by = defaultdict(list)
        for iid, r in out_rules.items():
            for c in r["features"]:
                used_by[c].append(iid)
        for c in sorted(wanted):
            if c not in used_by:
                continue
            ln = lineage.get(c)
            prods = []
            if ln:
                last = ln["chain"][-1]
                prods = [{"file": last["file"], "line": last["line"], "expr": last["expr"], "note": last.get("note", ""), "sources": last.get("sources", []),
                          "passthrough": False, "via": " <- ".join(f"{x['table']}" for x in ln["chain"])}]
            else:
                prods = [p for p in producers.get(c, []) if not p["passthrough"]][:2]
            note = (ln["chain"][-1].get("note") if ln else "") or ""
            features[c] = {"name": c, "meaning": comments.get(c) or note or glossary[c], "decoded": glossary[c], "comment": comments.get(c, ""),
                           "narrative_usage": usage.get(c, [])[:2], "producers": prods, "lineage": ln["chain"] if ln else [],
                           "home_table": ln["table"] if ln else "", "used_by": sorted(used_by[c])[:40], "used_by_count": len(used_by[c])}

        domains = defaultdict(list)
        for iid, r in out_rules.items():
            domains[r.get("domain") or "other"].append(iid)
        entities = defaultdict(lambda: {"rules": 0, "keys": Counter(), "tables": Counter()})
        for r in out_rules.values():
            t = r.get("target") or "unknown"
            entities[t]["rules"] += 1
            o = r.get("odm") or {}
            if o.get("key"):
                entities[t]["keys"][o["key"]] += 1
            for tb in o.get("tables", []):
                entities[t]["tables"][_short(tb)] += 1
        ent = {k: {"rules": v["rules"], "key_columns": [x for x, _ in v["keys"].most_common(3)], "main_tables": [x for x, _ in v["tables"].most_common(5)],
                   "meaning": ENTITY_KEYS.get(k, "")} for k, v in sorted(entities.items(), key=lambda kv: -kv[1]["rules"])}
        stats = {"rules": len(out_rules), "odm_rules": len(rules), "nlg_narratives": len(nlg), "linked": sum(1 for r in out_rules.values() if r["status"] == "rule+narrative"),
                 "odm_only": sum(1 for r in out_rules.values() if r["status"].startswith("rule only")),
                 "nlg_only": sum(1 for r in out_rules.values() if r["status"].startswith("narrative only")),
                 "features": len(features), "features_with_producer": sum(1 for f in features.values() if f["producers"]),
                 "features_with_lineage": sum(1 for f in features.values() if f.get("lineage")),
                 "conditions": sum(len((r.get("odm") or {}).get("conditions", [])) for r in out_rules.values()),
                 "conditions_in_english": sum(1 for r in out_rules.values() for c in (r.get("odm") or {}).get("conditions", []) if c.get("text")),
                 "with_group_layout": sum(1 for r in out_rules.values() if (r.get("nlg") or {}).get("layout")),
                 "with_docs": sum(1 for r in out_rules.values() if r.get("docs")), "parsers": dict(n_parsed),
                 "systems": sorted(self.roots)}
        self.say(f"business rules: {stats['rules']} insights ({stats['linked']} rule+narrative, {stats['odm_only']} rule only, {stats['nlg_only']} narrative only), "
                 f"{stats['features']} features ({stats['features_with_producer']} traced to IKG code), {stats['conditions_in_english']}/{stats['conditions']} conditions in English")
        return {"rules": out_rules, "features": features, "domains": {k: sorted(v) for k, v in sorted(domains.items())}, "entities": ent, "stats": stats}

    @staticmethod
    def _describe(rec: dict) -> str:
        o, n = rec.get("odm") or {}, rec.get("nlg") or {}
        parts = [rec["title"] + "."]
        lay = n.get("layout") or {}
        if lay:
            parts.append(f"Shown in {', '.join(map(str, lay.get('products') or []))} under {lay.get('category', '')} / {lay.get('group', '') or lay.get('sub_category', '')}.")
        for d in rec.get("docs", [])[:1]:
            parts.append("Business description: " + d["text"][:400])
        if n.get("narrative"):
            parts.append("Advisor reads: " + n["narrative"][:500])
        if o:
            conds = [c["text"] or c["sql"] for c in o.get("conditions", [])]
            parts.append(f"Fires for each {o.get('target') or 'target'} ({o.get('key')}) in {', '.join(_short(t) for t in o.get('tables', [])[:3])} when "
                         + "; ".join(conds[:12]) + ("." if conds else " (no WHERE conditions)."))
            if o.get("depends_on"):
                parts.append("Depends on insights: " + ", ".join(o["depends_on"]) + ".")
        return " ".join(parts)


# --------------------------------------------------------------------------------------------- pack outputs
def rule_card(r: dict, features: dict) -> str:
    o, n = r.get("odm") or {}, r.get("nlg") or {}
    L = [f"# {r['id']} - {r['title']}", "", f"target: **{r.get('target', '')}**  ·  domain: {r.get('domain', '')}  ·  {r['status']}", "", r["description"], ""]
    if o:
        L += ["## ODM rule (when it fires)", f"file: `{o['file']}`" + (f"  (also in {', '.join(o['also_in'])})" if o.get("also_in") else ""),
              f"writes: insight_type `{r['id']}`, target_type `{o['target']}`, target_key `{o['key']}`, metric {o['metric'].get('name', '')} = `{o['metric'].get('value', '')}`"
              + (f", attribute {o['attribute'].get('name')} = `{o['attribute'].get('value')}`" if o.get("attribute", {}).get("name") else ""),
              f"reads: {', '.join('`' + t + '`' for t in o['tables'])}"]
        if o.get("registration"):
            L.append(f"registered by: {o['registration']}")
        L.append("conditions (all must hold):")
        for c in o["conditions"]:
            L.append(f"- {c['text'] or c['sql']}  \n  `{c['sql']}`")
        if o.get("depends_on"):
            L.append(f"depends on: {', '.join(o['depends_on'])}")
        L.append("")
    if n:
        L += ["## NLG narrative (what the advisor reads)"]
        if n.get("file"):
            L.append(f"file: `{n['file']}`")
        if n.get("narrative"):
            L.append(f"> {n['narrative']}")
        if n.get("placeholders"):
            L.append(f"placeholders: {', '.join(n['placeholders'])}")
        if n.get("extra_columns"):
            ec = n["extra_columns"]
            L.append(f"extra NLG columns ({ec['file']}): {', '.join(ec['columns'])}  \n  `{ec['sql'][:400]}`")
        lay = n.get("layout") or {}
        if lay:
            L.append(f"layout ({lay['file']}): products {lay.get('products')}, category {lay.get('category')}, group {lay.get('group')}, label {lay.get('label')}, suppression {lay.get('suppression_weeks')}")
        L.append("")
    if r.get("features"):
        L += ["## Features used (IKG)"]
        for c in r["features"][:30]:
            f = features.get(c) or {}
            prod = f.get("producers") or []
            p = prod[0] if prod else None
            line = f"- `{c}` - {f.get('meaning', '')}"
            if p:
                line += f"; computed in `{p['file']}`:{p['line']} as `{p['expr'][:160]}`" + (f" from {', '.join(p['sources'][:3])}" if p.get("sources") else "")
                if p.get("via") and " <- " in p["via"]:
                    line += f"  (lineage: {p['via']})"
            L.append(line)
        L.append("")
    if r.get("docs"):
        L += ["## Documents"] + [f"- {d['file']}: {d['text'][:300]}" for d in r["docs"]] + [""]
    if r.get("mentioned_in"):
        L += ["## Also referenced in", ", ".join(f"`{x}`" for x in r["mentioned_in"])]
    return "\n".join(L).strip() + "\n"


def write(out_dir: Path, cat: dict, rule_cards: str = "single") -> dict:
    """facts/business.json + cards; rule_cards = "single" (all rule cards in cards/rules.md, one `# <id> - <title>` section
    each - one file compresses 3x better than 600 small ones) | "files" (cards/rule/<id>.md). Returns counts."""
    out_dir = Path(out_dir)
    (out_dir / "facts").mkdir(parents=True, exist_ok=True)
    (out_dir / "facts" / "business.json").write_text(json.dumps(cat, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    cards = out_dir / "cards"
    (cards / "domain").mkdir(parents=True, exist_ok=True)
    if rule_cards == "files":
        (cards / "rule").mkdir(parents=True, exist_ok=True)
        for iid, r in cat["rules"].items():
            (cards / "rule" / f"{iid}.md").write_text(rule_card(r, cat["features"]), encoding="utf-8")
    else:
        (cards / "rules.md").write_text("\n".join(rule_card(r, cat["features"]) for r in cat["rules"].values()), encoding="utf-8")
    for d, ids in cat["domains"].items():
        L = [f"# domain {d} - {len(ids)} insight(s)", "", "| insight | target | title | conditions |", "|---|---|---|---|"]
        for iid in ids:
            r = cat["rules"][iid]
            conds = "; ".join((c["text"] or c["sql"]) for c in (r.get("odm") or {}).get("conditions", [])[:4])
            L.append(f"| {iid} | {r.get('target', '')} | {r['title']} | {conds[:300].replace('|', '/')} |")
        (cards / "domain" / f"{re.sub(r'[^a-z0-9_]+', '_', d.lower())}.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    st = cat["stats"]
    L = ["# Business rules (insights) catalogue", "",
         f"{st['rules']} insights: {st['linked']} with ODM rule + NLG narrative, {st['odm_only']} rule only, {st['nlg_only']} narrative only; "
         f"{st['features']} features ({st['features_with_producer']} traced to the IKG script that computes them).", "",
         "Every insight's card: `cards/rules.md` (one `# <id> - <title>` section each). How the systems connect: IKG builds the profile tables (features) -> ODM rule `si_*` checks the features and writes an insight row "
         "(insight_type, target_type, target_key, metric) -> NLG yml `si_*.yml` turns it into the advisor's sentence -> products deliver it.", "",
         "## Entities (target types)", "", "| target | insights | key | main tables | meaning |", "|---|---|---|---|---|"]
    for k, v in cat["entities"].items():
        L.append(f"| {k} | {v['rules']} | {', '.join(v['key_columns'])} | {', '.join(v['main_tables'][:3])} | {v['meaning']} |")
    L += ["", "## Domains", ""] + [f"- **{d}** ({len(ids)}): " + ", ".join(f"{i} ({cat['rules'][i]['title'][:40]})" for i in ids[:6]) + (" ..." if len(ids) > 6 else "") for d, ids in cat["domains"].items()]
    (cards / "business_rules.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    return {"rules": len(cat["rules"]), "domains": len(cat["domains"]), "features": len(cat["features"])}


def items(cat: dict) -> List[dict]:
    out = []
    for iid, r in cat["rules"].items():
        o, n = r.get("odm") or {}, r.get("nlg") or {}
        text = (f"{r['description']}\ntarget: {r.get('target', '')} key: {o.get('key', '')} domain: {r.get('domain', '')}\n"
                f"features: {', '.join(r['features'][:40])}\ntables: {', '.join(o.get('tables', []))}\n"
                f"odm: {o.get('file', '')}\nnlg: {n.get('file', '')}\nconditions sql: " + " AND ".join(c["sql"] for c in o.get("conditions", []))[:1500])
        out.append({"kind": "business_rule", "ref": iid, "title": f"insight {iid}: {r['title']}", "text": text[:4000]})
    for c, f in cat["features"].items():
        p = (f.get("producers") or [{}])[0]
        text = (f"{f['meaning']} (decoded: {f['decoded']})\nadvisor sentence: {' | '.join(f.get('narrative_usage', []))}\n"
                f"computed in: {p.get('file', '')} as {p.get('expr', '')}\nsources: {', '.join(p.get('sources', [])[:4])}\n"
                f"used by {f['used_by_count']} insight(s): {', '.join(f['used_by'][:20])}")
        out.append({"kind": "feature", "ref": c, "title": f"feature {c}: {f['decoded']}", "text": text})
    for d, ids in cat["domains"].items():
        out.append({"kind": "domain", "ref": d, "title": f"insight domain {d}",
                    "text": "\n".join(f"{i}: {cat['rules'][i]['title']}" for i in ids)[:4000]})
    for k, v in cat["entities"].items():
        out.append({"kind": "entity", "ref": k, "title": f"entity {k}",
                    "text": f"{v['meaning']}\n{v['rules']} insights; key columns {', '.join(v['key_columns'])}; main tables {', '.join(v['main_tables'])}"})
    return out


def graph_parts(cat: dict) -> Tuple[List[dict], List[dict]]:
    nodes, edges = {}, []

    def node(kind, key, **a):
        k = f"{kind}:{key}"
        nodes.setdefault(k, {"id": k, "kind": kind, "name": key, **a})
        return k
    for iid, r in cat["rules"].items():
        rn = node("insight", iid, title=r["title"], target=r.get("target", ""))
        o, n = r.get("odm") or {}, r.get("nlg") or {}
        if o.get("file"):
            edges.append({"from": node("script", "odm:" + o["file"]), "rel": "defines_rule", "to": rn})
        if n.get("file"):
            edges.append({"from": node("script", "nlg:" + n["file"]), "rel": "narrates", "to": rn})
        for t in o.get("tables", []):
            edges.append({"from": rn, "rel": "reads", "to": node("table", _short(t))})
        for c in r["features"]:
            edges.append({"from": rn, "rel": "uses_feature", "to": node("feature", c)})
        for d in o.get("depends_on", []):
            edges.append({"from": rn, "rel": "depends_on", "to": node("insight", d)})
        edges.append({"from": node("domain", r.get("domain") or "other"), "rel": "contains", "to": rn})
        edges.append({"from": rn, "rel": "targets", "to": node("entity", r.get("target") or "unknown")})
    for c, f in cat["features"].items():
        fn = node("feature", c, meaning=f["meaning"][:120])
        for p in f.get("producers", [])[:2]:
            edges.append({"from": node("script", "ikg:" + p["file"]), "rel": "computes", "to": fn, "line": p["line"]})
    return list(nodes.values()), edges
