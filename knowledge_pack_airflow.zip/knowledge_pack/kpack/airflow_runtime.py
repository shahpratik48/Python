"""Airflow runtime helpers - same conventions as the existing IKG DAG code:

  * running inside Airflow = the airflow package imports AND AIRFLOW_CTX_DAG_ID is set (a developer machine with airflow
    installed is NOT treated as an Airflow run)
  * GitLab token        : Airflow Variable  GENESIS_DDLC_IKG_GIT_SECRET      (local: environment variable of the same name, else prompt)
  * Greenplum           : Airflow Variable  IKG_POSTGRES_CONN_ID -> Connection id (INSIGHT_PIPELINE_RUNNER_DB_CONNECTOR)
                          -> PostgresHook(...).get_connection(): host, port, schema (db), login, password
  * e-mail              : airflow.utils.email.send_email(to, subject, html_content, files=[...]) - Airflow's own SMTP config
  * Dev / Prod label    : conf webserver.base_url compared with Variables AIRFLOW_UAT_URL / AIRFLOW_PROD_URL
All names come from config/kpack_config.yaml (airflow.variables / airflow.connections); nothing is hard-coded here.
"""
from __future__ import annotations

import logging
import os
from typing import List, Optional

log = logging.getLogger("kpack.airflow")

try:
    from airflow.models import Variable  # type: ignore
    _HAS_AIRFLOW = True
except Exception:  # noqa: BLE001
    Variable = None  # type: ignore
    _HAS_AIRFLOW = False


def is_running_in_airflow() -> bool:
    return _HAS_AIRFLOW and bool(os.environ.get("AIRFLOW_CTX_DAG_ID"))


def _var(name: str, default: str = "") -> str:
    if not name or not _HAS_AIRFLOW:
        return default
    try:
        return Variable.get(name, default_var=default) or default
    except Exception:  # noqa: BLE001
        return default


def load_airflow_secrets(cfg) -> dict:
    """Inside Airflow: Variables / Connection -> process memory (kpack.config secret store) and cfg.greenplum. Returns what was found."""
    from .config import put_secret
    af = cfg.get("airflow") or {}
    vars_ = af.get("variables") or {}
    conns = af.get("connections") or {}
    found = {}
    if not is_running_in_airflow():
        return found
    for secret_name, var_key in (("llm_api_key", "azure_openai_api_key"), ("embeddings_api_key", "embeddings_api_key"), ("git_read_token", "git_read_token"),
                                 ("greenplum_password", "greenplum_password"), ("email_password", "email_password")):
        v = _var(str(vars_.get(var_key) or ""))
        if v:
            put_secret(secret_name, v); found[secret_name] = f"Variable {vars_.get(var_key)}"
    # Greenplum from the Connection named by a Variable (IKG_POSTGRES_CONN_ID) or directly by id
    conn_id = _var(str(vars_.get("greenplum_conn_id_var") or ""), "") or str(conns.get("greenplum_conn_id") or "")
    if conn_id:
        try:
            try:
                from airflow.providers.postgres.hooks.postgres import PostgresHook  # type: ignore
                conn = PostgresHook(postgres_conn_id=conn_id).get_connection(conn_id)
            except Exception:  # noqa: BLE001  (provider not installed)
                from airflow.hooks.base import BaseHook  # type: ignore
                conn = BaseHook.get_connection(conn_id)
            g = cfg["greenplum"]
            g.update({"host": conn.host or g.get("host"), "port": int(conn.port) if conn.port else g.get("port", 5432),
                      "database": conn.schema or g.get("database"), "user": conn.login or g.get("user")})
            if conn.password:
                put_secret("greenplum_password", conn.password)
            found["greenplum"] = f"Connection {conn_id} ({conn.host}/{conn.schema} as {conn.login})"
        except Exception as e:  # noqa: BLE001
            log.warning("could not resolve Greenplum credentials from Airflow connection %s: %s", conn_id, e)
    return found


def env_label(cfg) -> str:
    """' - Dev' / ' - Prod' from the webserver base_url vs the AIRFLOW_UAT_URL / AIRFLOW_PROD_URL Variables (as the IKG DAGs do)."""
    if not is_running_in_airflow():
        return ""
    try:
        from airflow.configuration import conf  # type: ignore
        base_url = conf.get("webserver", "base_url")
        af = (cfg.get("airflow") or {}).get("variables") or {}
        if base_url == _var(str(af.get("uat_url_var") or "AIRFLOW_UAT_URL")):
            return " - Dev"
        if base_url == _var(str(af.get("prod_url_var") or "AIRFLOW_PROD_URL")):
            return " - Prod"
    except Exception:  # noqa: BLE001
        pass
    return ""


def send_email_airflow(recipients: List[str], subject: str, html_body: str, attachments: List[str], cc: Optional[List[str]] = None) -> dict:
    """airflow.utils.email.send_email with file attachments - Airflow's SMTP settings, no password handling here."""
    if not recipients:
        return {"sent": False, "reason": "no recipients"}
    try:
        from airflow.utils.email import send_email  # type: ignore
        send_email(to=recipients, subject=subject, html_content=html_body, files=[a for a in attachments if a], cc=cc or None)
        return {"sent": True, "subject": subject, "to": recipients, "via": "airflow.utils.email", "attachments": [os.path.basename(a) for a in attachments]}
    except Exception as e:  # noqa: BLE001
        log.error("failed to send email via airflow.utils.email.send_email: %s", e)
        return {"sent": False, "reason": f"{type(e).__name__}: {str(e)[:200]}", "subject": subject}
