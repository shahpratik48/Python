"""Builds one System Knowledge Pack (IKG / ODM / NLG) from three inputs - repository, Greenplum tables, skills documents -
into ONE deliverable per system - output/<system>/<system>_pack.zip (complete, self-contained, root folder <system>_pack/;
replaced atomically on every good build). Nothing else is written to output/. The dated unzipped build, latest.json and any
degraded build live under data/versions/<system>/ (history for the diff, build.keep_versions):

  VERSION.txt        system, version, repo ref, health (for humans)     build_config.yaml   the (secret-free) config used
  manifest.json      what is in the pack, versions, sources, counts, build cost
  health.json        warnings (missing inputs, failed stages, unexplained folders / tables), stage timings
  pack.md            the human index: how the system works, folder guide, DAGs, tables, rules, glossary, what changed
  raw/repo/...       the code files (so consumers can open any script without git access)
  raw/skills/...     the skills / standards / glossary documents as text
  raw/gp/...         the gp.md table lists
  facts/structure.json    DAGs, registration map, folder map, companions, table lineage, params, symbols, file list
  facts/tables.json       column-level description of every table (+ sample rows when allowed)
  facts/skills.json       the documents (text + sections)
  derived/derived.json    conventions, checkable rules, definitions, folder purposes, how-tos, table semantics, bridge
  items.jsonl             every knowledge item (the retrieval units, incl. code chunks with contextual headers)
  index/                  BM25 + vector store over the items (hybrid search, reciprocal-rank fusion)
  graph.json              knowledge graph: tables / columns / scripts / folders / DAGs / params / terms and their relations
  cards/                  prompt-ready markdown context cards (folder, table, dag, howto, system)
  exemplars.json          one canonical file per folder (few-shot example for code generation)
  synonyms.json           query expansion table (business words -> technical tokens)
  facts/business.json     business rules (insights) traced across IKG -> ODM -> NLG: conditions (SQL + English), features,
                          the IKG scripts computing them (column lineage), narratives, layout; cards/rule/, cards/domain/
  store.sqlite            optional metadata tables copied from Greenplum
"""
from __future__ import annotations

import hashlib
import json
import os
import logging
import re
import shutil
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Dict, List, Optional

from agiledev.repoindex import RepoIndex

from .config import PACKAGE_ROOT, have_secret, secret, system_cfg
from .derived import Derived, rules_sanity
from . import enrich
from .index import PackIndex
from .inputs import copy_metadata_tables, describe_tables, open_greenplum, parse_gp_folder, read_skills
from .structure import RepoStructure

log = logging.getLogger("kpack.builder")


def _sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()[:16]


def _link_or_copy(src: Path, dst: Path) -> None:
    """A hard link (instant, no bytes copied - thousands of small files on a network disk took minutes), a copy when the
    two folders are on different file systems."""
    try:
        if dst.exists():
            dst.unlink()
        os.link(src, dst)
    except OSError:
        shutil.copyfile(src, dst)


def _rel(cfg, rel: str) -> Path:
    p = Path(rel)
    return p if p.is_absolute() else PACKAGE_ROOT / p


class PackBuilder:
    def __init__(self, cfg, system: str, progress: Optional[Callable[[str], None]] = None, repo_path: str = "", use_llm: bool = True,
                 llm=None, allow_prompt: bool = False, peers: Optional[dict] = None):
        self.cfg = cfg
        self.system = system
        self.sc = system_cfg(cfg, system)
        self.say = progress or (lambda m: log.info(m))
        self.repo_path = repo_path or str(self.sc.get("repo_path") or "")
        self.peers = peers                      # shared by the builds of one run: {"roots": {sys: (root, files)}, "events": {sys: Event}}
        self.business = None
        self.use_llm = use_llm
        self.llm = llm
        self.allow_prompt = allow_prompt
        self.b = cfg.build
        self.warnings: List[str] = []
        self.timings: Dict[str, float] = {}
        self.version = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        self.out_root = _rel(cfg, self.b.get("output_dir", "output")) / system            # deliverable only: <system>_pack.zip
        self.work_root = _rel(cfg, self.b.get("versions_dir", "data/versions")) / system  # dated builds, latest.json (history / diff)
        self.out = self.work_root / self.version
        self.gp = None

    # ------------------------------------------------------------------ utilities
    def _stage(self, name: str):
        builder = self

        class _S:
            def __enter__(self_):
                self_.t0 = time.time(); builder.say(f"[{builder.system}] {name} ...")
                return self_

            def __exit__(self_, et, ev, tb):
                builder.timings[name] = round(time.time() - self_.t0, 1)
                if ev is not None:
                    builder.warnings.append(f"{name} failed: {type(ev).__name__}: {str(ev)[:300]}")
                    log.exception("stage %s failed", name)
                return True                      # a failed stage degrades the pack, it does not abort the build
        return _S()

    def _write(self, rel: str, data) -> None:
        p = self.out / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(data, (dict, list)):
            p.write_text(json.dumps(data, indent=1, ensure_ascii=False, default=str), encoding="utf-8")
        else:
            p.write_text(str(data), encoding="utf-8")

    def _llm(self):
        if not self.use_llm:
            return None
        if self.llm is not None:
            return self.llm
        if not (have_secret("llm_api_key") or secret(self.cfg, "llm_api_key", allow_prompt=self.allow_prompt)):
            self.warnings.append("no Azure OpenAI key - derived layer and dense index skipped (BM25 index only)")
            return None
        from agiledev.llm import LLM
        self.llm = LLM(self.cfg, _rel(self.cfg, self.cfg.storage.get("llm_cache_dir", "data/cache/llm")))
        self._own_llm = True                      # this build owns the client (Airflow task): it prints the usage at the end
        return self.llm

    # ------------------------------------------------------------------ stages
    def fetch_repo(self, dest_name: str = "") -> Path:
        """dest_name: staging folder name under the repo cache (default the system name; peers use their own)."""
        if self.repo_path:
            p = _rel(self.cfg, self.repo_path)
            if p.is_file() and p.suffix.lower() in (".txt", ".dump", ".log"):
                p = self._split_dump(p)          # a text dump (****name****** / ****repo/path****** headers + code) -> real files (filtered by _stage_local below)
            if not p.is_dir():
                raise FileNotFoundError(f"repo path {p} not found")
            return self._stage_local(p, dest_name)
        from agiledev.gitclient import GitClient
        token = secret(self.cfg, "git_read_token", allow_prompt=self.allow_prompt)
        if not token:
            raise RuntimeError("no git read token and no --repo-path: cannot fetch the repository")
        url = self.sc["gitlab_url"].rstrip("/") + "/" + self.sc["project_path"].strip("/")
        gc = GitClient(url, token, ssl_verify=self.cfg.git.get("ssl_verify", True), default_provider=self.cfg.git.get("default_provider", "gitlab"))
        ref = self.sc.get("branch") or gc.project_info().get("default_branch", "main")
        dest = _rel(self.cfg, self.cfg.storage.get("repo_cache_dir", "data/cache/repos")) / (dest_name or self.system)
        r = gc.download(dest, ref, list(self.b.get("code_extensions", ["py", "sql"])), int(self.b.get("max_file_kb", 800)),
                        int(self.b.get("max_files", 12000)), cache_hours=0.5, refresh=True, subpath=self.sc.get("subpath", ""), progress=self.say)
        self.repo_ref = ref
        self.say(f"repository ready: {r.get('files')} files at {ref}")
        return self._prune_excluded_folders(Path(r["path"]))

    def _folder_excludes(self):
        """Folders (and glob-like path patterns) left OUT of the pack: build.exclude_folders (global) + systems.<sys>.exclude_folders.
        A plain name matches any path segment (`logs`), a pattern with `/` or `*` matches the repository-relative path (`dags/ikg/archive/*`)."""
        import fnmatch
        names, pats = set(), []
        for x in list(self.b.get("exclude_folders") or []) + list(self.sc.get("exclude_folders") or []):
            x = str(x).strip().strip("/")
            if not x:
                continue
            if "/" in x or "*" in x:
                pats.append(x)
            else:
                names.add(x)

        def why(rel: str) -> str:
            """'' = kept, else the rule that leaves the file out (for the report)."""
            parts = rel.split("/")
            for p in parts[:-1]:
                if p in names:
                    return f"folder '{p}'"
                if p.startswith(".") and p not in (".", ".."):
                    return f"hidden folder '{p}'"
            for pat in pats:
                if fnmatch.fnmatch(rel, pat) or fnmatch.fnmatch(rel, pat.rstrip("/*") + "/*"):
                    return f"pattern '{pat}'"
            return ""

        def excluded(rel: str) -> bool:
            return bool(why(rel))
        excluded.why = why
        return excluded

    INTERNAL = (".git_checkout", ".git", ".agiledev_ref", ".agiledev_index.pkl", ".dump_stamp")

    def _report_excluded(self, reasons) -> None:
        """One line per exclusion rule with the file count and the top folders, also kept in health.json."""
        from collections import Counter, defaultdict
        if not reasons:
            return
        by = Counter(r for _, r in reasons)
        tops = defaultdict(Counter)
        for rel, r in reasons:
            tops[r]["/".join(rel.split("/")[:3])] += 1
        lines = [f"{n} file(s) by {r}: " + ", ".join(f"{f} ({c})" for f, c in tops[r].most_common(4)) for r, n in by.most_common()]
        self.excluded_detail = lines
        self.say("left out of the pack - " + " | ".join(lines))

    def _prune_excluded_folders(self, root: Path) -> Path:
        """Removes the excluded folders from a staged repository copy (GitLab download or dump) so no later stage sees them."""
        excluded = self._folder_excludes()
        removed, reasons = 0, []
        for f in sorted(root.rglob("*"), key=lambda x: -len(x.parts)):
            rel = f.relative_to(root).as_posix()
            if rel.split("/")[0] in self.INTERNAL or f.name.startswith(".agiledev"):
                continue                                     # the git working copy / markers of the download: not repository content
            if f.is_file():
                r = excluded.why(rel)
                if r:
                    f.unlink(); removed += 1; reasons.append((rel, r))
        for d in sorted((d for d in root.rglob("*") if d.is_dir()), key=lambda x: -len(x.parts)):
            if d.relative_to(root).parts[0] in self.INTERNAL:
                continue
            if not any(d.iterdir()):
                d.rmdir()
        self._report_excluded(reasons)
        self.excluded_files = removed
        return root

    def _split_dump(self, dump: Path) -> Path:
        """Reconstructs a repository folder from a text dump where every file appears as `****name******`, then
        `****<repo>/<path>******`, then the code (optionally every line followed by an inserted blank line), files separated
        by a dashed line. Written once to data/cache/repos/<system>_dump/ and reused while the dump is unchanged."""
        dest = _rel(self.cfg, self.cfg.storage.get("repo_cache_dir", "data/cache/repos")) / f"{self.system}_dump"
        stamp = dest / ".dump_stamp"
        sig = f"{dump.stat().st_size}|{dump.stat().st_mtime}"
        if dest.exists() and stamp.exists() and stamp.read_text() == sig:
            return dest
        if dest.exists():
            shutil.rmtree(dest)
        hdr = re.compile(r"^\*{4}(.+?)\*{6}\s*$")
        files: Dict[str, List[str]] = {}
        cur = None
        for ln in dump.read_text(encoding="utf-8", errors="replace").splitlines():
            m = hdr.match(ln)
            if m:
                name = [x for x in re.split(r"\*{4,}", m.group(1)) if x.strip()][-1].strip()   # "name**********repo/path" on one line -> the path
                if "/" in name:               # the second header carries the path; the first only the file name
                    cur = name; files[cur] = []
                elif cur is None or files.get(cur):
                    cur = name; files[cur] = []
                continue
            if ln.startswith("-----------------------------------------------------------------"):
                cur = None; continue
            if cur is not None:
                files[cur].append(ln)
        if any("/" in k for k in files):      # name-only headers are just labels for the path header that follows: drop their empty entries
            files = {k: v for k, v in files.items() if "/" in k or any(l.strip() for l in v)}
        root_prefix = None
        firsts = {k.split("/", 1)[0] for k in files if "/" in k}
        if len(firsts) == 1 and all("/" in k for k in files):
            root_prefix = firsts.pop() + "/"
        n = 0
        for path, lines in files.items():
            body = lines
            if len(lines) > 4 and sum(1 for l in lines if l.strip() == "") / len(lines) > 0.45:
                body, run = [], 0            # the dump interleaves a blank after every line: drop them, keep real blank lines
                for l in lines:
                    if l.strip() == "":
                        run += 1
                        if run == 2:
                            body.append("")
                    else:
                        run = 0; body.append(l.rstrip())
            rel = path[len(root_prefix):] if root_prefix and path.startswith(root_prefix) else path
            if not rel or rel.endswith("/"):
                continue
            f = dest / rel
            f.parent.mkdir(parents=True, exist_ok=True)
            f.write_text("\n".join(body).rstrip() + "\n", encoding="utf-8")
            n += 1
        stamp.write_text(sig)
        self.say(f"dump {dump.name}: {n} files reconstructed into {dest}")
        return dest

    def _stage_local(self, src: Path, dest_name: str = "") -> Path:
        """A local repository copy is filtered like a GitLab download: code extensions only, size cap, no build / vendor folders."""
        exts = tuple("." + e.lower().lstrip(".") for e in self.b.get("code_extensions", ["py", "sql"]))
        max_kb, max_files = int(self.b.get("max_file_kb", 800)), int(self.b.get("max_files", 12000))
        excluded = self._folder_excludes()
        dest = _rel(self.cfg, self.cfg.storage.get("repo_cache_dir", "data/cache/repos")) / (dest_name or self.system)
        if dest.resolve() == Path(src).resolve() or dest.resolve() in Path(src).resolve().parents:
            dest = dest.with_name(dest.name + "_staged")       # never stage onto (and delete) the source itself
        if dest.exists():
            shutil.rmtree(dest)
        n, skipped, left_out = 0, 0, 0
        reasons = []
        for f in sorted(src.rglob("*")):
            if not f.is_file():
                continue
            rel = f.relative_to(src)
            if rel.parts[0] in self.INTERNAL or f.name.startswith(".agiledev"):
                continue
            r = excluded.why(rel.as_posix())
            if r:
                left_out += 1; reasons.append((rel.as_posix(), r))
                continue
            if not f.name.lower().endswith(exts) or f.stat().st_size > max_kb * 1024 or n >= max_files:
                skipped += 1
                continue
            d = dest / rel
            d.parent.mkdir(parents=True, exist_ok=True)
            _link_or_copy(f, d)
            n += 1
        (dest / ".agiledev_ref").write_text(f"local\n{time.time()}")
        self.excluded_files = left_out
        self.say(f"local repository copy {src}: {n} code files staged ({skipped} skipped by extension / size, {left_out} in excluded folders)")
        self._report_excluded(reasons)
        return dest

    def build(self) -> dict:
        t_all = time.time()
        self.out.mkdir(parents=True, exist_ok=True)
        self.repo_ref = self.sc.get("branch") or "local"
        structure, tables, skills, derived, items = {}, {}, {}, {}, []
        meta_status, repo_root, idx = {}, None, None

        with self._stage("repository"):
            repo_root = self.fetch_repo()
            idx = RepoIndex(repo_root, self.sc.get("repo_name") or repo_root.name, max_files=int(self.b.get("max_files", 12000)))
            self.say(f"indexed {len(idx.files)} files")
            if self.peers is not None:
                self.peers["roots"][self.system] = (repo_root, list(idx.files))
                ev = self.peers.get("events", {}).get(self.system)
                if ev is not None:
                    ev.set()

        with self._stage("structure"):
            if idx is not None:
                structure = RepoStructure(idx, self.system).analyse()
                excl = self._table_excludes()
                if excl:
                    before = len(structure["tables"])
                    keep_pats = [re.compile(x, re.I) for x in self.b.get("keep_used_tables_matching", [])]
                    drop, kept, by = set(), [], {}
                    for t, v in structure["tables"].items():
                        hits = [x for x in excl if x.search(t)]
                        if not hits:
                            continue
                        readers = set(v.get("read_by", [])) - set(v.get("written_by", []))
                        keepable = {k.pattern for k in keep_pats}
                        if "." in t and readers and all(h.pattern in keepable for h in hits):
                            kept.append(t); continue        # a persistent table other scripts read (x_temp, x_test): real pipeline data
                        hit = next((h for h in hits if h.pattern not in keepable), hits[0])
                        drop.add(t); by[hit.pattern] = by.get(hit.pattern, 0) + 1
                    structure["tables"] = {t: v for t, v in structure["tables"].items() if t not in drop}
                    structure["script_tables"] = {rel: [t for t in ts if t not in drop] for rel, ts in structure["script_tables"].items()}
                    for f in structure["folders"].values():
                        f["tables_built_here"] = [t for t in f.get("tables_built_here", []) if t not in drop]
                    self.table_exclusions = {"dropped_by_pattern": by, "kept_because_used": sorted(kept)}
                    if drop:
                        self.say(f"{len(drop)} table(s) ignored for {self.system}: " + ", ".join(f"{n} by {p!r}" for p, n in by.items())
                                 + (f"; {len(kept)} kept although they match (persistent and read by other scripts): {', '.join(kept[:8])}" if kept else ""))
                self._write("facts/structure.json", structure)
                self.say(f"{len(structure['dags'])} DAG files, {len(structure['folders'])} folders, {len(structure['tables'])} tables referenced, "
                         f"{len(structure['companion_patterns'])} companion patterns")

        with self._stage("tables"):
            wanted = parse_gp_folder(_rel(self.cfg, self.sc["gp_folder"]), self.sc.get("schema", ""))
            for p in [_rel(self.cfg, self.sc["gp_folder"])]:
                if p.is_dir():
                    for f in p.iterdir():
                        if f.is_file():
                            (self.out / "raw" / "gp").mkdir(parents=True, exist_ok=True)
                            shutil.copyfile(f, self.out / "raw" / "gp" / f.name)
            seen = {f"{t['schema']}.{t['table']}" for t in wanted}
            if self.b.get("describe_tables_from_code", True):
                excl = self._table_excludes()
                skipped_t = 0
                for t in structure.get("tables", {}):
                    if "." in t and t not in seen and structure["tables"][t].get("written_by"):
                        if any(x.search(t) for x in excl):
                            skipped_t += 1; continue
                        s, _, n = t.partition(".")
                        wanted.append({"schema": s, "table": n, "description": "", "source": "code"}); seen.add(t)
                if skipped_t:
                    self.say(f"{skipped_t} code tables skipped by exclude_table_patterns (dated snapshots / backups / sandboxes)")
            # code tables written with a schema parameter ({ikg_schema}.x): resolved through schema_params so Greenplum can describe them
            smap = {str(k).lower(): v for k, v in (self.cfg.get("schema_params") or {}).items()}
            tparams = self._table_params()
            resolved = []
            for t in wanted:
                tm = re.fullmatch(r"\{\{?\s*(?:params\.)?([a-z0-9_]+)\s*\}?\}", str(t.get("table", "")).lower())
                if tm:
                    if tm.group(1) not in tparams:
                        continue
                    t = dict(t, table=tparams[tm.group(1)], code_name=t.get("code_name") or f"{t.get('schema', '')}.{t['table']}")
                sch = str(t.get("schema", ""))
                m = re.fullmatch(r"\{\{?\s*(?:params\.)?([a-z0-9_]+)\s*\}?\}", sch.lower())
                if m:
                    if m.group(1) not in smap:
                        continue
                    t = dict(t, schema=smap[m.group(1)], code_name=f"{sch}.{t['table']}")
                resolved.append(t)
            # most useful first: gp.md tables, then profile tables, then by number of reading scripts
            gp_listed = [t for t in resolved if t.get("source") != "code"]
            code_t = [t for t in resolved if t.get("source") == "code"]
            st_t = structure.get("tables", {})

            def _uses(t):
                v = st_t.get(t.get("code_name") or f"{t['schema']}.{t['table']}", {})
                return ("_profile" not in t["table"], -len(v.get("read_by", [])))
            code_t.sort(key=_uses)
            resolved = gp_listed + code_t
            cap = int(self.b.get("max_described_tables", 1500))
            if len(resolved) > cap:
                self.warnings.append(f"{len(resolved) - cap} code table(s) beyond build.max_described_tables={cap} not described")
            wanted = resolved[:cap]
            self.gp = open_greenplum(self.cfg, secret(self.cfg, "greenplum_password", allow_prompt=self.allow_prompt))
            if self.gp is None:
                self.warnings.append(f"no Greenplum password - {len(wanted)} tables listed but not described (columns unknown)")
                tables = {f"{t['schema']}.{t['table']}": dict(t, columns=[], described=False) for t in wanted}
            else:
                self.say(f"Greenplum: {self.gp.test()}")
                tables = describe_tables(self.gp, wanted, int(self.b.get("sample_rows", 3)), self.say, sqlite_mode=bool(self.cfg.greenplum.get("sqlite_path")),
                                         sample_limit=int(self.b.get("sample_tables_max", 200)))
                for t in tables.values():
                    t["described"] = not t.get("error") and bool(t.get("columns"))
                missing = [k for k, v in tables.items() if not v["described"]]
                self.missing_tables = missing
                if missing:
                    self.warnings.append(f"{len(missing)} tables could not be described (not found / no access): {', '.join(missing[:10])}")
            # columns from the CREATE TABLE statements of the code for every table Greenplum did not describe (offline packs, new tables)
            if repo_root is not None and self.b.get("columns_from_ddl", True):
                from .business import ddl_tables
                ddl = ddl_tables(repo_root, idx.files if idx else [])
                smap = {str(k).lower(): v for k, v in (self.cfg.get("schema_params") or {}).items()}
                added = 0
                for name, info in ddl.items():
                    sch, _, base = name.rpartition(".")
                    real = f"{smap.get(sch.strip('{}'), sch)}.{base}" if sch else base
                    hit = tables.get(real) or tables.get(name)
                    if hit and hit.get("columns"):
                        continue
                    tables[real] = dict(hit or {"schema": real.rpartition(".")[0], "table": base, "description": ""},
                                        columns=info["columns"], described=False, columns_from=f"code DDL {info['file']}", code_name=name)
                    added += 1
                if added:
                    self.say(f"{added} table(s) with columns read from CREATE TABLE statements in the code (not described from Greenplum)")
            self._write("facts/tables.json", tables)

        with self._stage("metadata_tables"):
            names = list(self.b.get("metadata_tables") or [])
            if names and self.gp is not None:
                meta_status = copy_metadata_tables(self.gp, names, self.out / "store.sqlite", int(self.b.get("metadata_max_rows", 20000)), self.say,
                                                   sqlite_mode=bool(self.cfg.greenplum.get("sqlite_path")))
            elif names:
                self.warnings.append("metadata tables configured but Greenplum not available")

        with self._stage("standards_generated"):
            # the 100 % automatic standards file: written into skills/<sys>/ BEFORE the skills documents are read, so this
            # build already consumes it (conventions, rules, glossary are extracted from it like from any other document)
            try:
                from .standards import write_facts_doc
                gen = write_facts_doc(self.cfg, self.system, structure, "", self.say, tables=tables,       # no version inside: same code = same text = model cache hit
                                      read=(lambda rel: idx.read(rel, 20000)) if idx else None)
                self.generated_standards = str(gen)
                self.say(f"generated {gen.name} -> {gen.parent}")
            except Exception as e:  # noqa: BLE001
                self.generated_standards = ""
                self.warnings.append(f"generated standards file not written: {type(e).__name__}: {str(e)[:160]}")

        with self._stage("skills"):
            folders = [_rel(self.cfg, self.sc["skills_folder"]), _rel(self.cfg, self.cfg.get("common_skills_folder", "skills/common"))]
            gen_path = Path(getattr(self, "generated_standards", "") or "")
            if gen_path.exists() and not any(gen_path.parent == f for f in folders):
                folders.append(gen_path.parent)            # fallback location: still an input
            skills = read_skills(folders)
            if not skills:
                self.warnings.append(f"no skills documents found in {self.sc['skills_folder']} / common - conventions layer empty")
            self._write("facts/skills.json", skills)
            for folder in folders:
                if folder.is_dir():
                    for f in folder.rglob("*"):
                        if f.is_file() and not f.name.startswith(".") and "-checkpoint." not in f.name \
                                and not any(part.startswith(".") for part in f.relative_to(folder).parts[:-1]):
                            d = self.out / "raw" / "skills" / folder.name / f.relative_to(folder)
                            d.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(f, d)

        with self._stage("raw_repo"):
            if repo_root is not None:
                dst = self.out / "raw" / "repo"
                for rel in idx.files:
                    s = repo_root / rel
                    d = dst / rel
                    d.parent.mkdir(parents=True, exist_ok=True)
                    _link_or_copy(s, d)

        with self._stage("business"):
            bc = dict(self.cfg.get("business") or {})
            try:
                self._business_stage(bc, idx, repo_root, structure)
            except Exception as e:  # noqa: BLE001
                log.exception("business rules layer")
                self.business = None
                self.warnings.append(f"business rules layer skipped ({type(e).__name__}: {str(e)[:160]}) - the rest of the pack is complete")

        with self._stage("derived"):
            llm = self._llm() if self.b.get("derived_layer", True) else None
            dv = Derived(self.cfg, llm, self.say, budget_usd=float(self.b.get("max_llm_cost_usd", 3.0)))
            facts = dv.facts(structure, tables)
            derived = {"facts": facts, "knowledge": {}, "repo": {}, "data": {}, "bridge": {}, "model_layer": bool(llm)}
            if llm is not None:
                headers = {f: v.get("header_samples", []) for f, v in structure.get("folders", {}).items()}
                described = {k: v for k, v in tables.items() if v.get("described")}
                derived.update(dv.run_all(skills, facts, headers, described, structure, lambda rel: idx.read(rel, 4000) if idx else "", self.system))
                derived["model_calls"] = dv.calls
                self.warnings.extend(dv.errors)
            else:
                self.warnings.append("derived layer: model not used (facts only) - run with the Azure key for conventions / purposes / semantics")
            # rule catalogues in yaml are exact: they go in as checkable rules regardless of the model (and win over a
            # model-extracted rule with the same id)
            from .inputs import yaml_rules
            yrules = yaml_rules(skills)
            if yrules:
                kn = derived.setdefault("knowledge", {})
                kn.setdefault("definitions", []); kn.setdefault("conventions", []); kn.setdefault("notes_for_coder", [])
                dropped = len(kn.get("rules", []) or [])
                kn["rules"] = yrules                          # the team's catalogue is authoritative: model-guessed rules are not added next to it
                self.say(f"{len(yrules)} checkable rules read from yaml rule files ({', '.join(sorted({r['source'].split(' (')[0] for r in yrules}))})"
                         + (f"; {dropped} model-derived rule(s) dropped in favour of the catalogue" if dropped else ""))
            else:
                for r in (derived.get("knowledge") or {}).get("rules", []) or []:
                    r["origin"] = "model"                      # no catalogue: model-derived rules stay, marked (Agile Dev Assist treats them as advisory)
            self._write("derived/derived.json", derived)

        with self._stage("enrich"):
            read = (lambda rel: idx.read(rel, 200000)) if idx else (lambda rel: "")
            enrich_counts = enrich.write_all(self.out, structure, tables, derived, skills, read, self.system)
            if self.business:
                from .business import graph_parts
                g = json.loads((self.out / "graph.json").read_text(encoding="utf-8"))
                have = {n["id"] for n in g["nodes"]}
                bn, be = graph_parts(self.business)
                g["nodes"].extend(n for n in bn if n["id"] not in have)
                g["edges"].extend(be)
                from collections import Counter as _C
                g["counts"] = {"nodes": len(g["nodes"]), "edges": len(g["edges"]), "by_kind": dict(_C(n["kind"] for n in g["nodes"]))}
                (self.out / "graph.json").write_text(json.dumps(g, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
                enrich_counts["graph"] = g["counts"]
                from .business import BUSINESS_SYNONYMS
                syn = json.loads((self.out / "synonyms.json").read_text(encoding="utf-8"))
                for w, adds in BUSINESS_SYNONYMS.items():
                    syn[w] = (list(adds) + [x for x in syn.get(w, []) if x not in adds])[:8]     # business words first
                (self.out / "synonyms.json").write_text(json.dumps(syn, ensure_ascii=False, indent=0), encoding="utf-8")
            self.say(f"graph {enrich_counts['graph']['nodes']} nodes / {enrich_counts['graph']['edges']} edges, {enrich_counts['cards']} cards, "
                     f"{enrich_counts['exemplars']} exemplars, {enrich_counts['synonyms']} synonyms")

        previous = self._previous()
        with self._stage("standards"):
            try:
                from .standards import BuildView, build_generated, drift
                prev_struct = {}
                if previous and previous.get("path") and (Path(previous["path"]) / "facts" / "structure.json").exists():
                    prev_struct = json.loads((Path(previous["path"]) / "facts" / "structure.json").read_text(encoding="utf-8"))
                policy = ""
                for cand in (_rel(self.cfg, self.sc["skills_folder"]) / f"{self.system}_policy.md",):
                    if cand.exists():
                        policy = cand.read_text(encoding="utf-8", errors="replace")
                changes = drift(structure, prev_struct)
                view = BuildView(structure, derived, {"version": self.version, "repo": {"name": self.sc.get("repo_name")}})
                (self.out / "cards").mkdir(parents=True, exist_ok=True)
                (self.out / "cards" / "standards.md").write_text(build_generated(view, self.system, policy, changes), encoding="utf-8")
                self.standards_changes = changes
                self.say(f"standards.md generated ({'policy file included' if policy else 'no policy file'}; {sum(len(v) for v in changes.values())} structural change(s) since the previous build)")
            except Exception as e:  # noqa: BLE001
                self.warnings.append(f"standards.md not generated: {type(e).__name__}: {str(e)[:160]}")

        with self._stage("items"):
            items = self.items(structure, tables, skills, derived, idx)
            if self.business:
                from .business import items as bitems
                items.extend(bitems(self.business))
            if self.b.get("index_chunks", True):
                ch = enrich.chunks(structure, derived, read, self.system, int(self.b.get("max_chunks_per_file", 40)))
                items.extend(ch)
                self.say(f"{len(ch)} code chunks (contextual headers)")
            compact = bool(self.b.get("compact_items", True))
            from .index import compact_item
            (self.out / "items.jsonl").write_text("\n".join(json.dumps(compact_item(i) if compact else i, ensure_ascii=False, separators=(",", ":")) for i in items), encoding="utf-8")
            if compact:
                self._verify_compact(items)
            self.say(f"{len(items)} knowledge items")

        with self._stage("index"):
            emb = dict(self.cfg.get("embeddings") or {})
            emb["enabled"] = bool(emb.get("enabled", True)) and bool(self.b.get("embeddings", True))
            pi = PackIndex(self.out, emb, llm=self._llm() if emb["enabled"] else None,
                           cache_dir=_rel(self.cfg, self.cfg.storage.get("data_dir", "data")) / "cache" / "embeddings",
                           write_bm25=bool(self.b.get("ship_bm25", False)))
            st = pi.build(items, self.say)
            if not st.get("dense"):
                self.warnings.append(f"dense index not built ({st.get('error') or 'embeddings off'}) - BM25 search only")

        manifest = self.manifest(structure, tables, skills, derived, items, meta_status, previous)
        with self._stage("pack_md"):
            self._write("pack.md", self.pack_md(manifest, structure, tables, skills, derived, previous))
        health = {"status": "ok" if not any("failed" in w for w in self.warnings) else "degraded", "warnings": self.warnings,
                  "left_out_files": getattr(self, "excluded_detail", []), "table_exclusions": getattr(self, "table_exclusions", {}),
                  "tables_not_found_in_greenplum": getattr(self, "missing_tables", []),
                  "stage_seconds": self.timings, "total_seconds": round(time.time() - t_all, 1)}
        self._write("health.json", health)
        manifest["health"] = health["status"]
        self._write("manifest.json", manifest)
        # the ONE deliverable per system: output/<system>/<system>_pack.zip - a complete, self-contained pack (root folder
        # <system>_pack/, version inside VERSION.txt + manifest.json). The dated folder is kept only for the diff / history.
        zip_path = self.out_root / f"{self.system}_pack.zip"
        promoted = health["status"] == "ok" or not self.b.get("promote_only_if_ok", True)
        with self._stage("zip"):
            self._write("VERSION.txt", f"{self.system} pack {self.version}\nbuilt {manifest['built_at']}\nrepo {manifest['repo']['project']} @ {manifest['repo']['ref']}\nhealth {health['status']}\n")
            self._write("build_config.yaml", self._config_snapshot())
            self.out_root.mkdir(parents=True, exist_ok=True)
            tmp = self.out_root / f".{self.system}_pack.zip.part"
            with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED, compresslevel=int(self.b.get("zip_level", 6))) as zf:
                for p in sorted(self.out.rglob("*")):
                    if p.is_file() and p.name != "bm25_cache.npz":     # consumer-side cache, never shipped
                        # vectors (.npy) do not compress: stored as they are, which also makes the zip step far faster
                        ct = zipfile.ZIP_STORED if p.suffix in (".npy", ".npz", ".zip", ".png", ".jpg", ".sqlite") else zipfile.ZIP_DEFLATED
                        zf.write(p, f"{self.system}_pack/{p.relative_to(self.out)}", compress_type=ct)
            manifest["zip_mb"] = round(tmp.stat().st_size / 1048576, 2)
            with zipfile.ZipFile(tmp) as zf:                              # what takes the space (shown in the log and health.json)
                comp = {}
                for zi in zf.infolist():
                    parts = zi.filename.split("/")[1:]
                    k = "/".join(parts[:2]) if parts and parts[0] in ("raw", "cards", "facts", "index") and len(parts) > 1 else (parts[0] if parts else "")
                    comp[k] = comp.get(k, 0) + zi.compress_size
            comp = {k: round(v / 1048576, 2) for k, v in sorted(comp.items(), key=lambda kv: -kv[1]) if v > 50000}
            self.zip_composition = comp
            manifest["zip_composition_mb"] = comp
            self.say(f"zip {manifest['zip_mb']} MB - largest parts (MB): " + ", ".join(f"{k} {v}" for k, v in list(comp.items())[:8]))
            if promoted:
                tmp.replace(zip_path)                                   # atomic: readers never see a half-written zip
                manifest["zip"] = str(zip_path)
                (self.work_root / "latest.json").write_text(json.dumps({"system": self.system, "version": self.version, "path": str(self.out), "zip": str(zip_path),
                                                                       "built_at": manifest["built_at"], "health": health["status"]}, indent=1), encoding="utf-8")
            else:
                held = self.work_root / f"{self.system}_pack_{self.version}_degraded.zip"
                tmp.replace(held)
                manifest["zip"] = str(held)
                self.warnings.append(f"build degraded: {zip_path.name} and latest.json NOT replaced (previous good pack kept); this build saved as {held.name}")
                health["warnings"] = self.warnings
                self._write("health.json", health)
            manifest["promoted"] = promoted
            self._write("manifest.json", manifest)
            self._prune()
        if self.gp is not None:
            self.gp.close()
        if self.llm is not None and getattr(self, "_own_llm", False):
            try:
                self.say("\n" + self.llm.usage_by_model_text())
            except Exception:  # noqa: BLE001
                pass
        slow = sorted(self.timings.items(), key=lambda kv: -kv[1])[:6]
        self.say(f"[{self.system}] stage seconds: " + ", ".join(f"{k} {v}" for k, v in slow))
        self.say(f"[{self.system}] pack {self.version} {'ready' if promoted else 'built but NOT promoted'}: {manifest.get('zip')} ({manifest.get('zip_mb')} MB, {health['status']}, {health['total_seconds']}s)")
        if not promoted:
            self.say(f"[{self.system}] NOT promoted because: " + "; ".join(w for w in self.warnings if "failed" in w)[:500])
        return {"manifest": manifest, "health": health, "path": str(self.out), "zip": manifest.get("zip", ""), "promoted": promoted}

    def _verify_compact(self, items) -> None:
        """Format 2 stores code chunks as spans into raw/repo: prove every chunk reads back identically, else keep its text."""
        from .index import load_items
        back = {f"{i['kind']}|{i['ref']}": i.get("text", "") for i in load_items(self.out)}
        bad = [i for i in items if i.get("kind") == "chunk" and back.get(f"chunk|{i['ref']}") != i.get("text")]
        if bad:
            from .index import compact_item
            badk = {i["ref"] for i in bad}
            (self.out / "items.jsonl").write_text("\n".join(json.dumps(i if (i.get("kind") == "chunk" and i["ref"] in badk) else compact_item(i), ensure_ascii=False, separators=(",", ":")) for i in items), encoding="utf-8")
            self.say(f"{len(bad)} chunk(s) kept inline (span did not read back identically)")
        else:
            self.say(f"items written in compact format: {sum(1 for i in items if i.get('kind') == 'chunk')} code chunks as spans into raw/repo (verified)")

    def _business_stage(self, bc, idx, repo_root, structure) -> None:
        if not (bc.get("enabled", True) and idx is not None):
            return
        from .business import Catalogue, write as bwrite
        roots, files = self._business_inputs(repo_root, idx, bc)
        reg = structure.get("registration", {}) if self.system == "odm" else self._peer_registration(roots.get("odm"), files.get("odm"))
        shared = self.peers if (self.peers is not None and set(roots) >= set(bc.get("systems", ["ikg", "odm", "nlg"]))) else None
        if shared is not None:
            import threading
            lock = shared.setdefault("business_lock", threading.Lock())
            with lock:                                # one catalogue per run: the three packs carry the same trace
                if "business" not in shared:
                    shared["business"] = self._catalogue(roots, files, reg)
            self.business = json.loads(json.dumps(shared["business"], default=str))
        else:
            self.business = self._catalogue(roots, files, reg)
        missing = [s for s in bc.get("systems", ["ikg", "odm", "nlg"]) if s not in roots]
        if missing:
            self.warnings.append(f"business rules traced without {', '.join(missing)} (repository not available) - the trace is partial")
        self.business["stats"]["built_from"] = {s: str(roots[s]) for s in roots}
        c = bwrite(self.out, self.business, rule_cards=str(self.b.get("rule_cards", "single")))
        self.say(f"business layer: {c['rules']} rule cards, {c['domains']} domain cards, {c['features']} features")


    # ------------------------------------------------------------------ peers (the other systems, for the business trace)
    def _business_inputs(self, repo_root: Path, idx, bc: dict):
        """Repository roots + file lists of every system in business.systems: this build's own, then for each peer
        (1) the root registered by a concurrent build of the same run, (2) systems.<peer>.repo_path (folder / dump),
        (3) a GitLab download (sparse by systems.<peer>.subpath) into data/cache/repos/<peer>_peer_<system>."""
        import threading
        roots, files = {self.system: repo_root}, {self.system: list(idx.files)}
        wait_s = float(bc.get("peer_wait_seconds", 600))
        for peer in bc.get("systems", ["ikg", "odm", "nlg"]):
            if peer == self.system or peer not in (self.cfg.get("systems") or {}):
                continue
            got = None
            if self.peers is not None:
                ev = self.peers.get("events", {}).get(peer)
                if isinstance(ev, threading.Event):
                    ev.wait(wait_s)
                got = self.peers["roots"].get(peer)
            if got is None and bc.get("fetch_peers", True):
                try:
                    root = self._shared_peer(peer, float(bc.get("peer_cache_minutes", 60)))
                    got = (root, [p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file() and not p.name.startswith(".")])
                except Exception as e:  # noqa: BLE001
                    self.warnings.append(f"peer repository {peer} not available for the business trace: {type(e).__name__}: {str(e)[:160]}")
            if got:
                roots[peer], files[peer] = Path(got[0]), list(got[1])
        return roots, files

    def _shared_peer(self, peer: str, max_age_min: float) -> Path:
        """One staged copy of a peer repository per machine (data/cache/repos/<peer>_peer), reused for max_age_min minutes:
        the three Airflow tasks of one evening fetch each repository once, not twice. A file lock serialises the fetch."""
        base = _rel(self.cfg, self.cfg.storage.get("repo_cache_dir", "data/cache/repos"))
        base.mkdir(parents=True, exist_ok=True)
        dest = base / f"{peer}_peer"
        lock = open(base / f".{peer}_peer.lock", "w")
        try:
            try:
                import fcntl
                fcntl.flock(lock, fcntl.LOCK_EX)
            except ImportError:                                       # Windows notebook: single process, no lock needed
                pass
            ref = dest / ".agiledev_ref"
            if ref.exists() and (time.time() - ref.stat().st_mtime) < max_age_min * 60:
                self.say(f"[peer {peer}] reusing the copy staged {int((time.time() - ref.stat().st_mtime) / 60)} min ago")
                return dest
            pb = PackBuilder(self.cfg, peer, progress=lambda m: self.say(f"[peer {peer}] {m}"), use_llm=False, allow_prompt=False)
            root = pb.fetch_repo(dest_name=f"{peer}_peer")
            if not (Path(root) / ".agiledev_ref").exists():
                (Path(root) / ".agiledev_ref").write_text(f"peer\n{time.time()}")
            return Path(root)
        finally:
            lock.close()

    def _catalogue(self, roots, files, reg):
        """The business catalogue, cached on disk by the content of the three repositories (data/cache/business/<hash>.json):
        built once per code version, whichever build (or Airflow task) gets there first."""
        from .business import Catalogue
        h = hashlib.sha1()
        for sname in sorted(roots):
            for rel in sorted(files[sname]):
                fp = Path(roots[sname]) / rel
                try:
                    h.update(f"{sname}/{rel}".encode()); h.update(fp.read_bytes())
                except OSError:
                    continue
        # (the registration map is derived from the ODM code hashed above, so it is not part of the key)
        h.update(b"business-v3")
        cdir = _rel(self.cfg, self.cfg.storage.get("data_dir", "data")) / "cache" / "business"
        cdir.mkdir(parents=True, exist_ok=True)
        cp = cdir / f"{h.hexdigest()[:20]}.json"
        if cp.exists():
            try:
                cat = json.loads(cp.read_text(encoding="utf-8"))
                self.say(f"business rules: catalogue reused from cache ({cat['stats']['rules']} insights, code unchanged)")
                return cat
            except Exception:  # noqa: BLE001
                pass
        cat = Catalogue(roots, files, self.say, registration=reg).build()
        try:
            tmp = cp.with_suffix(".part")
            tmp.write_text(json.dumps(cat, default=str), encoding="utf-8"); tmp.replace(cp)
            for old in sorted(cdir.glob("*.json"), key=lambda x: x.stat().st_mtime)[:-6]:
                old.unlink()
        except OSError:
            pass
        return json.loads(json.dumps(cat, default=str))

    def _peer_registration(self, root, files) -> dict:
        """How the ODM rule folders are registered in the ODM DAGs (for the rule cards of the IKG / NLG packs)."""
        if not root:
            return {}
        try:
            pidx = RepoIndex(Path(root), "odm", max_files=int(self.b.get("max_files", 12000)))
            return RepoStructure(pidx, "odm").analyse().get("registration", {})
        except Exception:  # noqa: BLE001
            return {}

    def _table_params(self) -> Dict[str, str]:
        """Table names held in parameters ({{params.ODM_TABLE}}): table_params.<name> = {airflow_variable, default}.
        Inside Airflow the Variable wins; elsewhere the default (what the DAGs use in production)."""
        out = {}
        for k, v in (self.cfg.get("table_params") or {}).items():
            v = v if isinstance(v, dict) else {"default": v}
            val = ""
            if v.get("airflow_variable") and os.environ.get("AIRFLOW_CTX_DAG_ID"):
                try:
                    from airflow.models import Variable
                    val = Variable.get(v["airflow_variable"], default_var="") or ""
                except Exception:  # noqa: BLE001
                    val = ""
            out[str(k).lower()] = str(val or v.get("default") or "")
        return {k: v for k, v in out.items() if v}

    def _table_excludes(self):
        """Compiled exclude patterns: the global build.exclude_table_patterns plus this system's own (systems.<sys>.exclude_table_patterns)."""
        pats = list(self.b.get("exclude_table_patterns") or []) + list(self.sc.get("exclude_table_patterns") or [])
        out = []
        for x in pats:
            try:
                out.append(re.compile(str(x), re.I))
            except re.error:
                self.warnings.append(f"bad exclude_table_patterns entry ignored: {x!r}")
        return out

    def _config_snapshot(self) -> str:
        """The configuration this pack was built with (no secrets exist in it) - lets a consumer open the dense index with the
        same embedding deployment / dimensions and know which repo, branch, schema and folders the pack covers."""
        import yaml
        snap = {"system": self.system, "version": self.version, "source": dict(self.sc), "build": dict(self.b), "embeddings": dict(self.cfg.get("embeddings") or {}),
                "greenplum": {k: v for k, v in dict(self.cfg.get("greenplum") or {}).items() if k != "sqlite_path"}}
        return yaml.safe_dump(snap, sort_keys=False)

    # ------------------------------------------------------------------ knowledge items (retrieval units)
    def items(self, structure, tables, skills, derived, idx) -> List[dict]:
        out = []
        sysname = self.system
        d_repo, d_data, d_kn = derived.get("repo", {}), derived.get("data", {}).get("tables", {}), derived.get("knowledge", {})
        reg = structure.get("registration", {})
        if d_repo.get("system_summary"):
            out.append({"kind": "system", "ref": sysname, "title": f"{sysname} system overview", "text": d_repo["system_summary"]})
        for how in d_repo.get("how_to", []) or []:
            out.append({"kind": "howto", "ref": how.get("task", ""), "title": f"how to: {how.get('task', '')}", "text": "\n".join(f"- {s}" for s in how.get("steps", []))})
        for f, v in structure.get("folders", {}).items():
            purpose = (d_repo.get("folders", {}).get(f) or {})
            text = (f"purpose: {purpose.get('purpose') or v.get('purpose_hint', '')}\nhow to add: {purpose.get('how_to_add', '')}\n"
                    f"watch out: {purpose.get('watch_out', '')}\nfiles: {v['files']} {v['languages']}\ntypical files: {', '.join(v.get('typical_files', []))}\n"
                    f"name suffixes: {', '.join(v.get('common_name_suffixes', []))}\ntables built here: {', '.join(v.get('tables_built_here', [])[:20])}\n"
                    f"registration: {v.get('registration', '')}\nheaders: " + " | ".join(v.get("header_samples", [])[:3]))
            out.append({"kind": "folder", "ref": f or "(root)", "title": f"folder {f or '(root)'}", "text": text})
        for d in structure.get("dags", []):
            text = (f"dag ids: {', '.join(d.get('dag_ids', []))}\ntasks ({len(d.get('task_ids', []))}): {', '.join(d.get('task_ids', [])[:40])}\n"
                    f"task groups: {', '.join(d.get('task_groups', [])[:20])}\nfolders walked: {', '.join(d.get('folders_referenced', []))}\n"
                    f"dynamic registration: {', '.join(d.get('dynamic_registration', []))}\nvariables: {', '.join(d.get('variables', [])[:20])}\n"
                    f"dependencies: " + " ; ".join(d.get("dependency_chains", [])[:8]))
            out.append({"kind": "dag", "ref": d["path"], "title": f"DAG {d['path']}", "text": text})
        for c in structure.get("companion_patterns", []):
            out.append({"kind": "companion", "ref": f"{c['folder']}->{c['companion_folder_or_file']}", "title": f"companion rule {c['folder']}",
                        "text": f"{c['rule']}\nexample: {c['example']['file']} <-> {c['example']['companion']} {c['example']['line']}\noccurrences: {c['occurrences']}"})
        for t, info in tables.items():
            sem = d_data.get(t, {})
            cols = ", ".join(f"{c.get('name')} {c.get('type', '')}".strip() + (f" ({c['comment'][:80]})" if c.get("comment") else "") for c in info.get("columns", [])[:150])
            lin = structure.get("tables", {}).get(t) or structure.get("tables", {}).get(info.get("code_name", ""), {})
            text = (f"description: {info.get('description', '')}\npurpose: {sem.get('purpose', '')}\ngrain: {sem.get('grain', '')}\nkey columns: {', '.join(sem.get('key_columns', []) or [])}\n"
                    f"columns: {cols}\ncolumn notes: {json.dumps(sem.get('column_notes', {}), ensure_ascii=False)[:1500]}\n"
                    f"built by: {', '.join(lin.get('written_by', [])[:10])}\nread by: {', '.join(lin.get('read_by', [])[:15])}\n"
                    f"described: {info.get('described')}" + (f"\ncolumns from: {info['columns_from']}" if info.get("columns_from") else "")
                    + (f"\nin code: {info['code_name']}" if info.get("code_name") else ""))
            out.append({"kind": "table", "ref": t, "title": t, "text": text})
        code_names = {v.get("code_name") for v in tables.values() if v.get("code_name")}
        for t, lin in structure.get("tables", {}).items():
            if t not in tables and t not in code_names and lin.get("written_by"):
                out.append({"kind": "table", "ref": t, "title": t, "text": f"(not described) built by: {', '.join(lin['written_by'][:10])}\nread by: {', '.join(lin.get('read_by', [])[:15])}"})
        syms = structure.get("symbols", {})
        for rel, f in structure.get("file_list", {}).items():
            if f["language"] not in ("sql", "python", "airflow_dag", "r", "yaml", "shell", "ipynb", "md"):
                continue
            s = syms.get(rel, {})
            body = idx.read(rel, 1800) if idx else ""
            folder = rel.rsplit("/", 1)[0] if "/" in rel else ""
            text = (f"language: {f['language']} lines: {f['lines']}\nfolder: {folder}\nregistration: {reg.get(folder, {}).get('rule', '')[:200]}\n"
                    f"defs: {', '.join(s.get('defs', [])[:30])}\ntables: {', '.join(structure.get('script_tables', {}).get(rel, [])[:10])}\n"
                    f"header: {s.get('header', '')}\n{body}")
            out.append({"kind": "file", "ref": rel, "title": rel, "text": text})
        for name, doc in skills.items():
            secs = doc.get("sections") or []
            if secs:
                for i, sec in enumerate(secs[:80]):
                    title = sec.get("title") if isinstance(sec, dict) else str(sec)[:80]
                    body = sec.get("text", "") if isinstance(sec, dict) else ""
                    if body.strip():
                        out.append({"kind": doc.get("kind", "skills"), "ref": f"{name}#{i}", "title": f"{name}: {title}", "text": body[:4000]})
            elif doc.get("text"):
                t = doc["text"]
                for i in range(0, min(len(t), 60000), 3000):
                    out.append({"kind": doc.get("kind", "skills"), "ref": f"{name}#{i // 3000}", "title": name, "text": t[i:i + 3200]})
        for dfn in d_kn.get("definitions", []) or []:
            out.append({"kind": "definition", "ref": str(dfn.get("term", "")), "title": f"definition {dfn.get('term', '')}", "text": f"{dfn.get('definition', '')}\nsource: {dfn.get('source', '')}"})
        for i, c in enumerate(d_kn.get("conventions", []) or []):
            out.append({"kind": "convention", "ref": f"convention#{i}", "title": f"convention: {str(c.get('rule', ''))[:80]}", "text": f"{c.get('rule', '')}\napplies to: {c.get('applies_to', '')}\nsource: {c.get('source', '')}"})
        for r in d_kn.get("rules", []) or []:
            out.append({"kind": "rule", "ref": str(r.get("id", "")), "title": f"rule {r.get('id', '')}", "text": f"{r.get('message', '')}\npattern: {r.get('pattern', '')}\nmust match: {r.get('must_match')}\nlanguages: {r.get('languages')}\napplies to: {r.get('applies_to')}"})
        for p, v in list(structure.get("params", {}).items())[:200]:
            out.append({"kind": "param", "ref": p, "title": f"parameter {p}", "text": f"used {v['uses']} times, e.g. {', '.join(v['examples'][:4])}"})
        for g in (d_repo.get("glossary") or []) + [{"term": b.get("term"), "meaning": f"{b.get('note', '')} tables: {', '.join(b.get('tables', []) or [])} columns: {', '.join(b.get('columns', []) or [])} scripts: {', '.join(b.get('scripts_or_folders', []) or [])} synonyms: {', '.join(b.get('synonyms', []) or [])}"} for b in derived.get("bridge", {}).get("bridge", []) or []]:
            if g.get("term"):
                out.append({"kind": "glossary", "ref": str(g["term"]), "title": f"term {g['term']}", "text": str(g.get("meaning", ""))})
        return out

    # ------------------------------------------------------------------ manifest, diff, pack.md
    def _previous(self) -> Optional[dict]:
        lj = self.work_root / "latest.json"
        if not lj.exists():
            return None
        try:
            prev = json.loads(lj.read_text(encoding="utf-8"))
            pm = Path(prev["path"]) / "manifest.json"
            return json.loads(pm.read_text(encoding="utf-8")) if pm.exists() else None
        except Exception:  # noqa: BLE001
            return None

    def manifest(self, structure, tables, skills, derived, items, meta_status, previous) -> dict:
        hashes = {}
        for p in (self.out / "raw" / "repo").rglob("*"):
            if p.is_file():
                hashes[str(p.relative_to(self.out / "raw" / "repo")).replace("\\", "/")] = _sha(p)
        skill_hashes = {n: d.get("sha", "") for n, d in skills.items()}
        diff = {"added_files": [], "removed_files": [], "changed_files": [], "added_tables": [], "removed_tables": [], "changed_skills": [], "previous_version": None}
        if previous:
            ph = previous.get("file_hashes", {})
            diff["previous_version"] = previous.get("version")
            diff["added_files"] = sorted(set(hashes) - set(ph))[:300]
            diff["removed_files"] = sorted(set(ph) - set(hashes))[:300]
            diff["changed_files"] = sorted(k for k in set(hashes) & set(ph) if hashes[k] != ph[k])[:300]
            pt = set(previous.get("tables", []))
            diff["added_tables"] = sorted(set(tables) - pt)[:100]
            diff["removed_tables"] = sorted(pt - set(tables))[:100]
            psk = previous.get("skill_hashes", {})
            diff["changed_skills"] = sorted(k for k in skill_hashes if psk.get(k) != skill_hashes[k])
        cost = {}
        if self.llm is not None:
            try:
                cost = self.llm.token_stats()
                cost["by_model"] = self.llm.usage_by_model()
            except Exception:  # noqa: BLE001
                cost = cost or {}
        return {"system": self.system, "version": self.version, "built_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                "repo": {"name": self.sc.get("repo_name"), "project": self.sc.get("project_path"), "ref": getattr(self, "repo_ref", ""), "files": structure.get("files", 0),
                         "languages": structure.get("languages", {}), "files_in_excluded_folders": int(getattr(self, "excluded_files", 0) or 0)},
                "counts": {"dag_files": len(structure.get("dags", [])), "folders": len(structure.get("folders", {})), "tables_referenced": len(structure.get("tables", {})),
                           "tables_described": sum(1 for t in tables.values() if t.get("described")), "tables_listed": len(tables), "skills_documents": len(skills),
                           "companion_patterns": len(structure.get("companion_patterns", [])), "definitions": len(derived.get("knowledge", {}).get("definitions", []) or []),
                           "conventions": len(derived.get("knowledge", {}).get("conventions", []) or []), "rules": len(derived.get("knowledge", {}).get("rules", []) or []),
                           "items": len(items), "chunks": sum(1 for i in items if i["kind"] == "chunk"),
                           "business": (self.business or {}).get("stats", {})},
                "model_layer": bool(derived.get("model_layer")), "model_calls": derived.get("model_calls", 0), "cost": cost,
                "tables": sorted(tables), "metadata_tables": meta_status, "file_hashes": hashes, "skill_hashes": skill_hashes, "diff": diff,
                "layout": {"pack.md": "human index", "facts/": "deterministic facts", "derived/": "model layer", "items.jsonl": "retrieval units (incl. code chunks)",
                           "index/": "BM25 + vectors (hybrid, RRF)", "graph.json": "knowledge graph (tables, scripts, folders, DAGs, params, terms)",
                           "cards/": "prompt-ready context cards per folder / table / DAG / how-to", "exemplars.json": "one canonical file per folder",
                           "synonyms.json": "query expansion (business word -> technical tokens)", "raw/": "repo code, skills, gp lists", "store.sqlite": "metadata tables (optional)",
                           "facts/business.json": "business rules (insights) traced IKG -> ODM -> NLG: conditions in SQL + English, features, column lineage, narratives",
                           "cards/rule/ cards/domain/ cards/business_rules.md": "one card per insight / per domain + the catalogue"}}

    def pack_md(self, m, structure, tables, skills, derived, previous) -> str:
        L = []
        c = m["counts"]
        d_repo, d_kn, d_data = derived.get("repo", {}), derived.get("knowledge", {}), derived.get("data", {}).get("tables", {})
        L.append(f"# {self.system.upper()} System Knowledge Pack - {m['version']}\n")
        L.append(f"Built {m['built_at']} from `{m['repo']['project']}` @ `{m['repo']['ref']}` ({m['repo']['files']} files), {c['tables_listed']} tables "
                 f"({c['tables_described']} described from Greenplum), {c['skills_documents']} skills documents. Model layer: {'yes' if m['model_layer'] else 'no (facts only)'}. "
                 f"Items indexed: {c['items']}.\n")
        if self.warnings:
            L.append("## Health\n" + "\n".join(f"- {w}" for w in self.warnings) + "\n")
        if d_repo.get("system_summary"):
            L.append("## What the system does\n" + d_repo["system_summary"] + "\n")
        if d_repo.get("how_to"):
            L.append("## How to ...\n" + "\n".join(f"**{h.get('task')}**\n" + "\n".join(f"{i + 1}. {s}" for i, s in enumerate(h.get("steps", []))) for h in d_repo["how_to"]) + "\n")
        if self.business:
            bs = self.business["stats"]
            L.append("## Business rules (insights)\n"
                     f"{bs['rules']} insights traced across {', '.join(bs.get('systems', []))}: {bs['linked']} with ODM rule + NLG narrative, {bs['odm_only']} ODM rule only, "
                     f"{bs['nlg_only']} narrative only (mostly retired); {bs['conditions_in_english']} conditions rendered in English; {bs['features']} features, "
                     f"{bs.get('features_with_lineage', 0)} traced through the IKG tables to the script that computes them.\n\n"
                     "Chain: IKG profile table (features) -> ODM rule `si_*` (conditions -> insight row: insight_type, target_type, target_key, metric) -> "
                     "NLG `si_*.yml` (advisor sentence) -> products (layout: category, group, suppression). One card per insight: `cards/rules.md` (a `# si_x - title` section each); "
                     "per domain: `cards/domain/<domain>.md`; catalogue: `cards/business_rules.md`; API: `Pack.insights(text)`, `Pack.trace(id)`, `Pack.feature(col)`.\n")
            L.append("| target | insights | key | main tables |\n|---|---|---|---|")
            for k, v in list(self.business["entities"].items())[:30]:
                L.append(f"| {k} | {v['rules']} | {', '.join(v['key_columns'][:2])} | {', '.join(v['main_tables'][:3])} |")
            L.append("\nDomains: " + ", ".join(f"{d} ({len(ids)})" for d, ids in sorted(self.business["domains"].items(), key=lambda kv: -len(kv[1]))) + "\n")
        L.append("## DAGs\n| DAG file | dag ids | tasks | registration | folders walked |\n|---|---|---|---|---|")
        for d in structure.get("dags", [])[:60]:
            L.append(f"| `{d['path']}` | {', '.join(d.get('dag_ids', [])[:4])} | {len(d.get('task_ids', []))} | {'dynamic: ' + ', '.join(d['dynamic_registration']) if d.get('dynamic_registration') else 'static'} | {', '.join(d.get('folders_referenced', [])[:5])} |")
        L.append("\n## Folder guide\n| folder | files | purpose | registration | companions |\n|---|---|---|---|---|")
        comp_by = {}
        for cp in structure.get("companion_patterns", []):
            comp_by.setdefault(cp["folder"], []).append(cp["rule"])
        for f, v in structure.get("folders", {}).items():
            purpose = (d_repo.get("folders", {}).get(f) or {}).get("purpose") or v.get("purpose_hint", "")
            L.append(f"| `{f or '(root)'}` | {v['files']} | {purpose[:160]} | {v.get('registration', '')[:120]} | {'; '.join(comp_by.get(f, []))[:160]} |")
        L.append("\n## Tables\n| table | described | purpose | built by | read by |\n|---|---|---|---|---|")
        for t in sorted(tables)[:400]:
            lin = structure.get("tables", {}).get(t) or structure.get("tables", {}).get(tables[t].get("code_name", ""), {})
            L.append(f"| `{t}` | {'yes' if tables[t].get('described') else ('columns from code' if tables[t].get('columns_from') else 'no')} | {(d_data.get(t, {}).get('purpose') or tables[t].get('description', ''))[:140]} | "
                     f"{', '.join(Path(x).name for x in lin.get('written_by', [])[:3])} | {len(lin.get('read_by', []))} scripts |")
        _cn = {v.get("code_name") for v in tables.values()}
        other = [t for t in structure.get("tables", {}) if t not in tables and t not in _cn]
        if other:
            L.append(f"\nAlso referenced in code but not listed for description ({len(other)}): " + ", ".join(f"`{t}`" for t in other[:80]) + ("..." if len(other) > 80 else ""))
        if d_kn.get("conventions"):
            L.append("\n## Conventions\n" + "\n".join(f"- {x.get('rule')} _(applies to: {x.get('applies_to', '')}; source: {x.get('source', '')})_" for x in d_kn["conventions"][:150]))
        if d_kn.get("rules"):
            L.append("\n## Checkable rules\n| id | severity | languages | pattern | message |\n|---|---|---|---|---|")
            for r in d_kn["rules"][:100]:
                L.append(f"| {r.get('id')} | {r.get('severity')} | {r.get('languages')} | `{str(r.get('pattern', ''))[:60]}` | {str(r.get('message', ''))[:120]} |")
        if d_kn.get("definitions"):
            L.append("\n## Definitions\n" + "\n".join(f"- **{x.get('term')}**: {x.get('definition')} _({x.get('source', '')})_" for x in d_kn["definitions"][:300]))
        bridge = derived.get("bridge", {}).get("bridge", []) or []
        if bridge:
            L.append("\n## Business term -> technical object\n| term | tables | columns | scripts / folders |\n|---|---|---|---|")
            for b in bridge[:100]:
                L.append(f"| {b.get('term')} | {', '.join(b.get('tables', []) or [])[:100]} | {', '.join(b.get('columns', []) or [])[:100]} | {', '.join(b.get('scripts_or_folders', []) or [])[:100]} |")
        params = structure.get("params", {})
        if params:
            L.append("\n## Parameters\n" + ", ".join(f"`{p}` ({v['uses']})" for p, v in list(params.items())[:80]))
        if skills:
            L.append("\n## Skills documents\n" + "\n".join(f"- `{n}` ({d.get('kind')}, {d.get('chars', 0)} chars, {d.get('source_folder')})" for n, d in skills.items()))
        diff = m.get("diff", {})
        if diff.get("previous_version"):
            L.append(f"\n## What changed since {diff['previous_version']}\n- files added: {len(diff['added_files'])} {', '.join(diff['added_files'][:15])}\n"
                     f"- files changed: {len(diff['changed_files'])} {', '.join(diff['changed_files'][:15])}\n- files removed: {len(diff['removed_files'])} {', '.join(diff['removed_files'][:15])}\n"
                     f"- tables added: {', '.join(diff['added_tables'][:20]) or '-'}\n- tables removed: {', '.join(diff['removed_tables'][:20]) or '-'}\n"
                     f"- skills changed: {', '.join(diff['changed_skills']) or '-'}")
        else:
            L.append("\n## What changed\nFirst version of this pack.")
        L.append("\n## Build\n| stage | seconds |\n|---|---|\n" + "\n".join(f"| {k} | {v} |" for k, v in self.timings.items()))
        tot = (m.get("cost") or {}).get("total") or {}
        if tot:
            L.append(f"\nModel usage: {tot.get('calls', 0)} calls, {tot.get('total_tokens', 0)} tokens (cached {tot.get('cached_input_tokens', 0)}, "
                     f"embedding {tot.get('embedding_tokens', 0)}), {tot.get('cost_usd', 0)} USD, {tot.get('seconds_in_calls', 0)}s in calls")
        L.append("\n## Layout\n" + "\n".join(f"- `{k}`: {v}" for k, v in m["layout"].items()))
        return "\n".join(L)

    def _prune(self) -> None:
        keep = int(self.b.get("keep_versions", 3))
        vers = sorted([p for p in self.work_root.iterdir() if p.is_dir() and re.fullmatch(r"\d{8}_\d{4,6}", p.name)], key=lambda p: p.name)
        for p in vers[:-keep] if keep > 0 else []:
            shutil.rmtree(p, ignore_errors=True)
            for z in (self.work_root / f"{self.system}_pack_{p.name}.zip", self.work_root / f"{self.system}_pack_{p.name}_degraded.zip"):
                if z.exists():
                    z.unlink()
