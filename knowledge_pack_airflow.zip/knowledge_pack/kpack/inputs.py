"""Inputs of a pack besides the repository: the tables (gp/<system>/gp.md + tables named in the code, described from
Greenplum), optional metadata tables copied into the pack's sqlite store, and the skills / standards / glossary documents
(skills/<system>/ + skills/common/)."""
from __future__ import annotations

import json
import logging
import re
import sqlite3
import time
from pathlib import Path
from typing import Dict, List, Optional

from agiledev.greenplum import GreenplumInput
from agiledev.readers import read_document

log = logging.getLogger("kpack.inputs")
_TBL = re.compile(r"\b([a-z][a-z0-9_]*)\.([a-z][a-z0-9_]*)\b")


def parse_gp_folder(folder: Path, default_schema: str) -> List[dict]:
    """Every `schema.table` (or bare table) named in the md / txt / yaml / csv files of gp/<system>/ - with the description
    text on the same line / row when there is one. gp.md may be a plain list, a markdown table or prose."""
    out, seen = [], set()
    if not folder.is_dir():
        return out
    for p in sorted(folder.iterdir()):
        if not p.is_file() or p.suffix.lower() not in (".md", ".txt", ".yaml", ".yml", ".csv"):
            continue
        for ln in p.read_text(encoding="utf-8", errors="replace").splitlines():
            if not ln.strip() or ln.strip().startswith(("#", "|--", "|-")) or re.fullmatch(r"\|\s*table\s*\|\s*description\s*\|", ln.strip(), re.I):
                continue
            ln = re.sub(r"`[^`]*`", " ", ln)          # names inside back-ticks are documentation, not tables
            if "schema.table" in ln.lower():
                continue
            cells = [c.strip() for c in ln.strip("|").split("|")] if "|" in ln else [ln.strip()]
            found = []
            for c in cells:
                for m in _TBL.finditer(c.lower()):
                    found.append((m.group(1), m.group(2)))
                if not found and re.fullmatch(r"[a-z][a-z0-9_]{3,}", c.strip("-* ").lower()) and "_" in c:
                    found.append((default_schema, c.strip("-* ").lower()))
            for schema, table in found:
                key = f"{schema}.{table}"
                if key in seen:
                    continue
                seen.add(key)
                desc = " ".join(c for c in cells if f"{schema}.{table}" not in c.lower() and table not in c.lower()).strip(" -:|")
                out.append({"schema": schema, "table": table, "description": desc[:300], "source": p.name})
    return out


def describe_tables(gp: GreenplumInput, tables: List[dict], sample_rows: int, progress=None, sqlite_mode: bool = False, sample_limit: int = 0) -> Dict[str, dict]:
    """Columns of every table (catalog round trips); sample rows only for the first `sample_limit` tables (0 = all)."""
    if sample_limit and len(tables) > sample_limit and sample_rows and not sqlite_mode:
        a = describe_tables(gp, tables[:sample_limit], sample_rows, progress, sqlite_mode)
        (progress or (lambda m: None))(f"{len(tables) - sample_limit} more table(s): columns only, no sample rows (build.sample_tables_max)")
        a.update(describe_tables(gp, tables[sample_limit:], 0, progress, sqlite_mode))
        return a
    say = progress or (lambda m: None)
    out = {}
    pairs = [("" if sqlite_mode else t["schema"], t["table"]) for t in tables]
    say(f"describing {len(pairs)} tables ...")
    descs = []
    if sqlite_mode:
        for s, t in pairs:
            try:
                descs.append(gp.describe("", t, sample_rows))
            except Exception as e:  # noqa: BLE001
                descs.append({"schema": s, "table": t, "error": str(e)[:200], "columns": []})
    else:
        try:
            descs = gp.describe_many(pairs, sample_rows=sample_rows, progress=say)      # 3 catalog round trips for ALL tables; missing ones come back as errors
        except Exception as e:  # noqa: BLE001
            log.warning("describe_many failed (%s) - describing one by one", e)
            for s, t in pairs:
                try:
                    descs.append(gp.describe(s, t, sample_rows))
                except Exception as e2:  # noqa: BLE001
                    descs.append({"schema": s, "table": t, "error": str(e2)[:200], "columns": []})
    for t, d in zip(tables, descs):
        d = dict(d or {})
        smp = d.get("sample")
        if isinstance(smp, dict) and smp.get("columns"):        # wide profile tables: keep the sample readable and small
            keep = min(len(smp["columns"]), 60)
            smp["rows"] = [[(str(v)[:80] if v is not None else None) for v in r[:keep]] for r in smp.get("rows", [])]
            smp["columns"] = smp["columns"][:keep]
        d.setdefault("schema", t["schema"]); d.setdefault("table", t["table"])
        d["description"] = t.get("description", "")
        d["source"] = t.get("source", "")
        out[f"{t['schema']}.{t['table']}"] = d
    return out


def copy_metadata_tables(gp: GreenplumInput, names: List[str], db_path: Path, max_rows: int, progress=None, sqlite_mode: bool = False) -> Dict[str, dict]:
    say = progress or (lambda m: None)
    con = sqlite3.connect(str(db_path))
    status = {}
    for full in names:
        schema, _, table = full.rpartition(".")
        say(f"copying {full} ...")
        try:
            res = gp.query(f"select * from {table if sqlite_mode else full}", limit=max_rows)
            cols = res["columns"]
            con.execute(f'drop table if exists "{table}"')
            con.execute(f'create table "{table}" ({", ".join(chr(34) + c + chr(34) + " TEXT" for c in cols)})')
            con.executemany(f'insert into "{table}" values ({", ".join("?" for _ in cols)})', [[None if v is None else str(v) for v in r] for r in res["rows"]])
            con.commit()
            status[full] = {"rows": len(res["rows"]), "columns": cols, "truncated": len(res["rows"]) >= max_rows}
        except Exception as e:  # noqa: BLE001
            status[full] = {"error": f"{type(e).__name__}: {str(e)[:200]}"}
    con.close()
    return status


def read_skills(folders: List[Path]) -> Dict[str, dict]:
    """Every document in the skills folders -> {name: {kind, text, sections, format, chars, source_folder}}."""
    out = {}
    for folder in folders:
        if not folder.is_dir():
            continue
        for p in sorted(folder.rglob("*")):
            if not p.is_file() or p.name.startswith(".") or p.name.lower() == "readme.md":
                continue
            if any(part.startswith(("_", ".")) for part in p.relative_to(folder).parts[:-1]) or "-checkpoint." in p.name:
                continue                                   # _merged/, _drafts/, .ipynb_checkpoints/ (Jupyter autosave copies) are not inputs
            kind = "glossary" if re.search(r"gloss|dictionary", p.name, re.I) else ("standards" if re.search(r"standard|convention|rule|guideline", p.name, re.I) else "skills")
            try:
                d = read_document(p.name, p.read_bytes(), kind)
                out[p.name] = {"kind": kind, "format": d.get("format"), "text": d.get("text", ""), "sections": d.get("sections", [])[:200],
                               "chars": len(d.get("text", "")), "source_folder": str(folder.name), "sha": d.get("sha", "")}
                if isinstance(d.get("data"), (dict, list)):
                    out[p.name]["data"] = d["data"]        # parsed yaml / json: rule catalogues are read without the model (see yaml_rules)
            except Exception as e:  # noqa: BLE001
                out[p.name] = {"kind": kind, "error": str(e)[:200], "text": "", "chars": 0, "source_folder": str(folder.name)}
    return out


def open_greenplum(cfg, password: str) -> Optional[GreenplumInput]:
    g = cfg.greenplum
    if g.get("sqlite_path"):
        return GreenplumInput("", 0, "", "", "", sqlite_path=g["sqlite_path"])
    if not password:
        return None
    return GreenplumInput(g["host"], int(g["port"]), g["database"], g["user"], password, g.get("sslmode", "prefer"),
                          int(int(g.get("statement_timeout_ms", 60000)) / 1000))


# ---------------------------------------------------------------------- rule catalogues in yaml (deterministic, no model)
_SEV = {"critical": "critical", "high": "high", "medium": "medium", "low": "low", "warn": "medium", "warning": "medium", "error": "high", "info": "low"}


def _walk_rules(node, out: list, path: str = ""):
    """Finds every mapping that looks like a rule (rule_id + pattern / negative_pattern) anywhere in a yaml document."""
    if isinstance(node, dict):
        if ("rule_id" in node or "id" in node) and ("pattern" in node or "negative_pattern" in node or "must_match" in node):
            out.append((path, node))
        for k, v in node.items():
            _walk_rules(v, out, f"{path}/{k}" if path else str(k))
    elif isinstance(node, list):
        for i, v in enumerate(node):
            _walk_rules(v, out, f"{path}[{i}]")


def yaml_rules(skills: Dict[str, dict]) -> List[dict]:
    """Checkable rules straight from the team's yaml files (standards_config.yaml, *_project_rules.yaml, sql_rules.yaml ...):
    each entry with rule_id + a regex becomes {id, pattern, must_match, severity, message, languages, source} - exactly what
    the validator of Agile Dev Assist runs on every generated file. Rules with check_type (output_count, name_matching ...) or
    enabled: false are skipped (they need code, not a regex). A severity_mapping.yaml (rule_id -> critical/high/...) overrides
    the severity. Broken regexes are dropped."""
    found, sev_map = [], {}
    for name, doc in skills.items():
        data = doc.get("data")
        if not isinstance(data, (dict, list)):
            continue
        if re.search(r"severity", name, re.I):
            def _sev_walk(node, level=""):
                if isinstance(node, dict):
                    rid = node.get("rule_id")
                    if rid and level:
                        sev_map[str(rid)] = level
                    for k, v in node.items():
                        _sev_walk(v, k if str(k).lower() in _SEV else level)
                elif isinstance(node, list):
                    for v in node:
                        _sev_walk(v, level)
            _sev_walk(data)
            continue
        acc = []
        _walk_rules(data, acc)
        # path based exceptions of the same file: exclude_files (every rule) + rule_overrides (named rules)
        exc = (data.get("exceptions") if isinstance(data, dict) else None) or {}
        excl_all = [str(x) for x in (exc.get("exclude_files") or [])]
        per_rule = {}
        for ov in exc.get("rule_overrides") or []:
            for rid in ov.get("disabled_rules") or []:
                per_rule.setdefault(str(rid), []).append(str(ov.get("path_pattern", "")))
        for where, r in acc:
            r = dict(r)
            rid = str(r.get("rule_id") or r.get("id"))
            r["exempt"] = list(r.get("exempt") or r.get("exclude_files") or []) + excl_all + per_rule.get(rid, [])
            found.append((name, where, r))
    out, seen = [], set()
    for name, where, r in found:
        if r.get("enabled") is False or r.get("check_type"):
            continue
        rid = str(r.get("rule_id") or r.get("id"))
        pattern = r.get("pattern") or ""
        must = bool(r.get("must_match", False))
        if not pattern and r.get("negative_pattern"):
            pattern, must = r["negative_pattern"], True       # only a "what it must look like" pattern: required
        if not pattern or rid in seen:
            continue
        try:
            re.compile(str(pattern), re.I | re.M)
        except re.error:
            continue
        seen.add(rid)
        langs = r.get("languages") or r.get("file_types") or (["sql"] if re.search(r"sql|table|select|join|schema", json.dumps(r).lower()) else ["sql", "python"])
        when = r.get("when") or r.get("applies_when") or ""
        if not when and must and re.search(r"(?i)grant|owner|distributed|created tables|create table|analyze|drop table", f"{r.get('message', '')} {r.get('name', '')} {pattern}"):
            when = r"CREATE\s+TABLE"                        # required-in-created-tables rules never fire on deployer / validation scripts
        out.append({"id": rid, "pattern": str(pattern), "must_match": must, "origin": "yaml", "when": str(when),
                    "unless": str(r.get("unless") or r.get("allowed_if") or ""),     # forbidden rule waived when this regex matches the file (e.g. '-- cross join intended')
                    "severity": _SEV.get(str(sev_map.get(rid) or r.get("severity") or "medium").lower(), "medium"),
                    "message": str(r.get("message") or r.get("description") or r.get("name") or rid)[:300],
                    "languages": [str(x).lower() for x in (langs if isinstance(langs, list) else [langs])],
                    "applies_to": [str(x) for x in r["applies_to"]] if isinstance(r.get("applies_to"), list) else [],   # path globs only (the validator fnmatches them)
                    "exempt": [str(x) for x in (r.get("exempt") or [])],
                    "name": str(r.get("name") or ""), "example_violation": str(r.get("example_violation") or "")[:200],
                    "example_correct": str(r.get("example_correct") or "")[:200], "source": f"{name} ({where})"})
    return out
