"""Inputs of a pack besides the repository: the tables (gp/<system>/gp.md + tables named in the code, described from
Greenplum), optional metadata tables copied into the pack's sqlite store, and the skills / standards / glossary documents
(skills/<system>/ + skills/common/)."""
from __future__ import annotations

import json
import logging
import re
import sqlite3
import time
from pathlib import Path
from typing import Dict, List, Optional

from agiledev.greenplum import GreenplumInput
from agiledev.readers import read_document

log = logging.getLogger("kpack.inputs")
_TBL = re.compile(r"\b([a-z][a-z0-9_]*)\.([a-z][a-z0-9_]*)\b")


def parse_gp_folder(folder: Path, default_schema: str) -> List[dict]:
    """Every `schema.table` (or bare table) named in the md / txt / yaml / csv files of gp/<system>/ - with the description
    text on the same line / row when there is one. gp.md may be a plain list, a markdown table or prose."""
    out, seen = [], set()
    if not folder.is_dir():
        return out
    for p in sorted(folder.iterdir()):
        if not p.is_file() or p.suffix.lower() not in (".md", ".txt", ".yaml", ".yml", ".csv"):
            continue
        for ln in p.read_text(encoding="utf-8", errors="replace").splitlines():
            if not ln.strip() or ln.strip().startswith(("#", "|--", "|-")) or re.fullmatch(r"\|\s*table\s*\|\s*description\s*\|", ln.strip(), re.I):
                continue
            ln = re.sub(r"`[^`]*`", " ", ln)          # names inside back-ticks are documentation, not tables
            if "schema.table" in ln.lower():
                continue
            cells = [c.strip() for c in ln.strip("|").split("|")] if "|" in ln else [ln.strip()]
            found = []
            for c in cells:
                for m in _TBL.finditer(c.lower()):
                    found.append((m.group(1), m.group(2)))
                if not found and re.fullmatch(r"[a-z][a-z0-9_]{3,}", c.strip("-* ").lower()) and "_" in c:
                    found.append((default_schema, c.strip("-* ").lower()))
            for schema, table in found:
                key = f"{schema}.{table}"
                if key in seen:
                    continue
                seen.add(key)
                desc = " ".join(c for c in cells if f"{schema}.{table}" not in c.lower() and table not in c.lower()).strip(" -:|")
                out.append({"schema": schema, "table": table, "description": desc[:300], "source": p.name})
    return out


def describe_tables(gp: GreenplumInput, tables: List[dict], sample_rows: int, progress=None, sqlite_mode: bool = False) -> Dict[str, dict]:
    say = progress or (lambda m: None)
    out = {}
    pairs = [("" if sqlite_mode else t["schema"], t["table"]) for t in tables]
    say(f"describing {len(pairs)} tables ...")
    descs = []
    if sqlite_mode:
        for s, t in pairs:
            try:
                descs.append(gp.describe("", t, sample_rows))
            except Exception as e:  # noqa: BLE001
                descs.append({"schema": s, "table": t, "error": str(e)[:200], "columns": []})
    else:
        try:
            descs = gp.describe_many(pairs, sample_rows=sample_rows, progress=say)      # 3 catalog round trips for ALL tables; missing ones come back as errors
        except Exception as e:  # noqa: BLE001
            log.warning("describe_many failed (%s) - describing one by one", e)
            for s, t in pairs:
                try:
                    descs.append(gp.describe(s, t, sample_rows))
                except Exception as e2:  # noqa: BLE001
                    descs.append({"schema": s, "table": t, "error": str(e2)[:200], "columns": []})
    for t, d in zip(tables, descs):
        d = dict(d or {})
        d.setdefault("schema", t["schema"]); d.setdefault("table", t["table"])
        d["description"] = t.get("description", "")
        d["source"] = t.get("source", "")
        out[f"{t['schema']}.{t['table']}"] = d
    return out


def copy_metadata_tables(gp: GreenplumInput, names: List[str], db_path: Path, max_rows: int, progress=None, sqlite_mode: bool = False) -> Dict[str, dict]:
    say = progress or (lambda m: None)
    con = sqlite3.connect(str(db_path))
    status = {}
    for full in names:
        schema, _, table = full.rpartition(".")
        say(f"copying {full} ...")
        try:
            res = gp.query(f"select * from {table if sqlite_mode else full}", limit=max_rows)
            cols = res["columns"]
            con.execute(f'drop table if exists "{table}"')
            con.execute(f'create table "{table}" ({", ".join(chr(34) + c + chr(34) + " TEXT" for c in cols)})')
            con.executemany(f'insert into "{table}" values ({", ".join("?" for _ in cols)})', [[None if v is None else str(v) for v in r] for r in res["rows"]])
            con.commit()
            status[full] = {"rows": len(res["rows"]), "columns": cols, "truncated": len(res["rows"]) >= max_rows}
        except Exception as e:  # noqa: BLE001
            status[full] = {"error": f"{type(e).__name__}: {str(e)[:200]}"}
    con.close()
    return status


def read_skills(folders: List[Path]) -> Dict[str, dict]:
    """Every document in the skills folders -> {name: {kind, text, sections, format, chars, source_folder}}."""
    out = {}
    for folder in folders:
        if not folder.is_dir():
            continue
        for p in sorted(folder.rglob("*")):
            if not p.is_file() or p.name.startswith(".") or p.name.lower() == "readme.md":
                continue
            if any(part.startswith("_") for part in p.relative_to(folder).parts[:-1]):
                continue                                   # _merged/ (originals of a merged skill file), _drafts/ ... are not inputs
            kind = "glossary" if re.search(r"gloss|dictionary", p.name, re.I) else ("standards" if re.search(r"standard|convention|rule|guideline", p.name, re.I) else "skills")
            try:
                d = read_document(p.name, p.read_bytes(), kind)
                out[p.name] = {"kind": kind, "format": d.get("format"), "text": d.get("text", ""), "sections": d.get("sections", [])[:200],
                               "chars": len(d.get("text", "")), "source_folder": str(folder.name), "sha": d.get("sha", "")}
            except Exception as e:  # noqa: BLE001
                out[p.name] = {"kind": kind, "error": str(e)[:200], "text": "", "chars": 0, "source_folder": str(folder.name)}
    return out


def open_greenplum(cfg, password: str) -> Optional[GreenplumInput]:
    g = cfg.greenplum
    if g.get("sqlite_path"):
        return GreenplumInput("", 0, "", "", "", sqlite_path=g["sqlite_path"])
    if not password:
        return None
    return GreenplumInput(g["host"], int(g["port"]), g["database"], g["user"], password, g.get("sslmode", "prefer"),
                          int(int(g.get("statement_timeout_ms", 60000)) / 1000))
