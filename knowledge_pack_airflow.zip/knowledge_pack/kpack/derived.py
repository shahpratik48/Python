"""The derived layer: what a reader (human or agent) needs that the raw facts do not say outright. Built ONCE a week by the
pack builder - never at question time - so every consumer gets it for free.

Deterministic part (always): folder purposes from names/headers, companion rules, registration rules, parameter catalogue,
table lineage (built by / read by), per-DAG summaries.
LLM part (optional, `build.derived_layer`, cost-capped, low reasoning, every call cached by input hash):
  - conventions + checkable rules + glossary from the skills / standards documents (knowledge agent prompt),
  - plain-English purpose of each folder and of the system (repo summary),
  - business meaning of every described table / column group (data semantics),
  - bridge: business terms -> tables / columns / scripts.
"""
from __future__ import annotations

import json
import logging
import re
import time
from typing import Dict, List, Optional

log = logging.getLogger("kpack.derived")

KNOWLEDGE_SYSTEM = """You are building a SYSTEM KNOWLEDGE PACK for the data platform system named {system}. From the documents
given (skills, standards & conventions, glossary) return JSON with:
- "definitions": [{{"term","definition","source"}}] - every column, key, abbreviation, business concept defined IN the documents (as written).
- "conventions": [{{"rule","applies_to","source"}}] - naming, structure, parameterisation, layout, logging, error handling and
  'what else must change when ...' rules, as imperative sentences.
- "rules": [{{"id","pattern","must_match","severity","message","languages","applies_to","exempt"}}] - ONLY conventions that a
  case-insensitive Python regex on a single line can check (literal tokens / names). Never multi-line structure.
- "notes_for_coder": [str] (max 15).
Never invent: everything must come from the documents. Return compact JSON."""

REPO_SYSTEM = """You are documenting the code repository of the data platform system {system} for engineers and for AI agents
that will add code to it. From the FACTS given (folders, their typical files, header samples, tables built, DAG registration
rule, companion-file patterns, parameters) return JSON:
- "system_summary": 4-8 sentences: what the system does, how a DAG is built, how SQL scripts become tasks, where parameters
  come from, how a new script is added end-to-end.
- "folders": {{"<folder>": {{"purpose": one or two sentences, "how_to_add": one sentence, "watch_out": one sentence or ""}}}}
- "how_to": [{{"task": e.g. 'add a new insight table', "steps": [str]}}] (3-6 common tasks)
- "glossary": [{{"term","meaning"}}] - abbreviations / parameter names visible in the facts.
Use only the facts; when unsure say 'unclear from code'. Return compact JSON."""

DATA_SYSTEM = """You are documenting Greenplum tables of the data platform system {system}. From each table's columns, sample
values, the SQL that builds it and the scripts that read it, return JSON:
{{"tables": {{"<schema.table>": {{"purpose": one or two sentences, "grain": what one row is, "key_columns": [str],
  "column_notes": {{"<column>": short meaning}} (only non-obvious columns, max 15), "used_for": one sentence}}}}}}
Only state what the evidence supports; say 'unclear' otherwise. Return compact JSON."""

BRIDGE_SYSTEM = """Build a BRIDGE from business language to technical objects for system {system}. From the glossary / definitions,
table purposes and folder purposes given, return JSON {{"bridge": [{{"term", "synonyms": [str], "tables": [str], "columns": [str],
"scripts_or_folders": [str], "note": str}}]}} (max 80 entries, most useful first). Only link what the inputs support."""


class Derived:
    def __init__(self, cfg, llm=None, progress=None, budget_usd: float = 2.0):
        self.cfg, self.llm = cfg, llm
        self.say = progress or (lambda m: None)
        self.budget = float(budget_usd)
        self.calls = 0
        self.errors: List[str] = []
        self.effort = (cfg.get("agents") or {}).get("reasoning_effort") or {}
        self.t_start = time.time()
        self.max_minutes = float((cfg.get("build") or {}).get("max_llm_minutes", 12))

    # ------------------------------------------------------------------ helpers
    def _spent(self) -> float:
        if self.llm is None:
            return 0.0
        try:
            return float(self.llm.token_stats().get("total", {}).get("cost_usd", 0.0))
        except Exception:  # noqa: BLE001
            return 0.0

    def _call(self, name: str, system: str, user: str) -> Optional[dict]:
        if self.llm is None:
            return None
        if self._spent() > self.budget:
            self.errors.append(f"{name}: skipped, cost budget {self.budget} USD reached")
            return None
        if time.time() - self.t_start > self.max_minutes * 60:
            self.errors.append(f"{name}: skipped, model-layer time cap {self.max_minutes} min reached (facts still complete; rerun fills the cache)")
            return None
        key = self.llm.hash("kpack-derived-v1", name, system, user)
        hit = self.llm.cache_get(key)
        if hit is not None:
            self.llm.count_cache_hit()
            return hit
        self.llm.set_process(name)
        try:
            t0 = time.time()
            out = self.llm.json_call(system, user, reasoning_effort=self.effort.get(name, "low"))
            self.calls += 1
            self.say(f"{name}: model call done in {time.time() - t0:.0f}s")
            self.llm.cache_put(key, out)
            return out
        except Exception as e:  # noqa: BLE001
            self.errors.append(f"{name}: {type(e).__name__}: {str(e)[:200]}")
            return None

    def _parallel(self, calls):
        """Independent model calls concurrently (bounded by llm.parallel_calls; the LLM client rate-limits and retries)."""
        import concurrent.futures as cf
        if not calls:
            return []
        workers = max(1, min(len(calls), int((self.cfg.get("llm") or {}).get("parallel_calls", 4))))
        with cf.ThreadPoolExecutor(workers) as ex:
            return list(ex.map(lambda c: self._call(*c), calls))

    def run_all(self, skills, facts, headers, tables, structure, sql_text, system) -> dict:
        """The whole model layer with maximum overlap: knowledge + repo summary + data semantics at once, then the bridge."""
        import concurrent.futures as cf
        with cf.ThreadPoolExecutor(3) as ex:
            fk = ex.submit(self.knowledge, skills, system)
            fr = ex.submit(self.repo_summary, facts, system, headers)
            fd = ex.submit(self.data_semantics, tables, structure, sql_text, system)
            knowledge, repo, data = fk.result(), fr.result(), fd.result()
        knowledge["rules"] = rules_sanity(knowledge.get("rules", []))
        bridge = self.bridge(knowledge, repo, data, system)
        return {"knowledge": knowledge, "repo": repo, "data": data, "bridge": bridge}

    # ------------------------------------------------------------------ deterministic facts
    @staticmethod
    def facts(structure: dict, tables: Dict[str, dict]) -> dict:
        folders = structure.get("folders", {})
        reg = structure.get("registration", {})
        lineage = {}
        for t, info in structure.get("tables", {}).items():
            lineage[t] = {"built_by": sorted(info.get("written_by", []))[:20], "read_by": sorted(info.get("read_by", []))[:30],
                          "described": t in tables}
        dag_summ = []
        for d in structure.get("dags", []):
            dag_summ.append({"file": d.get("path"), "dag_ids": d.get("dag_ids", []), "tasks": len(d.get("task_ids", [])),
                             "task_groups": d.get("task_groups", [])[:20], "dynamic_registration": d.get("dynamic_registration", []),
                             "folders": d.get("folders_referenced", [])[:20], "variables": d.get("variables", [])[:20],
                             "chains": d.get("dependency_chains", [])[:10]})
        return {"folders": {f: {"purpose_hint": v.get("purpose_hint", ""), "typical_files": v.get("typical_files", [])[:8],
                                "suffixes": v.get("common_name_suffixes", []), "tables_built": v.get("tables_built_here", [])[:30],
                                "files": v.get("files", 0), "languages": v.get("languages", {}),
                                "registration": reg.get(f, {}).get("rule", "")} for f, v in folders.items()},
                "companion_rules": structure.get("companion_patterns", []), "registration": reg, "lineage": lineage,
                "params": structure.get("params", {}), "dags": dag_summ}

    # ------------------------------------------------------------------ LLM layers
    def knowledge(self, skills: Dict[str, dict], system: str) -> dict:
        docs = [(n, d) for n, d in skills.items() if d.get("text")]
        if not docs:
            return {"definitions": [], "conventions": [], "rules": [], "notes_for_coder": [], "source": "no documents"}
        out = {"definitions": [], "conventions": [], "rules": [], "notes_for_coder": []}
        chunk, size = [], 0
        chunks = []
        for n, d in docs:                                    # ~60k chars per call keeps each call cheap and complete
            t = f"### {n} ({d.get('kind')})\n{d['text'][:120000]}\n"
            if size + len(t) > 60000 and chunk:
                chunks.append(chunk); chunk, size = [], 0
            chunk.append(t); size += len(t)
        if chunk:
            chunks.append(chunk)
        self.say(f"knowledge layer: {len(chunks)} document chunk(s) in parallel ...")
        for r in self._parallel([("knowledge_agent", KNOWLEDGE_SYSTEM.format(system=system), "".join(c)) for c in chunks]):
            if r:
                for k in out:
                    v = r.get(k) or []
                    if isinstance(v, list):
                        out[k].extend(v)
        out["source"] = f"{len(docs)} documents, {len(chunks)} model calls" if self.llm else "model layer disabled"
        return out

    def repo_summary(self, facts: dict, system: str, header_samples: Dict[str, List[str]]) -> dict:
        folders = facts["folders"]
        brief = {f: {"purpose_hint": v["purpose_hint"], "typical_files": v["typical_files"][:5], "tables_built": v["tables_built"][:8],
                     "registration": v["registration"], "header_sample": (header_samples.get(f) or [""])[0][:600]} for f, v in list(folders.items())[:120]}
        user = json.dumps({"folders": brief, "companion_rules": facts["companion_rules"][:30], "params": dict(list(facts["params"].items())[:60]),
                           "dags": facts["dags"][:25]}, ensure_ascii=False)[:90000]
        self.say("repo summary layer ...")
        r = self._call("repo_summary_agent", REPO_SYSTEM.format(system=system), user)
        return r or {"system_summary": "", "folders": {}, "how_to": [], "glossary": []}

    def data_semantics(self, tables: Dict[str, dict], structure: dict, sql_text, system: str) -> dict:
        """Business meaning of the tables that matter: tables listed in gp.md first, then the repo's own tables ranked by how
        many scripts use them; temp / staging / backup tables are left out. Compact payload (~1.2k chars per table) so a
        system with 400 tables costs a handful of calls, not 76."""
        out = {"tables": {}}
        if not tables:
            return out
        tmap = structure.get("tables", {})
        junk = re.compile(r"(_tmp|_temp|_stg|_stage|_staging|_bkp|_bak|_backup|_old|_test|_\d{6,8})(_|$)", re.I)

        def rank(full, d):
            lin = tmap.get(full, {})
            sc = (100 if d.get("source") and d["source"] != "code" else 0) + len(lin.get("read_by", [])) + (2 if lin.get("written_by") else 0)
            return sc - (50 if junk.search(full) else 0)

        cap = int((self.cfg.get("build") or {}).get("max_semantic_tables", 150))
        chosen = sorted(tables.items(), key=lambda kv: -rank(*kv))
        chosen = [kv for kv in chosen if rank(*kv) > -40][:cap]
        if len(chosen) < len(tables):
            self.say(f"data semantics layer: {len(chosen)} of {len(tables)} described tables selected (gp.md tables, then most-used; temp / backup tables skipped)")
        batch, size, batches = [], 0, []
        for full, d in chosen:
            built = sorted(tmap.get(full, {}).get("written_by", []))[:1]
            sql_snip = re.sub(r"\s+", " ", sql_text(built[0])[:700]) if built else ""
            sample = _sample_rows(d)[:1]
            ent = {"table": full, "description_given": d.get("description", "")[:200],
                   "columns": [f"{c.get('name')} {str(c.get('type', ''))[:12]}" for c in d.get("columns", [])][:40],
                   "sample": json.dumps(sample, default=str)[:300] if sample else "", "built_by": built,
                   "read_by": sorted(tmap.get(full, {}).get("read_by", []))[:3], "sql_excerpt": sql_snip}
            t = json.dumps(ent, ensure_ascii=False, default=str)
            if size + len(t) > 45000 and batch:
                batches.append(batch); batch, size = [], 0
            batch.append(t); size += len(t)
        if batch:
            batches.append(batch)
        self.say(f"data semantics layer: {len(chosen)} tables in {len(batches)} batch(es) in parallel ...")
        for r in self._parallel([("data_agent", DATA_SYSTEM.format(system=system), "[" + ",".join(b) + "]") for b in batches]):
            if r and isinstance(r.get("tables"), dict):
                out["tables"].update(r["tables"])
        return out

    def bridge(self, knowledge: dict, repo: dict, data: dict, system: str) -> dict:
        user = json.dumps({"definitions": knowledge.get("definitions", [])[:200], "glossary": repo.get("glossary", [])[:80],
                           "tables": {k: v.get("purpose", "") for k, v in list(data.get("tables", {}).items())[:200]},
                           "folders": {k: v.get("purpose", "") for k, v in list(repo.get("folders", {}).items())[:120]}}, ensure_ascii=False)[:80000]
        self.say("bridge layer ...")
        r = self._call("bridge_agent", BRIDGE_SYSTEM.format(system=system), user)
        return r or {"bridge": []}


def _sample_rows(d: dict) -> list:
    s = d.get("sample")
    if isinstance(s, dict):
        return s.get("rows", [])[:2]
    return (s or d.get("rows") or [])[:2]


def rules_sanity(rules: List[dict]) -> List[dict]:
    """Keep only rules whose regex compiles - a broken rule would block every consumer."""
    ok = []
    for r in rules or []:
        try:
            re.compile(str(r.get("pattern", "")), re.I | re.M)
            ok.append(r)
        except re.error:
            continue
    return ok
