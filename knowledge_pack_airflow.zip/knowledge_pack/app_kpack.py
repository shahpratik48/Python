"""Knowledge Pack builder - command line.

  python app_kpack.py build --system odm                 # fetch odm-dags from GitLab (token asked), describe tables (password asked), build
  python app_kpack.py build --system all                 # ikg, odm and nlg one after the other, one e-mail report
  python app_kpack.py build --system ikg --repo-path /path/to/ikg-dags --no-llm --no-email
  python app_kpack.py show  --system odm                 # summary of the latest pack
  python app_kpack.py search --system odm "how is a new insight registered"
  python app_kpack.py selftest                           # offline check with a sample repo and a sqlite 'Greenplum'
  python app_kpack.py standards-template --system ikg    # skills/ikg/ikg_standards_TEMPLATE.md pre-filled from the latest pack (team completes the TODOs)
  python app_kpack.py merge-skills --system ikg          # all skills/ikg/*.md -> skills/ikg/ikg_skill.md (originals moved to skills/ikg/_merged/); yaml stays

Secrets: environment variables KPACK_AZURE_OPENAI_API_KEY, KPACK_GIT_READ_TOKEN, KPACK_GREENPLUM_PASSWORD, KPACK_EMAIL_PASSWORD
(or hidden prompts with --ask). Nothing is ever written to disk.
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from kpack.config import load_config, secret  # noqa: E402


def build_systems(cfg, systems, repo_paths=None, use_llm=True, send_email=True, allow_prompt=False, progress=print, llm=None, parallel=True):
    """Builds the packs of `systems` - concurrently by default (like the Airflow tasks); one shared model client so the
    rate limiter and the token accounting cover all of them."""
    import concurrent.futures as cf
    from kpack.builder import PackBuilder
    from kpack.config import have_secret, secret
    from kpack.mailer import send_report
    repo_paths = repo_paths or {}
    if use_llm and llm is None and (have_secret("llm_api_key") or secret(cfg, "llm_api_key", allow_prompt=allow_prompt)):
        from agiledev.llm import LLM
        from kpack.config import PACKAGE_ROOT
        cache = Path(cfg.storage.get("llm_cache_dir", "data/cache/llm"))
        llm = LLM(cfg, cache if cache.is_absolute() else PACKAGE_ROOT / cache)
    if allow_prompt:                                   # ask once, up front, not from inside worker threads
        if any(s not in repo_paths for s in systems):
            secret(cfg, "git_read_token", allow_prompt=True)
        secret(cfg, "greenplum_password", allow_prompt=True)

    def one(s):
        t0 = time.time()
        try:
            b = PackBuilder(cfg, s, progress=progress, repo_path=repo_paths.get(s, ""), use_llm=use_llm, allow_prompt=False, llm=llm)
            r = b.build()
            r["system"] = s
            return r
        except Exception as e:  # noqa: BLE001
            logging.exception("build %s failed", s)
            return {"system": s, "error": f"{type(e).__name__}: {str(e)[:300]}", "seconds": round(time.time() - t0, 1)}

    if parallel and len(systems) > 1:
        with cf.ThreadPoolExecutor(len(systems)) as ex:
            results = list(ex.map(one, systems))
    else:
        results = [one(s) for s in systems]
    if llm is not None:
        try:
            st = llm.token_stats()
            t = st.get("total", {})
            progress(f"model usage all systems: {t.get('calls', 0)} calls, {t.get('total_tokens', 0)} tokens, {t.get('cost_usd', 0)} USD, {t.get('seconds_in_calls', 0)}s in calls")
        except Exception:  # noqa: BLE001
            pass
    mail = send_report(cfg, results) if send_email else {"sent": False, "reason": "disabled by flag"}
    return results, mail


def main(argv=None):
    ap = argparse.ArgumentParser(description="Knowledge Pack builder")
    ap.add_argument("command", choices=["build", "show", "search", "selftest", "standards-template", "merge-skills"])
    ap.add_argument("query", nargs="?", default="")
    ap.add_argument("--system", default="", help="odm | ikg | nlg | all (default: default_system from the config)")
    ap.add_argument("--config", default="")
    ap.add_argument("--repo-path", action="append", default=[], help="local repository copy instead of GitLab: 'odm=/path' or just '/path' for one system; a folder, or a text dump (****name****** headers + code)")
    ap.add_argument("--no-llm", action="store_true", help="facts only: no derived layer, BM25 index only (no Azure key needed)")
    ap.add_argument("--no-email", action="store_true")
    ap.add_argument("--ask", action="store_true", help="ask for missing secrets with hidden prompts")
    ap.add_argument("--out", default="", help="standards-template: output file (default skills/<system>/<system>_standards_TEMPLATE.md)")
    ap.add_argument("--sequential", action="store_true", help="build the systems one after the other (default: concurrently)")
    ap.add_argument("-v", action="store_true")
    a = ap.parse_args(argv)
    logging.basicConfig(level=logging.INFO if a.v else logging.WARNING, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    cfg = load_config(a.config or None)
    systems = [a.system or cfg.get("default_system", "odm")]
    if systems[0] == "all":
        systems = list(cfg.systems)

    if a.command == "selftest":
        from kpack.selftest import run_selftest
        return 0 if run_selftest(print) else 1

    if a.command == "merge-skills":
        from kpack.standards import merge_skills
        for s in systems:
            print(json.dumps(merge_skills(cfg, s, a.out), indent=1))
        return 0

    if a.command == "standards-template":
        from kpack.standards import write_template
        for s in systems:
            try:
                print("written:", write_template(cfg, s, a.out if len(systems) == 1 else ""))
            except FileNotFoundError as e:
                print(e)
        return 0

    if a.command == "show":
        from kpack.pack import Pack
        for s in systems:
            try:
                print(json.dumps(Pack.latest(s, cfg).summary(), indent=1))
            except FileNotFoundError as e:
                print(e)
        return 0

    if a.command == "search":
        from kpack.pack import Pack
        p = Pack.latest(systems[0], cfg)
        for h in p.search(a.query, k=10):
            print(f"{h['score']:>7}  {h['kind']:<11} {h['ref'][:70]:<70} via {h.get('via')}")
        return 0

    repo_paths = {}
    for rp in a.repo_path:
        if "=" in rp:
            k, v = rp.split("=", 1); repo_paths[k.strip()] = v.strip()
        else:
            repo_paths[systems[0]] = rp
    if a.ask:
        for name in ("llm_api_key", "embeddings_api_key", "git_read_token", "greenplum_password"):
            if name in ("llm_api_key", "embeddings_api_key") and a.no_llm:
                continue
            if name == "git_read_token" and all(s in repo_paths for s in systems):
                continue
            secret(cfg, name, allow_prompt=True)
    results, mail = build_systems(cfg, systems, repo_paths, use_llm=not a.no_llm, send_email=not a.no_email, allow_prompt=a.ask, parallel=not a.sequential)
    for r in results:
        if r.get("error"):
            print(f"[{r['system']}] FAILED {r['error']}")
        else:
            m = r["manifest"]
            print(f"[{r['system']}] {m['version']} {r['health']['status']} -> {r['path']}  zip {m.get('zip_mb')} MB  items {m['counts']['items']}")
    print("e-mail:", mail)
    return 1 if any(r.get("error") for r in results) else 0


if __name__ == "__main__":
    sys.exit(main())
