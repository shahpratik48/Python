"""
airflow_dag_gitlab_metrics.py  --  DAG 1
-----------------------------------------
Issue throughput and merge request cycle time, for the current month plus
the previous three.

Three tasks, run in order:

    collect_issue_metrics  ->  collect_mr_metrics  ->  build_html_report

Task 1 and Task 2 each push their results to XCom; the third task combines
them into a single HTML report written beside this DAG file. Splitting
collection from reporting means a GitLab outage during Task 2 leaves Task 1's
work visible in the logs and XCom rather than losing the whole run.

Schedule: 18:00 America/New_York, Monday to Friday.

Credentials come from the Airflow Variable GENESIS_DDLC_IKG_GIT_SECRET
(override with the GITLAB_TOKEN_VAR env var), exactly as in the other
projects. Deploy this file together with the gl_*.py modules in the SAME
folder.
"""
from __future__ import annotations

import os
import sys
from datetime import datetime, timedelta

import pendulum
from airflow import DAG
from airflow.models import Variable
from airflow.operators.python import PythonOperator

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from gl_client import GitLabClient
from gl_metrics import (collect_issue_metrics, collect_mr_metrics, metrics_to_payload,
                        month_window, payload_to_metrics)
from gl_report import build_metrics_report, write_report
from gl_settings import GitLabSettings, get_logger, setup_logging

HERE = os.path.dirname(os.path.abspath(__file__))
EST = pendulum.timezone("America/New_York")


def _var(key, default=None):
    try:
        return Variable.get(key, default_var=default)
    except Exception:
        return default


def _settings() -> GitLabSettings:
    s = GitLabSettings()
    s.output_dir = HERE
    s.months_back = int(_var("GL_MONTHS_BACK", str(s.months_back)))
    s.issue_sla_business_days = float(_var("GL_ISSUE_SLA_DAYS", str(s.issue_sla_business_days)))
    s.mr_sla_hours = float(_var("GL_MR_SLA_HOURS", str(s.mr_sla_hours)))
    s.log_level = _var("GL_LOG_LEVEL", s.log_level)
    s.resolve_token(interactive=False)          # Airflow Variable, never prompts
    return s


def task_collect_issues(**kwargs):
    log_path = setup_logging("INFO", log_dir=HERE)
    log = get_logger("dag1.task1")
    s = _settings()
    log.info("Task 1 starting -- issue metrics for project %s", s.project_path)

    months, earliest = month_window(s.months_back)
    client = GitLabClient(s)
    metrics, summaries = collect_issue_metrics(client, s, months, earliest)

    payload = metrics_to_payload(metrics, summaries, [], {})
    ti = kwargs["ti"]
    ti.xcom_push(key="issue_payload", value=payload)
    ti.xcom_push(key="months", value=months)
    ti.xcom_push(key="log_path", value=log_path)

    flagged = sum(s_.flagged_count for s_ in summaries.values())
    log.info("Task 1 done: %d issue(s), %d over the %.4g-business-day SLA.",
             len(metrics), flagged, s.issue_sla_business_days)


def task_collect_mrs(**kwargs):
    setup_logging("INFO", log_dir=HERE)
    log = get_logger("dag1.task2")
    s = _settings()
    log.info("Task 2 starting -- merge request metrics across %s", ", ".join(s.code_repos))

    ti = kwargs["ti"]
    months = ti.xcom_pull(task_ids="collect_issue_metrics", key="months")
    if not months:
        months, _ = month_window(s.months_back)
        log.warning("No month list from Task 1 -- recomputed locally as %s", months)
    _, earliest = month_window(s.months_back)

    client = GitLabClient(s)
    metrics, summaries = collect_mr_metrics(client, s, months, earliest)

    ti.xcom_push(key="mr_payload", value=metrics_to_payload([], {}, metrics, summaries))
    flagged = sum(s_.flagged_count for s_ in summaries.values())
    log.info("Task 2 done: %d MR(s), %d over the %.4g-hour SLA.",
             len(metrics), flagged, s.mr_sla_hours)


def task_build_report(**kwargs):
    log_path = setup_logging("INFO", log_dir=HERE)
    log = get_logger("dag1.task3")
    s = _settings()
    ti = kwargs["ti"]

    months = ti.xcom_pull(task_ids="collect_issue_metrics", key="months") or []
    ipay = ti.xcom_pull(task_ids="collect_issue_metrics", key="issue_payload") or {}
    mpay = ti.xcom_pull(task_ids="collect_mr_metrics", key="mr_payload") or {}
    log.info("Task 3 starting -- combining results for months %s", months)

    issue_metrics, issue_summaries, _, _ = payload_to_metrics(ipay)
    _, _, mr_metrics, mr_summaries = payload_to_metrics(mpay)

    # a month with no data still needs a row in the report
    from gl_metrics import MonthIssueSummary, MonthMRSummary
    for m in months:
        issue_summaries.setdefault(m, MonthIssueSummary(month=m))
        mr_summaries.setdefault(m, MonthMRSummary(month=m))

    html = build_metrics_report(s, months, issue_metrics, issue_summaries,
                                mr_metrics, mr_summaries,
                                ti.xcom_pull(task_ids="collect_issue_metrics", key="log_path") or log_path)
    path = write_report(html, s.output_dir, "gitlab_metrics_report")

    ti.xcom_push(key="report_path", value=path)
    i_flag = sum(x.flagged_count for x in issue_summaries.values())
    m_flag = sum(x.flagged_count for x in mr_summaries.values())
    log.info("Report written: %s", path)
    log.info("Summary: %d issue(s) closed (%d flagged), %d MR(s) (%d flagged).",
             sum(x.closed_count for x in issue_summaries.values()), i_flag,
             sum(x.total_count for x in mr_summaries.values()), m_flag)
    print(f"\nReport: {path}\nFlagged: {i_flag} issue(s), {m_flag} merge request(s)")


default_args = {
    "owner": "STAAT-DS",
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
    "email_on_failure": True,
}

with DAG(
    dag_id="gitlab_productivity_metrics",
    default_args=default_args,
    description="Issues closed and MR cycle time for the current month plus the previous three.",
    start_date=datetime(2026, 1, 1, tzinfo=EST),
    schedule_interval="0 18 * * 1-5",        # 18:00 EST, Monday-Friday
    catchup=False,
    max_active_runs=1,
    tags=["gitlab", "metrics", "productivity"],
) as dag:

    t1 = PythonOperator(task_id="collect_issue_metrics", python_callable=task_collect_issues)
    t2 = PythonOperator(task_id="collect_mr_metrics", python_callable=task_collect_mrs)
    t3 = PythonOperator(task_id="build_html_report", python_callable=task_build_report)

    t1 >> t2 >> t3
