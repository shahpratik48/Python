"""
GitLab REST client for the productivity reporting project.

Everything is paginated, logged, and defensive: this runs unattended in
Airflow, so a permission gap or a missing optional feature (epics and
iterations are licence-dependent) is logged and degraded gracefully rather
than crashing a whole run.
"""
from __future__ import annotations

import urllib.parse
from typing import Dict, Iterable, List, Optional

from gl_settings import get_logger

log = get_logger("gitlab.client")


class GitLabClient:
    def __init__(self, settings):
        import requests
        self._requests = requests
        self.s = settings
        self.base = settings.gitlab_url.rstrip("/")
        self.token = settings.gitlab_token
        if not self.token:
            raise RuntimeError("GitLabClient requires a token -- call settings.resolve_token() first.")
        self._session = requests.Session()
        self._session.headers.update({"PRIVATE-TOKEN": self.token})
        self._project_ids: Dict[str, int] = {}
        self._group_ids: Dict[str, int] = {}
        log.info("GitLab client ready for %s", self.base)

    # ------------------------------------------------------------------ core
    def _get(self, path: str, params: Optional[dict] = None, allow_404: bool = False):
        url = f"{self.base}/api/v4{path}"
        log.debug("GET %s params=%s", url, params)
        r = self._session.get(url, params=params or {}, timeout=60)
        if r.status_code == 404 and allow_404:
            log.warning("404 Not Found for %s -- returning empty.", url)
            return None
        r.raise_for_status()
        return r.json()

    def _get_paged(self, path: str, params: Optional[dict] = None,
                   max_pages: int = 100) -> List[dict]:
        out, page, params = [], 1, dict(params or {})
        params.setdefault("per_page", 100)
        while page <= max_pages:
            params["page"] = page
            batch = self._get(path, params)
            if not batch:
                break
            out.extend(batch)
            if len(batch) < params["per_page"]:
                break
            page += 1
        if page > max_pages:
            log.warning("Pagination stopped at the %d-page cap for %s -- results may be partial.",
                        max_pages, path)
        log.debug("GET %s -> %d record(s)", path, len(out))
        return out

    def _post(self, path: str, payload: dict):
        url = f"{self.base}/api/v4{path}"
        log.debug("POST %s payload=%s", url, payload)
        r = self._session.post(url, json=payload, timeout=60)
        r.raise_for_status()
        return r.json()

    def _put(self, path: str, payload: dict):
        url = f"{self.base}/api/v4{path}"
        log.debug("PUT %s payload=%s", url, payload)
        r = self._session.put(url, json=payload, timeout=60)
        r.raise_for_status()
        return r.json()

    # ------------------------------------------------------------ id lookups
    def project_id(self, project_path: str) -> int:
        if project_path not in self._project_ids:
            enc = urllib.parse.quote(project_path, safe="")
            data = self._get(f"/projects/{enc}")
            self._project_ids[project_path] = data["id"]
            log.info("Resolved project '%s' -> id %s", project_path, data["id"])
        return self._project_ids[project_path]

    def group_id(self, group_path: str) -> int:
        if group_path not in self._group_ids:
            enc = urllib.parse.quote(group_path, safe="")
            data = self._get(f"/groups/{enc}")
            self._group_ids[group_path] = data["id"]
            log.info("Resolved group '%s' -> id %s", group_path, data["id"])
        return self._group_ids[group_path]

    # ---------------------------------------------------------------- issues
    def closed_issues(self, project_path: str, updated_after: str) -> List[dict]:
        """Closed issues touched since `updated_after` (ISO 8601).

        Filtering is deliberately done on `updated_after` rather than
        `closed_after`: an issue closed inside the window is always also
        updated inside it, and this stays correct on GitLab versions where
        the closed_* filters behave inconsistently. The exact month bucket
        is decided later from each issue's own `closed_at`.
        """
        pid = self.project_id(project_path)
        log.info("Fetching closed issues for project id %s updated after %s", pid, updated_after)
        issues = self._get_paged(f"/projects/{pid}/issues",
                                 {"state": "closed", "updated_after": updated_after,
                                  "scope": "all", "order_by": "updated_at", "sort": "desc"})
        log.info("Fetched %d closed issue(s).", len(issues))
        return issues

    def issue_label_events(self, project_path: str, issue_iid: int) -> List[dict]:
        pid = self.project_id(project_path)
        events = self._get_paged(f"/projects/{pid}/issues/{issue_iid}/resource_label_events") or []
        log.debug("Issue #%s -> %d label event(s)", issue_iid, len(events))
        return events

    def issue_state_events(self, project_path: str, issue_iid: int) -> List[dict]:
        pid = self.project_id(project_path)
        return self._get_paged(f"/projects/{pid}/issues/{issue_iid}/resource_state_events") or []

    def list_issues(self, project_path: str, **params) -> List[dict]:
        pid = self.project_id(project_path)
        return self._get_paged(f"/projects/{pid}/issues", params)

    def create_issue(self, project_path: str, payload: dict) -> dict:
        pid = self.project_id(project_path)
        log.info("Creating issue in project %s: %r", project_path, payload.get("title"))
        return self._post(f"/projects/{pid}/issues", payload)

    def close_issue(self, project_path: str, issue_iid: int) -> dict:
        pid = self.project_id(project_path)
        log.info("Closing issue #%s in %s", issue_iid, project_path)
        return self._put(f"/projects/{pid}/issues/{issue_iid}", {"state_event": "close"})

    def update_issue(self, project_path: str, issue_iid: int, payload: dict) -> dict:
        pid = self.project_id(project_path)
        return self._put(f"/projects/{pid}/issues/{issue_iid}", payload)

    # -------------------------------------------------------- merge requests
    def merge_requests(self, project_path: str, updated_after: str) -> List[dict]:
        """Merged + closed MRs touched since `updated_after`."""
        pid = self.project_id(project_path)
        log.info("Fetching merge requests for project id %s updated after %s", pid, updated_after)
        mrs = self._get_paged(f"/projects/{pid}/merge_requests",
                              {"state": "all", "updated_after": updated_after,
                               "scope": "all", "order_by": "updated_at", "sort": "desc"})
        log.info("Fetched %d merge request(s) for %s.", len(mrs), project_path)
        return mrs

    def mr_commits(self, project_path: str, mr_iid: int) -> List[dict]:
        """Commits on an MR -- the earliest of these is when a file in the MR
        was first touched."""
        pid = self.project_id(project_path)
        commits = self._get_paged(f"/projects/{pid}/merge_requests/{mr_iid}/commits") or []
        log.debug("MR !%s -> %d commit(s)", mr_iid, len(commits))
        return commits

    # ------------------------------------------------------------ iterations
    def current_iteration(self, group_path: str) -> Optional[dict]:
        """The group's current iteration. Iterations are a Premium feature, so
        a 404/403 here is logged and returns None rather than failing."""
        gid = self.group_id(group_path)
        try:
            data = self._get(f"/groups/{gid}/iterations",
                             {"state": "current", "include_ancestors": "true", "per_page": 100},
                             allow_404=True)
        except Exception as e:
            log.error("Could not read iterations for group %s: %s", group_path, e)
            return None
        if not data:
            log.warning("No current iteration found for group '%s'.", group_path)
            return None
        it = data[0]
        log.info("Current iteration: id=%s title=%r %s -> %s",
                 it.get("id"), it.get("title") or "(untitled)",
                 it.get("start_date"), it.get("due_date"))
        return it

    # ----------------------------------------------------------------- epics
    def find_epic(self, group_path: str, title: str) -> Optional[dict]:
        """Locate an epic by (case-insensitive) exact title. Epics are a
        Premium feature; absence is logged, not fatal."""
        gid = self.group_id(group_path)
        try:
            epics = self._get_paged(f"/groups/{gid}/epics",
                                    {"search": title, "include_ancestor_groups": "true"})
        except Exception as e:
            log.error("Could not search epics in group %s: %s", group_path, e)
            return None
        for e in epics or []:
            if str(e.get("title", "")).strip().lower() == title.strip().lower():
                log.info("Matched parent epic %r -> id=%s iid=%s", title, e.get("id"), e.get("iid"))
                return e
        log.warning("No epic titled %r found in group '%s' (searched %d candidate(s)).",
                    title, group_path, len(epics or []))
        return None
