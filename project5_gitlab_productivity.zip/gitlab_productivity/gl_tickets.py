"""
Ticket automation.

DAG 2 -- create the standing set of BAU tickets in the CURRENT iteration.
DAG 3 -- close every open ticket matching that same signature.

Both resolve the current iteration and the parent epic first and refuse to
proceed without them: creating tickets with no iteration, or closing a set
defined by a filter that silently matched everything, are both worse than
failing loudly.

DAG 2 is idempotent. It looks for an existing open ticket with the same
title in the same iteration and skips it rather than creating a duplicate,
so an accidental re-run does not produce eleven more tickets.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from gl_settings import get_logger

log = get_logger("gitlab.tickets")


@dataclass
class TicketAction:
    title: str
    action: str                 # "created" | "skipped_existing" | "closed" | "failed" | "dry_run"
    issue_iid: Optional[int] = None
    web_url: str = ""
    detail: str = ""


@dataclass
class TicketRunResult:
    iteration_title: str = ""
    iteration_id: Optional[int] = None
    epic_title: str = ""
    epic_id: Optional[int] = None
    actions: List[TicketAction] = field(default_factory=list)
    dry_run: bool = False

    @property
    def created(self) -> int:
        return sum(1 for a in self.actions if a.action == "created")

    @property
    def closed(self) -> int:
        return sum(1 for a in self.actions if a.action == "closed")

    @property
    def skipped(self) -> int:
        return sum(1 for a in self.actions if a.action == "skipped_existing")

    @property
    def failed(self) -> int:
        return sum(1 for a in self.actions if a.action == "failed")


def _resolve_context(client, settings, require_epic: bool = True):
    """Current iteration + parent epic. Raises when either is missing."""
    log.info("Resolving current iteration for group '%s'...", settings.group_path)
    iteration = client.current_iteration(settings.group_path)
    if not iteration:
        raise RuntimeError(
            f"No CURRENT iteration found in group '{settings.group_path}'. Tickets must be placed in "
            f"the current iteration, so this run is stopping rather than creating them without one. "
            f"Check that an iteration cadence exists and that today falls inside an active iteration.")

    log.info("Resolving parent epic %r...", settings.ticket_parent)
    epic = client.find_epic(settings.group_path, settings.ticket_parent)
    if not epic and require_epic:
        raise RuntimeError(
            f"Parent epic {settings.ticket_parent!r} was not found in group '{settings.group_path}'. "
            f"Stopping rather than creating tickets without their parent. Verify the epic title, and "
            f"that the token has epic read access (epics require a Premium licence).")
    return iteration, epic


# ------------------------------------------------------------------ DAG 2
def create_tickets(client, settings) -> TicketRunResult:
    log.info("=== DAG 2: create %d BAU ticket(s) ===", len(settings.ticket_titles))
    iteration, epic = _resolve_context(client, settings, require_epic=True)

    result = TicketRunResult(
        iteration_title=str(iteration.get("title") or f"Iteration {iteration.get('id')}"),
        iteration_id=iteration.get("id"),
        epic_title=str(epic.get("title", "")), epic_id=epic.get("id"),
        dry_run=settings.dry_run)

    log.info("Checking for tickets that already exist in this iteration (idempotency guard)...")
    try:
        existing = client.list_issues(
            settings.project_path,
            state="opened", labels=settings.ticket_label,
            iteration_id=iteration.get("id"), scope="all")
        existing_titles = {str(i.get("title", "")).strip().lower() for i in existing}
        log.info("Found %d existing open '%s' ticket(s) in the current iteration.",
                 len(existing), settings.ticket_label)
    except Exception as e:
        log.warning("Could not list existing tickets (%s) -- proceeding without the duplicate "
                    "guard, so re-running may create duplicates.", e)
        existing_titles = set()

    for title in settings.ticket_titles:
        if title.strip().lower() in existing_titles:
            log.info("SKIP  %r -- already open in this iteration.", title)
            result.actions.append(TicketAction(title, "skipped_existing",
                                               detail="An open ticket with this title already "
                                                      "exists in the current iteration."))
            continue

        payload = {
            "title": title,
            "description": title,                     # description mirrors the title, as specified
            "labels": settings.ticket_label,
            "weight": settings.ticket_weight,
            "iteration_id": iteration.get("id"),
            "epic_id": epic.get("id"),
        }

        if settings.dry_run:
            log.info("DRY-RUN would create %r with %s", title, payload)
            result.actions.append(TicketAction(title, "dry_run",
                                               detail=f"Would create with {payload}"))
            continue

        try:
            issue = client.create_issue(settings.project_path, payload)
            log.info("CREATED #%s %r", issue.get("iid"), title)
            result.actions.append(TicketAction(title, "created", issue_iid=issue.get("iid"),
                                               web_url=str(issue.get("web_url", ""))))
        except Exception as e:
            log.error("FAILED to create %r: %s", title, e)
            result.actions.append(TicketAction(title, "failed", detail=f"{type(e).__name__}: {e}"))

    log.info("DAG 2 complete: created=%d skipped=%d failed=%d dry_run=%s",
             result.created, result.skipped, result.failed, result.dry_run)
    return result


# ------------------------------------------------------------------ DAG 3
def close_tickets(client, settings) -> TicketRunResult:
    log.info("=== DAG 3: close open BAU tickets ===")
    iteration, epic = _resolve_context(client, settings, require_epic=False)

    result = TicketRunResult(
        iteration_title=str(iteration.get("title") or f"Iteration {iteration.get('id')}"),
        iteration_id=iteration.get("id"),
        epic_title=str((epic or {}).get("title", settings.ticket_parent)),
        epic_id=(epic or {}).get("id"), dry_run=settings.dry_run)

    log.info("Finding open issues with label=%r in iteration %r...",
             settings.ticket_label, result.iteration_title)
    issues = client.list_issues(settings.project_path, state="opened",
                                labels=settings.ticket_label,
                                iteration_id=iteration.get("id"), scope="all")
    log.info("Label+iteration filter matched %d open issue(s).", len(issues))

    # The API cannot filter on parent epic, so narrow it here. Without a
    # resolved epic we cannot verify parentage, and closing tickets that
    # merely share a label would be too blunt -- so we stop instead.
    if result.epic_id is None:
        raise RuntimeError(
            f"Parent epic {settings.ticket_parent!r} could not be resolved, so tickets cannot be "
            f"verified as belonging to it. Refusing to close {len(issues)} issue(s) on the label and "
            f"iteration alone -- that would risk closing unrelated work.")

    targets = []
    for issue in issues:
        eid = issue.get("epic_id") or (issue.get("epic") or {}).get("id")
        if eid == result.epic_id:
            targets.append(issue)
        else:
            log.debug("Skipping #%s -- parent epic %s does not match %s",
                      issue.get("iid"), eid, result.epic_id)
    log.info("%d of those belong to parent epic %r and will be closed.",
             len(targets), result.epic_title)

    for issue in targets:
        iid, title = issue.get("iid"), str(issue.get("title", ""))
        if settings.dry_run:
            log.info("DRY-RUN would close #%s %r", iid, title)
            result.actions.append(TicketAction(title, "dry_run", issue_iid=iid,
                                               web_url=str(issue.get("web_url", "")),
                                               detail="Would close this issue."))
            continue
        try:
            client.close_issue(settings.project_path, iid)
            log.info("CLOSED #%s %r", iid, title)
            result.actions.append(TicketAction(title, "closed", issue_iid=iid,
                                               web_url=str(issue.get("web_url", ""))))
        except Exception as e:
            log.error("FAILED to close #%s %r: %s", iid, title, e)
            result.actions.append(TicketAction(title, "failed", issue_iid=iid,
                                               detail=f"{type(e).__name__}: {e}"))

    log.info("DAG 3 complete: closed=%d failed=%d dry_run=%s",
             result.closed, result.failed, result.dry_run)
    return result
