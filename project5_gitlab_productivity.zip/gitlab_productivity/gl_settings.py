"""
Configuration and logging for the GitLab productivity reporting project.

Token resolution follows the same pattern as the other projects:
  - interactive=True  (notebook): env var -> Airflow Variable -> getpass prompt
  - interactive=False (Airflow):  env var -> Airflow Variable -> raise

Nothing is ever hard-coded and nothing is written back to disk.
"""
from __future__ import annotations

import getpass
import logging
import os
import sys
from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional

# --------------------------------------------------------------------------
# Logging
# --------------------------------------------------------------------------
_LOG_FORMAT = "%(asctime)s | %(levelname)-7s | %(name)-22s | %(message)s"
_configured = False


def setup_logging(level: str = "INFO", log_dir: Optional[str] = None,
                  log_to_file: bool = True) -> str:
    """Configures root logging once. Returns the log file path (or "").

    Logs go to stdout so they appear in Airflow task logs and in notebook
    output, and additionally to a timestamped file next to the scripts so a
    run can be reviewed after the fact.
    """
    global _configured
    root = logging.getLogger()
    log_path = ""

    if _configured:
        return getattr(root, "_gl_log_path", "")

    root.setLevel(getattr(logging, str(level).upper(), logging.INFO))
    for h in list(root.handlers):
        root.removeHandler(h)

    stream = logging.StreamHandler(sys.stdout)
    stream.setFormatter(logging.Formatter(_LOG_FORMAT))
    root.addHandler(stream)

    if log_to_file:
        log_dir = log_dir or os.path.dirname(os.path.abspath(__file__))
        os.makedirs(log_dir, exist_ok=True)
        log_path = os.path.join(
            log_dir, f"gitlab_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
        fh = logging.FileHandler(log_path, encoding="utf-8")
        fh.setFormatter(logging.Formatter(_LOG_FORMAT))
        root.addHandler(fh)

    # third-party HTTP chatter would drown out our own logs
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("requests").setLevel(logging.WARNING)

    root._gl_log_path = log_path        # type: ignore[attr-defined]
    _configured = True
    logging.getLogger("gitlab.setup").info(
        "Logging initialised (level=%s, file=%s)", level, log_path or "<stdout only>")
    return log_path


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)


def _env(name: str, default: Optional[str] = None) -> Optional[str]:
    return os.getenv(name, default)


@dataclass
class GitLabSettings:
    # ---------------- connection ----------------
    gitlab_url: str = field(default_factory=lambda: _env("GITLAB_URL", "https://devcloud.ubs.net"))
    gitlab_token: Optional[str] = field(default_factory=lambda: _env("GITLAB_TOKEN", ""))
    gitlab_token_var: str = field(default_factory=lambda: _env(
        "GITLAB_TOKEN_VAR", "GENESIS_DDLC_IKG_GIT_SECRET"))

    # ---------------- issues / iterations / epics ----------------
    group_path: str = field(default_factory=lambda: _env(
        "GROUP_PATH",
        "ubs/gwma/smart-technology-and-analytics/staat-data-science/staat-ds-insights-cl/commons"))
    project_path: str = field(default_factory=lambda: _env(
        "PROJECT_PATH",
        "ubs/gwma/smart-technology-and-analytics/staat-data-science/staat-ds-insights-cl/commons/"
        "staat-ds-insights-home"))

    # ---------------- code repositories (merge requests) ----------------
    ikg_project_path: str = field(default_factory=lambda: _env(
        "IKG_PROJECT_PATH",
        "ubs/gwma/smart-technology-and-analytics/staat-data-science/staat-ds-genesis/"
        "genesis-platform/ikg-dags"))
    nlg_project_path: str = field(default_factory=lambda: _env(
        "NLG_PROJECT_PATH",
        "ubs/gwma/smart-technology-and-analytics/staat-data-science/staat-ds-genesis/"
        "genesis-platform/nlg-dags"))
    odm_project_path: str = field(default_factory=lambda: _env(
        "ODM_PROJECT_PATH",
        "ubs/gwma/smart-technology-and-analytics/staat-data-science/staat-ds-genesis/"
        "genesis-platform/odm-dags"))

    @property
    def code_repos(self) -> dict:
        return {"IKG": self.ikg_project_path,
                "NLG": self.nlg_project_path,
                "ODM": self.odm_project_path}

    # ---------------- reporting window / thresholds ----------------
    months_back: int = field(default_factory=lambda: int(_env("GL_MONTHS_BACK", "3")))
    issue_sla_business_days: float = field(default_factory=lambda: float(_env("GL_ISSUE_SLA_DAYS", "5")))
    mr_sla_hours: float = field(default_factory=lambda: float(_env("GL_MR_SLA_HOURS", "72")))

    # Which label marks "In progress". Matching is case-insensitive and also
    # matches scoped labels such as `workflow::In progress`, since teams vary
    # in how they name this.
    in_progress_labels: List[str] = field(default_factory=lambda: [
        s.strip() for s in _env("GL_IN_PROGRESS_LABELS", "in progress,in-progress,doing,wip").split(",")
        if s.strip()])

    # ---------------- ticket automation (DAG 2 / DAG 3) ----------------
    ticket_label: str = field(default_factory=lambda: _env("GL_TICKET_LABEL", "@productivity"))
    ticket_parent: str = field(default_factory=lambda: _env("GL_TICKET_PARENT", "BAU Technical 2026"))
    ticket_weight: int = field(default_factory=lambda: int(_env("GL_TICKET_WEIGHT", "1")))
    ticket_titles: List[str] = field(default_factory=lambda: [
        "QA Testing for new insights",
        "UAT Testing for new insights",
        "Pipeline monitoring for Dev",
        "Pipeline monitoring for preprod",
        "Pipeline monitoring for production",
        "Pipeline monitoring for Dummy",
        "Dashboard enhencements for release",
        "Dashboard enhencements for metadata",
        "Code review for IKG",
        "Code review for ODM",
        "Code review for NLG",
    ])

    # ---------------- output ----------------
    output_dir: str = field(default_factory=lambda: _env(
        "GL_OUTPUT_DIR", os.path.dirname(os.path.abspath(__file__))))
    log_level: str = field(default_factory=lambda: _env("GL_LOG_LEVEL", "INFO"))

    # Safety switch for the write DAGs: when True nothing is created or
    # closed, but every action that WOULD be taken is logged and reported.
    dry_run: bool = field(default_factory=lambda: _env("GL_DRY_RUN", "false").lower() == "true")

    # ---------------- secrets ----------------
    def _airflow_variable(self, key: str) -> Optional[str]:
        try:
            from airflow.models import Variable  # type: ignore
            return Variable.get(key, default_var=None)
        except Exception:
            return None

    def resolve_token(self, interactive: bool = True) -> "GitLabSettings":
        log = get_logger("gitlab.settings")
        if self.gitlab_token:
            log.info("GitLab token supplied via environment/constructor.")
            return self

        self.gitlab_token = self._airflow_variable(self.gitlab_token_var)
        if self.gitlab_token:
            log.info("GitLab token resolved from Airflow Variable '%s'.", self.gitlab_token_var)
            return self

        if interactive:
            log.info("No token in environment or Airflow Variable -- prompting.")
            self.gitlab_token = getpass.getpass("GitLab personal access token: ").strip() or None
            if self.gitlab_token:
                log.info("GitLab token captured from prompt (hidden input).")
            return self

        raise RuntimeError(
            f"No GitLab token available. Set the GITLAB_TOKEN environment variable or the "
            f"Airflow Variable '{self.gitlab_token_var}'.")
