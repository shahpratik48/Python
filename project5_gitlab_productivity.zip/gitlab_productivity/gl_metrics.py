"""
Metrics for DAG 1.

Task 1 -- issues: how many closed per month, the elapsed time from the
"In progress" transition to closure for each, and the monthly average.
Elapsed time is measured in BUSINESS days (weekends excluded), and
anything over the SLA is flagged.

Task 2 -- merge requests, summed across the IKG / NLG / ODM repositories:
how many per author per month, the elapsed time from the moment a file in
the MR was first touched (the earliest commit on the MR) until it closed,
and the monthly average. Measured in calendar hours, flagged over the SLA.

Two deliberate choices worth knowing about:

* "In progress" is detected from resource label events, matching any of the
  configured label names case-insensitively, including scoped forms such as
  `workflow::In progress`. An issue with no such event cannot have a cycle
  time computed -- it is reported as UNKNOWN and counted separately, never
  silently dropped or treated as zero.
* An MR's "first file touched" is the earliest commit on the MR. If an MR
  has no commits (or they cannot be read) the elapsed time is UNKNOWN and
  reported as such, again rather than being quietly skipped.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Tuple

from gl_settings import get_logger

log = get_logger("gitlab.metrics")


# ------------------------------------------------------------------ time utils
def parse_ts(value: Optional[str]) -> Optional[datetime]:
    """Parses GitLab ISO 8601 timestamps into timezone-aware UTC datetimes."""
    if not value:
        return None
    txt = str(value).strip().replace("Z", "+00:00")
    try:
        dt = datetime.fromisoformat(txt)
    except ValueError:
        for fmt in ("%Y-%m-%dT%H:%M:%S.%f%z", "%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%d"):
            try:
                dt = datetime.strptime(txt, fmt)
                break
            except ValueError:
                continue
        else:
            log.warning("Could not parse timestamp %r", value)
            return None
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt.astimezone(timezone.utc)


def business_days_between(start: datetime, end: datetime) -> float:
    """Fractional business days between two instants, excluding Sat/Sun.

    Walks the interval a day at a time and accumulates only the portion
    falling on a weekday, so a Friday-afternoon-to-Monday-morning span
    correctly counts well under one business day rather than three.
    """
    if not start or not end or end <= start:
        return 0.0
    total, cur, guard = 0.0, start, 0
    while cur < end and guard < 4000:
        nxt = (cur + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
        seg_end = min(nxt, end)
        if cur.weekday() < 5:                      # Mon=0 .. Fri=4
            total += (seg_end - cur).total_seconds() / 86400.0
        cur, guard = seg_end, guard + 1
    return round(total, 2)


def elapsed_hours(start: datetime, end: datetime) -> float:
    if not start or not end or end <= start:
        return 0.0
    return round((end - start).total_seconds() / 3600.0, 2)


def month_key(dt: datetime) -> str:
    return dt.strftime("%Y-%m")


def month_window(months_back: int, now: Optional[datetime] = None) -> Tuple[List[str], datetime]:
    """The month buckets to report on (current month plus `months_back`
    previous months) and the UTC cutoff to fetch from."""
    now = now or datetime.now(timezone.utc)
    keys, cursor = [], now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    for _ in range(months_back + 1):
        keys.append(month_key(cursor))
        cursor = (cursor - timedelta(days=1)).replace(day=1)
    keys.reverse()
    earliest = datetime.strptime(keys[0] + "-01", "%Y-%m-%d").replace(tzinfo=timezone.utc)
    log.info("Reporting window: %s (fetching data updated on/after %s)",
             ", ".join(keys), earliest.date())
    return keys, earliest


# ------------------------------------------------------------------ models
@dataclass
class IssueMetric:
    iid: int
    title: str
    author: str
    assignee: str
    month: str
    in_progress_at: Optional[datetime]
    closed_at: Optional[datetime]
    elapsed_business_days: Optional[float]
    flagged: bool
    note: str = ""
    web_url: str = ""


@dataclass
class MonthIssueSummary:
    month: str
    closed_count: int = 0
    measured_count: int = 0          # those with a usable in-progress transition
    unknown_count: int = 0
    avg_business_days: Optional[float] = None
    flagged_count: int = 0


@dataclass
class MRMetric:
    repo: str
    iid: int
    title: str
    author: str
    month: str
    first_touch_at: Optional[datetime]
    closed_at: Optional[datetime]
    elapsed_hours: Optional[float]
    state: str
    flagged: bool
    note: str = ""
    web_url: str = ""


@dataclass
class MonthMRSummary:
    month: str
    total_count: int = 0
    per_author: Dict[str, int] = field(default_factory=dict)
    measured_count: int = 0
    unknown_count: int = 0
    avg_hours: Optional[float] = None
    flagged_count: int = 0


# ------------------------------------------------------------------ Task 1
def _first_in_progress(events: List[dict], wanted: List[str]) -> Optional[datetime]:
    """Earliest moment an 'in progress' style label was ADDED."""
    wanted_lc = [w.lower() for w in wanted]
    stamps = []
    for ev in events or []:
        if str(ev.get("action", "")).lower() != "add":
            continue
        name = str((ev.get("label") or {}).get("name", "")).lower()
        if not name:
            continue
        # matches "in progress", "In-Progress", and scoped "workflow::in progress"
        tail = name.split("::")[-1].strip()
        if any(w == name or w == tail or w in name for w in wanted_lc):
            ts = parse_ts(ev.get("created_at"))
            if ts:
                stamps.append(ts)
    return min(stamps) if stamps else None


def collect_issue_metrics(client, settings, months: List[str],
                          earliest: datetime) -> Tuple[List[IssueMetric], Dict[str, MonthIssueSummary]]:
    log.info("=== Task 1: issue closure metrics ===")
    issues = client.closed_issues(settings.project_path, earliest.isoformat())

    metrics: List[IssueMetric] = []
    summaries = {m: MonthIssueSummary(month=m) for m in months}
    considered = 0

    for issue in issues:
        closed_at = parse_ts(issue.get("closed_at"))
        if not closed_at:
            continue
        mkey = month_key(closed_at)
        if mkey not in summaries:
            continue                                    # closed outside the window
        considered += 1
        iid = issue.get("iid")

        try:
            events = client.issue_label_events(settings.project_path, iid)
        except Exception as e:
            log.error("Could not read label events for issue #%s: %s", iid, e)
            events = []

        in_prog = _first_in_progress(events, settings.in_progress_labels)
        if in_prog and in_prog <= closed_at:
            days = business_days_between(in_prog, closed_at)
            flagged = days > settings.issue_sla_business_days
            note = (f"Over the {settings.issue_sla_business_days:g}-business-day SLA."
                    if flagged else "")
        else:
            days, flagged = None, False
            note = ("No 'in progress' label transition found before closure, so cycle time cannot "
                    "be measured for this issue.")

        m = IssueMetric(
            iid=iid, title=str(issue.get("title", ""))[:200],
            author=str((issue.get("author") or {}).get("username", "unknown")),
            assignee=str((issue.get("assignee") or {}).get("username", "") or "unassigned"),
            month=mkey, in_progress_at=in_prog, closed_at=closed_at,
            elapsed_business_days=days, flagged=flagged, note=note,
            web_url=str(issue.get("web_url", "")))
        metrics.append(m)

        s = summaries[mkey]
        s.closed_count += 1
        if days is None:
            s.unknown_count += 1
        else:
            s.measured_count += 1
            if flagged:
                s.flagged_count += 1

    for mkey, s in summaries.items():
        vals = [m.elapsed_business_days for m in metrics
                if m.month == mkey and m.elapsed_business_days is not None]
        s.avg_business_days = round(sum(vals) / len(vals), 2) if vals else None
        log.info("%s -> closed=%d measured=%d unknown=%d avg=%s flagged=%d",
                 mkey, s.closed_count, s.measured_count, s.unknown_count,
                 s.avg_business_days, s.flagged_count)

    log.info("Task 1 complete: %d issue(s) in window, %d flagged.",
             considered, sum(s.flagged_count for s in summaries.values()))
    return metrics, summaries


# ------------------------------------------------------------------ Task 2
def collect_mr_metrics(client, settings, months: List[str],
                       earliest: datetime) -> Tuple[List[MRMetric], Dict[str, MonthMRSummary]]:
    log.info("=== Task 2: merge request metrics across %s ===",
             ", ".join(settings.code_repos.keys()))
    metrics: List[MRMetric] = []
    summaries = {m: MonthMRSummary(month=m) for m in months}

    for repo_name, repo_path in settings.code_repos.items():
        log.info("--- repository %s ---", repo_name)
        try:
            mrs = client.merge_requests(repo_path, earliest.isoformat())
        except Exception as e:
            log.error("Could not fetch merge requests for %s (%s): %s", repo_name, repo_path, e)
            continue

        for mr in mrs:
            iid = mr.get("iid")
            closed_at = parse_ts(mr.get("merged_at")) or parse_ts(mr.get("closed_at"))
            if not closed_at:
                continue                                # still open -- no elapsed time yet
            mkey = month_key(closed_at)
            if mkey not in summaries:
                continue

            author = str((mr.get("author") or {}).get("username", "unknown"))
            try:
                commits = client.mr_commits(repo_path, iid)
            except Exception as e:
                log.error("Could not read commits for %s MR !%s: %s", repo_name, iid, e)
                commits = []

            stamps = [t for t in (parse_ts(c.get("committed_date") or c.get("created_at"))
                                  for c in commits) if t]
            first_touch = min(stamps) if stamps else None

            if first_touch and first_touch <= closed_at:
                hours = elapsed_hours(first_touch, closed_at)
                flagged = hours > settings.mr_sla_hours
                note = f"Over the {settings.mr_sla_hours:g}-hour SLA." if flagged else ""
            else:
                hours, flagged = None, False
                note = ("No commit history available for this MR, so the time from first file "
                        "touched to closure cannot be measured.")

            metrics.append(MRMetric(
                repo=repo_name, iid=iid, title=str(mr.get("title", ""))[:200], author=author,
                month=mkey, first_touch_at=first_touch, closed_at=closed_at,
                elapsed_hours=hours, state=str(mr.get("state", "")), flagged=flagged,
                note=note, web_url=str(mr.get("web_url", ""))))

            s = summaries[mkey]
            s.total_count += 1
            s.per_author[author] = s.per_author.get(author, 0) + 1
            if hours is None:
                s.unknown_count += 1
            else:
                s.measured_count += 1
                if flagged:
                    s.flagged_count += 1

    for mkey, s in summaries.items():
        vals = [m.elapsed_hours for m in metrics if m.month == mkey and m.elapsed_hours is not None]
        s.avg_hours = round(sum(vals) / len(vals), 2) if vals else None
        log.info("%s -> MRs=%d authors=%d measured=%d unknown=%d avg_hours=%s flagged=%d",
                 mkey, s.total_count, len(s.per_author), s.measured_count,
                 s.unknown_count, s.avg_hours, s.flagged_count)

    log.info("Task 2 complete: %d MR(s) in window, %d flagged.",
             len(metrics), sum(s.flagged_count for s in summaries.values()))
    return metrics, summaries


# ------------------------------------------------------------------ serde
# Airflow passes data between tasks through XCom, which must be JSON-safe.
# These helpers round-trip the metric objects so Task 1 and Task 2 can hand
# their results to the reporting task without recomputing anything.
def _dt_out(dt: Optional[datetime]) -> Optional[str]:
    return dt.isoformat() if dt else None


def metrics_to_payload(issue_metrics, issue_summaries, mr_metrics, mr_summaries) -> dict:
    return {
        "issue_metrics": [{**vars(m), "in_progress_at": _dt_out(m.in_progress_at),
                           "closed_at": _dt_out(m.closed_at)} for m in issue_metrics],
        "issue_summaries": {k: dict(vars(v)) for k, v in issue_summaries.items()},
        "mr_metrics": [{**vars(m), "first_touch_at": _dt_out(m.first_touch_at),
                        "closed_at": _dt_out(m.closed_at)} for m in mr_metrics],
        "mr_summaries": {k: dict(vars(v)) for k, v in mr_summaries.items()},
    }


def payload_to_metrics(payload: dict):
    payload = payload or {}
    issues = [IssueMetric(**{**d, "in_progress_at": parse_ts(d.get("in_progress_at")),
                             "closed_at": parse_ts(d.get("closed_at"))})
              for d in payload.get("issue_metrics", [])]
    isums = {k: MonthIssueSummary(**v) for k, v in (payload.get("issue_summaries") or {}).items()}
    mrs = [MRMetric(**{**d, "first_touch_at": parse_ts(d.get("first_touch_at")),
                       "closed_at": parse_ts(d.get("closed_at"))})
           for d in payload.get("mr_metrics", [])]
    msums = {k: MonthMRSummary(**v) for k, v in (payload.get("mr_summaries") or {}).items()}
    return issues, isums, mrs, msums
