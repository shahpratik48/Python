"""
airflow_dag_gitlab_create_tickets.py  --  DAG 2
------------------------------------------------
Creates the standing set of BAU tickets in the CURRENT iteration.

No schedule -- triggered manually, typically on a Wednesday.

Two tasks, run in order:

    create_bau_tickets  ->  build_html_report

Every ticket is created with weight=1, label=@productivity, the current
iteration, and parent epic "BAU Technical 2026". The run refuses to start if
either the current iteration or the parent epic cannot be resolved, rather
than creating tickets that are missing them.

Creation is idempotent: a ticket whose title is already open in the current
iteration is skipped, so an accidental second trigger does not duplicate the
set.

Set the Airflow Variable GL_DRY_RUN=true to log exactly what would be
created without creating anything.

Deploy together with the gl_*.py modules in the SAME folder.
"""
from __future__ import annotations

import os
import sys
from datetime import datetime, timedelta

from airflow import DAG
from airflow.models import Variable
from airflow.operators.python import PythonOperator

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from gl_client import GitLabClient
from gl_report import build_ticket_report, write_report
from gl_settings import GitLabSettings, get_logger, setup_logging
from gl_tickets import TicketAction, TicketRunResult, create_tickets

HERE = os.path.dirname(os.path.abspath(__file__))


def _var(key, default=None):
    try:
        return Variable.get(key, default_var=default)
    except Exception:
        return default


def _settings(conf: dict) -> GitLabSettings:
    s = GitLabSettings()
    s.output_dir = HERE
    s.ticket_label = conf.get("label") or _var("GL_TICKET_LABEL", s.ticket_label)
    s.ticket_parent = conf.get("parent") or _var("GL_TICKET_PARENT", s.ticket_parent)
    s.ticket_weight = int(conf.get("weight") or _var("GL_TICKET_WEIGHT", str(s.ticket_weight)))
    dry = conf.get("dry_run")
    s.dry_run = (str(dry).lower() == "true") if dry is not None \
        else str(_var("GL_DRY_RUN", "false")).lower() == "true"
    s.resolve_token(interactive=False)
    return s


def task_create(**kwargs):
    log_path = setup_logging("INFO", log_dir=HERE)
    log = get_logger("dag2.create")
    conf = (kwargs.get("dag_run").conf if kwargs.get("dag_run") else {}) or {}
    s = _settings(conf)

    log.info("Creating %d BAU ticket(s) in project %s (dry_run=%s)",
             len(s.ticket_titles), s.project_path, s.dry_run)
    result = create_tickets(GitLabClient(s), s)

    ti = kwargs["ti"]
    ti.xcom_push(key="result", value={
        "iteration_title": result.iteration_title, "iteration_id": result.iteration_id,
        "epic_title": result.epic_title, "epic_id": result.epic_id, "dry_run": result.dry_run,
        "actions": [vars(a) for a in result.actions]})
    ti.xcom_push(key="log_path", value=log_path)

    log.info("created=%d skipped=%d failed=%d", result.created, result.skipped, result.failed)
    if result.failed:
        raise RuntimeError(
            f"{result.failed} ticket(s) could not be created -- see the report and logs. "
            f"({result.created} created, {result.skipped} skipped as already existing.)")


def task_report(**kwargs):
    log_path = setup_logging("INFO", log_dir=HERE)
    log = get_logger("dag2.report")
    conf = (kwargs.get("dag_run").conf if kwargs.get("dag_run") else {}) or {}
    s = _settings(conf)

    ti = kwargs["ti"]
    raw = ti.xcom_pull(task_ids="create_bau_tickets", key="result") or {}
    result = TicketRunResult(
        iteration_title=raw.get("iteration_title", ""), iteration_id=raw.get("iteration_id"),
        epic_title=raw.get("epic_title", ""), epic_id=raw.get("epic_id"),
        dry_run=bool(raw.get("dry_run")),
        actions=[TicketAction(**a) for a in raw.get("actions", [])])

    path = write_report(build_ticket_report(s, result, "create",
                                            ti.xcom_pull(task_ids="create_bau_tickets", key="log_path") or log_path),
                        s.output_dir, "gitlab_create_tickets_report")
    ti.xcom_push(key="report_path", value=path)
    log.info("Report written: %s", path)
    print(f"\nReport: {path}\nCreated {result.created}, skipped {result.skipped}, failed {result.failed}")


default_args = {
    "owner": "STAAT-DS",
    "retries": 0,          # creating tickets is a write -- never auto-retry
    "retry_delay": timedelta(minutes=5),
    "email_on_failure": True,
}

with DAG(
    dag_id="gitlab_create_bau_tickets",
    default_args=default_args,
    description='Creates the standing BAU ticket set in the current iteration. Manual trigger; '
                'pass {"dry_run": "true"} to preview.',
    start_date=datetime(2026, 1, 1),
    schedule_interval=None,        # manual only
    catchup=False,
    max_active_runs=1,
    tags=["gitlab", "tickets", "bau", "manual"],
) as dag:

    t1 = PythonOperator(task_id="create_bau_tickets", python_callable=task_create)
    t2 = PythonOperator(task_id="build_html_report", python_callable=task_report,
                        trigger_rule="all_done")   # still report even if creation partly failed

    t1 >> t2
