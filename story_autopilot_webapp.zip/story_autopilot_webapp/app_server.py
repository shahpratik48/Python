"""Story Autopilot - standalone service: watcher + queue + worker + agents, and the control center / onboarding web app.

    python app_server.py                  # run: watcher, worker and the web app (secrets from the vault / environment)
    python app_server.py --no-autostart   # web app only; press Start in the control center
    python app_server.py --check          # test GitLab token, story board, iteration, onboarding table, model key; exit
    python app_server.py --init-table     # create the Greenplum onboarding table and copy the config apps into it; exit
    python app_server.py --demo           # control center with a fake GitLab + scripted model (no secrets) - to look around
    python app_server.py --run-selftest   # offline end-to-end test

Secrets (names under `secrets:` in config/autopilot_config.yaml; Azure Key Vault references or HashiCorp vault):
AUTOPILOT_GIT_TOKEN, AGILEDEV_AZURE_OPENAI_API_KEY, AUTOPILOT_GP_PASSWORD, AGILEDEV_SERVER_SECRET (+ AGILEDEV_OIDC_CLIENT_SECRET).
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from agiledev.config import get_secret, load_config  # noqa: E402


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config")
    ap.add_argument("--host")
    ap.add_argument("--port", type=int)
    ap.add_argument("--auth", choices=["header", "oidc", "dev"], help="override auth.mode")
    ap.add_argument("--no-autostart", action="store_true")
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--init-table", action="store_true")
    ap.add_argument("--demo", action="store_true")
    ap.add_argument("--run-selftest", action="store_true")
    a = ap.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    for n in ("httpx", "openai", "urllib3", "sqlglot"):
        logging.getLogger(n).setLevel(logging.WARNING)
    cfg = load_config(a.config)
    if a.auth:
        cfg["auth"] = dict(cfg.get("auth") or {}, mode=a.auth)
    if a.run_selftest:
        from autopilot.selftest import run_selftest
        run_selftest(cfg, ROOT / "data_selftest" / "autopilot")
        print("SELFTEST OK")
        return
    from autopilot.server import serve
    from autopilot.service import Autopilot
    if a.demo:
        from agiledev.selftest import ScriptedLLM
        from autopilot.selftest import build_env
        c, fake, base, srv, restore, _ = build_env(cfg, ROOT / "data_selftest" / "demo")
        c["auth"] = dict(c.get("auth") or {}, mode="dev")
        c["autopilot"]["poll_minutes"] = 0.25
        svc = Autopilot(c, llm=ScriptedLLM(c, ROOT / "data_selftest" / "demo" / "data/cache/llm"), token="fake-token")
        svc.apps.seed_from_config("demo")
        fake.discussions.setdefault(1, [])
        svc.start()
        print(f"DEMO: fake GitLab at {base}; control center on http://localhost:{a.port or 8790}/ (sign in with any e-mail)")
        serve(c, svc, a.host, a.port or 8790)
        return
    svc = Autopilot(cfg)
    if a.init_table:
        print(svc.apps.ensure_table())
        print(f"{svc.apps.seed_from_config('init')} app(s) copied from the config file")
        return
    if a.check:
        print(json.dumps(svc.check(), indent=1))
        try:
            print("model:", svc.llm.check())
        except Exception as e:  # noqa: BLE001
            print("model check failed:", type(e).__name__, str(e)[:200])
        return
    if not a.no_autostart:
        try:
            print(json.dumps(svc.start(), indent=1))
        except Exception as e:  # noqa: BLE001
            logging.error("autopilot not started (%s) - open the control center and press Start once fixed", e)
    serve(cfg, svc, a.host, a.port)


if __name__ == "__main__":
    main()
