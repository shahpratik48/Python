"""Local state (sqlite, one file): the queue, what the watcher last saw of each story, branches / MRs per story and app,
handled /ai-fix comments, the cost ledger and the settings changed from the control center. Thread-safe."""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from pathlib import Path
from typing import Dict, List, Optional

SCHEMA = """
create table if not exists stories(iid text primary key, title text, iteration_id text, iteration text, labels text, assignee text,
    apps text, status text, decision text, web_url text, updated_at text, seen_at real, block_sig text, extra text);
create table if not exists queue(id integer primary key autoincrement, kind text, iid text, title text, apps text, position real,
    state text, payload text, enqueued_at real, started_at real, finished_at real, result text);
create table if not exists branches(iid text, app text, project text, branch text, base text, target text, mr_iid text, mr_url text,
    draft integer, updated_at real, primary key(iid, app));
create table if not exists notes(note_id text primary key, iid text, app text, mr_iid text, handled_at real, queue_id integer);
create table if not exists costs(day text, iid text, usd real, tokens integer, at real);
create table if not exists settings(key text primary key, value text);
create table if not exists events(id integer primary key autoincrement, at real, kind text, iid text, title text, detail text);
"""


class State:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self.db = sqlite3.connect(str(self.path), check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        with self._lock:
            self.db.executescript(SCHEMA)
            self.db.commit()

    def _x(self, sql: str, args=()) -> List[dict]:
        with self._lock:
            cur = self.db.execute(sql, args)
            rows = [dict(r) for r in cur.fetchall()] if cur.description else []
            self.db.commit()
            return rows

    # ------------------------------------------------------------------ settings
    def setting(self, key: str, default=None):
        r = self._x("select value from settings where key=?", (key,))
        return json.loads(r[0]["value"]) if r else default

    def set_setting(self, key: str, value) -> None:
        self._x("insert or replace into settings(key, value) values(?,?)", (key, json.dumps(value)))

    # ------------------------------------------------------------------ stories
    def upsert_story(self, iid, **kw) -> None:
        cur = self.story(iid) or {}
        row = dict(cur, iid=str(iid), **{k: (json.dumps(v) if isinstance(v, (list, dict)) else v) for k, v in kw.items()})
        cols = ["iid", "title", "iteration_id", "iteration", "labels", "assignee", "apps", "status", "decision", "web_url", "updated_at",
                "seen_at", "block_sig", "extra"]
        vals = [row.get(c) if not isinstance(row.get(c), (list, dict)) else json.dumps(row.get(c)) for c in cols]
        self._x(f"insert or replace into stories({','.join(cols)}) values({','.join('?' * len(cols))})", vals)

    def story(self, iid) -> Optional[dict]:
        r = self._x("select * from stories where iid=?", (str(iid),))
        return self._dec(r[0]) if r else None

    def stories(self) -> List[dict]:
        return [self._dec(r) for r in self._x("select * from stories order by cast(iid as integer) desc")]

    @staticmethod
    def _dec(r: dict) -> dict:
        for k in ("labels", "apps", "decision", "extra", "payload", "result"):
            if k in r and isinstance(r[k], str) and r[k][:1] in "[{":
                try:
                    r[k] = json.loads(r[k])
                except ValueError:
                    pass
        return r

    # ------------------------------------------------------------------ queue
    def enqueue(self, kind: str, iid, title: str = "", apps=None, payload: Optional[dict] = None) -> Optional[int]:
        """Adds a job unless the same story already has one of that kind waiting / running. Returns its id (None = already there)."""
        with self._lock:
            ex = self._x("select id from queue where kind=? and iid=? and state in ('queued','running')", (kind, str(iid)))
            if ex:
                return None
            pos = (self._x("select max(position) m from queue where state='queued'")[0]["m"] or 0) + 1
            self._x("insert into queue(kind, iid, title, apps, position, state, payload, enqueued_at) values(?,?,?,?,?,?,?,?)",
                    (kind, str(iid), title, json.dumps(apps or []), pos, "queued", json.dumps(payload or {}), time.time()))
            return self._x("select max(id) i from queue")[0]["i"]

    def queue(self, states=("queued", "running")) -> List[dict]:
        q = ",".join("?" * len(states))
        return [self._dec(r) for r in self._x(f"select * from queue where state in ({q}) order by state='running' desc, position", tuple(states))]

    def history(self, limit: int = 50) -> List[dict]:
        return [self._dec(r) for r in self._x("select * from queue where state not in ('queued','running') order by finished_at desc limit ?", (limit,))]

    def jobs_of(self, iid) -> List[dict]:
        return [self._dec(r) for r in self._x("select * from queue where iid=? order by id desc", (str(iid),))]

    def next_job(self) -> Optional[dict]:
        with self._lock:
            r = self._x("select * from queue where state='queued' order by position limit 1")
            if not r:
                return None
            self._x("update queue set state='running', started_at=? where id=?", (time.time(), r[0]["id"]))
            r[0]["state"] = "running"
            return self._dec(r[0])

    def finish(self, job_id: int, state: str, result: dict) -> None:
        self._x("update queue set state=?, finished_at=?, result=? where id=?", (state, time.time(), json.dumps(result, default=str), job_id))

    def reorder(self, ids: List[int]) -> None:
        """The queued jobs in this order (ids not listed keep their relative order after them)."""
        with self._lock:
            rest = [j["id"] for j in self.queue(("queued",)) if j["id"] not in ids]
            for i, jid in enumerate(list(ids) + rest, 1):
                self._x("update queue set position=? where id=? and state='queued'", (float(i), int(jid)))

    def move(self, job_id: int, where: str) -> None:
        ids = [j["id"] for j in self.queue(("queued",))]
        if job_id not in ids:
            return
        i = ids.index(job_id)
        ids.pop(i)
        j = {"top": 0, "bottom": len(ids), "up": max(0, i - 1), "down": min(len(ids), i + 1)}.get(where, i)
        ids.insert(j, job_id)
        self.reorder(ids)

    def cancel(self, job_id: int) -> None:
        self._x("update queue set state='cancelled', finished_at=? where id=? and state='queued'", (time.time(), job_id))

    def recover(self) -> int:
        """After a restart: a job left 'running' goes back to the head of the queue."""
        rows = self._x("select id from queue where state='running'")
        for r in rows:
            self._x("update queue set state='queued', position=0 where id=?", (r["id"],))
        return len(rows)

    # ------------------------------------------------------------------ branches / MRs
    def set_branch(self, iid, app, **kw) -> None:
        cur = self.branch(iid, app) or {}
        row = dict(cur, iid=str(iid), app=app, updated_at=time.time(), **kw)
        cols = ["iid", "app", "project", "branch", "base", "target", "mr_iid", "mr_url", "draft", "updated_at"]
        self._x(f"insert or replace into branches({','.join(cols)}) values({','.join('?' * len(cols))})", [row.get(c) for c in cols])

    def branch(self, iid, app) -> Optional[dict]:
        r = self._x("select * from branches where iid=? and app=?", (str(iid), app))
        return r[0] if r else None

    def branches(self, iid=None) -> List[dict]:
        return self._x("select * from branches where iid=?", (str(iid),)) if iid is not None else self._x("select * from branches")

    # ------------------------------------------------------------------ /ai-fix notes
    def note_seen(self, note_id) -> bool:
        return bool(self._x("select 1 from notes where note_id=?", (str(note_id),)))

    def mark_note(self, note_id, iid, app, mr_iid, queue_id=None) -> None:
        self._x("insert or replace into notes(note_id, iid, app, mr_iid, handled_at, queue_id) values(?,?,?,?,?,?)",
                (str(note_id), str(iid), app, str(mr_iid), time.time(), queue_id))

    # ------------------------------------------------------------------ costs
    def add_cost(self, iid, usd: float, tokens: int) -> None:
        self._x("insert into costs(day, iid, usd, tokens, at) values(?,?,?,?,?)", (time.strftime("%Y-%m-%d"), str(iid), float(usd or 0), int(tokens or 0), time.time()))

    def cost_today(self) -> float:
        return float(self._x("select coalesce(sum(usd),0) s from costs where day=?", (time.strftime("%Y-%m-%d"),))[0]["s"])

    def cost_story(self, iid) -> float:
        return float(self._x("select coalesce(sum(usd),0) s from costs where iid=?", (str(iid),))[0]["s"])

    # ------------------------------------------------------------------ events (control center feed)
    def event(self, kind: str, iid, title: str, detail: str = "") -> None:
        self._x("insert into events(at, kind, iid, title, detail) values(?,?,?,?,?)", (time.time(), kind, str(iid or ""), title[:300], detail[:2000]))
        self._x("delete from events where id < (select max(id) - 3000 from events)")

    def events(self, iid=None, limit: int = 200) -> List[dict]:
        if iid is not None:
            return self._x("select * from events where iid=? order by id desc limit ?", (str(iid), limit))
        return self._x("select * from events order by id desc limit ?", (limit,))
