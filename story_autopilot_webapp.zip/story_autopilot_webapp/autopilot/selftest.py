"""Offline end-to-end test of Story Autopilot: a fake GitLab (REST API in a local HTTP server + bare git repositories), the
scripted model of the agent engine, a sqlite file playing Greenplum. Nothing leaves the machine.

    python app_server.py --run-selftest

Checks: pick-up rules (ready / blocked / back from QA / not ready), one comment per block reason, labels created once, the
agent run, branch + commit author / committer + push, MR created once (Draft rules), story labels and comment, /ai-fix on
the MR (change, push to the same branch, reply in the thread, ai_review_fix_done), rework (same branch + MR,
agent_re_code_done), queue order, cost limit, dry run, onboarding table."""
from __future__ import annotations

import json
import re
import shutil
import subprocess
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Dict, List
from urllib.parse import parse_qs, unquote, urlparse

BOARD = "group/staat-ds-insights-home"
IKG = "group/ikg-dags"
NOW = "2026-11-05T10:00:00Z"


class FakeGitLab:
    """Just enough of the GitLab v4 API, in memory."""

    def __init__(self):
        self.lock = threading.Lock()
        self.me = {"id": 1, "username": "svc_autopilot", "name": "Story Autopilot Service", "email": "svc_autopilot@example.local"}
        self.users = {7: {"id": 7, "username": "pshah", "name": "shah pratik 49010206", "public_email": "pratik.shah@example.local"},
                      8: {"id": 8, "username": "jdoe", "name": "doe jane 49010300", "public_email": "jane.doe@example.local"}}
        self.iterations = [{"id": 91, "iid": 12, "title": None, "start_date": "2026-11-04", "due_date": "2026-11-17", "state": "current"},
                           {"id": 90, "iid": 11, "title": None, "start_date": "2026-10-21", "due_date": "2026-11-03", "state": "closed"}]
        self.labels = {"status::in progress": {"name": "status::In Progress"}, "status::qa": {"name": "status::QA"}, "ikg": {"name": "IKG"},
                       "ready_for_agent": {"name": "ready_for_agent"}}
        self.created_labels: List[str] = []
        self.issues: Dict[int, dict] = {}
        self.label_events: Dict[int, list] = {}
        self.state_events: Dict[int, list] = {}
        self.notes: Dict[int, list] = {}
        self.mrs: Dict[int, dict] = {}
        self.discussions: Dict[int, list] = {}
        self.branches: Dict[str, List[str]] = {IKG: ["ikg-master", "ikg-dev"]}
        self.writes: List[str] = []

    def add_issue(self, iid, title, labels, assignees=(7,), iteration=91, desc="", history=()):
        self.issues[iid] = {"iid": iid, "id": 1000 + iid, "title": title, "description": desc, "labels": list(labels), "state": "opened",
                            "assignees": [self.users[a] for a in assignees], "iteration": next(i for i in self.iterations if i["id"] == iteration),
                            "web_url": f"http://fake/{BOARD}/-/issues/{iid}", "updated_at": NOW}
        self.label_events[iid] = [{"created_at": at, "action": act, "label": {"name": name}} for at, act, name in history]
        self.state_events[iid] = []
        self.notes[iid] = []

    # ------------------------------------------------------------------ dispatch
    def handle(self, method, path, q, body):
        with self.lock:
            return self._handle(method, path, q, body)

    def _handle(self, method, path, q, body):
        p = unquote(path)
        if p == "/api/v4/user":
            return self.me
        m = re.match(r"^/api/v4/users/(\d+)$", p)
        if m:
            return self.users.get(int(m.group(1)), {})
        m = re.match(r"^/api/v4/projects/(.+?)/(iterations|issues|labels|repository/branches|merge_requests)(.*)$", p)
        if not m:
            return 404, {"message": "not found"}
        proj, kind, rest = m.group(1), m.group(2), m.group(3)
        if kind == "iterations":
            st = q.get("state", ["all"])[0]
            return [i for i in self.iterations if st in ("all", i["state"])]
        if kind == "labels":
            if method == "POST":
                self.labels[body["name"].lower()] = {"name": body["name"]}
                self.created_labels.append(body["name"])
                self.writes.append(f"label {body['name']}")
                return {"name": body["name"]}
            return list(self.labels.values())
        if kind == "repository/branches":
            s = q.get("search", [""])[0]
            return [{"name": b} for b in self.branches.get(proj, []) if s in b]
        if kind == "issues":
            if rest in ("", "/"):
                st = q.get("state", ["opened"])[0]
                it = q.get("iteration_id", [""])[0]
                rows = [i for i in self.issues.values() if i["state"] == st]
                if it:
                    rows = [i for i in rows if (it == "Current" and i["iteration"]["state"] == "current") or str(i["iteration"]["id"]) == it]
                return rows
            m2 = re.match(r"^/(\d+)(.*)$", rest)
            iid, sub = int(m2.group(1)), m2.group(2)
            it = self.issues[iid]
            if sub == "":
                if method == "PUT":
                    add = [x for x in str(body.get("add_labels", "")).split(",") if x]
                    rem = [x for x in str(body.get("remove_labels", "")).split(",") if x]
                    for x in add:
                        if x not in it["labels"]:
                            it["labels"].append(x)
                            self.label_events[iid].append({"created_at": NOW, "action": "add", "label": {"name": x}})
                    it["labels"] = [x for x in it["labels"] if x not in rem]
                    self.writes.append(f"#{iid} +{add} -{rem}")
                return it
            if sub == "/notes":
                if method == "POST":
                    n = {"id": len(self.notes[iid]) + 1, "body": body["body"], "author": {"name": self.me["name"]}, "system": False, "created_at": NOW}
                    self.notes[iid].append(n)
                    self.writes.append(f"#{iid} comment")
                    return n
                return self.notes[iid]
            if sub == "/resource_label_events":
                return self.label_events[iid]
            if sub == "/resource_state_events":
                return self.state_events[iid]
        if kind == "merge_requests":
            if rest in ("", "/"):
                if method == "POST":
                    iid = len(self.mrs) + 1
                    mr = dict(body, iid=iid, state="opened", web_url=f"http://fake/{proj}/-/merge_requests/{iid}", project=proj)
                    self.mrs[iid] = mr
                    self.discussions[iid] = []
                    self.writes.append(f"MR !{iid} {body['title']}")
                    return mr
                src = q.get("source_branch", [""])[0]
                tgt = q.get("target_branch", [""])[0]
                return [m_ for m_ in self.mrs.values() if m_["state"] == "opened" and m_["source_branch"] == src and (not tgt or m_["target_branch"] == tgt)]
            m2 = re.match(r"^/(\d+)(.*)$", rest)
            mid, sub = int(m2.group(1)), m2.group(2)
            if sub == "":
                if method == "PUT":
                    self.mrs[mid].update(body)
                    self.writes.append(f"MR !{mid} updated")
                return self.mrs[mid]
            if sub == "/discussions":
                return self.discussions[mid]
            m3 = re.match(r"^/discussions/([^/]+)/notes$", sub)
            if m3:
                d = next(x for x in self.discussions[mid] if x["id"] == m3.group(1))
                n = {"id": 9000 + len(d["notes"]), "body": body["body"], "author": {"username": self.me["username"], "name": self.me["name"]}, "system": False}
                d["notes"].append(n)
                self.writes.append(f"MR !{mid} reply")
                return n
            if sub == "/notes":
                self.writes.append(f"MR !{mid} note")
                return {"id": 1}
        return 404, {"message": "not found"}


def serve(fake: FakeGitLab):
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _do(self, method):
            u = urlparse(self.path)
            body = {}
            n = int(self.headers.get("Content-Length") or 0)
            if n:
                body = json.loads(self.rfile.read(n) or b"{}")
            r = fake.handle(method, u.path, parse_qs(u.query), body)
            code = 200
            if isinstance(r, tuple):
                code, r = r
            data = json.dumps(r).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self):
            self._do("GET")

        def do_POST(self):
            self._do("POST")

        def do_PUT(self):
            self._do("PUT")

    srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


def _git(*a, cwd=None):
    return subprocess.run(["git", *a], cwd=cwd, capture_output=True, text=True, check=True).stdout


def build_env(cfg, out: Path):
    """Fake GitLab + bare IKG repository + sample pack + sqlite onboarding table + five stories. Returns (config, fake, base url, server, restore)."""
    from agiledev.config import Config
    from agiledev.gitworkspace import GitWorkspace
    from agiledev.selftest import ScriptedLLM, make_sample_inputs, make_sample_pack
    from .service import Autopilot

    out = Path(out).resolve()
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)
    fake = FakeGitLab()
    srv = serve(fake)
    base = f"http://127.0.0.1:{srv.server_port}"
    # ---- the IKG repository: a bare repo with ikg-master + ikg-dev, seeded from the sample repository
    paths = make_sample_inputs(out / "samples")
    remotes = out / "remotes"
    seed = out / "seed"
    shutil.copytree(paths["repo"], seed)
    _git("init", "-q", "-b", "ikg-master", cwd=seed)
    _git("-c", "user.email=a@b", "-c", "user.name=seed", "add", "-A", cwd=seed)
    _git("-c", "user.email=a@b", "-c", "user.name=seed", "commit", "-qm", "init", cwd=seed)
    _git("branch", "ikg-dev", cwd=seed)
    (remotes / "group").mkdir(parents=True)
    _git("clone", "-q", "--bare", str(seed), str(remotes / f"{IKG}.git"))
    orig_remote = GitWorkspace._remote_url
    GitWorkspace._remote_url = lambda self, url: "file://" + str(remotes / (url.split(base + "/", 1)[-1] if base in url else IKG)) + ".git"
    # ---- config: everything local
    c = Config(json.loads(json.dumps(cfg, default=str)))
    c["_path"] = cfg.get("_path")
    a = c["autopilot"]
    a["story_board"]["project_url"] = f"{base}/{BOARD}"
    a["greenplum"]["sqlite_path"] = str(out / "onboarding.db")
    a["storage"] = {"state_db": str(out / "autopilot.db"), "stories_dir": str(out / "stories")}
    a["limits"]["usd_per_day"] = 1000
    for app in c["apps"]:
        app["repo_url"] = f"{base}/{IKG}" if app["app_id"] == "ikg" else app["repo_url"]
    c["knowledge_packs"]["dir"] = str(out / "packs")
    c["storage"] = dict(c["storage"], data_dir=str(out / "data"), llm_cache_dir=str(out / "data/cache/llm"), git_mirrors_dir=str(out / "data/cache/git"),
                        plan_lock_dir=str(out / "data/cache/plans"), repo_cache_dir=str(out / "data/cache/repos"))
    c["knowledge_packs"]["shared_cache_dir"] = str(out / "data/packs")
    (out / "packs").mkdir()
    make_sample_pack(paths["repo"], out / "packs" / "ikg_pack.zip")
    c["embeddings"] = dict(c.get("embeddings") or {}, enabled=False)
    # ---- the stories
    story = paths["story"].read_text(encoding="utf-8")
    ip, qa = "status::In Progress", "status::QA"
    fake.add_issue(101, "Client activity summary", [ip, "ready_for_agent", "IKG"], desc=story,
                   history=[("2026-11-05T09:00:00Z", "add", ip)])
    fake.add_issue(102, "No app label story", [ip, "ready_for_agent"], history=[("2026-11-05T09:00:00Z", "add", ip)])
    fake.add_issue(103, "Back from QA", [ip, "ready_for_agent", "IKG"], desc=story,
                   history=[("2026-11-01T09:00:00Z", "add", ip), ("2026-11-03T09:00:00Z", "remove", ip), ("2026-11-03T09:00:00Z", "add", qa),
                            ("2026-11-05T08:00:00Z", "remove", qa), ("2026-11-05T08:00:00Z", "add", ip)])
    fake.add_issue(104, "Not ready yet", [ip, "IKG"], history=[("2026-11-05T09:00:00Z", "add", ip)])
    fake.add_issue(105, "Two assignees", [ip, "ready_for_agent", "IKG"], assignees=(7, 8), history=[("2026-11-05T09:00:00Z", "add", ip)])
    def restore():
        GitWorkspace._remote_url = orig_remote
        srv.shutdown()
    return c, fake, base, srv, restore, remotes


def run_selftest(cfg, out: Path, verbose: bool = True) -> dict:
    from agiledev.selftest import ScriptedLLM
    from .service import Autopilot
    say = print if verbose else (lambda *a: None)
    c, fake, base, srv, restore, remotes = build_env(cfg, out)
    a = c["autopilot"]
    ip = "status::In Progress"
    out = Path(out).resolve()
    checks = {}
    try:
        svc = Autopilot(c, llm=ScriptedLLM(c, out / "data/cache/llm"), token="fake-token")
        # onboarding table (sqlite plays Greenplum): seeded from the config apps
        n = svc.apps.seed_from_config("selftest")
        assert n == 3 and svc.apps.source == "sqlite" and svc.apps.label_map().get("ikg") == "ikg", (n, svc.apps.source)
        checks["onboarding table"] = "3 apps seeded"
        info = svc.check()
        assert info["token_owner"] == "svc_autopilot" and info["current_iteration"] == "Nov 4 - 17, 2026", info
        # ---- poll 1
        r = svc.poll_once()
        q = svc.state.queue()
        assert [j["iid"] for j in q] == ["101"], [(j["iid"], j["kind"]) for j in q]
        d = {s["iid"]: s["decision"] for s in svc.state.stories()}
        assert "blocked" in d["102"]["reason"] and "application label" in d["102"]["block"], d["102"]
        assert "came back to In progress from status::QA" in d["103"]["reason"], d["103"]
        assert "ready_for_agent" in d["104"]["reason"], d["104"]
        assert "exactly one assignee" in d["105"]["block"], d["105"]
        assert "ai_blocked" in fake.issues[102]["labels"] and len(fake.notes[102]) == 1
        assert set(fake.created_labels) >= {"re_work_for_agent", "agent_code_done", "ai_blocked", "ai_failed"}, fake.created_labels
        svc.poll_once()
        assert len(fake.notes[102]) == 1, "a block comment must not repeat every poll"
        checks["pick-up rules"] = "101 queued; 102 / 105 blocked once; 103 back from QA waits for rework; 104 not ready"
        # ---- the worker runs 101
        assert svc.step()
        j = svc.state.history(1)[0]
        assert j["state"] == "done", j
        b = svc.state.branch("101", "ikg")
        assert b["branch"] == "101-ikg-client-activity-summary-ai" and b["mr_iid"] == "1", b
        mr = fake.mrs[1]
        assert mr["source_branch"] == b["branch"] and mr["target_branch"] == "ikg-dev" and mr["assignee_id"] == 7, mr
        bare = remotes / f"{IKG}.git"
        log_ = _git("log", "-1", "--format=%an|%ae|%cn|%ce|%s", b["branch"], cwd=bare).strip()
        assert log_.startswith("Pratik Shah|pratik.shah@example.local|Story Autopilot Service|svc_autopilot@example.local|101-ikg-ai"), log_
        labels = fake.issues[101]["labels"]
        assert "agent_code_done" in labels and "ai_working" not in labels, labels
        assert any("Story Autopilot** finished" in n_["body"] for n_ in fake.notes[101]), fake.notes[101]
        w = svc.worker
        assert w._draft({"confidence": {"score": 90}}, {"score": 80, "findings": [{"severity": "high", "status": "open"}]}), "open high finding -> Draft"
        assert w._draft({"confidence": {"score": 50}}, {"score": 90, "findings": []}), "low confidence -> Draft"
        assert not w._draft({"confidence": {"score": 90}}, {"score": 90, "findings": [{"severity": "high", "status": "fixed"}]}), "fixed findings -> ready MR"
        checks["story run"] = f"pushed {b['branch']} (author Pratik Shah, committer the token owner), MR !1 -> ikg-dev assigned to the assignee, agent_code_done"
        # done stories are not picked again
        svc.poll_once()
        assert not svc.state.queue(), svc.state.queue()
        # ---- /ai-fix on the MR
        fake.discussions[1].append({"id": "d1", "notes": [{"id": 501, "body": "/ai-fix only active accounts with a positive balance (balance > 0)",
                                                            "author": {"username": "reviewer", "name": "Rita Reviewer"}, "system": False,
                                                            "position": {"new_path": "dags/ikg/scripts/sql/ikg_create_profiles/client_activity_summary_ikg.sql", "new_line": 7}}]})
        fake.discussions[1].append({"id": "d2", "notes": [{"id": 502, "body": "looks fine to me", "author": {"username": "reviewer"}, "system": False}]})
        svc.poll_once()
        q = svc.state.queue()
        assert [(x["kind"], x["iid"]) for x in q] == [("mr_fix", "101")], q
        head_before = _git("rev-parse", b["branch"], cwd=bare).strip()
        assert svc.step()
        jr = svc.state.history(1)[0]
        assert jr["state"] == "done" and jr["result"].get("pushed"), jr
        assert _git("rev-parse", b["branch"], cwd=bare).strip() != head_before
        assert len(fake.mrs) == 1 and any("Story Autopilot changed" in n_["body"] for n_ in fake.discussions[1][0]["notes"]), fake.discussions[1]
        assert "ai_review_fix_done" in fake.issues[101]["labels"]
        svc.poll_once()
        assert not svc.state.queue(), "an /ai-fix comment is handled once; other comments are ignored"
        checks["MR /ai-fix"] = "change pushed to the same branch, reply in the thread, ai_review_fix_done; plain comments ignored"
        # ---- rework: same branch, same MR, agent_re_code_done
        fake.issues[101]["labels"].append("re_work_for_agent")
        svc.poll_once()
        q = svc.state.queue()
        assert q and q[0]["payload"]["kind"] == "rework", q
        assert svc.step()
        assert len(fake.mrs) == 1 and "agent_re_code_done" in fake.issues[101]["labels"] and "re_work_for_agent" not in fake.issues[101]["labels"], fake.issues[101]["labels"]
        checks["rework"] = "same branch + MR !1, agent_re_code_done, rework label removed"
        # ---- 103 with the rework label; queue order
        fake.issues[103]["labels"].append("re_work_for_agent")
        fake.issues[102]["labels"].append("IKG")
        svc.poll_once()
        ids = [x["iid"] for x in svc.state.queue()]
        assert ids == ["102", "103"], ids
        svc.state.move(svc.state.queue()[1]["id"], "top")
        assert [x["iid"] for x in svc.state.queue()] == ["103", "102"]
        checks["queue"] = "102 + 103 queued, 103 moved to the top"
        # ---- cost limit + switches
        a["limits"]["usd_per_day"] = 0
        assert "daily model budget" in svc.blocked_reason() and not svc.step()
        a["limits"]["usd_per_day"] = 1000
        svc.set_paused(True)
        assert not svc.step()
        svc.set_paused(False)
        checks["limits"] = "daily budget and pause stop the worker"
        # ---- dry run: nothing written
        svc.state.set_setting("dry_run", True)
        before = len(fake.writes)
        fake.add_issue(106, "Dry run story", [ip, "ready_for_agent"], history=[("2026-11-05T09:00:00Z", "add", ip)])
        svc.poll_once()
        assert len(fake.writes) == before, fake.writes[before:]
        svc.state.set_setting("dry_run", False)
        checks["dry run"] = "decisions made, nothing written to GitLab"
        # ---- control center data
        tr = svc.tree(refresh=True)
        assert tr["iterations"][0]["label"] == "Nov 4 - 17, 2026" and any(s["iid"] == "101" for s in tr["iterations"][0]["stories"]), tr["iterations"][0]
        det = svc.story_detail("101")
        assert det["session"] and det["session"]["files"] and det["branches"], list(det)
        checks["control center"] = "iteration tree, story detail with plan / files / review"
        say(json.dumps(checks, indent=1))
        return checks
    finally:
        restore()
