"""Story Autopilot service: the watcher (polls the story board and the MRs), the queue and the single worker.

    svc = Autopilot(cfg)          # token / LLM from the vault, environment or the notebook prompt
    svc.start()                   # watcher + worker threads; svc.stop()

Everything the control center shows comes from here: status(), tree(), queue, story detail, live events."""
from __future__ import annotations

import json
import logging
import threading
import time
import traceback
from collections import deque
from pathlib import Path
from typing import Dict, List, Optional

from agiledev.config import get_secret

from .apps import AppRegistry
from .gitlab import GitLab, GitLabError, iteration_label
from .rules import decide
from .state import State
from .worker import Worker

log = logging.getLogger(__name__)


class Autopilot:
    def __init__(self, cfg, llm=None, token: str = "", gitlab_cls=GitLab):
        self.cfg = cfg
        self.a = cfg.get("autopilot") or {}
        st = self.a.get("storage") or {}
        self.state = State(cfg.path(st.get("state_db", "data/autopilot.db")))
        self.stories_root = cfg.path(st.get("stories_dir", "data/stories"))
        self.token = token or get_secret(cfg, "git_token", allow_prompt=False, required=False)
        self._gitlab_cls = gitlab_cls
        self._gl: Optional[GitLab] = None
        self.apps = AppRegistry(cfg, password_fn=lambda: get_secret(cfg, "greenplum_password", allow_prompt=False, required=False))
        if llm is None:
            from agiledev.llm import LLM
            llm = LLM(cfg, cfg.path(cfg.storage.get("llm_cache_dir", "data/cache/llm")))
        self.llm = llm
        self.worker = Worker(self)
        self.identity: dict = {}
        self.bot_user = "story-autopilot"
        self._threads: List[threading.Thread] = []
        self._stop = threading.Event()
        self._wake = threading.Event()
        self.current: Optional[dict] = None          # the job the worker is on
        self._live: Dict[str, deque] = {}
        self._sessions: Dict[str, object] = {}
        self.watch = {"last_poll": None, "next_poll": None, "last_error": "", "polls": 0, "seen": 0, "queued": 0, "labels_ready": False,
                      "mr_checked": 0}
        self.worker_status = "idle"
        self._iter_cache: Dict[str, tuple] = {}
        self.recovered = self.state.recover()

    # ------------------------------------------------------------------ switches (config + control-center overrides)
    @property
    def enabled(self) -> bool:
        return bool(self.state.setting("enabled", self.a.get("enabled", True)))

    def set_enabled(self, on: bool) -> None:
        self.state.set_setting("enabled", bool(on))

    @property
    def paused(self) -> bool:
        return bool(self.state.setting("paused", False))

    def set_paused(self, on: bool) -> None:
        self.state.set_setting("paused", bool(on))
        self._wake.set()

    @property
    def dry_run(self) -> bool:
        return bool(self.state.setting("dry_run", self.a.get("dry_run", False)))

    def board_url(self) -> str:
        return str(self.state.setting("board_url", "") or (self.a.get("story_board") or {}).get("project_url", ""))

    def set_board(self, url: str) -> None:
        self.state.set_setting("board_url", url.strip())
        self._gl = None
        self._iter_cache.clear()

    def iteration_setting(self) -> str:
        return str(self.state.setting("iteration", "") or (self.a.get("story_board") or {}).get("iteration", "current"))

    @property
    def gl(self) -> GitLab:
        if self._gl is None or self._gl.dry_run != self.dry_run:
            self._gl = self._gitlab_cls(self.board_url(), self.token, self.cfg.git.get("ssl_verify", True), dry_run=self.dry_run)
        return self._gl

    def story_dir(self, iid) -> Path:
        d = self.stories_root / str(iid)
        d.mkdir(parents=True, exist_ok=True)
        return d

    # ------------------------------------------------------------------ live feed of the current story
    def live(self, iid, msg: str) -> None:
        self._live.setdefault(str(iid), deque(maxlen=400)).append({"at": time.strftime("%H:%M:%S"), "msg": msg})

    def on_session_event(self, iid, e: dict) -> None:
        self.live(iid, f"[{e.get('type')}] {e.get('title')}" + (f" - {str(e.get('detail'))[:200]}" if e.get("detail") else ""))
        if self.current and str(self.current.get("iid")) == str(iid):
            if e.get("pct") is not None:
                self.current["pct"] = e["pct"]
            if e.get("type") in ("stage", "milestone", "agent"):
                self.current["stage"] = e.get("title")

    # ------------------------------------------------------------------ lifecycle
    def check(self) -> dict:
        """Connection test: token owner, story board, current iteration, apps source."""
        me = self.gl.whoami()
        self.identity = {"name": me.get("name") or me.get("username"), "email": me.get("email") or f"{me.get('username')}@users.noreply",
                         "username": me.get("username")}
        self.bot_user = me.get("username") or "story-autopilot"
        cur = self.gl.current_iteration()
        self.apps.all(refresh=True)
        return {"token_owner": me.get("username"), "board": self.gl.project, "current_iteration": cur.get("label") if cur else None,
                "apps": [a["app_id"] for a in self.apps.enabled()], "apps_source": self.apps.source}

    def start(self) -> dict:
        if self._threads:
            return {"running": True}
        info = self.check()
        self._stop.clear()
        for name, fn in (("autopilot-watcher", self._watch_loop), ("autopilot-worker", self._work_loop)):
            t = threading.Thread(target=fn, name=name, daemon=True)
            t.start()
            self._threads.append(t)
        self.state.event("service", "", "Story Autopilot started", json.dumps(info))
        return info

    def stop(self) -> None:
        self._stop.set()
        self._wake.set()
        for t in self._threads:
            t.join(timeout=5)
        self._threads = []
        self.state.event("service", "", "Story Autopilot stopped")

    @property
    def running(self) -> bool:
        return bool(self._threads) and not self._stop.is_set()

    def poll_now(self) -> None:
        self._wake.set()

    def _watch_loop(self) -> None:
        while not self._stop.is_set():
            try:
                self.poll_once()
            except Exception as e:  # noqa: BLE001
                self.watch["last_error"] = f"{type(e).__name__}: {str(e)[:300]}"
                log.error("watcher: %s\n%s", e, traceback.format_exc())
            wait = float(self.a.get("poll_minutes", 2)) * 60
            self.watch["next_poll"] = time.time() + wait
            self._wake.wait(wait)
            self._wake.clear()

    def _work_loop(self) -> None:
        while not self._stop.is_set():
            try:
                if not self.step():
                    self._stop.wait(3)
            except Exception as e:  # noqa: BLE001
                log.error("worker: %s\n%s", e, traceback.format_exc())
                self._stop.wait(10)

    # ------------------------------------------------------------------ watcher
    def ensure_labels(self) -> None:
        L = self.a.get("labels") or {}
        c = self.a.get("criteria") or {}
        names = [L.get(k) for k in ("rework", "code_done", "recode_done", "review_fix_done", "blocked", "failed", "working")] + [c.get("ready_label")]
        for n in names:
            if n:
                try:
                    self.gl.ensure_label(n, L.get("color", "#7c3aed"))
                except GitLabError as e:
                    log.warning("label %s: %s", n, e)
        self.watch["labels_ready"] = True

    def poll_once(self) -> dict:
        t0 = time.time()
        gl = self.gl
        if not self.identity:
            self.check()
        if not self.watch["labels_ready"] and self.enabled:
            self.ensure_labels()
        board = self.a.get("story_board") or {}
        it = self.iteration_setting()
        issues = gl.issues(it, board.get("states") or ["opened"])
        cur = gl.current_iteration() if str(it).lower() == "current" else None
        labmap = self.apps.label_map()
        c = self.a.get("criteria") or {}
        ip, ready = str(c.get("in_progress_label", "")).lower(), str(c.get("ready_label", "")).lower()
        active = {str(j["iid"]) for j in self.state.queue() if j["kind"] == "story"}
        queued = 0
        for i in issues:
            iid = str(i.get("iid"))
            low = {str(x).lower() for x in i.get("labels") or []}
            itn = i.get("iteration") or {}
            if (ip in low and ready in low) or (iid in active):
                le, se = gl.label_events(iid), gl.state_events(iid)
                d = decide(i, le, se, self.a, labmap)
            else:
                d = {"pick": False, "reason": ("latest status is not " + c.get("in_progress_label", "")) if ip not in low else f"no {c.get('ready_label')} label",
                     "apps": [labmap[str(x).lower()] for x in i.get("labels") or [] if str(x).lower() in labmap], "block": ""}
            asg = (i.get("assignees") or [{}])[0] if i.get("assignees") else {}
            self.state.upsert_story(iid, title=i.get("title", ""), iteration_id=str(itn.get("id") or ""), iteration=iteration_label(itn) if itn else "",
                                    labels=i.get("labels") or [], assignee=(asg or {}).get("name", ""), apps=d.get("apps") or [],
                                    status=next((x for x in i.get("labels") or [] if str(x).lower().startswith(str(c.get("status_label_prefix", "status::")).lower())), i.get("state")),
                                    decision={k: d.get(k) for k in ("pick", "kind", "reason", "block", "previous_status")},
                                    web_url=i.get("web_url", ""), updated_at=i.get("updated_at", ""), seen_at=time.time())
            if not self.enabled:
                continue
            if d.get("block"):
                self._block(iid, i, d)
            elif d.get("pick") and iid not in active:
                jid = self.state.enqueue("story", iid, i.get("title", ""), d["apps"], {"kind": d["kind"]})
                if jid:
                    queued += 1
                    self.state.event("queued", iid, f"#{iid} queued ({d['kind']})", d["reason"])
        if self.enabled and (self.a.get("mr_fix") or {}).get("enabled", True):
            self.scan_mr_comments()
        self.watch.update({"last_poll": time.time(), "polls": self.watch["polls"] + 1, "seen": len(issues), "queued": queued, "last_error": "",
                           "iteration": cur.get("label") if cur else it, "poll_seconds": round(time.time() - t0, 1)})
        return {"seen": len(issues), "queued": queued}

    def _block(self, iid, issue: dict, d: dict) -> None:
        """ai_blocked + ONE comment per distinct reason (no comment every poll)."""
        L = self.a.get("labels") or {}
        sig = d["block"]
        st = self.state.story(iid) or {}
        if st.get("block_sig") == sig:
            return
        self.state.upsert_story(iid, block_sig=sig)
        try:
            self.gl.ensure_label(L.get("blocked", "ai_blocked"))
            self.gl.set_labels(iid, [L.get("blocked", "ai_blocked")], [])
            self.gl.comment(iid, f"Story Autopilot: this story is ready for the agent but {d['block']}. It is picked up on the next poll once that is fixed.")
        except GitLabError as e:
            log.warning("block comment: %s", e)
        self.state.event("blocked", iid, f"#{iid} blocked", d["block"])

    def scan_mr_comments(self) -> int:
        """Every open MR the automation raised: new comments starting with /ai-fix -> one mr_fix job each."""
        cmd = (self.a.get("mr_fix") or {}).get("command", "/ai-fix").lower()
        n = 0
        for b in self.state.branches():
            if not b.get("mr_iid"):
                continue
            try:
                ds = self.gl.mr_discussions(b["project"], b["mr_iid"])
            except GitLabError as e:
                log.info("MR !%s discussions: %s", b["mr_iid"], e)
                continue
            for dsc in ds:
                for note in dsc.get("notes") or []:
                    body = str(note.get("body") or "").strip()
                    if note.get("system") or not body.lower().startswith(cmd) or self.state.note_seen(note["id"]):
                        continue
                    if (note.get("author") or {}).get("username") == self.identity.get("username") and "Story Autopilot" in body:
                        continue
                    pos = note.get("position") or {}
                    payload = {"app": b["app"], "mr_iid": b["mr_iid"], "project": b["project"], "discussion_id": dsc.get("id"), "note_id": note["id"],
                               "body": body, "author": (note.get("author") or {}).get("name", ""), "file": pos.get("new_path") or pos.get("old_path") or "",
                               "line": pos.get("new_line") or pos.get("old_line")}
                    st = self.state.story(b["iid"]) or {}
                    jid = self.state.enqueue("mr_fix", b["iid"], f"/ai-fix !{b['mr_iid']} {st.get('title', '')}", [b["app"]], payload)
                    if jid is None:                          # a fix for this story is already waiting: queue it after that one
                        jid = self._enqueue_extra_fix(b, st, payload)
                    self.state.mark_note(note["id"], b["iid"], b["app"], b["mr_iid"], jid)
                    self.state.event("queued", b["iid"], f"#{b['iid']} /ai-fix from {payload['author']} on !{b['mr_iid']}", body[:300])
                    n += 1
        self.watch["mr_checked"] = time.time()
        return n

    def _enqueue_extra_fix(self, b, st, payload) -> int:
        with self.state._lock:
            pos = (self.state._x("select max(position) m from queue where state='queued'")[0]["m"] or 0) + 1
            self.state._x("insert into queue(kind, iid, title, apps, position, state, payload, enqueued_at) values(?,?,?,?,?,?,?,?)",
                          ("mr_fix", str(b["iid"]), f"/ai-fix !{b['mr_iid']} {st.get('title', '')}", json.dumps([b["app"]]), pos, "queued",
                           json.dumps(payload), time.time()))
            return self.state._x("select max(id) i from queue")[0]["i"]

    # ------------------------------------------------------------------ worker
    def blocked_reason(self) -> str:
        if not self.enabled:
            return "switched off (global switch)"
        if self.paused:
            return "paused from the control center"
        lim = self.a.get("limits") or {}
        if self.state.cost_today() >= float(lim.get("usd_per_day", 1e9)):
            return f"daily model budget reached (${self.state.cost_today():.2f} of ${float(lim['usd_per_day']):.2f})"
        return ""

    def step(self) -> bool:
        """Takes and runs the next job. False = nothing to do (or not allowed now)."""
        why = self.blocked_reason()
        if why:
            self.worker_status = why
            return False
        job = self.state.next_job()
        if not job:
            self.worker_status = "idle"
            return False
        self.current = dict(job, pct=0, stage="starting", started=time.time())
        self.worker_status = f"working on #{job['iid']}"
        self._live[str(job["iid"])] = deque(maxlen=400)
        try:
            res = self.worker.run_fix(job) if job["kind"] == "mr_fix" else self.worker.run_story(job)
            state = {"done": "done", "blocked": "blocked", "skipped": "skipped"}.get(res.get("state"), "failed")
        except Exception as e:  # noqa: BLE001
            log.error("job %s failed: %s\n%s", job["id"], e, traceback.format_exc())
            res, state = {"state": "failed", "reason": f"{type(e).__name__}: {str(e)[:400]}"}, "failed"
        self.state.finish(job["id"], state, res)
        try:                                          # the story's labels changed: show them now, not at the next poll
            i = self.gl.issue(job["iid"])
            self.state.upsert_story(job["iid"], labels=i.get("labels") or [], updated_at=i.get("updated_at", ""),
                                    decision=dict((self.state.story(job["iid"]) or {}).get("decision") or {}, pick=False,
                                                  reason=f"{job['kind']} {state} - see Runs"))
        except Exception:  # noqa: BLE001
            pass
        self.state.event(state, job["iid"], f"#{job['iid']} {job['kind']} {state}", json.dumps(res, default=str)[:1500])
        self._sessions.pop(str(job["iid"]), None)
        self.current = None
        self.worker_status = "idle"
        return True

    # ------------------------------------------------------------------ control center data
    def status(self) -> dict:
        lim = self.a.get("limits") or {}
        cur = None
        if self.current:
            cur = {k: self.current.get(k) for k in ("id", "kind", "iid", "title", "apps", "pct", "stage", "started")}
            cur["log"] = list(self._live.get(str(self.current["iid"]), []))[-60:]
        return {"running": self.running, "enabled": self.enabled, "paused": self.paused, "dry_run": self.dry_run, "worker": self.worker_status,
                "blocked": self.blocked_reason(), "current": cur, "watch": self.watch, "board": self.board_url(), "iteration": self.iteration_setting(),
                "cost_today": round(self.state.cost_today(), 2), "usd_per_day": lim.get("usd_per_day"), "usd_per_story": lim.get("usd_per_story"),
                "apps": [{k: a[k] for k in ("app_id", "name", "label", "enabled")} for a in self.apps.all()], "apps_source": self.apps.source,
                "apps_error": self.apps.error, "identity": self.identity.get("username"), "poll_minutes": self.a.get("poll_minutes", 2),
                "switches": {"push": (self.a.get("git") or {}).get("push", True), "merge_request": (self.a.get("git") or {}).get("merge_request", True),
                             "mr_fix": (self.a.get("mr_fix") or {}).get("enabled", True)}}

    def tree(self, refresh: bool = False) -> dict:
        """Iteration folders (newest first) with their stories. The current iteration's stories come from the watcher; other
        iterations are read when expanded (stories_of)."""
        key = "tree"
        if not refresh and key in self._iter_cache and time.time() - self._iter_cache[key][0] < 120:
            its = self._iter_cache[key][1]
        else:
            its = self.gl.iterations("all", int((self.a.get("story_board") or {}).get("iterations_in_tree", 6)))
            self._iter_cache[key] = (time.time(), its)
        known = self.state.stories()
        by_it: Dict[str, list] = {}
        for s in known:
            by_it.setdefault(str(s.get("iteration_id") or ""), []).append(self._story_row(s))
        return {"board": self.board_url(), "iterations": [dict(i, stories=by_it.get(str(i["id"]), []), loaded=str(i["id"]) in by_it) for i in its]}

    def stories_of(self, iteration_id) -> List[dict]:
        rows = self.gl.issues(str(iteration_id), ["opened", "closed"])
        labmap = self.apps.label_map()
        out = []
        for i in rows:
            st = self.state.story(i["iid"]) or {}
            out.append(self._story_row(dict(st, iid=str(i["iid"]), title=i.get("title"), labels=i.get("labels") or [], web_url=i.get("web_url"),
                                            apps=[labmap[x.lower()] for x in i.get("labels") or [] if x.lower() in labmap],
                                            assignee=((i.get("assignees") or [{}])[0] or {}).get("name", ""))))
        return out

    def _story_row(self, s: dict) -> dict:
        q = {j["iid"]: j for j in self.state.queue()}
        j = q.get(str(s["iid"]))
        return {"iid": str(s["iid"]), "title": s.get("title") or "", "labels": s.get("labels") or [], "apps": s.get("apps") or [],
                "status": s.get("status"), "assignee": s.get("assignee"), "web_url": s.get("web_url"), "decision": s.get("decision") or {},
                "queue": j["state"] if j else "", "current": bool(self.current and str(self.current["iid"]) == str(s["iid"]))}

    def story_detail(self, iid) -> dict:
        iid = str(iid)
        st = self.state.story(iid) or {"iid": iid}
        sess = self._sessions.get(iid)
        if sess is None and (self.stories_root / iid / "chat").exists():
            sess = self.worker.session(iid, live=False)
            self._sessions[iid] = sess
        return {"story": st, "branches": self.state.branches(iid), "jobs": self.state.jobs_of(iid), "events": self.state.events(iid, 100),
                "cost_usd": round(self.state.cost_story(iid), 2), "live": list(self._live.get(iid, [])),
                "session": sess.state() if sess is not None else None}

    def story_file(self, iid, path: str) -> str:
        sess = self._sessions.get(str(iid)) or self.worker.session(iid, live=False)
        f = sess.files.get(path)
        return f["content"] if f else ""

    def enqueue_manual(self, iid, kind: str = "story") -> Optional[int]:
        """Control center 'run now': re-checks the rules first (a manual run never bypasses them)."""
        i = self.gl.issue(iid)
        d = decide(i, self.gl.label_events(iid), self.gl.state_events(iid), self.a, self.apps.label_map())
        if not d.get("pick"):
            raise ValueError(f"#{iid} cannot be queued: {d.get('reason')}")
        return self.state.enqueue("story", iid, i.get("title", ""), d["apps"], {"kind": d["kind"], "manual": True})
