"""Story Autopilot web app: the control center (/) and the onboarding page (/onboarding).

Standard-library HTTP server (same core as Agile Dev Assist), SSO via auth.mode header | oidc | dev, the signed session
cookie. Changing switches, the queue order or the onboarding table needs an admin (auth.admins) when that list is set."""
from __future__ import annotations

import logging
import mimetypes
import re
import secrets as pysecrets
import threading
import time
from pathlib import Path
from typing import Optional

from agiledev.auth import COOKIE, Auth
from agiledev.config import Config, get_secret, load_config
from agiledev.webcore import HTTPError, Request, Response, Router, Server, _page, parse_multipart  # noqa: F401

from .service import Autopilot

log = logging.getLogger(__name__)
WEB = Path(__file__).resolve().parent.parent / "web"
router = Router()
route = router.route


class Core:
    def __init__(self, cfg: Config, svc: Autopilot):
        self.cfg, self.svc = cfg, svc
        self.auth = Auth(cfg, get_secret(cfg, "server_secret", allow_prompt=False, required=False))


def user(core: Core, r: Request) -> dict:
    try:
        u = core.auth.user_from_request(r.headers, r.cookies, r.client)
    except PermissionError as e:
        raise HTTPError(403, str(e))
    if not u:
        raise HTTPError(401, "not signed in")
    if not core.auth.allowed(u["user_id"]):
        raise HTTPError(403, "user not allowed")
    return u


def admin(core: Core, r: Request) -> dict:
    u = user(core, r)
    if (core.cfg.get("auth") or {}).get("admins") and not core.auth.is_admin(u["user_id"]):
        raise HTTPError(403, "only an administrator (auth.admins) can change this")
    return u


def _cookie(core: Core, resp: Response, u: dict, r: Request) -> None:
    secure = bool(core.cfg.auth.get("secure_cookies", False)) or r.header("x-forwarded-proto") == "https"
    resp.headers.append(("Set-Cookie", f"{COOKIE}={core.auth.sign(u)}; Max-Age={int(core.auth.ttl)}; Path=/; HttpOnly; SameSite=Lax" + ("; Secure" if secure else "")))


def _page_or_login(core: Core, r: Request, name: str) -> Response:
    try:
        u = core.auth.user_from_request(r.headers, r.cookies, r.client)
    except PermissionError as e:
        return Response.html(_page("Access refused", str(e)), 403)
    if not u:
        if core.auth.mode == "oidc":
            return Response.redirect("auth/login", 302)
        if core.auth.mode == "header":
            return Response.html(_page("Not signed in", "Open Story Autopilot through the corporate single sign-on URL."), 401)
        return Response.html((WEB / "login.html").read_text(encoding="utf-8"))
    return Response.html((WEB / name).read_text(encoding="utf-8"))


# ----------------------------------------------------------------------------- pages
@route("GET", "/")
def index(core: Core, r: Request):
    return _page_or_login(core, r, "index.html")


@route("GET", "/onboarding/?")
def onboarding(core: Core, r: Request):
    return _page_or_login(core, r, "onboarding.html")


@route("GET", "/(?:onboarding/)?static/(?P<name>[A-Za-z0-9_.-]+)")
def static(core: Core, r: Request, name: str):
    p = WEB / name
    if not p.is_file():
        raise HTTPError(404, "not found")
    return Response(200, p.read_bytes(), mimetypes.guess_type(name)[0] or "application/octet-stream", [("Cache-Control", "no-cache")])


@route("POST", "/(?:onboarding/)?auth/dev-login")
def dev_login(core: Core, r: Request):
    if core.auth.mode != "dev":
        raise HTTPError(404, "not found")
    uid = r.fields.get("user", "").strip()
    if not uid:
        raise HTTPError(400, "user id required")
    try:
        u = core.auth.normalize({"user_id": uid, "display_name": r.fields.get("name", "").strip() or uid, "email": uid if "@" in uid else ""})
    except PermissionError as e:
        raise HTTPError(400, str(e))
    resp = Response.redirect("../", 303)
    _cookie(core, resp, u, r)
    return resp


@route("GET", "/auth/login")
def login(core: Core, r: Request):
    if core.auth.mode != "oidc":
        return Response.redirect("../", 302)
    state = pysecrets.token_urlsafe(16)
    cb = f"{'https' if r.header('x-forwarded-proto') == 'https' else 'http'}://{r.header('host')}/auth/callback"
    resp = Response.redirect(core.auth.oidc_login_url(cb, state), 302)
    resp.headers.append(("Set-Cookie", f"autopilot_oidc_state={state}; Max-Age=600; Path=/; HttpOnly"))
    return resp


@route("GET", "/auth/callback")
def callback(core: Core, r: Request):
    if r.cookies.get("autopilot_oidc_state") != r.query.get("state", ""):
        raise HTTPError(400, "state mismatch")
    cb = f"{'https' if r.header('x-forwarded-proto') == 'https' else 'http'}://{r.header('host')}/auth/callback"
    try:
        u = core.auth.oidc_exchange(r.query.get("code", ""), cb, get_secret(core.cfg, "oidc_client_secret", allow_prompt=False, required=False))
    except PermissionError as e:
        raise HTTPError(403, str(e))
    resp = Response.redirect("../", 303)
    _cookie(core, resp, u, r)
    return resp


@route("POST", "/auth/logout")
def logout(core: Core, r: Request):
    resp = Response.json({"ok": True, "logout_url": core.auth.logout_url()})
    resp.headers.append(("Set-Cookie", f"{COOKIE}=; Max-Age=0; Path=/"))
    return resp


@route("GET", "/api/health")
def health(core: Core, r: Request):
    return Response.json({"ok": True, "product": "Story Autopilot", "running": core.svc.running})


# ----------------------------------------------------------------------------- control center
@route("GET", "/api/me")
def me(core: Core, r: Request):
    u = user(core, r)
    adm = not (core.cfg.get("auth") or {}).get("admins") or core.auth.is_admin(u["user_id"])
    return Response.json(dict(u, admin=adm))


@route("GET", "/api/status")
def status(core: Core, r: Request):
    user(core, r)
    return Response.json(core.svc.status())


@route("GET", "/api/tree")
def tree(core: Core, r: Request):
    user(core, r)
    try:
        return Response.json(core.svc.tree(refresh=r.query.get("refresh") == "1"))
    except Exception as e:  # noqa: BLE001
        return Response.json({"board": core.svc.board_url(), "iterations": [], "error": f"{type(e).__name__}: {str(e)[:300]}"})


@route("GET", "/api/iterations/(?P<iid>[^/]+)/stories")
def iteration_stories(core: Core, r: Request, iid: str):
    user(core, r)
    return Response.json({"stories": core.svc.stories_of(iid)})


@route("GET", "/api/stories/(?P<iid>\\d+)")
def story(core: Core, r: Request, iid: str):
    user(core, r)
    return Response.json(core.svc.story_detail(iid))


@route("GET", "/api/stories/(?P<iid>\\d+)/file")
def story_file(core: Core, r: Request, iid: str):
    user(core, r)
    return Response.json({"path": r.query.get("path", ""), "content": core.svc.story_file(iid, r.query.get("path", ""))})


@route("GET", "/api/stories/(?P<iid>\\d+)/log")
def story_log(core: Core, r: Request, iid: str):
    user(core, r)
    p = core.svc.story_dir(iid) / "chat" / "log.txt"
    txt = p.read_text(encoding="utf-8", errors="replace")[-200000:] if p.exists() else ""
    return Response.text(txt)


@route("POST", "/api/stories/(?P<iid>\\d+)/enqueue")
def story_enqueue(core: Core, r: Request, iid: str):
    admin(core, r)
    try:
        jid = core.svc.enqueue_manual(iid)
    except ValueError as e:
        raise HTTPError(400, str(e))
    return Response.json({"queued": jid is not None, "id": jid})


@route("GET", "/api/queue")
def queue(core: Core, r: Request):
    user(core, r)
    return Response.json({"queue": core.svc.state.queue(), "history": core.svc.state.history(40)})


@route("POST", "/api/queue/reorder")
def queue_reorder(core: Core, r: Request):
    admin(core, r)
    core.svc.state.reorder([int(x) for x in (r.json().get("ids") or [])])
    return Response.json({"queue": core.svc.state.queue()})


@route("POST", "/api/queue/(?P<jid>\\d+)/(?P<what>top|up|down|bottom|cancel)")
def queue_move(core: Core, r: Request, jid: str, what: str):
    admin(core, r)
    if what == "cancel":
        core.svc.state.cancel(int(jid))
    else:
        core.svc.state.move(int(jid), what)
    return Response.json({"queue": core.svc.state.queue()})


@route("GET", "/api/events")
def events(core: Core, r: Request):
    user(core, r)
    return Response.json({"events": core.svc.state.events(None, 150)})


@route("POST", "/api/control")
def control(core: Core, r: Request):
    u = admin(core, r)
    b = r.json()
    s = core.svc
    if "enabled" in b:
        s.set_enabled(bool(b["enabled"]))
    if "paused" in b:
        s.set_paused(bool(b["paused"]))
    if "dry_run" in b:
        s.state.set_setting("dry_run", bool(b["dry_run"]))
    if b.get("board_url"):
        s.set_board(str(b["board_url"]))
    if "iteration" in b:
        s.state.set_setting("iteration", str(b["iteration"] or ""))
    msg = ""
    if b.get("start") and not s.running:
        try:
            s.start()
        except Exception as e:  # noqa: BLE001
            raise HTTPError(400, f"cannot start: {type(e).__name__}: {e}")
    if b.get("stop") and s.running:
        s.stop()
    if b.get("poll_now"):
        if s.running:
            s.poll_now()
        else:
            threading.Thread(target=s.poll_once, daemon=True).start()
        msg = "poll started"
    s.state.event("control", "", f"control by {u['user_id']}", str({k: v for k, v in b.items()}))
    return Response.json(dict(s.status(), message=msg))


# ----------------------------------------------------------------------------- onboarding
@route("GET", "/api/apps")
def apps(core: Core, r: Request):
    user(core, r)
    reg = core.svc.apps
    rows = reg.all(refresh=r.query.get("refresh") == "1")
    return Response.json({"apps": rows, "source": reg.source, "error": reg.error, "table": reg._table() if reg.source != "config" else reg.fq,
                          "defaults": {k: (core.cfg.autopilot.get("git") or {}).get(k) for k in ("branch_template", "commit_template")}})


@route("POST", "/api/apps")
def apps_save(core: Core, r: Request):
    u = admin(core, r)
    try:
        a = core.svc.apps.save(r.json(), u["user_id"])
    except ValueError as e:
        raise HTTPError(400, str(e))
    except Exception as e:  # noqa: BLE001
        raise HTTPError(500, f"onboarding table not written: {type(e).__name__}: {str(e)[:300]}")
    core.svc.state.event("onboarding", "", f"app {a['app_id']} saved by {u['user_id']}")
    return Response.json({"app": a})


@route("DELETE", "/api/apps/(?P<app_id>[a-z0-9_]+)")
def apps_delete(core: Core, r: Request, app_id: str):
    u = admin(core, r)
    core.svc.apps.delete(app_id)
    core.svc.state.event("onboarding", "", f"app {app_id} removed by {u['user_id']}")
    return Response.json({"deleted": app_id})


@route("POST", "/api/apps/test")
def apps_test(core: Core, r: Request):
    """Test connection for one app row (not yet saved is fine): pack, repository + branches, story label, Greenplum."""
    user(core, r)
    from .apps import clean_app
    try:
        a = clean_app(r.json())
    except ValueError as e:
        raise HTTPError(400, str(e))
    s = core.svc
    out = []
    pdir = core.cfg.path((core.cfg.get("knowledge_packs") or {}).get("dir", "packs"))
    z = pdir / a["pack"]
    out.append({"check": "knowledge pack", "ok": z.exists(), "detail": f"{z} ({z.stat().st_size // 1048576} MB)" if z.exists() else f"{z.name} not in {pdir} - upload it below"})
    from agiledev.gitworkspace import GitWorkspace
    ws = GitWorkspace(core.cfg, core.cfg.path(core.cfg.storage.get("git_mirrors_dir", "data/cache/git")))
    for br in (a["base_branch"], a["target_branch"]):
        if not br:
            continue
        try:
            ok = ws.remote_branch_exists(a["repo_url"], s.token, br)
            out.append({"check": f"branch {br}", "ok": ok, "detail": "found" if ok else "not found in the repository"})
        except Exception as e:  # noqa: BLE001
            out.append({"check": f"branch {br}", "ok": False, "detail": str(e)[:200]})
    try:
        labs = s.gl.labels(refresh=True)
        miss = [x.strip() for x in a["label"].split(",") if x.strip() and x.strip().lower() not in labs]
        out.append({"check": "story label", "ok": not miss, "detail": "exists on the story board" if not miss else f"{', '.join(miss)} not on the story board yet (created on first use)"})
    except Exception as e:  # noqa: BLE001
        out.append({"check": "story label", "ok": False, "detail": str(e)[:200]})
    try:
        s.apps.ensure_table()
        out.append({"check": "onboarding table", "ok": True, "detail": s.apps._table()})
    except Exception as e:  # noqa: BLE001
        out.append({"check": "onboarding table", "ok": False, "detail": f"{type(e).__name__}: {str(e)[:200]}"})
    return Response.json({"checks": out})


@route("GET", "/api/packs")
def packs(core: Core, r: Request):
    user(core, r)
    pdir = core.cfg.path((core.cfg.get("knowledge_packs") or {}).get("dir", "packs"))
    pdir.mkdir(parents=True, exist_ok=True)
    return Response.json({"dir": str(pdir), "packs": [{"name": p.name, "mb": round(p.stat().st_size / 1048576, 1),
                                                       "modified": time.strftime("%Y-%m-%d %H:%M", time.localtime(p.stat().st_mtime))}
                                                      for p in sorted(pdir.glob("*.zip"))]})


@route("POST", "/api/packs/upload")
def packs_upload(core: Core, r: Request):
    u = admin(core, r)
    up = (r.files.get("file") or [None])[0]
    if not up:
        raise HTTPError(400, "no file")
    name, data = up
    if not re.fullmatch(r"[A-Za-z0-9_.-]+\.zip", Path(name).name):
        raise HTTPError(400, "a pack is a .zip file named like ikg_pack.zip")
    lim = float((core.cfg.get("knowledge_packs") or {}).get("max_zip_mb", 1024))
    if len(data) > lim * 1048576:
        raise HTTPError(400, f"larger than {lim:.0f} MB")
    import zipfile
    import io
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            if not any(n.endswith("manifest.json") for n in zf.namelist()):
                raise HTTPError(400, "not a knowledge pack (no manifest.json inside)")
    except zipfile.BadZipFile:
        raise HTTPError(400, "not a zip file")
    pdir = core.cfg.path((core.cfg.get("knowledge_packs") or {}).get("dir", "packs"))
    pdir.mkdir(parents=True, exist_ok=True)
    part = pdir / (Path(name).name + ".part")
    part.write_bytes(data)
    part.replace(pdir / Path(name).name)                   # atomic: a running story never sees half a pack
    core.svc.state.event("onboarding", "", f"pack {Path(name).name} uploaded by {u['user_id']}", f"{len(data) // 1048576} MB")
    return Response.json({"saved": Path(name).name, "mb": round(len(data) / 1048576, 1)})


# ----------------------------------------------------------------------------- entry
def serve(cfg: Optional[Config] = None, svc: Optional[Autopilot] = None, host: Optional[str] = None, port: Optional[int] = None,
          background: bool = False) -> Server:
    cfg = cfg or load_config()
    svc = svc or Autopilot(cfg)
    core = Core(cfg, svc)
    host = host or cfg.server.get("host", "0.0.0.0")
    port = int(port or cfg.server.get("port", 8790))
    srv = Server(core, host, port, router, name="autopilot-web")
    srv.svc = svc
    log.info("Story Autopilot listening on http://%s:%d/ (auth %s)", host, port, core.auth.mode)
    if background:
        return srv.start_background()
    srv.run()
    return srv
