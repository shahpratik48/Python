"""
The time series behind the dashboard.

Four metrics per pod per month, computed exactly as in the monthly report
project -- the same collectors, so the dashboard and the reports can never
disagree:

    Issue Throughput          closed issues
    Issue Cycle Time (Days)   avg elapsed business days, in progress -> closed
    Merged MRs per Author     merged MRs / distinct authors
    Lead Time (Hrs.)          avg elapsed hours, first file touched -> merged

On top of that, three things the dashboard needs:

* **Two views of every metric.** The monthly view plots each month as it
  landed. The windowed view plots consecutive 3-month averages -- Nov 24 to
  Jan 25, Dec 24 to Feb 25, Jan 25 to Mar 25, and so on -- for both actual
  and aspiration. Monthly figures for one pod swing hard on a single late
  ticket, so the windowed view is where the trend is readable; the monthly
  view is where the detail is.

* **Actual split at the baseline.** There is ONE actual series, drawn in two
  segments: everything BEFORE the baseline month is "Actual (Previous)" and
  everything FROM the baseline onward is "Actual (Current)". The baseline
  month itself belongs to both so the two segments join up rather than
  showing a visual break. This is why history starts in Nov 2024 -- it is
  the "previous" run-up to the Nov 2025 baseline.

* **Productivity gain.** One number combining all four metrics against the
  baseline month. Throughput and MRs-per-author are higher-is-better; Cycle
  Time and Lead Time are lower-is-better, so their sign is flipped before
  averaging. Without that inversion a slowdown would read as an improvement.

Fetching is deliberately separated from filtering: `collect_pod_series`
hits GitLab once per pod and everything after that is arithmetic on cached
numbers, so moving the dropdowns re-renders instantly instead of re-querying.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Sequence, Tuple

from gl_metrics import collect_issue_metrics, collect_mr_metrics, month_key
from gl_settings import GitLabSettings, PODS_BY_KEY, get_logger

log = get_logger("prod.metrics")

# (attribute, label, lower_is_better)
METRIC_DEFS = [
    ("throughput", "GitLab Issue Throughput", False),
    ("cycle_time", "GitLab Issue Cycle Time", True),
    ("merged_per_author", "Merge requests", False),
    ("lead_time", "Merge request Lead Time", True),
]
METRIC_KEYS = [m[0] for m in METRIC_DEFS]
LOWER_IS_BETTER = {a: low for a, _l, low in METRIC_DEFS}


# ------------------------------------------------------------------ months
def month_range(start: str, end: str) -> List[str]:
    """Inclusive list of YYYY-MM from `start` to `end`."""
    y, m = (int(x) for x in start.split("-"))
    ey, em = (int(x) for x in end.split("-"))
    out = []
    while (y, m) <= (ey, em):
        out.append("%04d-%02d" % (y, m))
        m += 1
        if m > 12:
            y, m = y + 1, 1
    return out


def month_start(mkey: str) -> datetime:
    return datetime.strptime(mkey + "-01", "%Y-%m-%d").replace(tzinfo=timezone.utc)


def shift_months(mkey: str, delta: int) -> str:
    y, m = (int(x) for x in mkey.split("-"))
    total = y * 12 + (m - 1) + delta
    return "%04d-%02d" % (total // 12, total % 12 + 1)


# ------------------------------------------------------------------ models
@dataclass
class PodSeries:
    """Raw monthly values for one pod, before any aggregation."""
    pod_key: str
    pod_name: str
    months: List[str]
    throughput: Dict[str, float] = field(default_factory=dict)
    cycle_time: Dict[str, Optional[float]] = field(default_factory=dict)
    merged_per_author: Dict[str, Optional[float]] = field(default_factory=dict)
    lead_time: Dict[str, Optional[float]] = field(default_factory=dict)
    # kept so aggregation across pods can weight correctly
    merged_count: Dict[str, float] = field(default_factory=dict)
    author_count: Dict[str, float] = field(default_factory=dict)
    measured_issues: Dict[str, float] = field(default_factory=dict)
    measured_mrs: Dict[str, float] = field(default_factory=dict)

    def get(self, metric: str) -> Dict[str, Optional[float]]:
        return getattr(self, metric)


@dataclass
class DashboardSeries:
    """Everything the charts draw, for one pod (or one filter selection).

    Held in two parallel views -- `months` for the month-by-month figure and
    `window_labels` for the 3-month-average figure -- so each chart reads its
    own arrays rather than re-deriving them at draw time.
    """
    months: List[str]
    window_labels: List[str] = field(default_factory=list)

    # month-by-month
    actual: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    actual_prev: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    actual_curr: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    aspiration: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    gain_actual: List[Optional[float]] = field(default_factory=list)
    gain_actual_prev: List[Optional[float]] = field(default_factory=list)
    gain_actual_curr: List[Optional[float]] = field(default_factory=list)
    gain_aspiration: List[Optional[float]] = field(default_factory=list)

    # 3-month windows
    w_actual: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    w_actual_prev: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    w_actual_curr: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    w_aspiration: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    w_gain_actual: List[Optional[float]] = field(default_factory=list)
    w_gain_actual_prev: List[Optional[float]] = field(default_factory=list)
    w_gain_actual_curr: List[Optional[float]] = field(default_factory=list)
    w_gain_aspiration: List[Optional[float]] = field(default_factory=list)

    baseline: Dict[str, Optional[float]] = field(default_factory=dict)
    # headline % for each view, computed from the numbers that view actually
    # plots -- monthly endpoints for the monthly figure, window averages for
    # the windowed one. Reusing one figure across both made the title
    # disagree with the line beneath it.
    progress_pct: Dict[str, Optional[float]] = field(default_factory=dict)
    w_progress_pct: Dict[str, Optional[float]] = field(default_factory=dict)
    baseline_window: Dict[str, Optional[float]] = field(default_factory=dict)
    latest_gain: Optional[float] = None
    w_latest_gain: Optional[float] = None
    baseline_month: str = ""
    baseline_index: Optional[int] = None
    baseline_window_index: Optional[int] = None
    pods: List[str] = field(default_factory=list)


# ------------------------------------------------------------------ fetch
def collect_pod_series(settings_template, pod_key: str, months: List[str], client=None) -> PodSeries:
    """One GitLab pass for one pod over the whole history window."""
    pod = PODS_BY_KEY[pod_key]
    s = GitLabSettings(pod=pod)
    s.gitlab_token = settings_template.gitlab_token
    s.gitlab_url = settings_template.gitlab_url
    s.in_progress_labels = settings_template.in_progress_labels

    if client is None:
        from gl_client import GitLabClient
        client = GitLabClient(s)

    earliest = month_start(months[0])
    log.info("Collecting %s: %d month(s) from %s", pod.name, len(months), months[0])
    _im, isum = collect_issue_metrics(client, s, months, earliest)
    _mm, msum = collect_mr_metrics(client, s, months, earliest)

    ps = PodSeries(pod_key=pod_key, pod_name=pod.name, months=list(months))
    for m in months:
        i = isum.get(m)
        r = msum.get(m)
        merged = float(r.merged_count) if r else 0.0
        authors = float(len(r.per_author)) if r else 0.0
        ps.throughput[m] = float(i.closed_count) if i else 0.0
        ps.cycle_time[m] = i.avg_business_days if i else None
        ps.lead_time[m] = r.avg_hours if r else None
        ps.merged_per_author[m] = (round(merged / authors, 2) if authors else None)
        ps.merged_count[m] = merged
        ps.author_count[m] = authors
        ps.measured_issues[m] = float(i.measured_count) if i else 0.0
        ps.measured_mrs[m] = float(r.measured_count) if r else 0.0
    return ps


# ------------------------------------------------------------------ maths
def month_label(mkey: str) -> str:
    y, mm = mkey.split("-")
    return "%s %s" % (["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul",
                       "Aug", "Sep", "Oct", "Nov", "Dec"][int(mm) - 1], y[2:])


def window_slices(months: Sequence[str], window: int = 3):
    """Consecutive `window`-month spans stepping one month at a time:
    Nov 24-Jan 25, Dec 24-Feb 25, Jan 25-Mar 25, ... Returns
    (labels, [(start_index, end_index_exclusive), ...])."""
    labels, spans = [], []
    for i in range(len(months) - window + 1):
        labels.append("%s-%s" % (month_label(months[i]), month_label(months[i + window - 1])))
        spans.append((i, i + window))
    return labels, spans


def window_average(values: Sequence[Optional[float]], spans) -> List[Optional[float]]:
    """Mean of each window, ignoring gaps.

    A month with no data contributes nothing rather than counting as zero --
    treating an unreported month as a zero would drag the average down and
    invent a decline that never happened.
    """
    out: List[Optional[float]] = []
    for a, b in spans:
        vals = [v for v in values[a:b] if v is not None]
        out.append(round(sum(vals) / len(vals), 2) if vals else None)
    return out


def split_at_baseline(values: Sequence[Optional[float]], baseline_index: Optional[int]):
    """Splits one series into (previous, current) around the baseline.

    The baseline point itself is present in BOTH halves so the two line
    segments meet rather than leaving a gap at the join.
    """
    if baseline_index is None:
        return list(values), [None] * len(values)
    prev = [v if i <= baseline_index else None for i, v in enumerate(values)]
    curr = [v if i >= baseline_index else None for i, v in enumerate(values)]
    return prev, curr


def _aggregate(pod_series: List[PodSeries], months: List[str]) -> Dict[str, List[Optional[float]]]:
    """Combines pods into one series per metric.

    Counts add up. Averages must NOT be averaged again -- a pod that closed
    two issues would otherwise pull the mean as hard as one that closed
    fifty. Cycle time and lead time are therefore weighted by how many items
    each pod actually measured, and merged-MRs-per-author is recomputed from
    total merges over total authors.
    """
    agg: Dict[str, List[Optional[float]]] = {k: [] for k in METRIC_KEYS}
    for m in months:
        agg["throughput"].append(sum(p.throughput.get(m, 0.0) for p in pod_series))

        num = sum((p.cycle_time.get(m) or 0.0) * p.measured_issues.get(m, 0.0)
                  for p in pod_series if p.cycle_time.get(m) is not None)
        den = sum(p.measured_issues.get(m, 0.0) for p in pod_series if p.cycle_time.get(m) is not None)
        agg["cycle_time"].append(round(num / den, 2) if den else None)

        num = sum((p.lead_time.get(m) or 0.0) * p.measured_mrs.get(m, 0.0)
                  for p in pod_series if p.lead_time.get(m) is not None)
        den = sum(p.measured_mrs.get(m, 0.0) for p in pod_series if p.lead_time.get(m) is not None)
        agg["lead_time"].append(round(num / den, 2) if den else None)

        merged = sum(p.merged_count.get(m, 0.0) for p in pod_series)
        authors = sum(p.author_count.get(m, 0.0) for p in pod_series)
        agg["merged_per_author"].append(round(merged / authors, 2) if authors else None)
    return agg


def _mean(values) -> Optional[float]:
    vals = [v for v in values if v is not None]
    return round(sum(vals) / len(vals), 2) if vals else None


def _gain(metric: str, value: Optional[float], baseline: Optional[float]) -> Optional[float]:
    """Percentage improvement against baseline, sign-corrected per metric."""
    if value is None or baseline in (None, 0):
        return None
    raw = (value - baseline) / abs(baseline) * 100.0
    return round(-raw if LOWER_IS_BETTER[metric] else raw, 2)


def build_dashboard_series(pod_series: List[PodSeries], months: List[str],
                           baseline_month: str, target_gain_pct: float = 20.0,
                           target_months: int = 14, window: int = 3) -> DashboardSeries:
    """Builds both views -- month-by-month and 3-month windows -- for the
    given pods, with the actual line split at the baseline month."""
    ds = DashboardSeries(months=list(months), pods=[p.pod_name for p in pod_series],
                         baseline_month=baseline_month)
    if not pod_series:
        log.warning("No pods selected -- nothing to plot.")
        return ds

    agg = _aggregate(pod_series, months)
    idx = {mm: i for i, mm in enumerate(months)}
    bi = idx.get(baseline_month)
    ds.baseline_index = bi

    labels, spans = window_slices(months, window)
    ds.window_labels = labels
    # a window counts as "current" once it starts at or after the baseline
    ds.baseline_window_index = next((k for k, (a, _b) in enumerate(spans) if bi is not None
                                     and a >= bi), None)
    bwi = ds.baseline_window_index

    for metric in METRIC_KEYS:
        vals = agg[metric]
        ds.actual[metric] = vals
        prev, curr = split_at_baseline(vals, bi)
        ds.actual_prev[metric] = prev
        ds.actual_curr[metric] = curr

        base = vals[bi] if bi is not None else None
        ds.baseline[metric] = base

        # aspiration in the metric's own units, so it shares the axis
        asp = []
        for mm in months:
            step = _ramp_pct(mm, baseline_month, target_gain_pct, target_months)
            if base is None or step is None:
                asp.append(None)
                continue
            factor = (1 - step / 100.0) if LOWER_IS_BETTER[metric] else (1 + step / 100.0)
            asp.append(round(base * factor, 2))
        ds.aspiration[metric] = asp

        # 3-month window view
        w_vals = window_average(vals, spans)
        ds.w_actual[metric] = w_vals
        wp, wc = split_at_baseline(w_vals, bwi)
        ds.w_actual_prev[metric] = wp
        ds.w_actual_curr[metric] = wc
        ds.w_aspiration[metric] = window_average(asp, spans)

        latest = next((v for v in reversed(vals) if v is not None), None)
        ds.progress_pct[metric] = _gain(metric, latest, base)

        # same comparison, but between window averages, for the windowed figure
        w_base = w_vals[bwi] if bwi is not None and bwi < len(w_vals) else None
        w_latest = next((v for v in reversed(w_vals) if v is not None), None)
        ds.baseline_window[metric] = w_base
        ds.w_progress_pct[metric] = _gain(metric, w_latest, w_base)

    # overall gain: mean of the four metric gains, month by month
    for i, mm in enumerate(months):
        gains = [_gain(k, ds.actual[k][i], ds.baseline[k]) for k in METRIC_KEYS]
        gains = [g for g in gains if g is not None]
        ds.gain_actual.append(round(sum(gains) / len(gains), 2) if gains else None)
        ds.gain_aspiration.append(_ramp_pct(mm, baseline_month, target_gain_pct, target_months))
    ds.gain_actual_prev, ds.gain_actual_curr = split_at_baseline(ds.gain_actual, bi)

    ds.w_gain_actual = window_average(ds.gain_actual, spans)
    ds.w_gain_aspiration = window_average(ds.gain_aspiration, spans)
    ds.w_gain_actual_prev, ds.w_gain_actual_curr = split_at_baseline(ds.w_gain_actual, bwi)

    # Headline = the mean of the four figures shown in that view's panels, so
    # the arithmetic a reader can do by eye always holds. (The plotted overall
    # LINE on the windowed figure is the window-average of the monthly gain
    # series, which is the right thing for a trend line but would not equal
    # the mean of the four window endpoints -- hence computing the headline
    # explicitly rather than taking the last point of the line.)
    ds.latest_gain = _mean([ds.progress_pct.get(k) for k in METRIC_KEYS])
    ds.w_latest_gain = _mean([ds.w_progress_pct.get(k) for k in METRIC_KEYS])

    log.info("Series built for %d pod(s): %d month(s), %d window(s), latest gain %s%%.",
             len(pod_series), len(months), len(labels), ds.latest_gain)
    return ds


def _ramp_pct(mkey: str, baseline_month: str, target_gain_pct: float,
              target_months: int) -> Optional[float]:
    """The aspiration curve: 0% at the baseline, rising linearly to the
    target. Months before the baseline have no aspiration -- the ambition
    only starts once the reference point exists."""
    if target_months <= 0:
        return None
    y, m = (int(x) for x in mkey.split("-"))
    by, bm = (int(x) for x in baseline_month.split("-"))
    delta = (y * 12 + m) - (by * 12 + bm)
    if delta < 0:
        return None
    return round(min(delta / float(target_months), 1.0) * target_gain_pct, 2)
