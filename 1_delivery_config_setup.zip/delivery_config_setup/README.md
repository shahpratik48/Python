# One-time configuration setup

Run this **once**, before the reporting job. It creates the two configuration tables and seeds them
with the current pods, then applies ownership and grants.

```
sandbox_prj_smart_insights.delivery_org_hierarchy   -- one row per pod, with its full org path
sandbox_prj_smart_insights.delivery_pod_links       -- one row per issue/MR link
```

Everything afterwards — the reporting job and the dashboard UI — reads its pods and links from these
tables. `delivery_config.json` in the reporting project keeps only the reporting window and
thresholds.

## Requirements

```
python 3.8+
psycopg2
```

## Usage

```bash
# create the tables, seed them with the three current pods, then show the result
python setup_config_tables.py

# seed from an existing nested config file instead of the built-in seed
python setup_config_tables.py --from-json old_delivery_config.json

# just show what is in the tables now
python setup_config_tables.py --show

# drop both tables first (destroys the configuration, not the metrics)
python setup_config_tables.py --drop
```

The password is read from `GREENPLUM_PASSWORD`, or prompted for (hidden input). It is never stored.

## What it does

1. `CREATE TABLE IF NOT EXISTS` for both tables
2. `ALTER TABLE ... OWNER TO` and `GRANT SELECT ... TO` on each — from `IKG_TABLE_OWNER_GROUP` and
   `IKG_TABLE_READER_GROUP`, defaulting to `erd_gpdb_prj_smart_insights` and
   `..._ro`. A grant failure is logged and rolled back on its own, so it cannot lose the data.
3. Replaces the configuration rows with the seed

**Re-running is safe.** Configuration is small and always written as a set, so it is replaced
wholesale rather than reconciled row by row — which also means a pod removed from the source really
does disappear rather than lingering. It never touches the metric tables.

## Expected output

```
Tables ready in sandbox_prj_smart_insights.
Loaded 3 pod(s) and 14 link(s).

sandbox_prj_smart_insights.delivery_org_hierarchy -- 3 pod(s)
  Global Wealth Management Americas > ... > STAAT Data Science
      Insights           key=insights       issue links=1   mr links=3
      Conv. Insights     key=conv_insights  issue links=1   mr links=7
      DS Data            key=ds_data        issue links=1   mr links=1
```

## Editing the configuration afterwards

Either edit the seed in this script and re-run it, or `INSERT` / `UPDATE` the tables directly.
`HOW_TO_CONFIGURE.md` has the SQL for adding a pod, a link, a crew or a whole new division, and
explains the `is_active` flag for retiring something without deleting history that refers to it.

## Environment variables

| Variable | Default |
|---|---|
| `GREENPLUM_HOST` | greenplum-rdsp.zur.swissbank.com |
| `GREENPLUM_PORT` | 5432 |
| `GREENPLUM_DB` | gprdsp |
| `GREENPLUM_USER` | ds_rdsp_dev |
| `GREENPLUM_PASSWORD` | prompted if unset |
| `DELIVERY_GP_SCHEMA` | sandbox_prj_smart_insights |
| `IKG_TABLE_OWNER_GROUP` | erd_gpdb_prj_smart_insights |
| `IKG_TABLE_READER_GROUP` | erd_gpdb_prj_smart_insights_ro |

## Verified

Run against a stubbed database: both `CREATE TABLE` statements issued, all four ownership and grant
statements applied, and the seed loaded as **3 pods and 14 links** (1/3, 1/7, 1/1 issue/MR links),
with full `https://` URLs normalised to bare project paths.
