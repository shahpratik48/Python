# How to configure

Configuration now lives in **two Greenplum tables**, not JSON. Only the reporting window and
thresholds stay in `delivery_config.json`.

| Where | What |
|---|---|
| `sandbox_prj_smart_insights.delivery_org_hierarchy` | one row per **pod**, with its full org path |
| `sandbox_prj_smart_insights.delivery_pod_links` | one row per **link**, so a pod may have many |
| `delivery_config.json` | the reporting window, baseline and thresholds |

Two tables rather than one because the relationship differs: a pod has exactly one place in the
hierarchy but many links. Flattening both into one table would repeat the whole org path on every URL
and make adding a link a copy-paste exercise.

---

## One-time setup

```bash
python setup_config_tables.py                      # create + seed + show
python setup_config_tables.py --from-json old.json # seed from a nested config file
python setup_config_tables.py --show               # show what is there now
python setup_config_tables.py --drop               # drop both tables first
```

Re-running replaces the configuration wholesale, so a pod removed from the source really does
disappear rather than lingering.

---

## `delivery_org_hierarchy`

| Column | Notes |
|---|---|
| `division`, `subdivision`, `stream`, `crew` | the org path |
| `pod_name` | display name. Also the **start of every file name** for that pod, and its `scope_name` in the metric tables |
| `pod_key` | short id used to join to `delivery_pod_links`. Must be unique |
| `group_path` | group holding iterations and epics. Needed for proper iteration names |
| `is_active` | set `false` to retire a pod without deleting history that refers to it |

## `delivery_pod_links`

| Column | Notes |
|---|---|
| `pod_key` | joins to the hierarchy table |
| `link_type` | `issue` or `mr` |
| `link_label` | column header for MR repos. Ignored for issue links |
| `link_path` | project path or full `https://` URL |
| `is_active` | set `false` to retire a link |

---

## Adding things

### A new pod

```sql
INSERT INTO sandbox_prj_smart_insights.delivery_org_hierarchy
  (division, subdivision, stream, crew, pod_name, pod_key, group_path, is_active,
   updated_timestamp)
VALUES ('Global Wealth Management Americas', 'Global Wealth Management Americas',
        'Data Analytics and Foundational Platforms', 'STAAT Data Science',
        'Data Platform', 'data_platform', 'ubs/.../dp', true, now());

INSERT INTO sandbox_prj_smart_insights.delivery_pod_links
  (pod_key, link_type, link_label, link_path, is_active, updated_timestamp)
VALUES ('data_platform', 'issue', '',       'ubs/.../dp-board',  true, now()),
       ('data_platform', 'issue', '',       'ubs/.../dp-intake', true, now()),
       ('data_platform', 'mr',    'ingest', 'ubs/.../dp-ingest', true, now()),
       ('data_platform', 'mr',    'api',    'ubs/.../dp-api',    true, now());
```

Nothing else to change. The next run produces `Data_Platform_pod_productivity_*.xlsx` and `.html`,
loads its four pod tables, and includes it in the crew roll-up.

### A new issue link or MR link on an existing pod

One more row in `delivery_pod_links` with the right `pod_key`. Issues are pooled across every issue
link; MRs are summed across every MR link.

### A new crew, stream, subdivision or division

There is no separate table for these — they are columns on the pod row. Insert pods with the new
values and the level appears. A crew with pods produces its own roll-up automatically.

### Retiring something

Set `is_active = false` rather than deleting. Historical metric rows that reference it stay valid,
and the pod simply stops being collected.

---

## Accepted values

**Full URLs are fine** — they are normalised, so you can paste from the browser:

```
https://devcloud.ubs.net/ubs/dp/board-a   ->  ubs/dp/board-a
```

**A link may name a project or a group.** Projects are tried first; anything that is not one is
expanded as a group and every project beneath it is included.

**A pod needs at least one active issue link and one active MR link.** One with neither is logged and
skipped rather than silently producing an empty report.

---

## Reporting settings — `delivery_config.json`

```json
{
  "reporting": {
    "start_month": "2024-11",
    "end_month": "2026-07",
    "baseline_month": "2025-11",
    "baseline_window_months": 3,
    "target_gain_pct": 20.0,
    "target_months": 14,
    "issue_sla_days": 5,
    "mr_sla_hours": 72,
    "issue_slowest_trim_pct": 15
  }
}
```

| Setting | Meaning |
|---|---|
| `start_month` | First month of the window. |
| `end_month` | **Intended** end of the window — see below. |
| `baseline_month` | First month of the baseline. |
| `baseline_window_months` | Baseline is the **mean** of this many months from `baseline_month`; 3 means Nov-25, Dec-25, Jan-26. |
| `target_gain_pct` / `target_months` | The aspiration ramp: 0% at the baseline, reaching the target after this many months. |
| `issue_sla_days` | Business days before an issue is flagged. |
| `mr_sla_hours` | Hours before a merge request is flagged. |
| `issue_slowest_trim_pct` | Slowest N% of each month's in-scope issues excluded from Cycle Time. 0 disables. |

### What `end_month` actually does

It sets the intended end of the reporting window — the last month drawn on the chart and listed in
the tables when the calendar has not yet passed it.

**It can never make the report go stale.** Once today is later than `end_month`, the window extends
to the current month automatically:

| `end_month` | Today | Window ends | Current month reloaded |
|---|---|---|---|
| 2026-07 | 2026-07 | 2026-07 | 2026-07 |
| 2026-07 | **2026-08** | **2026-08** | **2026-08** |
| 2026-07 | **2026-12** | **2026-12** | **2026-12** |
| 2026-07 | 2026-05 | 2026-07 | 2026-05 |

So a config left at `2026-07` keeps working in August — it does not silently stop reporting. The run
logs the extension when it happens. The current month is always deleted and reloaded, whatever
`end_month` says.

> Changing any reporting setting alters what stored months mean. Re-run once with
> `force_full_refresh=True` so history is recomputed on the new basis.
