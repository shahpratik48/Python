"""
setup_config_tables.py  --  RUN ONCE

Creates and populates the two configuration tables that replace the JSON
hierarchy. After this, the reports read their pods and links from Greenplum
and `delivery_config.json` holds only the reporting window and thresholds.

    sandbox_prj_smart_insights.delivery_org_hierarchy
        one row per POD, carrying its full org path
        division / subdivision / stream / crew / pod_name / pod_key / group_path

    sandbox_prj_smart_insights.delivery_pod_links
        one row per LINK, so a pod can have any number of each
        pod_key / link_type ('issue' | 'mr') / link_label / link_path

Two tables rather than one because the relationship differs: a pod has
exactly one place in the hierarchy, but many links. Flattening both into a
single table would repeat the whole org path on every URL and make adding a
link a copy-paste exercise.

Both carry `is_active`, so a pod or a link can be retired without deleting
history that already references it.

Usage
-----
    python setup_config_tables.py                 # create + seed + show
    python setup_config_tables.py --show          # show what is there now
    python setup_config_tables.py --from-json old_config.json
    python setup_config_tables.py --drop          # drop both tables first

Re-running is safe: rows are matched on their natural key and updated in
place rather than duplicated.
"""
from __future__ import annotations

import argparse
import getpass
import json
import os
import re
import sys
from typing import Dict, List, Optional

SCHEMA = os.getenv("DELIVERY_GP_SCHEMA", "sandbox_prj_smart_insights")
TBL_ORG = "delivery_org_hierarchy"
TBL_LINKS = "delivery_pod_links"

OWNER_GROUP = os.getenv("IKG_TABLE_OWNER_GROUP", "erd_gpdb_prj_smart_insights")
READER_GROUP = os.getenv("IKG_TABLE_READER_GROUP", "erd_gpdb_prj_smart_insights_ro")

DDL_ORG = """
CREATE TABLE IF NOT EXISTS {schema}.{tbl} (
  division           varchar(200),
  subdivision        varchar(200),
  stream             varchar(200),
  crew               varchar(200),
  pod_name           varchar(200),
  pod_key            varchar(100),
  group_path         varchar(500),
  is_active          boolean DEFAULT true,
  updated_timestamp  timestamp
)
"""

DDL_LINKS = """
CREATE TABLE IF NOT EXISTS {schema}.{tbl} (
  pod_key            varchar(100),
  link_type          varchar(10),
  link_label         varchar(200),
  link_path          varchar(500),
  is_active          boolean DEFAULT true,
  updated_timestamp  timestamp
)
"""

# ---------------------------------------------------------------- seed data
SEED = [
    {
        "division": "Global Wealth Management Americas",
        "subdivision": "Global Wealth Management Americas",
        "stream": "Data Analytics and Foundational Platforms",
        "crew": "STAAT Data Science",
        "pod_name": "Insights",
        "pod_key": "insights",
        "group_path": "ubs/gwma/smart-technology-and-analytics/staat-data-science/"
                      "staat-ds-insights-cl/commons",
        "issue_projects": [
            "ubs/gwma/smart-technology-and-analytics/staat-data-science/staat-ds-insights-cl/"
            "commons/staat-ds-insights-home"],
        "mr_repos": {
            "IKG": "ubs/gwma/smart-technology-and-analytics/staat-data-science/"
                   "staat-ds-genesis/genesis-platform/ikg-dags",
            "NLG": "ubs/gwma/smart-technology-and-analytics/staat-data-science/"
                   "staat-ds-genesis/genesis-platform/nlg-dags",
            "ODM": "ubs/gwma/smart-technology-and-analytics/staat-data-science/"
                   "staat-ds-genesis/genesis-platform/odm-dags"},
    },
    {
        "division": "Global Wealth Management Americas",
        "subdivision": "Global Wealth Management Americas",
        "stream": "Data Analytics and Foundational Platforms",
        "crew": "STAAT Data Science",
        "pod_name": "Conv. Insights",
        "pod_key": "conv_insights",
        "group_path": "ubs/gwma/smart-technology-and-analytics/staat-data-science/"
                      "staat-ds-genesis/genesis-platform",
        "issue_projects": [
            "ubs/gwma/smart-technology-and-analytics/staat-data-science/staat-ds-genesis/"
            "genesis-platform/data-elements"],
        "mr_repos": {
            k: "ubs/gwma/smart-technology-and-analytics/staat-data-science/staat-ds-genesis/"
               "genesis-platform/" + k
            for k in ("conv-insights", "data-elements", "data-elements-common", "de-api",
                      "transcript-accumulator", "nlg-chat", "portfolioq")},
    },
    {
        "division": "Global Wealth Management Americas",
        "subdivision": "Global Wealth Management Americas",
        "stream": "Data Analytics and Foundational Platforms",
        "crew": "STAAT Data Science",
        "pod_name": "DS Data",
        "pod_key": "ds_data",
        "group_path": "ubs/gwma/smart-technology-and-analytics/staat-data-science/"
                      "staat-ds-data/ds-data",
        "issue_projects": [
            "ubs/gwma/smart-technology-and-analytics/staat-data-science/staat-ds-data/"
            "ds-data/staat-ds-data-engineering"],
        "mr_repos": {
            "ds-data-dags": "ubs/gwma/smart-technology-and-analytics/staat-data-science/"
                            "staat-ds-genesis/genesis-platform/ds-data-dags"},
    },
]


# ---------------------------------------------------------------- helpers
def norm_path(value) -> str:
    p = str(value or "").strip().rstrip("/")
    if "://" in p:
        p = p.split("://", 1)[1]
        p = p.split("/", 1)[1] if "/" in p else ""
    return p.strip("/")


def rows_from_json(path: str) -> List[dict]:
    """Reads the old nested config so an existing file can seed the tables."""
    raw = json.load(open(path, encoding="utf-8"))
    out = []
    for d in raw.get("divisions", []):
        for s in d.get("subdivisions", []):
            for st in s.get("streams", []):
                for c in st.get("crews", []):
                    for p in c.get("pods", []):
                        name = str(p.get("name", "")).strip()
                        key = str(p.get("key") or "").strip() or \
                            re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")
                        issues = p.get("issue_projects")
                        if isinstance(issues, str):
                            issues = [issues]
                        repos = p.get("mr_repos") or {}
                        if isinstance(repos, (list, tuple)):
                            repos = {norm_path(x).rsplit("/", 1)[-1]: x for x in repos}
                        out.append({
                            "division": d.get("name", ""), "subdivision": s.get("name", ""),
                            "stream": st.get("name", ""), "crew": c.get("name", ""),
                            "pod_name": name, "pod_key": key,
                            "group_path": p.get("group_path", ""),
                            "issue_projects": issues or [], "mr_repos": repos})
    return out


def connect():
    import psycopg2
    host = os.getenv("GREENPLUM_HOST", "greenplum-rdsp.zur.swissbank.com")
    port = int(os.getenv("GREENPLUM_PORT", "5432"))
    db = os.getenv("GREENPLUM_DB", "gprdsp")
    user = os.getenv("GREENPLUM_USER", "ds_rdsp_dev")
    pwd = os.getenv("GREENPLUM_PASSWORD") or getpass.getpass(
        "Greenplum password for %s@%s: " % (user, host))
    print("Connecting to %s:%s/%s as %s ..." % (host, port, db, user))
    return psycopg2.connect(host=host, port=port, dbname=db, user=user, password=pwd,
                            connect_timeout=30)


def grant(cur, conn, tbl):
    for sql in ("ALTER TABLE {s}.{t} OWNER TO {g}".format(s=SCHEMA, t=tbl, g=OWNER_GROUP),
                "GRANT SELECT ON {s}.{t} TO {g}".format(s=SCHEMA, t=tbl, g=READER_GROUP)):
        try:
            cur.execute(sql)
            conn.commit()
        except Exception as e:
            conn.rollback()
            print("   WARNING could not apply '%s': %s" % (sql, e))


def upsert(cur, rows: List[dict]):
    """Replaces the configuration wholesale.

    Config is small and always written as a set, so replacing it is simpler
    and safer than reconciling row by row -- and it means a pod removed from
    the source really does disappear rather than lingering.
    """
    cur.execute("DELETE FROM {s}.{t}".format(s=SCHEMA, t=TBL_ORG))
    cur.execute("DELETE FROM {s}.{t}".format(s=SCHEMA, t=TBL_LINKS))

    org_sql = ("INSERT INTO {s}.{t} (division, subdivision, stream, crew, pod_name, pod_key, "
               "group_path, is_active, updated_timestamp) "
               "VALUES (%s,%s,%s,%s,%s,%s,%s,%s, now())".format(s=SCHEMA, t=TBL_ORG))
    link_sql = ("INSERT INTO {s}.{t} (pod_key, link_type, link_label, link_path, is_active, "
                "updated_timestamp) VALUES (%s,%s,%s,%s,%s, now())".format(s=SCHEMA,
                                                                           t=TBL_LINKS))
    n_links = 0
    for r in rows:
        cur.execute(org_sql, (r["division"], r["subdivision"], r["stream"], r["crew"],
                              r["pod_name"], r["pod_key"], norm_path(r.get("group_path")),
                              True))
        for path in r.get("issue_projects", []):
            cur.execute(link_sql, (r["pod_key"], "issue", "", norm_path(path), True))
            n_links += 1
        for label, path in (r.get("mr_repos") or {}).items():
            cur.execute(link_sql, (r["pod_key"], "mr", str(label), norm_path(path), True))
            n_links += 1
    return len(rows), n_links


def show(cur):
    cur.execute("SELECT division, subdivision, stream, crew, pod_name, pod_key, is_active "
                "FROM {s}.{t} ORDER BY division, subdivision, stream, crew, pod_name"
                .format(s=SCHEMA, t=TBL_ORG))
    rows = cur.fetchall()
    if not rows:
        print("No configuration rows found.")
        return
    print("\n%s.%s -- %d pod(s)" % (SCHEMA, TBL_ORG, len(rows)))
    last = None
    for d, sd, st, cw, pn, pk, act in rows:
        path = (d, sd, st, cw)
        if path != last:
            print("  %s > %s > %s > %s" % path)
            last = path
        cur.execute("SELECT link_type, count(*) FROM {s}.{t} WHERE pod_key = %s "
                    "AND is_active GROUP BY link_type".format(s=SCHEMA, t=TBL_LINKS), (pk,))
        counts = dict(cur.fetchall())
        print("      %-18s key=%-14s issue links=%-3s mr links=%-3s %s"
              % (pn, pk, counts.get("issue", 0), counts.get("mr", 0),
                 "" if act else "(INACTIVE)"))


def main():
    ap = argparse.ArgumentParser(description="Create and seed the delivery config tables.")
    ap.add_argument("--from-json", metavar="PATH",
                    help="seed from a nested config file instead of the built-in seed")
    ap.add_argument("--show", action="store_true", help="only show what is already there")
    ap.add_argument("--drop", action="store_true", help="drop both tables first")
    args = ap.parse_args()

    conn = connect()
    try:
        cur = conn.cursor()
        if args.show:
            show(cur)
            return

        if args.drop:
            for t in (TBL_ORG, TBL_LINKS):
                cur.execute("DROP TABLE IF EXISTS {s}.{t}".format(s=SCHEMA, t=t))
            conn.commit()
            print("Dropped %s.%s and %s.%s" % (SCHEMA, TBL_ORG, SCHEMA, TBL_LINKS))

        for ddl, t in ((DDL_ORG, TBL_ORG), (DDL_LINKS, TBL_LINKS)):
            cur.execute(ddl.format(schema=SCHEMA, tbl=t))
        conn.commit()
        print("Tables ready in %s." % SCHEMA)
        for t in (TBL_ORG, TBL_LINKS):
            grant(cur, conn, t)

        rows = rows_from_json(args.from_json) if args.from_json else SEED
        n_pods, n_links = upsert(cur, rows)
        conn.commit()
        print("Loaded %d pod(s) and %d link(s)." % (n_pods, n_links))
        show(cur)
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


if __name__ == "__main__":
    main()
