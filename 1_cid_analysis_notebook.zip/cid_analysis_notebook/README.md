# CID analysis — notebook bundle

Everything needed to run the check from a notebook, with no Airflow.

## Files

| File | Purpose |
|---|---|
| `run_cid_analysis.ipynb` | **start here** |
| `cid_settings.py` | branch/schema rules, secrets, logging |
| `cid_gitlab.py` | reads the branch (one archive download) |
| `cid_greenplum.py` | CID metadata + schema comparison |
| `cid_scan.py` | column usage and MD5 masking detection |
| `cid_analysis.py` | the six steps |
| `cid_report.py` | XLSX + HTML |
| `cid_main.py` | `run_cid_analysis()` |
| `HOW_IT_WORKS.md` | flow diagram and the full rule set |

## Running it

Open `run_cid_analysis.ipynb` and work down. You will be asked for:

| Input | Notes |
|---|---|
| `DAG_ID` | `nlg_dummy` or `nlg_dummy2` |
| `INPUT_BRANCH` | the feature branch — **nlg_dummy2 only**; `nlg_dummy` always uses develop |
| `IKG_SCHEMA` | Dev schema, e.g. `sandbox_prj_smart_insights` — used by `nlg_dummy2` |
| `IKG_PRE_PROD_SCHEMA` | UAT schema, e.g. `sandbox_ikg_pre_prd` — used by `nlg_dummy` |
| GitLab token | prompted, hidden |
| Greenplum password | prompted, hidden |

Requires `requests`, `PyYAML`, `openpyxl`, `psycopg2`. Python 3.8+.

## Output

`cid_report_<dag>_<branch>_<timestamp>.xlsx` and `.html`, plus a timestamped log, all beside the
notebook. Both are written whether or not anything was flagged.

## The rule in one line

A CID column may not appear in `sql_column_mapping` at all, and may appear in
`input_data_config_dummy` only wrapped in MD5. Anything else is flagged, and in the DAG that fails
the task.
