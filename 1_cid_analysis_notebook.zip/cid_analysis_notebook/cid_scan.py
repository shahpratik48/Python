"""
Finding the columns each config file uses, and whether they are masked.

## The two file patterns

**input_data_config_dummy/<target_type>.yml** -- flat folder, one file per
target type:

    account:
      input_db_join_col: acc_i
      sql_column_mapping:
        target_id:  b.acc_mhh_n::text
        ip_frst_x:  substring(MD5(b.ip_frst_x),1,8)

**sql_column_mapping/<target_type>/[<sub>/]<insight_type>.yml|.json** --
nested one or two levels deep, a flat map of output name to expression:

    data_asof_d: b.data_asof_d
    comp_set_with_event_name: >-
      case when b.comp_set = 'Target' then ... end as comp_set_with_event_name

In both the KEY is an output name and the VALUE is a SQL expression, so the
columns are found by parsing the expressions -- not by matching the keys,
which are frequently renamed (`ip_frst_x_real`, `hh_lead_account_title`) and
would miss the underlying column entirely.

`.json` files carry the same shape and are read the same way; there are 139
of them in the reference tree, so skipping them would leave a real gap.
"""
from __future__ import annotations

import json
import posixpath
import re
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Set, Tuple

import yaml

from cid_settings import get_logger

log = get_logger("cid.scan")

CONFIG_DIR_NAME = "input_data_config_dummy"
MAPPING_DIR_NAME = "sql_column_mapping"
DATA_SUFFIXES = (".yml", ".yaml", ".json")

_MASK_FN = re.compile(r"\b(md5|sha1|sha224|sha256|sha384|sha512|hashtext|encode|digest)\s*\(",
                      re.I)

# words that look like identifiers but never name a column
SQL_WORDS = {
    "select", "distinct", "from", "where", "and", "or", "not", "in", "is", "null", "case",
    "when", "then", "else", "end", "as", "on", "join", "inner", "left", "right", "full",
    "outer", "cross", "over", "partition", "by", "order", "group", "having", "asc", "desc",
    "interval", "cast", "date", "text", "int", "integer", "bigint", "numeric", "boolean",
    "timestamp", "varchar", "char", "float", "double", "precision", "day", "month", "year",
    "hour", "minute", "second", "true", "false", "between", "like", "ilike", "exists",
    "union", "all", "rows", "range", "preceding", "following", "unbounded", "current", "row",
    "nulls", "first", "last", "using", "filter", "within", "escape", "collate", "similar",
    "delimiter", "sub",
}


@dataclass
class Usage:
    file_path: str
    yaml_key: str
    column: str
    logic: str
    masked: bool
    target_type: str = ""


# ---------------------------------------------------------------- discovery
def is_data_file(path: str) -> bool:
    return path.lower().endswith(DATA_SUFFIXES)


def in_folder(path: str, folder: str) -> bool:
    """True when `folder` is one of the path's directory components.

    Matched by NAME at any depth rather than by a fixed prefix: the folders
    sit under `src/` in the reference checkout, but a repository layout that
    differs by even one level would otherwise silently find nothing -- which
    reads exactly like a clean result.
    """
    parts = path.replace("\\", "/").strip("/").split("/")
    return folder in parts[:-1]


def split_trees(files: Dict[str, str]) -> Tuple[Dict[str, str], Dict[str, str], List[str]]:
    """(config files, mapping files, problems)."""
    cfg = {p: t for p, t in files.items()
           if in_folder(p, CONFIG_DIR_NAME) and is_data_file(p)}
    mp = {p: t for p, t in files.items()
          if in_folder(p, MAPPING_DIR_NAME) and is_data_file(p)}
    problems = []
    if not cfg:
        problems.append("No .yml/.yaml/.json files found in any '%s' folder." % CONFIG_DIR_NAME)
    if not mp:
        problems.append("No .yml/.yaml/.json files found in any '%s' folder." % MAPPING_DIR_NAME)
    log.info("Discovered %d file(s) under '%s' and %d under '%s'.",
             len(cfg), CONFIG_DIR_NAME, len(mp), MAPPING_DIR_NAME)
    for name, d in (("config", cfg), ("mapping", mp)):
        roots = sorted({p.rsplit("/" + posixpath.basename(p), 1)[0] for p in list(d)[:400]})
        if roots:
            log.info("  %s roots: %s%s", name, ", ".join(roots[:4]),
                     " ... (%d in total)" % len(roots) if len(roots) > 4 else "")
    return cfg, mp, problems


# ---------------------------------------------------------------- parsing
def parse_doc(text: str, path: str):
    """YAML or JSON, whichever the file is."""
    if not text or not text.strip():
        return None
    try:
        if path.lower().endswith(".json"):
            return json.loads(text)
        return yaml.safe_load(text)
    except Exception as e:
        log.warning("Could not parse %s (%s); falling back to a line scan.", path, e)
        return None


def expressions(doc, path: str) -> List[Tuple[str, str]]:
    """(output name, SQL expression) for every leaf in the document.

    `input_data_config_dummy` nests its expressions under
    `<target_type>.sql_column_mapping`; the mapping files are flat. Walking
    every leaf handles both without needing to know which is which, and
    keeps working if a new key is added.
    """
    out: List[Tuple[str, str]] = []

    def walk(node, key_path=""):
        if isinstance(node, dict):
            for k, v in node.items():
                walk(v, "%s.%s" % (key_path, k) if key_path else str(k))
        elif isinstance(node, list):
            for i, v in enumerate(node):
                walk(v, "%s[%d]" % (key_path, i))
        elif node is not None:
            s = str(node).strip()
            if s:
                out.append((key_path, s))

    walk(doc)
    return out


def _mask_literals(expr: str) -> str:
    """Blanks string literals so identifier scanning cannot match inside
    them, keeping every offset intact."""
    out, i, n, in_str = list(expr), 0, len(expr), False
    while i < n:
        c = expr[i]
        if c == "'":
            j = i + 1
            while j < n:
                if expr[j] == "'":
                    if j + 1 < n and expr[j + 1] == "'":
                        j += 2
                        continue
                    break
                j += 1
            for k in range(i, min(j + 1, n)):
                out[k] = " "
            i = j + 1
            continue
        i += 1
    return "".join(out)


_QUALIFIED = re.compile(r"\b([A-Za-z_][\w$]*)\s*\.\s*([A-Za-z_][\w$]*)")
_BARE = re.compile(r"(?<![\w.$])([A-Za-z_][\w$]*)")


_AS_TAIL = re.compile(r"\bas\s+([A-Za-z_][\w$]*)\s*$", re.I)


def strip_output_alias(expr: str) -> str:
    """Drops a trailing `AS name`.

    That name is being DEFINED, not read. Left in, `'acc_i' as key_name`
    would report `key_name` as a column, and any alias that happens to share
    a CID column's name would raise a false finding.
    """
    return _AS_TAIL.sub("", expr).rstrip()


def extract_columns(expr: str) -> List[str]:
    """Every column name an expression reads.

    Qualified references (`b.acc_mhh_n`) give the column after the dot. Bare
    identifiers count too, with keywords, function names and cast targets
    filtered out -- at token level those look identical to a column, and
    including them would flood the report with `case`, `substring`, `text`.
    """
    masked = _mask_literals(strip_output_alias(expr))
    cols: List[str] = []
    taken = set()

    for m in _QUALIFIED.finditer(masked):
        cols.append(m.group(2).lower())
        taken.update(range(m.start(), m.end()))

    for m in _BARE.finditer(masked):
        if m.start() in taken:
            continue
        w = m.group(1)
        if w.lower() in SQL_WORDS:
            continue
        if masked[m.end():].lstrip().startswith("("):      # function call
            continue
        if masked[m.end():].lstrip().startswith("."):      # a table alias
            continue
        if masked[:m.start()].rstrip().endswith("::"):     # cast target
            continue
        cols.append(w.lower())

    return list(dict.fromkeys(cols))


def _mask_spans(expr: str) -> List[Tuple[int, int]]:
    """Character ranges covered by a hashing function's arguments."""
    spans = []
    for m in _MASK_FN.finditer(expr):
        depth = 0
        for j in range(m.end() - 1, len(expr)):
            if expr[j] == "(":
                depth += 1
            elif expr[j] == ")":
                depth -= 1
                if depth == 0:
                    spans.append((m.end(), j))
                    break
        else:
            spans.append((m.end(), len(expr)))
    return spans


def _col_pattern(column: str):
    return re.compile(r"(?<![\w$])%s(?![\w$])" % re.escape(column), re.I)


def is_masked(expr: str, column: str) -> Optional[bool]:
    """True only when EVERY occurrence sits inside a hashing call.

    One bare use is enough to leak the value, so partial masking counts as
    unmasked -- `MD5(b.a) || b.ip_frst_x` is NOT masked, even though the
    expression contains MD5.
    """
    spans = _mask_spans(expr)
    total = inside = 0
    for m in _col_pattern(column).finditer(expr):
        total += 1
        if any(a <= m.start() < b for a, b in spans):
            inside += 1
    return None if total == 0 else inside == total


# ---------------------------------------------------------------- scanning
def target_type_of(path: str, doc, folder: str) -> str:
    """`input_data_config_dummy` names it as the single top-level key;
    `sql_column_mapping` puts it in the folder just below the root."""
    if folder == CONFIG_DIR_NAME:
        if isinstance(doc, dict) and len(doc) == 1:
            return str(list(doc.keys())[0])
        return posixpath.basename(path).rsplit(".", 1)[0]
    parts = path.replace("\\", "/").strip("/").split("/")
    if MAPPING_DIR_NAME in parts:
        i = parts.index(MAPPING_DIR_NAME)
        if i + 1 < len(parts) - 1:
            return parts[i + 1]
    return ""


def scan_files(files: Dict[str, str], columns: Iterable[str], folder: str) -> List[Usage]:
    """Every use of any of `columns`, found by parsing each expression.

    Each file is parsed ONCE and its columns extracted once, then matched
    against the wanted set. Searching the raw text per column instead would
    re-scan ~470 files for every CID column.
    """
    want = {c.strip().lower() for c in columns if c and c.strip()}
    if not want:
        return []
    out: List[Usage] = []
    n_expr = 0

    for path, text in files.items():
        doc = parse_doc(text, path)
        if doc is None:
            leaves = [("(line %d)" % (i + 1), ln.strip())
                      for i, ln in enumerate((text or "").splitlines()) if ln.strip()]
            tt = posixpath.basename(path).rsplit(".", 1)[0]
        else:
            leaves = expressions(doc, path)
            tt = target_type_of(path, doc, folder)

        for key, expr in leaves:
            n_expr += 1
            for col in extract_columns(expr):
                if col not in want:
                    continue
                out.append(Usage(file_path=path, yaml_key=key, column=col,
                                 logic=" ".join(expr.split()),
                                 masked=bool(is_masked(expr, col)), target_type=tt))

    log.info("Scanned %d file(s) / %d expression(s) for %d column(s): %d usage(s).",
             len(files), n_expr, len(want), len(out))
    return out


def all_columns_used(files: Dict[str, str]) -> Set[str]:
    """Every column referenced anywhere -- useful for sanity-checking that
    the parser is actually reading the files."""
    seen: Set[str] = set()
    for path, text in files.items():
        doc = parse_doc(text, path)
        if doc is None:
            continue
        for _k, expr in expressions(doc, path):
            seen.update(extract_columns(expr))
    return seen


def load_profile_map(text: str) -> Dict[str, str]:
    """`target_type -> profile table` from profile_tbl.yaml."""
    try:
        doc = yaml.safe_load(text) or {}
    except Exception as e:
        log.error("Could not parse the profile map: %s", e)
        return {}
    out = {}
    for row in (doc.get("profile_tables") or []):
        if isinstance(row, dict):
            tt = str(row.get("target_type") or "").strip()
            tbl = str(row.get("profile_table_name") or "").strip()
            if tt and tbl:
                out[tt] = tbl
    log.info("Profile map: %d target_type -> table entries.", len(out))
    return out
