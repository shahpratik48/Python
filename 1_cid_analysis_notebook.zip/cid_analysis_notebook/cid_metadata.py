"""
Keeping the two CID metadata tables in step with the anonymisation code.

    core_ikg.cid_tables_metadata_manual_refresh    table_name, is_cid, created_at
    core_ikg.cid_columns_metadata_manual_refresh   cid_profile_column, is_cid, created_at

A table or column appearing in the anonymise function is, by definition,
client-identifying -- the team is already hashing it. So each run reconciles
what the code does against what the metadata says:

  * present in the code, absent from the table   -> INSERT with is_cid = 'Y'
  * present in both, but recorded as 'N'         -> UPDATE to 'Y'
  * present in both and already 'Y'              -> leave alone

Every row appears exactly once; nothing is ever inserted twice. What changed
is returned rather than merely logged, because the report has to show it and
the task has to fail on it.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Sequence, Set

try:
    from .cid_settings import CID_METADATA_SCHEMA, get_logger
except ImportError:                     # loaded as loose modules
    from cid_settings import CID_METADATA_SCHEMA, get_logger  # type: ignore

log = get_logger("cid.metadata")

TABLES_TABLE = "cid_tables_metadata_manual_refresh"
COLUMNS_TABLE = "cid_columns_metadata_manual_refresh"

# The column holding the name differs between the two tables, and a
# deployment may have named it differently again, so it is discovered rather
# than assumed.
TABLE_NAME_CANDIDATES = ("table_name", "tbl_name", "tablename")
COLUMN_NAME_CANDIDATES = ("cid_profile_column", "column_name", "col_name", "column_nm")


@dataclass
class MetadataChange:
    kind: str              # "table" | "column"
    name: str
    action: str            # "inserted" | "flag changed to Y"
    previous: str = ""


@dataclass
class MetadataResult:
    tables_inserted: List[str] = field(default_factory=list)
    tables_flagged: List[str] = field(default_factory=list)
    columns_inserted: List[str] = field(default_factory=list)
    columns_flagged: List[str] = field(default_factory=list)
    all_cid_tables: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)

    @property
    def changes(self) -> List[MetadataChange]:
        out = []
        for n in self.tables_inserted:
            out.append(MetadataChange("table", n, "inserted"))
        for n in self.tables_flagged:
            out.append(MetadataChange("table", n, "flag changed to Y", "N"))
        for n in self.columns_inserted:
            out.append(MetadataChange("column", n, "inserted"))
        for n in self.columns_flagged:
            out.append(MetadataChange("column", n, "flag changed to Y", "N"))
        return out

    @property
    def any_change(self) -> bool:
        return bool(self.changes)


def _name_column(cur, schema: str, table: str, candidates: Sequence[str]) -> Optional[str]:
    cur.execute("SELECT column_name FROM information_schema.columns "
                "WHERE table_schema = %s AND table_name = %s", (schema, table))
    cols = [str(r[0]).lower() for r in cur.fetchall()]
    if not cols:
        return None
    for c in candidates:
        if c in cols:
            return c
    return cols[0]


def _has_column(cur, schema: str, table: str, name: str) -> bool:
    cur.execute("SELECT 1 FROM information_schema.columns "
                "WHERE table_schema = %s AND table_name = %s AND column_name = %s",
                (schema, table, name))
    return cur.fetchone() is not None


def _reconcile(conn, schema: str, table: str, name_col_candidates: Sequence[str],
               wanted: Iterable[str], kind: str):
    """Insert what is missing, flip 'N' to 'Y', touch nothing else."""
    inserted, flagged = [], []
    wanted = sorted({str(w).strip().lower() for w in wanted if str(w).strip()})
    if not wanted:
        return inserted, flagged

    cur = conn.cursor()
    name_col = _name_column(cur, schema, table, name_col_candidates)
    if not name_col:
        raise RuntimeError("%s.%s does not exist, or has no columns." % (schema, table))
    has_flag = _has_column(cur, schema, table, "is_cid")
    has_created = _has_column(cur, schema, table, "created_at")
    log.info("%s.%s: name column '%s'%s%s.", schema, table, name_col,
             ", is_cid" if has_flag else "", ", created_at" if has_created else "")

    sel = "SELECT lower(trim(%s))%s FROM %s.%s" % (
        name_col, ", upper(trim(coalesce(is_cid,'')))" if has_flag else "", schema, table)
    cur.execute(sel)
    existing = {}
    for row in cur.fetchall():
        if row[0]:
            existing[row[0]] = (row[1] if has_flag and len(row) > 1 else "Y")

    to_insert = [w for w in wanted if w not in existing]
    to_flag = [w for w in wanted if w in existing and has_flag and existing[w] != "Y"]

    cols = [name_col] + (["is_cid"] if has_flag else []) + (["created_at"] if has_created else [])
    vals = ["%s"] + (["'Y'"] if has_flag else []) + (["current_timestamp"] if has_created else [])
    ins = "INSERT INTO %s.%s (%s) VALUES (%s)" % (schema, table, ", ".join(cols),
                                                  ", ".join(vals))
    for name in to_insert:
        cur.execute(ins, (name,))
        inserted.append(name)
        log.info("  INSERT %s '%s' (is_cid = Y).", kind, name)

    if to_flag:
        upd = ("UPDATE %s.%s SET is_cid = 'Y'%s WHERE lower(trim(%s)) = %%s"
               % (schema, table,
                  ", created_at = current_timestamp" if has_created else "", name_col))
        for name in to_flag:
            cur.execute(upd, (name,))
            flagged.append(name)
            log.info("  UPDATE %s '%s': is_cid N -> Y.", kind, name)

    conn.commit()
    if not to_insert and not to_flag:
        log.info("  %s.%s already up to date (%d name(s) checked).", schema, table, len(wanted))
    return inserted, flagged


def reconcile_metadata(conn, tables: Iterable[str], columns: Iterable[str],
                       schema: str = CID_METADATA_SCHEMA) -> MetadataResult:
    """Bring both metadata tables in line with the anonymise function."""
    res = MetadataResult()
    try:
        res.tables_inserted, res.tables_flagged = _reconcile(
            conn, schema, TABLES_TABLE, TABLE_NAME_CANDIDATES, tables, "table")
    except Exception as e:
        conn.rollback()
        msg = "Could not update %s.%s: %s" % (schema, TABLES_TABLE, e)
        res.errors.append(msg)
        log.error(msg)

    try:
        res.columns_inserted, res.columns_flagged = _reconcile(
            conn, schema, COLUMNS_TABLE, COLUMN_NAME_CANDIDATES, columns, "column")
    except Exception as e:
        conn.rollback()
        msg = "Could not update %s.%s: %s" % (schema, COLUMNS_TABLE, e)
        res.errors.append(msg)
        log.error(msg)

    try:
        res.all_cid_tables = load_cid_tables(conn, schema)
    except Exception as e:
        res.errors.append("Could not read %s.%s: %s" % (schema, TABLES_TABLE, e))
        log.error(res.errors[-1])

    log.info("Metadata reconciled: %d table(s) inserted, %d re-flagged; "
             "%d column(s) inserted, %d re-flagged.",
             len(res.tables_inserted), len(res.tables_flagged),
             len(res.columns_inserted), len(res.columns_flagged))
    return res


def load_cid_tables(conn, schema: str = CID_METADATA_SCHEMA) -> List[str]:
    """Every table recorded as CID, whether added on this run or long ago."""
    cur = conn.cursor()
    name_col = _name_column(cur, schema, TABLES_TABLE, TABLE_NAME_CANDIDATES)
    if not name_col:
        return []
    has_flag = _has_column(cur, schema, TABLES_TABLE, "is_cid")
    sql = "SELECT DISTINCT lower(trim(%s)) FROM %s.%s" % (name_col, schema, TABLES_TABLE)
    if has_flag:
        sql += " WHERE upper(trim(coalesce(is_cid,''))) = 'Y'"
    cur.execute(sql)
    out = sorted({r[0] for r in cur.fetchall() if r[0]})
    log.info("%s.%s holds %d CID table(s).", schema, TABLES_TABLE, len(out))
    return out
