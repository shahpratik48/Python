"""
The six steps of the CID check.

    1  resolve the branch          nlg_dummy -> develop; nlg_dummy2 -> input
    2  CID columns                 core_ikg, is_cid = 'Y'
    3  sql_column_mapping          ANY use of a CID column is flagged
    4  input_data_config_dummy     a CID column used WITHOUT MD5 is flagged
    5  schema comparison           new columns vs production; CID ones get
                                   steps 3 and 4 applied, and every new
                                   column is reported with how it is used
    6  fail the task               if anything at all was flagged

Steps 3 and 4 differ on purpose. `sql_column_mapping` builds the narrative
text a person reads, so a CID column appearing there at all is a finding.
`input_data_config_dummy` is allowed to carry CID columns provided they are
hashed, so only unmasked uses are findings.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set

from cid_scan import (CONFIG_DIR_NAME, MAPPING_DIR_NAME, Usage, all_columns_used,
                      load_profile_map, scan_files, split_trees)
from cid_settings import CID_METADATA_SCHEMA, get_logger

log = get_logger("cid.analysis")

# what a finding is
F_MAPPING_CID = "CID column used in sql_column_mapping"
F_CONFIG_UNMASKED = "CID column used without MD5 in input_data_config_dummy"
F_NEW_CID = "New column is CID and is used in the branch"


@dataclass
class Finding:
    step: str
    severity: str                 # "FLAG" or "INFO"
    rule: str
    column: str
    is_cid: str                   # Y / N
    masked: str                   # Yes / No / n/a
    file_path: str = ""
    yaml_key: str = ""
    logic: str = ""
    target_type: str = ""
    profile_table: str = ""
    exposure: str = ""            # how many occurrences reach the output
    context: str = ""             # why masking is or is not required here
    note: str = ""


@dataclass
class AnalysisResult:
    dag_id: str = ""
    branch: str = ""
    compare_schema: str = ""
    cid_column_count: int = 0
    files_config: int = 0
    files_mapping: int = 0
    findings: List[Finding] = field(default_factory=list)
    new_columns: Dict[str, Set[str]] = field(default_factory=dict)
    profile_tables: Dict[str, str] = field(default_factory=dict)
    excluded_keys: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)

    @property
    def flagged(self) -> List[Finding]:
        return [f for f in self.findings if f.severity == "FLAG"]

    @property
    def new_column_count(self) -> int:
        return sum(len(v) for v in self.new_columns.values())

    @property
    def failed(self) -> bool:
        """The task fails on a flag OR on ANY new column.

        A new column is not a violation in itself, but nobody has yet
        decided whether it is client-identifying. Passing silently would let
        that decision be skipped, so the run stops for a person to look --
        whether or not the column is CID, and whether or not the branch uses
        it yet.
        """
        return bool(self.flagged) or self.new_column_count > 0

    @property
    def fail_reason(self) -> str:
        bits = []
        if self.flagged:
            bits.append("%d item(s) flagged" % len(self.flagged))
        if self.new_column_count:
            bits.append("%d new column(s) needing a CID decision"
                        % self.new_column_count)
        return " and ".join(bits) if bits else "nothing to review"

    def counts(self) -> Dict[str, int]:
        out: Dict[str, int] = {}
        for f in self.flagged:
            out[f.rule] = out.get(f.rule, 0) + 1
        return out


def _usage_finding(u: Usage, rule: str, step: str, is_cid: str, severity: str,
                   profile_table: str = "", note: str = "") -> Finding:
    return Finding(step=step, severity=severity, rule=rule, column=u.column,
                   is_cid=is_cid, masked=("Yes" if u.masked else "No"),
                   file_path=u.file_path, yaml_key=u.yaml_key, logic=u.logic,
                   target_type=u.target_type, profile_table=profile_table,
                   exposure=("%d exposed / %d unmasked" % (u.exposed, u.unmasked_exposed)
                             if u.exposed else "not exposed"),
                   context=u.context, note=note)


def analyse(settings, repo, conn) -> AnalysisResult:
    res = AnalysisResult(dag_id=settings.dag_id, branch=settings.branch,
                         compare_schema=settings.compare_schema)

    # ---------------- files ----------------
    # The whole branch is read and the two folders located by NAME at any
    # depth. Fixed prefixes assume a layout, and one extra directory level
    # would silently match nothing -- indistinguishable from a clean result.
    all_files = repo.load_tree()
    cfg_files, map_files, problems = split_trees(all_files)
    res.files_config, res.files_mapping = len(cfg_files), len(map_files)
    for p in problems:
        res.errors.append("%s (branch '%s')" % (p, settings.branch))
        log.error(p)

    # Proof the parser actually read them, and a quick way to spot a file
    # format that is not being understood.
    if cfg_files or map_files:
        used = all_columns_used(cfg_files) | all_columns_used(map_files)
        log.info("Parsed %d distinct column name(s) across both folders.", len(used))
        if not used:
            msg = ("Files were found but no column names could be parsed from them -- the "
                   "file format may have changed.")
            res.errors.append(msg)
            log.error(msg)

    # ---------------- step 2 ----------------
    excluded = settings.excluded_key_set()
    if excluded:
        log.info("Excluding %d YAML key(s) from the masking check: %s",
                 len(excluded), ", ".join(excluded))
        res.excluded_keys = list(excluded)

    from cid_greenplum import compare_schemas, load_cid_columns
    cid_meta = load_cid_columns(conn)
    cid_cols = set(cid_meta)
    res.cid_column_count = len(cid_cols)

    # ---------------- step 3 ----------------
    log.info("STEP 3: CID columns in sql_column_mapping -- a finding only where the VALUE "
             "reaches the output unmasked.")
    for u in scan_files(map_files, cid_cols, MAPPING_DIR_NAME, excluded):
        if u.needs_masking:
            res.findings.append(_usage_finding(
                u, F_MAPPING_CID, "3", "Y", "FLAG",
                note="The value reaches narrative text unmasked; wrap this occurrence in MD5."))
        else:
            res.findings.append(_usage_finding(
                u, "CID column used in sql_column_mapping without exposing the value", "3",
                "Y", "INFO",
                note="Recorded for completeness -- %s." % (u.context or "no value exposed")))

    # ---------------- step 4 ----------------
    log.info("STEP 4: CID columns in input_data_config_dummy -- unmasked uses are findings.")
    for u in scan_files(cfg_files, cid_cols, CONFIG_DIR_NAME, excluded):
        if u.needs_masking:
            res.findings.append(_usage_finding(
                u, F_CONFIG_UNMASKED, "4", "Y", "FLAG",
                note="The value is selected without MD5; wrap this occurrence."))
        else:
            res.findings.append(_usage_finding(
                u, "CID column used acceptably in input_data_config_dummy", "4", "Y", "INFO",
                note="Recorded for completeness -- %s." % (u.context or "hashed")))

    # ---------------- step 5 ----------------
    log.info("STEP 5: comparing '%s' against production '%s' for the profile tables behind "
             "input_data_config_dummy.", settings.compare_schema, CID_METADATA_SCHEMA)
    # located by file NAME, for the same reason as the folders above
    pmap_path = next((p for p in all_files
                      if p.endswith("/" + settings.profile_map_name)
                      or p == settings.profile_map_name), "")
    profile_map = load_profile_map(all_files[pmap_path]) if pmap_path else {}
    if pmap_path:
        log.info("Profile map read from %s.", pmap_path)
    else:
        msg = ("Could not find %s anywhere in the branch; step 5 has no tables to compare."
               % settings.profile_map_name)
        res.errors.append(msg)
        log.error(msg)

    # only the target_types that actually have a dummy config
    dummy_types = set()
    for p in cfg_files:
        import posixpath
        dummy_types.add(posixpath.basename(p).rsplit(".", 1)[0])
    tables = {tt: tbl for tt, tbl in profile_map.items() if tt in dummy_types}
    res.profile_tables = tables
    log.info("  %d profile table(s) in scope (target_types present in "
             "input_data_config_dummy).", len(tables))

    new_cols: Dict[str, Set[str]] = {}
    if tables:
        new_cols, _cmp, _prod = compare_schemas(conn, settings.compare_schema,
                                                list(tables.values()))
    res.new_columns = new_cols
    table_to_type = {v: k for k, v in tables.items()}

    every_new = sorted({c for cols in new_cols.values() for c in cols})
    if every_new:
        # Scanned once for ALL new columns, CID or not: the report has to say
        # how each new column is used either way, and one pass is enough.
        map_hits = scan_files(map_files, every_new, MAPPING_DIR_NAME, excluded)
        cfg_hits = scan_files(cfg_files, every_new, CONFIG_DIR_NAME, excluded)
    else:
        map_hits, cfg_hits = [], []
        log.info("  No new columns; nothing further to check for step 5.")

    for tbl in sorted(new_cols):
        tt = table_to_type.get(tbl, "")
        for col in sorted(new_cols[tbl]):
            cid = "Y" if col in cid_cols else "N"
            used_map = [u for u in map_hits if u.column == col]
            used_cfg = [u for u in cfg_hits if u.column == col]

            if not used_map and not used_cfg:
                res.findings.append(Finding(
                    step="5", severity="FLAG" if cid == "Y" else "INFO",
                    rule=("New CID column, not yet used in the branch" if cid == "Y"
                          else "New column, not used in the branch"),
                    column=col, is_cid=cid, masked="n/a", target_type=tt,
                    profile_table=tbl,
                    note=("Marked is_cid = Y in %s.%s. Not referenced yet, but it will need "
                          "masking before it is." % (CID_METADATA_SCHEMA,
                                                     "cid_columns_metadata_manual_refresh")
                          if cid == "Y" else "Reported so the change is visible.")))
                continue

            for u in used_map:
                bad = cid == "Y" and u.needs_masking
                res.findings.append(_usage_finding(
                    u, ("New CID column exposed in sql_column_mapping" if bad
                        else ("New CID column used in sql_column_mapping" if cid == "Y"
                              else "New column used in sql_column_mapping")),
                    "5", cid, "FLAG" if bad else "INFO",
                    profile_table=tbl,
                    note=("New in '%s' and marked CID." % settings.compare_schema
                          if cid == "Y" else "New in '%s'." % settings.compare_schema)))
            for u in used_cfg:
                if cid == "Y" and u.needs_masking:
                    res.findings.append(_usage_finding(
                        u, "New CID column used without MD5 in input_data_config_dummy",
                        "5", cid, "FLAG", profile_table=tbl,
                        note="New in '%s', marked CID, and not hashed."
                             % settings.compare_schema))
                else:
                    res.findings.append(_usage_finding(
                        u, ("New CID column used WITH MD5 (acceptable)" if cid == "Y"
                            else "New column used in input_data_config_dummy"),
                        "5", cid, "INFO", profile_table=tbl,
                        note="New in '%s'." % settings.compare_schema))

    # ---------------- step 6 ----------------
    n_flag = len(res.flagged)
    if n_flag:
        log.warning("STEP 6: %d item(s) flagged -- the task will fail so a person looks at "
                    "this.", n_flag)
        for rule, n in sorted(res.counts().items(), key=lambda kv: -kv[1]):
            log.warning("   %-62s %d", rule, n)
    else:
        log.info("STEP 6: nothing flagged.")
    return res
