"""
The XLSX and HTML reports.

Both are produced on EVERY run, pass or fail, because the email attaches
them either way -- a clean report is the evidence that the check ran, and is
as much a part of the audit trail as a failing one.
"""
from __future__ import annotations

import base64
import datetime as _dt
import html as _html
import os
from typing import List

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

# Imports work BOTH ways: as a package member (from nlg.src.cid import ...)
# and as loose modules on sys.path (the notebook). Relative is tried first
# so the package form does not depend on the folder being on sys.path.
try:
    from .cid_settings import CID_METADATA_SCHEMA, get_logger
except ImportError:                     # loaded as loose modules
    from cid_settings import CID_METADATA_SCHEMA, get_logger  # type: ignore

log = get_logger("cid.report")

C_HEAD, C_HEAD_TX = "305496", "FFFFFF"
C_FLAG_BG, C_FLAG_TX = "FDECEA", "9B1C1C"
C_OK_BG, C_OK_TX = "E7F6EC", "0B6B36"
C_ALT, C_BORDER = "FAFBFC", "E6E8EB"
_thin = Side(style="thin", color=C_BORDER)
BORDER = Border(left=_thin, right=_thin, top=_thin, bottom=_thin)

NEWCOL_HEADERS = ["Profile Table", "Target Type", "New Column", "Data Type", "Is CID",
                  "Status", "Used In", "File Path", "YAML Key", "Masked", "Exposure",
                  "Why", "Logic (how the column is used)", "Action"]
NEWCOL_WIDTHS = [46, 24, 30, 18, 8, 13, 26, 58, 30, 9, 22, 44, 84, 56]


CIDTBL_HEADERS = ["Table", "Why listed", "Column", "Data Type", "Present in production?",
                  "Masked by the anonymise function?", "Action"]
CIDTBL_WIDTHS = [46, 34, 32, 20, 24, 34, 60]


def cid_table_rows(res):
    """Columns of the CID tables that a person has to look at.

    Two populations, in one sheet because the question is the same for both
    -- is this column client-identifying, and is it masked?

      * every column of a table newly recorded as CID, since nobody has
        reviewed any of them yet;
      * columns that exist in the dummy schema but not in production, for
        tables already recorded as CID.
    """
    masked = set()
    per_table = {}
    if res.anon is not None:
        masked = {c.lower() for c in res.anon.columns}
        per_table = {t: {c.lower() for c in cs}
                     for t, cs in (res.anon.per_table_columns or {}).items()}

    rows = []
    for tbl in sorted(res.new_cid_table_columns):
        cols = res.new_cid_table_columns[tbl]
        prod = res.cid_table_new_columns.get(tbl, {})
        for col in sorted(cols):
            is_masked = col in per_table.get(tbl, set()) or col in masked
            rows.append([tbl, "newly recorded as a CID table", col, cols[col] or "",
                         "no" if col in prod else "yes",
                         "yes" if is_masked else "no",
                         "Already hashed by the anonymise function; confirm that is enough."
                         if is_masked else
                         "NOT hashed. Decide whether this column is client-identifying."])
    for tbl in sorted(res.cid_table_new_columns):
        if tbl in res.new_cid_table_columns:
            continue                    # already listed in full above
        for col, dtype in sorted(res.cid_table_new_columns[tbl].items()):
            is_masked = col in per_table.get(tbl, set()) or col in masked
            rows.append([tbl, "added since production", col, dtype or "", "no",
                         "yes" if is_masked else "no",
                         "Already hashed by the anonymise function; confirm that is enough."
                         if is_masked else
                         "NOT hashed. Decide whether this column is client-identifying."])
    return rows


def metadata_rows(res):
    """What changed in the two CID metadata tables on this run."""
    if res.metadata is None:
        return []
    out = []
    for ch in res.metadata.changes:
        out.append([ch.kind, ch.name, ch.action, ch.previous or "(absent)", "Y",
                    "Taken from the anonymise function, which hashes it."])
    return out


METADATA_HEADERS = ["Kind", "Name", "Action", "Previous is_cid", "Now", "Source"]
METADATA_WIDTHS = [10, 44, 26, 18, 8, 62]


def new_column_rows(res):
    """One row per new column PER PLACE IT IS USED, with everything a
    reviewer needs to make the CID call without opening another sheet.

    Every new column already has at least one step-5 finding -- one per
    usage, or a single "not used" row -- so the detail is assembled from
    those rather than recomputed, which keeps this sheet and the findings
    sheets from ever disagreeing.
    """
    t2t = {v: k for k, v in res.profile_tables.items()}
    rows = []
    for f in res.findings:
        if f.step != "5":
            continue
        tbl = f.profile_table
        dtype = (res.new_column_types.get(tbl, {}) or {}).get(f.column, "")
        if f.file_path:
            where = ("input_data_config_dummy" if CONFIG_DIR in f.file_path
                     else ("sql_column_mapping" if MAPPING_DIR in f.file_path else "other"))
        else:
            where = "not used in the branch"
        if f.severity == "FLAG":
            status, action = "NEEDS FIX", "Mask this occurrence, or confirm it may be exposed."
        elif f.is_cid == "Y":
            status = "CID - ok here"
            action = "No change needed here; confirm every other use is also safe."
        else:
            status = "review"
            action = ("Decide whether this column is client-identifying. If it is, add it to "
                      "the CID metadata table and mask the uses below.")
        rows.append([tbl, t2t.get(tbl, f.target_type), f.column, dtype, f.is_cid,
                     status, where, f.file_path, f.yaml_key, f.masked, f.exposure,
                     f.context, f.logic, action])
    # newest information first is not meaningful here; group by table then column
    # Metadata changes belong here too: they are new CID facts discovered on
    # this run, and a reader looking for "what changed" should find them all
    # in one place.
    for ch in (res.metadata.changes if res.metadata else []):
        rows.append(["" if ch.kind == "column" else ch.name, "", 
                     ch.name if ch.kind == "column" else "", "", "Y",
                     "METADATA", "cid_%s_metadata_manual_refresh" % (
                         "columns" if ch.kind == "column" else "tables"),
                     "", "", "n/a", "n/a",
                     "%s %s" % (ch.kind, ch.action), "",
                     "Recorded from the anonymise function; confirm nothing downstream "
                     "relied on the old value."])
    rows.sort(key=lambda x: (x[0], x[2], x[7]))
    return rows


CONFIG_DIR = "input_data_config_dummy"
MAPPING_DIR = "sql_column_mapping"

FINDING_HEADERS = ["Step", "Severity", "Rule", "Column", "Is CID", "Masked", "Exposure",
                   "Why", "Target Type", "Profile Table", "File Path", "YAML Key",
                   "Logic (how the column is used)", "Note"]
FINDING_WIDTHS = [7, 11, 54, 28, 8, 9, 22, 46, 24, 44, 60, 30, 88, 60]


def _sheet(ws, headers, widths):
    for i, (h, w) in enumerate(zip(headers, widths), start=1):
        c = ws.cell(row=1, column=i, value=h)
        c.font = Font(name="Calibri", size=10, bold=True, color=C_HEAD_TX)
        c.fill = PatternFill("solid", start_color=C_HEAD, end_color=C_HEAD)
        c.alignment = Alignment(vertical="center", horizontal="center", wrap_text=True)
        c.border = BORDER
        ws.column_dimensions[get_column_letter(i)].width = w


def write_xlsx(res, settings, output_dir: str) -> str:
    wb = Workbook()
    wb.remove(wb.active)

    # ---- Summary ----
    ws = wb.create_sheet("Summary")
    ws.column_dimensions["A"].width = 42
    ws.column_dimensions["B"].width = 96
    rows = [
        ("CID analysis", ""),
        ("Outcome", ("NEEDS REVIEW -- %s" % res.fail_reason) if res.failed
         else "PASSED -- nothing flagged and no new columns"),
        ("DAG", res.dag_id),
        ("Source analysed", res.branch),
        ("Schema compared", "%s  vs  %s (production)" % (res.compare_schema,
                                                         CID_METADATA_SCHEMA)),
        ("CID metadata source", "%s.cid_columns_metadata_manual_refresh (is_cid = 'Y')"
         % CID_METADATA_SCHEMA),
        ("CID columns in scope", res.cid_column_count),
        ("input_data_config_dummy files", res.files_config),
        ("sql_column_mapping files", res.files_mapping),
        ("New columns found", res.new_column_count),
        ("CID metadata changes", res.metadata_change_count),
        ("New columns in CID tables", res.cid_table_new_column_count),
        ("Keys excluded from masking check",
         ", ".join(res.excluded_keys) if res.excluded_keys else "(none)"),
        ("Generated", _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
    ]
    for i, (k, v) in enumerate(rows, start=1):
        a = ws.cell(row=i, column=1, value=k)
        b = ws.cell(row=i, column=2, value=v)
        a.font = Font(name="Calibri", size=11, bold=True,
                      color=C_HEAD if i == 1 else "333333")
        b.font = Font(name="Calibri", size=11)
        if k == "Outcome":
            b.font = Font(name="Calibri", size=11, bold=True,
                          color=C_FLAG_TX if res.failed else C_OK_TX)
            b.fill = PatternFill("solid",
                                 start_color=C_FLAG_BG if res.failed else C_OK_BG,
                                 end_color=C_FLAG_BG if res.failed else C_OK_BG)

    r = len(rows) + 2
    ws.cell(row=r, column=1, value="Flagged by rule").font = Font(bold=True, size=11)
    r += 1
    for rule, n in sorted(res.counts().items(), key=lambda kv: -kv[1]):
        ws.cell(row=r, column=1, value=rule).font = Font(size=10)
        ws.cell(row=r, column=2, value=n).font = Font(size=10, bold=True)
        r += 1
    if res.errors:
        r += 1
        ws.cell(row=r, column=1, value="Problems encountered").font = Font(bold=True, size=11)
        for e in res.errors:
            r += 1
            ws.cell(row=r, column=1, value=e).font = Font(size=10, color=C_FLAG_TX)

    # ---- Flagged / All findings ----
    for name, items in (("Flagged", res.flagged), ("All findings", res.findings)):
        w = wb.create_sheet(name)
        _sheet(w, FINDING_HEADERS, FINDING_WIDTHS)
        alt = PatternFill("solid", start_color=C_ALT, end_color=C_ALT)
        flag = PatternFill("solid", start_color=C_FLAG_BG, end_color=C_FLAG_BG)
        for i, f in enumerate(items):
            vals = [f.step, f.severity, f.rule, f.column, f.is_cid, f.masked,
                    f.exposure, f.context, f.target_type, f.profile_table,
                    f.file_path, f.yaml_key, f.logic, f.note]
            for j, v in enumerate(vals, start=1):
                c = w.cell(row=i + 2, column=j, value=v)
                c.font = Font(name="Consolas" if j == 13 else "Calibri", size=9.5)
                c.alignment = Alignment(vertical="top", wrap_text=True)
                c.border = BORDER
                if f.severity == "FLAG":
                    c.fill = flag
                elif i % 2:
                    c.fill = alt
        if items:
            w.auto_filter.ref = "A1:%s%d" % (get_column_letter(len(FINDING_HEADERS)),
                                             len(items) + 1)

    # ---- New columns: every detail, in one place ----
    w = wb.create_sheet("New columns")
    _sheet(w, NEWCOL_HEADERS, NEWCOL_WIDTHS)
    alt = PatternFill("solid", start_color=C_ALT, end_color=C_ALT)
    flag = PatternFill("solid", start_color=C_FLAG_BG, end_color=C_FLAG_BG)
    rows = new_column_rows(res)
    for i, vals in enumerate(rows):
        for j, v in enumerate(vals, start=1):
            c = w.cell(row=i + 2, column=j, value=v)
            c.font = Font(name="Consolas" if j == 13 else "Calibri", size=9.5)
            c.alignment = Alignment(vertical="top", wrap_text=True)
            c.border = BORDER
            if vals[5] == "NEEDS FIX":
                c.fill = flag
            elif i % 2:
                c.fill = alt
    if rows:
        w.auto_filter.ref = "A1:%s%d" % (get_column_letter(len(NEWCOL_HEADERS)), len(rows) + 1)

    # ---- CID tables: columns needing a manual CID decision ----
    rows = cid_table_rows(res)
    if rows or res.metadata is not None:
        w = wb.create_sheet("CID tables")
        _sheet(w, CIDTBL_HEADERS, CIDTBL_WIDTHS)
        alt = PatternFill("solid", start_color=C_ALT, end_color=C_ALT)
        flag = PatternFill("solid", start_color=C_FLAG_BG, end_color=C_FLAG_BG)
        for i, vals in enumerate(rows):
            for j, v in enumerate(vals, start=1):
                c = w.cell(row=i + 2, column=j, value=v)
                c.font = Font(name="Calibri", size=9.5)
                c.alignment = Alignment(vertical="top", wrap_text=True)
                c.border = BORDER
                if vals[5] == "no":
                    c.fill = flag
                elif i % 2:
                    c.fill = alt
        if rows:
            w.auto_filter.ref = "A1:%s%d" % (get_column_letter(len(CIDTBL_HEADERS)),
                                             len(rows) + 1)

        mrows = metadata_rows(res)
        if mrows:
            start = len(rows) + 4
            w.cell(row=start - 1, column=1,
                   value="Changes written to the CID metadata tables").font = Font(
                bold=True, size=11, color=C_HEAD)
            for j, h in enumerate(METADATA_HEADERS, start=1):
                c = w.cell(row=start, column=j, value=h)
                c.font = Font(size=10, bold=True, color=C_HEAD_TX)
                c.fill = PatternFill("solid", start_color=C_HEAD, end_color=C_HEAD)
                c.border = BORDER
            for i, vals in enumerate(mrows):
                for j, v in enumerate(vals, start=1):
                    c = w.cell(row=start + 1 + i, column=j, value=v)
                    c.font = Font(name="Calibri", size=9.5)
                    c.alignment = Alignment(vertical="top", wrap_text=True)
                    c.border = BORDER

    os.makedirs(output_dir, exist_ok=True)
    path = os.path.join(output_dir, "cid_report_%s_%s_%s.xlsx" % (
        res.dag_id, _safe(res.branch), _dt.datetime.now().strftime("%Y%m%d_%H%M%S")))
    wb.save(path)
    log.info("XLSX written: %s", path)
    return path


def _safe(s: str) -> str:
    """A short, filename-safe label.

    A local run's "branch" is a full path, which would otherwise produce an
    unreadable file name, so only the last component is kept.
    """
    s = str(s or "")
    if s.startswith("local:"):
        s = "local_" + s.split("/")[-1].strip()
    out = "".join(c if (c.isalnum() or c in "._-") else "_" for c in s).strip("_")
    return out[:40] or "run"


def _e(s) -> str:
    return _html.escape("" if s is None else str(s))


_CSS = """
body{font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;margin:0;
padding:28px;background:#f6f7f9;color:#1a1a1a}
.wrap{max-width:1600px;margin:0 auto}
h1{font-size:22px;margin:0 0 4px}h2{font-size:15px;margin:26px 0 8px;color:#305496}
.sub{color:#666;font-size:12px;margin-bottom:16px}
.banner{padding:12px 16px;border-radius:8px;font-weight:600;margin:14px 0}
.fail{background:#fdecea;color:#9b1c1c;border:1px solid #f5c2bd}
.pass{background:#e7f6ec;color:#0b6b36;border:1px solid #b7e3c6}
.cards{display:flex;flex-wrap:wrap;gap:10px;margin:12px 0 4px}
.card{background:#fff;border:1px solid #e6e8eb;border-radius:8px;padding:10px 14px;min-width:150px}
.card .k{font-size:11px;color:#666}.card .v{font-size:19px;font-weight:600;margin-top:2px}
table{border-collapse:collapse;width:100%;background:#fff;font-size:12px}
th{background:#305496;color:#fff;text-align:left;padding:7px 9px;position:sticky;top:0}
td{padding:6px 9px;border-top:1px solid #eef0f2;vertical-align:top}
tr.flag td{background:#fdecea}
code,td.logic{font-family:Consolas,Monaco,monospace;font-size:11px;white-space:pre-wrap}
.scroll{max-height:620px;overflow:auto;border:1px solid #e6e8eb;border-radius:8px}
input.f{width:320px;padding:6px 9px;margin:6px 0;border:1px solid #d6d9dd;border-radius:6px}
.note{color:#666;font-size:12px;margin:4px 0 8px}
"""

_JS = """
document.querySelectorAll('input.f').forEach(function(inp){
  inp.addEventListener('keyup', function(){
    var q=this.value.toLowerCase(), t=document.getElementById(this.dataset.t);
    t.querySelectorAll('tbody tr').forEach(function(r){
      r.style.display = r.innerText.toLowerCase().indexOf(q)>-1 ? '' : 'none';});
  });});
"""


def _table(tid, headers, rows, row_class=None, logic_col=None):
    if not rows:
        return "<div class='note'>Nothing to show.</div>"
    h = "".join("<th>%s</th>" % _e(x) for x in headers)
    body = []
    for r in rows:
        cls = row_class(r) if row_class else ""
        tds = []
        for i, v in enumerate(r):
            c = " class='logic'" if (logic_col is not None and i == logic_col) else ""
            tds.append("<td%s>%s</td>" % (c, _e(v)))
        body.append("<tr class='%s'>%s</tr>" % (cls, "".join(tds)))
    return ("<input class='f' data-t='%s' placeholder='Filter...'>"
            "<div class='scroll'><table id='%s'><thead><tr>%s</tr></thead>"
            "<tbody>%s</tbody></table></div>" % (tid, tid, h, "".join(body)))


def write_html(res, settings, output_dir: str) -> str:
    banner = ("<div class='banner fail'>NEEDS REVIEW &mdash; %s. The task fails so a person "
              "looks at this before the change goes further.</div>" % _e(res.fail_reason)
              if res.failed else
              "<div class='banner pass'>PASSED &mdash; nothing flagged and no new "
              "columns.</div>")

    cards = "".join(
        "<div class='card'><div class='k'>%s</div><div class='v'>%s</div></div>" % (k, v)
        for k, v in [("Flagged", len(res.flagged)),
                     ("All findings", len(res.findings)),
                     ("CID columns", res.cid_column_count),
                     ("New columns", res.new_column_count),
                     ("Metadata changes", res.metadata_change_count),
                     ("New in CID tables", res.cid_table_new_column_count),
                     ("config files", res.files_config),
                     ("mapping files", res.files_mapping)])

    def frow(f):
        return [f.step, f.severity, f.rule, f.column, f.is_cid, f.masked, f.exposure,
                f.context, f.target_type, f.profile_table, f.file_path, f.yaml_key,
                f.logic, f.note]

    new_rows = new_column_rows(res)

    errs = ("<h2>Problems encountered</h2><div class='note'>%s</div>"
            % "<br>".join(_e(e) for e in res.errors)) if res.errors else ""

    body = """
<h1>CID analysis &mdash; %s</h1>
<div class='sub'>branch <b>%s</b> &nbsp;|&nbsp; schema <b>%s</b> vs production <b>%s</b>
 &nbsp;|&nbsp; generated %s</div>
%s
<div class='cards'>%s</div>
%s
<h2>Flagged (%d)</h2>
<div class='note'>Every one of these fails the task. A column is flagged only where its
<b>value reaches the output unmasked</b>. Using it to count, compare, filter, group, order or
partition is not a finding &mdash; the value is never revealed. The <b>Why</b> column says which
applies.</div>
%s
<h2>New columns in %s not present in %s</h2>
<div class='note'>Every new column, with its data type and <b>every place the branch uses it</b> &mdash;
file, key, expression, whether the value is exposed and whether it is masked. One row per usage, so
the CID decision can be made here without opening another sheet. <b>Any new column fails the task on
its own</b>: not because it is a violation, but because nobody has decided yet whether it is
client-identifying, and passing silently would let that decision be skipped.</div>
%s
<h2>CID tables &mdash; columns needing a decision</h2>
<div class='note'>Every column of a table <b>newly recorded as CID</b>, plus columns that exist in
the schema under test but <b>not in production</b> for tables already recorded. The question is the
same for both: is this column client-identifying, and is it hashed by the anonymise function?</div>
%s

<h2>Changes written to the CID metadata tables</h2>
<div class='note'>A table or column used by the anonymise function is client-identifying by
definition &mdash; it is being hashed. Anything missing was inserted, and anything recorded as
<code>N</code> was corrected to <code>Y</code>.</div>
%s

<h2>All findings (%d)</h2>
<div class='note'>Includes the acceptable, masked uses, so the report shows everything that was
examined rather than only the problems.</div>
%s
""" % (_e(res.dag_id), _e(res.branch), _e(res.compare_schema), _e(CID_METADATA_SCHEMA),
       _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), banner, cards, errs,
       len(res.flagged),
       _table("t1", FINDING_HEADERS, [frow(f) for f in res.flagged],
              lambda r: "flag", 12),
       _e(res.compare_schema), _e(CID_METADATA_SCHEMA),
       _table("t2", NEWCOL_HEADERS, new_rows,
              lambda x: "flag" if x[5] == "NEEDS FIX" else "", 12),
       _table("t4", CIDTBL_HEADERS, cid_table_rows(res),
              lambda x: "flag" if x[5] == "no" else ""),
       _table("t5", METADATA_HEADERS, metadata_rows(res)),
       len(res.findings),
       _table("t3", FINDING_HEADERS, [frow(f) for f in res.findings],
              lambda r: "flag" if r[1] == "FLAG" else "", 12))

    doc = ("<!DOCTYPE html><html><head><meta charset='utf-8'><title>CID analysis - %s</title>"
           "<style>%s</style></head><body><div class='wrap'>%s</div>"
           "<script>%s</script></body></html>" % (_e(res.branch), _CSS, body, _JS))

    os.makedirs(output_dir, exist_ok=True)
    path = os.path.join(output_dir, "cid_report_%s_%s_%s.html" % (
        res.dag_id, _safe(res.branch), _dt.datetime.now().strftime("%Y%m%d_%H%M%S")))
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(doc)
    log.info("HTML written: %s", path)
    return path
