# Change-impact test harness

Runs exactly what the merge-request pipeline runs.

| Input | Where it comes from |
|---|---|
| `FEATURE_BRANCH` | set in the first cell |
| GitLab token | `GITLAB_TOKEN` env → `[gitlab] token` in the ini → prompt. Needed here because there is no `CI_JOB_TOKEN` outside a pipeline |
| Model key | `ANTHROPIC_API_KEY` env → `[llm] api_key` in the ini → prompt |
| Email recipients | `[email] to` in `change_impact_config.ini` |

The same `change_impact_config.ini` the pipeline uses sits beside the notebook, so both read one
file. Requires `requests`, `openpyxl`, `anthropic`; `nlg_dag_agent` must be importable.
