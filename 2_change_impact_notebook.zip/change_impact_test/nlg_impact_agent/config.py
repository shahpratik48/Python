"""
nlg_impact_agent config -- reuses nlg_code_reader.config.Settings verbatim
(same LLM provider/keys, same GitLab URL/project paths/token, same
Greenplum connection settings) and adds only the fields specific to
branch-diff impact analysis: which branch to analyze, what to compare it
against, and where to write the impact report.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Optional

from nlg_code_reader.config import Settings as _BaseSettings


def _env(name: str, default: Optional[str] = None) -> Optional[str]:
    return os.getenv(name, default)


@dataclass
class ImpactSettings(_BaseSettings):
    # The branch a developer wants analyzed -- REQUIRED input, no default,
    # supplied by the caller (notebook cell / --branch / dag_run.conf).
    branch: Optional[str] = None

    # What to diff `branch` against. Defaults to the same branch
    # nlg_code_reader/nlg_query_tracer use as their baseline (develop).
    base_branch: str = field(default_factory=lambda: _env("IMPACT_BASE_BRANCH", "develop"))

    # Max number of tool-call round-trips the agent is allowed before it
    # must finalize -- a hard safety bound on the agentic loop, not a
    # tuning knob for accuracy (the agent decides when it's actually done;
    # this only prevents a runaway loop).
    max_agent_iterations: int = field(default_factory=lambda: int(_env("IMPACT_MAX_AGENT_ITERATIONS", "40")))

    # Output table for the impact report (Greenplum), analogous to
    # Project 1's nlg_hierarchy_table.
    nlg_change_impact_table: str = field(default_factory=lambda: _env("NLG_CHANGE_IMPACT_TABLE", "nlg_change_impact"))

    def __post_init__(self):
        if not self.branch:
            raise ValueError("ImpactSettings.branch is required -- which branch should the agent analyze?")

        # ONE key, whichever name it arrived under. The azure_openai provider
        # reads `azure_openai_api_key`; the notebook, the ini and the CI
        # pipeline all supply `llm_api_key`. Left separate, the key a person
        # typed was silently never sent -- the request went out with an empty
        # Bearer header and the endpoint answered 403 PermissionDenied while
        # the very same key worked from other code.
        if self.llm_api_key and not self.azure_openai_api_key:
            self.azure_openai_api_key = self.llm_api_key
        elif self.azure_openai_api_key and not self.llm_api_key:
            self.llm_api_key = self.azure_openai_api_key

        # Endpoint / deployment / api-version from change_impact_config.ini
        # when nothing more specific was given, so the whole LLM setup lives
        # in one editable file beside the code.
        try:
            import ci_config
            ep = ci_config.get("llm", "endpoint", "AZURE_OPENAI_ENDPOINT", "")
            if ep:
                self.azure_openai_endpoint = ep
            dep = ci_config.get("llm", "model", "AZURE_OPENAI_DEPLOYMENT", "")
            if dep:
                self.azure_openai_deployment = dep
                self.llm_model = dep
            ver = ci_config.get("llm", "api_version", "AZURE_OPENAI_API_VERSION", "")
            if ver:
                self.azure_openai_api_version = ver
            prov = ci_config.get("llm", "provider", "LLM_PROVIDER", "")
            if prov:
                self.llm_provider = prov
        except ImportError:
            pass
        if self.local_dags_dir or self.local_src_dir:
            raise ValueError(
                "nlg_impact_agent always analyzes a real GitLab branch/commit history -- "
                "local_dags_dir/local_src_dir are not supported here. Leave both unset."
            )
