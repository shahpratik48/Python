"""
Thin client around GitLab's repository `compare` API -- the actual source
of truth for "what changed between branch and base_branch": which files
were added, modified, deleted, or renamed, the commits in between, and a
unified diff per file. No local git clone involved.

https://docs.gitlab.com/ee/api/repositories.html#compare-branches-tags-or-commits
"""
from __future__ import annotations


def explain_empty_compare(settings, project_id: str, compare_url: str) -> None:
    """Logs what an empty compare actually means for this pair of branches."""
    import requests
    base = settings.gitlab_url.rstrip("/")
    h = auth_headers(settings.gitlab_token)

    def tip(ref):
        rr = requests.get(f"{base}/api/v4/projects/{project_id}/repository/branches/{ref}",
                          headers=h, timeout=60)
        if rr.status_code != 200:
            return None
        c = rr.json().get("commit") or {}
        return c.get("short_id"), (c.get("committed_date") or "")[:10], (c.get("title") or "")[:60]

    b, t = tip(settings.base_branch), tip(settings.branch)
    print(f"  compare returned 0 commits for {settings.base_branch} -> {settings.branch}")
    print(f"    {settings.base_branch:<24} tip {b}")
    print(f"    {settings.branch:<24} tip {t}")
    if t is None:
        print(f"    branch '{settings.branch}' was NOT found -- check the exact name (case, prefix).")
        return
    if b and t and b[0] == t[0]:
        print("    both tips are the same commit: the branch IS the base right now.")
        return
    rev = requests.get(compare_url, headers=h,
                       params={"from": settings.branch, "to": settings.base_branch}, timeout=120)
    behind = len((rev.json().get("commits") or [])) if rev.status_code == 200 else "?"
    print(f"    reverse compare: {settings.base_branch} has {behind} commit(s) the branch lacks.")
    print(f"    => every commit on '{settings.branch}' is already in '{settings.base_branch}' -- "
          f"it has been merged. Looking up what the branch contributed...")


def auth_headers(token: str) -> dict:
    """The right header for whichever token this is.

    A merge-request pipeline has no personal token and needs none: GitLab
    hands every job a CI_JOB_TOKEN that can read the project's own
    repository through the API. It is sent as JOB-TOKEN rather than
    PRIVATE-TOKEN. A value prefixed "job:" -- which is how the CI runner
    passes it through -- selects that header; anything else is treated as a
    personal token.
    """
    token = token or ""
    if token.startswith("job:"):
        return {"JOB-TOKEN": token[4:]}
    return {"PRIVATE-TOKEN": token}


import urllib.parse
from dataclasses import dataclass, field
from typing import List, Optional

from nlg_impact_agent.config import ImpactSettings


@dataclass
class FileDiff:
    old_path: str
    new_path: str
    diff: str                  # unified diff text (may be empty for pure renames with no content change)
    new_file: bool = False
    deleted_file: bool = False
    renamed_file: bool = False
    change_type: str = ""      # "added" | "deleted" | "renamed" | "modified" -- derived, see below

    def __post_init__(self):
        if self.new_file:
            self.change_type = "added"
        elif self.deleted_file:
            self.change_type = "deleted"
        elif self.renamed_file:
            self.change_type = "renamed"
        else:
            self.change_type = "modified"


@dataclass
class CommitInfo:
    id: str
    short_id: str
    title: str
    author_name: str
    created_at: str


@dataclass
class CompareResult:
    branch: str
    base_branch: str
    base_commit_sha: Optional[str]
    head_commit_sha: Optional[str]
    commits: List[CommitInfo] = field(default_factory=list)
    diffs: List[FileDiff] = field(default_factory=list)
    # The refs the hierarchies should be built from. Normally the two branch
    # names; for a branch that has already been merged, the merge request's
    # base and head SHAs -- so the analysis covers what the branch DID, not
    # the empty difference it has with the base today.
    after_ref: str = ""
    before_ref: str = ""
    source: str = "branch compare"      # how the changeset was obtained
    mr_iid: Optional[int] = None
    mr_url: str = ""

    def changed_python_files(self) -> List[FileDiff]:
        return [d for d in self.diffs if (d.new_path.endswith(".py") or d.old_path.endswith(".py"))]

    def changed_non_python_files(self) -> List[FileDiff]:
        return [d for d in self.diffs if not (d.new_path.endswith(".py") or d.old_path.endswith(".py"))]


def find_merged_mr(settings, project_id: str):
    """The merge request that brought this branch into the base, if any.

    GitLab keeps every MR's commits and its diff refs -- the base it was
    diffed against and the head that was merged -- for as long as the MR
    exists. That is the exact record of what the branch contributed, and it
    survives the branch being merged, or even deleted.
    """
    import requests
    base = settings.gitlab_url.rstrip("/")
    h = auth_headers(settings.gitlab_token)
    url = f"{base}/api/v4/projects/{project_id}/merge_requests"
    for state in ("merged", "opened", "all"):
        r = requests.get(url, headers=h, timeout=60,
                         params={"source_branch": settings.branch, "state": state,
                                 "order_by": "updated_at", "sort": "desc", "per_page": 5})
        if r.status_code != 200:
            continue
        mrs = [m for m in r.json() if m.get("target_branch") == settings.base_branch] or r.json()
        if mrs:
            return mrs[0]
    return None


def find_merge_commit(settings, project_id: str):
    """Fallback for a branch merged without an MR: the merge commit on the
    base whose message names the branch. Its two parents are the refs."""
    import requests
    base = settings.gitlab_url.rstrip("/")
    h = auth_headers(settings.gitlab_token)
    r = requests.get(f"{base}/api/v4/projects/{project_id}/repository/commits", headers=h,
                     params={"ref_name": settings.base_branch, "per_page": 100}, timeout=60)
    if r.status_code != 200:
        return None
    needle = settings.branch.lower()
    for c in r.json():
        parents = c.get("parent_ids") or []
        if len(parents) >= 2 and needle in (c.get("title", "") + c.get("message", "")).lower():
            return {"id": c["id"], "base": parents[0], "head": parents[1],
                    "title": c.get("title", "")}
    return None


def _project_id_lookup(requests_mod, base_url: str, project_path: str, token: str) -> int:
    encoded = urllib.parse.quote(project_path, safe="")
    url = f"{base_url.rstrip('/')}/api/v4/projects/{encoded}"
    r = requests_mod.get(url, headers=auth_headers(token), timeout=30)
    r.raise_for_status()
    return r.json()["id"]


def get_compare(settings: ImpactSettings) -> CompareResult:
    """Calls GitLab's `repository/compare` endpoint for
    from=base_branch, to=branch, restricted to nlg-dags' own subtree
    (dags/nlg/dags + dags/nlg/src). Deliberately does NOT pass straight=true:
    GitLab's default (straight=false) diffs from the MERGE BASE of
    base_branch and branch, not from base_branch's current tip -- so this
    isolates exactly the commits made ON the branch itself, regardless of
    how far base_branch has moved forward independently since the branch
    was created. (straight=true would diff the two tips directly, which
    would incorrectly pull in base_branch's own forward progress as if it
    were part of the branch's changes.)"""
    import requests
    project_id = _project_id_lookup(requests, settings.gitlab_url, settings.nlg_project_path, settings.gitlab_token)
    url = f"{settings.gitlab_url.rstrip('/')}/api/v4/projects/{project_id}/repository/compare"
    params = {"from": settings.base_branch, "to": settings.branch}
    r = requests.get(url, headers=auth_headers(settings.gitlab_token), params=params, timeout=120)
    after_ref, before_ref = settings.branch, settings.base_branch
    source, mr_iid, mr_url = "branch compare", None, ""
    if r.status_code == 200 and not (r.json().get("commits") or []):
        # Nothing on the branch that the base does not already have -- it
        # has been merged. The work still happened, and it is still what
        # needs analysing; the record of it is in the merge request.
        explain_empty_compare(settings, project_id, url)
        mr = find_merged_mr(settings, project_id)
        if mr and (mr.get("diff_refs") or {}).get("base_sha"):
            refs = mr["diff_refs"]
            before_ref, after_ref = refs["base_sha"], refs["head_sha"]
            source, mr_iid, mr_url = "merge request", mr.get("iid"), mr.get("web_url", "")
            print(f"  recovered from MR !{mr_iid} ({mr.get('state')}): '{mr.get('title','')[:60]}'")
            print(f"    analysing {before_ref[:8]} -> {after_ref[:8]}  (the MR's base and head)")
        else:
            mc = find_merge_commit(settings, project_id)
            if mc:
                before_ref, after_ref = mc["base"], mc["head"]
                source = "merge commit"
                print(f"  recovered from merge commit {mc['id'][:8]}: '{mc['title'][:60]}'")
                print(f"    analysing {before_ref[:8]} -> {after_ref[:8]}  (its two parents)")
            else:
                print("  no merge request or merge commit found for this branch; "
                      "there is genuinely nothing to analyse.")
        if source != "branch compare":
            # exact SHAs, so diff the two points directly rather than from a
            # merge base (which for a merged branch is the head itself)
            r = requests.get(url, headers=auth_headers(settings.gitlab_token), timeout=120,
                             params={"from": before_ref, "to": after_ref, "straight": "true"})
    r.raise_for_status()
    data = r.json()

    commits = [CommitInfo(id=c.get("id", ""), short_id=c.get("short_id", ""), title=c.get("title", ""),
                            author_name=c.get("author_name", ""), created_at=c.get("created_at", ""))
               for c in data.get("commits", [])]

    prefix_dags = settings.nlg_dags_subpath.strip("/") + "/"
    prefix_src = settings.nlg_src_subpath.strip("/") + "/"

    diffs = []
    for d in data.get("diffs", []):
        old_path, new_path = d.get("old_path", ""), d.get("new_path", "")
        # only files inside nlg-dags' own dags/src subtrees are in scope
        in_scope = any(p.startswith(prefix_dags) or p.startswith(prefix_src) for p in (old_path, new_path) if p)
        if not in_scope:
            continue
        diffs.append(FileDiff(
            old_path=_strip_known_prefix(old_path, prefix_dags, prefix_src),
            new_path=_strip_known_prefix(new_path, prefix_dags, prefix_src),
            diff=d.get("diff", ""),
            new_file=bool(d.get("new_file")), deleted_file=bool(d.get("deleted_file")),
            renamed_file=bool(d.get("renamed_file")),
        ))

    commit_block = data.get("commit") or {}
    return CompareResult(
        branch=settings.branch, base_branch=settings.base_branch,
        base_commit_sha=data.get("diff_refs", {}).get("base_sha") if isinstance(data.get("diff_refs"), dict) else None,
        head_commit_sha=commit_block.get("id"),
        commits=commits, diffs=diffs,
        after_ref=after_ref, before_ref=before_ref, source=source,
        mr_iid=mr_iid, mr_url=mr_url,
    )


def _strip_known_prefix(path: str, *prefixes: str) -> str:
    if not path:
        return path
    for p in prefixes:
        if path.startswith(p):
            return path[len(p):]
    return path
