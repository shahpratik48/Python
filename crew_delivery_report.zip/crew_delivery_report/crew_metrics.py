"""
The four delivery parameters, per month, for the whole crew.

    Issue Throughput        issues closed in the month
    Cycle Time (Days)       average elapsed BUSINESS days per closed issue
                            (weekends excluded)
    Merged MR per Author    merged MRs / distinct authors
    Lead Time (Hrs)         average elapsed hours per merged MR

Cycle Time start point, in priority order -- this is the crew's definition
and it is not the same as issue creation:

    1. the first time the issue moved to IN PROGRESS
    2. otherwise, the day an ITERATION was assigned to it -- the crew treats
       that as the issue being opened for delivery, because an item sitting
       in the backlog with no iteration has not been committed to yet
    3. otherwise, the creation date, recorded as a last resort so the issue
       still appears rather than vanishing from the report

Which of the three was used is carried on every issue row, because an
iteration-based figure reads differently from an in-progress one and a
reader should be able to see which they are looking at.

Elapsed time is measured in BUSINESS days: Saturdays and Sundays are
excluded entirely, so an issue opened Friday and closed Monday counts as
roughly one day rather than three. Public holidays are not accounted for.

Lead Time runs from the FIRST FILE CHECK-IN -- the earliest commit on the
merge request -- to the merge itself. Only merged MRs are considered at
all; opened, closed-without-merging and locked ones never enter the data.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Sequence, Tuple

from crew_settings import get_logger

log = get_logger("crew.metrics")

METRIC_DEFS = [
    ("throughput", "Issue Throughput", False),
    ("cycle_time", "Cycle Time (Days)", True),
    ("mr_per_author", "Merged MR per Author", False),
    ("lead_time", "Lead Time (Hrs)", True),
]
METRIC_KEYS = [m[0] for m in METRIC_DEFS]
LOWER_IS_BETTER = {a: low for a, _l, low in METRIC_DEFS}

FROM_IN_PROGRESS = "in_progress"
FROM_ITERATION = "iteration_assigned"
FROM_CREATED = "created"


# ------------------------------------------------------------------ time
def parse_ts(v: Optional[str]) -> Optional[datetime]:
    if not v:
        return None
    t = str(v).strip().replace("Z", "+00:00")
    try:
        dt = datetime.fromisoformat(t)
    except ValueError:
        for f in ("%Y-%m-%dT%H:%M:%S.%f%z", "%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%d"):
            try:
                dt = datetime.strptime(t, f)
                break
            except ValueError:
                continue
        else:
            return None
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt.astimezone(timezone.utc)


def elapsed_days(a: datetime, b: datetime) -> Optional[float]:
    """Fractional BUSINESS days between two instants, excluding Sat/Sun.

    Walks the interval a day at a time and counts only the portion falling
    on a weekday, so Friday afternoon to Monday morning is well under one
    business day rather than three. Whole weekends contribute nothing.
    """
    if not a or not b or b < a:
        return None
    total, cur, guard = 0.0, a, 0
    while cur < b and guard < 4000:
        nxt = (cur + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
        seg_end = min(nxt, b)
        if cur.weekday() < 5:                     # Mon=0 .. Fri=4
            total += (seg_end - cur).total_seconds() / 86400.0
        cur, guard = seg_end, guard + 1
    return round(total, 2)


def elapsed_hours(a: datetime, b: datetime) -> Optional[float]:
    if not a or not b or b < a:
        return None
    return round((b - a).total_seconds() / 3600.0, 2)


def month_key(dt: datetime) -> str:
    return dt.strftime("%Y-%m")


def month_range(start: str, end: str) -> List[str]:
    y, m = (int(x) for x in start.split("-"))
    ey, em = (int(x) for x in end.split("-"))
    out = []
    while (y, m) <= (ey, em):
        out.append("%04d-%02d" % (y, m))
        m += 1
        if m > 12:
            y, m = y + 1, 1
    return out


def month_label(mk: str) -> str:
    y, m = mk.split("-")
    return "%s %s" % (["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul",
                       "Aug", "Sep", "Oct", "Nov", "Dec"][int(m) - 1], y[2:])


def month_start(mk: str) -> datetime:
    return datetime.strptime(mk + "-01", "%Y-%m-%d").replace(tzinfo=timezone.utc)


# ------------------------------------------------------------------ rows
@dataclass
class IssueRow:
    project_path: str
    folders: str
    iid: int
    title: str
    author: str
    assignee: str
    month: str
    measured_from: str
    start_at: Optional[datetime]
    closed_at: Optional[datetime]
    cycle_days: Optional[float]
    flagged: bool
    iteration_name: str = ""
    iteration_start: str = ""
    iteration_end: str = ""
    epic_id: str = ""
    epic_name: str = ""
    web_url: str = ""


@dataclass
class MRRow:
    project_path: str
    folders: str
    iid: int
    title: str
    author: str
    month: str
    first_commit_at: Optional[datetime]
    merged_at: Optional[datetime]
    lead_hours: Optional[float]
    flagged: bool
    web_url: str = ""


@dataclass
class MonthStats:
    month: str
    throughput: int = 0
    state_counts: Dict[str, int] = field(default_factory=dict)   # opened/merged/closed/locked
    cycle_time: Optional[float] = None
    mr_count: int = 0
    author_count: int = 0
    mr_per_author: Optional[float] = None
    lead_time: Optional[float] = None
    issues_flagged: int = 0
    mrs_flagged: int = 0
    from_in_progress: int = 0
    from_iteration: int = 0
    from_created: int = 0

    @property
    def from_opened(self) -> int:
        """Issues whose clock started at the iteration assignment or, failing
        that, at creation -- both are "opened" in the crew's terms."""
        return self.from_iteration + self.from_created

    @property
    def not_measurable(self) -> int:
        return max(0, self.throughput - self.from_in_progress - self.from_opened)

    def value(self, k):
        return getattr(self, k)


# ------------------------------------------------------------------ helpers
def first_in_progress(events: List[dict], wanted: Sequence[str]) -> Optional[datetime]:
    """Earliest moment an 'in progress' style label was ADDED."""
    w = [x.lower() for x in wanted]
    stamps = []
    for ev in events or []:
        if str(ev.get("action", "")).lower() != "add":
            continue
        name = str((ev.get("label") or {}).get("name", "")).lower()
        if not name:
            continue
        tail = name.split("::")[-1].strip()
        if any(x == name or x == tail or x in name for x in w):
            ts = parse_ts(ev.get("created_at"))
            if ts:
                stamps.append(ts)
    return min(stamps) if stamps else None


def first_iteration_assigned(events: List[dict]) -> Optional[datetime]:
    """Earliest moment an iteration was ADDED to the issue."""
    stamps = []
    for ev in events or []:
        if str(ev.get("action", "")).lower() not in ("add", "added"):
            continue
        ts = parse_ts(ev.get("created_at"))
        if ts:
            stamps.append(ts)
    return min(stamps) if stamps else None


def _iteration_name(it: dict, lookup: Dict[int, dict]):
    """The name a board would show for this iteration, plus its dates.

    Priority: the iteration's own title, then its CADENCE name (which is what
    is normally displayed, since iteration titles are usually null), then a
    date range, and only as a last resort the bare id.
    """
    if not it:
        return "", "", ""
    ref = lookup.get(it.get("id")) or {}
    title = str(it.get("title") or ref.get("title") or "").strip()
    cadence = str(ref.get("cadence") or (it.get("iteration_cadence") or {}).get("title")
                  or "").strip()
    start = str(it.get("start_date") or ref.get("start") or "")
    due = str(it.get("due_date") or ref.get("due") or "")

    if title and cadence and title.lower() != cadence.lower():
        name = "%s - %s" % (cadence, title)
    else:
        name = title or cadence
    if not name:
        name = ("%s to %s" % (start, due)) if (start and due) else ("Iteration %s" % it.get("id"))
    return name, start, due


def _person(o, fallback="unknown") -> str:
    if not o:
        return fallback
    return str(o.get("name") or o.get("username") or fallback)


# ------------------------------------------------------------------ collect
def collect(client, settings, months: List[str], progress=None):
    """Scans every project under the crew's groups and builds one row per
    closed issue and per merged MR inside the reporting window.

    Runs in phases rather than item by item. The per-item context -- label
    history, iteration history, MR commits -- is one HTTP round trip each
    and is the entire cost of the job. Gathering the lists first and then
    issuing all the detail calls through a thread pool turns thousands of
    sequential waits into a handful of concurrent batches.
    """
    from crew_gitlab import folder_trail, parallel_map

    def say(msg):
        log.info(msg)
        if progress:
            progress(msg)

    workers = int(getattr(settings, "max_workers", 12))
    earliest = month_start(months[0]).isoformat()
    in_window = set(months)

    # Resolved once for the whole run so every issue can be given the name a
    # board actually shows, rather than a bare iteration id.
    try:
        iteration_lookup = client.group_iterations(settings.issue_group)
    except Exception as e:
        log.warning("Iteration lookup unavailable (%s).", e)
        iteration_lookup = {}

    # ============================ ISSUES ============================
    say("Scanning issue group '%s'..." % settings.issue_group)
    projects = client.discover_projects(settings.issue_group)
    say("  %d project(s); fetching closed issues with %d worker(s)..."
        % (len(projects), workers))

    def _issues_for(proj):
        try:
            return proj, client.closed_issues(proj["id"], earliest)
        except Exception as e:
            log.error("  issues failed for %s: %s", proj.get("path_with_namespace"), e)
            return proj, []

    pending = []          # (project, issue) still inside the window
    for res in parallel_map(_issues_for, projects, workers, progress, "projects"):
        if not res:
            continue
        proj, issues = res
        for iss in issues:
            closed = parse_ts(iss.get("closed_at"))
            if closed and month_key(closed) in in_window:
                pending.append((proj, iss, closed))
    say("  %d closed issue(s) in window; fetching label history..." % len(pending))

    # phase 2 -- label events for every issue, in parallel
    def _labels(item):
        proj, iss, _c = item
        try:
            return client.issue_label_events(proj["id"], iss.get("iid"))
        except Exception:
            return []

    label_sets = parallel_map(_labels, pending, workers, progress, "label history")

    # The start of the clock, resolved in strict priority order and recorded
    # as it is decided -- so the tier is known once rather than re-derived
    # later, and every row carries the basis it was actually measured on.
    #
    #   1. first IN PROGRESS transition
    #   2. else first ITERATION assignment
    #   3. else the issue CREATION date
    starts: List[Optional[datetime]] = []
    bases: List[str] = []
    for ev in label_sets:
        ip = first_in_progress(ev or [], settings.in_progress_labels)
        starts.append(ip)
        bases.append(FROM_IN_PROGRESS if ip else "")

    # phase 3 -- iteration history ONLY for the issues tier 1 could not resolve
    need_iter = [i for i, st in enumerate(starts) if st is None]
    if need_iter:
        say("  %d issue(s) have no in-progress transition; checking iteration history..."
            % len(need_iter))

        def _iters(i):
            proj, iss, _c = pending[i]
            try:
                return client.issue_iteration_events(proj["id"], iss.get("iid"))
            except Exception:
                return []

        for i, ev in zip(need_iter, parallel_map(_iters, need_iter, workers, progress,
                                                 "iteration history")):
            it_start = first_iteration_assigned(ev or [])
            if it_start is not None:
                starts[i] = it_start
                bases[i] = FROM_ITERATION

    issue_rows: List[IssueRow] = []
    n_created = 0
    for k, ((proj, iss, closed), _lab) in enumerate(zip(pending, label_sets)):
        start, measured = starts[k], bases[k]
        if start is None:                          # tier 3
            start = parse_ts(iss.get("created_at"))
            measured = FROM_CREATED if start else ""
            n_created += 1
        days = elapsed_days(start, closed) if start else None
        it = iss.get("iteration") or {}
        ep = iss.get("epic") or {}
        ppath = proj.get("path_with_namespace", "")
        it_name, it_start, it_due = _iteration_name(it, iteration_lookup)
        issue_rows.append(IssueRow(
            project_path=ppath, folders=folder_trail(ppath, settings.issue_group),
            iid=iss.get("iid"), title=str(iss.get("title", ""))[:300],
            author=_person(iss.get("author")), assignee=_person(iss.get("assignee"), "unassigned"),
            month=month_key(closed), measured_from=measured, start_at=start, closed_at=closed,
            cycle_days=days,
            flagged=bool(days is not None and days > settings.issue_sla_days),
            iteration_name=it_name, iteration_start=it_start, iteration_end=it_due,
            epic_id=str(ep.get("id") or ""), epic_name=str(ep.get("title") or ""),
            web_url=str(iss.get("web_url", ""))))
    from collections import Counter as _C
    mix = _C(r.measured_from for r in issue_rows)
    say("Collected %d closed issue(s)  [in-progress %d | iteration %d | created %d]"
        % (len(issue_rows), mix.get(FROM_IN_PROGRESS, 0), mix.get(FROM_ITERATION, 0),
           mix.get(FROM_CREATED, 0)))

    # ============================ MERGE REQUESTS ============================
    say("Scanning MR group '%s'..." % settings.mr_group)
    mr_projects = client.discover_projects(settings.mr_group)
    say("  %d project(s); fetching merged MRs with %d worker(s)..." % (len(mr_projects), workers))

    def _mrs_for(proj):
        try:
            # every state is listed so the breakdown table can show them;
            # only merged ones go on to cost a commit lookup or enter a metric
            return proj, client.merge_requests_all(proj["id"], earliest)
        except Exception as e:
            log.error("  merge requests failed for %s: %s", proj.get("path_with_namespace"), e)
            return proj, []

    pending_mr = []
    state_counts: Dict[str, Dict[str, int]] = {mm: {} for mm in months}
    for res in parallel_map(_mrs_for, mr_projects, workers, progress, "projects"):
        if not res:
            continue
        proj, mrs = res
        for mr in mrs:
            state = str(mr.get("state", "")).lower().strip() or "opened"
            merged = parse_ts(mr.get("merged_at"))
            # bucket by the timestamp that matches the state
            at = merged or parse_ts(mr.get("closed_at")) or parse_ts(mr.get("created_at"))
            if at and month_key(at) in in_window:
                state_counts[month_key(at)][state] = \
                    state_counts[month_key(at)].get(state, 0) + 1
            if state == "merged" and merged and month_key(merged) in in_window:
                pending_mr.append((proj, mr, merged))
    say("  %d merged MR(s) in window; fetching commit history..." % len(pending_mr))

    def _commits(item):
        proj, mr, _m = item
        try:
            return client.mr_commits(proj["id"], mr.get("iid"))
        except Exception:
            return []

    commit_sets = parallel_map(_commits, pending_mr, workers, progress, "commit history")

    mr_rows: List[MRRow] = []
    for (proj, mr, merged), commits in zip(pending_mr, commit_sets):
        stamps = [t for t in (parse_ts(c.get("committed_date") or c.get("created_at"))
                              for c in (commits or [])) if t]
        first = min(stamps) if stamps else None
        hours = elapsed_hours(first, merged) if first else None
        ppath = proj.get("path_with_namespace", "")
        mr_rows.append(MRRow(
            project_path=ppath, folders=folder_trail(ppath, settings.mr_group),
            iid=mr.get("iid"), title=str(mr.get("title", ""))[:300],
            author=_person(mr.get("author")), month=month_key(merged),
            first_commit_at=first, merged_at=merged, lead_hours=hours,
            flagged=bool(hours is not None and hours > settings.mr_sla_hours),
            web_url=str(mr.get("web_url", ""))))
    say("Collected %d merged MR(s)." % len(mr_rows))
    return issue_rows, mr_rows, state_counts


# ------------------------------------------------------------------ summarise
def monthly_stats(issue_rows: List[IssueRow], mr_rows: List[MRRow], months: List[str],
                  state_counts: Optional[Dict[str, Dict[str, int]]] = None
                  ) -> Dict[str, MonthStats]:
    state_counts = state_counts or {}
    stats = {m: MonthStats(month=m, state_counts=dict(state_counts.get(m, {})))
             for m in months}
    for m in months:
        iss = [i for i in issue_rows if i.month == m]
        mrs = [x for x in mr_rows if x.month == m]
        s = stats[m]
        s.throughput = len(iss)
        cyc = [i.cycle_days for i in iss if i.cycle_days is not None]
        s.cycle_time = round(sum(cyc) / len(cyc), 2) if cyc else None
        s.issues_flagged = sum(1 for i in iss if i.flagged)
        s.from_in_progress = sum(1 for i in iss if i.measured_from == FROM_IN_PROGRESS)
        s.from_iteration = sum(1 for i in iss if i.measured_from == FROM_ITERATION)
        s.from_created = sum(1 for i in iss if i.measured_from == FROM_CREATED)

        s.mr_count = len(mrs)
        authors = {x.author for x in mrs}
        s.author_count = len(authors)
        s.mr_per_author = round(len(mrs) / len(authors), 2) if authors else None
        lead = [x.lead_hours for x in mrs if x.lead_hours is not None]
        s.lead_time = round(sum(lead) / len(lead), 2) if lead else None
        s.mrs_flagged = sum(1 for x in mrs if x.flagged)
    return stats


# ------------------------------------------------------------------ gains
def gain(metric: str, value: Optional[float], base: Optional[float]) -> Optional[float]:
    """Percentage improvement vs baseline, sign-corrected per metric so that
    a positive number always means better."""
    if value is None or base in (None, 0):
        return None
    raw = (value - base) / abs(base) * 100.0
    return round(-raw if LOWER_IS_BETTER[metric] else raw, 2)


def ramp_at(offset: Optional[int], target_pct: float, target_months: int) -> Optional[float]:
    """Aspiration ramp: 0% at the baseline, linear to the target, then flat.
    None before the baseline -- the ambition starts at the reference point."""
    if offset is None or offset < 0 or target_months <= 0:
        return None
    return round(min(offset / float(target_months), 1.0) * target_pct, 2)


@dataclass
class Series:
    months: List[str]
    baseline_month: str
    baseline_index: Optional[int] = None
    actual: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    actual_prev: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    actual_curr: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    aspiration: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    baseline: Dict[str, Optional[float]] = field(default_factory=dict)
    shift_pct: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    progress_pct: Dict[str, Optional[float]] = field(default_factory=dict)
    gain_prev: List[Optional[float]] = field(default_factory=list)
    gain_curr: List[Optional[float]] = field(default_factory=list)
    gain_asp: List[Optional[float]] = field(default_factory=list)
    gain_actual: List[Optional[float]] = field(default_factory=list)
    overall_gain: Optional[float] = None


def _split(vals, bi):
    """One series drawn in two segments; the baseline point sits in both so
    the lines join rather than showing a break."""
    if bi is None:
        return list(vals), [None] * len(vals)
    return ([v if i <= bi else None for i, v in enumerate(vals)],
            [v if i >= bi else None for i, v in enumerate(vals)])


def _mean(vals):
    v = [x for x in vals if x is not None]
    return round(sum(v) / len(v), 2) if v else None


def build_series(stats: Dict[str, MonthStats], months: List[str], settings) -> Series:
    bm = settings.baseline_month
    ser = Series(months=list(months), baseline_month=bm)
    ser.baseline_index = months.index(bm) if bm in months else None
    bi = ser.baseline_index

    for k in METRIC_KEYS:
        vals = [stats[m].value(k) for m in months]
        vals = [float(v) if v is not None else None for v in vals]
        ser.actual[k] = vals
        base = vals[bi] if bi is not None else None
        ser.baseline[k] = base
        ser.actual_prev[k], ser.actual_curr[k] = _split(vals, bi)

        lower = LOWER_IS_BETTER[k]
        asp = []
        for i in range(len(months)):
            step = ramp_at(None if bi is None else i - bi,
                           settings.target_gain_pct, settings.target_months)
            if base is None or step is None:
                asp.append(None)
            else:
                f = (1 - step / 100.0) if lower else (1 + step / 100.0)
                asp.append(round(base * f, 2))
        ser.aspiration[k] = asp

        ser.shift_pct[k] = [gain(k, v, base) for v in vals]
        latest = next((v for v in reversed(vals) if v is not None), None)
        ser.progress_pct[k] = gain(k, latest, base)

    for i in range(len(months)):
        ser.gain_actual.append(_mean([ser.shift_pct[k][i] for k in METRIC_KEYS]))
        ser.gain_asp.append(ramp_at(None if bi is None else i - bi,
                                    settings.target_gain_pct, settings.target_months))
    ser.gain_prev, ser.gain_curr = _split(ser.gain_actual, bi)
    ser.overall_gain = _mean([ser.progress_pct[k] for k in METRIC_KEYS])

    log.info("Series built: baseline %s, overall gain %s%%", bm, ser.overall_gain)
    return ser
