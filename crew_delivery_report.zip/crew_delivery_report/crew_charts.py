"""
The crew dashboard figure, embedded into both the workbook and the web page.

One wide **Overall Productivity Gain** panel, then the four parameters in a
2x2 grid. Each panel carries three series:

    Actual (Previous)   before the baseline month   dotted, grey
    Actual (Current)    baseline month onward       solid, blue
    Aspiration          the target ramp             dashed, red

Layout rules that keep text from colliding:

* the progress figure lives INSIDE the panel title, not in a floating badge
  that would sit on top of the legend
* legends are drawn inside the axes with a solid background
* every point is labelled, actual above and aspiration below, so the two
  never collide where the lines cross
* generous y-margin so the topmost labels are not clipped
"""
from __future__ import annotations

import os
from typing import List, Optional

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator

from crew_metrics import LOWER_IS_BETTER, METRIC_DEFS, month_label
from crew_settings import get_logger

log = get_logger("crew.charts")

C_CURR, C_PREV, C_ASP = "#1f3f7a", "#8a94a6", "#b0392b"
C_GRID, C_GOOD, C_BAD, C_MUTED = "#e6e8eb", "#0b6b36", "#9b1c1c", "#666666"
PANEL_ORDER = ["mr_per_author", "throughput", "lead_time", "cycle_time"]
LABELS = dict((a, l) for a, l, _x in METRIC_DEFS)


def _fmt(v: float) -> str:
    a = abs(v)
    return ("%.0f" % v) if a >= 100 else ("%.1f" % v) if a >= 10 else ("%.2f" % v)


def _plot(ax, series, colour, style, label, width=2.0, marker=None):
    xs = [i for i, v in enumerate(series) if v is not None]
    ys = [v for v in series if v is not None]
    if not xs:
        return False
    ax.plot(xs, ys, style, color=colour, linewidth=width, label=label,
            marker=marker, markersize=3, solid_capstyle="round")
    return True


def _labels(ax, series, colour, above=True, size=6.2):
    dy = 7 if above else -11
    for i, v in enumerate(series):
        if v is None:
            continue
        ax.annotate(_fmt(v), (i, v), textcoords="offset points", xytext=(0, dy),
                    ha="center", fontsize=size, color=colour, fontweight="bold", zorder=6,
                    bbox=dict(boxstyle="round,pad=0.12", facecolor="white",
                              edgecolor="none", alpha=0.72))


def _style(ax, ticks, tick_labels):
    ax.grid(True, axis="y", color=C_GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_color(C_GRID)
    ax.set_xticks(ticks)
    ax.set_xticklabels(tick_labels, rotation=45, ha="right", fontsize=7)
    ax.tick_params(labelsize=7.5, colors="#555")
    ax.yaxis.set_major_locator(MaxNLocator(nbins=5))
    ax.margins(y=0.22)


def _title(ax, main, sub, pct):
    if pct is None:
        ax.set_title("%s\n%s" % (main, sub), fontsize=10.5, fontweight="bold", pad=10)
        return
    ax.set_title("%s   %+.2f%%\n%s" % (main, pct, sub), fontsize=10.5, fontweight="bold",
                 pad=10, color=(C_GOOD if pct >= 0 else C_BAD))


def _legend(ax):
    if ax.get_legend_handles_labels()[0]:
        ax.legend(loc="best", fontsize=7, frameon=True, framealpha=0.92,
                  edgecolor=C_GRID, borderpad=0.4)


def build_figure(ser, crew_name: str, figsize=(20.0, 13.0), show_values: bool = True):
    xl = [month_label(m) for m in ser.months]
    step = max(1, len(xl) // 11)
    ticks = [i for i in range(len(xl)) if i % step == 0 or i == len(xl) - 1]
    shown = [xl[i] for i in ticks]
    bi = ser.baseline_index

    fig = plt.figure(figsize=figsize, facecolor="white")
    gs = fig.add_gridspec(3, 2, height_ratios=[1.15, 1, 1], hspace=0.95, wspace=0.18,
                          left=0.06, right=0.98, top=0.855, bottom=0.085)

    ax0 = fig.add_subplot(gs[0, :])
    _plot(ax0, ser.gain_prev, C_PREV, ":", "Actual (Previous)", 2.0)
    _plot(ax0, ser.gain_curr, C_CURR, "-", "Actual (Current)", 2.4, "o")
    _plot(ax0, ser.gain_asp, C_ASP, "--", "Aspiration", 1.8)
    ax0.axhline(0, color="#c8ccd4", linewidth=1)
    if bi is not None:
        ax0.axvline(bi, color="#c8ccd4", linewidth=1, linestyle=":")
    _title(ax0, "Overall Productivity Gain", "% vs baseline", ser.overall_gain)
    ax0.set_ylabel("% vs baseline", fontsize=8.5)
    ax0.set_xlim(-0.5, len(xl) - 0.5)
    _style(ax0, ticks, shown)
    _legend(ax0)
    if show_values:
        _labels(ax0, ser.gain_prev, C_PREV, True)
        _labels(ax0, ser.gain_curr, C_CURR, True)
        _labels(ax0, ser.gain_asp, C_ASP, False)

    for (r, c), k in zip([(1, 0), (1, 1), (2, 0), (2, 1)], PANEL_ORDER):
        ax = fig.add_subplot(gs[r, c])
        drew = False
        drew |= _plot(ax, ser.actual_prev.get(k, []), C_PREV, ":", "Actual (Previous)", 1.8)
        drew |= _plot(ax, ser.actual_curr.get(k, []), C_CURR, "-", "Actual (Current)", 2.2)
        drew |= _plot(ax, ser.aspiration.get(k, []), C_ASP, "--", "Aspiration", 1.6)
        if bi is not None:
            ax.axvline(bi, color="#dfe3e8", linewidth=1, linestyle=":")
        _title(ax, LABELS[k], "lower is better" if LOWER_IS_BETTER[k] else "higher is better",
               ser.progress_pct.get(k))
        ax.set_xlim(-0.5, len(xl) - 0.5)
        _style(ax, ticks, shown)
        _legend(ax)
        if show_values:
            _labels(ax, ser.actual_prev.get(k, []), C_PREV, True)
            _labels(ax, ser.actual_curr.get(k, []), C_CURR, True)
            _labels(ax, ser.aspiration.get(k, []), C_ASP, False)
        if not drew:
            ax.text(0.5, 0.5, "No data", transform=ax.transAxes, ha="center",
                    va="center", fontsize=10, color="#999")

    fig.suptitle("Crew Delivery Dashboard  \u2014  %s" % crew_name,
                 fontsize=15, fontweight="bold", y=0.985)
    fig.text(0.06, 0.945, "baseline %s   |   %s to %s"
             % (month_label(ser.baseline_month), xl[0], xl[-1]),
             fontsize=9, color=C_MUTED)
    fig.text(0.06, 0.917,
             "Actual (Previous) = before the baseline    Actual (Current) = baseline onward    "
             "Aspiration = target ramp, starting on the actual at the baseline",
             fontsize=8, color=C_MUTED, style="italic")
    log.info("Figure built for %d month(s).", len(ser.months))
    return fig


def save_png(fig, output_dir: str, name: str = "crew_dashboard") -> str:
    os.makedirs(output_dir, exist_ok=True)
    path = os.path.join(output_dir, "%s.png" % name)
    fig.savefig(path, dpi=110, bbox_inches="tight", facecolor="white")
    log.info("Chart image: %s", path)
    return path
