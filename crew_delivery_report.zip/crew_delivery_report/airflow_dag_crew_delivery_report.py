"""
airflow_dag_crew_delivery_report.py
------------------------------
Crew-level delivery report: XLSX + HTML (each with the dashboard embedded),
plus a Greenplum load.

Three tasks, run in order:

    collect_and_report  ->  summarise

Collection, reporting and the database load happen in a single pass.
Splitting them across tasks meant collecting twice, which doubled the
slowest part of the job. Reports are written before the load, so a
Greenplum failure still leaves the XLSX and HTML on disk.

Secrets come from Airflow Variables:
    GENESIS_DDLC_IKG_GIT_SECRET   GitLab token
    GREENPLUM_PASSWORD            Greenplum password

Deploy alongside the crew_*.py modules in the SAME folder.
"""
from __future__ import annotations

import os
import sys
from datetime import datetime, timedelta

import pendulum
from airflow import DAG
from airflow.models import Variable
from airflow.operators.python import PythonOperator

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from crew_main import run_crew_report
from crew_settings import CrewSettings, get_logger, setup_logging

HERE = os.path.dirname(os.path.abspath(__file__))
EST = pendulum.timezone("America/New_York")


def _var(k, d=None):
    try:
        return Variable.get(k, default_var=d)
    except Exception:
        return d


def _settings(load_gp=True) -> CrewSettings:
    s = CrewSettings()
    s.output_dir = HERE
    s.crew_name = _var("CREW_CREW_NAME", s.crew_name)
    s.start_month = _var("CREW_START_MONTH", s.start_month)
    s.end_month = _var("CREW_END_MONTH", s.end_month)
    s.baseline_month = _var("CREW_BASELINE_MONTH", s.baseline_month)
    s.gp_schema = _var("CREW_GP_SCHEMA", s.gp_schema)
    s.max_workers = int(_var("CREW_MAX_WORKERS", str(s.max_workers)))
    s.load_to_greenplum = load_gp
    s.resolve_secrets(interactive=False)
    return s


def task_collect_and_report(**kwargs):
    """Collects, reports and loads in ONE pass.

    An earlier split ran the collection twice -- once for the reports and
    again for the database -- which doubled the most expensive part of the
    job for no benefit. The reports are written before the load inside
    run_crew_report(), so a Greenplum failure still leaves the XLSX and HTML
    on disk; the task then fails loudly rather than silently succeeding.
    """
    log_path = setup_logging("INFO", log_dir=HERE)
    log = get_logger("crew.dag.report")
    s = _settings(load_gp=True)
    res = run_crew_report(s, progress=print)

    ti = kwargs["ti"]
    ti.xcom_push(key="xlsx_path", value=res.xlsx_path)
    ti.xcom_push(key="html_path", value=res.html_path)
    ti.xcom_push(key="current_month", value=res.current_month)
    ti.xcom_push(key="issue_count", value=len(res.issues))
    ti.xcom_push(key="mr_count", value=len(res.mrs))
    ti.xcom_push(key="overall_gain", value=res.series.overall_gain)
    ti.xcom_push(key="months_fetched", value=res.months_fetched)
    ti.xcom_push(key="months_from_db", value=res.months_from_db)
    ti.xcom_push(key="greenplum", value=res.greenplum)
    ti.xcom_push(key="log_path", value=log_path)
    log.info("Reports: %s | %s", res.xlsx_path, res.html_path)


def task_summarise(**kwargs):
    ti = kwargs["ti"]
    gp = ti.xcom_pull(task_ids="collect_and_report", key="greenplum") or {}
    print("=" * 68)
    print("Crew report complete")
    print("  XLSX          :", ti.xcom_pull(task_ids="collect_and_report", key="xlsx_path"))
    print("  HTML          :", ti.xcom_pull(task_ids="collect_and_report", key="html_path"))
    print("  issues        :", ti.xcom_pull(task_ids="collect_and_report", key="issue_count"))
    print("  merged MRs    :", ti.xcom_pull(task_ids="collect_and_report", key="mr_count"))
    print("  overall gain  :", ti.xcom_pull(task_ids="collect_and_report", key="overall_gain"), "%")
    print("  months fetched:", ti.xcom_pull(task_ids="collect_and_report", key="months_fetched"))
    print("  months from DB:", len(ti.xcom_pull(task_ids="collect_and_report",
                                                key="months_from_db") or []))
    if gp:
        print("  schema        :", gp.get("schema"))
        print("  months loaded :", len(gp.get("months_loaded") or []))
        print("  months skipped:", len(gp.get("months_skipped") or []), "(already settled)")
        for t, n in (gp.get("tables") or {}).items():
            print("     %-32s %d row(s)" % (t, n))
    print("=" * 68)


default_args = {
    "owner": "STAAT-DS",
    "retries": 1,
    "retry_delay": timedelta(minutes=10),
    "email_on_failure": True,
}

with DAG(
    dag_id="crew_delivery_report",
    default_args=default_args,
    description="Crew-level issue and merge request metrics: XLSX + HTML with embedded "
                "dashboard, and a Greenplum load.",
    start_date=datetime(2026, 1, 1, tzinfo=EST),
    schedule_interval="0 19 * * 1-5",     # 19:00 EST, Monday-Friday
    catchup=False,
    max_active_runs=1,
    tags=["gitlab", "crew", "metrics", "greenplum"],
) as dag:

    t1 = PythonOperator(task_id="collect_and_report", python_callable=task_collect_and_report)
    t2 = PythonOperator(task_id="summarise", python_callable=task_summarise,
                        trigger_rule="all_done")

    t1 >> t2
