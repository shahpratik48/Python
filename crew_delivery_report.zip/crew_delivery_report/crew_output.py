"""
The two deliverables: a workbook and a web page, each carrying the SAME
content and the SAME embedded chart.

Both open with the monthly table -- every month from the start of the window
through the current one, with the **baseline row highlighted** and a
**shift-from-baseline** block covering baseline to current month. Then the
chart. Then the full detail: every closed issue and every merged MR in the
window, sorted newest first, flagged or not.

The chart is the identical PNG in both -- embedded as a drawing in the
workbook and base64-inlined in the page, so the HTML stays a single
self-contained file that survives being emailed.
"""
from __future__ import annotations

import base64
import datetime as _dt
import html as _html
import os
from typing import Dict, List, Optional

from openpyxl import Workbook
from openpyxl.drawing.image import Image as XLImage
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from crew_metrics import (FROM_CREATED, FROM_ITERATION, LOWER_IS_BETTER, METRIC_DEFS,
                        month_label)
from crew_settings import get_logger

log = get_logger("crew.output")

C_HEAD, C_HEAD_TX = "305496", "FFFFFF"
C_ALT, C_BASE_BG = "FAFBFC", "FFF3CD"      # baseline row highlight
C_FLAG_BG, C_FLAG_TX = "FDECEC", "9B1C1C"
C_OK_BG, C_OK_TX = "E6F5EC", "0B6B36"
C_BORDER = "E6E8EB"

F_TITLE = Font(name="Calibri", size=16, bold=True)
F_H2 = Font(name="Calibri", size=12, bold=True, color=C_HEAD)
F_SUB = Font(name="Calibri", size=9, italic=True, color="666666")
F_HEAD = Font(name="Calibri", size=10, bold=True, color=C_HEAD_TX)
F_BODY = Font(name="Calibri", size=10)
FILL_HEAD = PatternFill("solid", start_color=C_HEAD, end_color=C_HEAD)
FILL_ALT = PatternFill("solid", start_color=C_ALT, end_color=C_ALT)
FILL_BASE = PatternFill("solid", start_color=C_BASE_BG, end_color=C_BASE_BG)
FILL_FLAG = PatternFill("solid", start_color=C_FLAG_BG, end_color=C_FLAG_BG)
_thin = Side(style="thin", color=C_BORDER)
BORDER = Border(left=_thin, right=_thin, top=_thin, bottom=_thin)
WRAP = Alignment(vertical="top", wrap_text=True)


def _dt_str(d) -> str:
    return d.strftime("%Y-%m-%d %H:%M") if d else ""


def _num(v, nd=2):
    return round(float(v), nd) if v is not None else None


# ------------------------------------------------------------------ shared
MONTH_HEADERS = ["Month", "Issue Throughput (per pod)", "Issue Cycle Time (Days)",
                 "Merged MRs per Author", "Lead Time (Hrs.)", "Issues Flagged", "MRs Flagged"]
SHIFT_HEADERS = ["Month", "Issue Throughput (per pod)", "Issue Cycle Time (Days)",
                 "Merged MRs per Author", "Lead Time (Hrs.)", "Overall"]
ISSUE_MONTH_HEADERS = ["Month", "Closed", "From in progress", "From opened",
                       "Avg business days", "Flagged", "Not measurable"]
MR_STATE_HEADERS = ["Month", "opened", "merged", "closed", "locked", "Total"]
MR_ELAPSED_HEADERS = ["Month", "Merged", "Authors", "Avg hours", "Flagged", "Unknown"]
MR_STATES = ["opened", "merged", "closed", "locked"]
ISSUE_HEADERS = ["Closed At", "Month", "Issue IID", "Title", "Author", "Assignee",
                 "Measured From", "Start Date", "Cycle Time (Days)", "Flagged",
                 "Iteration", "Iteration Start", "Iteration End", "Epic ID", "Epic Name",
                 "Folders", "Project Path", "Link"]
MR_HEADERS = ["Merged At", "Month", "MR IID", "Title", "Author", "First Commit At",
              "Lead Time (Hrs)", "Flagged", "Folders", "Project Path", "Link"]


def months_desc(months, current_month):
    """Months up to and including the current one, NEWEST FIRST.

    Every table in the report reads top-down from the most recent month --
    that is what people look at first, and it keeps the workbook and the page
    consistent with each other.
    """
    return [m for m in months if m <= current_month][::-1]


def month_rows(stats, months, current_month):
    return [[m, stats[m].throughput, _num(stats[m].cycle_time), _num(stats[m].mr_per_author),
             _num(stats[m].lead_time), stats[m].issues_flagged, stats[m].mrs_flagged]
            for m in months_desc(months, current_month)]


def shift_rows(ser, months, baseline_month, current_month):
    """Shift from the baseline, baseline month through the current, newest first."""
    idx = {m: i for i, m in enumerate(months)}
    rows = []
    for m in months_desc(months, current_month):
        if m < baseline_month:
            continue
        i = idx[m]
        rows.append([m] + [_num(ser.shift_pct[k][i], 1) for k, _l, _x in METRIC_DEFS]
                    + [_num(ser.gain_actual[i], 1)])
    return rows


def issue_month_rows(stats, months, current_month):
    return [[m, stats[m].closed_count, stats[m].from_in_progress, stats[m].from_opened,
             _num(stats[m].cycle_time), stats[m].issues_flagged, stats[m].not_measurable]
            for m in months_desc(months, current_month)]


def mr_state_rows(stats, months, current_month):
    rows = []
    for m in months_desc(months, current_month):
        sc = stats[m].state_counts or {}
        cells = [sc.get(st, 0) for st in MR_STATES]
        rows.append([m] + cells + [sum(cells)])
    return rows


def mr_elapsed_rows(stats, months, current_month, mrs):
    unknown = {}
    for x in mrs:
        if x.lead_hours is None:
            unknown[x.month] = unknown.get(x.month, 0) + 1
    return [[m, stats[m].mr_count, stats[m].author_count, _num(stats[m].lead_time),
             stats[m].mrs_flagged, unknown.get(m, 0)]
            for m in months_desc(months, current_month)]


def mr_author_table(mrs, months, current_month):
    """Merged MRs per author per month, newest month first."""
    md = months_desc(months, current_month)
    authors = sorted({x.author for x in mrs})
    counts = {}
    for x in mrs:
        counts[(x.author, x.month)] = counts.get((x.author, x.month), 0) + 1
    rows = []
    for a in authors:
        vals = [counts.get((a, m), 0) for m in md]
        rows.append([a] + vals + [sum(vals)])
    totals = [sum(counts.get((a, m), 0) for a in authors) for m in md]
    rows.append(["All authors"] + totals + [sum(totals)])
    return ["Author"] + md + ["Total"], rows


def issue_rows(issues):
    rows = sorted(issues, key=lambda i: (i.closed_at or _dt.datetime.min.replace(
        tzinfo=_dt.timezone.utc)), reverse=True)
    return [[_dt_str(i.closed_at), i.month, i.iid, i.title, i.author, i.assignee,
             i.measured_from, _dt_str(i.start_at), _num(i.cycle_days),
             "Y" if i.flagged else "N", i.iteration_name, i.iteration_start, i.iteration_end,
             i.epic_id, i.epic_name, i.folders, i.project_path, i.web_url] for i in rows], rows


def mr_rows(mrs):
    rows = sorted(mrs, key=lambda m: (m.merged_at or _dt.datetime.min.replace(
        tzinfo=_dt.timezone.utc)), reverse=True)
    return [[_dt_str(m.merged_at), m.month, m.iid, m.title, m.author,
             _dt_str(m.first_commit_at), _num(m.lead_hours), "Y" if m.flagged else "N",
             m.folders, m.project_path, m.web_url] for m in rows], rows


# ------------------------------------------------------------------ XLSX
class _Sheet:
    def __init__(self, ws, widths=None):
        self.ws, self.row = ws, 1
        if widths:
            for i, w in enumerate(widths, start=1):
                ws.column_dimensions[get_column_letter(i)].width = w

    def title(self, text, font=F_TITLE):
        c = self.ws.cell(row=self.row, column=1, value=text)
        c.font = font
        self.row += 1

    def blank(self, n=1):
        self.row += n

    def table(self, headers, rows, highlight=None, flag_col=None, autofilter=False,
              pct_cols=None):
        """`pct_cols` are 0-based column indexes holding a percentage shift.

        Those cells are written as real percentages and coloured by direction
        -- green when better, red when worse -- so the table reads at a glance
        without anyone tracing which metrics invert.
        """
        first = self.row
        for i, h in enumerate(headers, start=1):
            c = self.ws.cell(row=self.row, column=i, value=h)
            c.font, c.fill, c.border = F_HEAD, FILL_HEAD, BORDER
            c.alignment = Alignment(vertical="center", horizontal="center", wrap_text=True)
        self.row += 1
        for ri, r in enumerate(rows):
            fill = None
            if highlight and highlight(r):
                fill = FILL_BASE
            elif flag_col is not None and str(r[flag_col]).upper() == "Y":
                fill = FILL_FLAG
            elif ri % 2:
                fill = FILL_ALT
            for i, v in enumerate(r, start=1):
                c = self.ws.cell(row=self.row, column=i, value=v)
                c.font, c.border, c.alignment = F_BODY, BORDER, WRAP
                if fill:
                    c.fill = fill
                if pct_cols and (i - 1) in pct_cols and isinstance(v, (int, float)):
                    good = v >= 0
                    c.value = float(v) / 100.0
                    c.number_format = "+0.0%;-0.0%"
                    c.font = Font(name="Calibri", size=10, bold=True,
                                  color=(C_OK_TX if good else C_FLAG_TX))
                    c.fill = PatternFill("solid",
                                         start_color=(C_OK_BG if good else C_FLAG_BG),
                                         end_color=(C_OK_BG if good else C_FLAG_BG))
                    c.alignment = Alignment(vertical="top", horizontal="right")
            self.row += 1
        if autofilter and rows:
            # A worksheet supports ONE autofilter, so this is set only on the
            # detail table of each sheet -- otherwise whichever table was
            # written last would quietly take it.
            self.ws.auto_filter.ref = "A%d:%s%d" % (first, get_column_letter(len(headers)),
                                                    self.row - 1)
        # Deliberately NO freeze_panes. Sheets here hold several stacked
        # tables, and freezing on each one leaves the last table's header row
        # frozen -- locking every row above it and making the sheet look as
        # though it will not scroll.
        self.row += 1


def write_xlsx(settings, ser, stats, months, issues, mrs, chart_png, current_month,
               output_dir) -> str:
    wb = Workbook()
    wb.remove(wb.active)

    # ---- Summary + chart ----
    sh = _Sheet(wb.create_sheet("Summary"), [16, 18, 20, 22, 18, 16, 14])
    sh.title("Crew Delivery Report  -  %s" % settings.crew_name)
    sh.title("%s to %s   |   baseline %s   |   generated %s"
             % (month_label(months[0]), month_label(current_month),
                month_label(settings.baseline_month),
                _dt.datetime.now().strftime("%Y-%m-%d %H:%M")), F_SUB)
    sh.blank()
    sh.title("Monthly parameters  (baseline months highlighted)", F_H2)
    sh.title("Issue Throughput is closed issues divided by %d pod(s). Baseline = mean of %s."
             % (settings.pod_count, ", ".join(ser.baseline_months)), F_SUB)
    sh.table(MONTH_HEADERS, month_rows(stats, months, current_month),
             highlight=lambda r: r[0] in set(ser.baseline_months))
    sh.title("Shift against baseline (mean of %s)" % ", ".join(ser.baseline_months), F_H2)
    sh.title("Positive is always better -- Cycle Time and Lead Time are lower-is-better, so their "
             "sign is already inverted. Green = better than baseline, red = worse.", F_SUB)
    sh.table(SHIFT_HEADERS, shift_rows(ser, months, settings.baseline_month, current_month),
             highlight=lambda r: r[0] in set(ser.baseline_months),
             pct_cols=[1, 2, 3, 4, 5])

    if chart_png and os.path.exists(chart_png):
        ws2 = wb.create_sheet("Dashboard")
        img = XLImage(chart_png)
        # scale to a sensible on-screen width without distorting the aspect
        scale = 1400.0 / float(img.width or 1400)
        img.width = int((img.width or 1400) * scale)
        img.height = int((img.height or 900) * scale)
        ws2.add_image(img, "A1")
        log.info("Chart embedded into the workbook.")

    # ---- Issues ----
    irows, _ = issue_rows(issues)
    sh3 = _Sheet(wb.create_sheet("Issues"),
                 [18, 10, 11, 46, 20, 20, 16, 18, 16, 9, 22, 14, 14, 10, 26, 34, 46, 44])
    sh3.title("Issues  -  %s" % settings.crew_name)
    sh3.blank()
    sh3.title("Per month", F_H2)
    sh3.title("\"Closed\" is the raw issue count; Issue Throughput on the Summary sheet is this "
              "divided by %d pod(s). \"From opened\" covers issues measured from the iteration "
              "assignment, or from creation where no iteration was ever assigned."
              % settings.pod_count, F_SUB)
    sh3.table(ISSUE_MONTH_HEADERS, issue_month_rows(stats, months, current_month),
              highlight=lambda r: r[0] in set(ser.baseline_months))
    sh3.title("All closed issues  (newest first, flagged or not)", F_H2)
    sh3.table(ISSUE_HEADERS, irows, flag_col=9, autofilter=True)

    # ---- Merge requests ----
    mrows, _ = mr_rows(mrs)
    sh4 = _Sheet(wb.create_sheet("MRs"), [18, 12, 12, 46, 20, 18, 16, 9, 30, 46, 44])
    sh4.title("Merge requests  -  %s" % settings.crew_name)
    sh4.blank()
    sh4.title("By state", F_H2)
    sh4.title("closed means closed WITHOUT merging. Counts elsewhere consider merged only -- an "
              "abandoned MR is not delivered work.", F_SUB)
    sh4.table(MR_STATE_HEADERS, mr_state_rows(stats, months, current_month),
              highlight=lambda r: r[0] in set(ser.baseline_months))
    sh4.title("Merged -- elapsed time", F_H2)
    sh4.table(MR_ELAPSED_HEADERS, mr_elapsed_rows(stats, months, current_month, mrs),
              highlight=lambda r: r[0] in set(ser.baseline_months))
    sh4.title("Merged per author", F_H2)
    ah, ar = mr_author_table(mrs, months, current_month)
    sh4.table(ah, ar)
    sh4.title("All merged merge requests  (newest first, flagged or not)", F_H2)
    sh4.table(MR_HEADERS, mrows, flag_col=7, autofilter=True)

    os.makedirs(output_dir, exist_ok=True)
    safe = "".join(c if (c.isalnum() or c in "._-") else "_" for c in settings.crew_name).strip("_")
    path = os.path.join(output_dir, "%s_crew_report_%s.xlsx"
                        % (safe, _dt.datetime.now().strftime("%Y%m%d_%H%M%S")))
    wb.save(path)
    log.info("XLSX written: %s", path)
    return path


# ------------------------------------------------------------------ HTML
_CSS = """
body{font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;margin:0;padding:24px;
background:#f6f7f9;color:#1a1a1a}
.wrap{max-width:1500px;margin:0 auto;background:#fff;padding:28px 32px;border-radius:10px;
box-shadow:0 1px 3px rgba(0,0,0,.08)}
h1{margin:0 0 4px;font-size:24px} h2{margin:30px 0 10px;font-size:18px;
border-bottom:2px solid #e6e8eb;padding-bottom:6px}
.sub{color:#666;font-size:13px;margin-bottom:16px}
table{border-collapse:collapse;width:100%;margin:8px 0;font-size:12.5px}
th{background:#305496;color:#fff;text-align:left;padding:8px 10px;font-weight:600;
cursor:pointer;white-space:nowrap;position:sticky;top:0}
td{border-bottom:1px solid #e6e8eb;padding:6px 9px;vertical-align:top}
tbody tr:nth-child(even) td{background:#fafbfc}
tbody tr.flag td{background:#fdecec}
tbody tr.baseline td{background:#fff3cd;font-weight:600}
.tbl{margin:10px 0 20px}
.bar{display:flex;gap:10px;align-items:center;margin-bottom:4px}
.filter{flex:0 0 300px;padding:6px 10px;border:1px solid #cfd4da;border-radius:6px;font-size:13px}
.count{font-size:12px;color:#666}
.scroll{max-height:520px;overflow:auto;border:1px solid #e6e8eb;border-radius:6px}
.cards{display:flex;flex-wrap:wrap;gap:12px;margin:14px 0}
.card{flex:1 1 190px;background:#f8f9fb;border:1px solid #e6e8eb;border-radius:8px;padding:12px 14px}
.card .k{font-size:11px;color:#666;text-transform:uppercase;letter-spacing:.4px}
.card .v{font-size:23px;font-weight:700;margin-top:3px}
.good{color:#0b6b36}.bad{color:#9b1c1c}
td.pos{background:#e6f5ec;color:#0b6b36;font-weight:700;text-align:right}
td.neg{background:#fdecec;color:#9b1c1c;font-weight:700;text-align:right}
.note{background:#f2f6ff;border-left:3px solid #305496;padding:9px 13px;margin:10px 0;
font-size:13px;color:#33415c}
img.chart{width:100%;border:1px solid #e6e8eb;border-radius:8px}
a{color:#305496}
.foot{margin-top:30px;padding-top:14px;border-top:1px solid #e6e8eb;color:#777;font-size:12px}
"""

_JS = """
(function(){
 function num(s){var t=String(s).replace(/,/g,'').trim().replace(/^[#!]/,'');
  var m=t.match(/^-?\\d+(\\.\\d+)?/); if(!m) return null;
  var rest=t.slice(m[0].length).trim(); if(rest&&/[\\d\\-\\/:]/.test(rest)) return null;
  return parseFloat(m[0]);}
 function blank(s){return s===''||s==='\\u2014'||s==='-';}
 document.querySelectorAll('table.data').forEach(function(tb){
  var heads=tb.tHead?tb.tHead.rows[0].cells:null; if(!heads) return;
  Array.prototype.forEach.call(heads,function(th,i){
   th.title='Click to sort';
   th.addEventListener('click',function(){
    var dir=th.dataset.dir==='asc'?'desc':'asc';
    Array.prototype.forEach.call(heads,function(o){o.dataset.dir='';});
    th.dataset.dir=dir;
    var body=tb.tBodies[0], rows=Array.prototype.slice.call(body.rows);
    rows.sort(function(a,b){
     var x=(a.cells[i]||{}).innerText||'', y=(b.cells[i]||{}).innerText||'';
     x=x.trim();y=y.trim();
     if(blank(x)&&blank(y))return 0; if(blank(x))return 1; if(blank(y))return -1;
     var nx=num(x),ny=num(y),r;
     if(nx!==null&&ny!==null)r=nx-ny; else r=x.localeCompare(y,undefined,{numeric:true});
     return dir==='asc'?r:-r;});
    rows.forEach(function(r){body.appendChild(r);});});});
  var box=tb.closest('.tbl').querySelector('.filter');
  var cnt=tb.closest('.tbl').querySelector('.count');
  if(cnt&&tb.tBodies[0])cnt.textContent=tb.tBodies[0].rows.length+' row(s)';
  if(box)box.addEventListener('input',function(){
   var t=box.value.toLowerCase(),n=0;
   Array.prototype.forEach.call(tb.tBodies[0].rows,function(r){
    var hit=!t||(r.innerText||'').toLowerCase().indexOf(t)>-1;
    r.style.display=hit?'':'none'; if(hit)n++;});
   if(cnt)cnt.textContent=t?n+' of '+tb.tBodies[0].rows.length+' row(s)':
    tb.tBodies[0].rows.length+' row(s)';});});
})();
"""


def _e(x):
    return _html.escape(str(x if x is not None else ""))


def _html_table(headers, rows, row_class=None, link_col=None, filter_hint="Filter rows...",
                scroll=True, pct_cols=None):
    head = "".join("<th>%s</th>" % _e(h) for h in headers)
    body = []
    for r in rows:
        cls = row_class(r) if row_class else ""
        cells = []
        for i, v in enumerate(r):
            if link_col is not None and i == link_col and v:
                cells.append('<td><a href="%s" target="_blank">open</a></td>' % _e(v))
            elif pct_cols and i in pct_cols and isinstance(v, (int, float)):
                cells.append('<td class="%s">%+.1f%%</td>' % ("pos" if v >= 0 else "neg", v))
            else:
                cells.append("<td>%s</td>" % _e(v))
        body.append('<tr class="%s">%s</tr>' % (cls, "".join(cells)))
    inner = ('<table class="data"><thead><tr>%s</tr></thead><tbody>%s</tbody></table>'
             % (head, "".join(body)))
    if scroll:
        inner = '<div class="scroll">%s</div>' % inner
    return ('<div class="tbl"><div class="bar">'
            '<input class="filter" type="text" placeholder="%s"><span class="count"></span>'
            "</div>%s</div>" % (_e(filter_hint), inner))


def write_html(settings, ser, stats, months, issues, mrs, chart_png, current_month,
               output_dir) -> str:
    gen = _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    chart_tag = ""
    if chart_png and os.path.exists(chart_png):
        with open(chart_png, "rb") as fh:
            b64 = base64.b64encode(fh.read()).decode("ascii")
        chart_tag = ('<img class="chart" alt="Crew dashboard" src="data:image/png;base64,%s">'
                     % b64)

    cards = []
    for k, label, lower in METRIC_DEFS:
        v = ser.progress_pct.get(k)
        cls = "good" if (v is not None and v >= 0) else "bad"
        cards.append('<div class="card"><div class="k">%s</div><div class="v %s">%s</div></div>'
                     % (_e(label), cls, "n/a" if v is None else "%+.2f%%" % v))
    og = ser.overall_gain
    cards.insert(0, '<div class="card"><div class="k">Overall Productivity Gain</div>'
                    '<div class="v %s">%s</div></div>'
                    % ("good" if (og is not None and og >= 0) else "bad",
                       "n/a" if og is None else "%+.2f%%" % og))

    irows, _ = issue_rows(issues)
    mrows, _ = mr_rows(mrs)

    body = """
<h1>Crew Delivery Report &mdash; %s</h1>
<div class="sub">%s to %s &nbsp;|&nbsp; baseline %s &nbsp;|&nbsp; generated %s</div>
<div class="cards">%s</div>

<h2>Monthly parameters</h2>
<div class="note">Newest month first, back to %s. The <b>baseline months are highlighted</b>.
<b>Issue Throughput is per pod</b> &mdash; closed issues divided by the number of pods in the crew.
Cycle Time and Lead Time are lower-is-better.</div>
%s

<h2>Shift against baseline (mean of %s)</h2>
<div class="note">Positive is always better &mdash; Cycle Time and Lead Time are lower-is-better, so
their sign is already inverted. <b>Green</b> = better than baseline, <b>red</b> = worse.
<b>Overall</b> is the plain mean of the four.</div>
%s

<h2>Dashboard</h2>
<div class="note"><b>Actual (Previous)</b> is before the baseline, <b>Actual (Current)</b> from the
baseline onward, and <b>Aspiration</b> starts exactly on the actual at the baseline and ramps to the
target.</div>
%s

<h2>Issues &mdash; per month</h2>
<div class="note"><b>Closed</b> is the raw issue count; <b>Issue Throughput</b> above is this divided
by the number of pods. "From opened" covers issues measured from the iteration assignment, or from
creation where no iteration was ever assigned.</div>
%s

<h2>Issues &mdash; all closed</h2>
<div class="note">Every closed issue in the window, newest first, flagged or not. Click a column to
sort; type to filter.</div>
%s

<h2>Merge requests &mdash; by state</h2>
<div class="note"><code>closed</code> means closed <b>without</b> merging. Counts elsewhere consider
merged only &mdash; an abandoned MR is not delivered work.</div>
%s

<h2>Merge requests &mdash; merged, elapsed time</h2>
%s

<h2>Merge requests &mdash; merged per author</h2>
%s

<h2>Merge requests &mdash; all merged</h2>
<div class="note">Every merged MR in the window, newest first.</div>
%s

<div class="foot">Cycle Time starts at the first <i>in progress</i> transition; where there is none
it starts when an <i>iteration was assigned</i>; failing both, at creation. The basis is recorded per
issue. Lead Time runs from the first file check-in on the merge request to the merge.</div>
""" % (_e(settings.crew_name), _e(month_label(months[0])), _e(month_label(current_month)),
       _e(month_label(settings.baseline_month)), _e(gen), "".join(cards),
       _e(month_label(months[0])),
       _html_table(MONTH_HEADERS, month_rows(stats, months, current_month),
                   row_class=lambda r: "baseline" if r[0] in set(ser.baseline_months) else "",
                   filter_hint="Filter months...", scroll=False),
       _e(", ".join(ser.baseline_months)),
       _html_table(SHIFT_HEADERS, shift_rows(ser, months, settings.baseline_month, current_month),
                   row_class=lambda r: "baseline" if r[0] in set(ser.baseline_months) else "",
                   filter_hint="Filter months...", scroll=False, pct_cols=[1, 2, 3, 4, 5]),
       chart_tag,
       _html_table(ISSUE_MONTH_HEADERS, issue_month_rows(stats, months, current_month),
                   row_class=lambda r: "baseline" if r[0] in set(ser.baseline_months) else "",
                   filter_hint="Filter months...", scroll=False),
       _html_table(ISSUE_HEADERS, irows,
                   row_class=lambda r: "flag" if str(r[9]).upper() == "Y" else "",
                   link_col=17, filter_hint="Filter issues..."),
       _html_table(MR_STATE_HEADERS, mr_state_rows(stats, months, current_month),
                   row_class=lambda r: "baseline" if r[0] in set(ser.baseline_months) else "",
                   filter_hint="Filter months...", scroll=False),
       _html_table(MR_ELAPSED_HEADERS, mr_elapsed_rows(stats, months, current_month, mrs),
                   row_class=lambda r: "baseline" if r[0] in set(ser.baseline_months) else "",
                   filter_hint="Filter months...", scroll=False),
       _html_table(*mr_author_table(mrs, months, current_month),
                   filter_hint="Filter authors...", scroll=False),
       _html_table(MR_HEADERS, mrows,
                   row_class=lambda r: "flag" if str(r[7]).upper() == "Y" else "",
                   link_col=10, filter_hint="Filter merge requests..."))

    doc = ("<!DOCTYPE html><html><head><meta charset='utf-8'><title>Crew Delivery Report - %s"
           "</title><style>%s</style></head><body><div class='wrap'>%s</div>"
           "<script>%s</script></body></html>"
           % (_e(settings.crew_name), _CSS, body, _JS))

    os.makedirs(output_dir, exist_ok=True)
    safe = "".join(c if (c.isalnum() or c in "._-") else "_" for c in settings.crew_name).strip("_")
    path = os.path.join(output_dir, "%s_crew_report_%s.html"
                        % (safe, _dt.datetime.now().strftime("%Y%m%d_%H%M%S")))
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(doc)
    log.info("HTML written: %s", path)
    return path
