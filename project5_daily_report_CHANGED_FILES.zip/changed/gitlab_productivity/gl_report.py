"""
HTML reports.

Self-contained -- inline CSS and inline JavaScript, no external assets or
CDNs -- so a report renders and stays interactive when opened straight from
disk or from an email attachment, including on a machine with no internet
access.

Every table is sortable (click a column header) and filterable (type in the
box above it). That is implemented in a few lines of vanilla JavaScript at
the bottom of the page rather than a library, for the same offline reason.

Months are presented newest first throughout, and both the issue and the
merge request listings are split into a separate table per month.
"""
from __future__ import annotations

import datetime as _dt
import html
import os
from typing import Dict, List, Optional

from gl_settings import get_logger

log = get_logger("gitlab.report")

# sort-key fallback for rows with no timestamp, so they land last in a desc sort
_EPOCH = _dt.datetime(1970, 1, 1, tzinfo=_dt.timezone.utc)

_CSS = """
body{font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;margin:0;padding:24px;
color:#1a1a1a;background:#f6f7f9;}
.wrap{max-width:1250px;margin:0 auto;background:#fff;padding:28px 32px;border-radius:10px;
box-shadow:0 1px 3px rgba(0,0,0,.08);}
h1{margin:0 0 4px;font-size:24px;} h2{margin:32px 0 10px;font-size:18px;
border-bottom:2px solid #e6e8eb;padding-bottom:6px;} h3{margin:22px 0 6px;font-size:15px;}
.sub{color:#666;font-size:13px;margin-bottom:18px;}
table{border-collapse:collapse;width:100%;margin:6px 0 4px;font-size:13px;}
th{background:#305496;color:#fff;text-align:left;padding:8px 10px;font-weight:600;
cursor:pointer;user-select:none;white-space:nowrap;position:relative;}
th:hover{background:#3b63ad;}
th .arrow{opacity:.45;font-size:10px;margin-left:5px;}
th.asc .arrow:after{content:"\\25B2";} th.desc .arrow:after{content:"\\25BC";}
th.asc .arrow,th.desc .arrow{opacity:1;}
td{border-bottom:1px solid #e6e8eb;padding:7px 10px;vertical-align:top;}
tbody tr:nth-child(even) td{background:#fafbfc;}
tbody tr.flag td{background:#fdecec;}
tbody tr:hover td{background:#eef3fb;}
.tbl{margin:10px 0 18px;}
.tbl-bar{display:flex;align-items:center;gap:10px;margin-bottom:2px;}
.tbl-filter{flex:0 0 300px;padding:6px 10px;border:1px solid #cfd4da;border-radius:6px;
font-size:13px;font-family:inherit;}
.tbl-filter:focus{outline:none;border-color:#305496;box-shadow:0 0 0 2px rgba(48,84,150,.15);}
.tbl-count{font-size:12px;color:#666;}
.badge{display:inline-block;padding:2px 9px;border-radius:11px;font-size:11px;font-weight:600;
white-space:nowrap;}
.b-flag{background:#fdecec;color:#9b1c1c;} .b-ok{background:#e6f5ec;color:#0b6b36;}
.b-unk{background:#fff6e0;color:#9a6700;}
.cards{display:flex;flex-wrap:wrap;gap:12px;margin:14px 0;}
.card{flex:1 1 190px;background:#f8f9fb;border:1px solid #e6e8eb;border-radius:8px;padding:12px 14px;}
.card .k{font-size:11px;color:#666;text-transform:uppercase;letter-spacing:.4px;}
.card .v{font-size:23px;font-weight:700;margin-top:3px;} .card.warn .v{color:#9b1c1c;}
.note{background:#f2f6ff;border-left:3px solid #305496;padding:9px 13px;margin:10px 0;
font-size:13px;color:#33415c;}
code{font-family:Consolas,Monaco,monospace;background:#f2f3f5;padding:1px 5px;border-radius:3px;
font-size:12px;}
.meta td{border:none;padding:3px 12px 3px 0;font-size:13px;}
.none{color:#0b6b36;font-size:14px;padding:8px 0;}
.foot{margin-top:32px;padding-top:14px;border-top:1px solid #e6e8eb;color:#777;font-size:12px;}
"""

# Vanilla JS -- no library, so the report stays interactive offline.
# Sorting reads each cell's text, so a cell like "1.33 ok" (value plus badge)
# still sorts numerically on 1.33. Blank and em-dash cells sort last in both
# directions, which keeps "not measurable" rows out of the way.
_JS = """
(function () {
  function cellText(row, i) {
    var c = row.cells[i];
    return c ? (c.innerText || c.textContent || "").trim() : "";
  }
  // Numeric only when the cell is genuinely a number, optionally followed by
  // a word-only status badge ("126.00 over SLA"). Anything with further
  // digits, dashes, slashes or colons after the leading number is a date,
  // month or timestamp ("2026-04", "2026-07-22 15:00") and must sort as
  // text -- otherwise every month in a year collapses to the same value.
  // A leading # or ! is stripped so issue and MR ids sort numerically.
  function numOf(s) {
    var t = String(s).replace(/,/g, "").trim().replace(/^[#!]/, "");
    var m = t.match(/^-?\\d+(\\.\\d+)?/);
    if (!m) return null;
    var rest = t.slice(m[0].length).trim();
    if (rest && /[\\d\\-\\/:]/.test(rest)) return null;
    return parseFloat(m[0]);
  }
  function isBlank(s) { return s === "" || s === "\\u2014" || s === "-"; }

  function sortTable(table, idx, dir) {
    var body = table.tBodies[0];
    if (!body) return;
    var rows = Array.prototype.slice.call(body.rows);
    rows.sort(function (a, b) {
      var x = cellText(a, idx), y = cellText(b, idx);
      if (isBlank(x) && isBlank(y)) return 0;
      if (isBlank(x)) return 1;
      if (isBlank(y)) return -1;
      var nx = numOf(x), ny = numOf(y), r;
      if (nx !== null && ny !== null) r = nx - ny;
      else r = x.localeCompare(y, undefined, { numeric: true, sensitivity: "base" });
      return dir === "asc" ? r : -r;
    });
    rows.forEach(function (r) { body.appendChild(r); });
  }

  function wire(table) {
    var heads = table.tHead ? table.tHead.rows[0].cells : null;
    if (!heads) return;
    Array.prototype.forEach.call(heads, function (th, i) {
      var a = document.createElement("span");
      a.className = "arrow";
      th.appendChild(a);
      th.title = "Click to sort";
      th.addEventListener("click", function () {
        var dir = th.classList.contains("asc") ? "desc" : "asc";
        Array.prototype.forEach.call(heads, function (o) {
          o.classList.remove("asc", "desc");
        });
        th.classList.add(dir);
        sortTable(table, i, dir);
      });
    });
  }

  function filterTable(table, term, counter) {
    var body = table.tBodies[0];
    if (!body) return;
    var t = term.toLowerCase(), shown = 0;
    Array.prototype.forEach.call(body.rows, function (row) {
      var hit = !t || (row.innerText || row.textContent || "").toLowerCase().indexOf(t) > -1;
      row.style.display = hit ? "" : "none";
      if (hit) shown++;
    });
    if (counter) {
      counter.textContent = t
        ? shown + " of " + body.rows.length + " row(s)"
        : body.rows.length + " row(s)";
    }
  }

  document.querySelectorAll("table.data").forEach(function (table) {
    wire(table);
    var box = table.parentNode.querySelector(".tbl-filter");
    var counter = table.parentNode.querySelector(".tbl-count");
    if (counter && table.tBodies[0]) {
      counter.textContent = table.tBodies[0].rows.length + " row(s)";
    }
    if (box) {
      box.addEventListener("input", function () {
        filterTable(table, box.value, counter);
      });
    }
  });
})();
"""


def _e(x) -> str:
    return html.escape(str(x if x is not None else ""))


def _fmt(dt) -> str:
    return dt.strftime("%Y-%m-%d %H:%M") if dt else "&mdash;"


def _count_badge(n: int, kind: str) -> str:
    """A count as a coloured badge when non-zero, plain "0" otherwise.

    A helper rather than inline markup: building this inside an f-string
    expression would need escaped quotes, and f-string expressions cannot
    contain backslashes before Python 3.12. This has to run on Python 3.8.
    """
    if not n:
        return "0"
    return '<span class="badge b-%s">%d</span>' % (kind, n)


def _link(url: str, text: str) -> str:
    if url:
        return '<a href="%s">%s</a>' % (_e(url), text)
    return text


def _action_badge(action: str) -> str:
    if action == "failed":
        kind = "b-flag"
    elif action in ("skipped_existing", "dry_run"):
        kind = "b-unk"
    else:
        kind = "b-ok"
    return '<span class="badge %s">%s</span>' % (kind, _e(action))


def _table(headers: List[str], rows_html: str, filter_hint: str = "Filter rows...") -> str:
    """A sortable, filterable table. Headers go in <thead> so the JS can wire
    them up without touching the body rows."""
    head = "".join("<th>%s</th>" % h for h in headers)
    return (
        '<div class="tbl"><div class="tbl-bar">'
        '<input class="tbl-filter" type="text" placeholder="%s">'
        '<span class="tbl-count"></span></div>'
        '<table class="data"><thead><tr>%s</tr></thead><tbody>%s</tbody></table></div>'
        % (_e(filter_hint), head, rows_html))


def _shell(title: str, body: str) -> str:
    return ("<!DOCTYPE html><html><head><meta charset='utf-8'><title>" + _e(title) +
            "</title><style>" + _CSS + "</style></head><body><div class='wrap'>" + body +
            "</div><script>" + _JS + "</script></body></html>")


def _card(label: str, value, warn: bool = False) -> str:
    return ('<div class="card%s"><div class="k">%s</div><div class="v">%s</div></div>'
            % (" warn" if warn else "", _e(label), _e(value)))


# ------------------------------------------------------------------ DAG 1
def build_metrics_report(settings, months, issue_metrics, issue_summaries,
                         mr_metrics, mr_summaries, log_path: str = "") -> str:
    from gl_metrics import BASIS_IN_PROGRESS, MR_STATES

    gen = _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    repos = list(settings.code_repos.keys())
    months_desc = list(reversed(list(months)))          # newest month first, everywhere

    tot_closed = sum(s.closed_count for s in issue_summaries.values())
    tot_iflag = sum(s.flagged_count for s in issue_summaries.values())
    tot_merged = sum(s.merged_count for s in mr_summaries.values())
    tot_mflag = sum(s.flagged_count for s in mr_summaries.values())

    cards = "".join([
        _card("Issues closed", tot_closed),
        _card("Issues over %g bd" % settings.issue_sla_business_days, tot_iflag, tot_iflag > 0),
        _card("Merge requests merged", tot_merged),
        _card("Merged over %g h" % settings.mr_sla_hours, tot_mflag, tot_mflag > 0),
    ])

    # ---------------- Task 1: monthly summary ----------------
    t1_parts = []
    for m in months_desc:
        s = issue_summaries[m]
        avg = "&mdash;" if s.avg_business_days is None else ("%.2f" % s.avg_business_days)
        t1_parts.append(
            "<tr><td><b>%s</b></td><td>%d</td><td>%d</td><td>%d</td><td>%s</td><td>%s</td>"
            "<td>%s</td></tr>"
            % (_e(m), s.closed_count, s.from_in_progress, s.from_opened, avg,
               _count_badge(s.flagged_count, "flag"), _count_badge(s.unmeasurable, "unk")))
    t1_summary = _table(["Month", "Closed", "From in progress", "From opened",
                         "Avg business days", "Flagged", "Not measurable"],
                        "".join(t1_parts), "Filter months...")

    # ---------------- Task 1: detail, one table per month ----------------
    def issue_rows(items):
        out = []
        for i in items:
            if i.elapsed_business_days is None:
                badge, val = '<span class="badge b-unk">not measurable</span>', "&mdash;"
            elif i.flagged:
                badge, val = '<span class="badge b-flag">over SLA</span>', "%.2f" % i.elapsed_business_days
            else:
                badge, val = '<span class="badge b-ok">ok</span>', "%.2f" % i.elapsed_business_days
            if i.basis == BASIS_IN_PROGRESS:
                basis, start_dt = '<span class="badge b-ok">in progress</span>', _fmt(i.in_progress_at)
            elif i.basis:
                basis, start_dt = '<span class="badge b-unk">opened</span>', _fmt(i.created_at)
            else:
                basis, start_dt = "&mdash;", "&mdash;"
            out.append(
                '<tr class="%s"><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td>'
                "<td>%s</td><td>%s %s</td><td><small>%s</small></td></tr>"
                % ("flag" if i.flagged else "", _link(i.web_url, "#%s" % i.iid), _e(i.title),
                   _e(i.author_name), basis, start_dt, _fmt(i.closed_at), val, badge, _e(i.note)))
        return "".join(out)

    issue_sections = []
    for m in months_desc:
        in_month = [x for x in issue_metrics if x.month == m]
        # Only SLA breaches are listed. Issues that met the SLA are counted in
        # the summary above but not itemised -- the detail is a problem list,
        # not a changelog, and including the compliant majority buries the
        # handful that need action.
        rows = sorted([x for x in in_month if x.flagged],
                      key=lambda x: (x.closed_at or _EPOCH), reverse=True)
        hidden = len(in_month) - len(rows)
        s = issue_summaries[m]
        issue_sections.append(
            "<h3>%s &mdash; %d issue(s) closed, %d over SLA</h3>"
            % (_e(m), s.closed_count, s.flagged_count))
        if rows:
            issue_sections.append(
                _table(["Issue", "Title", "Author", "Measured from", "Start", "Closed",
                        "Business days", "Note"], issue_rows(rows),
                       "Filter %s issues..." % m))
            if hidden:
                issue_sections.append(
                    '<div class="sub">%d further issue(s) closed this month within SLA '
                    "(not listed).</div>" % hidden)
        elif in_month:
            issue_sections.append(
                '<div class="none">All %d issue(s) closed this month met the SLA.</div>'
                % len(in_month))
        else:
            issue_sections.append('<div class="none">No issues closed in this month.</div>')
    t1_detail = "".join(issue_sections)

    # ---------------- Task 2: state breakdown ----------------
    st_parts = []
    for m in months_desc:
        s = mr_summaries[m]
        cells = "".join("<td>%d</td>" % s.state_counts.get(st, 0) for st in MR_STATES)
        st_parts.append("<tr><td><b>%s</b></td>%s<td><b>%d</b></td></tr>"
                        % (_e(m), cells, sum(s.state_counts.values())))
    totals = "".join("<td><b>%d</b></td>"
                     % sum(mr_summaries[m].state_counts.get(st, 0) for m in months)
                     for st in MR_STATES)
    grand = sum(sum(mr_summaries[m].state_counts.values()) for m in months)
    st_parts.append("<tr><td><b>All months</b></td>%s<td><b>%d</b></td></tr>" % (totals, grand))
    state_tbl = _table(["Month"] + list(MR_STATES) + ["Total"], "".join(st_parts),
                       "Filter months...")

    # ---------------- Task 2: merged counts per repository ----------------
    repo_parts = []
    for m in months_desc:
        s = mr_summaries[m]
        cells = "".join("<td>%d</td>" % s.per_repo.get(r, 0) for r in repos)
        repo_parts.append("<tr><td><b>%s</b></td>%s<td><b>%d</b></td></tr>"
                          % (_e(m), cells, s.merged_count))
    rtot = "".join("<td><b>%d</b></td>" % sum(mr_summaries[m].per_repo.get(r, 0) for m in months)
                   for r in repos)
    repo_parts.append("<tr><td><b>All months</b></td>%s<td><b>%d</b></td></tr>" % (rtot, tot_merged))
    repo_tbl = _table(["Month"] + repos + ["Total"], "".join(repo_parts), "Filter months...")

    # ---------------- Task 2: monthly elapsed summary ----------------
    t2_parts = []
    for m in months_desc:
        s = mr_summaries[m]
        avg = "&mdash;" if s.avg_hours is None else ("%.2f" % s.avg_hours)
        t2_parts.append("<tr><td><b>%s</b></td><td>%d</td><td>%d</td><td>%d</td><td>%s</td>"
                        "<td>%s</td><td>%s</td></tr>"
                        % (_e(m), s.merged_count, len(s.per_author), s.measured_count, avg,
                           _count_badge(s.flagged_count, "flag"),
                           _count_badge(s.unknown_count, "unk")))
    t2_summary = _table(["Month", "Merged", "Authors", "Measured", "Avg hours",
                         "Flagged", "Unknown"], "".join(t2_parts), "Filter months...")

    # ---------------- Task 2: merged per author ----------------
    authors = sorted({a for s in mr_summaries.values() for a in s.per_author})
    if authors:
        body_rows = ""
        for a in authors:
            row = [mr_summaries[m].per_author.get(a, 0) for m in months_desc]
            body_rows += ("<tr><td><b>%s</b></td>%s<td><b>%d</b></td></tr>"
                          % (_e(a), "".join("<td>%d</td>" % v for v in row), sum(row)))
        mt = "".join("<td><b>%d</b></td>" % mr_summaries[m].merged_count for m in months_desc)
        body_rows += "<tr><td><b>All authors</b></td>%s<td><b>%d</b></td></tr>" % (mt, tot_merged)
        author_tbl = _table(["Author"] + list(months_desc) + ["Total"], body_rows,
                            "Filter authors...")
    else:
        author_tbl = '<div class="none">No merged merge requests in this window.</div>'

    # ---------------- Task 2: detail, one table per month ----------------
    def mr_rows(items):
        out = []
        for m in items:
            if m.elapsed_hours is None:
                val = "&mdash;"
                badge = ('<span class="badge b-unk">n/a</span>' if m.state != "merged"
                         else '<span class="badge b-unk">unknown</span>')
            elif m.flagged:
                val, badge = "%.2f" % m.elapsed_hours, '<span class="badge b-flag">over SLA</span>'
            else:
                val, badge = "%.2f" % m.elapsed_hours, '<span class="badge b-ok">ok</span>'
            skind = {"merged": "b-ok", "closed": "b-flag", "locked": "b-unk"}.get(m.state, "b-unk")
            out.append(
                '<tr class="%s"><td>%s</td><td>%s</td><td>%s</td><td>%s</td>'
                '<td><span class="badge %s">%s</span></td><td>%s</td><td>%s</td>'
                "<td>%s %s</td><td><small>%s</small></td></tr>"
                % ("flag" if m.flagged else "", _e(m.repo), _link(m.web_url, "!%s" % m.iid),
                   _e(m.title), _e(m.author_name), skind, _e(m.state),
                   _fmt(m.first_touch_at), _fmt(m.merged_at or m.closed_at), val, badge,
                   _e(m.note)))
        return "".join(out)

    mr_sections = []
    for m in months_desc:
        in_month = [x for x in mr_metrics if x.month == m]
        # Same principle as the issue listing: only SLA breaches are itemised.
        rows = sorted([x for x in in_month if x.flagged],
                      key=lambda x: (x.merged_at or x.closed_at or _EPOCH), reverse=True)
        hidden = len(in_month) - len(rows)
        s = mr_summaries[m]
        counts = ", ".join("%s %d" % (st, s.state_counts.get(st, 0)) for st in MR_STATES)
        mr_sections.append("<h3>%s &mdash; %d merge request(s) (%s), %d over SLA</h3>"
                           % (_e(m), sum(s.state_counts.values()), _e(counts), s.flagged_count))
        if rows:
            mr_sections.append(
                _table(["Repo", "MR", "Title", "Author", "State", "First file touched",
                        "Merged / closed", "Hours", "Note"], mr_rows(rows),
                       "Filter %s merge requests..." % m))
            if hidden:
                mr_sections.append(
                    '<div class="sub">%d further merge request(s) this month either met the SLA or '
                    "have none (not merged) -- not listed.</div>" % hidden)
        elif in_month:
            mr_sections.append(
                '<div class="none">None of the %d merge request(s) this month breached the SLA.</div>'
                % len(in_month))
        else:
            mr_sections.append('<div class="none">No merge requests in this month.</div>')
    t2_detail = "".join(mr_sections)

    log_row = ("<tr><td><b>Log file</b></td><td><code>%s</code></td></tr>"
               % _e(os.path.basename(log_path))) if log_path else ""

    body = """
<h1>GitLab Productivity Report</h1>
<div class="sub">Issue throughput and merge request cycle time &mdash; newest month first.
The per-month listings show <b>SLA breaches only</b>; summary tables above them count everything.
Click any column header to sort; type in a filter box to narrow a table.</div>
<table class="meta">
<tr><td><b>Reporting months</b></td><td>%s (newest first; current month plus the previous %d)</td></tr>
<tr><td><b>Issue project</b></td><td><code>%s</code></td></tr>
<tr><td><b>Code repositories</b></td><td>%s</td></tr>
<tr><td><b>Generated</b></td><td>%s</td></tr>
%s
</table>
<div class="cards">%s</div>

<h2>Task 1 &mdash; Issues closed per month</h2>
<div class="note">Elapsed time is measured in <b>business days</b> (weekends excluded) and flagged over
%g. It runs from the <b>in progress</b> transition where one exists; where it does not, it falls back
to <b>opened &rarr; closed</b> so every issue still contributes a figure. An opened-based figure
usually reads higher, so the two columns below show how much of each month's average rests on the
fallback.</div>
%s
<h3>Issues by month</h3>
%s

<h2>Task 2 &mdash; Merge requests</h2>
<div class="note">Summed across %s. <b>Counts consider merged merge requests only</b> &mdash; an
abandoned MR is not delivered work. <b>Elapsed hours</b> run from the earliest commit on the MR (when a
file in it was first touched) until it was <b>merged</b>, and are flagged over %g hours; opened,
closed-without-merging and locked MRs have no elapsed time by definition.</div>

<h3>Merge requests by state</h3>
<div class="note"><code>closed</code> means closed <i>without</i> merging.</div>
%s

<h3>Merged merge requests per repository</h3>
%s

<h3>Merged merge requests &mdash; elapsed time</h3>
%s

<h3>Merged merge requests per author</h3>
%s

<h3>Merge requests by month</h3>
%s

<div class="foot">Business-day elapsed time excludes Saturdays and Sundays but does not account for
public holidays or working-hour boundaries. People are shown by GitLab display name. Tables sort on
click and filter as you type; sorting reads the visible cell text, so a value shown with a status
badge still sorts on its number.</div>"""
    body = body % (_e(", ".join(months_desc)), settings.months_back, _e(settings.project_path),
                   _e(", ".join(repos)), _e(gen), log_row, cards,
                   settings.issue_sla_business_days, t1_summary, t1_detail,
                   _e(", ".join(repos)), settings.mr_sla_hours,
                   state_tbl, repo_tbl, t2_summary, author_tbl, t2_detail)

    log.info("Metrics report built (%d issue rows, %d MR rows, newest month first).",
             len(issue_metrics), len(mr_metrics))
    return _shell("GitLab Productivity Report", body)


# ------------------------------------------------------------------ daily
def build_daily_report(settings, day, month, issues_closed_today, mrs_merged_today,
                       at_risk_issues, at_risk_mrs, issue_summary, mr_summary,
                       repos, log_path: str = "") -> str:
    """A single-day view: what breached today, and what will breach today if
    nothing is done. Summary tables cover the CURRENT MONTH only."""
    from gl_daily import STATUS_BREACHED
    from gl_metrics import BASIS_IN_PROGRESS, MR_STATES

    gen = _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    day_str = day.strftime("%A %d %B %Y")

    n_breach_i, n_breach_m = len(issues_closed_today), len(mrs_merged_today)
    n_risk_i, n_risk_m = len(at_risk_issues), len(at_risk_mrs)
    action_needed = n_risk_i + n_risk_m

    cards = "".join([
        _card("Issues closed today over SLA", n_breach_i, n_breach_i > 0),
        _card("MRs merged today over SLA", n_breach_m, n_breach_m > 0),
        _card("Open issues at risk", n_risk_i, n_risk_i > 0),
        _card("Open MRs at risk", n_risk_m, n_risk_m > 0),
    ])

    banner = ('<div class="note"><b>%d item(s) still need action today.</b> The at-risk tables below '
              "list work that is open now and will breach its SLA before the day ends unless it is "
              "closed or merged.</div>" % action_needed) if action_needed else \
             ('<div class="none"><b>Nothing is at risk right now</b> &mdash; no open issue or merge '
              "request will breach its SLA by the end of today.</div>")

    # ---- at-risk issues ----
    if at_risk_issues:
        rows = []
        for i in at_risk_issues:
            kind = "b-flag" if i.status == STATUS_BREACHED else "b-unk"
            basis = ('<span class="badge b-ok">in progress</span>' if i.basis == BASIS_IN_PROGRESS
                     else '<span class="badge b-unk">opened</span>')
            start = i.in_progress_at if i.basis == BASIS_IN_PROGRESS else i.created_at
            rows.append(
                '<tr class="%s"><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td>'
                '<td>%.2f</td><td>%.2f</td><td><span class="badge %s">%s</span></td></tr>'
                % ("flag" if i.status == STATUS_BREACHED else "",
                   _link(i.web_url, "#%s" % i.iid), _e(i.title), _e(i.author_name),
                   _e(i.assignee_name), basis, _fmt(start),
                   i.elapsed_now, i.elapsed_end_of_day, kind, _e(i.status)))
        risk_i_tbl = _table(["Issue", "Title", "Author", "Assignee", "Measured from", "Start",
                             "Business days now", "By end of today", "Status"],
                            "".join(rows), "Filter at-risk issues...")
    else:
        risk_i_tbl = ('<div class="none">No open issue will breach the %g-business-day SLA today.</div>'
                      % settings.issue_sla_business_days)

    # ---- at-risk MRs ----
    if at_risk_mrs:
        rows = []
        for m in at_risk_mrs:
            kind = "b-flag" if m.status == STATUS_BREACHED else "b-unk"
            rows.append(
                '<tr class="%s"><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td>'
                '<td>%.2f</td><td>%.2f</td><td><span class="badge %s">%s</span></td></tr>'
                % ("flag" if m.status == STATUS_BREACHED else "", _e(m.repo),
                   _link(m.web_url, "!%s" % m.iid), _e(m.title), _e(m.author_name),
                   _fmt(m.first_touch_at), m.elapsed_now, m.elapsed_end_of_day,
                   kind, _e(m.status)))
        risk_m_tbl = _table(["Repo", "MR", "Title", "Author", "First file touched",
                             "Hours now", "By end of today", "Status"],
                            "".join(rows), "Filter at-risk merge requests...")
    else:
        risk_m_tbl = ('<div class="none">No open merge request will breach the %g-hour SLA today.</div>'
                      % settings.mr_sla_hours)

    # ---- breached today: issues ----
    if issues_closed_today:
        rows = []
        for i in issues_closed_today:
            basis = ('<span class="badge b-ok">in progress</span>' if i.basis == BASIS_IN_PROGRESS
                     else '<span class="badge b-unk">opened</span>')
            start = i.in_progress_at if i.basis == BASIS_IN_PROGRESS else i.created_at
            rows.append(
                '<tr class="flag"><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td>'
                '<td>%s</td><td>%.2f <span class="badge b-flag">over SLA</span></td></tr>'
                % (_link(i.web_url, "#%s" % i.iid), _e(i.title), _e(i.author_name), basis,
                   _fmt(start), _fmt(i.closed_at), i.elapsed_business_days or 0))
        closed_tbl = _table(["Issue", "Title", "Author", "Measured from", "Start", "Closed",
                             "Business days"], "".join(rows), "Filter issues...")
    else:
        closed_tbl = '<div class="none">No issue closed today breached the SLA.</div>'

    # ---- breached today: MRs ----
    if mrs_merged_today:
        rows = []
        for m in mrs_merged_today:
            rows.append(
                '<tr class="flag"><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td>'
                '<td>%s</td><td>%.2f <span class="badge b-flag">over SLA</span></td></tr>'
                % (_e(m.repo), _link(m.web_url, "!%s" % m.iid), _e(m.title), _e(m.author_name),
                   _fmt(m.first_touch_at), _fmt(m.merged_at), m.elapsed_hours or 0))
        merged_tbl = _table(["Repo", "MR", "Title", "Author", "First file touched", "Merged",
                             "Hours"], "".join(rows), "Filter merge requests...")
    else:
        merged_tbl = '<div class="none">No merge request merged today breached the SLA.</div>'

    # ---- month-to-date stats (current month only) ----
    iavg = "&mdash;" if issue_summary.avg_business_days is None \
        else ("%.2f" % issue_summary.avg_business_days)
    issue_month_tbl = _table(
        ["Month", "Closed", "From in progress", "From opened", "Avg business days",
         "Flagged", "Not measurable"],
        "<tr><td><b>%s</b></td><td>%d</td><td>%d</td><td>%d</td><td>%s</td><td>%s</td>"
        "<td>%s</td></tr>"
        % (_e(month), issue_summary.closed_count, issue_summary.from_in_progress,
           issue_summary.from_opened, iavg, _count_badge(issue_summary.flagged_count, "flag"),
           _count_badge(issue_summary.unmeasurable, "unk")), "Filter...")

    state_cells = "".join("<td>%d</td>" % mr_summary.state_counts.get(st, 0) for st in MR_STATES)
    mr_state_tbl = _table(["Month"] + list(MR_STATES) + ["Total"],
                          "<tr><td><b>%s</b></td>%s<td><b>%d</b></td></tr>"
                          % (_e(month), state_cells, sum(mr_summary.state_counts.values())),
                          "Filter...")

    repo_cells = "".join("<td>%d</td>" % mr_summary.per_repo.get(r, 0) for r in repos)
    mr_repo_tbl = _table(["Month"] + list(repos) + ["Total merged"],
                         "<tr><td><b>%s</b></td>%s<td><b>%d</b></td></tr>"
                         % (_e(month), repo_cells, mr_summary.merged_count), "Filter...")

    mavg = "&mdash;" if mr_summary.avg_hours is None else ("%.2f" % mr_summary.avg_hours)
    mr_month_tbl = _table(["Month", "Merged", "Authors", "Measured", "Avg hours", "Flagged",
                           "Unknown"],
                          "<tr><td><b>%s</b></td><td>%d</td><td>%d</td><td>%d</td><td>%s</td>"
                          "<td>%s</td><td>%s</td></tr>"
                          % (_e(month), mr_summary.merged_count, len(mr_summary.per_author),
                             mr_summary.measured_count, mavg,
                             _count_badge(mr_summary.flagged_count, "flag"),
                             _count_badge(mr_summary.unknown_count, "unk")), "Filter...")

    if mr_summary.per_author:
        arows = "".join("<tr><td><b>%s</b></td><td>%d</td></tr>" % (_e(a), n)
                        for a, n in sorted(mr_summary.per_author.items(),
                                           key=lambda kv: -kv[1]))
        mr_author_tbl = _table(["Author", "Merged this month"], arows, "Filter authors...")
    else:
        mr_author_tbl = '<div class="none">No merge requests merged this month yet.</div>'

    log_row = ("<tr><td><b>Log file</b></td><td><code>%s</code></td></tr>"
               % _e(os.path.basename(log_path))) if log_path else ""

    body = """
<h1>GitLab Daily Report</h1>
<div class="sub">%s &mdash; what breached today, and what will breach today unless it is finished.
Click any column header to sort; type in a filter box to narrow a table.</div>
<table class="meta">
<tr><td><b>Report day</b></td><td>%s</td></tr>
<tr><td><b>Month to date</b></td><td>%s</td></tr>
<tr><td><b>Issue project</b></td><td><code>%s</code></td></tr>
<tr><td><b>Code repositories</b></td><td>%s</td></tr>
<tr><td><b>Generated</b></td><td>%s</td></tr>
%s
</table>
<div class="cards">%s</div>
%s

<h2>Needs action &mdash; open and at risk today</h2>
<div class="note"><b>%s</b> means the item is already past its SLA and still open.
<b>%s</b> means it is inside the SLA now but crosses it before the day ends, so today is the last
chance to finish it cleanly.</div>
<h3>Open issues that will breach the %g-business-day SLA today</h3>
%s
<h3>Open merge requests that will breach the %g-hour SLA today</h3>
%s

<h2>Breached today</h2>
<div class="note">Only items that finished <b>today</b> and <b>exceeded</b> their SLA. Work completed
today within SLA is counted in the month-to-date tables below but not listed here.</div>
<h3>Issues closed today over SLA</h3>
%s
<h3>Merge requests merged today over SLA</h3>
%s

<h2>Month to date &mdash; %s</h2>
<div class="note">These cover the current month only, not the rolling window used in the monthly
report.</div>
<h3>Issues</h3>
%s
<h3>Merge requests by state</h3>
%s
<h3>Merged merge requests per repository</h3>
%s
<h3>Merged merge requests &mdash; elapsed time</h3>
%s
<h3>Merged merge requests per author</h3>
%s

<div class="foot">Business-day elapsed time excludes Saturdays and Sundays but not public holidays.
"By end of today" projects the elapsed time forward to 23:59 UTC on the report day, which is what
makes an item at risk. People are shown by GitLab display name.</div>"""
    body = body % (
        _e(day_str), _e(day.strftime("%Y-%m-%d")), _e(month), _e(settings.project_path),
        _e(", ".join(repos)), _e(gen), log_row, cards, banner,
        _e(STATUS_BREACHED), _e("at risk today"),
        settings.issue_sla_business_days, risk_i_tbl,
        settings.mr_sla_hours, risk_m_tbl,
        closed_tbl, merged_tbl, _e(month),
        issue_month_tbl, mr_state_tbl, mr_repo_tbl, mr_month_tbl, mr_author_tbl)

    log.info("Daily report built (%d closed-today breaches, %d merged-today breaches, "
             "%d at-risk issues, %d at-risk MRs).", n_breach_i, n_breach_m, n_risk_i, n_risk_m)
    return _shell("GitLab Daily Report %s" % day.strftime("%Y-%m-%d"), body)


# ------------------------------------------------------------ DAG 2 / DAG 3
def build_ticket_report(settings, result, mode: str, log_path: str = "") -> str:
    gen = _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    verb = "created" if mode == "create" else "closed"
    primary = result.created if mode == "create" else result.closed

    cards = "".join([
        _card("Tickets %s" % verb, primary),
        _card("Skipped (already existed)", result.skipped) if mode == "create" else "",
        _card("Failed", result.failed, result.failed > 0),
    ])

    row_parts = []
    for a in result.actions:
        issue_cell = _link(a.web_url, "#%s" % a.issue_iid) if a.issue_iid else "&mdash;"
        row_parts.append(
            '<tr class="%s"><td>%s</td><td>%s</td><td>%s</td><td><small>%s</small></td></tr>'
            % ("flag" if a.action == "failed" else "", _e(a.title),
               _action_badge(a.action), issue_cell, _e(a.detail)))
    actions_tbl = (_table(["Title", "Action", "Issue", "Detail"], "".join(row_parts),
                          "Filter tickets...")
                   if result.actions else '<div class="none">No tickets matched -- nothing to do.</div>')

    dry = ('<div class="note"><b>DRY RUN</b> &mdash; nothing was actually created or closed. '
           "Every action listed below is what <i>would</i> have happened.</div>"
           if result.dry_run else "")

    log_row = ("<tr><td><b>Log file</b></td><td><code>%s</code></td></tr>"
               % _e(os.path.basename(log_path))) if log_path else ""

    body = """
<h1>GitLab BAU Ticket %s</h1>
<div class="sub">%s in the current iteration. Click a column header to sort; type in the filter box to
narrow the table.</div>
%s
<table class="meta">
<tr><td><b>Project</b></td><td><code>%s</code></td></tr>
<tr><td><b>Iteration</b></td><td>%s (id %s)</td></tr>
<tr><td><b>Parent</b></td><td>%s</td></tr>
<tr><td><b>Label</b></td><td><code>%s</code></td></tr>
<tr><td><b>Weight</b></td><td>%s</td></tr>
<tr><td><b>Generated</b></td><td>%s</td></tr>
%s
</table>
<div class="cards">%s</div>
<h2>Actions</h2>
%s
<div class="foot">Ticket creation is idempotent: a ticket whose title is already open in the current
iteration is skipped rather than duplicated.</div>"""
    body = body % (
        verb.capitalize(),
        "Creating the standing BAU ticket set" if mode == "create" else "Closing open BAU tickets",
        dry, _e(settings.project_path), _e(result.iteration_title), _e(result.iteration_id),
        _e(result.epic_title) + ((" (id %s)" % _e(result.epic_id)) if result.epic_id else ""),
        _e(settings.ticket_label), _e(settings.ticket_weight), _e(gen), log_row, cards, actions_tbl)

    log.info("Ticket report built (%d action rows).", len(result.actions))
    return _shell("GitLab BAU Ticket %s" % verb.capitalize(), body)


def write_report(html_text: str, output_dir: str, prefix: str) -> str:
    os.makedirs(output_dir, exist_ok=True)
    path = os.path.join(output_dir,
                        "%s_%s.html" % (prefix, _dt.datetime.now().strftime("%Y%m%d_%H%M%S")))
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(html_text)
    log.info("Report written: %s", path)
    return path
