"""
Daily view.

Where DAG 1's main report answers "how did the last four months go", this
answers "what needs attention today". It is deliberately narrow:

  * Issues -- only those CLOSED on the report day that BREACHED the SLA.
  * Merge requests -- only those MERGED on the report day that breached.
  * Summary tables -- the CURRENT MONTH only, not the four-month window.

Plus the part that makes it actionable rather than purely retrospective:

  * Issues still OPEN that will breach the SLA if they are not closed
    today.
  * Merge requests still OPEN that will breach if they are not merged
    today.

Those two lists are where the value is. A breach already recorded is
history; an item about to breach can still be saved, which is the whole
point of running this at 6pm each working day.

Each at-risk row is labelled either ALREADY BREACHED (over the SLA and
still open) or AT RISK TODAY (crosses the SLA before the day ends).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import List, Optional, Tuple

from gl_metrics import (BASIS_IN_PROGRESS, BASIS_OPENED, _first_in_progress, _person_name,
                        business_days_between, elapsed_hours, month_key, parse_ts)
from gl_settings import get_logger

log = get_logger("gitlab.daily")

STATUS_BREACHED = "already breached"
STATUS_AT_RISK = "at risk today"


@dataclass
class AtRiskIssue:
    iid: int
    title: str
    author_name: str
    assignee_name: str
    created_at: Optional[datetime]
    in_progress_at: Optional[datetime]
    basis: str
    elapsed_now: float
    elapsed_end_of_day: float
    status: str
    web_url: str = ""


@dataclass
class AtRiskMR:
    repo: str
    iid: int
    title: str
    author_name: str
    created_at: Optional[datetime]
    first_touch_at: Optional[datetime]
    elapsed_now: float
    elapsed_end_of_day: float
    status: str
    web_url: str = ""


def day_bounds(now: Optional[datetime] = None) -> Tuple[datetime, datetime, datetime]:
    """(start of day, end of day, now) in UTC for the report day."""
    now = now or datetime.now(timezone.utc)
    start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    end = start + timedelta(days=1) - timedelta(seconds=1)
    return start, end, now


def on_day(dt: Optional[datetime], start: datetime, end: datetime) -> bool:
    return bool(dt) and start <= dt <= end


# ------------------------------------------------------------------ filters
def issues_closed_on_day(issue_metrics, start: datetime, end: datetime, flagged_only: bool = True):
    """Issues closed on the report day. Flagged-only by default -- the daily
    view is a list of problems, not a changelog."""
    out = [i for i in issue_metrics if on_day(i.closed_at, start, end)]
    if flagged_only:
        out = [i for i in out if i.flagged]
    out.sort(key=lambda i: (i.closed_at or start), reverse=True)
    log.info("%d issue(s) closed on the report day%s.", len(out),
             " and over SLA" if flagged_only else "")
    return out


def mrs_merged_on_day(mr_metrics, start: datetime, end: datetime, flagged_only: bool = True):
    """Merge requests MERGED on the report day. Merged only -- an abandoned
    MR has no SLA to breach."""
    out = [m for m in mr_metrics if m.state == "merged" and on_day(m.merged_at, start, end)]
    if flagged_only:
        out = [m for m in out if m.flagged]
    out.sort(key=lambda m: (m.merged_at or start), reverse=True)
    log.info("%d merge request(s) merged on the report day%s.", len(out),
             " and over SLA" if flagged_only else "")
    return out


# ------------------------------------------------------------------ at risk
def collect_at_risk_issues(client, settings, now: Optional[datetime] = None) -> List[AtRiskIssue]:
    """Open issues that have breached the SLA, or will breach it by the end
    of today if they are not closed."""
    start, end, now = day_bounds(now)
    log.info("=== Daily: open issues at risk of breaching the %g-business-day SLA ===",
             settings.issue_sla_business_days)
    try:
        issues = client.open_issues(settings.project_path)
    except Exception as e:
        log.error("Could not fetch open issues: %s", e)
        return []

    out: List[AtRiskIssue] = []
    for issue in issues:
        iid = issue.get("iid")
        created_at = parse_ts(issue.get("created_at"))
        try:
            events = client.issue_label_events(settings.project_path, iid)
        except Exception as e:
            log.error("Could not read label events for open issue #%s: %s", iid, e)
            events = []
        in_prog = _first_in_progress(events, settings.in_progress_labels)

        if in_prog:
            begin, basis = in_prog, BASIS_IN_PROGRESS
        elif created_at:
            begin, basis = created_at, BASIS_OPENED
        else:
            continue

        now_days = business_days_between(begin, now)
        eod_days = business_days_between(begin, end)
        if eod_days <= settings.issue_sla_business_days:
            continue                       # comfortably inside the SLA today

        status = STATUS_BREACHED if now_days > settings.issue_sla_business_days else STATUS_AT_RISK
        out.append(AtRiskIssue(
            iid=iid, title=str(issue.get("title", ""))[:200],
            author_name=_person_name(issue.get("author")),
            assignee_name=_person_name(issue.get("assignee"), "unassigned"),
            created_at=created_at, in_progress_at=in_prog, basis=basis,
            elapsed_now=now_days, elapsed_end_of_day=eod_days, status=status,
            web_url=str(issue.get("web_url", ""))))

    out.sort(key=lambda x: -x.elapsed_end_of_day)
    log.info("%d open issue(s) at risk (%d already breached).", len(out),
             sum(1 for x in out if x.status == STATUS_BREACHED))
    return out


def collect_at_risk_mrs(client, settings, now: Optional[datetime] = None) -> List[AtRiskMR]:
    """Open merge requests that have breached the SLA, or will breach it by
    the end of today if they are not merged."""
    start, end, now = day_bounds(now)
    log.info("=== Daily: open merge requests at risk of breaching the %g-hour SLA ===",
             settings.mr_sla_hours)
    out: List[AtRiskMR] = []

    for repo_name, repo_path in settings.code_repos.items():
        try:
            mrs = client.open_merge_requests(repo_path)
        except Exception as e:
            log.error("Could not fetch open merge requests for %s: %s", repo_name, e)
            continue

        for mr in mrs:
            iid = mr.get("iid")
            created_at = parse_ts(mr.get("created_at"))
            try:
                commits = client.mr_commits(repo_path, iid)
            except Exception as e:
                log.error("Could not read commits for open %s MR !%s: %s", repo_name, iid, e)
                commits = []
            stamps = [t for t in (parse_ts(c.get("committed_date") or c.get("created_at"))
                                  for c in commits) if t]
            first_touch = min(stamps) if stamps else created_at
            if not first_touch:
                continue

            now_hours = elapsed_hours(first_touch, now)
            eod_hours = elapsed_hours(first_touch, end)
            if eod_hours <= settings.mr_sla_hours:
                continue

            status = STATUS_BREACHED if now_hours > settings.mr_sla_hours else STATUS_AT_RISK
            out.append(AtRiskMR(
                repo=repo_name, iid=iid, title=str(mr.get("title", ""))[:200],
                author_name=_person_name(mr.get("author")), created_at=created_at,
                first_touch_at=first_touch, elapsed_now=now_hours,
                elapsed_end_of_day=eod_hours, status=status,
                web_url=str(mr.get("web_url", ""))))

    out.sort(key=lambda x: -x.elapsed_end_of_day)
    log.info("%d open merge request(s) at risk (%d already breached).", len(out),
             sum(1 for x in out if x.status == STATUS_BREACHED))
    return out


# ------------------------------------------------------------------ serde
def _dt_out(dt: Optional[datetime]) -> Optional[str]:
    return dt.isoformat() if dt else None


def at_risk_to_payload(issues: List[AtRiskIssue], mrs: List[AtRiskMR]) -> dict:
    return {
        "issues": [{**vars(i), "created_at": _dt_out(i.created_at),
                    "in_progress_at": _dt_out(i.in_progress_at)} for i in issues],
        "mrs": [{**vars(m), "created_at": _dt_out(m.created_at),
                 "first_touch_at": _dt_out(m.first_touch_at)} for m in mrs],
    }


def payload_to_at_risk(payload: dict):
    payload = payload or {}
    issues = [AtRiskIssue(**{**d, "created_at": parse_ts(d.get("created_at")),
                             "in_progress_at": parse_ts(d.get("in_progress_at"))})
              for d in payload.get("issues", [])]
    mrs = [AtRiskMR(**{**d, "created_at": parse_ts(d.get("created_at")),
                       "first_touch_at": parse_ts(d.get("first_touch_at"))})
           for d in payload.get("mrs", [])]
    return issues, mrs
