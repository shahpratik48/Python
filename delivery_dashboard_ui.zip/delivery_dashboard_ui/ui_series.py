"""
Rebuilds the chart series from stored monthly rows.

The reporting job already computed the four parameters per month; this
module only re-derives what the chart needs on top of them -- baseline,
shift, aspiration and the 3-month rolling windows -- so a filter change is
arithmetic over a few hundred numbers rather than a fresh collection.

Definitions match the reporting job exactly, so the UI and the XLSX/HTML
reports cannot disagree:

    baseline    the mean of `baseline_window_months` starting at the
                baseline month, per parameter
    shift       (value - baseline) / |baseline| x 100, sign-flipped for
                Cycle Time and Lead Time so positive always means better
    chart       3-month rolling windows; the window starting at the baseline
                month spans exactly the baseline months, so aspiration meets
                actual there by construction
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence

from ui_data import get_logger

log = get_logger("ui.series")

METRIC_DEFS = [
    ("throughput", "Issue Throughput", False),
    ("cycle_time", "Cycle Time (Days)", True),
    ("mr_per_author", "Merged MR per Author", False),
    ("lead_time", "Lead Time (Hrs)", True),
]
METRIC_KEYS = [m[0] for m in METRIC_DEFS]
LOWER_IS_BETTER = {a: low for a, _l, low in METRIC_DEFS}


def month_label(mk: str) -> str:
    y, m = mk.split("-")
    return "%s %s" % (["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul",
                       "Aug", "Sep", "Oct", "Nov", "Dec"][int(m) - 1], y[2:])


def window_slices(months: Sequence[str], window: int = 3):
    labels, spans = [], []
    for i in range(len(months) - window + 1):
        labels.append("%s-%s" % (month_label(months[i]), month_label(months[i + window - 1])))
        spans.append((i, i + window))
    return labels, spans


def window_average(values, spans):
    """Mean per window, ignoring gaps -- a month with no data contributes
    nothing rather than counting as zero, which would invent a decline."""
    out = []
    for a, b in spans:
        vals = [v for v in values[a:b] if v is not None]
        out.append(round(sum(vals) / len(vals), 2) if vals else None)
    return out


def gain(metric: str, value: Optional[float], base: Optional[float]) -> Optional[float]:
    if value is None or base in (None, 0):
        return None
    raw = (value - base) / abs(base) * 100.0
    return round(-raw if LOWER_IS_BETTER[metric] else raw, 2)


def ramp_at(offset: Optional[int], target_pct: float, target_months: int) -> Optional[float]:
    if offset is None or offset < 0 or target_months <= 0:
        return None
    return round(min(offset / float(target_months), 1.0) * target_pct, 2)


def _split(vals, bi):
    """One series in two segments; the anchor sits in both so they join."""
    if bi is None:
        return list(vals), [None] * len(vals)
    return ([v if i <= bi else None for i, v in enumerate(vals)],
            [v if i >= bi else None for i, v in enumerate(vals)])


def _mean(vals):
    v = [x for x in vals if x is not None]
    return round(sum(v) / len(v), 2) if v else None


@dataclass
class Series:
    window_labels: List[str] = field(default_factory=list)
    baseline_label: str = ""
    baseline_index: Optional[int] = None
    baseline_months: List[str] = field(default_factory=list)
    windows: List = field(default_factory=list)
    actual: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    actual_prev: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    actual_curr: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    aspiration: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    baseline: Dict[str, Optional[float]] = field(default_factory=dict)
    shift_pct: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    progress_pct: Dict[str, Optional[float]] = field(default_factory=dict)
    gain_actual: List[Optional[float]] = field(default_factory=list)
    gain_prev: List[Optional[float]] = field(default_factory=list)
    gain_curr: List[Optional[float]] = field(default_factory=list)
    gain_asp: List[Optional[float]] = field(default_factory=list)
    overall_gain: Optional[float] = None
    scopes: List[str] = field(default_factory=list)


def build_series(rows: Dict[str, object], labels: List[str], baseline_lab: str,
                 target_gain_pct: float = 20.0, target_months: int = 14,
                 scopes: Optional[List[str]] = None) -> Series:
    """The chart series from stored windows.

    Definitions match the reporting job exactly, so the UI and the XLSX/HTML
    reports cannot disagree. Only the aspiration and the percentages are
    derived here; the four parameters come from the tables as loaded.
    """
    ser = Series(window_labels=list(labels), scopes=list(scopes or []),
                 windows=[rows.get(l) for l in labels])
    if not labels:
        return ser

    bi = labels.index(baseline_lab) if baseline_lab in labels else None
    ser.baseline_index = bi
    if bi is not None:
        ser.baseline_label = baseline_lab
        w = rows.get(baseline_lab)
        if w is not None and getattr(w, "start_month", ""):
            ser.baseline_months = [w.start_month, w.end_month]

    for k in METRIC_KEYS:
        vals = []
        for l in labels:
            w = rows.get(l)
            v = getattr(w, k, None) if w is not None else None
            vals.append(float(v) if v is not None else None)
        ser.actual[k] = vals
        base = vals[bi] if bi is not None else None
        ser.baseline[k] = base
        ser.actual_prev[k], ser.actual_curr[k] = _split(vals, bi)
        ser.shift_pct[k] = [gain(k, v, base) for v in vals]

        lower = LOWER_IS_BETTER[k]
        asp = []
        for j in range(len(labels)):
            step = ramp_at(None if bi is None else j - bi, target_gain_pct, target_months)
            if base is None or step is None:
                asp.append(None)
            else:
                f = (1 - step / 100.0) if lower else (1 + step / 100.0)
                asp.append(round(base * f, 2))
        ser.aspiration[k] = asp

        latest = next((v for v in reversed(vals) if v is not None), None)
        ser.progress_pct[k] = gain(k, latest, base)

    for j in range(len(labels)):
        ser.gain_actual.append(_mean([ser.shift_pct[k][j] for k in METRIC_KEYS]))
        ser.gain_asp.append(ramp_at(None if bi is None else j - bi,
                                    target_gain_pct, target_months))
    ser.gain_prev, ser.gain_curr = _split(ser.gain_actual, bi)
    ser.overall_gain = _mean([ser.progress_pct[k] for k in METRIC_KEYS])

    log.info("Series: %d window(s), baseline %s, overall gain %s%%",
             len(labels), ser.baseline_label or "n/a", ser.overall_gain)
    return ser
