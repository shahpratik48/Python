"""
Rebuilds the chart series from stored monthly rows.

The reporting job already computed the four parameters per month; this
module only re-derives what the chart needs on top of them -- baseline,
shift, aspiration and the 3-month rolling windows -- so a filter change is
arithmetic over a few hundred numbers rather than a fresh collection.

Definitions match the reporting job exactly, so the UI and the XLSX/HTML
reports cannot disagree:

    baseline    the mean of `baseline_window_months` starting at the
                baseline month, per parameter
    shift       (value - baseline) / |baseline| x 100, sign-flipped for
                Cycle Time and Lead Time so positive always means better
    chart       3-month rolling windows; the window starting at the baseline
                month spans exactly the baseline months, so aspiration meets
                actual there by construction
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence

from ui_data import MonthRow, get_logger

log = get_logger("ui.series")

METRIC_DEFS = [
    ("throughput", "Issue Throughput", False),
    ("cycle_time", "Cycle Time (Days)", True),
    ("mr_per_author", "Merged MR per Author", False),
    ("lead_time", "Lead Time (Hrs)", True),
]
METRIC_KEYS = [m[0] for m in METRIC_DEFS]
LOWER_IS_BETTER = {a: low for a, _l, low in METRIC_DEFS}


def month_label(mk: str) -> str:
    y, m = mk.split("-")
    return "%s %s" % (["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul",
                       "Aug", "Sep", "Oct", "Nov", "Dec"][int(m) - 1], y[2:])


def window_slices(months: Sequence[str], window: int = 3):
    labels, spans = [], []
    for i in range(len(months) - window + 1):
        labels.append("%s-%s" % (month_label(months[i]), month_label(months[i + window - 1])))
        spans.append((i, i + window))
    return labels, spans


def window_average(values, spans):
    """Mean per window, ignoring gaps -- a month with no data contributes
    nothing rather than counting as zero, which would invent a decline."""
    out = []
    for a, b in spans:
        vals = [v for v in values[a:b] if v is not None]
        out.append(round(sum(vals) / len(vals), 2) if vals else None)
    return out


def gain(metric: str, value: Optional[float], base: Optional[float]) -> Optional[float]:
    if value is None or base in (None, 0):
        return None
    raw = (value - base) / abs(base) * 100.0
    return round(-raw if LOWER_IS_BETTER[metric] else raw, 2)


def ramp_at(offset: Optional[int], target_pct: float, target_months: int) -> Optional[float]:
    if offset is None or offset < 0 or target_months <= 0:
        return None
    return round(min(offset / float(target_months), 1.0) * target_pct, 2)


def _split(vals, bi):
    """One series in two segments; the anchor sits in both so they join."""
    if bi is None:
        return list(vals), [None] * len(vals)
    return ([v if i <= bi else None for i, v in enumerate(vals)],
            [v if i >= bi else None for i, v in enumerate(vals)])


def _mean(vals):
    v = [x for x in vals if x is not None]
    return round(sum(v) / len(v), 2) if v else None


@dataclass
class Series:
    months: List[str] = field(default_factory=list)
    baseline_month: str = ""
    baseline_months: List[str] = field(default_factory=list)
    baseline_index: Optional[int] = None
    baseline_window_index: Optional[int] = None
    window_labels: List[str] = field(default_factory=list)
    chart_months: List[str] = field(default_factory=list)
    actual: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    baseline: Dict[str, Optional[float]] = field(default_factory=dict)
    shift_pct: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    progress_pct: Dict[str, Optional[float]] = field(default_factory=dict)
    w_actual: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    w_actual_prev: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    w_actual_curr: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    w_aspiration: Dict[str, List[Optional[float]]] = field(default_factory=dict)
    w_gain_actual: List[Optional[float]] = field(default_factory=list)
    w_gain_prev: List[Optional[float]] = field(default_factory=list)
    w_gain_curr: List[Optional[float]] = field(default_factory=list)
    w_gain_asp: List[Optional[float]] = field(default_factory=list)
    overall_gain: Optional[float] = None
    scopes: List[str] = field(default_factory=list)


def build_series(rows: Dict[str, MonthRow], months: List[str], baseline_month: str,
                 baseline_window: int = 3, target_gain_pct: float = 20.0,
                 target_months: int = 14, window: int = 3,
                 scopes: Optional[List[str]] = None,
                 current_month: Optional[str] = None) -> Series:
    """`current_month` is EXCLUDED from the chart.

    A month still in progress is incomplete by definition, so any window
    containing it would sit artificially low and read as a decline. Viewing
    in August therefore charts windows ending July at the latest.
    """
    ser = Series(months=list(months), baseline_month=baseline_month,
                 scopes=list(scopes or []))
    if not months:
        return ser
    bi = months.index(baseline_month) if baseline_month in months else None
    ser.baseline_index = bi
    ser.baseline_months = months[bi:bi + baseline_window] if bi is not None else []

    for k in METRIC_KEYS:
        vals = [getattr(rows.get(m) or MonthRow(month=m), k) for m in months]
        vals = [float(v) if v is not None else None for v in vals]
        ser.actual[k] = vals
        chunk = [v for v in vals[bi:bi + baseline_window] if v is not None] if bi is not None \
            else []
        base = round(sum(chunk) / len(chunk), 2) if chunk else None
        ser.baseline[k] = base
        ser.shift_pct[k] = [gain(k, v, base) for v in vals]
        # the headline is computed below from the WINDOW series, so the
        # panel title describes exactly the line drawn beneath it

    chart_months = [m for m in months if not current_month or m < current_month]
    if len(chart_months) < window:
        chart_months = list(months)          # too little history to drop anything
    ser.chart_months = chart_months
    n_chart = len(chart_months)
    labels, spans = window_slices(chart_months, window)
    ser.window_labels = labels
    bwi = bi if (bi is not None and bi < len(labels)) else None
    ser.baseline_window_index = bwi

    for k in METRIC_KEYS:
        wv = window_average(ser.actual[k][:n_chart], spans)
        ser.w_actual[k] = wv
        ser.w_actual_prev[k], ser.w_actual_curr[k] = _split(wv, bwi)
        wbase = wv[bwi] if (bwi is not None and bwi < len(wv)) else None
        lower = LOWER_IS_BETTER[k]
        asp = []
        for j in range(len(labels)):
            step = ramp_at(None if bwi is None else j - bwi, target_gain_pct, target_months)
            if wbase is None or step is None:
                asp.append(None)
            else:
                f = (1 - step / 100.0) if lower else (1 + step / 100.0)
                asp.append(round(wbase * f, 2))
        ser.w_aspiration[k] = asp

    # Panel headline: LAST window vs BASELINE window -- the two points a
    # reader can see at either end of the plotted line. The last single month
    # would sit far above the window average that smooths it, so the title
    # would disagree with its own line.
    for k in METRIC_KEYS:
        wv = ser.w_actual[k]
        w_base = wv[bwi] if (bwi is not None and bwi < len(wv)) else None
        w_latest = next((v for v in reversed(wv) if v is not None), None)
        ser.progress_pct[k] = gain(k, w_latest, w_base)

    for j in range(len(labels)):
        wbase = {k: (ser.w_actual[k][bwi] if bwi is not None else None) for k in METRIC_KEYS}
        ser.w_gain_actual.append(_mean([gain(k, ser.w_actual[k][j], wbase[k])
                                        for k in METRIC_KEYS]))
        ser.w_gain_asp.append(ramp_at(None if bwi is None else j - bwi,
                                      target_gain_pct, target_months))
    ser.w_gain_prev, ser.w_gain_curr = _split(ser.w_gain_actual, bwi)
    ser.overall_gain = _mean([ser.progress_pct[k] for k in METRIC_KEYS])

    log.info("Series: %d month(s) charted (to %s), %d window(s), baseline %s, "
             "overall gain %s%%", len(chart_months),
             chart_months[-1] if chart_months else "n/a", len(labels),
             ", ".join(ser.baseline_months) or "n/a", ser.overall_gain)
    return ser
