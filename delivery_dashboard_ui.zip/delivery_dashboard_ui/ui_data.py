"""
Greenplum access for the dashboard UI.

Reads the hierarchy and the already-loaded metrics. It never touches GitLab
and never recomputes anything from raw issues -- the reporting job has
already done that work, and the point of this UI is to explore the result
quickly.

Tables read (all in the same schema):

    delivery_org_hierarchy              the filter dropdowns
    pod_issue_monthly_summary           per-pod monthly issue parameters
    pod_mr_monthly_summary              per-pod monthly MR parameters
    crew_rollup_issue_monthly_summary   crew-level, when a whole crew is chosen
    crew_rollup_mr_monthly_summary

**One naming convention, no per-pod table map.** Every pod's rows live in
the same four tables, distinguished by `scope_name`. A map of pod to table
would have to be maintained by hand and would drift the first time a pod was
renamed.
"""
from __future__ import annotations

import getpass
import logging
import os
import sys
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence

LEVELS = ["division", "subdivision", "stream", "crew", "pod"]

TBL_ORG = "delivery_org_hierarchy"
TBL_POD_ISSUE = "pod_issue_monthly_summary"
TBL_POD_MR = "pod_mr_monthly_summary"
TBL_CREW_ISSUE = "crew_rollup_issue_monthly_summary"
TBL_CREW_MR = "crew_rollup_mr_monthly_summary"

_LOG_FMT = "%(asctime)s | %(levelname)-7s | %(name)-16s | %(message)s"
_configured = False


def setup_logging(level: str = "INFO") -> None:
    global _configured
    if _configured:
        return
    root = logging.getLogger()
    root.setLevel(getattr(logging, str(level).upper(), logging.INFO))
    for h in list(root.handlers):
        root.removeHandler(h)
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(logging.Formatter(_LOG_FMT))
    root.addHandler(sh)
    _configured = True


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)


log = get_logger("ui.data")


@dataclass
class DbSettings:
    host: str = field(default_factory=lambda: os.getenv(
        "GREENPLUM_HOST", "greenplum-rdsp.zur.swissbank.com"))
    port: int = field(default_factory=lambda: int(os.getenv("GREENPLUM_PORT", "5432")))
    db: str = field(default_factory=lambda: os.getenv("GREENPLUM_DB", "gprdsp"))
    user: str = field(default_factory=lambda: os.getenv("GREENPLUM_USER", "ds_rdsp_dev"))
    password: Optional[str] = field(default_factory=lambda: os.getenv("GREENPLUM_PASSWORD", ""))
    schema: str = field(default_factory=lambda: os.getenv("DELIVERY_GP_SCHEMA",
                                                          "sandbox_prj_smart_insights"))

    def resolve_password(self, interactive: bool = True) -> "DbSettings":
        if not self.password:
            try:
                from airflow.models import Variable  # type: ignore
                self.password = Variable.get("GREENPLUM_PASSWORD", default_var=None)
            except Exception:
                pass
        if not self.password and interactive:
            self.password = getpass.getpass(
                "Greenplum password for %s@%s: " % (self.user, self.host)).strip() or None
        if not self.password:
            raise RuntimeError("No Greenplum password. Set GREENPLUM_PASSWORD or enter it "
                               "when prompted.")
        return self

    def connect(self):
        import psycopg2
        return psycopg2.connect(host=self.host, port=self.port, dbname=self.db,
                                user=self.user, password=self.password, connect_timeout=30)


@dataclass
class OrgNode:
    division: str
    subdivision: str
    stream: str
    crew: str
    pod: str
    pod_key: str = ""

    def value(self, level: str) -> str:
        return getattr(self, level)


@dataclass
class Org:
    nodes: List[OrgNode] = field(default_factory=list)

    def options(self, level: str, selection: Optional[Dict[str, Sequence[str]]] = None
                ) -> List[str]:
        """Distinct values at `level`, narrowed by the levels ABOVE it, so the
        dropdowns cascade downward only."""
        selection = selection or {}
        idx = LEVELS.index(level)
        out = []
        for n in self.nodes:
            if all(self._match(n, lv, selection.get(lv)) for lv in LEVELS[:idx]):
                v = n.value(level)
                if v and v not in out:
                    out.append(v)
        return out

    @staticmethod
    def _match(node: OrgNode, level: str, chosen) -> bool:
        # empty selection means "all", which is what a dashboard filter is
        # normally expected to do
        return True if not chosen else node.value(level) in set(chosen)

    def resolve(self, selection: Optional[Dict[str, Sequence[str]]] = None) -> List[OrgNode]:
        selection = selection or {}
        return [n for n in self.nodes
                if all(self._match(n, lv, selection.get(lv)) for lv in LEVELS)]

    def pods(self, selection=None) -> List[str]:
        out = []
        for n in self.resolve(selection):
            if n.pod not in out:
                out.append(n.pod)
        return out

    def crews(self, selection=None) -> List[str]:
        out = []
        for n in self.resolve(selection):
            if n.crew not in out:
                out.append(n.crew)
        return out

    def pods_of_crew(self, crew: str) -> List[str]:
        out = []
        for n in self.nodes:
            if n.crew == crew and n.pod not in out:
                out.append(n.pod)
        return out


def load_org(db: DbSettings) -> Org:
    conn = db.connect()
    try:
        cur = conn.cursor()
        cur.execute("SELECT division, subdivision, stream, crew, pod_name, pod_key "
                    "FROM %s.%s WHERE is_active "
                    "ORDER BY division, subdivision, stream, crew, pod_name"
                    % (db.schema, TBL_ORG))
        rows = cur.fetchall()
    finally:
        conn.close()
    if not rows:
        raise ValueError("No active rows in %s.%s -- run setup_config_tables.py first."
                         % (db.schema, TBL_ORG))
    org = Org(nodes=[OrgNode(*r) for r in rows])
    log.info("Hierarchy: %d pod(s) across %d crew(s).", len(org.nodes), len(org.crews()))
    return org


# ------------------------------------------------------------------ metrics
@dataclass
class MonthRow:
    month: str
    throughput: Optional[float] = None
    cycle_time: Optional[float] = None
    mr_per_author: Optional[float] = None
    lead_time: Optional[float] = None
    closed_count: float = 0.0
    mr_count: float = 0.0
    author_count: float = 0.0
    is_baseline: bool = False


def _f(v):
    return None if v is None else float(v)


def load_monthly(db: DbSettings, level: str, scope_names: Sequence[str]) -> Dict[str, dict]:
    """Monthly rows for one or more scopes, keyed by scope then month.

    `level` picks the table pair: "pod" for individual pods, "crew" for the
    pre-computed roll-up.
    """
    if not scope_names:
        return {}
    itbl, mtbl = ((TBL_POD_ISSUE, TBL_POD_MR) if level == "pod"
                  else (TBL_CREW_ISSUE, TBL_CREW_MR))
    names = list(scope_names)
    out: Dict[str, dict] = {n: {} for n in names}

    conn = db.connect()
    try:
        cur = conn.cursor()
        cur.execute("SELECT scope_name, month_key, is_baseline_month, closed_issue_count, "
                    "issue_throughput, cycle_time_days FROM %s.%s WHERE scope_name = ANY(%%s)"
                    % (db.schema, itbl), (names,))
        for scope, month, base, closed, thr, cyc in cur.fetchall():
            r = out.setdefault(scope, {}).setdefault(month, MonthRow(month=month))
            r.is_baseline = bool(base)
            r.closed_count = float(closed or 0)
            r.throughput = _f(thr)
            r.cycle_time = _f(cyc)

        cur.execute("SELECT scope_name, month_key, merged_mr_count, author_count, "
                    "merged_mr_per_author, lead_time_hours FROM %s.%s "
                    "WHERE scope_name = ANY(%%s)" % (db.schema, mtbl), (names,))
        for scope, month, cnt, auth, per, lead in cur.fetchall():
            r = out.setdefault(scope, {}).setdefault(month, MonthRow(month=month))
            r.mr_count = float(cnt or 0)
            r.author_count = float(auth or 0)
            r.mr_per_author = _f(per)
            r.lead_time = _f(lead)
    finally:
        conn.close()

    total = sum(len(v) for v in out.values())
    log.info("Loaded %d month-row(s) for %d %s scope(s).", total, len(names), level)
    return out


def combine_pods(per_scope: Dict[str, dict], months: Sequence[str]) -> Dict[str, MonthRow]:
    """Merges several pods into one series.

    Counts add up. Averages must NOT be averaged again -- cycle time and lead
    time are weighted by how many items each pod actually measured, and
    merged-MRs-per-author is recomputed from total merges over total authors.
    Otherwise a pod that closed two issues would sway the mean as hard as one
    that closed fifty.
    """
    out: Dict[str, MonthRow] = {}
    n_pods = max(1, len(per_scope))
    for m in months:
        rows = [v.get(m) for v in per_scope.values()]
        rows = [r for r in rows if r is not None]
        r = MonthRow(month=m)
        if not rows:
            out[m] = r
            continue
        r.is_baseline = any(x.is_baseline for x in rows)
        r.closed_count = sum(x.closed_count for x in rows)
        # throughput is per pod: total closed over the pods being combined
        r.throughput = round(r.closed_count / float(n_pods), 2)

        num = sum((x.cycle_time or 0.0) * x.closed_count
                  for x in rows if x.cycle_time is not None)
        den = sum(x.closed_count for x in rows if x.cycle_time is not None)
        r.cycle_time = round(num / den, 2) if den else None

        r.mr_count = sum(x.mr_count for x in rows)
        r.author_count = sum(x.author_count for x in rows)
        r.mr_per_author = (round(r.mr_count / r.author_count, 2)
                           if r.author_count else None)

        num = sum((x.lead_time or 0.0) * x.mr_count for x in rows if x.lead_time is not None)
        den = sum(x.mr_count for x in rows if x.lead_time is not None)
        r.lead_time = round(num / den, 2) if den else None
        out[m] = r
    return out


def all_months(per_scope: Dict[str, dict]) -> List[str]:
    ms = set()
    for v in per_scope.values():
        ms.update(v.keys())
    return sorted(ms)


def baseline_months(per_scope: Dict[str, dict]) -> List[str]:
    ms = set()
    for v in per_scope.values():
        ms.update(m for m, r in v.items() if r.is_baseline)
    return sorted(ms)
