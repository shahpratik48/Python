"""
Greenplum access for the dashboard UI.

Reads the hierarchy and the already-loaded metrics. It never touches GitLab
and never recomputes anything from raw issues -- the reporting job has
already done that work, and the point of this UI is to explore the result
quickly.

Tables read (all in the same schema):

    delivery_org_hierarchy              the filter dropdowns
    pod_issue_monthly_summary           per-pod monthly issue parameters
    pod_mr_monthly_summary              per-pod monthly MR parameters
    crew_rollup_issue_monthly_summary   crew-level, when a whole crew is chosen
    crew_rollup_mr_monthly_summary

**One naming convention, no per-pod table map.** Every pod's rows live in
the same four tables, distinguished by `scope_name`. A map of pod to table
would have to be maintained by hand and would drift the first time a pod was
renamed.
"""
from __future__ import annotations

import getpass
import logging
import os
import sys
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence

LEVELS = ["division", "subdivision", "stream", "crew", "pod"]

TBL_ORG = "delivery_org_hierarchy"
TBL_POD_ISSUE = "pod_issue_monthly_summary"
TBL_POD_MR = "pod_mr_monthly_summary"
TBL_CREW_ISSUE = "crew_rollup_issue_monthly_summary"
TBL_CREW_MR = "crew_rollup_mr_monthly_summary"

_LOG_FMT = "%(asctime)s | %(levelname)-7s | %(name)-16s | %(message)s"
_configured = False


def setup_logging(level: str = "INFO") -> None:
    global _configured
    if _configured:
        return
    root = logging.getLogger()
    root.setLevel(getattr(logging, str(level).upper(), logging.INFO))
    for h in list(root.handlers):
        root.removeHandler(h)
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(logging.Formatter(_LOG_FMT))
    root.addHandler(sh)
    _configured = True


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)


log = get_logger("ui.data")


@dataclass
class DbSettings:
    host: str = field(default_factory=lambda: os.getenv(
        "GREENPLUM_HOST", "greenplum-rdsp.zur.swissbank.com"))
    port: int = field(default_factory=lambda: int(os.getenv("GREENPLUM_PORT", "5432")))
    db: str = field(default_factory=lambda: os.getenv("GREENPLUM_DB", "gprdsp"))
    user: str = field(default_factory=lambda: os.getenv("GREENPLUM_USER", "ds_rdsp_dev"))
    password: Optional[str] = field(default_factory=lambda: os.getenv("GREENPLUM_PASSWORD", ""))
    schema: str = field(default_factory=lambda: os.getenv("DELIVERY_GP_SCHEMA",
                                                          "sandbox_prj_smart_insights"))

    def resolve_password(self, interactive: bool = True) -> "DbSettings":
        if not self.password:
            try:
                from airflow.models import Variable  # type: ignore
                self.password = Variable.get("GREENPLUM_PASSWORD", default_var=None)
            except Exception:
                pass
        if not self.password and interactive:
            self.password = getpass.getpass(
                "Greenplum password for %s@%s: " % (self.user, self.host)).strip() or None
        if not self.password:
            raise RuntimeError("No Greenplum password. Set GREENPLUM_PASSWORD or enter it "
                               "when prompted.")
        return self

    def connect(self):
        import psycopg2
        return psycopg2.connect(host=self.host, port=self.port, dbname=self.db,
                                user=self.user, password=self.password, connect_timeout=30)


@dataclass
class OrgNode:
    division: str
    subdivision: str
    stream: str
    crew: str
    pod: str
    pod_key: str = ""

    def value(self, level: str) -> str:
        return getattr(self, level)


@dataclass
class Org:
    nodes: List[OrgNode] = field(default_factory=list)

    def options(self, level: str, selection: Optional[Dict[str, Sequence[str]]] = None
                ) -> List[str]:
        """Distinct values at `level`, narrowed by the levels ABOVE it, so the
        dropdowns cascade downward only."""
        selection = selection or {}
        idx = LEVELS.index(level)
        out = []
        for n in self.nodes:
            if all(self._match(n, lv, selection.get(lv)) for lv in LEVELS[:idx]):
                v = n.value(level)
                if v and v not in out:
                    out.append(v)
        return out

    @staticmethod
    def _match(node: OrgNode, level: str, chosen) -> bool:
        # empty selection means "all", which is what a dashboard filter is
        # normally expected to do
        return True if not chosen else node.value(level) in set(chosen)

    def resolve(self, selection: Optional[Dict[str, Sequence[str]]] = None) -> List[OrgNode]:
        selection = selection or {}
        return [n for n in self.nodes
                if all(self._match(n, lv, selection.get(lv)) for lv in LEVELS)]

    def pods(self, selection=None) -> List[str]:
        out = []
        for n in self.resolve(selection):
            if n.pod not in out:
                out.append(n.pod)
        return out

    def crews(self, selection=None) -> List[str]:
        out = []
        for n in self.resolve(selection):
            if n.crew not in out:
                out.append(n.crew)
        return out

    def pods_of_crew(self, crew: str) -> List[str]:
        out = []
        for n in self.nodes:
            if n.crew == crew and n.pod not in out:
                out.append(n.pod)
        return out


def load_org(db: DbSettings) -> Org:
    conn = db.connect()
    try:
        cur = conn.cursor()
        # COALESCE, not a bare `WHERE is_active`: a row inserted by hand
        # without the flag would otherwise be NULL and silently vanish from
        # the dropdowns. Retiring a pod has to be deliberate.
        cur.execute("SELECT division, subdivision, stream, crew, pod_name, pod_key "
                    "FROM %s.%s WHERE COALESCE(is_active, true) "
                    "ORDER BY division, subdivision, stream, crew, pod_name"
                    % (db.schema, TBL_ORG))
        rows = cur.fetchall()
        cur.execute("SELECT count(*) FROM %s.%s WHERE NOT COALESCE(is_active, true)"
                    % (db.schema, TBL_ORG))
        n_inactive = cur.fetchone()[0]
    finally:
        conn.close()
    if not rows:
        raise ValueError("No active rows in %s.%s -- run setup_config_tables.py first."
                         % (db.schema, TBL_ORG))
    org = Org(nodes=[OrgNode(*r) for r in rows])
    log.info("Hierarchy: %d active pod(s) across %d crew(s)%s.",
             len(org.nodes), len(org.crews()),
             (", %d inactive pod(s) excluded" % n_inactive) if n_inactive else "")
    return org


# ------------------------------------------------------------------ metrics
@dataclass
class WindowRow:
    """One stored 3-month window for one scope."""
    label: str
    start_month: str = ""
    end_month: str = ""
    is_baseline: bool = False
    throughput: Optional[float] = None
    cycle_time: Optional[float] = None
    mr_per_author: Optional[float] = None
    lead_time: Optional[float] = None
    closed_total: float = 0.0
    in_progress: float = 0.0
    trimmed: float = 0.0
    mr_count: float = 0.0
    author_count: float = 0.0
    lead_measured: float = 0.0
    lead_excluded: float = 0.0
    pod_count: float = 1.0

    def value(self, k):
        return getattr(self, k)


def _f(v):
    return None if v is None else float(v)


def load_windows(db: DbSettings, level: str, scope_names: Sequence[str]) -> Dict[str, dict]:
    """The stored window rows for one or more scopes, keyed scope -> label.

    Nothing is recomputed from raw issues here: the reporting job already
    applied the scope rules, the slowest-15% trim and the GPN attribution, so
    re-deriving them would risk the UI disagreeing with the reports.
    """
    if not scope_names:
        return {}
    itbl, mtbl = ((TBL_POD_ISSUE, TBL_POD_MR) if level == "pod"
                  else (TBL_CREW_ISSUE, TBL_CREW_MR))
    names = list(scope_names)
    out: Dict[str, dict] = {n: {} for n in names}

    conn = db.connect()
    try:
        cur = conn.cursor()
        cur.execute("SELECT scope_name, window_label, window_start_month, window_end_month, "
                    "is_baseline_window, pod_count, closed_issue_total, issue_throughput, "
                    "reached_in_progress, trimmed_slowest, cycle_time_days "
                    "FROM %s.%s WHERE scope_name = ANY(%%s)" % (db.schema, itbl), (names,))
        for (scope, lab, m0, m1, base, pods, closed, thr, inprog, trim, cyc) in cur.fetchall():
            r = out.setdefault(scope, {}).setdefault(lab, WindowRow(label=lab))
            r.start_month, r.end_month = m0 or "", m1 or ""
            r.is_baseline = bool(base)
            r.pod_count = float(pods or 1)
            r.closed_total = float(closed or 0)
            r.throughput = _f(thr)
            r.in_progress = float(inprog or 0)
            r.trimmed = float(trim or 0)
            r.cycle_time = _f(cyc)

        cur.execute("SELECT scope_name, window_label, merged_mr_total, distinct_authors, "
                    "merged_mr_per_author, lead_time_measured, lead_time_excluded, "
                    "lead_time_hours FROM %s.%s WHERE scope_name = ANY(%%s)"
                    % (db.schema, mtbl), (names,))
        for (scope, lab, cnt, auth, per, meas, excl, lead) in cur.fetchall():
            r = out.setdefault(scope, {}).setdefault(lab, WindowRow(label=lab))
            r.mr_count = float(cnt or 0)
            r.author_count = float(auth or 0)
            r.mr_per_author = _f(per)
            r.lead_measured = float(meas or 0)
            r.lead_excluded = float(excl or 0)
            r.lead_time = _f(lead)
    finally:
        conn.close()

    total = sum(len(v) for v in out.values())
    log.info("Loaded %d window row(s) for %d %s scope(s).", total, len(names), level)
    return out


def combine_windows(per_scope: Dict[str, dict], labels: Sequence[str],
                    pod_count: int) -> Dict[str, WindowRow]:
    """Merges several pods into one series, window by window.

    Counts add up. Ratios are RECOMPUTED from the combined totals rather than
    averaged: averaging a pod that merged two MRs against one that merged
    fifty would weight them equally. Cycle time is weighted by how many
    issues each pod actually measured, for the same reason.
    """
    out: Dict[str, WindowRow] = {}
    for lab in labels:
        rows = [v.get(lab) for v in per_scope.values()]
        rows = [r for r in rows if r is not None]
        r = WindowRow(label=lab, pod_count=max(1, pod_count))
        if not rows:
            out[lab] = r
            continue
        r.start_month, r.end_month = rows[0].start_month, rows[0].end_month
        r.is_baseline = any(x.is_baseline for x in rows)

        r.closed_total = sum(x.closed_total for x in rows)
        r.throughput = round(r.closed_total / float(max(1, pod_count)), 2)

        r.in_progress = sum(x.in_progress for x in rows)
        r.trimmed = sum(x.trimmed for x in rows)
        meas = [(x.cycle_time, max(0.0, x.in_progress - x.trimmed)) for x in rows
                if x.cycle_time is not None]
        den = sum(w for _v, w in meas)
        r.cycle_time = round(sum(v * w for v, w in meas) / den, 2) if den else None

        r.mr_count = sum(x.mr_count for x in rows)
        r.author_count = sum(x.author_count for x in rows)
        r.mr_per_author = (round(r.mr_count / r.author_count, 2)
                           if r.author_count else None)

        r.lead_measured = sum(x.lead_measured for x in rows)
        r.lead_excluded = sum(x.lead_excluded for x in rows)
        lead = [(x.lead_time, x.lead_measured) for x in rows if x.lead_time is not None]
        den = sum(w for _v, w in lead)
        r.lead_time = round(sum(v * w for v, w in lead) / den, 2) if den else None
        out[lab] = r
    return out


def all_labels(per_scope: Dict[str, dict]) -> List[str]:
    """Window labels in chronological order.

    Sorted by the window's START MONTH, not alphabetically -- "Apr 26-Jun 26"
    would otherwise sort before "Nov 24-Jan 25".
    """
    seen = {}
    for v in per_scope.values():
        for lab, r in v.items():
            seen.setdefault(lab, r.start_month or "")
    return [l for l, _m in sorted(seen.items(), key=lambda kv: (kv[1], kv[0]))]


def baseline_label(per_scope: Dict[str, dict]) -> str:
    for v in per_scope.values():
        for lab, r in v.items():
            if r.is_baseline:
                return lab
    return ""
