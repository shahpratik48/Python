# Crew Delivery Report — STAAT Data Science

Crew-level delivery metrics as **XLSX and HTML**, each with the dashboard chart embedded, plus a
**Greenplum** load. Runs from a notebook locally, or on a schedule via Airflow.

| | |
|---|---|
| **Window** | Nov 2024 → Jul 2026 |
| **Baseline** | Nov 2025 |
| **Issue scope** | every project beneath `…/staat-data-science` |
| **MR scope** | every project beneath `…/staat-ds-genesis/genesis-platform` |

## Projects are discovered, not configured

Both groups are scanned **recursively** (`include_subgroups`), so every project in every sub-group is
found automatically. A new repository appears in the next run with no config change. Archived
projects are excluded — they are not active work, and including them would inflate history with
repositories the crew no longer runs.


> ### ⚠ If you have already loaded data
>
> Scope rules were added — issues must have reached In Progress, the slowest 15% are trimmed, and
> merge requests over a year are dropped — so stored months are not comparable with new ones.
>
> Two earlier definition changes — Issue Throughput is now **per pod**, and the baseline
> is a **three-month average** — so stored months are not comparable with new ones. Re-run once with
> `force_full_refresh=True`. The summary table also gained a `closed_issue_count` column, which is
> added automatically to an existing table.
>
> Cycle Time previously counted **calendar** days. Any month already in Greenplum was computed on the
> old basis and is **not comparable** with newly collected months. Re-fetch and rewrite everything
> once:
>
> ```python
> run_crew_report(settings, force_full_refresh=True)
> ```
>
> This is a one-off; normal incremental behaviour resumes on the next run.

## The four parameters

| Parameter | Definition | Direction |
|---|---|---|
| **Issue Throughput** | issues closed in the month **÷ number of pods** | higher is better |
| **Cycle Time (Days)** | average elapsed **business** days per closed issue | **lower** is better |
| **Merged MR per Author** | merged MRs ÷ distinct authors | higher is better |
| **Lead Time (Hrs)** | average elapsed hours, first file check-in → merged | **lower** is better |

### Cycle Time start point

Strict priority order — this is the crew's definition and it is **not** issue creation:

| Tier | `measured_from` | Start point | Source |
|---|---|---|---|
| 1 | `in_progress` | first time the issue moved to **In Progress** | `resource_label_events`, earliest **add** |
| 2 | `iteration_assigned` | the day an **iteration was assigned** | `resource_iteration_events`, earliest **add** |
| 3 | `created` | the issue **creation date** | the issue itself |

Tier 1 always wins where it exists — an issue with both an in-progress transition *and* an earlier
iteration assignment is measured from the in-progress transition. Tier 2 is only queried for issues
tier 1 could not resolve, so it costs nothing for the majority. Tier 3 exists so no issue silently
disappears from the report.

Only the **earliest add** counts at each tier; later re-adds and any *remove* events are ignored, so
an issue bounced in and out of In Progress still dates from when work first started.

Which tier was used is carried on every issue row (`measured_from`) and counted per month in
`crew_issue_monthly_summary`. An iteration-based figure reads differently from an in-progress one,
and a reader should be able to see which they are looking at.

### Iteration names

GitLab iterations very often have a **null title** — the human name a board shows
("STAAT DS insight iteration") belongs to the iteration **cadence**, not the iteration itself. Issues
only carry the iteration, so the cadence is resolved separately; without that every row would read
`Iteration 4207`.

The group's iterations and cadences are fetched **once per run** (a handful of requests) and looked up
in memory per issue. The `Iteration` column resolves in this order:

| Available | Column shows |
|---|---|
| iteration title *and* cadence | `STAAT DS insight iteration - Sprint 42` |
| cadence only (the common case) | `STAAT DS insight iteration` |
| neither, but dates | `2026-04-01 to 2026-04-14` |
| nothing | `Iteration 4207` |

`Iteration Start` and `Iteration End` come from the iteration, falling back to the resolved record.

If names still come through as bare ids, the token likely cannot read
`/groups/:id/iteration_cadences` — that call is logged as a warning rather than failing the run.

### Business days

```
cycle_time_days = business days between start and closed_at
```

**Saturdays and Sundays are excluded entirely.** Friday afternoon to Monday morning counts as roughly
0.75 days, not 2.75; a whole weekend contributes 0.00. Public holidays are **not** accounted for.

The 5-day SLA threshold is therefore 5 *business* days.

### Merge requests

Only **merged** MRs are considered. Opened, closed-without-merging and locked ones never enter the
data at all — the lead-time measure is about delivered code, and an abandoned branch delivered
nothing.

## Issue Throughput is per pod

The crew spans several pods, so a raw closed count says as much about headcount as about delivery.
Throughput is therefore **closed issues divided by the number of pods**:

```
Issue Throughput = closed issues in the month / CREW_POD_COUNT     (default 9)
```

The *Issues* sheet still shows **Closed** as the raw count, so both views are available.

## The baseline is a three-month average

The baseline is the **mean of the baseline month and the two that follow it** — by default
**Nov-25, Dec-25 and Jan-26** — for each of the four parameters, not the value in a single month.

```
baseline[metric] = mean(value[Nov-25], value[Dec-25], value[Jan-26])
```

A one-month baseline is fragile: an unusually quiet or busy November shifts every percentage on the
report, and that demonstrably happened on earlier runs. Averaging three months damps it.

All three months are **highlighted** in every table. Window size is `CREW_BASELINE_WINDOW_MONTHS`
(default 3); set it to 1 to go back to a single-month baseline.

> **This resolves cleanly on the chart.** Because the chart plots 3-month windows, the
> `Nov 25-Jan 26` window averages exactly the baseline months — so aspiration and actual meet there
> exactly. The averaged baseline and "aspiration equals actual at the anchor" are the same statement
> once both are windowed.


## Scope — what feeds the metrics

The graph and every metric use **in-scope** items only. The detail tables list **everything**, with a
`Scope` column and a `Scope Reason`, so an excluded item is visible and explained rather than
silently missing.

### Issues

In scope when the issue **reached In Progress and was then closed** — measured from the **first**
in-progress transition to the **last** closed event. An issue reopened and closed again is measured
to the final closure.

Excluded, and why:

| Reason | Rationale |
|---|---|
| never moved to in progress (measured from iteration assignment) | the elapsed time would describe how long it sat in a backlog, not how long the work took |
| never moved to in progress (measured from creation) | same |
| slowest 15% of issues closed in *month* | a handful of stale tickets would otherwise dominate the month's average |

**A closed date is enough.** Where the state history has no closed event, or records one *before* the
in-progress transition, the issue's own `closed_at` is used instead. GitLab reporting a `closed_at`
means the issue was closed, so it stays in scope — an accounting quirk in the event history should
not remove real delivered work from the numbers. Where the transition is recorded *after* the
closure, the issue still counts towards throughput but contributes no cycle time, and says so in its
`Scope Reason`.

The trim is per month, applied after scoping, and skipped where a month has fewer than three
in-scope issues — a percentile over one or two items means nothing. Set with
`CREW_ISSUE_SLOWEST_TRIM_PCT` (default 15; 0 disables).

**Both Issue Throughput and Cycle Time count in-scope issues only**, so the two always describe the
same population.

### Merge requests

In scope when **merged** with a **lead time under one year**. Excluded:

| Reason |
|---|
| lead time over one year |
| no commit history, so lead time cannot be measured |

Opened, closed-without-merging and locked merge requests never enter the data at all.

### Detail table columns

Both tables gain `Scope` and `Scope Reason` as the first two columns, and out-of-scope rows are shaded
grey. The MR table also carries **MR ID**, **Target Project ID**, **Source Branch**, **Target
Branch**, **Created At** and **First Approved At**.

First-approved comes from the approvals endpoint, which is a Premium feature — where it is
unavailable the column is simply blank rather than the run failing.

## Percentages

```
shift = (value − baseline) / |baseline| × 100
```

sign-flipped for Cycle Time and Lead Time, so **positive always means better**. **Overall** is the
plain mean of the four. The shift block runs from the baseline month to the current month.

## The chart

**The chart plots 3-month rolling windows, not individual months** — `Nov 24-Jan 25`,
`Dec 24-Feb 25`, `Jan 25-Mar 25`, and so on, each point being the average of those three months. A
single month for one crew swings hard on a couple of late tickets; the trend is what is readable, not
any one point. 21 months produce 19 windows.

The **aspiration anchor is the `Nov 25-Jan 26` window** — which spans exactly the baseline months, so
its average *is* the baseline. Aspiration therefore starts precisely on the actual there by
construction rather than by coincidence, and nothing is drawn before it.

The tables remain **monthly**; only the chart is windowed.

One wide **Overall Productivity Gain** panel, then the four parameters in a 2×2 grid. Three series
each:

| Series | Meaning | Style |
|---|---|---|
| **Actual (Previous)** | before the baseline | dotted, grey |
| **Actual (Current)** | baseline onward | solid, blue |
| **Aspiration** | target ramp | dashed, red |

The aspiration **starts exactly on the actual at the baseline** and ramps to the target from there.
Nothing is drawn before the baseline. Every point is labelled — actual above, aspiration below — so
values can be read straight off.

The **same PNG** is embedded in both deliverables: as a drawing on the workbook's *Dashboard* sheet,
and base64-inlined in the HTML so the page stays a single self-contained file that survives being
emailed.

## Outputs

**Every table is ordered newest month first.**

No worksheet uses frozen panes, so every sheet scrolls freely. The autofilter is applied to the
**Issue List** and **MR List** sheets only — a worksheet supports just one, and those are where
filtering is actually useful.

**Six worksheets:**

| # | Sheet | Contents |
|---|---|---|
| 1 | **Summary** | Monthly parameters (baseline months highlighted) · **Shift against baseline**, coloured green when better, red when worse |
| 2 | **Dashboard** | the chart |
| 3 | **Issues-summary** | *Per month* — Closed · From in progress · From opened · Avg business days · Flagged · Not measurable |
| 4 | **MR-summary** | *By state* (opened/merged/closed/locked) · *Merged — elapsed time* · *Merged per author* |
| 5 | **Issue List** | every closed issue, **newest closed date first** |
| 6 | **MR List** | every merged MR, **newest merged date first** |

The summary sheets carry the monthly tables only; the full lists live on their own sheets, so a long
detail table never pushes the summaries out of view.

The HTML page carries the same content and the same chart, with sortable and filterable tables and
the same green/red shift colouring.

*From opened* covers issues measured from the iteration assignment, or from creation where no
iteration was ever assigned. *By state* lists every state for visibility, but **counts everywhere
else consider merged only** — an abandoned MR is not delivered work.

Both detail tables list **every** closed issue and merged MR in the window, newest first, **flagged
or not**, with the iteration, epic, folder trail and a direct link.

## Files

| File | Purpose |
|---|---|
| `crew_settings.py` | Configuration, secret resolution, logging. |
| `crew_gitlab.py` | GitLab client — recursive project discovery, issues, MRs, iterations, parallel fetching. |
| `crew_metrics.py` | The four parameters, cycle-time tiers, baseline, aspiration, shift. |
| `crew_charts.py` | The dashboard figure. |
| `crew_output.py` | XLSX and HTML generation, with the chart embedded in both. |
| `crew_greenplum.py` | Table creation, grants, and the incremental load. |
| `crew_main.py` | `run_crew_report()` — the single entry point used by both the notebook and the DAG. |
| `airflow_dag_crew_delivery_report.py` | Airflow DAG (19:00 EST, Mon–Fri). |
| `run_crew_report.ipynb` | Notebook. |

All modules share the `crew_` prefix deliberately. Airflow puts the DAGs folder on `sys.path`, so a
bare `settings.py` or `main.py` could collide with another DAG's module; the prefix keeps them
distinct without needing a package.

### Environment variables

The `CREW_*` names are current. Anything already configured with the older `P7_*` prefix still works
— the lookup falls back to it — so an existing Airflow setup does not need changing on the same day
as the rename.


# Performance

The cost of this job is almost entirely **HTTP round trips**, not computation. Each issue needs its
label history (and sometimes its iteration history) and each merge request needs its commits — one
request each. Done sequentially that is thousands of trips spent waiting on the network.

Three changes make it fast:

**1. Parallel fetching.** Lists are gathered first, then all the detail calls are issued through a
thread pool. Each thread keeps its own session and the connection pool is sized to the worker count,
so connections are reused rather than renegotiated per request.

Measured on a simulated 12 ms round trip, 8 projects, 21 months (1,866 API calls):

| Workers | Time | |
|---|---|---|
| 1 | 23.0s | sequential — the old behaviour |
| 4 | 5.8s | |
| **12** | **2.1s** | **default — 11x faster** |
| 24 | 1.0s | |

Results are **byte-identical** at every worker count — verified by comparing the full issue and MR
signatures from a 1-worker run against a 12-worker run.

Tune with `CREW_MAX_WORKERS` (default **24**). Lower it if the instance starts returning 429s — the
client already retries those with backoff, but sustained rate limiting is worth avoiding.

### What a full first load actually costs

A real crew-wide run measured roughly **20,000 API calls**:

| Phase | Calls |
|---|---|
| label history | 7,523 |
| iteration history | 3,218 |
| commit history | 8,976 |

That is the irreducible shape of the problem — every issue needs its history and every merge request
needs its commits. Parallelism divides the wall-clock time; it cannot remove the calls.

**This is a one-off.** Every run after the first fetches the current month only (see the incremental
strategy below), which is a few hundred calls rather than twenty thousand. Budget several minutes for
the initial load and seconds thereafter.

### Progress reporting

Every phase reports steadily with elapsed time, rate and an ETA:

```
    commit history 2000/8976  (48s elapsed, 42/s, ~166s left)
```

The cadence adapts to the batch size — roughly a twentieth of the total. An earlier fixed interval of
250 meant a 148-project phase printed nothing until it finished, which looked like a hang when it was
simply working.

**2. Iteration history is only fetched when needed.** Issues that already have an in-progress
transition never trigger that second call, so it costs nothing for the majority of issues.

**3. Large merge requests skip intermediate pages.** Only the earliest commit matters, and GitLab
returns commits newest-first — so for an MR with more than 100 commits the page count is read from
the response header and the last page fetched directly, rather than walking every page in between.
Small MRs, the overwhelming majority, still cost exactly one request.

**4. The DAG collects once, not twice.** An earlier version split collection and the database load
across two tasks, and each called the full pipeline — doubling the slowest part of the job for no
benefit. It is now a single pass, with the reports written before the load so a Greenplum failure
still leaves the XLSX and HTML on disk.

Combined with the incremental fetch below, a **daily run touches GitLab for one month only** and
issues those calls in parallel — the difference between minutes and seconds.

---

# Greenplum

**Schema:** `sandbox_prj_smart_insights` (`CREW_GP_SCHEMA` to change)

The schema is **assumed to already exist** — the code does not create it, since that would need
rights this account should not have.

## Ownership and grants

After creating each table, these run automatically:

```sql
ALTER TABLE <schema>.<table> OWNER TO <owner_group>;
GRANT SELECT ON <schema>.<table> TO <reader_group>;
```

| | Setting | Notebook default |
|---|---|---|
| owner | `IKG_TABLE_OWNER_GROUP` | `erd_gpdb_prj_smart_insights` |
| reader | `IKG_TABLE_READER_GROUP` | `erd_gpdb_prj_smart_insights_ro` |

In Airflow, set those as Variables to whatever `{{params.IKG_TABLE_OWNER_GROUP}}` and
`{{params.IKG_TABLE_READER_GROUP}}` resolve to for your environment.

They are re-applied on **every** run, not just at creation — cheap, idempotent, and it means a table
created by hand or restored from backup still ends up with the right grants. A permissions failure
here is logged and rolled back on its own, so it can never cost you the data load.

## Tables

### `crew_issue_detail` — one row per closed issue

`month_key`, `issue_iid`, `project_path`, `folders`, `title`, `author_name`, `assignee_name`,
`measured_from`, `start_at`, `closed_at`, `cycle_time_days`, `is_flagged`, `iteration_name`,
`iteration_start_date`, `iteration_end_date`, `epic_id`, `epic_name`, `web_url`, `load_timestamp`

### `crew_mr_detail` — one row per merged MR

`month_key`, `mr_iid`, `project_path`, `folders`, `title`, `author_name`, `first_commit_at`,
`merged_at`, `lead_time_hours`, `is_flagged`, `web_url`, `load_timestamp`

### `crew_issue_monthly_summary`

`month_key`, `is_baseline_month`, `issue_throughput`, `cycle_time_days`, `issues_flagged`,
`measured_from_in_progress`, `measured_from_iteration`, `measured_from_created`,
`throughput_shift_pct`, `cycle_time_shift_pct`, `load_timestamp`

### `crew_mr_monthly_summary`

`month_key`, `is_baseline_month`, `merged_mr_count`, `author_count`, `merged_mr_per_author`,
`lead_time_hours`, `mrs_flagged`, `mr_per_author_shift_pct`, `lead_time_shift_pct`,
`load_timestamp`

## Load strategy — the database is the system of record for history

History does not change; the current month does. So the run is incremental at the **fetch** level,
not just the write level:

| Run | GitLab scan | Database |
|---|---|---|
| **First** | all months in the window | tables created, every month written |
| **Every run after** | **the current month only** | current month deleted and rewritten; settled months **read back** |

Settled months are never re-scanned. Walking every project under the crew for twenty-one months is
by far the most expensive part of the job, and once a month has closed its numbers cannot change —
so the report rebuilds the full Nov-24 → Jul-26 window by **reading settled months back out of these
tables** and fetching only what is still moving.

The `updated_after` sent to GitLab moves with it: `2024-11-01` on the first run, `2026-07-01` on
every run afterwards.

`crew_issue_monthly_summary` is the authority on what has been loaded — **not** the detail tables. A
month in which the crew closed nothing still gets a summary row, whereas it would leave no detail
rows and would otherwise be re-fetched forever.

The decision comes from the table itself, not a marker file or a run log, so it stays correct if a
run is interrupted or the tables are truncated by hand. If Greenplum is unreachable, or the tables do
not exist yet, the run falls back to fetching the full history rather than failing.

Inserts use `COPY` — one round trip rather than one per row — inside a transaction that rolls back on
failure, so a failed load never leaves partial data.

### Forcing a full refresh

After changing a metric definition, stored history is no longer comparable with newly collected
months. Re-fetch and rewrite everything with:

```python
run_crew_report(settings, force_full_refresh=True)
```

**Verified:** run 1 fetched 21 months from GitLab and wrote all of them. Run 2 asked GitLab only for
`2026-07`, read the other 20 back from the database, produced the **identical** full-window report
(same issue and MR totals), and rewrote only the current month.

---

# Configuration

Everything is an environment variable or an Airflow Variable.

| Setting | Default |
|---|---|
| `CREW_CREW_NAME` | STAAT Data Science |
| `CREW_ISSUE_GROUP` | `ubs/…/staat-data-science` |
| `CREW_MR_GROUP` | `ubs/…/staat-ds-genesis/genesis-platform` |
| `CREW_START_MONTH` / `CREW_END_MONTH` | 2024-11 / 2026-07 |
| `CREW_BASELINE_MONTH` | 2025-11 |
| `CREW_POD_COUNT` | 9 |
| `CREW_BASELINE_WINDOW_MONTHS` | 3 |
| `CREW_ISSUE_SLOWEST_TRIM_PCT` | 15 |
| `CREW_ISSUE_SLA_DAYS` / `CREW_MR_SLA_HOURS` | 5 / 72 |
| `CREW_TARGET_GAIN_PCT` / `CREW_TARGET_MONTHS` | 20 / 14 |
| `CREW_IN_PROGRESS_LABELS` | `in progress,in-progress,doing,wip` |
| `CREW_MAX_WORKERS` | 24 |
| `CREW_GP_SCHEMA` | sandbox_prj_smart_insights |
| `IKG_TABLE_OWNER_GROUP` | erd_gpdb_prj_smart_insights |
| `IKG_TABLE_READER_GROUP` | erd_gpdb_prj_smart_insights_ro |
| `CREW_LOAD_GP` | true |

**Secrets** — never hard-coded, resolved as env → Airflow Variable → prompt (notebook only):

| | Airflow Variable |
|---|---|
| GitLab token | `GENESIS_DDLC_IKG_GIT_SECRET` |
| Greenplum password | `GREENPLUM_PASSWORD` |

## Running it

**Notebook** — open `run_crew_report.ipynb`, run the cells; it prompts for both credentials.

**Airflow** — deploy the DAG beside the `crew_*.py` files. Two tasks:
`collect_and_report → summarise`. Collection, reporting and the load happen in a single pass; the
reports are written before the load, so a Greenplum failure still leaves the XLSX and HTML on disk.

To skip the database entirely: `settings.load_to_greenplum = False`, or `CREW_LOAD_GP=false`.

## Adjusting the in-progress labels

`Cycle Time` depends on recognising the in-progress transition. The defaults match
`in progress`, `in-progress`, `doing`, `wip` — case-insensitive, and scoped forms like
`workflow::In progress` work too. If the crew's board uses different names, set
`CREW_IN_PROGRESS_LABELS`. The `measured_from_in_progress` / `measured_from_iteration` counts in the
monthly summary tell you how well the match is working: if almost everything is falling through to
`iteration`, the labels are probably wrong.

## Validation performed

Tested end-to-end with a mocked GitLab across 21 months and multiple projects:

- **Recursive discovery** — projects from several sub-group depths were scanned, and the folder trail
  rendered as `staat-ds-genesis | genesis-platform | nlg-dags` relative to the crew group.
- **Cycle-time priority** — verified with three issues closed at the same instant: one with both an
  in-progress transition and an *earlier* iteration assignment resolved to `in_progress` (tier 1
  wins); one with no in-progress resolved to `iteration_assigned`; one with neither resolved to
  `created`.
- **Iteration naming** — an iteration with a null title resolved to its cadence name
  (`STAAT DS insight iteration`) rather than `Iteration 4207`; title plus cadence combined; a
  nameless iteration fell back to its date range.
- **Windowed chart** — 21 months produced 19 windows starting `Nov 24-Jan 25`, `Dec 24-Feb 25`,
  `Jan 25-Mar 25`. At the `Nov 25-Jan 26` anchor, actual == aspiration == baseline for all four
  parameters and the overall gain read exactly 0.00%. The plotted aspiration line's first point sits
  at the anchor index on every panel, with nothing before it.
- **Scope rules** — of 252 closed issues, 147 were in scope: 84 excluded for never reaching in
  progress and 21 as the slowest 15% of their month (one per month, correctly skipping months with
  too few issues). Of 105 merged MRs, 84 were in scope and 21 excluded for a lead time over a year.
  Asserted that every in-scope issue is `in_progress`-based and every in-scope MR is under the
  one-year limit, and that the monthly counts reconcile (`in scope + out of scope = total`).
- **Per-pod throughput** — 18, 27, 9 and 36 closed issues over four months divided by 9 pods gave
  2.0, 3.0, 1.0 and 4.0; the raw counts remain on the Issues sheet.
- **Three-month baseline** — `baseline = mean(2.0, 3.0, 1.0) = 2.0`, computed per metric, with a
  later month of 4.0 reading `+100.0%`. Exactly the three baseline months carry the highlight in
  every sheet of the workbook and in the HTML.
- **Business days** — `Mon 9am → Thu 9am` = 3.00; `Fri 3pm → Mon 9am` = **0.75** (not 2.75); a full
  weekend = **0.00**; `Mon → next Mon` = 5.00.
- **Baseline anchoring** — aspiration equals actual at the baseline for all four parameters, is blank
  before it, and the shift at the baseline is exactly 0%.
- **Overall gain** — equals the plain mean of the four parameter shifts.
- **Outputs** — workbook with 4 sheets and the chart embedded on *Dashboard*; baseline row
  highlighted; HTML with the chart base64-inlined, 4 sortable/filterable tables and working links.
- **Greenplum incremental load** — first run 21 months, second run only the current month, with
  identical totals both times.
- **Parallel correctness** — a 12-worker run produced output byte-identical to a 1-worker run
  (same counts, same `measured_from` mix, same cycle times and flags).
