"""
GitLab access for the crew report.

Two things distinguish this from a per-project client:

**Recursive discovery.** Projects are not listed anywhere in configuration.
The crew's issue group and MR group are scanned with `include_subgroups`,
so every project in every sub-group beneath them is found automatically and
new repositories appear in the report without a config change.

**Full context per item.** Each issue carries the state history needed to
work out when it actually started (label events for "in progress",
iteration events for when it was scheduled), plus its iteration and epic.
Each merge request carries its commits, so the first file check-in can be
found.

**Parallel by default.** That per-item context is the whole cost of the
run: one HTTP round trip per issue for its label history, another for
iteration history where needed, and one per merge request for its commits.
Done sequentially that is thousands of round trips end to end, and it is
almost entirely waiting on the network rather than doing work -- so the
calls are issued from a thread pool. Each thread keeps its own session, and
the connection pool is sized to match, so connections are reused instead of
being renegotiated per request.
"""
from __future__ import annotations

import threading
import urllib.parse
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Callable, Dict, Iterable, List, Optional

from p7_settings import get_logger

log = get_logger("p7.gitlab")


def parallel_map(fn: Callable, items: Iterable, workers: int, progress=None,
                 label: str = "", every: int = 250) -> List:
    """Runs `fn` over `items` in a thread pool, preserving input order.

    Progress is reported every `every` completions rather than per item --
    with thousands of tasks, per-item logging costs more than the work and
    floods the Airflow log.
    """
    items = list(items)
    if not items:
        return []
    if workers <= 1 or len(items) == 1:
        return [fn(x) for x in items]

    out = [None] * len(items)
    done = 0
    with ThreadPoolExecutor(max_workers=workers) as ex:
        futs = {ex.submit(fn, it): i for i, it in enumerate(items)}
        for fut in as_completed(futs):
            i = futs[fut]
            try:
                out[i] = fut.result()
            except Exception as e:
                log.error("%s task %d failed: %s", label or "parallel", i, e)
                out[i] = None
            done += 1
            if progress and (done % every == 0 or done == len(items)):
                progress("    %s %d/%d" % (label or "done", done, len(items)))
    return out


class GitLabClient:
    def __init__(self, settings, workers: Optional[int] = None):
        import requests
        self._r = requests
        self.s = settings
        self.base = settings.gitlab_url.rstrip("/")
        self.workers = int(workers or getattr(settings, "max_workers", 12))
        self._local = threading.local()
        self._gid: Dict[str, int] = {}
        self._gid_lock = threading.Lock()
        log.info("GitLab client ready for %s (%d worker(s))", self.base, self.workers)

    @property
    def _sess(self):
        """One session per thread, with the pool sized to the worker count.

        A shared session would serialise on its connection pool and give
        back much of the parallelism; a fresh session per request would pay
        a new TLS handshake every time.
        """
        s = getattr(self._local, "sess", None)
        if s is None:
            from requests.adapters import HTTPAdapter
            try:
                from urllib3.util.retry import Retry
                retry = Retry(total=3, backoff_factor=0.6,
                              status_forcelist=[429, 500, 502, 503, 504],
                              allowed_methods=frozenset(["GET"]))
            except Exception:
                retry = 3
            s = self._r.Session()
            s.headers.update({"PRIVATE-TOKEN": self.s.gitlab_token})
            ad = HTTPAdapter(pool_connections=self.workers, pool_maxsize=self.workers * 2,
                             max_retries=retry)
            s.mount("https://", ad)
            s.mount("http://", ad)
            self._local.sess = s
        return s

    # ------------------------------------------------------------------ core
    def _get(self, path, params=None, allow_404=False):
        r = self._sess.get(self.base + "/api/v4" + path, params=params or {}, timeout=90)
        if r.status_code == 404 and allow_404:
            return None
        if r.status_code in (401, 403):
            log.warning("%s on %s -- token may lack access; treating as empty.",
                        r.status_code, path)
            return None
        r.raise_for_status()
        return r.json()

    def _paged(self, path, params=None, max_pages=200) -> List[dict]:
        out, page = [], 1
        params = dict(params or {})
        params.setdefault("per_page", 100)
        while page <= max_pages:
            params["page"] = page
            batch = self._get(path, params)
            if not batch:
                break
            out.extend(batch)
            if len(batch) < params["per_page"]:
                break
            page += 1
        if page > max_pages:
            log.warning("Hit the %d-page cap on %s -- results may be partial.", max_pages, path)
        return out

    def group_id(self, path: str) -> Optional[int]:
        with self._gid_lock:
            if path in self._gid:
                return self._gid[path]
        data = self._get("/groups/" + urllib.parse.quote(path, safe=""), allow_404=True)
        if not data:
            log.error("Group not found or not accessible: %s", path)
            return None
        with self._gid_lock:
            self._gid[path] = data["id"]
        log.info("Group '%s' -> id %s", path, data["id"])
        return data["id"]

    # ------------------------------------------------------- discovery
    def discover_projects(self, group_path: str) -> List[dict]:
        """Every project beneath `group_path`, at any depth.

        Archived projects are excluded: they are not active work, and
        including them would inflate historical months with repositories
        the crew no longer runs.
        """
        gid = self.group_id(group_path)
        if gid is None:
            return []
        projects = self._paged("/groups/%s/projects" % gid,
                               {"include_subgroups": "true", "archived": "false",
                                "with_shared": "false", "order_by": "path", "sort": "asc"})
        log.info("Discovered %d project(s) beneath '%s'.", len(projects), group_path)
        for p in projects:
            log.debug("   %s", p.get("path_with_namespace"))
        return projects

    # ------------------------------------------------------------ issues
    def closed_issues(self, project_id: int, updated_after: str) -> List[dict]:
        return self._paged("/projects/%s/issues" % project_id,
                           {"state": "closed", "updated_after": updated_after,
                            "scope": "all", "order_by": "updated_at", "sort": "desc"}) or []

    def issue_label_events(self, project_id: int, iid: int) -> List[dict]:
        return self._paged("/projects/%s/issues/%s/resource_label_events" % (project_id, iid)) or []

    def issue_iteration_events(self, project_id: int, iid: int) -> List[dict]:
        """When an iteration was added to the issue -- this is what the crew
        treats as the issue being 'opened' for cycle-time purposes when no
        in-progress transition exists."""
        return self._paged(
            "/projects/%s/issues/%s/resource_iteration_events" % (project_id, iid)) or []

    def issue_state_events(self, project_id: int, iid: int) -> List[dict]:
        return self._paged("/projects/%s/issues/%s/resource_state_events" % (project_id, iid)) or []

    # ---------------------------------------------------- merge requests
    def merged_requests(self, project_id: int, updated_after: str) -> List[dict]:
        """MERGED merge requests only.

        Opened, closed-without-merging and locked ones are excluded
        entirely: the crew's lead-time measure is about delivered code, and
        an abandoned branch never delivered anything.
        """
        mrs = self._paged("/projects/%s/merge_requests" % project_id,
                          {"state": "merged", "updated_after": updated_after,
                           "scope": "all", "order_by": "updated_at", "sort": "desc"}) or []
        return [m for m in mrs if str(m.get("state", "")).lower() == "merged"]

    def mr_commits(self, project_id: int, iid: int) -> List[dict]:
        return self._paged("/projects/%s/merge_requests/%s/commits" % (project_id, iid)) or []

    # ------------------------------------------------------------- epics
    def epic(self, group_id: int, epic_iid: int) -> Optional[dict]:
        return self._get("/groups/%s/epics/%s" % (group_id, epic_iid), allow_404=True)


def folder_trail(project_path: str, base_group: str, sep: str = " | ") -> str:
    """The sub-group trail from the crew group down to the project.

    `.../staat-data-science/staat-ds-genesis/genesis-platform/nlg-dags`
    against base `.../staat-data-science`
    becomes `staat-ds-genesis | genesis-platform | nlg-dags`.

    Falls back to the full path when the project sits outside the base
    group, so nothing is silently blanked.
    """
    p = (project_path or "").strip("/")
    b = (base_group or "").strip("/")
    rel = p[len(b):].strip("/") if b and p.startswith(b) else p
    return sep.join([x for x in rel.split("/") if x])
