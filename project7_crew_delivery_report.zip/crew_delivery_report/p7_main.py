"""
Orchestration for the crew delivery report.

One entry point, `run_crew_report(settings)`, used identically by the
notebook and the Airflow DAG:

  1. ask Greenplum which months are already loaded
  2. fetch from GitLab ONLY what is missing -- normally just the current
     month -- and read the settled months back from the database
  3. summarise per month, and build the baseline / aspiration series
  4. render the dashboard chart once, and embed that same image in both
     the workbook and the web page
  5. write back only the months that were fetched

Step 1 is what makes a daily run cheap. Scanning every project under the
crew for twenty-one months is the expensive part; once history is loaded it
never needs doing again, because settled months cannot change. Only the
current month is re-fetched, because it is still being written.

The chart is rendered before the outputs on purpose: both deliverables
embed the identical PNG, so the workbook and the page can never disagree.
"""
from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from p7_charts import build_figure, save_png
from p7_gitlab import GitLabClient
from p7_metrics import build_series, collect, month_range, monthly_stats
from p7_output import write_html, write_xlsx
from p7_settings import get_logger

log = get_logger("p7.main")


@dataclass
class RunResult:
    crew: str
    months: List[str]
    current_month: str
    issues: List = field(default_factory=list)
    mrs: List = field(default_factory=list)
    stats: Dict = field(default_factory=dict)
    series: object = None
    xlsx_path: str = ""
    html_path: str = ""
    chart_path: str = ""
    greenplum: Optional[dict] = None
    months_fetched: List[str] = field(default_factory=list)
    months_from_db: List[str] = field(default_factory=list)


def run_crew_report(settings, progress=None, now: Optional[_dt.datetime] = None,
                    force_full_refresh: bool = False) -> RunResult:
    """Set `force_full_refresh=True` to re-fetch and rewrite every month --
    use it after changing a metric definition, when stored history would no
    longer be comparable with newly collected months."""
    def say(m):
        log.info(m)
        if progress:
            progress(m)

    now = now or _dt.datetime.now(_dt.timezone.utc)
    months = month_range(settings.start_month, settings.end_month)
    current_month = min(now.strftime("%Y-%m"), months[-1])
    say("Crew '%s': %d month(s) %s to %s, baseline %s, current month %s"
        % (settings.crew_name, len(months), months[0], months[-1],
           settings.baseline_month, current_month))

    # ---- decide what actually needs fetching -------------------------
    already: set = set()
    if settings.load_to_greenplum and not force_full_refresh:
        from p7_greenplum import loaded_months
        already = loaded_months(settings)

    eligible = [m for m in months if m <= current_month]
    # the current month always re-fetches; anything not already stored must
    # be fetched at least once
    to_fetch = [m for m in eligible if m == current_month or m not in already]
    from_db = [m for m in eligible if m not in to_fetch]

    if from_db:
        say("Reusing %d settled month(s) from Greenplum; fetching %d month(s) from GitLab: %s"
            % (len(from_db), len(to_fetch), ", ".join(to_fetch)))
    else:
        say("No stored history found -- fetching all %d month(s) from GitLab. This is the "
            "one-off full load; later runs will only fetch the current month."
            % len(to_fetch))

    client = GitLabClient(settings)
    issues, mrs = collect(client, settings, to_fetch, progress=progress)

    if from_db:
        from p7_greenplum import read_detail
        old_i, old_m = read_detail(settings, from_db)
        issues = old_i + issues
        mrs = old_m + mrs
        say("Combined: %d issue(s) and %d merge request(s) across the full window."
            % (len(issues), len(mrs)))

    stats = monthly_stats(issues, mrs, months)
    ser = build_series(stats, months, settings)
    say("Overall productivity gain vs baseline: %s%%" % ser.overall_gain)

    chart = save_png(build_figure(ser, settings.crew_name), settings.output_dir,
                     "crew_dashboard")
    xlsx = write_xlsx(settings, ser, stats, months, issues, mrs, chart, current_month,
                      settings.output_dir)
    html = write_html(settings, ser, stats, months, issues, mrs, chart, current_month,
                      settings.output_dir)
    say("XLSX: %s" % xlsx)
    say("HTML: %s" % html)

    gp = None
    if settings.load_to_greenplum:
        from p7_greenplum import load
        gp = load(settings, ser, stats, months, issues, mrs, current_month,
                  progress=progress, fetched_months=to_fetch)
    else:
        say("Greenplum load skipped (load_to_greenplum = False).")

    return RunResult(crew=settings.crew_name, months=months, current_month=current_month,
                     issues=issues, mrs=mrs, stats=stats, series=ser,
                     xlsx_path=xlsx, html_path=html, chart_path=chart, greenplum=gp,
                     months_fetched=to_fetch, months_from_db=from_db)
