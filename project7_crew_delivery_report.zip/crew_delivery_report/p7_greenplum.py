"""
Greenplum persistence.

Four tables, all lower_snake_case:

    crew_issue_detail            one row per closed issue, flagged or not
    crew_mr_detail               one row per merged MR, flagged or not
    crew_issue_monthly_summary   the issue parameters per month
    crew_mr_monthly_summary      the MR parameters per month

**Load strategy.** History does not change, but the current month does --
it is still being written as the month runs. So:

    * settled months are collected from GitLab and loaded ONCE. On every
      later run they are READ BACK FROM THESE TABLES instead, so a daily
      job neither re-scans twenty months of GitLab nor rewrites history.
      That is the expensive part of the run, and it is skipped entirely.
    * the CURRENT month is re-fetched, deleted and reloaded on every run,
      because its numbers move until the month ends.

`crew_issue_monthly_summary` is the authority on what has been loaded, not
the detail tables: a month in which the crew closed nothing still gets a
summary row, whereas it would leave no detail rows at all and would
otherwise be re-fetched forever.

The decision is made from what is actually in the table (`SELECT DISTINCT
month_key`), not from a marker file or a run log, so it stays correct even
if a run is interrupted half way or the tables are truncated by hand.

Inserts use COPY rather than row-by-row execute: a single round trip
instead of one per row, which matters once the detail tables run to
thousands of issues.
"""
from __future__ import annotations

import csv
import io
from typing import Dict, List, Optional, Sequence

from p7_metrics import METRIC_DEFS
from p7_settings import get_logger

log = get_logger("p7.greenplum")

ISSUE_DETAIL_COLS = [
    ("month_key", "varchar(7)"), ("issue_iid", "integer"), ("project_path", "varchar(500)"),
    ("folders", "varchar(500)"), ("title", "varchar(1000)"), ("author_name", "varchar(200)"),
    ("assignee_name", "varchar(200)"), ("measured_from", "varchar(30)"),
    ("start_at", "timestamp"), ("closed_at", "timestamp"), ("cycle_time_days", "numeric(12,2)"),
    ("is_flagged", "boolean"), ("iteration_name", "varchar(300)"),
    ("iteration_start_date", "varchar(20)"), ("iteration_end_date", "varchar(20)"),
    ("epic_id", "varchar(50)"), ("epic_name", "varchar(500)"), ("web_url", "varchar(1000)"),
    ("load_timestamp", "timestamp"),
]

MR_DETAIL_COLS = [
    ("month_key", "varchar(7)"), ("mr_iid", "integer"), ("project_path", "varchar(500)"),
    ("folders", "varchar(500)"), ("title", "varchar(1000)"), ("author_name", "varchar(200)"),
    ("first_commit_at", "timestamp"), ("merged_at", "timestamp"),
    ("lead_time_hours", "numeric(12,2)"), ("is_flagged", "boolean"),
    ("web_url", "varchar(1000)"), ("load_timestamp", "timestamp"),
]

ISSUE_SUMMARY_COLS = [
    ("month_key", "varchar(7)"), ("is_baseline_month", "boolean"),
    ("issue_throughput", "integer"), ("cycle_time_days", "numeric(12,2)"),
    ("issues_flagged", "integer"), ("measured_from_in_progress", "integer"),
    ("measured_from_iteration", "integer"), ("measured_from_created", "integer"),
    ("throughput_shift_pct", "numeric(12,2)"), ("cycle_time_shift_pct", "numeric(12,2)"),
    ("load_timestamp", "timestamp"),
]

MR_SUMMARY_COLS = [
    ("month_key", "varchar(7)"), ("is_baseline_month", "boolean"),
    ("merged_mr_count", "integer"), ("author_count", "integer"),
    ("merged_mr_per_author", "numeric(12,2)"), ("lead_time_hours", "numeric(12,2)"),
    ("mrs_flagged", "integer"), ("mr_per_author_shift_pct", "numeric(12,2)"),
    ("lead_time_shift_pct", "numeric(12,2)"), ("load_timestamp", "timestamp"),
]


def _connect(settings):
    import psycopg2
    log.info("Connecting to Greenplum %s:%s/%s as %s",
             settings.gp_host, settings.gp_port, settings.gp_db, settings.gp_user)
    return psycopg2.connect(host=settings.gp_host, port=settings.gp_port,
                            dbname=settings.gp_db, user=settings.gp_user,
                            password=settings.gp_password, connect_timeout=30)


def _ddl(schema: str, table: str, cols) -> str:
    body = ",\n  ".join("%s %s" % (n, t) for n, t in cols)
    return "CREATE TABLE IF NOT EXISTS %s.%s (\n  %s\n)" % (schema, table, body)


def _existing_months(cur, schema: str, table: str) -> set:
    cur.execute("SELECT DISTINCT month_key FROM %s.%s" % (schema, table))
    return {r[0] for r in cur.fetchall() if r[0]}


def _copy(cur, schema: str, table: str, cols, rows: List[Sequence]) -> int:
    if not rows:
        return 0
    buf = io.StringIO()
    w = csv.writer(buf, quoting=csv.QUOTE_MINIMAL, lineterminator="\n")
    for r in rows:
        w.writerow(["" if v is None else v for v in r])
    buf.seek(0)
    names = ", ".join(n for n, _t in cols)
    cur.copy_expert("COPY %s.%s (%s) FROM STDIN WITH (FORMAT csv, NULL '')"
                    % (schema, table, names), buf)
    return len(rows)


def _ts(d):
    return d.strftime("%Y-%m-%d %H:%M:%S") if d else None


def _table_exists(cur, schema: str, table: str) -> bool:
    cur.execute("SELECT 1 FROM information_schema.tables "
                "WHERE table_schema = %s AND table_name = %s", (schema, table))
    return cur.fetchone() is not None


def loaded_months(settings) -> set:
    """Months already persisted, judged from the issue summary table.

    Returns an empty set (rather than raising) when the schema or tables do
    not exist yet, or when the database cannot be reached -- a first run,
    or an unreachable database, should fall back to fetching everything
    from GitLab rather than failing.
    """
    try:
        conn = _connect(settings)
    except Exception as e:
        log.warning("Greenplum unreachable (%s) -- treating every month as not yet loaded, "
                    "so this run will fetch the full history from GitLab.", e)
        return set()
    try:
        cur = conn.cursor()
        if not _table_exists(cur, settings.gp_schema, settings.tbl_issue_summary):
            log.info("%s.%s does not exist yet -- first run, full history will be fetched.",
                     settings.gp_schema, settings.tbl_issue_summary)
            return set()
        months = _existing_months(cur, settings.gp_schema, settings.tbl_issue_summary)
        log.info("%d month(s) already loaded in Greenplum.", len(months))
        return months
    except Exception as e:
        log.warning("Could not read loaded months (%s) -- will fetch the full history.", e)
        return set()
    finally:
        conn.close()


def _fetch(cur, schema, table, cols, months):
    names = ", ".join(n for n, _t in cols)
    cur.execute("SELECT %s FROM %s.%s WHERE month_key = ANY(%%s)" % (names, schema, table),
                (list(months),))
    return [dict(zip([n for n, _t in cols], r)) for r in cur.fetchall()]


def read_detail(settings, months):
    """Rebuilds IssueRow / MRRow objects for already-loaded months.

    This is what makes the incremental run cheap: settled months come back
    from the database in one query each, instead of re-walking every project
    in GitLab for twenty months of history.
    """
    from p7_metrics import IssueRow, MRRow, parse_ts
    if not months:
        return [], []
    conn = _connect(settings)
    try:
        cur = conn.cursor()
        if not _table_exists(cur, settings.gp_schema, settings.tbl_issue_detail):
            return [], []
        irows = _fetch(cur, settings.gp_schema, settings.tbl_issue_detail,
                       ISSUE_DETAIL_COLS, months)
        mrows = _fetch(cur, settings.gp_schema, settings.tbl_mr_detail, MR_DETAIL_COLS, months)
    finally:
        conn.close()

    def _as_dt(v):
        return v if hasattr(v, "year") else parse_ts(v)

    issues = [IssueRow(
        project_path=r["project_path"] or "", folders=r["folders"] or "",
        iid=r["issue_iid"], title=r["title"] or "", author=r["author_name"] or "",
        assignee=r["assignee_name"] or "", month=r["month_key"],
        measured_from=r["measured_from"] or "", start_at=_as_dt(r["start_at"]),
        closed_at=_as_dt(r["closed_at"]),
        cycle_days=float(r["cycle_time_days"]) if r["cycle_time_days"] is not None else None,
        flagged=bool(r["is_flagged"]), iteration_name=r["iteration_name"] or "",
        iteration_start=r["iteration_start_date"] or "", iteration_end=r["iteration_end_date"] or "",
        epic_id=r["epic_id"] or "", epic_name=r["epic_name"] or "",
        web_url=r["web_url"] or "") for r in irows]

    mrs = [MRRow(
        project_path=r["project_path"] or "", folders=r["folders"] or "", iid=r["mr_iid"],
        title=r["title"] or "", author=r["author_name"] or "",
        month=r["month_key"], first_commit_at=_as_dt(r["first_commit_at"]),
        merged_at=_as_dt(r["merged_at"]),
        lead_hours=float(r["lead_time_hours"]) if r["lead_time_hours"] is not None else None,
        flagged=bool(r["is_flagged"]), web_url=r["web_url"] or "") for r in mrows]

    log.info("Read back from Greenplum: %d issue(s) and %d merge request(s) across %d "
             "settled month(s).", len(issues), len(mrs), len(months))
    return issues, mrs


def load(settings, ser, stats, months: List[str], issues, mrs,
         current_month: str, progress=None, fetched_months=None) -> Dict[str, object]:
    """Creates the tables if needed and writes the months that were fetched
    this run -- which is normally just the current month.

    `fetched_months` is what the caller actually pulled from GitLab. Passing
    it keeps the write set identical to the fetch set, so a month that was
    read back from the database is never rewritten with the same rows it
    came from.
    """
    def say(m):
        log.info(m)
        if progress:
            progress(m)

    import datetime as _dt
    now = _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    schema = settings.gp_schema
    result = {"schema": schema, "tables": {}, "months_loaded": [], "months_skipped": [],
              "current_month_reloaded": current_month}

    # only months up to and including the current one are eligible
    eligible = [m for m in months if m <= current_month]

    conn = _connect(settings)
    try:
        conn.autocommit = False
        cur = conn.cursor()
        cur.execute("CREATE SCHEMA IF NOT EXISTS %s" % schema)

        specs = [
            (settings.tbl_issue_detail, ISSUE_DETAIL_COLS),
            (settings.tbl_mr_detail, MR_DETAIL_COLS),
            (settings.tbl_issue_summary, ISSUE_SUMMARY_COLS),
            (settings.tbl_mr_summary, MR_SUMMARY_COLS),
        ]
        for tbl, cols in specs:
            cur.execute(_ddl(schema, tbl, cols))
        conn.commit()
        say("Schema and %d table(s) ready in %s." % (len(specs), schema))

        # write exactly what was fetched; fall back to computing it if the
        # caller did not say
        if fetched_months is not None:
            to_load = [m for m in eligible if m in set(fetched_months)]
        else:
            present = _existing_months(cur, schema, settings.tbl_issue_summary)
            to_load = [m for m in eligible if m == current_month or m not in present]
        skipped = [m for m in eligible if m not in to_load]
        result["months_loaded"], result["months_skipped"] = to_load, skipped
        say("Months already loaded: %d. To load now: %d (of which the current month, %s, is "
            "always reloaded)." % (len(skipped), len(to_load), current_month))
        if skipped:
            log.info("Skipping settled months: %s", ", ".join(skipped))

        load_set = set(to_load)
        idx = {m: i for i, m in enumerate(months)}

        # remove anything we are about to rewrite
        for tbl, _cols in specs:
            cur.execute("DELETE FROM %s.%s WHERE month_key = ANY(%%s)" % (schema, tbl),
                        (list(load_set),))
        conn.commit()

        # ---- detail rows ----
        irows = [[i.month, i.iid, i.project_path, i.folders, i.title, i.author, i.assignee,
                  i.measured_from, _ts(i.start_at), _ts(i.closed_at), i.cycle_days,
                  bool(i.flagged), i.iteration_name, i.iteration_start, i.iteration_end,
                  i.epic_id, i.epic_name, i.web_url, now]
                 for i in issues if i.month in load_set]
        mrows = [[m.month, m.iid, m.project_path, m.folders, m.title, m.author,
                  _ts(m.first_commit_at), _ts(m.merged_at), m.lead_hours, bool(m.flagged),
                  m.web_url, now]
                 for m in mrs if m.month in load_set]

        # ---- summary rows ----
        isum, msum = [], []
        for m in to_load:
            s = stats[m]
            i = idx[m]
            base = (m == settings.baseline_month)
            isum.append([m, base, s.throughput, s.cycle_time, s.issues_flagged,
                         s.from_in_progress, s.from_iteration, s.from_created,
                         ser.shift_pct["throughput"][i], ser.shift_pct["cycle_time"][i], now])
            msum.append([m, base, s.mr_count, s.author_count, s.mr_per_author, s.lead_time,
                         s.mrs_flagged, ser.shift_pct["mr_per_author"][i],
                         ser.shift_pct["lead_time"][i], now])

        for tbl, cols, rows in [
                (settings.tbl_issue_detail, ISSUE_DETAIL_COLS, irows),
                (settings.tbl_mr_detail, MR_DETAIL_COLS, mrows),
                (settings.tbl_issue_summary, ISSUE_SUMMARY_COLS, isum),
                (settings.tbl_mr_summary, MR_SUMMARY_COLS, msum)]:
            n = _copy(cur, schema, tbl, cols, rows)
            result["tables"][tbl] = n
            say("  %s.%s <- %d row(s)" % (schema, tbl, n))

        conn.commit()
        say("Greenplum load complete.")
        return result
    except Exception:
        conn.rollback()
        log.exception("Greenplum load failed and was rolled back -- no partial data was left "
                      "behind.")
        raise
    finally:
        conn.close()
