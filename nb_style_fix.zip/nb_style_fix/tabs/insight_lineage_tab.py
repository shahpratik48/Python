"""
insight_lineage_tab.py
──────────────────────
Dash tab: insight lineage using the exact same multi-tab style as
ikg_lineage_explorer.ipynb Cell 8 (vis-network 9.1.2, SCHEMA_COLORS, multi-tab
HTML with switchTab, per-graph nodeDetails).

HTML payload: single var ALL_INSIGHT_GRAPHS = []; placeholder.
Each array element:
  {profile_table, rule_column, insight_type,
   nodes, edges, nodeColors, edgeColors, schemasInGraph, nodeDetails}
"""
import json
import re
import urllib.parse
from collections import Counter
from pathlib import Path

import pandas as pd
from dash import Input, Output, dcc, html
from flask import request
from styles import metadata_dashboard_styles as mds
from utils.data import (
    get_all_insight_types,
    get_insight_column_lineage,
    get_insight_rule_meta,
)

# ── Exact SCHEMA_COLORS from ikg_lineage_explorer.ipynb ───────────────────
SCHEMA_COLORS = {
    'core_ikg': '#E74C3C',
    'ikg_schema': '#E74C3C',
    'sandbox_prj_smart_insights': '#E74C3C',
    'sandbox_ikg_pre_prd': '#E74C3C',
    'core_wma_shared': '#3498DB',
    'edw_view_input_schema': '#3498DB',
    'ikg_vendor_schema': '#3498DB',
    'sandbox_wma_shared': '#2ECC71',
    'sandbox_prj_ds_data': '#F39C12',
    'core_wma_shared_masked': '#1ABC9C',
    'sandbox_prj_sbl': '#9B59B6',
    'core_nlg': '#8E44AD',
    'nlg_schema': '#8E44AD',
    'core_model': '#E67E22',
    'model_schema': '#E67E22',
    'sandbox_prj_dsforoverdrive': '#3498DB',
    'edw_input_schema': '#5DADE2',
    'core_in_shared': '#EC7063',
    'ikg_clip_schema': '#EC7063',
    'sandbox_prj_adhoc': '#F1948A',
    'sandbox_prj_smart_relationship': '#48C9B0',
    'ikg_wealthx_schema': '#48C9B0',
    'sandbox_prj_rbat': '#52BE80',
}
SCHEMA_DISPLAY_NAMES = {
    'core_ikg': 'Core IKG',
    'core_wma_shared': 'Core WMA Shared',
    'sandbox_wma_shared': 'Sandbox WMA Shared',
    'sandbox_prj_ds_data': 'DS Data',
    'core_wma_shared_masked': 'WMA Shared Masked',
    'sandbox_prj_sbl': 'SBL',
    'core_nlg': 'Core NLG',
    'core_model': 'Core Model',
    'sandbox_prj_dsforoverdrive': 'DS For Overdrive',
    'edw_input_schema': 'EDW Input',
    'core_in_shared': 'Core IN Shared',
    'sandbox_prj_adhoc': 'Adhoc',
    'sandbox_prj_smart_relationship': 'Smart Relationship',
    'sandbox_prj_rbat': 'RBAT',
}


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _s(v) -> str:
    if v is None:
        return ''
    try:
        if pd.isna(v):
            return ''
    except Exception:
        pass
    s = str(v).strip()
    return '' if s.lower() in ('none', 'nan') else s


def _get_schema_color(schema: str) -> str:
    sl = str(schema).lower().strip()
    for key, color in SCHEMA_COLORS.items():
        if sl == key or key in sl or sl in key:
            return color
    return '#B8B8D1'


# ─────────────────────────────────────────────────────────────────────────────
# Payload builder
# ─────────────────────────────────────────────────────────────────────────────

def _build_all_insight_graphs(insight_type: str) -> list:
    """
    Returns ALL_INSIGHT_GRAPHS – one dict per ODM rule_column.
    Format mirrors the notebook's per-graph data structure.
    """
    insight_type = _s(insight_type)
    if not insight_type:
        return []

    df      = get_insight_column_lineage(insight_type)
    df_meta = get_insight_rule_meta(insight_type)

    rule_cols: list[str] = []
    if not df_meta.empty and 'rule_column' in df_meta.columns:
        rule_cols = (df_meta['rule_column'].dropna().astype(str)
                     .str.strip().unique().tolist())
    rule_cols = [c for c in rule_cols if c]

    if df.empty or not rule_cols:
        return []

    # Build adjacency: (target_table, target_column) → [row_dicts]
    adj: dict[tuple, list] = {}
    for r in df.itertuples(index=False):
        tgt_t  = _s(getattr(r, 'target_table',      None))
        tgt_s  = _s(getattr(r, 'target_schema',     None))
        tgt_c  = _s(getattr(r, 'target_column',     None))
        src_t  = _s(getattr(r, 'source_table',      None))
        src_s  = _s(getattr(r, 'source_schema',     None))
        src_c  = _s(getattr(r, 'source_column',     None))
        logic  = _s(getattr(r, 'logic',             None))
        proc   = _s(getattr(r, 'process',           None))
        sqlp   = _s(getattr(r, 'sql_process',       None))
        sub_tt = _s(getattr(r, 'sub_target_table',  None))
        sub_ts = _s(getattr(r, 'sub_target_schema', None))
        if not tgt_t or not src_t:
            continue
        adj.setdefault((tgt_t, tgt_c), []).append({
            '_tgt_s': tgt_s, '_src_s': src_s,
            'target_table': tgt_t, 'target_schema': tgt_s,
            'sub_target_table': sub_tt, 'sub_target_schema': sub_ts,
            'target_column': tgt_c,
            'source_table': src_t, 'source_schema': src_s,
            'source_column': src_c,
            'process': proc, 'sql_process': sqlp,
            'logic': logic[:500] if logic else '',
        })

    all_graphs = []

    for rc in rule_cols:
        rc_lower = rc.lower()

        # Find profile table (most common target_table where target_column = rc)
        tbl_counts = Counter(
            rd['target_table']
            for (tt, tc), rows in adj.items()
            if tc.lower() == rc_lower
            for rd in rows
        )
        if not tbl_counts:
            continue
        profile_table = tbl_counts.most_common(1)[0][0]

        focal_id = f"{profile_table.lower()}::{rc.lower()}"

        # BFS upstream from focal node
        nodes_dict: dict[str, dict] = {
            focal_id: {
                'id': focal_id, 'table': profile_table, 'column': rc,
                'schema': '', 'is_start': True,
            }
        }
        edges_set:  set[tuple] = set()
        edges_list: list[dict] = []
        node_details: dict[str, dict] = {}

        queue:   list[tuple] = [(profile_table, rc)]
        visited: set[tuple]  = {(profile_table, rc)}

        while queue:
            cur_t, cur_c = queue.pop(0)
            cur_id = f"{cur_t.lower()}::{cur_c.lower()}"

            for row in adj.get((cur_t, cur_c), []):
                src_t  = row['source_table']
                src_s  = row['_src_s']
                tgt_s  = row['_tgt_s']
                src_c  = row['source_column']
                src_id = f"{src_t.lower()}::{src_c.lower()}"

                # Update target node schema
                if tgt_s and not nodes_dict.get(cur_id, {}).get('schema'):
                    if cur_id in nodes_dict:
                        nodes_dict[cur_id]['schema'] = tgt_s

                # Source node
                if src_id not in nodes_dict:
                    nodes_dict[src_id] = {
                        'id': src_id, 'table': src_t, 'column': src_c,
                        'schema': src_s, 'is_start': False,
                    }
                elif src_s and not nodes_dict[src_id]['schema']:
                    nodes_dict[src_id]['schema'] = src_s

                # Edge
                ek = (src_id, cur_id)
                if ek not in edges_set:
                    edges_set.add(ek)
                    edges_list.append({'from': src_id, 'to': cur_id})

                # nodeDetails – first row per target node
                if cur_id not in node_details:
                    node_details[cur_id] = {
                        k: v for k, v in row.items() if not k.startswith('_')
                    }

                if (src_t, src_c) not in visited:
                    visited.add((src_t, src_c))
                    queue.append((src_t, src_c))

        if len(nodes_dict) <= 1:
            continue

        nodes_list = list(nodes_dict.values())

        # Fill profile node schema if still empty
        if not nodes_dict[focal_id]['schema']:
            for nd in nodes_list:
                if nd['schema']:
                    nodes_dict[focal_id]['schema'] = nd['schema']
                    break

        node_colors  = {n['id']: _get_schema_color(n['schema']) for n in nodes_list}
        edge_colors  = {n['id']: _get_schema_color(n['schema']) + 'DD' for n in nodes_list}

        schemas_seen: dict[str, dict] = {}
        for n in nodes_list:
            sch = (n['schema'] or 'unknown').lower()
            if sch not in schemas_seen:
                schemas_seen[sch] = {
                    'color':   _get_schema_color(n['schema']),
                    'display': SCHEMA_DISPLAY_NAMES.get(sch, n['schema'] or 'unknown'),
                }

        all_graphs.append({
            'profile_table':  profile_table,
            'rule_column':    rc,
            'insight_type':   insight_type,
            'nodes':          nodes_list,
            'edges':          edges_list,
            'nodeColors':     node_colors,
            'edgeColors':     edge_colors,
            'schemasInGraph': schemas_seen,
            'nodeDetails':    node_details,
        })

    return all_graphs


# ─────────────────────────────────────────────────────────────────────────────
# Template rendering
# ─────────────────────────────────────────────────────────────────────────────

def _template_path() -> Path:
    return Path(__file__).resolve().parents[1] / 'utils' / 'insight_lineage_template.html'


def _render(insight_type: str) -> str:
    template   = _template_path().read_text(encoding='utf-8')
    all_graphs = _build_all_insight_graphs(insight_type)

    payload = f"var ALL_INSIGHT_GRAPHS = {json.dumps(all_graphs)};"

    template = re.sub(
        r'var ALL_INSIGHT_GRAPHS\s*=\s*.*?;',
        lambda _: payload,
        template,
        flags=re.DOTALL,
    )
    template = re.sub(
        r'<title>.*?</title>',
        f'<title>{insight_type} — Insight Lineage</title>',
        template, count=1, flags=re.DOTALL,
    )
    return template


# ─────────────────────────────────────────────────────────────────────────────
# Dash layout
# ─────────────────────────────────────────────────────────────────────────────

def layout():
    try:
        df_it = get_all_insight_types()
        opts  = [{'label': v, 'value': v}
                 for v in df_it['insight_type'].dropna().astype(str).tolist()]
    except Exception:
        opts = []

    return dcc.Tab(
        label='Insight Lineage',
        value='tab-insight-lineage',
        children=html.Div([
            html.H3('Insight Lineage', style=mds['section_header_style']),
            html.Div([
                html.Div([
                    html.Span('Insight Type', style=mds['dropdown_label_style']),
                    dcc.Dropdown(
                        id='il-insight-dd', options=opts,
                        placeholder='Select an insight type …',
                        clearable=True, searchable=True,
                        style={**mds['dropdown_style'], 'width': '520px'},
                    ),
                ], style={'minWidth': '560px'}),
                html.Div(id='il-rule-badge', style={
                    'marginLeft': 'auto', 'alignSelf': 'center', 'marginTop': '18px',
                    'fontSize': '11px', 'color': '#1d4ed8', 'fontWeight': '600',
                    'padding': '4px 12px', 'background': '#dbeafe',
                    'border': '1px solid #93c5fd', 'borderRadius': '20px',
                }),
            ], style={
                **mds['toolbar_style'],
                'display': 'flex', 'alignItems': 'flex-start',
                'gap': '16px', 'flexWrap': 'wrap', 'marginBottom': '10px',
            }),
            html.Div(id='il-meta-card', style={'display': 'none'}, children=[
                html.Div(id='il-meta-content', style={
                    **mds['content_card_style'],
                    'marginBottom': '10px', 'display': 'flex',
                    'flexWrap': 'wrap', 'gap': '8px', 'padding': '10px 16px',
                })
            ]),
            html.Iframe(
                id='il-iframe', src='',
                style={
                    'width': '100%', 'height': '85vh',
                    'border': '1px solid #e2e8f0', 'borderRadius': '8px',
                },
            ),
        ], style=mds['table_container_style']),
    )


# ─────────────────────────────────────────────────────────────────────────────
# Callbacks
# ─────────────────────────────────────────────────────────────────────────────

def register_callbacks(app):

    @app.callback(
        Output('il-rule-badge',   'children'),
        Output('il-meta-card',    'style'),
        Output('il-meta-content', 'children'),
        Input('il-insight-dd', 'value'),
    )
    def _update_meta(selected_insight):
        hidden = {'display': 'none'}
        if not selected_insight:
            return '', hidden, []
        try:
            df_m = get_insight_rule_meta(str(selected_insight))
        except Exception:
            return '⚠ error', hidden, []
        rule_cols = []
        if not df_m.empty and 'rule_column' in df_m.columns:
            rule_cols = (df_m['rule_column'].dropna().astype(str)
                         .str.strip().unique().tolist())
        badge = f"{len(rule_cols)} rule column{'s' if len(rule_cols) != 1 else ''}"
        chips = [html.Span('◈ ODM Rule Columns:', style={
            'fontSize': '11px', 'fontWeight': '700', 'color': '#1d4ed8',
            'marginRight': '8px', 'textTransform': 'uppercase', 'letterSpacing': '0.06em',
        })]
        for rc in sorted(rule_cols):
            chips.append(html.Span(rc, style={
                'display': 'inline-block', 'background': '#dbeafe',
                'border': '1px solid #93c5fd', 'borderRadius': '4px',
                'padding': '2px 8px', 'fontSize': '12px', 'color': '#1d4ed8',
            }))
        return badge, {'display': 'block'}, chips

    @app.callback(
        Output('il-iframe', 'src'),
        Input('il-insight-dd', 'value'),
    )
    def _update_iframe(selected_insight):
        if not selected_insight:
            return ''
        enc = urllib.parse.quote(str(selected_insight), safe='')
        return app.get_relative_path(f'/insight-lineage-view?insight={enc}')


# ─────────────────────────────────────────────────────────────────────────────
# Server route
# ─────────────────────────────────────────────────────────────────────────────

def register_server_routes(server, routes_prefix='/'):
    def _handler():
        insight = request.args.get('insight', '').strip()
        if not insight:
            return ("<html><body style='font-family:Arial;padding:20px'>"
                    'Select an insight type to view lineage.</body></html>')
        try:
            return _render(insight)
        except Exception as exc:
            safe = str(exc).replace('<', '&lt;').replace('>', '&gt;')
            return (f"<html><body style='font-family:Arial;padding:20px'>"
                    f'<b>Error:</b> {safe}</body></html>')

    if not routes_prefix.startswith('/'): routes_prefix = '/' + routes_prefix
    if not routes_prefix.endswith('/'):   routes_prefix = routes_prefix + '/'
    base = '/insight-lineage-view'
    pref = f"{routes_prefix.rstrip('/')}{base}"
    existing = {r.rule for r in server.url_map.iter_rules()}
    if base not in existing:
        server.add_url_rule(base, endpoint='insight_lineage_view', view_func=_handler)
    if pref not in existing and pref != base:
        server.add_url_rule(pref, endpoint='insight_lineage_view_prefixed', view_func=_handler)
