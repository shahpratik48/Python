"""
column_lineage_tab.py
─────────────────────
Dash tab: column lineage using the exact same style/libraries as
ikg_lineage_explorer.ipynb (vis-network 9.1.2, SCHEMA_COLORS, nodeDetails format).

HTML payload variables match the notebook exactly:
  nodes_raw    – [{id, table, column, schema, is_start}]
  edges_raw    – [{from, to}]
  nodeColors   – {node_id: color_hex}
  edgeColors   – {node_id: color_hex+'DD'}
  schemasInGraph – {schema: {color, display}}
  nodeDetails  – {node_id: {process, target_table, ...}}
"""
import json
import re
import urllib.parse
from pathlib import Path

import pandas as pd
from dash import Input, Output, dcc, html
from flask import request
from styles import metadata_dashboard_styles as mds
from utils.data import (
    get_all_target_columns,
    get_column_lineage_upstream,
    get_tables_for_column,
)

# ── Exact SCHEMA_COLORS from ikg_lineage_explorer.ipynb Cell 8 ────────────
SCHEMA_COLORS = {
    'core_ikg': '#E74C3C',
    'ikg_schema': '#E74C3C',
    'sandbox_prj_smart_insights': '#E74C3C',
    'sandbox_ikg_pre_prd': '#E74C3C',
    'core_wma_shared': '#3498DB',
    'edw_view_input_schema': '#3498DB',
    'ikg_vendor_schema': '#3498DB',
    'sandbox_wma_shared': '#2ECC71',
    'sandbox_prj_ds_data': '#F39C12',
    'core_wma_shared_masked': '#1ABC9C',
    'sandbox_prj_sbl': '#9B59B6',
    'core_nlg': '#8E44AD',
    'nlg_schema': '#8E44AD',
    'core_model': '#E67E22',
    'model_schema': '#E67E22',
    'sandbox_prj_dsforoverdrive': '#3498DB',
    'edw_input_schema': '#5DADE2',
    'core_in_shared': '#EC7063',
    'ikg_clip_schema': '#EC7063',
    'sandbox_prj_adhoc': '#F1948A',
    'sandbox_prj_smart_relationship': '#48C9B0',
    'ikg_wealthx_schema': '#48C9B0',
    'sandbox_prj_rbat': '#52BE80',
}
SCHEMA_DISPLAY_NAMES = {
    'core_ikg': 'Core IKG',
    'core_wma_shared': 'Core WMA Shared',
    'sandbox_wma_shared': 'Sandbox WMA Shared',
    'sandbox_prj_ds_data': 'DS Data',
    'core_wma_shared_masked': 'WMA Shared Masked',
    'sandbox_prj_sbl': 'SBL',
    'core_nlg': 'Core NLG',
    'core_model': 'Core Model',
    'sandbox_prj_dsforoverdrive': 'DS For Overdrive',
    'edw_input_schema': 'EDW Input',
    'core_in_shared': 'Core IN Shared',
    'sandbox_prj_adhoc': 'Adhoc',
    'sandbox_prj_smart_relationship': 'Smart Relationship',
    'sandbox_prj_rbat': 'RBAT',
}


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _s(v) -> str:
    if v is None:
        return ''
    try:
        if pd.isna(v):
            return ''
    except Exception:
        pass
    s = str(v).strip()
    return '' if s.lower() in ('none', 'nan') else s


def _get_schema_color(schema: str) -> str:
    """Exact logic from ikg_lineage_explorer.ipynb get_schema_color()."""
    sl = str(schema).lower().strip()
    for key, color in SCHEMA_COLORS.items():
        if sl == key or key in sl or sl in key:
            return color
    return '#B8B8D1'


# ─────────────────────────────────────────────────────────────────────────────
# Payload builder – exact notebook format
# ─────────────────────────────────────────────────────────────────────────────

def _build_payload(target_column: str, target_table: str) -> dict:
    """
    Build the 6 payload dicts that the notebook's HTML template consumes.
    Node IDs use "table::column" format (lowercase), matching the notebook.
    """
    target_column = _s(target_column)
    target_table  = _s(target_table)

    df = get_column_lineage_upstream(target_column, target_table)

    nodes_dict:   dict[str, dict] = {}
    edges_set:    set[tuple]      = set()
    edges_list:   list[dict]      = []
    node_rows:    dict[str, list] = {}   # first row per target node for nodeDetails

    focal_id = f"{target_table.lower()}::{target_column.lower()}"

    # Pre-populate focal node (filled in with schema from rows below)
    nodes_dict[focal_id] = {
        'id':       focal_id,
        'table':    target_table,
        'column':   target_column,
        'schema':   '',
        'is_start': True,
    }
    node_rows[focal_id] = []

    if not df.empty:
        for r in df.itertuples(index=False):
            tgt_t  = _s(getattr(r, 'target_table',      None))
            tgt_s  = _s(getattr(r, 'target_schema',     None))
            tgt_c  = _s(getattr(r, 'target_column',     None))
            src_t  = _s(getattr(r, 'source_table',      None))
            src_s  = _s(getattr(r, 'source_schema',     None))
            src_c  = _s(getattr(r, 'source_column',     None))
            logic  = _s(getattr(r, 'logic',             None))
            proc   = _s(getattr(r, 'process',           None))
            sqlp   = _s(getattr(r, 'sql_process',       None))
            sub_tt = _s(getattr(r, 'sub_target_table',  None))
            sub_ts = _s(getattr(r, 'sub_target_schema', None))

            if not tgt_t or not src_t:
                continue

            tgt_id = f"{tgt_t.lower()}::{tgt_c.lower()}"
            src_id = f"{src_t.lower()}::{src_c.lower()}"

            # Target node
            if tgt_id not in nodes_dict:
                nodes_dict[tgt_id] = {
                    'id': tgt_id, 'table': tgt_t, 'column': tgt_c,
                    'schema': tgt_s, 'is_start': (tgt_id == focal_id),
                }
            elif tgt_s and not nodes_dict[tgt_id]['schema']:
                nodes_dict[tgt_id]['schema'] = tgt_s

            # Source node
            if src_id not in nodes_dict:
                nodes_dict[src_id] = {
                    'id': src_id, 'table': src_t, 'column': src_c,
                    'schema': src_s, 'is_start': False,
                }
            elif src_s and not nodes_dict[src_id]['schema']:
                nodes_dict[src_id]['schema'] = src_s

            # Edge (deduplicated)
            ek = (src_id, tgt_id)
            if ek not in edges_set:
                edges_set.add(ek)
                edges_list.append({'from': src_id, 'to': tgt_id})

            # nodeDetails – keep first row per target node
            if tgt_id not in node_rows:
                node_rows[tgt_id] = {
                    'process':           proc,
                    'target_table':      tgt_t,
                    'target_schema':     tgt_s,
                    'sub_target_table':  sub_tt,
                    'sub_target_schema': sub_ts,
                    'target_column':     tgt_c,
                    'source_table':      src_t,
                    'source_schema':     src_s,
                    'source_column':     src_c,
                    'logic':             logic[:500] if logic else '',
                    'sql_process':       sqlp,
                }

    nodes_list = list(nodes_dict.values())

    node_colors     = {n['id']: _get_schema_color(n['schema']) for n in nodes_list}
    edge_colors     = {n['id']: _get_schema_color(n['schema']) + 'DD' for n in nodes_list}

    schemas_seen: dict[str, dict] = {}
    for n in nodes_list:
        sch = (n['schema'] or 'unknown').lower()
        if sch not in schemas_seen:
            schemas_seen[sch] = {
                'color':   _get_schema_color(n['schema']),
                'display': SCHEMA_DISPLAY_NAMES.get(sch, n['schema'] or 'unknown'),
            }

    node_details = {nid: v for nid, v in node_rows.items() if isinstance(v, dict)}

    return {
        'nodes_raw':      nodes_list,
        'edges_raw':      edges_list,
        'nodeColors':     node_colors,
        'edgeColors':     edge_colors,
        'schemasInGraph': schemas_seen,
        'nodeDetails':    node_details,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Template rendering
# ─────────────────────────────────────────────────────────────────────────────

def _template_path() -> Path:
    return Path(__file__).resolve().parents[1] / 'utils' / 'column_lineage_template.html'


def _render(target_column: str, target_table: str) -> str:
    template = _template_path().read_text(encoding='utf-8')
    data     = _build_payload(target_column, target_table)

    # Inject all 6 data variables in one re.sub call.
    # lambda prevents re.sub from interpreting backslashes in the JSON payload.
    payload = (
        f"var nodes_raw = {json.dumps(data['nodes_raw'])};\n"
        f"var edges_raw = {json.dumps(data['edges_raw'])};\n"
        f"var nodeColors = {json.dumps(data['nodeColors'])};\n"
        f"var edgeColors = {json.dumps(data['edgeColors'])};\n"
        f"var schemasInGraph = {json.dumps(data['schemasInGraph'])};\n"
        f"var nodeDetails = {json.dumps(data['nodeDetails'])};"
    )
    template = re.sub(
        r'var nodes_raw\s*=\s*.*?;\s*'
        r'var edges_raw\s*=\s*.*?;\s*'
        r'var nodeColors\s*=\s*.*?;\s*'
        r'var edgeColors\s*=\s*.*?;\s*'
        r'var schemasInGraph\s*=\s*.*?;\s*'
        r'var nodeDetails\s*=\s*.*?;',
        lambda _: payload,
        template,
        flags=re.DOTALL,
    )
    template = re.sub(
        r'<title>.*?</title>',
        f'<title>{target_column} in {target_table}</title>',
        template, count=1, flags=re.DOTALL,
    )
    return template


# ─────────────────────────────────────────────────────────────────────────────
# Dash layout
# ─────────────────────────────────────────────────────────────────────────────

def layout():
    try:
        df_cols  = get_all_target_columns()
        col_opts = [{'label': c, 'value': c}
                    for c in df_cols['target_column'].dropna().astype(str).tolist()]
    except Exception:
        col_opts = []

    return dcc.Tab(
        label='Column Lineage',
        value='tab-column-lineage',
        children=html.Div([
            html.H3('Column Lineage', style=mds['section_header_style']),
            html.Div([
                html.Div([
                    html.Span('Target Column', style=mds['dropdown_label_style']),
                    dcc.Dropdown(
                        id='cl-column-dd', options=col_opts,
                        placeholder='Select a column …',
                        clearable=True, searchable=True,
                        style={**mds['dropdown_style'], 'width': '380px'},
                    ),
                ], style={'minWidth': '400px'}),
                html.Div('→', style={
                    'fontSize': '1.4rem', 'color': '#94a3b8',
                    'padding': '0 8px', 'alignSelf': 'center', 'marginTop': '18px',
                }),
                html.Div([
                    html.Span('Target Table', style=mds['dropdown_label_style']),
                    dcc.Dropdown(
                        id='cl-table-dd', options=[],
                        placeholder='Select a table …',
                        clearable=True, disabled=True,
                        style={**mds['dropdown_style'], 'width': '380px'},
                    ),
                ], style={'minWidth': '400px'}),
                html.Div(id='cl-info-badge', style={
                    'marginLeft': 'auto', 'alignSelf': 'center', 'marginTop': '18px',
                    'fontSize': '11px', 'color': '#1d4ed8', 'fontWeight': '600',
                    'padding': '4px 12px', 'background': '#dbeafe',
                    'border': '1px solid #93c5fd', 'borderRadius': '20px',
                }),
            ], style={
                **mds['toolbar_style'],
                'display': 'flex', 'alignItems': 'flex-start',
                'gap': '0px', 'flexWrap': 'wrap', 'marginBottom': '10px',
            }),
            html.Iframe(
                id='cl-iframe', src='',
                style={
                    'width': '100%', 'height': '88vh',
                    'border': '1px solid #e2e8f0', 'borderRadius': '8px',
                },
            ),
        ], style=mds['table_container_style']),
    )


# ─────────────────────────────────────────────────────────────────────────────
# Callbacks
# ─────────────────────────────────────────────────────────────────────────────

def register_callbacks(app):

    @app.callback(
        Output('cl-table-dd',   'options'),
        Output('cl-table-dd',   'disabled'),
        Output('cl-table-dd',   'value'),
        Output('cl-info-badge', 'children'),
        Input('cl-column-dd',   'value'),
    )
    def _populate_tables(selected_col):
        if not selected_col:
            return [], True, None, ''
        try:
            df    = get_tables_for_column(str(selected_col))
            tables = df['target_table'].dropna().astype(str).tolist()
        except Exception:
            tables = []
        opts  = [{'label': t, 'value': t} for t in sorted(tables)]
        badge = f"{len(opts)} table{'s' if len(opts) != 1 else ''}"
        return opts, len(opts) == 0, None, badge

    @app.callback(
        Output('cl-iframe', 'src'),
        Input('cl-column-dd', 'value'),
        Input('cl-table-dd',  'value'),
    )
    def _update_iframe(col, table):
        if not col or not table:
            return ''
        return app.get_relative_path(
            f'/column-lineage-view'
            f'?col={urllib.parse.quote(str(col), safe="")}'
            f'&table={urllib.parse.quote(str(table), safe="")}',
        )


# ─────────────────────────────────────────────────────────────────────────────
# Server route
# ─────────────────────────────────────────────────────────────────────────────

def register_server_routes(server, routes_prefix='/'):
    def _handler():
        col   = request.args.get('col',   '').strip()
        table = request.args.get('table', '').strip()
        if not col or not table:
            return ("<html><body style='font-family:Arial;padding:20px'>"
                    'Select a column and table to view lineage.</body></html>')
        try:
            return _render(col, table)
        except Exception as exc:
            safe = str(exc).replace('<', '&lt;').replace('>', '&gt;')
            return (f"<html><body style='font-family:Arial;padding:20px'>"
                    f'<b>Error:</b> {safe}</body></html>')

    if not routes_prefix.startswith('/'): routes_prefix = '/' + routes_prefix
    if not routes_prefix.endswith('/'):   routes_prefix = routes_prefix + '/'
    base = '/column-lineage-view'
    pref = f"{routes_prefix.rstrip('/')}{base}"
    existing = {r.rule for r in server.url_map.iter_rules()}
    if base not in existing:
        server.add_url_rule(base, endpoint='column_lineage_view', view_func=_handler)
    if pref not in existing and pref != base:
        server.add_url_rule(pref, endpoint='column_lineage_view_prefixed', view_func=_handler)
