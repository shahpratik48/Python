# dags/scripts/ikg_lineage_sql_stitcher_task.py
# -*- coding: utf-8 -*-
"""
Airflow-callable wrapper around ``ikg_lineage_sql_stitcher``.

Single-task execution: processes **all** profile tables in one Airflow task.

**Dual-mode execution** (same pattern as ``odm_metadata_python_module.py``
and ``swat_issues_report.py``):

- *Airflow*: all credentials, schemas, and roles come from Airflow
  Variables / ``ikg.scripts.python.props``.
- *Local*: falls back to ``GP_*`` / ``GITLAB_TOKEN`` environment variables
  or interactive ``getpass`` prompts.
"""

from __future__ import annotations

import datetime as dt
import logging
import os
import zipfile
from pathlib import Path
from typing import Any, Dict, List, Tuple

# NOTE: This import requires dags/scripts/ikg_lineage_sql_stitcher.py to exist
from ikg_lineage_sql_stitcher import (
    GitLabSQLFetcher,
    build_dependency_artifacts,
    derive_forced_table_tokens,
    fetch_lineage_entries,
    fetch_profile_scripts,
    get_db_config,
    get_private_token,
    get_target_schema,
    is_running_in_airflow,
    lineage_temp_table_name,
    normalize_table_name,
    prepare_temp_table_plan,
    stitch_sql,
    transform_insert_only_scripts,
    enforce_unique_table_targets,
    enforce_profile_table_suffix,
    render_stitched_text,
    write_output_file,
    write_modified_file,
    find_tables_for_suffix,
    run_sql_script,
    build_profile_only_text,
    write_profile_only_file,
    display_table_counts,
    preview_final_table,
    EXCLUDE_FOLDER,
)

# ---------------------------------------------------------------------------
# Airflow detection — tolerate environments where Airflow is not installed
# ---------------------------------------------------------------------------
try:
    from airflow.models import Variable  # type: ignore
    _HAS_AIRFLOW = True
except Exception:  # noqa: BLE001
    Variable = None  # type: ignore
    _HAS_AIRFLOW = False

logger = logging.getLogger("ikg_lineage_sql_stitch")
logger.setLevel(logging.INFO)

# Optional switches (can be Airflow Variables later)
GENERATE_SQL_ARTIFACTS = False
EXECUTE_SQL = False

# Profile discovery query — use Python .format() (NOT Jinja {{params...}})
PROFILE_TABLE_SQL = """
SELECT DISTINCT target_table
FROM {schema}.ikg_table_lineage_metadata_auto_refresh
WHERE target_table ILIKE %s
ORDER BY target_table;
"""


def _get_profile_date() -> str:
    """Return IKG_PROFILE_DATE from Airflow Variable or environment."""
    if is_running_in_airflow():
        value = Variable.get("IKG_PROFILE_DATE", default_var=None)
        if value:
            return value
    value = os.environ.get("IKG_PROFILE_DATE")
    if value:
        return value
    raise RuntimeError(
        "IKG_PROFILE_DATE must be set as an Airflow Variable or environment variable."
    )


def _fetch_all_profile_tables(db_config: Dict[str, Any], like_pattern: str = "%profile_curr_ikg") -> List[str]:
    import psycopg2
    schema = get_target_schema()
    rendered_sql = PROFILE_TABLE_SQL.format(schema=schema)
    with psycopg2.connect(**db_config) as conn, conn.cursor() as cur:
        cur.execute(rendered_sql, (like_pattern,))
        rows = cur.fetchall()
    return [r[0] for r in rows if r and r[0]]


def _zip_excels(excel_paths: List[Path], zip_path: Path) -> str:
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for p in excel_paths:
            if p.exists():
                zf.write(p, arcname=p.name)
    return str(zip_path)




def run_ikg_lineage_sql_stitcher_job(**context) -> Dict[str, Any]:
    """
    Airflow callable:
      - builds lineage artifacts for all profile tables
      - produces one excel per profile (≈47)
      - zips them into one attachment for the EmailOperator
      - deletes the individual excels after zip
      - returns excel_path + temp_dir via XCom for your existing DAG

    IMPORTANT FIX:
      - Use the same temp folder pattern as other metadata jobs:
        <this_script_dir>/temp_ikg_lineage_sql_stitch_<timestamp>
      - Avoid /tmp (pod-local) so EmailOperator can see attachments across workers/pods.
    """
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    gitlab_token = get_private_token(allow_prompt=not is_running_in_airflow())
    profile_date = _get_profile_date()
    db_config = get_db_config()
    target_schema = get_target_schema()

    # ✅ Match other jobs: create temp folder under this scripts directory
    base_dir = os.path.dirname(os.path.abspath(__file__))
    timestamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d_%H%M%S")
    temp_dir = Path(os.path.join(base_dir, f"temp_ikg_lineage_sql_stitch_{timestamp}"))
    temp_dir.mkdir(parents=True, exist_ok=True)
    logger.info("[IKG SQL Stitch] Temporary folder created: %s", temp_dir)

    try:
        # Discover profiles
        profile_tables = _fetch_all_profile_tables(db_config, "%profile_curr_ikg")
        logger.info("Discovered %d profile tables.", len(profile_tables))

        if not profile_tables:
            # Create an empty zip anyway so EmailOperator never fails
            zip_path = temp_dir / "ikg_lineage_excels.zip"
            _zip_excels([], zip_path)
            return {
                "profile_table_count": 0,
                "row_count": 0,
                "excel_path": str(zip_path),
                "executed": False,
                "temp_dir": str(temp_dir),
                "skipped": [],
                "errors": [],
            }

        # Prepare vendor temp tables ONCE (same as notebook)
        temp_plan = prepare_temp_table_plan(db_config, target_schema, acc_mhh_n_value=None)
        temp_table_map = temp_plan.table_map
        vendor_guard_tables = {normalize_table_name(name) for name in temp_table_map.keys()}

        # GitLab fetcher once
        exclude_folders = [f for f in EXCLUDE_FOLDER.split() if f]
        fetcher = GitLabSQLFetcher(private_token=gitlab_token, exclude_folders=exclude_folders)

        excel_outputs: List[Path] = []
        total_rows = 0
        errors: List[Tuple[str, str]] = []
        skipped: List[str] = []

        # Process each profile
        for idx, profile in enumerate(profile_tables, start=1):
            try:
                logger.info("(%d/%d) Processing profile table: %s", idx, len(profile_tables), profile)

                lineage_rows, returned_profiles, excel_path, alias_lookup = build_dependency_artifacts(
                    insight_types=[],
                    db_config=db_config,
                    run_timestamp=None,
                    override_profile_tables=[profile],
                )

                if not returned_profiles or not lineage_rows:
                    logger.warning("NO DATA for profile table %s -> skipping.", profile)
                    skipped.append(profile)
                    continue

                total_rows += len(lineage_rows)

                # Move Excel into our temp_dir so EmailOperator can attach from shared/scripts location
                excel_src = Path(excel_path)
                excel_dst = temp_dir / excel_src.name
                try:
                    excel_dst.write_bytes(excel_src.read_bytes())
                except FileNotFoundError:
                    # If the library returned a path that doesn't exist, track it and skip
                    logger.warning("Excel path returned but file not found: %s", excel_src)
                    skipped.append(profile)
                    continue

                # Try removing original (best-effort)
                try:
                    excel_src.unlink(missing_ok=True)
                except Exception:
                    pass

                excel_outputs.append(excel_dst)

                if not GENERATE_SQL_ARTIFACTS:
                    continue

                primary_profile = returned_profiles[-1]
                lineage_table = lineage_temp_table_name(primary_profile)

                import psycopg2 as _psycopg2
                with _psycopg2.connect(**db_config) as conn:
                    entries = fetch_lineage_entries(conn, lineage_table)

                if not entries:
                    logger.warning("NO LINEAGE ENTRIES for %s -> skipping SQL stitching.", profile)
                    continue

                profile_scripts = fetch_profile_scripts(fetcher, returned_profiles)
                selected_profile = None
                skip_paths = set()

                if profile_scripts and primary_profile:
                    target_lower = primary_profile.lower()
                    for path, content in reversed(profile_scripts):
                        if Path(path).stem.lower() == target_lower:
                            selected_profile = (path, content)
                            break
                    selected_profile = selected_profile or profile_scripts[-1]
                    skip_paths.add(selected_profile[0].lower())

                stitched_sql = stitch_sql(entries, fetcher, alias_lookup, skip_paths=skip_paths)
                if not stitched_sql:
                    logger.warning("No SQL stitched for %s -> skipping SQL outputs.", profile)
                    continue

                forced_tables = set(derive_forced_table_tokens(returned_profiles))

                if selected_profile and primary_profile:
                    stitched_sql.append(
                        (selected_profile[0], enforce_profile_table_suffix(selected_profile[1], primary_profile))
                    )

                stitched_sql, insert_forced = transform_insert_only_scripts(stitched_sql, vendor_guard_tables)
                forced_tables.update(insert_forced)

                stitched_sql = enforce_unique_table_targets(stitched_sql, forced_tables, vendor_guard_tables)
                stitched_text = render_stitched_text(stitched_sql)

                # Write outputs into temp_dir by chdir
                cwd = Path.cwd()
                try:
                    os.chdir(str(temp_dir))

                    _ = write_output_file("", stitched_text, primary_profile)
                    modified_path, modified_text = write_modified_file(
                        "",
                        stitched_text,
                        profile_date,
                        forced_tables,
                        temp_table_map,
                        target_schema,
                        primary_profile,
                        vendor_guard_tables,
                    )

                    if EXECUTE_SQL:
                        created_tables = sorted(find_tables_for_suffix(modified_text))
                        run_sql_script(modified_text, db_config)
                        display_table_counts(created_tables, db_config)
                        preview_final_table(db_config, returned_profiles)

                    # Optional: profile-only
                    if selected_profile and primary_profile:
                        profile_only_text = build_profile_only_text(
                            selected_profile[1],
                            profile_date,
                            forced_tables,
                            temp_table_map,
                            target_schema,
                            vendor_guard_tables,
                        )
                        _ = write_profile_only_file("", profile_only_text, primary_profile)

                finally:
                    os.chdir(str(cwd))

            except Exception as e:
                logger.exception("Error while processing %s", profile)
                errors.append((profile, str(e)))

        # ✅ Zip all excels in the SAME temp_dir
        zip_path = temp_dir / "ikg_lineage_excels.zip"
        _zip_excels(excel_outputs, zip_path)
        logger.info("Created ZIP attachment: %s", zip_path)

        # ✅ Delete individual excel files AFTER zip
        for p in excel_outputs:
            try:
                p.unlink(missing_ok=True)
            except Exception:
                logger.warning("Could not delete %s", p)

        if skipped:
            logger.info("Skipped %d profiles (no data or missing excel).", len(skipped))
        if errors:
            logger.warning("Encountered %d errors during processing.", len(errors))

        return {
            "profile_table_count": len(profile_tables),
            "row_count": total_rows,
            "excel_path": str(zip_path),   # EmailOperator attaches this
            "executed": bool(EXECUTE_SQL),
            "temp_dir": str(temp_dir),     # cleanup_temp_folder will delete it
            "skipped": skipped,
            "errors": errors,
        }

    except Exception:
        logger.exception("IKG lineage SQL stitcher failed.")
        raise


# =====================================================================================
# LOCAL EXECUTION — ``python ikg_lineage_sql_stitcher_task.py``
# =====================================================================================

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
    result = run_ikg_lineage_sql_stitcher_job()
    logger.info("Result: %s", result)