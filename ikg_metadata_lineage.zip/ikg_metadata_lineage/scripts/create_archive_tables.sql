DROP TABLE IF EXISTS {{params.IKG_SCHEMA}}.odm_rule_metadata_auto_refresh_archive;
CREATE TABLE {{params.IKG_SCHEMA}}.odm_rule_metadata_auto_refresh_archive AS
SELECT * FROM {{params.IKG_SCHEMA}}.odm_rule_metadata_auto_refresh;
ALTER TABLE {{params.IKG_SCHEMA}}.odm_rule_metadata_auto_refresh_archive OWNER TO {{params.IKG_TABLE_OWNER_GROUP}};
GRANT SELECT ON {{params.IKG_SCHEMA}}.odm_rule_metadata_auto_refresh_archive TO {{params.IKG_TABLE_READER_GROUP}};
DROP TABLE IF EXISTS {{params.IKG_SCHEMA}}.nlg_input_config_metadata_auto_refresh_archive;
CREATE TABLE {{params.IKG_SCHEMA}}.nlg_input_config_metadata_auto_refresh_archive AS
SELECT * FROM {{params.IKG_SCHEMA}}.nlg_input_config_metadata_auto_refresh;
ALTER TABLE {{params.IKG_SCHEMA}}.nlg_input_config_metadata_auto_refresh_archive OWNER TO {{params.IKG_TABLE_OWNER_GROUP}};
GRANT SELECT ON {{params.IKG_SCHEMA}}.nlg_input_config_metadata_auto_refresh_archive TO {{params.IKG_TABLE_READER_GROUP}};
DROP TABLE IF EXISTS {{params.IKG_SCHEMA}}.nlg_sql_mapping_metadata_auto_refresh_archive;
CREATE TABLE {{params.IKG_SCHEMA}}.nlg_sql_mapping_metadata_auto_refresh_archive AS
SELECT * FROM {{params.IKG_SCHEMA}}.nlg_sql_mapping_metadata_auto_refresh;
ALTER TABLE {{params.IKG_SCHEMA}}.nlg_sql_mapping_metadata_auto_refresh_archive OWNER TO {{params.IKG_TABLE_OWNER_GROUP}};
GRANT SELECT ON {{params.IKG_SCHEMA}}.nlg_sql_mapping_metadata_auto_refresh_archive TO {{params.IKG_TABLE_READER_GROUP}};
DROP TABLE IF EXISTS {{params.IKG_SCHEMA}}.nlg_rule_metadata_auto_refresh_archive;
CREATE TABLE {{params.IKG_SCHEMA}}.nlg_rule_metadata_auto_refresh_archive AS
SELECT * FROM {{params.IKG_SCHEMA}}.nlg_rule_metadata_auto_refresh;
ALTER TABLE {{params.IKG_SCHEMA}}.nlg_rule_metadata_auto_refresh_archive OWNER TO {{params.IKG_TABLE_OWNER_GROUP}};
GRANT SELECT ON {{params.IKG_SCHEMA}}.nlg_rule_metadata_auto_refresh_archive TO {{params.IKG_TABLE_READER_GROUP}};
DROP TABLE IF EXISTS {{params.IKG_SCHEMA}}.cid_columns_metadata_auto_refresh_archive;
CREATE TABLE {{params.IKG_SCHEMA}}.cid_columns_metadata_auto_refresh_archive AS
SELECT * FROM {{params.IKG_SCHEMA}}.cid_columns_metadata_auto_refresh;
ALTER TABLE {{params.IKG_SCHEMA}}.cid_columns_metadata_auto_refresh_archive OWNER TO {{params.IKG_TABLE_OWNER_GROUP}};
GRANT SELECT ON {{params.IKG_SCHEMA}}.cid_columns_metadata_auto_refresh_archive TO {{params.IKG_TABLE_READER_GROUP}};
DROP TABLE IF EXISTS {{params.IKG_SCHEMA}}.nlg_combined_metadata_auto_refresh_archive;
CREATE TABLE {{params.IKG_SCHEMA}}.nlg_combined_metadata_auto_refresh_archive AS
SELECT * FROM {{params.IKG_SCHEMA}}.nlg_combined_metadata_auto_refresh;
ALTER TABLE {{params.IKG_SCHEMA}}.nlg_combined_metadata_auto_refresh_archive OWNER TO {{params.IKG_TABLE_OWNER_GROUP}};
GRANT SELECT ON {{params.IKG_SCHEMA}}.nlg_combined_metadata_auto_refresh_archive TO {{params.IKG_TABLE_READER_GROUP}};
DROP TABLE IF EXISTS {{params.IKG_SCHEMA}}.ikg_dictiONary_metadata_auto_refresh_archive;
CREATE TABLE {{params.IKG_SCHEMA}}.ikg_dictiONary_metadata_auto_refresh_archive AS
SELECT * FROM {{params.IKG_SCHEMA}}.ikg_dictiONary_metadata_auto_refresh;
ALTER TABLE {{params.IKG_SCHEMA}}.ikg_dictiONary_metadata_auto_refresh_archive OWNER TO {{params.IKG_TABLE_OWNER_GROUP}};
GRANT SELECT ON {{params.IKG_SCHEMA}}.ikg_dictiONary_metadata_auto_refresh_archive TO {{params.IKG_TABLE_READER_GROUP}};