DROP TABLE IF EXISTS {{params.IKG_SCHEMA}}.nlg_combined_metadata_auto_refresh;
CREATE TABLE {{params.IKG_SCHEMA}}.nlg_combined_metadata_auto_refresh AS
WITH nlg_rule_metadata_auto_refresh AS (
SELECT DISTINCT r.target_type, r.profile_TABLE, r.insight_type, r.rule_tag_value
FROM {{params.IKG_SCHEMA}}.nlg_rule_metadata_auto_refresh r
),
nlg_sql_mapping_metadata_auto_refresh AS (
SELECT DISTINCT s.target_type, s.profile_TABLE, s.insight_type, s.sql_tag, s.sql_profile_column
FROM {{params.IKG_SCHEMA}}.nlg_sql_mapping_metadata_auto_refresh s
),
nlg_input_cONfig_metadata_auto_refresh AS (
SELECT DISTINCT target_type, profile_TABLE, cONfig_tag, cONfig_profile_column
FROM {{params.IKG_SCHEMA}}.nlg_input_cONfig_metadata_auto_refresh
)
SELECT DISTINCT r.target_type, r.profile_TABLE, r.insight_type, r.rule_tag_value, s.sql_tag AS tag, s.sql_profile_column AS ikg_column
FROM nlg_rule_metadata_auto_refresh r
LEFT JOIN nlg_sql_mapping_metadata_auto_refresh s
ON r.target_type = s.target_type
AND r.profile_TABLE = s.profile_TABLE
AND r.insight_type = s.insight_type
AND r.rule_tag_value = s.sql_tag
WHERE s.sql_tag IS NOT NULL
uniON
SELECT DISTINCT r.target_type, r.profile_TABLE, r.insight_type, r.rule_tag_value, i.cONfig_tag AS tag, i.cONfig_profile_column AS ikg_column
FROM nlg_rule_metadata_auto_refresh r
LEFT JOIN nlg_input_cONfig_metadata_auto_refresh i
ON r.target_type = i.target_type
AND r.profile_TABLE = i.profile_TABLE
AND r.rule_tag_value = i.cONfig_tag
WHERE i.cONfig_tag IS NOT NULL;
ALTER TABLE {{params.IKG_SCHEMA}}.nlg_combined_metadata_auto_refresh OWNER TO {{params.IKG_TABLE_OWNER_GROUP}}; --erd_gpdb_prj_smart_insights
GRANT SELECT ON {{params.IKG_SCHEMA}}.nlg_combined_metadata_auto_refresh TO {{params.IKG_TABLE_READER_GROUP}};