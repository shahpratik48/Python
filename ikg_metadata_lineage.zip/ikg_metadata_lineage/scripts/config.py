DEFAULT_GP_HOST = "greenplum-rdsp.zur.swissbank.com"
DEFAULT_GP_PORT = 5432
DEFAULT_GP_DB = "gprdsp"
DEFAULT_GP_USER = "ds_rdsp_dev"
DEFAULT_GP_SCHEMA = "sandbox_prj_smart_insights"
DEFAULT_CORE_IKG_SCHEMA = "core_ikg"
DEFAULT_GP_OWNER_ROLE = "erd_gpdb_prj_smart_insights"
DEFAULT_GP_READER_ROLE = "erd_gpdb_prj_smart_insights_ro"