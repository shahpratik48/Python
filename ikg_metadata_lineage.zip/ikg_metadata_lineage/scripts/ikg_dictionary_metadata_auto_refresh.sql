DROP TABLE IF EXISTS {{params.IKG_SCHEMA}}.ikg_dictiONary_metadata_auto_refresh;
CREATE TABLE {{params.IKG_SCHEMA}}.ikg_dictiONary_metadata_auto_refresh AS
WITH odm_columns AS (
SELECT target_type, insight_type, profile_table, rule_column AS odm_rule_column
FROM {{params.IKG_SCHEMA}}.odm_rule_metadata_auto_refresh r
UNION
SELECT target_type, insight_type, profile_table, target_key AS odm_rule_column
FROM {{params.IKG_SCHEMA}}.odm_rule_metadata_auto_refresh r
UNION
SELECT target_type, insight_type, profile_table, metric_val AS odm_rule_column
FROM {{params.IKG_SCHEMA}}.odm_rule_metadata_auto_refresh r
UNION
SELECT target_type, insight_type, profile_table, insight_att_val AS odm_rule_column
FROM {{params.IKG_SCHEMA}}.odm_rule_metadata_auto_refresh r
),
odm_columns_agg AS (
SELECT target_type AS odm_target_type, profile_table AS odm_profile_table, odm_rule_column,
STRING_AGG(odm.insight_type, ',') AS odm_insight_types
FROM odm_columns odm
GROUP BY 1,2,3
),
nlg_columns AS (
SELECT DISTINCT r.target_type, r.profile_table, r.insight_type, ikg_column
FROM {{params.IKG_SCHEMA}}.nlg_combined_metadata_auto_refresh r
),
nlg_columns_agg AS (
SELECT target_type AS nlg_target_type, profile_table AS nlg_profile_table, ikg_column AS nlg_ikg_column,
STRING_AGG(nlg.insight_type, ',') AS nlg_insight_types
FROM nlg_columns nlg
GROUP BY 1,2,3
)
SELECT
c.table_schema,
c.table_name,
c.column_name,
c.data_type,
c.character_maximum_length AS max_length,
c.numeric_precISiON,
c.numeric_scale,
odm.odm_target_type,
odm.odm_insight_types,
CASE WHEN odm.odm_target_type IS NOT NULL THEN 'Y' ELSE 'N' END AS IS_odm,
nlg.nlg_target_type,
nlg.nlg_insight_types,
CASE WHEN nlg.nlg_target_type IS NOT NULL THEN 'Y' ELSE 'N' END AS IS_nlg,
CASE WHEN cid.cid_profile_column IS NOT NULL THEN 'Y' ELSE '' end AS IS_cid
FROM informatiON_schema.columns c
LEFT JOIN odm_columns_agg odm ON c.table_name = odm.odm_profile_table AND c.column_name = odm.odm_rule_column
LEFT JOIN nlg_columns_agg nlg ON c.table_name = nlg.nlg_profile_table AND c.column_name = nlg.nlg_ikg_column
LEFT JOIN (SELECT dIStinct cid_profile_column
FROM {{params.IKG_SCHEMA}}.cid_columns_metadata_auto_refresh
WHERE tag IS NOT NULL) cid ON c.column_name = cid.cid_profile_column
WHERE c.table_schema IN ('core_ikg') AND c.table_name LIKE '%profile_curr_ikg'
ORDER BY
c.table_schema,
c.table_name,
c.ordinal_positiON;
ALTER TABLE {{params.IKG_SCHEMA}}.ikg_dictiONary_metadata_auto_refresh OWNER TO {{params.IKG_TABLE_OWNER_GROUP}};
GRANT SELECT ON {{params.IKG_SCHEMA}}.ikg_dictiONary_metadata_auto_refresh TO {{params.IKG_TABLE_READER_GROUP}};