# dags/scripts/odm_metadata_python_module.py
# -*- coding: utf-8 -*-
"""
Generate the ODM rules details Excel report from ODM SQL assets hosted in GitLab
and upload the resulting data into <IKG_SCHEMA>.odm_rule_metadata_auto_refresh.

Also generates NLG profile columns metadata report (Input Config + SQL Mapping) from NLG GitLab assets
and refreshes:
- <IKG_SCHEMA>.nlg_input_config_metadata_auto_refresh
- <IKG_SCHEMA>.nlg_sql_mapping_metadata_auto_refresh

Adds NLG rules tag metadata and CID profile columns metadata jobs.

Adds IKG Table Lineage metadata job.

**Dual-mode execution:**
- *Airflow*: All credentials, schemas, and roles are resolved from Airflow
  Variables / ``ikg.scripts.python.props`` (environment-aware: Preview/UAT/Prod).
- *Local*: Falls back to environment variables (``GP_SCHEMA``, ``GP_HOST``, etc.)
  or interactive prompts (``getpass``) for credentials.
"""

from __future__ import annotations

import base64
import datetime as dt
import getpass
import json
import logging
import os
import re
import shutil
from collections import defaultdict
from dataclasses import dataclass
from pathlib import PurePosixPath, Path
from typing import (
    Any, Callable, Dict, Iterable, Iterator, List, Match,
    Optional, Sequence, Set, Tuple, Union,
)

import gitlab  # type: ignore
import pandas as pd
import sqlparse  # type: ignore
import yaml  # type: ignore
from sqlglot import exp, parse_one  # type: ignore
from sqlglot.errors import ParseError  # type: ignore
from psycopg2.extras import execute_values  # type: ignore
from config import (
    DEFAULT_GP_HOST,
    DEFAULT_GP_PORT,
    DEFAULT_GP_DB,
    DEFAULT_GP_USER,
    DEFAULT_GP_SCHEMA,
    DEFAULT_CORE_IKG_SCHEMA,
    DEFAULT_GP_OWNER_ROLE,
    DEFAULT_GP_READER_ROLE,
)

# ---------------------------------------------------------------------------
# Airflow detection — tolerate environments where Airflow is not installed
# ---------------------------------------------------------------------------
try:
    from airflow.models import Variable  # type: ignore
    from airflow.providers.postgres.hooks.postgres import PostgresHook  # type: ignore
    _HAS_AIRFLOW = True
except Exception:  # noqa: BLE001
    Variable = None  # type: ignore
    PostgresHook = None  # type: ignore
    _HAS_AIRFLOW = False


# =====================================================================================
# ODM CONSTANTS (UNCHANGED)
# =====================================================================================

GITLAB_URL = "https://devcloud.ubs.net"
ODM_PROJECT_PATH = (
    "ubs/gwma/smart-technology-and-analytics/staat-data-science/"
    "staat-ds-genesis/genesis-platform/odm-dags"
)
BRANCH = "develop"
SQL_PATH = "dags/odm/script/sql"

IGNORE_FILES = {"aa_nlg_review.sql"}
IGNORE_FOLDERS = {"odm_process"}

REPORT_COLUMNS: Sequence[str] = (
    "filename",
    "target_type",
    "insight_type",
    "profile_table",
    "target_key",
    "metric_name",
    "metric_type",
    "metric_val",
    "run_id",
    "insight_date_time",
    "insight_category",
    "insight_att_name",
    "insight_att_val",
    "rule_column",
    "logic",
    "file_path",
    "dependency",
    "is_active",
    "generated_at",
)

PLACEHOLDER_PATTERN = re.compile(r"\{\{\s*([^\{\}]+?)\s*\}\}")

# Airflow variables
GITLAB_TOKEN_VAR = "GENESIS_DDLC_IKG_GIT_SECRET"
POSTGRES_CONN_ID_VAR = "IKG_POSTGRES_CONN_ID"


@dataclass
class ParsedRow:
    data: Dict[str, str]
    source_statement: str
    source_file: str


# =====================================================================================
# RUNTIME HELPERS — Airflow detection + credential / config resolution
# =====================================================================================

def is_running_in_airflow() -> bool:
    """Return True when executing inside an Airflow worker."""
    return _HAS_AIRFLOW and bool(os.environ.get("AIRFLOW_CTX_DAG_ID"))


def get_private_token(allow_prompt: bool = True) -> str:
    """Resolve GitLab token — Airflow Variables when in a DAG, else env / prompt."""
    if is_running_in_airflow():
        token = Variable.get(GITLAB_TOKEN_VAR, default_var=None)
        if not token:
            raise RuntimeError(f"'{GITLAB_TOKEN_VAR}' must be set.")
        return token
    # Local: environment variable or interactive prompt
    token = os.environ.get(GITLAB_TOKEN_VAR) or os.environ.get("GITLAB_TOKEN")
    if token:
        return token
    if allow_prompt:
        return getpass.getpass("Enter your GitLab private token: ")
    raise RuntimeError("GitLab token not found in environment and prompting is disabled.")


def get_gp_schema() -> str:
    """Return the environment-appropriate GP schema name.

    On Airflow this reads ``IKG_SCHEMA`` from the shared IKG props
    (which varies by Preview / UAT / Prod).  Locally it falls back
    to the ``GP_SCHEMA`` environment variable or the compile-time default.
    """
    if is_running_in_airflow():
        try:
            from ikg.scripts.python import props as ikg_props  # type: ignore
            airflow_props = ikg_props.get_airflow_variables()
            schema = airflow_props.get("IKG_SCHEMA")
            if schema:
                return schema
        except Exception as exc:
            logging.warning("Could not resolve IKG_SCHEMA from Airflow props: %s", exc)
    return os.environ.get("GP_SCHEMA", DEFAULT_GP_SCHEMA)

def get_owner_role() -> str:
    """Return the table owner role.

    On Airflow: ``IKG_TABLE_OWNER_GROUP`` Airflow Variable.
    Locally: ``GP_OWNER_ROLE`` env var or default.
    """
    if is_running_in_airflow():
        try:
            return Variable.get("IKG_TABLE_OWNER_GROUP")
        except Exception as exc:
            logging.warning("Could not resolve IKG_TABLE_OWNER_GROUP: %s", exc)
    return os.environ.get("GP_OWNER_ROLE", DEFAULT_GP_OWNER_ROLE)


def get_reader_role() -> str:
    """Return the table reader (SELECT grant) role.

    On Airflow: ``IKG_TABLE_READER_GROUP`` Airflow Variable.
    Locally: ``GP_READER_ROLE`` env var or default.
    """
    if is_running_in_airflow():
        try:
            return Variable.get("IKG_TABLE_READER_GROUP")
        except Exception as exc:
            logging.warning("Could not resolve IKG_TABLE_READER_GROUP: %s", exc)
    return os.environ.get("GP_READER_ROLE", DEFAULT_GP_READER_ROLE)


class _LocalPostgresHookShim:
    """Provides a ``get_conn()`` interface identical to ``PostgresHook``
    but backed by a direct *psycopg2* connection for local runs."""

    def __init__(self) -> None:
        self._conn_params: Dict[str, Any] = {
            "host": os.environ.get("GP_HOST", DEFAULT_GP_HOST),
            "port": int(os.environ.get("GP_PORT", str(DEFAULT_GP_PORT))),
            "dbname": os.environ.get("GP_DB", DEFAULT_GP_DB),
            "user": os.environ.get("GP_USER", DEFAULT_GP_USER),
            "password": (
                os.environ.get("GP_PASSWORD")
                or getpass.getpass("Enter Greenplum password: ")
            ),
        }

    def get_conn(self):
        import psycopg2  # local import keeps psycopg2 optional at import time
        return psycopg2.connect(**self._conn_params)


def _get_postgres_hook():
    """Return a ``PostgresHook`` (Airflow) or equivalent shim (local)."""
    if is_running_in_airflow():
        postgres_conn_id = Variable.get(POSTGRES_CONN_ID_VAR)
        return PostgresHook(postgres_conn_id=postgres_conn_id)
    return _LocalPostgresHookShim()


def _log_and_execute(cur, query: str, params=None) -> None:
    """Log the exact SQL query and execute (like you requested)."""
    q = (query or "").strip()
    logging.info("[DB] Executing query:\n%s", q)
    if params is None:
        cur.execute(query)
    else:
        cur.execute(query, params)


def get_max_profile_date(ikg_schema: str, table_name: str):
    """
    Example implemented with PostgresHook.
    """
    hook = _get_postgres_hook()
    with hook.get_conn() as conn:
        with conn.cursor() as cur:
            query = f"SELECT MAX(profile_date) FROM {ikg_schema}.{table_name}"
            _log_and_execute(cur, query)
            profile_date = cur.fetchone()[0]
    return profile_date


# =====================================================================================
# ODM PARSER / EXTRACTOR (UNCHANGED - YOUR ORIGINAL CODE)
# =====================================================================================

def mask_placeholders(sql_text: str) -> Tuple[str, Dict[str, str]]:
    """Replace Jinja placeholders with SQL-safe tokens and keep a reverse map."""
    mapping: Dict[str, str] = {}

    def _replace(match: re.Match[str]) -> str:
        token = f"__JINJA_{len(mapping)}__"
        mapping[token] = match.group(0)
        return token

    masked_sql = PLACEHOLDER_PATTERN.sub(_replace, sql_text)
    return masked_sql, mapping


def unmask_placeholders(text: str, mapping: Dict[str, str]) -> str:
    """Restore original Jinja placeholders in the provided text."""
    result = text
    for token, placeholder in mapping.items():
        result = result.replace(token, placeholder)
    return result


def normalize_value(column_name: str, value: str) -> str:
    """Apply column-specific normalization rules."""
    text = (value or "").strip()
    if column_name in {"insight_type", "target_type"}:
        if len(text) >= 2 and text[0] == text[-1] and text[0] in {"'", '"'}:
            text = text[1:-1].strip()
    return text


def normalize_report_column_name(column_name: str) -> str:
    """Normalize report column names to match expected output schema."""
    normalized = (column_name or "").strip().lower()
    if normalized == "profile_column":
        return "rule_column"
    return normalized


def strip_quotes(value: str) -> str:
    """Remove single/double quotes surrounding a literal value."""
    text = (value or "").strip()
    if len(text) >= 2 and text[0] == text[-1] and text[0] in {"'", '"'}:
        text = text[1:-1]
    return text.strip()


def normalize_profile_table_value(value: str) -> str:
    """Remove schema parameter prefix from profile table references."""
    if not value:
        return value
    cleaned = value.strip()
    cleaned = re.sub(
        r"^\{\{\s*params\.IKG_SCHEMA\s*\}\}\.",
        "",
        cleaned,
        flags=re.IGNORECASE,
    )
    return strip_quotes(cleaned)


def normalize_filter_text(value: str) -> str:
    """Normalize text for comparison in exclusion filters."""
    return strip_quotes((value or "")).strip().lower()


EXCLUDED_PROFILE_TABLES = {
    normalize_filter_text(normalize_profile_table_value("fl_rec_profile_curr_ikg AS fl"))
}
EXCLUDED_TARGET_KEYS = {
    normalize_filter_text("cast(ip_cli_i as text)")
}


def extract_insert_columns_from_text(sql_text: str) -> List[str]:
    """Extract the column list from an INSERT statement using simple bracket matching."""
    lowered = sql_text.lower()
    select_idx = lowered.find("select")
    if select_idx == -1:
        return []

    insert_segment = sql_text[:select_idx]
    open_idx = insert_segment.find("(")
    if open_idx == -1:
        return []

    depth = 0
    close_idx = -1
    for pos in range(open_idx, len(sql_text)):
        char = sql_text[pos]
        if char == "(":
            depth += 1
        elif char == ")":
            depth -= 1
            if depth == 0:
                close_idx = pos
                break

    if close_idx == -1:
        return []

    column_section = sql_text[open_idx + 1 : close_idx]
    columns = [
        col.strip().strip('"').strip()
        for col in column_section.split(",")
        if col.strip()
    ]
    return columns


def collect_sql_file_paths(project: gitlab.v4.objects.Project, sql_root: str, ref: str) -> List[str]:
    """Recursively list SQL files under the provided path using the GitLab tree API."""
    stack = [sql_root]
    sql_files: List[str] = []

    while stack:
        current_path = stack.pop()
        for node in project.repository_tree(path=current_path, ref=ref, all=True):
            node_path: str = node["path"]
            node_type: str = node["type"]

            lower_parts = {part.lower() for part in node_path.split("/")}
            if any(folder in lower_parts for folder in IGNORE_FOLDERS):
                continue

            if node_type == "tree":
                stack.append(node_path)
            elif node_type == "blob" and node_path.lower().endswith(".sql"):
                if os.path.basename(node_path) in IGNORE_FILES:
                    continue
                sql_files.append(node_path)

    return sorted(sql_files)


def fetch_sql(project: gitlab.v4.objects.Project, path: str, ref: str) -> str:
    """Download and decode a SQL file from GitLab."""
    file_obj = project.files.get(file_path=path, ref=ref)
    return base64.b64decode(file_obj.content).decode("utf-8", errors="replace")


def parse_insert_statement(statement: str, source_file: str) -> List[ParsedRow]:
    """Parse INSERT statements that load into the ODM table and extract column mappings."""
    masked_sql, placeholder_map = mask_placeholders(statement)

    try:
        expression = parse_one(masked_sql, read="postgres")
    except ParseError as exc:
        logging.warning("Skipping statement in %s due to parse error: %s", source_file, exc)
        return []

    if not isinstance(expression, exp.Insert):
        return []

    # FIX: build full_statement early so fallback paths can use it safely
    full_statement = unmask_placeholders(expression.sql(dialect="postgres"), placeholder_map)

    table_expr = expression.this
    if isinstance(table_expr, exp.Schema) and table_expr.this is not None:
        table_sql = table_expr.this.sql(dialect="postgres")
    else:
        table_sql = expression.this.sql(dialect="postgres")

    target_table = unmask_placeholders(table_sql, placeholder_map)
    target_table_normalized = target_table.replace(" ", "").lower()
    if "{{params.odm_table}}" not in target_table_normalized:
        return []

    columns_expr = expression.args.get("columns")
    target_columns: List[str] = []

    column_items = None
    if columns_expr:
        column_items = columns_expr.expressions if hasattr(columns_expr, "expressions") else columns_expr
    elif isinstance(table_expr, exp.Schema) and table_expr.expressions:
        column_items = table_expr.expressions

    if column_items:
        target_columns = [
            unmask_placeholders(col.sql(dialect="postgres"), placeholder_map).strip('"').strip()
            for col in column_items
        ]
    else:
        target_columns = extract_insert_columns_from_text(
            unmask_placeholders(statement, placeholder_map)
        )
        if not target_columns:
            logging.warning("Insert without explicit column list in %s; skipping.", source_file)
            return []

    payload = expression.args.get("expression")
    if payload is None:
        fallback_rows = fallback_build_rows_from_select(
            masked_sql,
            placeholder_map,
            target_columns,
            full_statement,
            source_file,
        )
        return fallback_rows

    rows: List[ParsedRow] = []

    base_ctes: Dict[str, exp.Expression] = {}
    insert_with = expression.args.get("with")
    if isinstance(insert_with, exp.With):
        for cte in insert_with.expressions:
            cte_name = (cte.alias or cte.alias_or_name or "").lower()
            if cte_name:
                base_ctes[cte_name] = cte.this

    if isinstance(payload, exp.With):
        for cte in payload.expressions:
            cte_name = (cte.alias or cte.alias_or_name or "").lower()
            if cte_name:
                base_ctes[cte_name] = cte.this
        payload = payload.this
    if isinstance(payload, exp.Paren):
        payload = payload.this

    select_statements = list(iter_select_statements(payload, base_ctes=base_ctes))
    if select_statements:
        for select_stmt, cte_scope in select_statements:
            rows.extend(
                build_rows_from_select(
                    target_columns,
                    select_stmt,
                    placeholder_map,
                    full_statement,
                    source_file,
                    cte_scope,
                )
            )
    elif isinstance(payload, exp.Values):
        value_rows: List[List[str]] = []
        for tup in payload.expressions:
            value_rows.append(
                [
                    unmask_placeholders(item.sql(dialect="postgres"), placeholder_map).strip()
                    for item in tup.expressions
                ]
            )
        rows.extend(
            build_rows_from_values(
                target_columns,
                value_rows,
                "",
                full_statement,
                source_file,
            )
        )
    else:
        logging.warning(
            "Unsupported INSERT payload (%s) in %s; statement skipped.",
            type(payload).__name__,
            source_file,
        )

    if not rows:
        rows = fallback_build_rows_from_select(
            masked_sql,
            placeholder_map,
            target_columns,
            full_statement,
            source_file,
        )

    return rows


def build_rows_from_values(
    target_columns: Sequence[str],
    value_rows: Sequence[Sequence[str]],
    logic_sql: str,
    full_statement: str,
    source_file: str,
) -> List[ParsedRow]:
    """Align column names and row values, trimming and normalizing for the report."""
    normalized_columns = [normalize_report_column_name(col) for col in target_columns]
    missing = [
        col for col in REPORT_COLUMNS
        if col not in normalized_columns and col not in {"logic", "file_path"}
    ]
    if missing:
        logging.debug(
            "Columns missing from INSERT target in %s: %s",
            source_file,
            ", ".join(missing),
        )

    parsed_rows: List[ParsedRow] = []

    for values in value_rows:
        row_map: Dict[str, str] = {}
        for idx, col in enumerate(target_columns):
            normalized_col = normalize_report_column_name(col)
            raw_value = values[idx] if idx < len(values) else ""
            row_map[normalized_col] = normalize_value(normalized_col, raw_value)

        report_data = {column: row_map.get(column, "") for column in REPORT_COLUMNS}
        report_data["logic"] = logic_sql.strip()
        report_data["file_path"] = source_file
        report_data["dependency"] = ""
        report_data["filename"] = os.path.basename(source_file)
        report_data["profile_table"] = normalize_profile_table_value(report_data.get("profile_table", ""))
        report_data["is_active"] = ""
        report_data["generated_at"] = ""
        parsed_rows.append(
            ParsedRow(
                data=report_data,
                source_statement=full_statement,
                source_file=source_file,
            )
        )

    return parsed_rows


def iter_select_statements(
    expression: exp.Expression | None,
    base_ctes: Dict[str, exp.Expression] | None = None,
) -> List[Tuple[exp.Select, Dict[str, exp.Expression]]]:
    """Yield SELECT statements and their visible CTE map, flattening set operations."""
    if expression is None:
        return []

    initial_ctes = dict(base_ctes or {})
    stack: List[Tuple[exp.Expression, Dict[str, exp.Expression]]] = [(expression, initial_ctes)]
    results: List[Tuple[exp.Select, Dict[str, exp.Expression]]] = []

    while stack:
        node, cte_scope = stack.pop()
        if isinstance(node, exp.Paren):
            stack.append((node.this, dict(cte_scope)))
            continue
        if isinstance(node, exp.With):
            updated_scope = dict(cte_scope)
            for cte in node.expressions:
                cte_name = (cte.alias or cte.alias_or_name or "").lower()
                if not cte_name:
                    continue
                updated_scope[cte_name] = cte.this
            stack.append((node.this, updated_scope))
            continue
        if isinstance(node, exp.Subquery):
            stack.append((node.this, dict(cte_scope)))
            continue
        if isinstance(node, (exp.Order, exp.Limit)):
            stack.append((node.this, dict(cte_scope)))
            continue
        if isinstance(node, exp.Select):
            scope_for_select = dict(cte_scope)
            with_clause = node.args.get("with")
            if isinstance(with_clause, exp.With):
                for cte in with_clause.expressions:
                    cte_name = (cte.alias or cte.alias_or_name or "").lower()
                    if not cte_name:
                        continue
                    scope_for_select[cte_name] = cte.this
            results.append((node, scope_for_select))
            continue
        if isinstance(node, exp.SetOperation):
            stack.append((node.right, dict(cte_scope)))
            stack.append((node.left, dict(cte_scope)))
            continue

    return results


# ---- STAR EXPANSION + DEPENDENCY + SELECT PROCESSING (unchanged from your original)
def expand_select_expressions(
    select_expression: exp.Select,
    placeholder_map: Dict[str, str],
    cte_map: Dict[str, exp.Expression],
    column_cache: Dict[str, List[exp.Expression]],
    visited_ctes: Set[str],
) -> List[exp.Expression]:
    """Expand SELECT list, replacing star expressions with concrete expressions when possible."""
    expanded: List[exp.Expression] = []

    for expression in select_expression.expressions:
        replacement = _expand_select_expression_item(
            expression,
            select_expression,
            placeholder_map,
            cte_map,
            column_cache,
            visited_ctes,
        )
        if not replacement:
            expanded.append(expression)
        else:
            expanded.extend(replacement)

    return expanded


def _expand_select_expression_item(
    expression: exp.Expression,
    select_expression: exp.Select,
    placeholder_map: Dict[str, str],
    cte_map: Dict[str, exp.Expression],
    column_cache: Dict[str, List[exp.Expression]],
    visited_ctes: Set[str],
) -> List[exp.Expression]:
    if isinstance(expression, exp.Star):
        resolved = _resolve_star_expressions(
            select_expression,
            qualifier=None,
            placeholder_map=placeholder_map,
            cte_map=cte_map,
            column_cache=column_cache,
            visited_ctes=visited_ctes,
        )
        return resolved

    if isinstance(expression, exp.Column) and getattr(expression, "is_star", False):
        table_ref = expression.table
        qualifier = (
            table_ref.sql(dialect="postgres")
            if isinstance(table_ref, exp.Expression)
            else (str(table_ref) if table_ref else None)
        )
        resolved = _resolve_star_expressions(
            select_expression,
            qualifier=qualifier.lower() if qualifier else None,
            placeholder_map=placeholder_map,
            cte_map=cte_map,
            column_cache=column_cache,
            visited_ctes=visited_ctes,
        )
        return resolved

    return []


def _resolve_star_expressions(
    select_expression: exp.Select,
    qualifier: str | None,
    placeholder_map: Dict[str, str],
    cte_map: Dict[str, exp.Expression],
    column_cache: Dict[str, List[exp.Expression]],
    visited_ctes: Set[str],
) -> List[exp.Expression]:
    resolved: List[exp.Expression] = []

    sources: List[exp.Expression] = []
    from_expr = select_expression.args.get("from")
    if isinstance(from_expr, exp.From) and from_expr.this is not None:
        sources.append(from_expr.this)
    for join in select_expression.args.get("joins") or []:
        sources.append(join.this)

    qualifier_lower = qualifier.lower() if qualifier else None

    for source in sources:
        alias = (source.alias or source.alias_or_name or "").strip()
        alias_lower = alias.lower()
        if qualifier_lower and alias_lower != qualifier_lower:
            continue

        expressions = _resolve_source_output_expressions(
            source,
            alias_lower,
            placeholder_map,
            cte_map,
            column_cache,
            visited_ctes,
        )
        if expressions:
            resolved.extend(expressions)
        if qualifier_lower:
            break

    return resolved


def _resolve_source_output_expressions(
    source_expression: exp.Expression,
    alias_lower: str,
    placeholder_map: Dict[str, str],
    cte_map: Dict[str, exp.Expression],
    column_cache: Dict[str, List[exp.Expression]],
    visited_ctes: Set[str],
) -> List[exp.Expression]:
    if alias_lower in column_cache:
        return [expr.copy() for expr in column_cache[alias_lower]]

    resolved: List[exp.Expression] = []

    if alias_lower and alias_lower in cte_map:
        if alias_lower in visited_ctes:
            return []
        visited_ctes.add(alias_lower)
        cte_expression = cte_map[alias_lower]
        for inner_select, inner_cte_scope in iter_select_statements(cte_expression, base_ctes=cte_map):
            combined_scope = dict(cte_map)
            combined_scope.update(inner_cte_scope)
            resolved = expand_select_expressions(
                inner_select,
                placeholder_map,
                combined_scope,
                column_cache,
                visited_ctes,
            )
            if resolved:
                break
        visited_ctes.remove(alias_lower)
    elif isinstance(source_expression, exp.Subquery):
        subquery_expression = source_expression.this
        for inner_select, inner_cte_scope in iter_select_statements(subquery_expression, base_ctes=cte_map):
            combined_scope = dict(cte_map)
            combined_scope.update(inner_cte_scope)
            resolved = expand_select_expressions(
                inner_select,
                placeholder_map,
                combined_scope,
                column_cache,
                visited_ctes,
            )
            if resolved:
                break

    if alias_lower and resolved:
        column_cache[alias_lower] = [expr.copy() for expr in resolved]

    return [expr.copy() for expr in resolved]


def normalize_insight_type_key(value: str) -> str:
    return strip_quotes(value).strip().lower()


def extract_profile_table(select_expression: exp.Select, placeholder_map: Dict[str, str]) -> str:
    for table in select_expression.find_all(exp.Table):
        table_name = unmask_placeholders(table.sql(dialect="postgres"), placeholder_map)
        return normalize_profile_table_value(table_name)
    return ""


def column_in_odm_table_subquery(
    column: exp.Column,
    root_select: exp.Select,
    placeholder_map: Dict[str, str],
) -> bool:
    current: exp.Expression | None = column
    while current is not None:
        if current is root_select:
            return False
        if isinstance(current, exp.Select):
            for table in current.find_all(exp.Table):
                table_sql = unmask_placeholders(table.sql(dialect="postgres"), placeholder_map)
                normalized = table_sql.replace(" ", "").lower()
                if "{{params.odm_table}}" in normalized:
                    return True
        current = current.parent
    return False


def extract_where_context(
    select_expression: exp.Select,
    placeholder_map: Dict[str, str],
) -> Tuple[str, List[str]]:
    where_clause = ""
    profile_columns: List[str] = []
    seen: Set[str] = set()

    where_exp = select_expression.args.get("where")
    if not where_exp:
        return where_clause, profile_columns

    where_clause = unmask_placeholders(where_exp.this.sql(dialect="postgres"), placeholder_map).strip()

    for column in where_exp.this.find_all(exp.Column):
        if column_in_odm_table_subquery(column, select_expression, placeholder_map):
            continue
        column_sql = unmask_placeholders(column.sql(dialect="postgres"), placeholder_map).strip()
        if not column_sql or column_sql.lower() == "null":
            continue
        if column_sql not in seen:
            seen.add(column_sql)
            profile_columns.append(column_sql)

    return where_clause, profile_columns


def extract_value_combinations(select_expression: exp.Select, placeholder_map: Dict[str, str]) -> List[Dict[str, str]]:
    value_tables: List[Tuple[Set[str], List[str], List[List[str]]]] = []

    for values_expr in select_expression.find_all(exp.Values):
        base_expr = values_expr
        if isinstance(base_expr, exp.Paren):
            base_expr = base_expr.this

        table_alias = values_expr.args.get("alias")
        if not table_alias:
            continue

        alias_sql_name = table_alias.this.sql(dialect="postgres").strip()
        if not alias_sql_name:
            continue
        alias_variants = {alias_sql_name.lower(), alias_sql_name.replace('"', "").lower()}

        alias_columns_expr = table_alias.args.get("columns")
        if alias_columns_expr is None:
            continue

        if isinstance(alias_columns_expr, list):
            alias_column_nodes = alias_columns_expr
        elif hasattr(alias_columns_expr, "expressions"):
            alias_column_nodes = list(alias_columns_expr.expressions)
        else:
            alias_column_nodes = [alias_columns_expr]

        alias_columns: List[str] = []
        for col in alias_column_nodes:
            column_sql = unmask_placeholders(col.sql(dialect="postgres"), placeholder_map).strip()
            if column_sql:
                alias_columns.append(column_sql)

        rows: List[List[str]] = []
        for tuple_expr in base_expr.expressions:
            row_values: List[str] = []
            for value_expr in tuple_expr.expressions:
                value_text = unmask_placeholders(value_expr.sql(dialect="postgres"), placeholder_map).strip()
                row_values.append(value_text)
            rows.append(row_values)

        if alias_columns and rows:
            value_tables.append((alias_variants, alias_columns, rows))

    if not value_tables:
        return [dict()]

    combinations: List[Dict[str, str]] = [dict()]
    for alias_variants, columns, rows in value_tables:
        new_combinations: List[Dict[str, str]] = []
        for combo in combinations:
            for row in rows:
                updated = combo.copy()
                for idx, column_name in enumerate(columns):
                    value = row[idx] if idx < len(row) else ""
                    column_clean = column_name.replace('"', "")
                    column_variants = {column_name.lower(), column_clean.lower(), f'"{column_clean}"'.lower()}
                    for alias_variant in alias_variants:
                        updated[f"{alias_variant}.{column_name}".lower()] = value
                        updated[f"{alias_variant}.{column_clean}".lower()] = value
                        updated[f'{alias_variant}."{column_clean}"'.lower()] = value
                    for column_variant in column_variants:
                        updated[column_variant] = value
                new_combinations.append(updated)
        combinations = new_combinations or combinations

    return combinations or [dict()]


def evaluate_select_expression(expr: exp.Expression | None, combination: Dict[str, str], placeholder_map: Dict[str, str]) -> str:
    if expr is None:
        return ""
    if isinstance(expr, exp.Alias):
        expr = expr.this

    expr_sql = unmask_placeholders(expr.sql(dialect="postgres"), placeholder_map).strip()
    lookup_key = expr_sql.lower()

    if lookup_key in combination:
        return combination[lookup_key]

    if "." in lookup_key:
        _, column_only = lookup_key.rsplit(".", 1)
        if column_only in combination:
            return combination[column_only]

    if isinstance(expr, exp.Literal):
        return expr_sql

    return expr_sql


def _infer_select_column_names(select_expression: exp.Select, placeholder_map: Dict[str, str], cte_map: Dict[str, exp.Expression]) -> List[str]:
    expanded = expand_select_expressions(select_expression, placeholder_map, cte_map, column_cache={}, visited_ctes=set())
    names: List[str] = []
    for idx, expression in enumerate(expanded):
        alias_or_name = (expression.alias_or_name or "").replace('"', "").strip()
        if not alias_or_name and isinstance(expression, exp.Column):
            alias_or_name = (expression.alias_or_name or expression.output_name or "").replace('"', "").strip()
        if not alias_or_name:
            alias_or_name = f"column_{idx}"
        names.append(alias_or_name.lower())
    return names


def extract_dependency_values(
    select_expression: exp.Select,
    placeholder_map: Dict[str, str],
    cte_map: Dict[str, exp.Expression],
    visited_ctes: Set[str] | None = None,
    expected_column_names: Sequence[str] | None = None,
) -> List[str]:
    seen: Set[str] = set()
    ordered: List[str] = []

    def add_value(raw_value: str) -> None:
        literal = strip_quotes(unmask_placeholders(raw_value, placeholder_map))
        if literal and literal not in seen:
            seen.add(literal)
            ordered.append(literal)

    def is_insight_type_reference(expr: exp.Expression | None) -> bool:
        if expr is None:
            return False
        if isinstance(expr, exp.Column):
            column_sql = unmask_placeholders(expr.sql(dialect="postgres"), placeholder_map)
            normalized = column_sql.replace('"', "").strip().lower()
            return normalized.endswith(".insight_type") or normalized == "insight_type"
        return False

    for combination in extract_value_combinations(select_expression, placeholder_map):
        for key, raw in combination.items():
            column_ref = key.replace('"', "").strip().lower().split(".")[-1]
            if column_ref == "insight_type":
                add_value(raw)

    for idx, expression in enumerate(select_expression.expressions):
        alias_raw = (expression.alias_or_name or "").replace('"', "").strip()
        alias_or_name = alias_raw.lower()
        if isinstance(expression, exp.Literal):
            literal_text = strip_quotes(unmask_placeholders(expression.sql(dialect="postgres"), placeholder_map))
            if alias_raw.lower() == literal_text.lower():
                alias_or_name = ""
        if not alias_or_name and expected_column_names and idx < len(expected_column_names):
            alias_or_name = expected_column_names[idx]

        expr_node = expression.this if isinstance(expression, exp.Alias) else expression
        if alias_or_name == "insight_type" and isinstance(expr_node, exp.Literal):
            add_value(expr_node.sql(dialect="postgres"))

    where_exp = select_expression.args.get("where")
    if where_exp:
        for condition in where_exp.this.walk():
            if isinstance(condition, exp.EQ):
                left = condition.left
                right = condition.right
                if is_insight_type_reference(left) and isinstance(right, exp.Literal):
                    add_value(right.sql(dialect="postgres"))
                elif is_insight_type_reference(right) and isinstance(left, exp.Literal):
                    add_value(left.sql(dialect="postgres"))
            elif isinstance(condition, exp.In):
                if is_insight_type_reference(condition.this):
                    for option in condition.expressions:
                        if isinstance(option, exp.Literal):
                            add_value(option.sql(dialect="postgres"))

    if cte_map:
        visited = visited_ctes or set()
        referenced_ctes: Set[str] = set()
        for table in select_expression.find_all(exp.Table):
            table_name = (table.name or "").lower()
            if table_name in cte_map:
                referenced_ctes.add(table_name)

        for cte_name in referenced_ctes:
            if cte_name in visited or cte_name not in cte_map:
                continue
            visited.add(cte_name)
            cte_expression = cte_map[cte_name]
            reference_names: Sequence[str] | None = None

            for inner_select, inner_cte_map in iter_select_statements(cte_expression, base_ctes=cte_map):
                combined_map = dict(cte_map)
                combined_map.update(inner_cte_map)
                if reference_names is None:
                    reference_names = _infer_select_column_names(inner_select, placeholder_map, combined_map)
                inner_values = extract_dependency_values(inner_select, placeholder_map, combined_map, visited, reference_names)
                for value in inner_values:
                    if value not in seen:
                        seen.add(value)
                        ordered.append(value)

    return ordered


def build_rows_from_select(
    target_columns: Sequence[str],
    select_expression: exp.Select,
    placeholder_map: Dict[str, str],
    full_statement: str,
    source_file: str,
    cte_map: Dict[str, exp.Expression],
) -> List[ParsedRow]:
    normalized_columns = [normalize_report_column_name(col) for col in target_columns]
    select_items = expand_select_expressions(select_expression, placeholder_map, cte_map, column_cache={}, visited_ctes=set())

    profile_table = extract_profile_table(select_expression, placeholder_map)
    where_logic, profile_columns = extract_where_context(select_expression, placeholder_map)

    alias_map: Dict[str, List[exp.Expression]] = {}
    for expr in select_items:
        raw_key = (expr.alias_or_name or "").replace('"', "").strip()
        key = normalize_report_column_name(raw_key)
        if key:
            value_expr = expr.this if isinstance(expr, exp.Alias) else expr
            alias_map.setdefault(key, []).append(value_expr)

    select_mappings: List[Tuple[str, exp.Expression | None]] = []
    for idx, column_name in enumerate(normalized_columns):
        expr_node: exp.Expression | None = None
        if column_name in alias_map and alias_map[column_name]:
            expr_node = alias_map[column_name].pop(0)
        elif idx < len(select_items):
            candidate = select_items[idx]
            expr_node = candidate.this if isinstance(candidate, exp.Alias) else candidate
        select_mappings.append((column_name, expr_node))

    dependency_values = extract_dependency_values(select_expression, placeholder_map, cte_map, expected_column_names=normalized_columns)
    dependency_text = ", ".join(dependency_values)

    base_defaults: Dict[str, str] = {column: "" for column in REPORT_COLUMNS}
    base_defaults["profile_table"] = profile_table
    base_defaults["file_path"] = source_file
    base_defaults["dependency"] = dependency_text
    base_defaults["filename"] = os.path.basename(source_file)
    base_defaults["is_active"] = ""
    base_defaults["generated_at"] = ""

    parsed_rows: List[ParsedRow] = []
    target_rule_columns = profile_columns or [""]
    value_combinations = extract_value_combinations(select_expression, placeholder_map)

    if len(select_items) < len(target_columns):
        logging.warning(
            "Column/SELECT mismatch in %s: %d columns but %d select expressions.",
            source_file,
            len(target_columns),
            len(select_items),
        )

    for combination in value_combinations:
        row_base = base_defaults.copy()
        for column_name, expr_node in select_mappings:
            raw_value = evaluate_select_expression(expr_node, combination, placeholder_map)
            row_base[column_name] = normalize_value(column_name, raw_value)

        for rule_column in target_rule_columns:
            row_data = row_base.copy()
            row_data["rule_column"] = rule_column
            row_data["logic"] = where_logic

            insight_key = normalize_insight_type_key(row_data.get("insight_type", ""))
            filtered_dependencies = [v for v in dependency_values if normalize_insight_type_key(v) != insight_key and v]
            row_data["dependency"] = ", ".join(filtered_dependencies)

            row_data["profile_table"] = normalize_profile_table_value(row_data.get("profile_table", ""))
            report_data = {column: row_data.get(column, "") for column in REPORT_COLUMNS}

            parsed_rows.append(
                ParsedRow(
                    data=report_data,
                    source_statement=full_statement,
                    source_file=source_file,
                )
            )

    return parsed_rows


def fallback_build_rows_from_select(
    masked_statement: str,
    placeholder_map: Dict[str, str],
    target_columns: Sequence[str],
    full_statement: str,
    source_file: str,
) -> List[ParsedRow]:
    if not target_columns:
        target_columns = extract_insert_columns_from_text(unmask_placeholders(masked_statement, placeholder_map))
        if not target_columns:
            return []

    lower_masked = masked_statement.lower()
    select_pos = lower_masked.find("select")
    if select_pos == -1:
        return []

    select_sql_masked = masked_statement[select_pos:].strip().rstrip(";")

    try:
        select_expression = parse_one(select_sql_masked, read="postgres")
    except ParseError as exc:
        logging.warning("Fallback parse error in %s: %s", source_file, exc)
        return []

    base_ctes: Dict[str, exp.Expression] = {}
    if isinstance(select_expression, exp.With):
        for cte in select_expression.expressions:
            cte_name = (cte.alias or cte.alias_or_name or "").lower()
            if cte_name:
                base_ctes[cte_name] = cte.this
        select_expression = select_expression.this

    select_statements = list(iter_select_statements(select_expression, base_ctes=base_ctes))
    if not select_statements:
        logging.warning(
            "Fallback parser produced %s instead of SELECT in %s; skipping.",
            type(select_expression).__name__,
            source_file,
        )
        return []

    fallback_rows: List[ParsedRow] = []
    for stmt, cte_scope in select_statements:
        fallback_rows.extend(build_rows_from_select(target_columns, stmt, placeholder_map, full_statement, source_file, cte_scope))

    return fallback_rows


def extract_report_rows(sql_text: str, source_file: str) -> List[ParsedRow]:
    rows: List[ParsedRow] = []
    for statement in sqlparse.split(sql_text):
        cleaned_statement = statement.strip()
        if not cleaned_statement:
            continue
        rows.extend(parse_insert_statement(cleaned_statement, source_file))
    return rows


def create_report_dataframe(rows: Iterable[ParsedRow]) -> pd.DataFrame:
    data = [row.data for row in rows]
    return pd.DataFrame(data, columns=REPORT_COLUMNS)


def filter_excluded_records(df: pd.DataFrame) -> pd.DataFrame:
    profile_table_normalized = df["profile_table"].fillna("").map(normalize_filter_text)
    target_key_normalized = df["target_key"].fillna("").map(normalize_filter_text)

    exclusion_mask = profile_table_normalized.isin(EXCLUDED_PROFILE_TABLES) | target_key_normalized.isin(EXCLUDED_TARGET_KEYS)

    excluded_count = int(exclusion_mask.sum())
    if excluded_count:
        logging.info("Excluding %d row(s) from report/output.", excluded_count)

    return df.loc[~exclusion_mask].reset_index(drop=True)


def write_excel_report(df: pd.DataFrame, directory: str = ".") -> str:
    timestamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d_%H%M%S")
    filename = f"odm_rules_details_{timestamp}.xlsx"
    output_path = os.path.abspath(os.path.join(directory, filename))

    logging.info("Writing Excel report to %s", output_path)
    with pd.ExcelWriter(output_path, engine="xlsxwriter") as writer:
        df.to_excel(writer, index=False, sheet_name="odm_rules_details")

    return output_path


# ----------------------------
# ODM DB FUNCTIONS (UNCHANGED)
# ----------------------------
def fetch_exclusion_insight_types() -> Set[str]:
    """Fetch insight types that should be marked as inactive."""
    ikg_schema = get_gp_schema()
    query = f"""
        SELECT insight_type
        FROM {ikg_schema}.odm_exclusion_insight_type
        WHERE is_curr = 1
    """

    hook = _get_postgres_hook()
    with hook.get_conn() as conn:
        with conn.cursor() as cur:
            _log_and_execute(cur, query)
            results = cur.fetchall() or []

    return {normalize_insight_type_key(row[0]) for row in results if row and row[0]}


def upload_dataframe_to_db(df: pd.DataFrame) -> None:
    """Drop and recreate the destination table, then load the DataFrame contents (Hook-based)."""
    schema = get_gp_schema()
    table_fqn = f"{schema}.odm_rule_metadata_auto_refresh"
    owner_role = get_owner_role()
    reader_role = get_reader_role()

    drop_sql = f"DROP TABLE IF EXISTS {table_fqn};"
    column_definitions = ", ".join(f'"{column}" TEXT' for column in REPORT_COLUMNS)
    create_sql = f"CREATE TABLE {table_fqn} ({column_definitions});"
    alter_owner_sql = f"ALTER TABLE {table_fqn} OWNER TO {owner_role};"
    grant_sql = f"GRANT SELECT ON {table_fqn} TO {reader_role};"

    hook = _get_postgres_hook()
    with hook.get_conn() as conn:
        conn.autocommit = False
        with conn.cursor() as cur:
            _log_and_execute(cur, drop_sql)
            _log_and_execute(cur, create_sql)

            if not df.empty:
                columns_clause = ", ".join(f'"{column}"' for column in REPORT_COLUMNS)
                insert_sql = f"INSERT INTO {table_fqn} ({columns_clause}) VALUES %s"
                values = [tuple(row[column] for column in REPORT_COLUMNS) for _, row in df.iterrows()]

                logging.info("[DB] Bulk inserting %d rows into %s", len(values), table_fqn)
                logging.info("[DB] Insert template:\n%s", insert_sql)
                execute_values(cur, insert_sql, values)

            _log_and_execute(cur, alter_owner_sql)
            _log_and_execute(cur, grant_sql)

        conn.commit()
        logging.info("Table %s refreshed successfully.", table_fqn)


# ----------------------------
# ODM AIRFLOW ENTRYPOINT (UNCHANGED)
# ----------------------------
def run_odm_metadata_job() -> Dict[str, object]:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    private_token = get_private_token(allow_prompt=not is_running_in_airflow())

    # temp dir
    base_dir = os.path.dirname(os.path.abspath(__file__))
    timestamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d_%H%M%S")
    temp_dir = os.path.join(base_dir, f"temp_odm_metadata_{timestamp}")
    os.makedirs(temp_dir, exist_ok=True)
    logging.info("[ODM Metadata] Temporary folder created: %s", temp_dir)

    gl = gitlab.Gitlab(GITLAB_URL, private_token=private_token)
    logging.info("Fetching ODM project metadata...")
    project = gl.projects.get(ODM_PROJECT_PATH)

    logging.info("Collecting SQL file paths under %s...", SQL_PATH)
    sql_files = collect_sql_file_paths(project, SQL_PATH, BRANCH)
    logging.info("Found %d SQL files to inspect.", len(sql_files))

    all_rows: List[ParsedRow] = []
    for path in sql_files:
        sql_content = fetch_sql(project, path, BRANCH)
        rows = extract_report_rows(sql_content, path)
        if rows:
            logging.info("Extracted %d row(s) from %s", len(rows), path)
            all_rows.extend(rows)

    if not all_rows:
        raise RuntimeError("No ODM rule rows were parsed from the SQL sources.")

    df = create_report_dataframe(all_rows)

    generated_at = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M:%S%z")
    df["generated_at"] = generated_at
    df["filename"] = df["filename"].fillna("").apply(lambda v: os.path.basename(v) if isinstance(v, str) else "")
    df["profile_table"] = df["profile_table"].fillna("").apply(normalize_profile_table_value)
    df = filter_excluded_records(df)

    exclusion_types = fetch_exclusion_insight_types()
    logging.info("Fetched %d exclusion insight_type record(s) for is_active flag.", len(exclusion_types))

    def resolve_is_active(value: str) -> str:
        key = normalize_insight_type_key(value)
        return "N" if key and key in exclusion_types else "Y"

    df["is_active"] = df["insight_type"].fillna("").apply(resolve_is_active)

    excel_path = write_excel_report(df, directory=temp_dir)
    logging.info("Report contains %d rows.", len(df))

    upload_dataframe_to_db(df)
    logging.info("Process completed. Excel report saved at: %s", excel_path)

    return {
        "temp_dir": temp_dir,
        "excel_path": excel_path,
        "row_count": int(len(df)),
        "sql_files_scanned": int(len(sql_files)),
    }


# =====================================================================================
# NEW: NLG METADATA JOB (AIRFLOW + SAME HOOK PATTERN)
# =====================================================================================

# GitLab (NLG)
NLG_PROJECT_PATH = (
    "ubs/gwma/smart-technology-and-analytics/"
    "staat-data-science/staat-ds-genesis/genesis-platform/nlg-dags"
)
NLG_BRANCH = "develop"

# Repo paths
NLG_PATH_PROFILE_MAP = "dags/nlg/src/config/odm_profile_map/profile_tbl.yaml"
NLG_PATH_INPUT_CONFIG = "dags/nlg/src/config/input_data_config"
NLG_PATH_SQL_MAPPING = "dags/nlg/src/sql_column_mapping"

# Targets in GP — table names only; schema + roles are resolved at runtime
# via get_gp_schema(), get_owner_role(), get_reader_role().
NLG_TARGET_TABLE_INPUT = "nlg_input_config_metadata_auto_refresh"
NLG_TARGET_TABLE_SQL = "nlg_sql_mapping_metadata_auto_refresh"

# Parsing patterns
NLG_COLUMN_PATTERN = re.compile(r'\bb\.(?:"([^"]+)"|([A-Za-z0-9_]+))', re.IGNORECASE)
NLG_PROFILE_TABLE_KEYS = ["profile_table", "profile_tbl", "profile_table_name", "profile_tbl_name"]
NLG_JOIN_KEY_KEYS = ["joining_key", "join_key", "joining_keys", "join_keys"]
NLG_TARGET_TYPE_PATTERN = re.compile(r"^[A-Za-z0-9_]+$")

# Overrides
NLG_PROFILE_OVERRIDES = {
    "fl_recruitment": {
        "profile_table": "fl_rec_profile_curr_ikg",
        "joining_key": "fl_rec_profile_key",
    },
    "fl_ubs_fa": {
        "profile_table": "fl_fa_profile_curr_ikg",
        "joining_key": "f1_fa_profile_key",
    },
}


def _nlg_normalize_target_type(candidate, fallback=None) -> Optional[str]:
    if isinstance(candidate, str):
        stripped = candidate.strip()
        if stripped and NLG_TARGET_TYPE_PATTERN.fullmatch(stripped):
            return stripped
    if isinstance(fallback, str) and NLG_TARGET_TYPE_PATTERN.fullmatch(fallback.strip()):
        return fallback.strip()
    return None


def _nlg_fetch_file_content(project, file_path: str, ref: str) -> bytes:
    gl_file = project.files.get(file_path=file_path, ref=ref)
    return base64.b64decode(gl_file.content)


def _nlg_load_structured_file(project, file_path: str, ref: str):
    raw_bytes = _nlg_fetch_file_content(project, file_path, ref)
    text = raw_bytes.decode("utf-8", errors="replace")
    if file_path.lower().endswith(".json"):
        return json.loads(text)
    return yaml.safe_load(text)


def _nlg_walk_repository(project, path: str, ref: str):
    for item in project.repository_tree(path=path, ref=ref, all=True):
        full_path = f"{path}/{item['name']}" if path else item["name"]
        if item["type"] == "tree":
            yield from _nlg_walk_repository(project, full_path, ref)
        elif item["type"] == "blob":
            yield full_path


def _nlg_first_non_empty(container, keys: Sequence[str]):
    for key in keys:
        value = container.get(key) if isinstance(container, dict) else None
        if value not in (None, ""):
            return value
    return None


def _nlg_serialise_value(value):
    if value is None:
        return None
    if isinstance(value, (list, tuple, set)):
        return ", ".join(str(v) for v in value)
    if isinstance(value, dict):
        return json.dumps(value, sort_keys=True)
    return str(value)


def _nlg_deduplicate(rows: List[Dict[str, object]], key_fields: Sequence[str]) -> List[Dict[str, object]]:
    seen = set()
    deduped: List[Dict[str, object]] = []
    for row in rows:
        key = tuple(row.get(field) for field in key_fields)
        if key not in seen:
            seen.add(key)
            deduped.append(row)
    return deduped


def _nlg_search_profile_map(node, fallback_target=None) -> List[Dict[str, object]]:
    rows: List[Dict[str, object]] = []
    if isinstance(node, dict):
        explicit_target = node.get("target_type")
        normalized_target = _nlg_normalize_target_type(explicit_target, fallback_target)
        target_value = normalized_target or fallback_target
        profile_table = _nlg_first_non_empty(node, NLG_PROFILE_TABLE_KEYS)
        joining_key = _nlg_first_non_empty(node, NLG_JOIN_KEY_KEYS)
        if (profile_table or joining_key) and target_value:
            row = {
                "target_type": target_value,
                "profile_table": _nlg_serialise_value(profile_table),
                "joining_key": _nlg_serialise_value(joining_key),
            }
            rows.append(row)
        for key, value in node.items():
            key_fallback = _nlg_normalize_target_type(key, target_value)
            new_fallback = normalized_target or key_fallback or target_value
            rows.extend(_nlg_search_profile_map(value, fallback_target=new_fallback))
    elif isinstance(node, list):
        for item in node:
            rows.extend(_nlg_search_profile_map(item, fallback_target=fallback_target))
    return rows


def _nlg_collect_profile_map(project, ref: str, file_path: str) -> List[Dict[str, object]]:
    content = _nlg_load_structured_file(project, file_path, ref)
    if content is None:
        return []
    rows = _nlg_search_profile_map(content)
    return _nlg_deduplicate(rows, ["target_type", "profile_table", "joining_key"])


def _nlg_find_b_columns(expression: str) -> List[str]:
    columns: List[str] = []
    seen: Set[str] = set()
    for quoted, unquoted in NLG_COLUMN_PATTERN.findall(expression):
        column = quoted or unquoted
        if column:
            key = column.lower()
            if key not in seen:
                seen.add(key)
                columns.append(column)
    return columns


def _nlg_extract_logic_entries(node, prefix=None) -> List[Tuple[str, str, List[str]]]:
    entries: List[Tuple[str, str, List[str]]] = []
    if isinstance(node, dict):
        for key, value in node.items():
            new_prefix = f"{prefix}.{key}" if prefix else str(key)
            entries.extend(_nlg_extract_logic_entries(value, new_prefix))
    elif isinstance(node, list):
        for idx, item in enumerate(node):
            new_prefix = f"{prefix}[{idx}]" if prefix else f"[{idx}]"
            entries.extend(_nlg_extract_logic_entries(item, new_prefix))
    else:
        if isinstance(node, str):
            logic = node.strip()
            if not logic:
                return entries
            columns = _nlg_find_b_columns(logic)
            if columns:
                entries.append((prefix or "", logic, columns))
    return entries


def _nlg_derive_tag_name(tag_path: str) -> Optional[str]:
    if not tag_path:
        return None
    last_part = tag_path.split(".")[-1]
    last_part = re.sub(r"\[\d+\]", "", last_part)
    return last_part


def _nlg_should_skip_tag(tag_path: str) -> bool:
    if not tag_path:
        return True
    parts = [re.sub(r"\[\d+\]", "", segment) for segment in tag_path.split(".")]
    return any(part.lower() in {"target_type"} for part in parts if part)


def _nlg_find_explicit_target(node) -> Optional[str]:
    if isinstance(node, dict):
        value = node.get("target_type")
        if isinstance(value, str) and value:
            return value
        for child in node.values():
            result = _nlg_find_explicit_target(child)
            if result:
                return result
    elif isinstance(node, list):
        for item in node:
            result = _nlg_find_explicit_target(item)
            if result:
                return result
    return None


def _nlg_collect_input_config_rows(project, ref: str, base_path: str) -> List[Dict[str, object]]:
    rows: List[Dict[str, object]] = []
    for file_path in _nlg_walk_repository(project, base_path, ref):
        if not file_path.lower().endswith((".yml", ".yaml")):
            continue
        data = _nlg_load_structured_file(project, file_path, ref)
        if data is None:
            continue
        path_obj = PurePosixPath(file_path)
        target_type = _nlg_normalize_target_type(path_obj.stem, path_obj.stem)
        if target_type is None:
            logging.warning("Skipping input config file %s; unable to determine target_type.", file_path)
            continue
        for tag_path, logic, columns in _nlg_extract_logic_entries(data):
            if _nlg_should_skip_tag(tag_path):
                continue
            tag = _nlg_derive_tag_name(tag_path)
            for column in columns:
                rows.append(
                    {
                        "target_type": target_type,
                        "config_tag": tag,
                        "config_tag_path": tag_path,
                        "config_profile_column": column,
                        "config_logic": logic,
                        "config_filename": path_obj.name,
                        "config_file_path": file_path,
                    }
                )
    return rows


def _nlg_collect_sql_mapping_rows(project, ref: str, base_path: str) -> List[Dict[str, object]]:
    rows: List[Dict[str, object]] = []
    base_parts = PurePosixPath(base_path).parts
    for file_path in _nlg_walk_repository(project, base_path, ref):
        if not file_path.lower().endswith((".yml", ".yaml", ".json")):
            continue
        path_obj = PurePosixPath(file_path)
        if len(path_obj.parts) <= len(base_parts):
            continue
        target_folder = path_obj.parts[len(base_parts)]
        target_type = _nlg_normalize_target_type(target_folder, target_folder)
        if target_type is None:
            logging.warning("Skipping SQL mapping file %s; unable to determine target_type from folder.", file_path)
            continue
        data = _nlg_load_structured_file(project, file_path, ref)
        if data is None:
            continue
        explicit_target = _nlg_find_explicit_target(data)
        normalized_explicit = _nlg_normalize_target_type(explicit_target, target_type)
        target_type = normalized_explicit or target_type
        insight_type = path_obj.stem
        for tag_path, logic, columns in _nlg_extract_logic_entries(data):
            if _nlg_should_skip_tag(tag_path):
                continue
            tag = _nlg_derive_tag_name(tag_path)
            for column in columns:
                rows.append(
                    {
                        "target_type": target_type,
                        "insight_type": insight_type,
                        "sql_tag": tag,
                        "sql_tag_path": tag_path,
                        "sql_profile_column": column,
                        "sql_logic": logic,
                        "filename_under_sql_column_mapping": path_obj.name,
                        "file_path_under_sql_column_mapping": file_path,
                    }
                )
    return rows


def _nlg_ensure_dataframe(rows: List[Dict[str, object]], columns: Sequence[str]) -> pd.DataFrame:
    df = pd.DataFrame(rows)
    if df.empty:
        df = pd.DataFrame(columns=columns)
    return df


def _nlg_apply_profile_overrides(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty or "target_type" not in df.columns:
        return df
    df = df.copy()
    target_series = df["target_type"].astype(str).str.lower()
    not_null = df["target_type"].notna()
    for target_type, overrides in NLG_PROFILE_OVERRIDES.items():
        mask = not_null & (target_series == target_type.lower())
        if not mask.any():
            continue
        for column, value in overrides.items():
            if column not in df.columns:
                df[column] = None
            df.loc[mask, column] = value
    return df


def _nlg_build_report_dataframes(project, ref: str, report_timestamp: str) -> Tuple[pd.DataFrame, pd.DataFrame]:
    profile_map_rows = _nlg_collect_profile_map(project, ref, NLG_PATH_PROFILE_MAP)
    input_config_rows = _nlg_collect_input_config_rows(project, ref, NLG_PATH_INPUT_CONFIG)
    sql_mapping_rows = _nlg_collect_sql_mapping_rows(project, ref, NLG_PATH_SQL_MAPPING)

    df_profile = _nlg_ensure_dataframe(profile_map_rows, ["target_type", "profile_table", "joining_key"])
    df_profile = _nlg_apply_profile_overrides(df_profile)

    df_config = _nlg_ensure_dataframe(
        input_config_rows,
        [
            "target_type",
            "config_tag",
            "config_tag_path",
            "config_profile_column",
            "config_logic",
            "config_filename",
            "config_file_path",
        ],
    )

    df_sql = _nlg_ensure_dataframe(
        sql_mapping_rows,
        [
            "target_type",
            "insight_type",
            "sql_tag",
            "sql_tag_path",
            "sql_profile_column",
            "sql_logic",
            "filename_under_sql_column_mapping",
            "file_path_under_sql_column_mapping",
        ],
    )

    df_input = df_profile.merge(df_config, on="target_type", how="outer")
    df_sql_merged = df_profile.merge(df_sql, on="target_type", how="outer")

    df_input["current_time_stamp"] = report_timestamp
    df_sql_merged["current_time_stamp"] = report_timestamp

    df_input = _nlg_apply_profile_overrides(df_input)
    df_sql_merged = _nlg_apply_profile_overrides(df_sql_merged)

    return df_input, df_sql_merged


def _nlg_write_excel(input_df: pd.DataFrame, sql_df: pd.DataFrame, directory: str) -> str:
    timestamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d_%H%M%S")
    filename = f"nlg_profile_columns_{timestamp}.xlsx"
    output_path = os.path.abspath(os.path.join(directory, filename))

    logging.info("[NLG Metadata] Writing Excel report to %s", output_path)
    with pd.ExcelWriter(output_path, engine="xlsxwriter") as writer:
        input_df.to_excel(writer, sheet_name="Input_config", index=False)
        sql_df.to_excel(writer, sheet_name="sql_mapping", index=False)

    return output_path


def _nlg_upload_dataframe_to_gp_table(df: pd.DataFrame, table_fqn: str) -> None:
    """
    Same GP pattern as ODM job:
    - DROP TABLE IF EXISTS
    - CREATE TABLE with TEXT columns
    - INSERT via execute_values
    - ALTER OWNER + GRANT SELECT
    """
    df_for_db = df.fillna("").astype(str)

    owner_role = get_owner_role()
    reader_role = get_reader_role()

    drop_sql = f"DROP TABLE IF EXISTS {table_fqn};"
    column_definitions = ", ".join(f'"{column}" TEXT' for column in df_for_db.columns)
    create_sql = f"CREATE TABLE {table_fqn} ({column_definitions});"
    alter_owner_sql = f"ALTER TABLE {table_fqn} OWNER TO {owner_role};"
    grant_sql = f"GRANT SELECT ON {table_fqn} TO {reader_role};"

    hook = _get_postgres_hook()
    with hook.get_conn() as conn:
        conn.autocommit = False
        with conn.cursor() as cur:
            _log_and_execute(cur, drop_sql)
            _log_and_execute(cur, create_sql)

            if not df_for_db.empty:
                columns_clause = ", ".join(f'"{c}"' for c in df_for_db.columns)
                insert_sql = f"INSERT INTO {table_fqn} ({columns_clause}) VALUES %s"
                values = [tuple(row[c] for c in df_for_db.columns) for _, row in df_for_db.iterrows()]

                logging.info("[DB] Bulk inserting %d rows into %s", len(values), table_fqn)
                logging.info("[DB] Insert template:\n%s", insert_sql)
                execute_values(cur, insert_sql, values)

            _log_and_execute(cur, alter_owner_sql)
            _log_and_execute(cur, grant_sql)

        conn.commit()
        logging.info("Table %s refreshed successfully.", table_fqn)


def run_nlg_profile_columns_metadata_job() -> Dict[str, object]:
    """
    Airflow callable:
    - GitLab token via Airflow Variables (same idea as ODM)
    - GP access via PostgresHook (same as ODM)
    - Creates Excel with 2 sheets + refreshes 2 tables
    """
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    private_token = get_private_token(allow_prompt=not is_running_in_airflow())

    base_dir = os.path.dirname(os.path.abspath(__file__))
    timestamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d_%H%M%S")
    temp_dir = os.path.join(base_dir, f"temp_nlg_metadata_{timestamp}")
    os.makedirs(temp_dir, exist_ok=True)
    logging.info("[NLG Metadata] Temporary folder created: %s", temp_dir)

    gl = gitlab.Gitlab(GITLAB_URL, private_token=private_token)
    logging.info("[NLG Metadata] Fetching NLG project metadata...")
    project = gl.projects.get(NLG_PROJECT_PATH)

    report_timestamp = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M:%S%z")
    input_df, sql_df = _nlg_build_report_dataframes(project, NLG_BRANCH, report_timestamp)

    excel_path = _nlg_write_excel(input_df, sql_df, directory=temp_dir)

    gp_schema = get_gp_schema()
    input_table_fqn = f"{gp_schema}.{NLG_TARGET_TABLE_INPUT}"
    sql_table_fqn = f"{gp_schema}.{NLG_TARGET_TABLE_SQL}"

    _nlg_upload_dataframe_to_gp_table(input_df, input_table_fqn)
    _nlg_upload_dataframe_to_gp_table(sql_df, sql_table_fqn)

    logging.info("[NLG Metadata] Completed. Excel: %s", excel_path)
    return {
        "temp_dir": temp_dir,
        "excel_path": excel_path,
        "input_rows": int(len(input_df)),
        "sql_rows": int(len(sql_df)),
        "table_input": input_table_fqn,
        "table_sql": sql_table_fqn,
    }

# =====================================================================================
# NEW: NLG RULES METADATA JOB (RULE TAGS) — Airflow + PostgresHook pattern
# =====================================================================================

# Reuses GITLAB_URL, NLG_PROJECT_PATH, NLG_BRANCH,
# get_gp_schema(), get_owner_role(), get_reader_role(),
# _get_postgres_hook, _log_and_execute, _nlg_walk_repository,
# _nlg_load_structured_file, _nlg_collect_profile_map,
# _nlg_apply_profile_overrides

NLG_PATH_RULES = "dags/nlg/src/rules"
NLG_TARGET_TABLE_RULES = "nlg_rule_metadata_auto_refresh"
NLG_RULE_TAG_PATTERN = re.compile(r"\{([^{}]+)\}")

NLG_RULES_COLUMNS = [
    "target_type",
    "profile_table",
    "joining_key",
    "insight_type",
    "rule_tag",
    "rule_tag_value",
    "filepath",
    "filename",
    "current_timestamp",
]


def _nlg_extract_rule_tags(node: Any) -> List[Tuple[str, str]]:
    """
    Extract {tag_value} occurrences from rule files, paired with their key (rule_tag).
    """
    matches: List[Tuple[str, str]] = []

    def handle_pair(key: str, value: Any) -> None:
        if isinstance(value, list):
            for item in value:
                if isinstance(item, str):
                    for match in NLG_RULE_TAG_PATTERN.findall(item):
                        matches.append((key, match))
        elif isinstance(value, str):
            for match in NLG_RULE_TAG_PATTERN.findall(value):
                matches.append((key, match))

    def walk(obj: Any) -> None:
        if isinstance(obj, dict):
            for k, v in obj.items():
                if isinstance(k, str):
                    handle_pair(k, v)
                if isinstance(v, (dict, list)):
                    walk(v)
        elif isinstance(obj, list):
            for item in obj:
                if isinstance(item, (dict, list)):
                    walk(item)

    walk(node)
    return matches


def _upload_dataframe_to_gp_table_typed(
    df: pd.DataFrame,
    table_fqn: str,
    owner_role: str,
    reader_role: str,
    timestamp_columns: Set[str] | None = None,
) -> None:
    """
    Drop/create/insert using PostgresHook + execute_values.
    Allows TIMESTAMP columns.
    """
    timestamp_columns = timestamp_columns or set()
    df_for_db = df.copy()

    # Ensure expected columns exist and correct dtypes
    for col in df_for_db.columns:
        if col in timestamp_columns:
            df_for_db[col] = pd.to_datetime(df_for_db[col], errors="coerce")
        else:
            df_for_db[col] = df_for_db[col].fillna("").astype(str)

    # Fill timestamps if NaT/None
    now_dt = dt.datetime.now(dt.timezone.utc).replace(tzinfo=None)
    for col in timestamp_columns:
        if col in df_for_db.columns:
            df_for_db[col] = df_for_db[col].fillna(now_dt).apply(
                lambda x: x.to_pydatetime() if isinstance(x, pd.Timestamp) else (now_dt if x is None else x)
            )

    drop_sql = f"DROP TABLE IF EXISTS {table_fqn};"
    column_defs = []
    for col in df_for_db.columns:
        if col in timestamp_columns:
            column_defs.append(f'"{col}" TIMESTAMP')
        else:
            column_defs.append(f'"{col}" TEXT')
    create_sql = f"CREATE TABLE {table_fqn} ({', '.join(column_defs)});"
    alter_owner_sql = f"ALTER TABLE {table_fqn} OWNER TO {owner_role};"
    grant_sql = f"GRANT SELECT ON {table_fqn} TO {reader_role};"

    hook = _get_postgres_hook()
    with hook.get_conn() as conn:
        conn.autocommit = False
        with conn.cursor() as cur:
            _log_and_execute(cur, drop_sql)
            _log_and_execute(cur, create_sql)

            if not df_for_db.empty:
                cols = list(df_for_db.columns)
                columns_clause = ", ".join(f'"{c}"' for c in cols)
                insert_sql = f"INSERT INTO {table_fqn} ({columns_clause}) VALUES %s"

                values = []
                for _, row in df_for_db.iterrows():
                    values.append(tuple(row[c] for c in cols))

                logging.info("[DB] Bulk inserting %d rows into %s", len(values), table_fqn)
                logging.info("[DB] Insert template:\n%s", insert_sql)
                execute_values(cur, insert_sql, values)

            _log_and_execute(cur, alter_owner_sql)
            _log_and_execute(cur, grant_sql)

        conn.commit()
        logging.info("Table %s refreshed successfully.", table_fqn)


def run_nlg_rules_metadata_job() -> Dict[str, object]:
    """
    Airflow callable:
    - Reads NLG profile_tbl.yaml for profile_table/joining_key
    - Scans dags/nlg/src/rules/** for YAML/JSON rule files
    - Extracts rule tags and {tag_value} definitions
    - Writes Excel
    - Refreshes <schema>.nlg_rule_metadata_auto_refresh (schema from Airflow props)
    """
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    private_token = get_private_token(allow_prompt=not is_running_in_airflow())

    base_dir = os.path.dirname(os.path.abspath(__file__))
    timestamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d_%H%M%S")
    temp_dir = os.path.join(base_dir, f"temp_nlg_rules_metadata_{timestamp}")
    os.makedirs(temp_dir, exist_ok=True)
    logging.info("[NLG Rules Metadata] Temporary folder created: %s", temp_dir)

    gl = gitlab.Gitlab(GITLAB_URL, private_token=private_token)
    logging.info("[NLG Rules Metadata] Fetching NLG project metadata...")
    project = gl.projects.get(NLG_PROJECT_PATH)

    # Profile map dataframe (target_type -> profile_table/joining_key)
    profile_rows = _nlg_collect_profile_map(project, NLG_BRANCH, NLG_PATH_PROFILE_MAP)
    df_profile = pd.DataFrame(profile_rows) if profile_rows else pd.DataFrame(columns=["target_type", "profile_table", "joining_key"])
    df_profile["target_type"] = df_profile["target_type"].astype(str).str.strip().str.lower()
    df_profile = _nlg_apply_profile_overrides(df_profile).drop_duplicates(subset=["target_type"], keep="last")

    profile_table_map = (
        df_profile.dropna(subset=["profile_table", "target_type"])
        .drop_duplicates(subset=["target_type"], keep="last")
        .set_index("target_type")["profile_table"]
        .to_dict()
    )
    joining_key_map = (
        df_profile.dropna(subset=["joining_key", "target_type"])
        .drop_duplicates(subset=["target_type"], keep="last")
        .set_index("target_type")["joining_key"]
        .to_dict()
    )

    records: List[Dict[str, object]] = []
    seen_values: Dict[Tuple[str, str, str], Set[str]] = defaultdict(set)

    # Walk rules repository
    for file_path in _nlg_walk_repository(project, NLG_PATH_RULES, NLG_BRANCH):
        if not file_path.lower().endswith((".yml", ".yaml", ".json")):
            continue

        path_obj = PurePosixPath(file_path)

        # Expect: dags/nlg/src/rules/<target_type>/<insight_file>.yml
        try:
            idx = path_obj.parts.index("rules")
        except ValueError:
            continue

        if len(path_obj.parts) <= idx + 2:
            continue

        target_type = path_obj.parts[idx + 1].strip().lower()
        insight_type = path_obj.stem
        filename = path_obj.name

        data = _nlg_load_structured_file(project, file_path, NLG_BRANCH)
        if data is None:
            continue

        for rule_tag, rule_value in _nlg_extract_rule_tags(data):
            dedupe_key = (target_type, insight_type, str(rule_tag))
            rule_val = str(rule_value)
            if rule_val in seen_values[dedupe_key]:
                continue
            seen_values[dedupe_key].add(rule_val)

            records.append(
                {
                    "target_type": target_type,
                    "profile_table": profile_table_map.get(target_type, ""),
                    "joining_key": joining_key_map.get(target_type, ""),
                    "insight_type": insight_type,
                    "rule_tag": str(rule_tag),
                    "rule_tag_value": rule_val,
                    "filepath": file_path,
                    "filename": filename,
                    "current_timestamp": dt.datetime.now(dt.timezone.utc).replace(tzinfo=None),
                }
            )

    df_rules = pd.DataFrame(records, columns=NLG_RULES_COLUMNS)
    if not df_rules.empty:
        df_rules["target_type"] = df_rules["target_type"].astype(str).str.strip().str.lower()
        df_rules = _nlg_apply_profile_overrides(df_rules)

        # Deduplicate
        df_rules = df_rules.drop_duplicates(
            subset=[
                "target_type",
                "profile_table",
                "joining_key",
                "insight_type",
                "rule_tag",
                "rule_tag_value",
                "filepath",
                "filename",
            ]
        ).reset_index(drop=True)

    # Write Excel
    excel_filename = f"nlg_rules_metadata_{timestamp}.xlsx"
    excel_path = os.path.abspath(os.path.join(temp_dir, excel_filename))
    logging.info("[NLG Rules Metadata] Writing Excel report to %s", excel_path)
    with pd.ExcelWriter(excel_path, engine="xlsxwriter") as writer:
        df_rules.to_excel(writer, sheet_name="nlg_rules_metadata", index=False)

    # Upload to GP
    gp_schema = get_gp_schema()
    table_fqn = f"{gp_schema}.{NLG_TARGET_TABLE_RULES}"
    _upload_dataframe_to_gp_table_typed(
        df_rules if not df_rules.empty else pd.DataFrame(columns=NLG_RULES_COLUMNS),
        table_fqn=table_fqn,
        owner_role=get_owner_role(),
        reader_role=get_reader_role(),
        timestamp_columns={"current_timestamp"},
    )

    logging.info("[NLG Rules Metadata] Completed. Rows: %d | Excel: %s", len(df_rules), excel_path)
    return {
        "temp_dir": temp_dir,
        "excel_path": excel_path,
        "row_count": int(len(df_rules)),
        "table_rules": table_fqn,
    }


# =====================================================================================
# NEW: CID PROFILE COLUMNS (MD5 IN DUMMY CONFIG) — Airflow + PostgresHook pattern
# =====================================================================================

CID_CONFIG_BASE_PATH = "dags/nlg/src/config/input_data_config_dummy"
CID_TARGET_TABLE = "cid_columns_metadata_auto_refresh"

CID_OUTPUT_COLUMNS = [
    "target_type",
    "profile_table",
    "joining_key",
    "tag",
    "cid_profile_column",
    "logic",
    "current_timestamp",
    "filepath",
    "filename",
]

# Patterns copied/adapted from your provided script
ALIAS_COLUMN_PATTERN = re.compile(
    r'(?:"?([A-Za-z_][\w$]*)"?\.)?"?([A-Za-z_][\w$]*)"?', re.IGNORECASE
)
BARE_IDENTIFIER_PATTERN = re.compile(r'"?([A-Za-z_][\w$]*)"?')
STRING_LITERAL_PATTERN = re.compile(r"'(?:[^'\\]|\\.)*'|\"(?:[^\"\\]|\\.)*\"")

CID_SQL_KEYWORDS = {
    "ABS","ADD","AND","ANY","ARRAY","AS","ASC","AVG","BETWEEN","BTRIM","BY","CASE","CAST","COALESCE",
    "COLLATE","CONCAT","CONCAT_WS","COUNT","DATE","DESC","DISTINCT","ELSE","END","EXISTS","FALSE","FILTER",
    "FIRST_VALUE","GREATEST","GROUP","HAVING","INITCAP","INNER","JOIN","LAG","LAST_VALUE","LEAD","LEFT",
    "LENGTH","LIKE","LOWER","LTRIM","MAX","MD5","MIN","NOT","NULL","NULLIF","ON","OR","ORDER","OUTER","OVER",
    "POSITION","POWER","REGEXP_REPLACE","REPLACE","RIGHT","ROW_NUMBER","RTRIM","SELECT","SPLIT_PART","SUBSTR",
    "SUBSTRING","SUM","THEN","TO_CHAR","TO_DATE","TRIM","TRUE","UPPER","USING","WHEN","WHERE","WITH",
}

PROFILE_OVERRIDES_FOR_CID: Dict[str, Dict[str, str]] = {
    "fl_recruitment": {"profile_table": "fl_rec_profile_curr_ikg", "joining_key": "fl_rec_profile_key"},
    "fl_ubs_fa": {"profile_table": "fl_fa_profile_curr_ikg", "joining_key": "f1_fa_profile_key"},
}


def _cid_is_url_token(value: str) -> bool:
    lowered = (value or "").lower()
    return lowered in {"http", "https"} or lowered.startswith("http://") or lowered.startswith("https://")


def _cid_normalize_column_name(name: str) -> str:
    if name is None:
        return ""
    cleaned = str(name).strip().strip('"').strip("'")
    if "." in cleaned:
        cleaned = cleaned.split(".")[-1]
    return cleaned.strip('"').strip("'")


def _cid_extract_md5_arguments(logic: str) -> List[str]:
    arguments: List[str] = []
    upper_logic = (logic or "").upper()
    search_start = 0
    marker = "MD5("

    while True:
        idx = upper_logic.find(marker, search_start)
        if idx == -1:
            break
        idx += len(marker)
        depth = 1
        end = idx
        while end < len(logic) and depth > 0:
            char = logic[end]
            if char == "(":
                depth += 1
            elif char == ")":
                depth -= 1
            end += 1
        arguments.append(logic[idx : end - 1])
        search_start = end

    return arguments


def _cid_extract_alias_columns(md5_argument: str) -> List[Tuple[str | None, str]]:
    matches: List[Tuple[str | None, str]] = []
    for alias, col in ALIAS_COLUMN_PATTERN.findall(md5_argument or ""):
        matches.append((alias or None, col))
    return matches


def _cid_extract_profile_columns(logic: str) -> List[str]:
    """
    Extract likely profile column identifiers used inside MD5(...) expressions.
    """
    columns: List[str] = []
    seen: Set[str] = set()

    for md5_arg in _cid_extract_md5_arguments(logic or ""):
        local_found = False
        alias_matches = _cid_extract_alias_columns(md5_arg)

        alias_names: Set[str] = set()
        for alias, _ in alias_matches:
            if alias:
                norm_alias = _cid_normalize_column_name(alias)
                if norm_alias:
                    alias_names.add(norm_alias)

        # 1) Prefer alias.column style
        for alias, col in alias_matches:
            norm = _cid_normalize_column_name(col)
            if not norm or norm in seen:
                continue
            if _cid_is_url_token(norm):
                continue
            if norm in alias_names:
                continue
            if norm.upper() in CID_SQL_KEYWORDS:
                continue
            columns.append(norm)
            seen.add(norm)
            local_found = True

        # 2) Bare identifiers (after stripping strings)
        stripped_argument = ALIAS_COLUMN_PATTERN.sub(lambda m: m.group(2), md5_arg)
        without_strings = STRING_LITERAL_PATTERN.sub(" ", stripped_argument)
        for ident in BARE_IDENTIFIER_PATTERN.findall(without_strings):
            norm = _cid_normalize_column_name(ident)
            if not norm or norm in seen:
                continue
            if norm in alias_names:
                continue
            if norm.upper() in CID_SQL_KEYWORDS:
                continue
            if norm.isdigit():
                continue
            if _cid_is_url_token(norm):
                continue
            columns.append(norm)
            seen.add(norm)
            local_found = True

        # 3) Fallback if nothing found
        if not local_found:
            cleaned_expr = STRING_LITERAL_PATTERN.sub(" ", md5_arg)
            for ident in BARE_IDENTIFIER_PATTERN.findall(cleaned_expr):
                norm = _cid_normalize_column_name(ident)
                if not norm or norm in seen:
                    continue
                if norm in alias_names:
                    continue
                if norm.upper() in CID_SQL_KEYWORDS or norm.isdigit() or _cid_is_url_token(norm):
                    continue
                columns.append(norm)
                seen.add(norm)

    return columns


def _cid_determine_tag(parent_keys: Sequence[str]) -> str:
    for key in reversed(parent_keys):
        if not str(key).startswith("["):
            return str(key)
    return str(parent_keys[-1]) if parent_keys else "unknown"


def _cid_walk_for_md5_strings(node: Any, parent_keys: Sequence[str]) -> Iterator[Tuple[str, str]]:
    """
    Yield (tag, logic_string) for any leaf string containing 'MD5'.
    """
    if isinstance(node, dict):
        for k, v in node.items():
            yield from _cid_walk_for_md5_strings(v, [*parent_keys, str(k)])
    elif isinstance(node, list):
        for idx, item in enumerate(node):
            yield from _cid_walk_for_md5_strings(item, [*parent_keys, f"[{idx}]"])
    elif isinstance(node, str) and "MD5" in node.upper():
        yield (_cid_determine_tag(parent_keys), node.strip())


def _cid_apply_overrides_df(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty or "target_type" not in df.columns:
        return df
    df = df.copy()
    lower_tt = df["target_type"].fillna("").astype(str).str.lower()
    for target_type, override in PROFILE_OVERRIDES_FOR_CID.items():
        mask = lower_tt == target_type.lower()
        if not mask.any():
            continue
        for col in ("profile_table", "joining_key"):
            val = override.get(col)
            if val is not None:
                df.loc[mask, col] = val
    return df


def run_cid_profile_columns_metadata_job() -> Dict[str, object]:
    """
    Airflow callable:
    - scans dags/nlg/src/config/input_data_config_dummy/** for YAML files
    - finds strings containing MD5(...)
    - extracts candidate profile column identifiers
    - merges profile_table/joining_key from profile_tbl.yaml
    - writes Excel
    - refreshes <schema>.cid_columns_metadata_auto_refresh (schema from Airflow props)
    """
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    private_token = get_private_token(allow_prompt=not is_running_in_airflow())

    base_dir = os.path.dirname(os.path.abspath(__file__))
    timestamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d_%H%M%S")
    temp_dir = os.path.join(base_dir, f"temp_cid_metadata_{timestamp}")
    os.makedirs(temp_dir, exist_ok=True)
    logging.info("[CID Metadata] Temporary folder created: %s", temp_dir)

    gl = gitlab.Gitlab(GITLAB_URL, private_token=private_token)
    logging.info("[CID Metadata] Fetching NLG project metadata...")
    project = gl.projects.get(NLG_PROJECT_PATH)

    # Profile map (target_type -> profile_table/joining_key)
    profile_rows = _nlg_collect_profile_map(project, NLG_BRANCH, NLG_PATH_PROFILE_MAP)
    df_profile = pd.DataFrame(profile_rows) if profile_rows else pd.DataFrame(columns=["target_type", "profile_table", "joining_key"])
    df_profile["target_type"] = df_profile["target_type"].astype(str).str.strip().str.lower()
    df_profile = _nlg_apply_profile_overrides(df_profile).drop_duplicates(subset=["target_type"], keep="last")

    profile_table_map = (
        df_profile.dropna(subset=["profile_table", "target_type"])
        .drop_duplicates(subset=["target_type"], keep="last")
        .set_index("target_type")["profile_table"]
        .to_dict()
    )
    joining_key_map = (
        df_profile.dropna(subset=["joining_key", "target_type"])
        .drop_duplicates(subset=["target_type"], keep="last")
        .set_index("target_type")["joining_key"]
        .to_dict()
    )

    now_dt = dt.datetime.now(dt.timezone.utc).replace(tzinfo=None)
    records: List[Dict[str, object]] = []

    # Find YAML files under dummy input config
    for file_path in _nlg_walk_repository(project, CID_CONFIG_BASE_PATH, NLG_BRANCH):
        if not file_path.lower().endswith((".yml", ".yaml")):
            continue

        path_obj = PurePosixPath(file_path)
        target_type = path_obj.stem.strip().lower()
        if not target_type:
            continue

        yaml_text = _nlg_fetch_file_content(project, file_path, NLG_BRANCH).decode("utf-8", errors="replace")

        # Some files might contain multiple YAML docs
        for document in yaml.safe_load_all(yaml_text):
            if document is None:
                continue

            for tag, logic in _cid_walk_for_md5_strings(document, []):
                cols = _cid_extract_profile_columns(logic)
                if not cols:
                    continue
                for col in cols:
                    records.append(
                        {
                            "target_type": target_type,
                            "profile_table": profile_table_map.get(target_type, ""),
                            "joining_key": joining_key_map.get(target_type, ""),
                            "tag": tag,
                            "cid_profile_column": col,
                            "logic": logic,
                            "current_timestamp": now_dt,
                            "filepath": file_path,
                            "filename": path_obj.name,
                        }
                    )

    df_cid = pd.DataFrame(records, columns=CID_OUTPUT_COLUMNS)
    if not df_cid.empty:
        df_cid["target_type"] = df_cid["target_type"].astype(str).str.strip().str.lower()
        df_cid = _cid_apply_overrides_df(df_cid)

        # Deduplicate on (target_type, tag, cid_profile_column)
        df_cid = df_cid.sort_values(["target_type", "tag", "cid_profile_column", "logic"])
        df_cid = df_cid.drop_duplicates(subset=["target_type", "tag", "cid_profile_column"], keep="first").reset_index(drop=True)

    # Write Excel
    excel_filename = f"cid_profile_columns_{timestamp}.xlsx"
    excel_path = os.path.abspath(os.path.join(temp_dir, excel_filename))
    logging.info("[CID Metadata] Writing Excel report to %s", excel_path)
    with pd.ExcelWriter(excel_path, engine="xlsxwriter") as writer:
        df_cid.to_excel(writer, sheet_name="cid_profile_columns", index=False)

    # Upload to GP
    gp_schema = get_gp_schema()
    table_fqn = f"{gp_schema}.{CID_TARGET_TABLE}"
    _upload_dataframe_to_gp_table_typed(
        df_cid if not df_cid.empty else pd.DataFrame(columns=CID_OUTPUT_COLUMNS),
        table_fqn=table_fqn,
        owner_role=get_owner_role(),
        reader_role=get_reader_role(),
        timestamp_columns={"current_timestamp"},
    )

    logging.info("[CID Metadata] Completed. Rows: %d | Excel: %s", len(df_cid), excel_path)
    return {
        "temp_dir": temp_dir,
        "excel_path": excel_path,
        "row_count": int(len(df_cid)),
        "table_cid": table_fqn,
    }

# =====================================================================================
# NEW: IKG TABLE LINEAGE METADATA JOB — Airflow + PostgresHook pattern
# =====================================================================================

# Constants mirrored from the provided standalone file, aligned to module patterns
GENESTS_GROUP_PATH = "ubs/gwma/smart-technology-and-analytics/staat-data-science/staat-ds-genesis/genesis-platform"
IKG_PROJECT_PATH = f"{GENESTS_GROUP_PATH}/ikg-dags"
IKG_BRANCH = "develop"
IKG_SQL_PATH = "dags/ikg/scripts/sql"
IKG_EXCLUDE_FOLDER = "ikg_new fa_shhp_map"  # space-separated, same as original script
IKG_SQL_PATH_PARTS = Path(IKG_SQL_PATH).parts

IKG_TARGET_TABLE = "ikg_table_lineage_metadata_auto_refresh"

IKG_LINEAGE_COLUMNS = [
    "filename",
    "filepath",
    "process",
    "target_table",
    "source_schema",
    "source_table",
    "current_timestamp",
]


@dataclass(frozen=True)
class IKGLineageRow:
    filename: str
    filepath: str
    process: str
    target_table: str
    source_schema: Optional[str]
    source_table: Optional[str]
    current_timestamp: dt.datetime


def _ikg_derive_process(file_path: str) -> str:
    parts = Path(file_path).parts
    prefix_len = len(IKG_SQL_PATH_PARTS)
    if parts[:prefix_len] == IKG_SQL_PATH_PARTS and len(parts) > prefix_len:
        return parts[prefix_len]
    return ""


class IKGGitLabSQLFetcher:
    def __init__(self, project: gitlab.v4.objects.Project, exclude_folders: Sequence[str]) -> None:
        self._project = project
        self._exclude_folders = {folder.lower() for folder in exclude_folders}

    def iter_sql_paths(self) -> Iterable[str]:
        tree = self._project.repository_tree(path=IKG_SQL_PATH, ref=IKG_BRANCH, recursive=True, all=True)
        for node in tree:
            if node.get("type") != "blob":
                continue
            path = node.get("path", "")
            if not path.lower().endswith(".sql"):
                continue
            if self._is_excluded(path):
                logging.debug("[IKG] Skipping excluded path: %s", path)
                continue
            yield path

    def fetch_sql(self, file_path: str) -> str:
        f = self._project.files.get(file_path=file_path, ref=IKG_BRANCH)
        decoded = base64.b64decode(f.content).decode("utf-8", errors="replace")
        return decoded

    def _is_excluded(self, path: str) -> bool:
        parts = {part.lower() for part in Path(path).parts}
        return any(part in self._exclude_folders for part in parts)


class IKGSQLParser:
    TEMPLATE_PATTERN = re.compile(r"{{\s*([^{}]+?)\s*}}")
    SOURCE_CONTEXTS: Tuple[type, ...] = (
        exp.From,
        exp.Join,
        exp.Subquery,
        exp.Select,
        exp.With,
        exp.Union,
        exp.Where,
        exp.Group,
        exp.Having,
        exp.Order,
        exp.SetOperation,
    )

    def extract_tables(self, sql_text: str) -> Set[Tuple[Optional[str], Optional[str]]]:
        """Return a set of (schema, table) pairs referenced inside the SQL text."""
        cleaned = self._remove_sql_comments(sql_text)
        normalized = self._strip_vendor_specific(cleaned)
        sanitized, placeholders = self._replace_templates(normalized)
        sanitized_no_do, do_blocks = self._strip_do_blocks(sanitized)
        logging.debug("[IKG] Sanitized SQL length: %d", len(sanitized_no_do))
        tables = self._parse_sql_to_tables(sanitized_no_do, placeholders)
        for block in do_blocks:
            tables |= self._parse_do_block(block, placeholders)
        # Ensure Optional[str] union is respected
        return {(schema, table) for (schema, table) in tables}

    def _remove_sql_comments(self, sql_text: str) -> str:
        no_block = re.sub(r"/\*.*?\*/", "", sql_text, flags=re.S)
        no_inline = re.sub(r"--.*?$", "", no_block, flags=re.M)
        return no_inline

    def _strip_do_blocks(self, sql_text: str) -> Tuple[str, List[str]]:
        blocks: List[str] = []
        pattern = re.compile(
            r"do\s+\$\$(.*?)\$\$\s*(?:language\s+\w+)?\s*;",
            flags=re.I | re.S,
        )

        def repl(match: Match) -> str:
            blocks.append(match.group(1))
            return ""

        stripped = pattern.sub(repl, sql_text)
        return stripped, blocks

    def _strip_vendor_specific(self, sql_text: str) -> str:
        patterns = [
            r"\bdistributed\s+by\s*\([^;]+?\)",
            r"\bdistributed\s+replicated",
            r"\bon\s+commit\s+preserve\s+rows",
            r"\bwith\s*\(.*?appendonly.*?\)",
            r"\bencode\s*'.*?'",
            r"\borganization\s*\([^)]*\)",
            r"\bpartition\s+by\s+range\s+\([^)]*\)",
        ]
        cleaned = sql_text
        for pattern in patterns:
            cleaned = re.sub(pattern, "", cleaned, flags=re.I | re.S)
        return cleaned

    def _replace_templates(self, sql_text: str) -> Tuple[str, Dict[str, str]]:
        placeholders: Dict[str, str] = {}

        def repl(match: Match) -> str:
            inner = re.sub(r"\s+", "", match.group(1))
            token = f"TEMPLATE_TOKEN_{len(placeholders)}"
            placeholders[token] = f"{{{{{inner}}}}}"
            return token

        sanitized = self.TEMPLATE_PATTERN.sub(repl, sql_text)
        return sanitized, placeholders

    def _parse_sql_to_tables(self, sql_text: str, placeholders: Dict[str, str]) -> Set[Tuple[Optional[str], Optional[str]]]:
        if not sql_text.strip():
            return set()
        try:
            parsed = parse_one(sql_text, read="postgres")  # parse_one for DO-block pieces; below fallback uses regex
            # The top-level may not be a single statement; switch to sqlglot.parse for completeness
            parsed_list = []
            try:
                import sqlglot
                parsed_list = sqlglot.parse(sql_text, read="postgres", error_level="ignore") or []
            except Exception:
                parsed_list = [parsed] if parsed is not None else []
        except Exception:
            return self._regex_fallback(sql_text, placeholders)

        if not parsed_list:
            return set()
        if all(isinstance(statement, exp.Command) for statement in parsed_list):
            return self._regex_fallback(sql_text, placeholders)

        return self._collect_tables(parsed_list, placeholders)

    def _collect_tables(self, statements: List[exp.Expression], placeholders: Dict[str, str]) -> Set[Tuple[Optional[str], Optional[str]]]:
        tables: Set[Tuple[Optional[str], Optional[str]]] = set()
        placeholder_lookup = {k.lower(): v for k, v in placeholders.items()}

        for statement in statements:
            if statement is None:
                continue
            if isinstance(statement, (exp.Alter, exp.Grant)):
                continue
            if isinstance(statement, exp.Command):
                this_obj = statement.this
                text = this_obj.sql().upper() if isinstance(this_obj, exp.Expression) else str(this_obj or "").upper()
                if text.startswith("ALTER") or text.startswith("GRANT"):
                    continue

            cte_names = {(cte.alias_or_name or "").lower() for cte in statement.find_all(exp.CTE)}
            for table in statement.find_all(exp.Table):
                if not self._is_source_context(table):
                    continue
                raw_name = table.name
                if raw_name is None:
                    continue
                table_name = placeholder_lookup.get(raw_name.lower(), raw_name)
                candidate = table_name.lower()
                if candidate in cte_names and not table.db:
                    continue
                schema = table.db
                if schema:
                    restored = placeholder_lookup.get(schema.lower())
                    schema_name = restored or schema
                else:
                    schema_name = None
                tables.add((schema_name, table_name))
        return tables

    def _regex_fallback(self, sanitized_sql: str, placeholders: Dict[str, str], depth: int = 0) -> Set[Tuple[Optional[str], Optional[str]]]:
        if depth > 5:
            return set()
        placeholder_lookup = {k.lower(): v for k, v in placeholders.items()}
        pattern = re.compile(
            r"""(?ix)
            (?:from|inner\s+join|left\s+(?:outer\s+)?join|right\s+(?:outer\s+)?join|full\s+(?:outer\s+)?join|cross\s+join|join)\s+
            (?:
                (?P<schema>[a-z0-9_]+)\.(?P<table>[a-z0-9_]+) |
                (?P<table_only>[a-z0-9_]+)
            )
            """,
        )
        tables: Set[Tuple[Optional[str], Optional[str]]] = set()
        for match in pattern.finditer(sanitized_sql):
            schema = match.group("schema")
            table_name = match.group("table") or match.group("table_only")
            if not table_name:
                continue
            schema_name: Optional[str]
            if schema:
                schema_name = placeholder_lookup.get(schema.lower()) or schema
            else:
                schema_name = None
            restored_table = placeholder_lookup.get(table_name.lower()) or table_name
            tables.add((schema_name, restored_table))

        subquery_pattern = re.compile(r"""(?is)from\s+\((?P<inner>select.+?)\)\s+[a-z0-9_]+""")
        for submatch in subquery_pattern.finditer(sanitized_sql):
            inner_sql = submatch.group("inner")
            tables |= self._regex_fallback(inner_sql, placeholders, depth + 1)
        return tables

    def _is_source_context(self, table: exp.Table) -> bool:
        return any(table.find_ancestor(ctx) is not None for ctx in self.SOURCE_CONTEXTS)

    def _parse_do_block(self, block_text: str, placeholders: Dict[str, str]) -> Set[Tuple[Optional[str], Optional[str]]]:
        prepared = self._prepare_do_block(block_text)
        tables = self._parse_sql_to_tables(prepared, placeholders)
        if tables:
            return tables
        return self._regex_fallback(prepared, placeholders)

    def _prepare_do_block(self, block_text: str) -> str:
        block = self._remove_raise_statements(block_text)
        block = re.sub(r"\blanguage\s+\w+\s*;?", "", block, flags=re.I)
        block = re.sub(r"^\s*begin\b", "", block, flags=re.I)
        block = re.sub(r"\bend\s*;?\s*$", "", block, flags=re.I)
        block = re.sub(r"\bif\b.+?\bthen\b", "", block, flags=re.I | re.S)
        block = re.sub(r"\belse\b", "", block, flags=re.I)
        block = re.sub(r"\bend\s+if\b", "", block, flags=re.I)
        return block

    def _remove_raise_statements(self, sql_text: str) -> str:
        return re.sub(r"\braise\s+(?:exception|error).*?;", "", sql_text, flags=re.I | re.S)


class IKGLineageBuilder:
    def __init__(self, fetcher: IKGGitLabSQLFetcher, parser: IKGSQLParser) -> None:
        self._fetcher = fetcher
        self._parser = parser

    def build(
        self,
        progress_callback: Optional[Callable[[Sequence[IKGLineageRow]], None]] = None,
        run_timestamp: Optional[dt.datetime] = None,
    ) -> List[IKGLineageRow]:
        timestamp = run_timestamp or dt.datetime.utcnow()
        rows: List[IKGLineageRow] = []
        for file_path in self._fetcher.iter_sql_paths():
            logging.info("[IKG] Processing %s", file_path)
            try:
                sql_text = self._fetcher.fetch_sql(file_path)
                tables = self._parser.extract_tables(sql_text)
                if not tables:
                    tables = {(None, None)}
                filename = Path(file_path).name
                target_table = Path(filename).stem
                process = _ikg_derive_process(file_path)
                for schema, table in tables:
                    row = IKGLineageRow(
                        filename=filename,
                        filepath=file_path,
                        process=process,
                        target_table=target_table,
                        source_schema=schema,
                        source_table=table,
                        current_timestamp=timestamp.replace(tzinfo=None),
                    )
                    rows.append(row)
            except Exception as exc:  # noqa: BLE001
                logging.exception("[IKG] Failed to process %s: %s", file_path, exc)
            finally:
                if progress_callback:
                    progress_callback(self._filter_self_references(rows))
        return self._filter_self_references(rows)

    @staticmethod
    def _filter_self_references(rows: Sequence[IKGLineageRow]) -> List[IKGLineageRow]:
        return [
            row
            for row in rows
            if not (row.source_table and row.source_table.lower() == row.target_table.lower())
        ]


def _ikg_rows_to_dataframe(rows: Sequence[IKGLineageRow]) -> pd.DataFrame:
    data = [
        {
            "filename": row.filename,
            "filepath": row.filepath,
            "process": row.process,
            "target_table": row.target_table,
            "source_schema": row.source_schema,
            "source_table": row.source_table,
            "current_timestamp": row.current_timestamp,
        }
        for row in rows
    ]
    return pd.DataFrame(data, columns=IKG_LINEAGE_COLUMNS)


def _ikg_write_excel(df: pd.DataFrame, directory: str, run_timestamp: Optional[dt.datetime] = None) -> str:
    ts = run_timestamp or dt.datetime.now(dt.timezone.utc)
    filename = f"ikg_table_lineage_metadata_{ts.strftime('%Y%m%d_%H%M%S')}.xlsx"
    path = os.path.abspath(os.path.join(directory, filename))
    logging.info("[IKG] Writing Excel report to %s", path)
    with pd.ExcelWriter(path, engine="xlsxwriter") as writer:
        df.to_excel(writer, sheet_name="ikg_table_lineage_metadata", index=False)
    return path


def run_ikg_table_lineage_metadata_job() -> Dict[str, object]:
    """
    Airflow callable:
    - Uses GitLab token from Airflow Variables (nlg_gitlab_token -> odm_gitlab_token -> GENESIS_DDLC_IKG_GIT_SECRET)
    - Uses PostgresHook from Airflow Variable 'IKG_POSTGRES_CONN_ID'
    - Scans dags/ikg/scripts/sql for .sql (excluding configured folders)
    - Parses lineage and refreshes <schema>.ikg_table_lineage_metadata_auto_refresh (schema from Airflow props)
    - Writes Excel snapshot to temp folder
    """
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    private_token = get_private_token(allow_prompt=not is_running_in_airflow())

    base_dir = os.path.dirname(os.path.abspath(__file__))
    timestamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d_%H%M%S")
    temp_dir = os.path.join(base_dir, f"temp_ikg_lineage_{timestamp}")
    os.makedirs(temp_dir, exist_ok=True)
    logging.info("[IKG Lineage] Temporary folder created: %s", temp_dir)

    # GitLab project
    gl = gitlab.Gitlab(GITLAB_URL, private_token=private_token)
    logging.info("[IKG Lineage] Fetching IKG project metadata...")
    project = gl.projects.get(IKG_PROJECT_PATH)

    # Build lineage
    exclude_folders = [folder for folder in IKG_EXCLUDE_FOLDER.split() if folder]
    fetcher = IKGGitLabSQLFetcher(project=project, exclude_folders=exclude_folders)
    parser = IKGSQLParser()
    run_ts = dt.datetime.utcnow()

    # Initialize Excel snapshot (empty) to ensure file exists even if parsing fails early
    empty_excel = _ikg_write_excel(_ikg_rows_to_dataframe([]), directory=temp_dir, run_timestamp=run_ts)

    def flush_excel(current_rows: Sequence[IKGLineageRow]) -> None:
        df_snapshot = _ikg_rows_to_dataframe(current_rows)
        _ikg_write_excel(df_snapshot, directory=temp_dir, run_timestamp=run_ts)

    builder = IKGLineageBuilder(fetcher, parser)
    rows = builder.build(progress_callback=flush_excel, run_timestamp=run_ts)
    df = _ikg_rows_to_dataframe(rows)
    excel_path = _ikg_write_excel(df, directory=temp_dir, run_timestamp=run_ts)

    # Upload to GP (TIMESTAMP column support)
    gp_schema = get_gp_schema()
    table_fqn = f"{gp_schema}.{IKG_TARGET_TABLE}"
    _upload_dataframe_to_gp_table_typed(
        df if not df.empty else pd.DataFrame(columns=IKG_LINEAGE_COLUMNS),
        table_fqn=table_fqn,
        owner_role=get_owner_role(),
        reader_role=get_reader_role(),
        timestamp_columns={"current_timestamp"},
    )

    logging.info("[IKG Lineage] Completed. Rows: %d | Excel: %s", len(df), excel_path)
    return {
        "temp_dir": temp_dir,
        "excel_path": excel_path if df is not None else empty_excel,
        "row_count": int(len(df)),
        "table_lineage": table_fqn,
    }


# =====================================================================================
# CLEANUP (ENHANCED TO SUPPORT LIST OR STRING) - keeps DAG as single cleanup task
# =====================================================================================

def cleanup_temp_folder(temp_dir: Union[str, List[str]]) -> None:
    if not temp_dir:
        return

    dirs = temp_dir if isinstance(temp_dir, list) else [temp_dir]
    for d in dirs:
        if d and os.path.exists(d):
            shutil.rmtree(d)
            logging.info("[Cleanup] Temporary folder deleted: %s", d)


# =====================================================================================
# LOCAL EXECUTION — ``python odm_metadata_python_module.py [job ...]``
# =====================================================================================

_JOB_REGISTRY: Dict[str, Callable[[], Dict[str, object]]] = {
    "odm": run_odm_metadata_job,
    "nlg": run_nlg_profile_columns_metadata_job,
    "nlg_rules": run_nlg_rules_metadata_job,
    "cid": run_cid_profile_columns_metadata_job,
    "ikg_lineage": run_ikg_table_lineage_metadata_job,
}


def _run_local(jobs: Sequence[str] | None = None) -> None:
    """Execute one or more metadata jobs locally (outside Airflow).

    Parameters
    ----------
    jobs : list of str, optional
        Job keys to run (see ``_JOB_REGISTRY``).  When *None* or empty,
        all jobs are executed sequentially.
    """
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    if not jobs:
        jobs = list(_JOB_REGISTRY.keys())

    for key in jobs:
        func = _JOB_REGISTRY.get(key)
        if func is None:
            logging.error("Unknown job '%s'. Available: %s", key, ", ".join(_JOB_REGISTRY))
            continue
        logging.info("=" * 72)
        logging.info("Running job: %s", key)
        logging.info("=" * 72)
        result = func()
        logging.info("Result: %s", result)
        temp = result.get("temp_dir")
        if temp:
            logging.info("Temp folder (not cleaned up): %s", temp)


if __name__ == "__main__":
    import sys

    _run_local(sys.argv[1:] or None)